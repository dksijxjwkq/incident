﻿using UnityEngine;
using UnityEngine.InputSystem;

namespace K_Incident.Core
{
    [RequireComponent(typeof(CharacterController))]
    public class K_PlayerMotor : MonoBehaviour
    {
        [Header("Movement Speeds")]
        [SerializeField] private float _walkSpeed = 1.8f;
        [SerializeField] private float _runSpeed = 4.5f;
        [SerializeField] private float _crouchSpeed = 1.2f;

        [Header("Dynamics")]
        [SerializeField] private float _accelerationTime = 0.25f;
        [SerializeField] private float _decelerationTime = 0.1f;
        [SerializeField] private float _rotationSpeed = 720f;
        [SerializeField] private float _gravityMultiplier = 2.0f;

        [Header("References")]
        [SerializeField] private K_WeightManager _weightManager;
        [SerializeField] private K_VitalitySystem _vitalitySystem;

        [Header("Status (Read Only)")]
        [SerializeField] private bool _isLimping;
        [SerializeField] private bool _isShockActive;

        private CharacterController _controller;
        private UnityEngine.Camera _mainCamera;
        private K_InputActions _inputActions;
        private K_HealthSystem _health;

        private Vector3 _currentVelocityXZ;
        private Vector3 _smoothVelocityRef;
        private float _verticalVelocity;

        // Константа минимальной скорости (Аспект №2)
        private const float MIN_SPEED_FLOOR = 0.05f;

        // Для отладочного логирования (раз в секунду)
        private float _lastLogTime;

        // =====================================================================
        // БЛОКИРОВКА ДВИЖЕНИЯ (для инвентаря)
        // =====================================================================
        private bool _movementEnabled = true;

        private void Awake()
        {
            _controller = GetComponent<CharacterController>();
            _health = GetComponent<K_HealthSystem>();

            // Автопоиск ссылок если не назначены
            if (_weightManager == null)
                _weightManager = GetComponent<K_WeightManager>();
            if (_vitalitySystem == null)
                _vitalitySystem = GetComponent<K_VitalitySystem>();

            if (_controller != null)
                _controller.stepOffset = 0.4f;

            _mainCamera = UnityEngine.Camera.main;
            _inputActions = new K_InputActions();
        }

        private void OnEnable() => _inputActions?.Enable();
        private void OnDisable() => _inputActions?.Disable();

        // =====================================================================
        // ONDESTROY — ДИСПОЗИЦИЯ INPUT ACTIONS (ИСПРАВЛЕНИЕ УТЕЧКИ)
        // =====================================================================
        private void OnDestroy()
        {
            // Критически важно: Dispose() освобождает внутренние ресурсы InputActionAsset
            _inputActions?.Dispose();
        }

        private void Update()
        {
            // ✅ ПРОВЕРКА: если движение заблокировано (инвентарь открыт)
            if (!_movementEnabled) return;

            if (_mainCamera == null || _inputActions == null || (_health != null && _health.IsDead))
                return;

            UpdateStatusFlags();
            ProcessMovement();
            ProcessRotation();
            ApplyGravityAndMove();
        }

        private void UpdateStatusFlags()
        {
            if (_health == null) return;

            _isShockActive = _health.IsShocked;
            _isLimping = _health.HasLegFracture && !_isShockActive;
        }

        private void ProcessMovement()
        {
            if (_health == null) return;

            Vector2 input = _inputActions.Player.Move.ReadValue<Vector2>();
            bool isSprintingInput = _inputActions.Player.Sprint.ReadValue<float>() > 0.1f;
            bool isCrouching = _inputActions.Player.Crouch.ReadValue<float>() > 0.1f;

            // Нельзя бежать, если есть перелом ноги, КРОМЕ случаев, когда активен шок
            bool canSprint = (!_health.HasLegFracture || _isShockActive);

            // Блокировка спринта при перегрузе (Аспект №2)
            if (_weightManager != null && _weightManager.IsOverloaded())
            {
                canSprint = false;
            }

            float targetSpeed = _walkSpeed;
            if (isCrouching)
                targetSpeed = _crouchSpeed;
            else if (isSprintingInput && canSprint)
                targetSpeed = _runSpeed;

            // Модификаторы скорости при переломах ног (если нет шока)
            if (!_isShockActive && _health.HasLegFracture)
            {
                bool leftLegBroken = _health.IsFractured(BodyPart.LeftLeg);
                bool rightLegBroken = _health.IsFractured(BodyPart.RightLeg);

                if (leftLegBroken && rightLegBroken)
                {
                    targetSpeed *= 0.3f; // Две ноги сломаны
                }
                else if (leftLegBroken || rightLegBroken)
                {
                    targetSpeed *= 0.6f; // Одна нога сломана
                }
            }

            // =================================================================
            // ИНТЕГРАЦИЯ ПЕРЕГРУЗА (Аспект №2)
            // =================================================================
            if (_weightManager != null)
            {
                // Применяем множитель скорости от веса
                float weightMult = _weightManager.GetSpeedMultiplier();
                targetSpeed *= weightMult;

#if UNITY_EDITOR
                // Логируем только раз в секунду
                if (Time.time - _lastLogTime >= 1f)
                {
                    Debug.Log($"[Motor] Speed: Base={_runSpeed:F1} × WeightMult={weightMult:F2} = {targetSpeed:F2} m/s");
                    _lastLogTime = Time.time;
                }
#endif
            }

            // =================================================================
            // ОТЛАДКА: ХОЛОД СНИЖАЕТ СКОРОСТЬ НА 20% (Аспект №9)
            // =================================================================
#if UNITY_EDITOR
            if (_vitalitySystem != null && _vitalitySystem.IsColdCritical)
            {
                float coldSpeedPenalty = 0.8f; // 20% снижение
                float speedBefore = targetSpeed;
                targetSpeed *= coldSpeedPenalty;

                // Логируем только раз в секунду
                if (Time.time - _lastLogTime >= 1f)
                {
                    Debug.Log($"[Motor] COLD PENALTY: {speedBefore:F2} → {targetSpeed:F2} m/s (-20%)");
                    _lastLogTime = Time.time;
                }
            }
#endif

            // =================================================================
            // МИНИМАЛЬНЫЙ ПОРОГ СКОРОСТИ (Аспект №2: 0.05 от базы)
            // =================================================================
            float minSpeed = _runSpeed * MIN_SPEED_FLOOR;
            if (targetSpeed < minSpeed && input.sqrMagnitude > 0.01f)
            {
                targetSpeed = minSpeed;
#if UNITY_EDITOR
                // Логируем только раз в секунду
                if (Time.time - _lastLogTime >= 1f)
                {
                    Debug.Log($"[Motor] Speed clamped to minimum: {minSpeed:F2} m/s");
                    _lastLogTime = Time.time;
                }
#endif
            }

            if (input.sqrMagnitude < 0.01f)
            {
                targetSpeed = 0f;
            }

            Vector3 camForward = _mainCamera.transform.forward;
            Vector3 camRight = _mainCamera.transform.right;
            camForward.y = 0;
            camRight.y = 0;
            camForward.Normalize();
            camRight.Normalize();

            Vector3 targetDirection = (camForward * input.y + camRight * input.x).normalized;
            Vector3 targetVelocity = targetDirection * targetSpeed;
            float smoothTime = targetSpeed > 0.01f ? _accelerationTime : _decelerationTime;
            _currentVelocityXZ = Vector3.SmoothDamp(_currentVelocityXZ, targetVelocity, ref _smoothVelocityRef, smoothTime);
        }

        private void ProcessRotation()
        {
            Plane groundPlane = new Plane(Vector3.up, transform.position);
            Ray ray = _mainCamera.ScreenPointToRay(Mouse.current.position.ReadValue());

            if (groundPlane.Raycast(ray, out float hitDistance))
            {
                Vector3 lookPoint = ray.GetPoint(hitDistance);
                Vector3 direction = (lookPoint - transform.position);
                direction.y = 0;

                if (direction.sqrMagnitude > 0.01f)
                {
                    Quaternion targetRot = Quaternion.LookRotation(direction);
                    transform.rotation = Quaternion.RotateTowards(transform.rotation, targetRot, _rotationSpeed * Time.deltaTime);
                }
            }
        }

        private void ApplyGravityAndMove()
        {
            if (_controller == null) return;

            if (_controller.isGrounded)
                _verticalVelocity = -2.0f;
            else
                _verticalVelocity += Physics.gravity.y * _gravityMultiplier * Time.deltaTime;

            Vector3 finalMotion = _currentVelocityXZ;
            finalMotion.y = _verticalVelocity;

            _controller.Move(finalMotion * Time.deltaTime);
        }

        // =====================================================================
        // ГЕТТЕРЫ ДЛЯ ДРУГИХ СИСТЕМ
        // =====================================================================
        public bool IsLimping => _isLimping;
        public bool IsShockActive => _isShockActive;
        public float CurrentSpeed => _currentVelocityXZ.magnitude;
        public Vector3 CurrentVelocity => _currentVelocityXZ;

        // =====================================================================
        // МЕТОД БЛОКИРОВКИ ДВИЖЕНИЯ
        // =====================================================================
        public void SetMovementEnabled(bool enabled)
        {
            _movementEnabled = enabled;
            if (!enabled)
            {
                _currentVelocityXZ = Vector3.zero;
            }
        }
    }
}