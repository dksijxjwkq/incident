﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using K_Incident.Core;
using K_Incident.Core.Inventory;
using System.Collections.Generic;
using UnityEngine.EventSystems;

public class K_InventoryUI : MonoBehaviour
{
    [Header("Grid Config")]
    [SerializeField] private float slotSize = 80f;
    [SerializeField] private float slotSpacing = -16f;
    [SerializeField] private float slotCompression = 1f;

    [Header("References")]
    [SerializeField] private K_InventorySetup _inventorySetup;
    [SerializeField] private TextMeshProUGUI _weightText;
    [SerializeField] private GameObject _slotPrefab;
    [SerializeField] private GameObject _uiItemPrefab;
    [SerializeField] private GameObject _dragGhostPrefab;

    [Header("Player Inventory (LEFT PANE)")]
    [SerializeField] private Transform _pocketsGrid;
    [SerializeField] private Transform _backpackGridParent;
    [SerializeField] private Transform _backpackGrid;
    [SerializeField] private GameObject _backpackPanel;
    [SerializeField] private Transform _pocketsItemsContainer;
    [SerializeField] private Transform _backpackItemsContainer;

    [Header("Equipment Slots")]
    [SerializeField] private K_EquipmentSlotUI _primarySlot1;
    [SerializeField] private K_EquipmentSlotUI _primarySlot2;
    [SerializeField] private K_EquipmentSlotUI _pistolSlot;
    [SerializeField] private K_EquipmentSlotUI _backpackSlot;

    [Header("Surroundings/Container (RIGHT PANE)")]
    [SerializeField] private GameObject _surroundingsPanel;
    [SerializeField] private Transform _surroundingsGrid;
    [SerializeField] private Transform _surroundingsItemsContainer;
    [SerializeField] private TextMeshProUGUI _containerNameText;

    [Header("Configuration")]
    [SerializeField] private KeyCode _openCloseKey = KeyCode.Tab;
    [SerializeField] private KeyCode _rotateKey = KeyCode.R;

    [Header("UI Colors")]
    [SerializeField] private Color _dragValidColor = new Color(0.33f, 0.55f, 0.33f, 0.7f);
    [SerializeField] private Color _dragInvalidColor = new Color(0.71f, 0.24f, 0.24f, 0.7f);
    [SerializeField] private Color _textNormalColor = new Color(0.71f, 0.73f, 0.75f);
    [SerializeField] private Color _textWarningColor = new Color(0.71f, 0.55f, 0.24f);
    [SerializeField] private Color _textCriticalColor = new Color(0.71f, 0.24f, 0.24f);

    private const int POCKET_COLUMNS = 4;
    private const int POCKET_ROWS = 2;
    private const int PROTOTYPE_BACKPACK_WIDTH = 8;
    private const int PROTOTYPE_BACKPACK_HEIGHT = 10;
    private const int POOL_PREWARM_COUNT = 100;
    private const float WEIGHT_WARNING_RATIO = 0.9f;
    private const float WEIGHT_CRITICAL_RATIO = 1.1f;
    private const float PANEL_PADDING = 16f;

    private InventoryController _playerController;
    private InventoryController _activeContainerController;
    private CanvasGroup _canvasGroup;
    private bool _isOpen;
    private bool _isLootingContainer;

    private readonly Queue<UI_Item> _itemPool = new Queue<UI_Item>();
    private readonly Dictionary<string, UI_Item> _activeItems = new Dictionary<string, UI_Item>();
    private readonly List<RaycastResult> _raycastBuffer = new List<RaycastResult>(8);
    private PointerEventData _cachedEventData;

    private bool _isDragging;
    private UI_Item _draggedItem;
    private GameObject _dragGhost;
    private Image _dragGhostImage;
    private bool _pendingRefresh;

    public static event System.Action<InventoryController> OnContainerClosed;

    private void Awake()
    {
        _canvasGroup = GetComponent<CanvasGroup>();
        if (_canvasGroup == null) { Debug.LogError("[InventoryUI] CanvasGroup missing!"); enabled = false; return; }
        InitializeCanvasState();
        if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);

        if (_dragGhostPrefab != null)
        {
            _dragGhost = Instantiate(_dragGhostPrefab, transform);
            _dragGhost.SetActive(false);
            _dragGhostImage = _dragGhost.GetComponent<Image>();
            var layout = _dragGhost.GetComponent<LayoutElement>();
            if (layout == null) layout = _dragGhost.AddComponent<LayoutElement>();
            layout.ignoreLayout = true;
        }

        _cachedEventData = new PointerEventData(null);
        PreWarmPool(POOL_PREWARM_COUNT);
        DisableLayoutOnItemContainers();
    }

    private void Start()
    {
        if (!InitializeReferences()) { Debug.LogError("[InventoryUI] Init FAILED!"); return; }
        BuildAllGrids();
        SubscribeToEvents();
        UpdateWeightDisplay(_playerController.CurrentWeightKg);
    }

    private void Update()
    {
        if (Input.GetKeyDown(_openCloseKey)) ToggleInventory();
        if (_isDragging)
        {
            UpdateDragGhost();
            if (Input.GetKeyDown(_rotateKey) && _draggedItem?.Item?.Data?.CanRotate == true)
                RotateDraggedItem();
        }
    }

    private void OnDestroy()
    {
        UnsubscribeFromEvents();
        ClearPooledItems();
        OnContainerClosed = null;
        if (_dragGhost != null) { Destroy(_dragGhost); _dragGhost = null; }
    }

    private void InitializeCanvasState()
    {
        _canvasGroup.alpha = 0f;
        _canvasGroup.interactable = false;
        _canvasGroup.blocksRaycasts = false;
    }

    private bool InitializeReferences()
    {
        if (_inventorySetup == null)
        {
            _inventorySetup = FindFirstObjectByType<K_InventorySetup>();
            if (_inventorySetup == null) { Debug.LogError("[InventoryUI] K_InventorySetup not found!"); return false; }
        }
        _playerController = _inventorySetup.Controller;
        if (_playerController == null) { Debug.LogError("[InventoryUI] Controller is null!"); return false; }
        return true;
    }

    private void PreWarmPool(int count)
    {
        if (_uiItemPrefab == null) { Debug.LogError("[InventoryUI] UI_Item prefab not assigned!"); return; }
        for (int i = 0; i < count; i++) _itemPool.Enqueue(CreateNewPooledItem());
    }

    private UI_Item CreateNewPooledItem()
    {
        var newItem = Instantiate(_uiItemPrefab).GetComponent<UI_Item>();
        newItem.gameObject.SetActive(false);
        newItem.transform.SetParent(transform, false);
        CanvasGroup cg = newItem.GetComponent<CanvasGroup>();
        if (cg == null) cg = newItem.gameObject.AddComponent<CanvasGroup>();
        cg.alpha = 1f; cg.interactable = true; cg.blocksRaycasts = true;
        return newItem;
    }

    private void DisableLayoutOnItemContainers()
    {
        foreach (var container in new[] { _pocketsItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer })
        {
            if (container == null) continue;
            var grid = container.GetComponent<GridLayoutGroup>();
            if (grid != null) grid.enabled = false;
            var image = container.GetComponent<Image>();
            if (image != null) image.raycastTarget = false;
            foreach (var graphic in container.GetComponents<UnityEngine.UI.Graphic>()) graphic.raycastTarget = false;
        }
    }

    private void BuildAllGrids()
    {
        BuildGrid(_pocketsGrid, POCKET_COLUMNS * POCKET_ROWS, POCKET_COLUMNS, GridType.Pockets);
        if (_backpackGrid != null && _backpackPanel != null)
        {
            int bw = _playerController.GetSaveData().Width;
            int bh = _playerController.GetSaveData().Height;
            RebuildBackpackGrid(bw, bh);
            _backpackPanel.SetActive(true);
        }
        SetupEquipmentSlots();
    }

    private void SetupEquipmentSlots()
    {
        if (_primarySlot1 != null) _primarySlot1.Initialize(this, EquipmentSlotType.Primary);
        if (_primarySlot2 != null) _primarySlot2.Initialize(this, EquipmentSlotType.Primary);
        if (_pistolSlot != null) _pistolSlot.Initialize(this, EquipmentSlotType.Pistol);
    }

    private void BuildGrid(Transform parent, int slotCount, int columns, GridType gridType)
    {
        if (parent == null || _slotPrefab == null) return;
        ClearGrid(parent);
        SetupGridLayout(parent, columns, slotSize);
        for (int i = 0; i < slotCount; i++)
        {
            GameObject slot = Instantiate(_slotPrefab, parent);
            var slotUI = slot.GetComponent<K_InventorySlotUI>();
            if (slotUI != null) { int x = i % columns; int y = i / columns; slotUI.Setup(x, y, gridType, this); }
        }
        var rt = parent.GetComponent<RectTransform>();
        if (rt != null) LayoutRebuilder.ForceRebuildLayoutImmediate(rt);
    }

    private void ClearGrid(Transform parent) { if (parent == null) return; for (int i = parent.childCount - 1; i >= 0; i--) Destroy(parent.GetChild(i).gameObject); }

    private void SetupGridLayout(Transform parent, int columns, float cellSize)
    {
        var gridLayout = parent.GetComponent<GridLayoutGroup>();
        if (gridLayout == null) gridLayout = parent.gameObject.AddComponent<GridLayoutGroup>();
        gridLayout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
        gridLayout.constraintCount = columns;
        gridLayout.cellSize = new Vector2(cellSize, cellSize);
        gridLayout.spacing = new Vector2(slotSpacing, slotSpacing);
        gridLayout.childAlignment = TextAnchor.UpperLeft;
        gridLayout.padding = new RectOffset(0, 0, 0, 0);
    }

    public void OnBackpackEquipped(InventoryItem backpackItem) { }
    public void OnBackpackUnequipped() { }

    public void RebuildBackpackGrid(int width, int height)
    {
        if (_backpackGrid == null || _slotPrefab == null) { Debug.LogError("[InventoryUI] Backpack grid not assigned!"); return; }
        ClearGrid(_backpackGrid);
        SetupGridLayout(_backpackGrid, width, slotSize);
        ResizeBackpackPanel(width, height);
        int totalSlots = width * height;
        for (int i = 0; i < totalSlots; i++)
        {
            GameObject slot = Instantiate(_slotPrefab, _backpackGrid);
            var slotUI = slot.GetComponent<K_InventorySlotUI>();
            if (slotUI != null) { int x = i % width; int y = i / width; slotUI.Setup(x, y, GridType.Backpack, this); }
        }
        var rt = _backpackGrid.GetComponent<RectTransform>();
        if (rt != null) LayoutRebuilder.ForceRebuildLayoutImmediate(rt);
        RefreshAll();
    }

    private void ResizeBackpackPanel(int cols, int rows)
    {
        if (_backpackPanel == null) return;
        float totalWidth = cols * slotSize + (cols - 1) * slotSpacing + PANEL_PADDING;
        float totalHeight = rows * slotSize + (rows - 1) * slotSpacing + PANEL_PADDING;
        var rect = _backpackPanel.GetComponent<RectTransform>();
        if (rect != null) rect.sizeDelta = new Vector2(totalWidth, totalHeight);
    }

    public void HideBackpackGrid() { }

    public void OpenContainer(InventoryController containerController, string containerName, int width, int height)
    {
        if (containerController == null) { Debug.LogError("[InventoryUI] Cannot open container: Controller is null!"); return; }
        _activeContainerController = containerController;
        _isLootingContainer = true;
        _isOpen = true;
        SetCanvasActive(true);
        if (_surroundingsPanel != null)
        {
            _surroundingsPanel.SetActive(true);
            if (_containerNameText != null && !string.IsNullOrEmpty(containerName)) _containerNameText.text = containerName.ToUpper();
            RebuildSurroundingsGrid(width, height);
        }
        RefreshAll();
    }

    private void RebuildSurroundingsGrid(int width, int height)
    {
        if (_surroundingsGrid == null || _slotPrefab == null) return;
        ClearGrid(_surroundingsGrid);
        SetupGridLayout(_surroundingsGrid, width, slotSize);
        if (_surroundingsPanel != null)
        {
            float totalWidth = width * slotSize + (width - 1) * slotSpacing + PANEL_PADDING;
            float totalHeight = height * slotSize + (height - 1) * slotSpacing + PANEL_PADDING;
            var rect = _surroundingsPanel.GetComponent<RectTransform>();
            if (rect != null) rect.sizeDelta = new Vector2(totalWidth, totalHeight);
        }
        int totalSlots = width * height;
        for (int i = 0; i < totalSlots; i++)
        {
            GameObject slot = Instantiate(_slotPrefab, _surroundingsGrid);
            var slotUI = slot.GetComponent<K_InventorySlotUI>();
            if (slotUI != null) { int x = i % width; int y = i / width; slotUI.Setup(x, y, GridType.Container, this); }
        }
        var rt = _surroundingsGrid.GetComponent<RectTransform>();
        if (rt != null) LayoutRebuilder.ForceRebuildLayoutImmediate(rt);
    }

    private void CloseContainer()
    {
        _isLootingContainer = false;
        InventoryController controllerToNotify = _activeContainerController;
        if (controllerToNotify != null) OnContainerClosed?.Invoke(controllerToNotify);
        _activeContainerController = null;
        if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
    }

    public void ToggleInventory() { if (_isOpen) CloseInventory(); else OpenInventory(); }

    private void OpenInventory()
    {
        _isOpen = true;
        _isLootingContainer = false;
        _activeContainerController = null;
        SetCanvasActive(true);
        if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
        RefreshAll();
    }

    public void CloseInventory()
    {
        if (_isDragging) { _isDragging = false; _draggedItem = null; if (_dragGhost != null) _dragGhost.SetActive(false); if (_dragGhostImage != null) _dragGhostImage.color = Color.white; }
        _isOpen = false;
        _isLootingContainer = false;
        CloseContainer();
        SetCanvasActive(false);
        ReturnAllItemsToPool();
    }

    private UI_Item GetPooledItem() { if (_itemPool.Count > 0) return _itemPool.Dequeue(); return CreateNewPooledItem(); }

    private void ReturnToPool(UI_Item item)
    {
        if (item == null) return;
        item.ResetState();
        item.gameObject.SetActive(false);
        item.transform.SetParent(transform, false);
        _itemPool.Enqueue(item);
    }

    private void ClearPooledItems() { foreach (var item in _itemPool) { if (item != null) Destroy(item.gameObject); } _itemPool.Clear(); _activeItems.Clear(); }

    private void ReturnAllItemsToPool() { foreach (var item in _activeItems.Values) ReturnToPool(item); _activeItems.Clear(); }

    public void RefreshAll()
    {
        ReturnAllItemsToPool();
        ForceRebuildGridLayouts();

        for (int y = 0; y < POCKET_ROWS; y++)
            for (int x = 0; x < POCKET_COLUMNS; x++)
                RefreshSlot(GridType.Pockets, x, y);

        if (_backpackGrid != null)
        {
            int bw = _playerController.GetSaveData().Width;
            int bh = _playerController.GetSaveData().Height;
            for (int y = 0; y < bh; y++)
                for (int x = 0; x < bw; x++)
                    RefreshSlot(GridType.Backpack, x, y);
        }

        if (_surroundingsGrid != null && _surroundingsGrid.childCount > 0 && _isLootingContainer)
        {
            int cw = _surroundingsGrid.GetComponent<GridLayoutGroup>().constraintCount;
            int ch = _surroundingsGrid.childCount / cw;
            for (int y = 0; y < ch; y++)
                for (int x = 0; x < cw; x++)
                    RefreshSlot(GridType.Container, x, y);
        }
        RefreshEquipmentSlots();

        // ✅ КРИТИЧНО: Принудительно обновляем Canvas до того, как Input System начнет читать рейкасты
        Canvas.ForceUpdateCanvases();
    }

    private void ForceRebuildGridLayouts()
    {
        if (_pocketsGrid != null) { var rt = _pocketsGrid.GetComponent<RectTransform>(); if (rt != null) LayoutRebuilder.ForceRebuildLayoutImmediate(rt); }
        if (_backpackGrid != null && _backpackPanel != null && _backpackPanel.activeSelf) { var rt = _backpackGrid.GetComponent<RectTransform>(); if (rt != null) LayoutRebuilder.ForceRebuildLayoutImmediate(rt); }
        if (_surroundingsGrid != null && _isLootingContainer) { var rt = _surroundingsGrid.GetComponent<RectTransform>(); if (rt != null) LayoutRebuilder.ForceRebuildLayoutImmediate(rt); }
    }

    public void RefreshSlot(GridType gridType, int x, int y)
    {
        if (x < 0 || y < 0) return;
        string key = GetCellKey(gridType, x, y);
        InventoryController controller = (gridType == GridType.Container) ? _activeContainerController : _playerController;
        if (controller == null) return;

        int gridWidth, gridHeight;
        switch (gridType)
        {
            case GridType.Pockets: gridWidth = POCKET_COLUMNS; gridHeight = POCKET_ROWS; break;
            case GridType.Backpack:
            case GridType.Container:
            default: gridWidth = controller.GetSaveData().Width; gridHeight = controller.GetSaveData().Height; break;
        }
        if (x >= gridWidth || y >= gridHeight) return;

        InventoryItem item = controller.GetItemAt(x, y);

        if (_activeItems.TryGetValue(key, out var uiItem))
        {
            if (item == null) { ReturnToPool(uiItem); _activeItems.Remove(key); }
            else { uiItem.UpdateData(item); uiItem.gameObject.SetActive(true); }
        }
        else if (item != null)
        {
            if (controller.IsRootCell(item.InstanceID, x, y))
                CreateUIItem(item, x, y, gridType);
        }
    }

    private string GetCellKey(GridType gridType, int x, int y) => $"{gridType}_{x}_{y}";

    public void CreateUIItem(InventoryItem item, int x, int y, GridType gridType)
    {
        // ✅ ДОБАВЛЕНЫ ЛОГИ ДЛЯ ОТЛАДКИ
        Debug.Log($"[CreateUIItem] Item {item.InstanceID} at ({x},{y}) in {gridType}");
        Debug.Log($"[CreateUIItem] Key: {GetCellKey(gridType, x, y)}");

        if (_uiItemPrefab == null || item == null) return;
        if (x < 0 || y < 0) return;

        string key = GetCellKey(gridType, x, y);
        if (_activeItems.ContainsKey(key)) return;

        Transform parentContainer = GetItemsContainer(gridType);
        if (parentContainer == null) { Debug.LogError($"[InventoryUI] Items container not found for {gridType}!"); return; }

        UI_Item uiItem = GetPooledItem();

        // ✅ 1. Настраиваем иерархию и позицию ПОКА объект неактивен
        uiItem.transform.SetParent(parentContainer, false);
        uiItem.transform.SetAsLastSibling();

        var rect = uiItem.GetComponent<RectTransform>();
        if (rect != null)
        {
            Vector2Int size = item.CurrentSize;
            float widthPx = size.x * slotSize + (size.x - 1) * slotSpacing;
            float heightPx = size.y * slotSize + (size.y - 1) * slotSpacing;

            rect.anchorMin = new Vector2(0f, 1f);
            rect.anchorMax = new Vector2(0f, 1f);
            rect.pivot = new Vector2(0f, 1f);
            rect.sizeDelta = new Vector2(widthPx, heightPx);
            float step = slotSize + slotSpacing;
            rect.anchoredPosition = new Vector2(x * step, -y * step);
            rect.localScale = Vector3.one;
            rect.localRotation = Quaternion.identity;
        }

        CanvasGroup canvasGroup = uiItem.GetComponent<CanvasGroup>();
        if (canvasGroup == null) canvasGroup = uiItem.gameObject.AddComponent<CanvasGroup>();
        canvasGroup.alpha = 1f;
        canvasGroup.interactable = true;
        canvasGroup.blocksRaycasts = true;

        // ✅ ЛОГ состояния CanvasGroup
        Debug.Log($"[CreateUIItem] CanvasGroup: blocksRaycasts={canvasGroup.blocksRaycasts}, interactable={canvasGroup.interactable}");

        // ✅ 2. Активируем ТОЛЬКО ПОСЛЕ полной настройки
        uiItem.gameObject.SetActive(true);
        uiItem.Setup(item, this, gridType, x, y);
        _activeItems[key] = uiItem;

        // ✅ ФИНАЛЬНЫЙ ЛОГ
        Debug.Log($"[CreateUIItem] UI_Item created and added to _activeItems[{key}]");
    }

    private Transform GetItemsContainer(GridType gridType) => gridType switch
    {
        GridType.Pockets => _pocketsItemsContainer,
        GridType.Backpack => _backpackItemsContainer,
        GridType.Container => _surroundingsItemsContainer,
        _ => null
    };

    public void StartDrag(UI_Item draggedItem)
    {
        if (draggedItem == null || draggedItem.Item == null) return;
        _draggedItem = draggedItem;
        _isDragging = true;

        if (_dragGhost != null && _dragGhostImage != null && draggedItem.Item.Data?.Icon != null)
        {
            _dragGhostImage.sprite = draggedItem.Item.Data.Icon;
            _dragGhost.SetActive(true);
            _dragGhost.transform.SetAsLastSibling();
            UpdateGhostSize();
            _dragGhost.transform.position = Input.mousePosition;
        }
    }

    private void RotateDraggedItem()
    {
        if (_draggedItem == null || !_draggedItem.Item.Data.CanRotate) return;
        _draggedItem.Item.Rotate();
        _draggedItem.UpdateVisuals();
        UpdateGhostSize();
        if (_dragGhostImage != null)
            _dragGhostImage.rectTransform.localRotation = Quaternion.Euler(0, 0, -_draggedItem.Item.RotationAngle);
    }

    private void UpdateGhostSize()
    {
        if (_draggedItem == null || _dragGhostImage == null) return;
        Vector2Int size = _draggedItem.Item.CurrentSize;
        float w = size.x * slotSize + (size.x - 1) * slotSpacing;
        float h = size.y * slotSize + (size.y - 1) * slotSpacing;
        _dragGhostImage.rectTransform.sizeDelta = new Vector2(w, h);
    }

    private void UpdateDragGhost()
    {
        if (!_isDragging || _dragGhost == null || !_dragGhost.activeSelf) return;
        _dragGhost.transform.position = Input.mousePosition;
        UpdateGhostColor();
    }

    private void UpdateGhostColor()
    {
        if (_dragGhostImage == null || _draggedItem?.Item == null) return;
        if (EventSystem.current == null) return;
        if (_cachedEventData == null) _cachedEventData = new PointerEventData(EventSystem.current);
        _cachedEventData.position = Input.mousePosition;
        _raycastBuffer.Clear();
        EventSystem.current.RaycastAll(_cachedEventData, _raycastBuffer);
        Color targetColor = _dragInvalidColor;

        foreach (var result in _raycastBuffer)
        {
            var slot = result.gameObject.GetComponent<K_InventorySlotUI>();
            if (slot != null)
            {
                int adjustedX = slot.X;
                int adjustedY = slot.Y;
                Vector2Int itemSize = _draggedItem.Item.CurrentSize;
                int gridWidth = GetGridWidth(slot.GridType);
                int gridHeight = GetGridHeight(slot.GridType);

                if (itemSize.x > 1 && adjustedX + itemSize.x > gridWidth) adjustedX = Mathf.Max(0, gridWidth - itemSize.x);
                if (itemSize.y > 1 && adjustedY + itemSize.y > gridHeight) adjustedY = Mathf.Max(0, gridHeight - itemSize.y);

                InventoryController controller = GetControllerForGrid(slot.GridType);
                if (controller != null && controller.CanPlaceItem(_draggedItem.Item, adjustedX, adjustedY))
                    targetColor = _dragValidColor;
                break;
            }

            var equipSlot = result.gameObject.GetComponent<K_EquipmentSlotUI>();
            if (equipSlot != null) { if (ValidateEquipItem(_draggedItem.Item, equipSlot)) targetColor = _dragValidColor; break; }
        }
        _dragGhostImage.color = targetColor;
    }

    public bool TryPlaceItem(UI_Item draggedItem, GridType targetGrid, int targetX, int targetY)
    {
        if (draggedItem == null || draggedItem.Item == null) return false;
        InventoryItem item = draggedItem.Item;
        InventoryController sourceController = GetControllerForGrid(draggedItem.GridType);
        InventoryController targetController = GetControllerForGrid(targetGrid);
        if (targetController == null) return false;
        if (sourceController == targetController && draggedItem.X == targetX && draggedItem.Y == targetY) return true;

        int originX = draggedItem.X;
        int originY = draggedItem.Y;
        if (sourceController != null && !sourceController.RemoveItem(item)) return false;

        int placedCount = targetController.TryPlaceItem(item, targetX, targetY);
        bool success = placedCount > 0;
        if (!success && sourceController != null)
            sourceController.TryPlaceItem(item, originX, originY);

        if (_dragGhostImage != null)
            _dragGhostImage.color = success ? _dragValidColor : _dragInvalidColor;
        return success;
    }

    public bool TryEquipItem(UI_Item draggedItem, K_EquipmentSlotUI slot)
    {
        if (draggedItem == null || draggedItem.Item == null || slot == null) return false;
        InventoryItem item = draggedItem.Item;
        if (!ValidateEquipItem(item, slot)) { ReturnToPool(draggedItem); return false; }

        InventoryController sourceController = GetControllerForGrid(draggedItem.GridType);
        if (sourceController == null) { ReturnToPool(draggedItem); return false; }

        if (sourceController.RemoveItem(item))
        {
            slot.OnDropItem(item);
            draggedItem.gameObject.SetActive(false);
            ReturnToPool(draggedItem);
            return true;
        }
        ReturnToPool(draggedItem); return false;
    }

    public void EndDragComplete()
    {
        _isDragging = false;
        _draggedItem = null;
        if (_dragGhost != null) _dragGhost.SetActive(false);
        MarkForRefresh();
    }

    private bool ValidateEquipItem(InventoryItem item, K_EquipmentSlotUI slot)
    {
        if (item == null || item.Data == null) return false;
        EquipmentSlotType slotType = slot.SlotType;
        if (slotType == EquipmentSlotType.Backpack) return item.Data.IsBackpack;
        else
        {
            if (item.Type != ItemType.Weapon) return false;
            if (slotType == EquipmentSlotType.Pistol && !item.Data.IsPistol) return false;
        }
        return true;
    }

    public void QuickMoveItem(InventoryItem item, int sourceGridType)
    {
        if (item == null) return;
        GridType sourceGrid = (GridType)sourceGridType;
        if (sourceGrid == GridType.Pockets || sourceGrid == GridType.Backpack)
        {
            if (_activeContainerController != null && _activeContainerController.TryPlaceItemInFirstFreeSlot(item))
            { _playerController.RemoveItem(item); MarkForRefresh(); }
        }
        else if (sourceGrid == GridType.Container && _activeContainerController != null)
        {
            if (_playerController.TryPlaceItemInFirstFreeSlot(item)) { _activeContainerController.RemoveItem(item); MarkForRefresh(); }
        }
    }

    private void MarkForRefresh() { if (!_pendingRefresh) { _pendingRefresh = true; StartCoroutine(RefreshNextFrame()); } }
    private System.Collections.IEnumerator RefreshNextFrame() { yield return null; _pendingRefresh = false; RefreshAll(); }

    private void OnInventoryChangedHandler() => RefreshAll();
    private void OnItemPlacedHandler(InventoryItem item, int x, int y) => RefreshAll();
    private void OnItemChangedHandler(InventoryItem item) => RefreshAll();

    private void SubscribeToEvents()
    {
        if (_playerController == null) return;
        _playerController.OnInventoryChanged += OnInventoryChangedHandler;
        _playerController.OnWeightChanged += UpdateWeightDisplay;
        _playerController.OnItemPlaced += OnItemPlacedHandler;
        _playerController.OnItemRemoved += OnItemChangedHandler;
        _playerController.OnItemRotated += OnItemChangedHandler;
        _playerController.OnItemQuantityChanged += OnItemChangedHandler;
    }

    private void UnsubscribeFromEvents()
    {
        if (_playerController == null) return;
        _playerController.OnInventoryChanged -= OnInventoryChangedHandler;
        _playerController.OnWeightChanged -= UpdateWeightDisplay;
        _playerController.OnItemPlaced -= OnItemPlacedHandler;
        _playerController.OnItemRemoved -= OnItemChangedHandler;
        _playerController.OnItemRotated -= OnItemChangedHandler;
        _playerController.OnItemQuantityChanged -= OnItemChangedHandler;
    }

    private void RefreshEquipmentSlots() { if (_primarySlot1 != null) _primarySlot1.Refresh(); if (_primarySlot2 != null) _primarySlot2.Refresh(); if (_pistolSlot != null) _pistolSlot.Refresh(); }

    private void UpdateWeightDisplay(float kg)
    {
        if (_weightText == null || _playerController == null) return;
        float ratio = _playerController.WeightRatio;
        Color textColor = ratio > WEIGHT_CRITICAL_RATIO ? _textCriticalColor : ratio > WEIGHT_WARNING_RATIO ? _textWarningColor : _textNormalColor;
        float maxKg = _playerController.MaxCapacityGrams / 1000f;
        _weightText.text = $"<color=#{ColorUtility.ToHtmlStringRGB(textColor)}>{kg:F1} / {maxKg:F0} kg</color>";
    }

    private void SetCanvasActive(bool active)
    {
        _canvasGroup.alpha = active ? 1f : 0f;
        _canvasGroup.interactable = active;
        _canvasGroup.blocksRaycasts = active;
    }

    public bool IsOpen() => _isOpen;
    public bool IsLooting() => _isLootingContainer;
    public bool IsDragging() => _isDragging;

    public InventoryController GetControllerForGrid(GridType gridType) { if (gridType == GridType.Container) return _activeContainerController; return _playerController; }
    public int GetPrimarySlot1ID() => _primarySlot1?.GetInstanceID() ?? 0;
    public float GetSlotSize() => slotSize;
    public float GetSlotSpacing() => slotSpacing;
    public float GetSlotCompression() => slotCompression;
    public int GetGridWidth(GridType gridType) { var controller = GetControllerForGrid(gridType); if (gridType == GridType.Pockets) return POCKET_COLUMNS; return controller?.GetSaveData().Width ?? 0; }
    public int GetGridHeight(GridType gridType) { var controller = GetControllerForGrid(gridType); if (gridType == GridType.Pockets) return POCKET_ROWS; return controller?.GetSaveData().Height ?? 0; }
}