﻿using UnityEngine;
using UnityEngine.UI; // ✅ ДОБАВЛЕНО: Без этого Image не работает
using UnityEngine.EventSystems;

public class K_SlotHighlight : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] private Image background;
    [SerializeField] private Color normalColor = new Color(0.14f, 0.16f, 0.18f);
    [SerializeField] private Color hoverColor = new Color(0.20f, 0.22f, 0.25f);

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (background != null) background.color = hoverColor;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (background != null) background.color = normalColor;
    }
}