using System;
using UnityEngine;

namespace K_Incident.Core
{
    public enum TimePhase { Morning, Day, Evening, Night }

    public class K_TimeSystem : MonoBehaviour
    {
        private const float GAME_TIME_MULTIPLIER = 48f;

        public static K_TimeSystem Instance { get; private set; }
        public event Action<TimePhase> OnPhaseChanged;

        [Header("Time State")]
        [SerializeField, Range(0f, 24f)] private float _currentGameHours = 5f;
        private TimePhase _currentPhase;

        [Header("Visual References")]
        [SerializeField] private Light _sunLight;
        [SerializeField] private Gradient _atmosphereColor;
        [SerializeField] private AnimationCurve _sunIntensity;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            SetupFogSafety();
            InitializePhase();
        }

        // =====================================================================
        // ONDESTROY � ����� SINGLETON
        // =====================================================================
        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void Update()
        {
            UpdateTime();
            ApplyAtmosphere();
            CheckPhaseTransition();
        }

        private void SetupFogSafety()
        {
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 5f;
            RenderSettings.fogEndDistance = 20f;
        }

        private void UpdateTime()
        {
            float addedSeconds = Time.deltaTime * GAME_TIME_MULTIPLIER;
            _currentGameHours += addedSeconds / 3600f;
            if (_currentGameHours >= 24f) _currentGameHours -= 24f;
        }

        private void ApplyAtmosphere()
        {
            float timeNormalized = _currentGameHours / 24f;
            float sunPitch = (_currentGameHours * 15f) - 90f;
            if (_sunLight != null)
            {
                _sunLight.transform.rotation = Quaternion.Euler(sunPitch, 170f, 0f);
                _sunLight.intensity = _sunIntensity.Evaluate(timeNormalized);
            }
            Color currentColor = _atmosphereColor.Evaluate(timeNormalized);
            RenderSettings.fogColor = currentColor;
            RenderSettings.ambientLight = currentColor;
        }

        private void InitializePhase() { _currentPhase = DeterminePhase(_currentGameHours); }

        private void CheckPhaseTransition()
        {
            TimePhase calculatedPhase = DeterminePhase(_currentGameHours);
            if (calculatedPhase != _currentPhase)
            {
                _currentPhase = calculatedPhase;
                OnPhaseChanged?.Invoke(_currentPhase);
            }
        }

        private TimePhase DeterminePhase(float hours)
        {
            if (hours >= 5f && hours < 9f) return TimePhase.Morning;
            if (hours >= 9f && hours < 17f) return TimePhase.Day;
            if (hours >= 17f && hours < 21f) return TimePhase.Evening;
            return TimePhase.Night;
        }

        public float CurrentGameHours => _currentGameHours;
        public TimePhase CurrentPhase => _currentPhase;
    }
}