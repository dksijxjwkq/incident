﻿using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core
{
    public class K_VitalitySystem : MonoBehaviour, ISaveable
    {
        public string SaveID => "PlayerVitality";
        public bool IsDirty { get; set; } = true;

        public event Action OnMetabolismChanged;
        public event Action OnStimulatorChanged;
        public event Action OnHangoverChanged;
        public event Action OnColdExposureChanged;
        public event Action OnOverloadChanged;

        // =====================================================================
        // КОНСТАНТЫ БАЛАНСА (Аспект №11, №5, №9)
        // =====================================================================
        private const float MAX_VITALITY = 100f;
        private const float MIN_VITALITY = 0f;
        private const float HUNGER_DECAY_TIME = 9000f;
        private const float THIRST_DECAY_TIME = 4800f;
        private const float THIRST_DAMAGE_PER_SEC = 0.15f;
        private const float HUNGER_DAMAGE_PER_SEC = 0.1f;
        private const float RADIATION_METABOLISM_MULTIPLIER = 2.0f;
        private const float SAFE_ZONE_MULTIPLIER = 0.2f;
        private const float METABOLISM_TICK_RATE = 1.0f;
        private const float STIM_ON_DURATION = 85f;
        private const float STIM_OFF_DURATION = 200f;
        private const float FATIGUE_DURATION = 30f;
        private const float COLD_LETHAL_THRESHOLD = -25f;
        private const float COLD_WARNING_THRESHOLD = -20f;
        private const float COLD_EXPOSURE_GAIN_RATE = 0.00037f;
        private const float COLD_DAMAGE_PER_SEC = 1.0f;
        private const float SAFE_ZONE_COLD_RECOVERY_TIME = 60f;
        private const float ALCOHOL_RADIATION_IMMUNITY_THRESHOLD = 0.5f;
        private const float ALCOHOL_COLD_THRESHOLD_OFFSET = 10f;
        private const float BLACKOUT_HANGOVER_DURATION = 120f;
        private const float ALCOHOL_RADIATION_REDUCTION_PER_100ML = 5f;

        // =====================================================================
        // ПАРАМЕТРЫ
        // =====================================================================
        [Header("Vitality Stats (Max 100)")]
        [SerializeField, Range(0f, 100f)] private float _hunger = 100f;
        [SerializeField, Range(0f, 100f)] private float _thirst = 100f;
        [SerializeField, Range(0f, 100f)] private float _radiation = 0f;

        [Header("Stimulator & Debuffs")]
        [SerializeField] private float _stimulatorTimer = 0f;
        [SerializeField] private float _stimOffTimer = 0f;
        [SerializeField] private float _fatigueTimer = 0f;

        [Header("Alcohol System")]
        [SerializeField] private float _alcoholConcentration = 0f;
        [SerializeField] private float _drunkTimer = 0f;
        [SerializeField] private float _hangoverTimer = 0f;
        [SerializeField] private float _totalAlcoholConsumed = 0f;

        [Header("Cold System")]
        [SerializeField, Range(0f, 1f)] private float _coldExposure = 0f;
        [SerializeField, Range(-40f, 10f)] private float _currentTemperature = -15f;

        [Header("Other Debuffs")]
        [SerializeField] private bool _isOverloaded = false;

        [Header("Zone & FX Status")]
        [SerializeField] private bool _isInSafeZone = false;
        [SerializeField] private GameObject _bloodDecalPrefab;

        // =====================================================================
        // КЭШИРОВАННЫЕ ССЫЛКИ
        // =====================================================================
        private K_HealthSystem _cachedHealth;

#if UNITY_EDITOR
        private float _previousRadiation = 0f;
#endif

        // =====================================================================
        // ТАЙМЕРЫ И ОТСЛЕЖИВАНИЕ РЕСУРСОВ (ИСПРАВЛЕНИЕ УТЕЧЕК)
        // =====================================================================
        private float _bloodDecalTimer = 0f;
        private Coroutine _tickerCoroutine;
        private Coroutine _stimulatorCoroutine;
        private Coroutine _temperatureLerpCoroutine; // ДОБАВЛЕНО: отслеживание корутины температуры

        // ДОБАВЛЕНО: список для отслеживания созданных декалей крови
        private readonly List<GameObject> _spawnedBloodDecals = new List<GameObject>();

        // =====================================================================
        // ГЕТТЕРЫ
        // =====================================================================
        public float Hunger => _hunger;
        public float Thirst => _thirst;
        public float Radiation => _radiation;
        public float CurrentTemperature => _currentTemperature;
        public bool IsStimOn => _stimulatorTimer > 0f;
        public bool IsStimOff => _stimOffTimer > 0f;
        public bool IsFatigued => _fatigueTimer > 0f;
        public bool IsStimReady => _stimulatorTimer <= 0f && _stimOffTimer <= 0f && _fatigueTimer <= 0f;
        public bool IsHangover => _hangoverTimer > 0f;
        public bool IsDrunk => _drunkTimer > 0f;
        public bool IsColdCritical => _coldExposure >= 1.0f;
        public bool IsOverloaded => _isOverloaded;
        public bool IsStaminaFree => _cachedHealth != null && _cachedHealth.IsShocked;
        public float AlcoholConcentration => _alcoholConcentration;
        public float TotalAlcoholConsumed => _totalAlcoholConsumed;
        public bool HasRadiationImmunity => _alcoholConcentration > ALCOHOL_RADIATION_IMMUNITY_THRESHOLD;
        public float FOVModifier => IsStimOn ? 1.25f : 1.0f;
        public float AimStability => IsStimOn ? 1.0f : (IsHangover ? 0.7f : 1.0f);
        public float ActionSpeedMult => IsStimOn ? 1.25f : (IsHangover ? 0.8f : 1.0f);
        public float StaminaRegenMult => IsStimOn ? 1.5f : (IsFatigued ? 0.5f : (IsHangover ? 0.5f : 1.0f));
        public float FractureChanceMult => IsHangover ? 1.75f : 1.0f;
        public float NoiseRadius => IsHangover ? 10.0f : 0f;
        public float ColdExposure => _coldExposure;
        public bool Icon_Hunger => _hunger <= 50f;
        public bool Icon_Thirst => _thirst <= 50f;
        public bool Icon_Radiation => _radiation > 5f && !HasRadiationImmunity;
        public int Icon_Bleeding => _cachedHealth != null ? _cachedHealth.GetMaxBleedingLevel() : 0;
        public bool Icon_Fracture => _cachedHealth != null && _cachedHealth.FractureCount > 0;
        public bool Icon_Laceration => _cachedHealth != null && _cachedHealth.HasAnyLaceration();
        public bool Icon_StimOn => IsStimOn;
        public bool Icon_StimOff => IsStimOff;
        public bool Icon_Hangover => IsHangover;
        public bool Icon_Cold => _coldExposure > 0.5f;
        public bool Icon_Overload => _isOverloaded;
        public bool Icon_Drunk => IsDrunk;

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
        {
            _cachedHealth = GetComponent<K_HealthSystem>();
            if (_cachedHealth == null)
                Debug.LogError("[K_VitalitySystem] K_HealthSystem NOT FOUND on this GameObject!");

            if (K_TimeSystem.Instance != null)
                K_TimeSystem.Instance.OnPhaseChanged += OnTimePhaseChanged;

#if UNITY_EDITOR
            _previousRadiation = _radiation;
#endif
        }

        private void Start()
        {
            if (K_SaveManager.Instance != null)
                K_SaveManager.Instance.Register(this);

            if (_cachedHealth != null && _radiation > 0f)
            {
                _cachedHealth.ApplyRadiationClamp(_radiation);
                Debug.Log($"[Vitality] Initial radiation clamp applied: {_radiation:F1}%");
            }

            _tickerCoroutine = StartCoroutine(StatsTick());
        }

        // =====================================================================
        // ONDESTROY — ОЧИСТКА РЕСУРСОВ (ИСПРАВЛЕНИЕ УТЕЧЕК)
        // =====================================================================
        private void OnDestroy()
        {
            // Остановка корутин
            if (_tickerCoroutine != null) StopCoroutine(_tickerCoroutine);
            if (_stimulatorCoroutine != null) StopCoroutine(_stimulatorCoroutine);
            if (_temperatureLerpCoroutine != null) StopCoroutine(_temperatureLerpCoroutine);

            // Отписка от событий времени
            if (K_TimeSystem.Instance != null)
                K_TimeSystem.Instance.OnPhaseChanged -= OnTimePhaseChanged;

            // Очистка декалей крови (ИСПРАВЛЕНИЕ УТЕЧКИ)
            foreach (var decal in _spawnedBloodDecals)
            {
                if (decal != null) Destroy(decal);
            }
            _spawnedBloodDecals.Clear();

            // Отписка от SaveManager (ИСПРАВЛЕНИЕ УТЕЧКИ)
            if (K_SaveManager.Instance != null)
                K_SaveManager.Instance.Unregister(this);
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (_cachedHealth != null && Application.isPlaying && Mathf.Abs(_radiation - _previousRadiation) > 0.1f)
            {
                if (HasRadiationImmunity && _radiation > _previousRadiation)
                {
                    _radiation = _previousRadiation;
                    Debug.Log("[Vitality] Radiation immunity blocked manual increase");
                    _previousRadiation = _radiation;
                    return;
                }
                Debug.Log($"[Vitality] Radiation changed in Inspector: {_previousRadiation:F1}% → {_radiation:F1}%");
                _cachedHealth.ApplyRadiationClamp(_radiation);
                _previousRadiation = _radiation;
            }
        }
#endif

        // =====================================================================
        // ОСНОВНОЙ ТИК
        // =====================================================================
        private IEnumerator StatsTick()
        {
            WaitForSeconds waitOneSecond = new WaitForSeconds(METABOLISM_TICK_RATE);
            while (true)
            {
                yield return waitOneSecond;
                if (_cachedHealth != null && _cachedHealth.IsDead) yield break;
                ProcessMetabolism();
                UpdateStimulatorTimers(METABOLISM_TICK_RATE);
                UpdateDebuffs(METABOLISM_TICK_RATE);
                UpdateTemperature(METABOLISM_TICK_RATE);
                if (_cachedHealth != null && _cachedHealth.GetMaxBleedingLevel() >= 3)
                    HandleBloodDecals();
                NotifyChange();
            }
        }

        // =====================================================================
        // МЕТАБОЛИЗМ
        // =====================================================================
        private void ProcessMetabolism()
        {
            float zoneMultiplier = _isInSafeZone ? SAFE_ZONE_MULTIPLIER : 1.0f;
            float radiationMultiplier = 1.0f + (_radiation / 100f) * (RADIATION_METABOLISM_MULTIPLIER - 1.0f);
            float thirstDecayPerTick = (MAX_VITALITY / THIRST_DECAY_TIME) * zoneMultiplier * radiationMultiplier;
            float hungerDecayPerTick = (MAX_VITALITY / HUNGER_DECAY_TIME) * zoneMultiplier * radiationMultiplier;

            if (_thirst > MIN_VITALITY)
                _thirst = Mathf.Max(_thirst - thirstDecayPerTick, MIN_VITALITY);
            else if (_cachedHealth != null)
                _cachedHealth.TakeMetabolismDamage(THIRST_DAMAGE_PER_SEC, BodyPart.Stomach);

            if (_hunger > MIN_VITALITY)
                _hunger = Mathf.Max(_hunger - hungerDecayPerTick, MIN_VITALITY);
            else if (_cachedHealth != null)
                _cachedHealth.TakeMetabolismDamage(HUNGER_DAMAGE_PER_SEC, BodyPart.Stomach);
        }

        // =====================================================================
        // СТИМУЛЯТОР
        // =====================================================================
        private void UpdateStimulatorTimers(float deltaTime)
        {
            if (_stimulatorTimer > 0f)
            {
                _stimulatorTimer -= deltaTime;
                if (_stimulatorTimer <= 0f)
                {
                    _stimulatorTimer = 0f;
                    _stimOffTimer = STIM_OFF_DURATION;
                    Debug.Log("[Vitality] STIM OFF: Side effects + Cooldown (200s)");
                }
                OnStimulatorChanged?.Invoke();
            }
            else if (_stimOffTimer > 0f)
            {
                _stimOffTimer -= deltaTime;
                if (_stimOffTimer <= 0f)
                {
                    _stimOffTimer = 0f;
                    _fatigueTimer = FATIGUE_DURATION;
                    Debug.Log($"[Vitality] Fatigue started ({FATIGUE_DURATION}s)");
                }
                OnStimulatorChanged?.Invoke();
            }
            else if (_fatigueTimer > 0f)
            {
                _fatigueTimer -= deltaTime;
                if (_fatigueTimer <= 0f)
                {
                    _fatigueTimer = 0f;
                    Debug.Log("[Vitality] Fatigue ended. Stimulator fully ready.");
                }
                OnStimulatorChanged?.Invoke();
            }
        }

        // =====================================================================
        // ДЕБАФФЫ
        // =====================================================================
        private void UpdateDebuffs(float deltaTime)
        {
            if (_alcoholConcentration > 0f)
            {
                _alcoholConcentration -= 0.00083f * deltaTime;
                _alcoholConcentration = Mathf.Max(_alcoholConcentration, 0f);
            }

            if (_drunkTimer > 0f)
            {
                _drunkTimer -= deltaTime;
                if (_drunkTimer <= 0f)
                {
                    _drunkTimer = 0f;
                    _hangoverTimer = 30f;
                    Debug.Log("[Vitality] Hangover started (30s)");
                }
            }

            if (_hangoverTimer > 0f)
            {
                _hangoverTimer -= deltaTime;
                if (_hangoverTimer <= 0f)
                {
                    _hangoverTimer = 0f;
                    Debug.Log("[Vitality] Hangover ended");
                }
                OnHangoverChanged?.Invoke();
            }
        }

        // =====================================================================
        // ТЕМПЕРАТУРА И ХОЛОД
        // =====================================================================
        private void UpdateTemperature(float deltaTime)
        {
            float alcoholThresholdOffset = GetColdThresholdOffset();
            float effectiveThreshold = COLD_LETHAL_THRESHOLD - alcoholThresholdOffset;

            if (_currentTemperature <= effectiveThreshold)
            {
                float delta = Mathf.Abs(_currentTemperature) - Mathf.Abs(effectiveThreshold);
                _coldExposure += delta * COLD_EXPOSURE_GAIN_RATE * deltaTime;
                _coldExposure = Mathf.Clamp01(_coldExposure);
                if (_coldExposure > 0f) OnColdExposureChanged?.Invoke();
                if (IsColdCritical) ApplyColdDamage(COLD_DAMAGE_PER_SEC * deltaTime);
            }
            else if (_coldExposure > 0f)
            {
                if (_isInSafeZone)
                {
                    _coldExposure -= deltaTime / SAFE_ZONE_COLD_RECOVERY_TIME;
                    _coldExposure = Mathf.Max(0f, _coldExposure);
                    if (_coldExposure <= 0f) Debug.Log("[Vitality] Safe Zone: Cold exposure fully recovered (60s)");
                }
                else
                {
                    _coldExposure -= deltaTime * 0.01f;
                    _coldExposure = Mathf.Max(0f, _coldExposure);
                }
                OnColdExposureChanged?.Invoke();
            }
        }

        private void ApplyColdDamage(float totalDamage)
        {
            if (_cachedHealth == null) return;
            _cachedHealth.ApplyColdDamage(totalDamage);
        }

        // =====================================================================
        // СМЕНА ФАЗЫ ВРЕМЕНИ (ИСПРАВЛЕНИЕ: ОТСЛЕЖИВАНИЕ КОРУТИНЫ)
        // =====================================================================
        private void OnTimePhaseChanged(K_Incident.Core.TimePhase phase)
        {
            float targetTemp = phase switch
            {
                K_Incident.Core.TimePhase.Night => UnityEngine.Random.Range(-40f, -30f),
                K_Incident.Core.TimePhase.Morning => UnityEngine.Random.Range(-24f, -20f),
                K_Incident.Core.TimePhase.Day => UnityEngine.Random.Range(-20f, -15f),
                K_Incident.Core.TimePhase.Evening => UnityEngine.Random.Range(-25f, -20f),
                _ => -25f
            };

            // Останавливаем предыдущую корутину если есть
            if (_temperatureLerpCoroutine != null) StopCoroutine(_temperatureLerpCoroutine);
            _temperatureLerpCoroutine = StartCoroutine(TemperatureLerpRoutine(targetTemp));
        }

        private IEnumerator TemperatureLerpRoutine(float targetTemp)
        {
            float startTemp = _currentTemperature;
            float duration = 120f;
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                _currentTemperature = Mathf.Lerp(startTemp, targetTemp, elapsed / duration);
                yield return null;
            }
            _currentTemperature = targetTemp;
            _temperatureLerpCoroutine = null; // Очищаем ссылку после завершения
            Debug.Log($"[Vitality] Temperature transition complete: {targetTemp:F1}°C");
        }

        // =====================================================================
        // КРОВЬ (ИСПРАВЛЕНИЕ: ОТСЛЕЖИВАНИЕ ДЕКАЛЕЙ)
        // =====================================================================
        private void HandleBloodDecals()
        {
            if (_bloodDecalPrefab == null) return;
            _bloodDecalTimer += METABOLISM_TICK_RATE;
            if (_bloodDecalTimer >= 2.0f)
            {
                _bloodDecalTimer = 0f;
                SpawnBloodDecal();
            }
        }

        private void SpawnBloodDecal()
        {
            if (Physics.Raycast(transform.position + Vector3.up * 0.5f, Vector3.down, out RaycastHit hit, 2.0f))
            {
                GameObject decal = Instantiate(_bloodDecalPrefab, hit.point + Vector3.up * 0.01f, Quaternion.LookRotation(hit.normal));
                _spawnedBloodDecals.Add(decal); // ДОБАВЛЕНО: отслеживаем созданный декаль

                // Авто-удаление через 30 секунд чтобы не засорять память
                Destroy(decal, 30f);

                // Очищаем список от уничтоженных объектов
                _spawnedBloodDecals.RemoveAll(d => d == null);
            }
        }

        // =====================================================================
        // СТИМУЛЯТОР
        // =====================================================================
        public void UseStimulatorEnhanced()
        {
            if (_stimulatorTimer > 0f || _stimOffTimer > 0f || _fatigueTimer > 0f)
            {
                Debug.Log($"[Vitality] Stimulator on cooldown! {_stimOffTimer + _fatigueTimer:F1}s remaining");
                return;
            }
            _stimulatorTimer = STIM_ON_DURATION;
            if (_stimulatorCoroutine != null) StopCoroutine(_stimulatorCoroutine);
            _stimulatorCoroutine = StartCoroutine(StimulatorHealRoutine());
            Debug.Log("[Vitality] STIM ON: Enhanced perception (85s)");
            OnStimulatorChanged?.Invoke();
            NotifyChange();
        }

        private IEnumerator StimulatorHealRoutine()
        {
            WaitForSeconds waitOneSec = new WaitForSeconds(1.0f);
            for (int i = 0; i < 60; i++)
            {
                if (_cachedHealth != null && !_cachedHealth.IsDead) HealPrioritySegment();
                yield return waitOneSec;
            }
            _stimulatorCoroutine = null;
            NotifyChange();
        }

        private void HealPrioritySegment()
        {
            if (TryHeal(BodyPart.Head)) return;
            if (TryHeal(BodyPart.Torso)) return;
            if (TryHeal(BodyPart.Stomach)) return;
            if (TryHeal(BodyPart.LeftLeg)) return;
            if (TryHeal(BodyPart.RightLeg)) return;
            if (TryHeal(BodyPart.LeftArm)) return;
            TryHeal(BodyPart.RightArm);
        }

        private bool TryHeal(BodyPart part)
        {
            float cur = 0f, max = 0f;
            switch (part)
            {
                case BodyPart.Head: cur = _cachedHealth.HeadHP; max = _cachedHealth.BaseHeadHP; break;
                case BodyPart.Torso: cur = _cachedHealth.TorsoHP; max = _cachedHealth.BaseTorsoHP; break;
                case BodyPart.Stomach: cur = _cachedHealth.StomachHP; max = _cachedHealth.BaseStomachHP; break;
                case BodyPart.LeftLeg: cur = _cachedHealth.LeftLegHP; max = _cachedHealth.BaseLeftLegHP; break;
                case BodyPart.RightLeg: cur = _cachedHealth.RightLegHP; max = _cachedHealth.BaseRightLegHP; break;
                case BodyPart.LeftArm: cur = _cachedHealth.LeftArmHP; max = _cachedHealth.BaseLeftArmHP; break;
                case BodyPart.RightArm: cur = _cachedHealth.RightArmHP; max = _cachedHealth.BaseRightArmHP; break;
            }
            if (cur > 0f && cur < max)
            {
                _cachedHealth.HealSegment(part, 1.0f);
                return true;
            }
            return false;
        }

        // =====================================================================
        // АЛКОГОЛЬНАЯ СИСТЕМА
        // =====================================================================
        public void ConsumeVodka(float volumeMl)
        {
            float concentrationGain = volumeMl / 1000f;
            _alcoholConcentration = Mathf.Min(_alcoholConcentration + concentrationGain, 1.0f);
            _drunkTimer = 120f;
            _hangoverTimer = 0f;
            _totalAlcoholConsumed += volumeMl;
            float radiationReduction = (volumeMl / 100f) * ALCOHOL_RADIATION_REDUCTION_PER_100ML;
            if (_cachedHealth != null)
            {
                float currentRad = _radiation;
                _radiation = Mathf.Max(_radiation - radiationReduction, 0f);
                Debug.Log($"[Vitality] Vodka consumed: {volumeMl}ml | Radiation: {currentRad:F1} → {_radiation:F1} (-{radiationReduction:F1})");
                _cachedHealth.ApplyRadiationClamp(_radiation);
            }
            if (_totalAlcoholConsumed >= 3000f) TriggerBlackout();
            Debug.Log($"[Vitality] Vodka: {volumeMl}ml | Concentration: {_alcoholConcentration:F2} | Total: {_totalAlcoholConsumed:F0}ml | Immunity: {(HasRadiationImmunity ? "ACTIVE" : "NONE")}");
            NotifyChange();
        }

        private void TriggerBlackout()
        {
            Debug.LogWarning("[Vitality] BLACKOUT TRIGGERED! 3+ liters consumed!");
            _totalAlcoholConsumed = 0f;
            _alcoholConcentration = 0f;
            _hangoverTimer = BLACKOUT_HANGOVER_DURATION;
            Debug.Log($"[Vitality] Blackout: Woke up with hangover ({BLACKOUT_HANGOVER_DURATION}s)");
        }

        public float GetColdThresholdOffset() => _alcoholConcentration > 0f ? ALCOHOL_COLD_THRESHOLD_OFFSET : 0f;

        // =====================================================================
        // ХОЛОД, ПЕРЕГРУЗ, ПОТРЕБЛЕНИЕ
        // =====================================================================
        public void SetColdExposure(float exposure)
        {
            _coldExposure = Mathf.Clamp01(exposure);
            OnColdExposureChanged?.Invoke();
            NotifyChange();
            if (_coldExposure >= 1.0f) Debug.Log("[Vitality] CRITICAL FROSTBITE!");
        }

        public void SetTemperature(float temp)
        {
            _currentTemperature = temp;
            Debug.Log($"[Vitality] Temperature set to {temp:F1}°C");
        }

        public void SetOverload(bool overloaded)
        {
            if (_isOverloaded != overloaded)
            {
                _isOverloaded = overloaded;
                Debug.Log($"[Vitality] Overload: {(_isOverloaded ? "ON" : "OFF")}");
                OnOverloadChanged?.Invoke();
                NotifyChange();
            }
        }

        public void ConsumeFoodWater(float food, float water)
        {
            _hunger = Mathf.Clamp(_hunger + food, MIN_VITALITY, MAX_VITALITY);
            _thirst = Mathf.Clamp(_thirst + water, MIN_VITALITY, MAX_VITALITY);
            NotifyChange();
        }

        public void AddRadiation(float amount)
        {
            if (HasRadiationImmunity)
            {
                Debug.Log("[Vitality] Radiation immunity active — radiation blocked");
                return;
            }
            _radiation = Mathf.Clamp(_radiation + amount, MIN_VITALITY, MAX_VITALITY);
            Debug.Log($"[Vitality] Radiation added: {amount:F1}% → Total: {_radiation:F1}%");
            if (_cachedHealth != null) _cachedHealth.ApplyRadiationClamp(_radiation);
            NotifyChange();
        }

        public void SetSafeZoneState(bool isSafe)
        {
            _isInSafeZone = isSafe;
            Debug.Log($"[Vitality] Safe Zone: {(_isInSafeZone ? "ENTERED" : "LEFT")}");
            NotifyChange();
        }

        // =====================================================================
        // УВЕДОМЛЕНИЯ И СОХРАНЕНИЕ
        // =====================================================================
        private void NotifyChange()
        {
            IsDirty = true;
            OnMetabolismChanged?.Invoke();
        }

        public void Save(BinaryWriter writer)
        {
            writer.Write(_hunger); writer.Write(_thirst); writer.Write(_radiation);
            writer.Write(_stimulatorTimer); writer.Write(_stimOffTimer); writer.Write(_fatigueTimer);
            writer.Write(_alcoholConcentration); writer.Write(_drunkTimer); writer.Write(_hangoverTimer);
            writer.Write(_totalAlcoholConsumed); writer.Write(_coldExposure); writer.Write(_isOverloaded);
            writer.Write(_currentTemperature); writer.Write(_isInSafeZone);
        }

        public void Load(BinaryReader reader)
        {
            _hunger = reader.ReadSingle(); _thirst = reader.ReadSingle(); _radiation = reader.ReadSingle();
            _stimulatorTimer = reader.ReadSingle(); _stimOffTimer = reader.ReadSingle(); _fatigueTimer = reader.ReadSingle();
            _alcoholConcentration = reader.ReadSingle(); _drunkTimer = reader.ReadSingle(); _hangoverTimer = reader.ReadSingle();
            _totalAlcoholConsumed = reader.ReadSingle(); _coldExposure = reader.ReadSingle(); _isOverloaded = reader.ReadBoolean();
            _currentTemperature = reader.ReadSingle(); _isInSafeZone = reader.ReadBoolean();
            if (_cachedHealth != null && _radiation > 0f) _cachedHealth.ApplyRadiationClamp(_radiation);
            NotifyChange();
        }

        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Debug: Use Stimulator")] public void DebugStim() => UseStimulatorEnhanced();
        [ContextMenu("Debug: Consume 500ml Vodka")] public void DebugVodka500() => ConsumeVodka(500f);
        [ContextMenu("Debug: Set Radiation 50")] public void DebugRad50() { _radiation = 50f; NotifyChange(); }
        [ContextMenu("Debug: Set Hunger 0")] public void DebugStarve() { _hunger = 0f; NotifyChange(); }
        [ContextMenu("Debug: Set Thirst 0")] public void DebugThirst() { _thirst = 0f; NotifyChange(); }
        [ContextMenu("Debug: Add 50 Radiation")] public void DebugRadiation() { AddRadiation(50f); }
        [ContextMenu("Debug: Set Cold Exposure 1.0")] public void DebugColdCritical() { SetColdExposure(1.0f); }
        [ContextMenu("Debug: Set Temperature -40")] public void DebugTempLethal() { SetTemperature(-40f); }
        [ContextMenu("Debug: Toggle Overload")] public void DebugOverload() { SetOverload(!_isOverloaded); }
        [ContextMenu("Debug: Enter Safe Zone")] public void DebugEnterSafeZone() { SetSafeZoneState(true); }
        [ContextMenu("Debug: Leave Safe Zone")] public void DebugLeaveSafeZone() { SetSafeZoneState(false); }
    }
}