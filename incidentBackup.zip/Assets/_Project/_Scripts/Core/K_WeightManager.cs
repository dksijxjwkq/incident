﻿using UnityEngine;
using System;

namespace K_Incident.Core
{
    /// <summary>
    /// Система управления весом и перегрузом (Аспект №2)
    /// </summary>
    public class K_WeightManager : MonoBehaviour
    {
        // =====================================================================
        // СОБЫТИЯ
        // =====================================================================
        public event Action OnWeightChanged;
        public event Action OnOverloadStateChanged;

        // =====================================================================
        // НАСТРОЙКИ ВЕСА
        // =====================================================================
        [Header("Weight Settings")]
        [SerializeField] private float _maxCapacity = 30f;
        [SerializeField] private float _currentWeight = 0f;

        [Header("Weight Thresholds")]
        [SerializeField] private float _warningThreshold = 0.5f;
        [SerializeField] private float _overloadThreshold = 0.9f;
        [SerializeField] private float _criticalThreshold = 1.1f;

        [Header("Speed Multipliers")]
        [SerializeField] private float _normalSpeedMult = 1.0f;
        [SerializeField] private float _overloadSpeedMult = 0.75f;
        [SerializeField] private float _criticalSpeedMult = 0.15f;
        [SerializeField] private float _minSpeedFloor = 0.05f;

        [Header("Stamina Costs")]
        [SerializeField] private float _normalStaminaCost = 0f;
        [SerializeField] private float _overloadStaminaCost = 2.0f;
        [SerializeField] private float _criticalStaminaCost = 4.0f;

        [Header("References")]
        [SerializeField] private K_VitalitySystem _vitalitySystem;
        [SerializeField] private K_HealthSystem _healthSystem;

        // =====================================================================
        // ВНУТРЕННИЕ ПЕРЕМЕННЫЕ
        // =====================================================================
        private bool _isOverloaded = false;
        private bool _isCriticalOverload = false;
        private float _weightRatio = 0f;
        private float _speedMultiplier = 1.0f;
        private float _staminaDrainRate = 0f;
        private float _accelerationTime = 0.25f;

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
        {
            if (_vitalitySystem == null)
                _vitalitySystem = GetComponent<K_VitalitySystem>();

            if (_healthSystem == null)
                _healthSystem = GetComponent<K_HealthSystem>();

            UpdateWeightState();
        }

        // =====================================================================
        // ONDESTROY — ОТПИСКА ОТ СОБЫТИЙ (ИСПРАВЛЕНИЕ УТЕЧКИ)
        // =====================================================================
        private void OnDestroy()
        {
            // Очищаем все события, чтобы избежать утечек памяти
            OnWeightChanged = null;
            OnOverloadStateChanged = null;
        }

        // =====================================================================
        // ONVALIDATE — ДЛЯ ИЗМЕНЕНИЙ В INSPECTOR ВО ВРЕМЯ PLAY MODE
        // =====================================================================
        private void OnValidate()
        {
            if (Application.isPlaying)
            {
                // При изменении веса в Inspector сразу пересчитываем состояние
                UpdateWeightState();
            }
        }

        // =====================================================================
        // ГЕТТЕРЫ
        // =====================================================================
        public float CurrentWeight => _currentWeight;
        public float MaxCapacity => _maxCapacity;

        public float GetCurrentWeightRatio()
        {
            if (_maxCapacity <= 0f) return 0f;
            return _currentWeight / _maxCapacity;
        }

        public float GetSpeedMultiplier() => _speedMultiplier;
        public float GetStaminaDrainRate() => _staminaDrainRate;
        public float GetAccelerationTime() => _accelerationTime;
        public bool IsOverloaded() => _isOverloaded;
        public bool IsCriticalOverload() => _isCriticalOverload;
        public bool CanSprint() => !_isOverloaded;

        // =====================================================================
        // ИЗМЕНЕНИЕ ВЕСА
        // =====================================================================
        /// <summary>
        /// Обновляет текущий вес от внешней системы (Инвентарь).
        /// </summary>
        public void SetWeight(float kg)
        {
            _currentWeight = kg;
            UpdateWeightState();
        }

        public void AddWeight(float weight)
        {
            _currentWeight += weight;
            _currentWeight = Mathf.Max(0f, _currentWeight);
            UpdateWeightState();
        }

        public void RemoveWeight(float weight)
        {
            _currentWeight -= weight;
            _currentWeight = Mathf.Max(0f, _currentWeight);
            UpdateWeightState();
        }

        public void SetMaxCapacity(float newCapacity)
        {
            _maxCapacity = Mathf.Max(1f, newCapacity);
            UpdateWeightState();
        }

        // =====================================================================
        // РАСЧЁТ МУЛЬТИПЛИКАТОРОВ (ИСПРАВЛЕНО)
        // =====================================================================
        public void UpdateWeightState()
        {
            // Сначала рассчитываем базовый ratio
            _weightRatio = GetCurrentWeightRatio();

            // Применяем гиподинамию ДО расчёта множителя скорости
            ApplyHypodynamiaPenalty();

            bool wasOverloaded = _isOverloaded;
            bool wasCritical = _isCriticalOverload;

            // Расчёт множителя скорости на основе ОБНОВЛЁННОГО _weightRatio
            if (_weightRatio <= _warningThreshold)
            {
                _speedMultiplier = _normalSpeedMult;
                _staminaDrainRate = _normalStaminaCost;
                _accelerationTime = 0.25f;
                _isOverloaded = false;
                _isCriticalOverload = false;
            }
            else if (_weightRatio <= _overloadThreshold)
            {
                _speedMultiplier = Mathf.Lerp(_normalSpeedMult, _overloadSpeedMult,
                    Mathf.InverseLerp(_warningThreshold, _overloadThreshold, _weightRatio));
                _staminaDrainRate = _normalStaminaCost;
                _accelerationTime = 0.5f;
                _isOverloaded = false;
                _isCriticalOverload = false;
            }
            else if (_weightRatio <= _criticalThreshold)
            {
                _speedMultiplier = _overloadSpeedMult;
                _staminaDrainRate = _overloadStaminaCost;
                _accelerationTime = 0.5f;
                _isOverloaded = true;
                _isCriticalOverload = false;
            }
            else
            {
                _speedMultiplier = _criticalSpeedMult;
                _staminaDrainRate = _criticalStaminaCost;
                _accelerationTime = 0.5f;
                _isOverloaded = true;
                _isCriticalOverload = true;
            }

            // Применяем синергию с травмами ног
            ApplyLegInjurySynergy();

            // Применяем минимальный порог скорости
            _speedMultiplier = Mathf.Max(_speedMultiplier, _minSpeedFloor);

            // События
            OnWeightChanged?.Invoke();

            if (wasOverloaded != _isOverloaded || wasCritical != _isCriticalOverload)
            {
                OnOverloadStateChanged?.Invoke();

                if (_vitalitySystem != null)
                {
                    _vitalitySystem.SetOverload(_isCriticalOverload);
                }
            }
        }

        // =====================================================================
        // СИНЕРГИЯ С ТРАВМАМИ НОГ
        // =====================================================================
        private void ApplyLegInjurySynergy()
        {
            if (_healthSystem == null) return;

            int brokenLegs = 0;

            if (_healthSystem.IsFractured(BodyPart.LeftLeg) && !_healthSystem.IsSplinted(BodyPart.LeftLeg))
                brokenLegs++;
            if (_healthSystem.IsFractured(BodyPart.RightLeg) && !_healthSystem.IsSplinted(BodyPart.RightLeg))
                brokenLegs++;

            float injuryMult = brokenLegs switch
            {
                1 => 0.6f,
                2 => 0.3f,
                _ => 1.0f
            };

            _speedMultiplier *= injuryMult;
            _speedMultiplier = Mathf.Max(_speedMultiplier, _minSpeedFloor);
        }

        // =====================================================================
        // ГИПОДИНАМИЯ (ИСПРАВЛЕНО: Обновляем _weightRatio ДО расчёта скорости)
        // =====================================================================
        private void ApplyHypodynamiaPenalty()
        {
            if (_vitalitySystem == null) return;

            if (_vitalitySystem.Hunger <= 30f)
            {
                float reducedCapacity = _maxCapacity * 0.75f;
                float adjustedRatio = _currentWeight / reducedCapacity;

                // Обновляем _weightRatio если гиподинамия ухудшает ситуацию
                if (adjustedRatio > _weightRatio)
                {
                    _weightRatio = adjustedRatio;
                }
            }
        }

        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Debug: Add 10kg")]
        public void DebugAddWeight() => AddWeight(10f);

        [ContextMenu("Debug: Add 20kg (Critical Overload)")]
        public void DebugAddCritical() => AddWeight(20f);

        [ContextMenu("Debug: Remove 10kg")]
        public void DebugRemoveWeight() => RemoveWeight(10f);

        [ContextMenu("Debug: Set Critical Overload (120%)")]
        public void DebugCriticalOverload() => SetWeight(_maxCapacity * 1.2f);

        [ContextMenu("Debug: Reset Weight")]
        public void DebugResetWeight() => SetWeight(0f);

        [ContextMenu("Debug: Print Status")]
        public void DebugPrintStatus()
        {
            Debug.Log($"[WeightManager] Current: {_currentWeight:F1}kg | Max: {_maxCapacity:F1}kg");
            Debug.Log($"[WeightManager] Ratio: {_weightRatio * 100:F0}% | SpeedMult: {_speedMultiplier:F2}");
            Debug.Log($"[WeightManager] StaminaDrain: {_staminaDrainRate:F1}/sec");
            Debug.Log($"[WeightManager] Overload: {_isOverloaded} | Critical: {_isCriticalOverload}");
        }
    }
}