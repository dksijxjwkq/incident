﻿using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Компонентный триггер безопасной зоны (Аспект №6, №9)
    /// Поддержка множества зон в будущем без изменения кода
    /// </summary>
    public class K_SafeZoneTrigger : MonoBehaviour
    {
        [Header("Zone Settings")]
        [SerializeField] private string _zoneName = "TheHole";
        [SerializeField] private float _coldRecoveryTime = 60f; // Секунд на полную очистку холода
        [SerializeField] private float _metabolismMultiplier = 0.2f; // Замедление метаболизма

        private void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                var vitality = other.GetComponent<K_VitalitySystem>();
                if (vitality != null)
                {
                    vitality.SetSafeZoneState(true);
                    Debug.Log($"[SafeZone] ENTERED {_zoneName} — Metabolism ×{_metabolismMultiplier}, Cold recovery {_coldRecoveryTime}s");
                }
            }
        }

        private void OnTriggerExit(Collider other)
        {
            if (other.CompareTag("Player"))
            {
                var vitality = other.GetComponent<K_VitalitySystem>();
                if (vitality != null)
                {
                    vitality.SetSafeZoneState(false);
                    Debug.Log($"[SafeZone] LEFT {_zoneName}");
                }
            }
        }

        // ВИЗУАЛИЗАЦИЯ В SCENE VIEW (ТОЛЬКО КУБ, БЕЗ ТЕКСТА)
        private void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(0f, 1f, 0f, 0.3f); // Полупрозрачный зелёный
            Gizmos.DrawCube(transform.position, transform.lossyScale);

            Gizmos.color = Color.green;
            Gizmos.DrawWireCube(transform.position, transform.lossyScale);
        }
    }
}