﻿using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core
{
    public enum BodyPart { Head, Torso, Stomach, LeftArm, RightArm, LeftLeg, RightLeg }
    public enum DamageType { Generic, Firearm, Metabolism, Fall, Bleeding, Cold }

    public class K_HealthSystem : MonoBehaviour, ISaveable
    {
        public event Action OnHealthChanged;
        public event Action OnDeath;

        public string SaveID => "PlayerHealth";
        public bool IsDirty { get; set; } = true;
        public bool IsDead { get; private set; }

        // =====================================================================
        // КЭШИРОВАННЫЙ МАССИВ ДЛЯ ОПТИМИЗАЦИИ (ИСПРАВЛЕНИЕ УТЕЧКИ ПАМЯТИ)
        // =====================================================================
        private static readonly BodyPart[] _allBodyParts = (BodyPart[])Enum.GetValues(typeof(BodyPart));

        // =====================================================================
        // КОНСТАНТЫ БАЛАНСА (265 HP total)
        // =====================================================================
        private const float HEAD_BASE_HP = 20f;
        private const float TORSO_BASE_HP = 60f;
        private const float STOMACH_BASE_HP = 45f;
        private const float ARM_BASE_HP = 35f;
        private const float LEG_BASE_HP = 35f;
        private const float TOTAL_BASE_HEALTH = 265f;

        private const float PASSIVE_HEAL_RATE = 0.0004f;
        private const float BLEED_DAMAGE_RATE_LEVEL_1 = 0.01f;
        private const float BLEED_DAMAGE_RATE_LEVEL_2 = 0.02f;
        private const float BLEED_DAMAGE_RATE_LEVEL_3 = 0.05f;
        private const float FIREARM_SHOCK_DURATION = 10f;
        private const float FIREARM_FRACTURE_CHANCE = 0.4f;
        private const float UI_UPDATE_INTERVAL = 0.5f;
        private const float DAMAGE_DISTRIBUTION_COUNT = 7f;
        private const float LACERATION_HEAL_PENALTY = 0.7f;

        private const float LIMB_HP_FLOOR = 0.1f;

        // =====================================================================
        // ЛОКАЛИЗОВАННЫЕ СТАТУСЫ КОНЕЧНОСТЕЙ
        // =====================================================================
        [System.Serializable]
        public struct LimbStatus
        {
            public int bleedingLevel;
            public bool hasLaceration;
        }

        [Header("Localized Limb Statuses")]
        [SerializeField] private LimbStatus _headStatus;
        [SerializeField] private LimbStatus _torsoStatus;
        [SerializeField] private LimbStatus _stomachStatus;
        [SerializeField] private LimbStatus _leftArmStatus;
        [SerializeField] private LimbStatus _rightArmStatus;
        [SerializeField] private LimbStatus _leftLegStatus;
        [SerializeField] private LimbStatus _rightLegStatus;

        // =====================================================================
        // СЕГМЕНТЫ ТЕЛА
        // =====================================================================
        [Header("Body Segments")]
        [SerializeField] private BodySegment _head;
        [SerializeField] private BodySegment _torso;
        [SerializeField] private BodySegment _stomach;
        [SerializeField] private BodySegment _leftArm;
        [SerializeField] private BodySegment _rightArm;
        [SerializeField] private BodySegment _leftLeg;
        [SerializeField] private BodySegment _rightLeg;

        // =====================================================================
        // СТАТУСЫ
        // =====================================================================
        [Header("Status (Read Only)")]
        [SerializeField] private float _shockTimer = 0f;

        [Header("Fractures & Splints")]
        [SerializeField] private bool _lArmFractured;
        [SerializeField] private bool _rArmFractured;
        [SerializeField] private bool _lLegFractured;
        [SerializeField] private bool _rLegFractured;

        [SerializeField] private bool _lArmSplinted;
        [SerializeField] private bool _rArmSplinted;
        [SerializeField] private bool _lLegSplinted;
        [SerializeField] private bool _rLegSplinted;

        // =====================================================================
        // КЭШИРОВАННЫЕ ССЫЛКИ
        // =====================================================================
        private K_VitalitySystem _cachedVitality;
        private float _timeSinceLastUIUpdate = 0f;

        // =====================================================================
        // ГЕТТЕРЫ
        // =====================================================================
        public float HeadHP => _head.CurrentHP;
        public float BaseHeadHP => _head.OriginalMaxHP;
        public float TorsoHP => _torso.CurrentHP;
        public float BaseTorsoHP => _torso.OriginalMaxHP;
        public float StomachHP => _stomach.CurrentHP;
        public float BaseStomachHP => _stomach.OriginalMaxHP;
        public float LeftArmHP => _leftArm.CurrentHP;
        public float BaseLeftArmHP => _leftArm.OriginalMaxHP;
        public float RightArmHP => _rightArm.CurrentHP;
        public float BaseRightArmHP => _rightArm.OriginalMaxHP;
        public float LeftLegHP => _leftLeg.CurrentHP;
        public float BaseLeftLegHP => _leftLeg.OriginalMaxHP;
        public float RightLegHP => _rightLeg.CurrentHP;
        public float BaseRightLegHP => _rightLeg.OriginalMaxHP;

        public bool HasFracture => _lArmFractured || _rArmFractured || _lLegFractured || _rLegFractured;

        public int FractureCount =>
            ((_lArmFractured && !_lArmSplinted) ? 1 : 0) +
            ((_rArmFractured && !_rArmSplinted) ? 1 : 0) +
            ((_lLegFractured && !_lLegSplinted) ? 1 : 0) +
            ((_rLegFractured && !_rLegSplinted) ? 1 : 0);

        public bool HasLegFracture => (_lLegFractured && !_lLegSplinted) || (_rLegFractured && !_rLegSplinted);
        public bool HasArmFracture => (_lArmFractured && !_lArmSplinted) || (_rArmFractured && !_rArmSplinted);
        public bool IsShocked => _shockTimer > 0f;

        // =====================================================================
        // ЛОКАЛИЗОВАННЫЕ ГЕТТЕРЫ
        // =====================================================================
        public int GetBleedingLevel(BodyPart part) => GetLimbStatus(part).bleedingLevel;
        public bool HasLaceration(BodyPart part) => GetLimbStatus(part).hasLaceration;

        public int GetMaxBleedingLevel()
        {
            int maxLevel = 0;
            foreach (BodyPart part in _allBodyParts)
            {
                maxLevel = Mathf.Max(maxLevel, GetBleedingLevel(part));
            }
            return maxLevel;
        }

        public bool HasAnyLaceration()
        {
            foreach (BodyPart part in _allBodyParts)
            {
                if (HasLaceration(part)) return true;
            }
            return false;
        }

        public int GetBleedingLimbsCount()
        {
            int count = 0;
            foreach (BodyPart part in _allBodyParts)
            {
                if (GetBleedingLevel(part) > 0) count++;
            }
            return count;
        }

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void OnValidate()
        {
            if (Application.isPlaying)
            {
                FixZeroHPWithoutFracture();
                EnforceFractureHP();
                ClampAllSegments();
                CheckDeathConditions();
                NotifyChange();
            }
        }

        private void Awake()
        {
            InitializeSegments();
            _cachedVitality = GetComponent<K_VitalitySystem>();

            if (_cachedVitality == null)
                Debug.LogWarning("[K_HealthSystem] K_VitalitySystem not found!");
            else
                Debug.Log("[K_HealthSystem] K_VitalitySystem cached successfully");
        }

        private void Start()
        {
            K_SaveManager.Instance?.Register(this);
        }

        // =====================================================================
        // ONDESTROY — ИСПРАВЛЕНИЕ УТЕЧКИ (ОТПИСКА ОТ SAVE MANAGER)
        // =====================================================================
        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
        }

        private void Update()
        {
            if (IsDead) return;

            if (_shockTimer > 0f)
            {
                _shockTimer -= Time.deltaTime;
                if (_shockTimer <= 0f) NotifyChange();
            }

            if (GetMaxBleedingLevel() > 0 && !IsShocked)
            {
                ApplyBleedingDamage();
            }

            if (HandlePassiveHealing())
            {
                _timeSinceLastUIUpdate += Time.deltaTime;
                if (_timeSinceLastUIUpdate >= UI_UPDATE_INTERVAL)
                {
                    NotifyChange();
                    _timeSinceLastUIUpdate = 0f;
                }
            }
        }

        // =====================================================================
        // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
        // =====================================================================
        private LimbStatus GetLimbStatus(BodyPart part)
        {
            return part switch
            {
                BodyPart.Head => _headStatus,
                BodyPart.Torso => _torsoStatus,
                BodyPart.Stomach => _stomachStatus,
                BodyPart.LeftArm => _leftArmStatus,
                BodyPart.RightArm => _rightArmStatus,
                BodyPart.LeftLeg => _leftLegStatus,
                BodyPart.RightLeg => _rightLegStatus,
                _ => _torsoStatus
            };
        }

        private void SetLimbStatus(BodyPart part, LimbStatus status)
        {
            switch (part)
            {
                case BodyPart.Head: _headStatus = status; break;
                case BodyPart.Torso: _torsoStatus = status; break;
                case BodyPart.Stomach: _stomachStatus = status; break;
                case BodyPart.LeftArm: _leftArmStatus = status; break;
                case BodyPart.RightArm: _rightArmStatus = status; break;
                case BodyPart.LeftLeg: _leftLegStatus = status; break;
                case BodyPart.RightLeg: _rightLegStatus = status; break;
            }
        }

        private void FixZeroHPWithoutFracture()
        {
            if (_leftArm.CurrentHP <= 0f && !_lArmFractured)
            {
                _lArmFractured = true;
                _lArmSplinted = false;
            }
            if (_rightArm.CurrentHP <= 0f && !_rArmFractured)
            {
                _rArmFractured = true;
                _rArmSplinted = false;
            }
            if (_leftLeg.CurrentHP <= 0f && !_lLegFractured)
            {
                _lLegFractured = true;
                _lLegSplinted = false;
            }
            if (_rightLeg.CurrentHP <= 0f && !_rLegFractured)
            {
                _rLegFractured = true;
                _rLegSplinted = false;
            }
        }

        private void EnforceFractureHP()
        {
            if (_lArmFractured && !_lArmSplinted && _leftArm.CurrentHP > 0f) _leftArm.SetHP(0f);
            if (_rArmFractured && !_rArmSplinted && _rightArm.CurrentHP > 0f) _rightArm.SetHP(0f);
            if (_lLegFractured && !_lLegSplinted && _leftLeg.CurrentHP > 0f) _leftLeg.SetHP(0f);
            if (_rLegFractured && !_rLegSplinted && _rightLeg.CurrentHP > 0f) _rightLeg.SetHP(0f);
        }

        private void InitializeSegments()
        {
            if (_head.OriginalMaxHP <= 0) _head = new BodySegment(HEAD_BASE_HP);
            if (_torso.OriginalMaxHP <= 0) _torso = new BodySegment(TORSO_BASE_HP);
            if (_stomach.OriginalMaxHP <= 0) _stomach = new BodySegment(STOMACH_BASE_HP);
            if (_leftArm.OriginalMaxHP <= 0) _leftArm = new BodySegment(ARM_BASE_HP);
            if (_rightArm.OriginalMaxHP <= 0) _rightArm = new BodySegment(ARM_BASE_HP);
            if (_leftLeg.OriginalMaxHP <= 0) _leftLeg = new BodySegment(LEG_BASE_HP);
            if (_rightLeg.OriginalMaxHP <= 0) _rightLeg = new BodySegment(LEG_BASE_HP);
        }

        // =====================================================================
        // ПРИНЯТИЕ УРОНА
        // =====================================================================
        public void TakeDamage(float damage, BodyPart part, DamageType type = DamageType.Generic, int weaponBleed = 0)
        {
            if (IsDead || damage <= 0f) return;

            var segment = GetSegment(part);
            float overflow = segment.ApplyDamageWithOverflow(damage);

            if (overflow > 0f && part != BodyPart.Torso)
            {
                float torsoOverflow = _torso.ApplyDamageWithOverflow(overflow);
                if (torsoOverflow > 0f)
                    _head.ApplyDamage(torsoOverflow);
            }

            if (type == DamageType.Firearm)
            {
                _shockTimer = FIREARM_SHOCK_DURATION;

                if (weaponBleed > 0)
                {
                    LimbStatus status = GetLimbStatus(part);
                    status.bleedingLevel = Mathf.Max(status.bleedingLevel, weaponBleed);
                    status.hasLaceration = true;
                    SetLimbStatus(part, status);
                }

                if (CanPartFracture(part))
                {
                    float fractureMult = _cachedVitality != null ? _cachedVitality.FractureChanceMult : 1.0f;
                    float finalChance = FIREARM_FRACTURE_CHANCE * fractureMult;

                    if (segment.CurrentHP <= 0f)
                    {
                        ApplyFracture(part);
                    }
                    else if (UnityEngine.Random.value < finalChance)
                    {
                        ApplyFracture(part);
                    }
                }

                NotifyChange();
            }

            CheckDeathConditions();
            NotifyChange();
        }

        // =====================================================================
        // УРОН ОТ МЕТАБОЛИЗМА
        // =====================================================================
        public void TakeMetabolismDamage(float damage, BodyPart part)
        {
            if (IsDead || damage <= 0f) return;

            if (_stomach.CurrentHP > 0f)
            {
                _stomach.ApplyDamage(damage);
            }
            else
            {
                float damagePerSegment = damage / DAMAGE_DISTRIBUTION_COUNT;
                _head.ApplyDamage(damagePerSegment);
                _torso.ApplyDamage(damagePerSegment);
                _stomach.ApplyDamage(damagePerSegment);
                _leftArm.ApplyDamage(damagePerSegment);
                _rightArm.ApplyDamage(damagePerSegment);
                _leftLeg.ApplyDamage(damagePerSegment);
                _rightLeg.ApplyDamage(damagePerSegment);
            }

            CheckDeathConditions();
            NotifyChange();
        }

        // =====================================================================
        // УРОН ОТ ХОЛОДА
        // =====================================================================
        public void ApplyColdDamage(float totalDamage)
        {
            if (IsDead) return;

            BodyPart[] primaryTargets = {
                BodyPart.LeftArm, BodyPart.RightArm,
                BodyPart.LeftLeg, BodyPart.RightLeg,
                BodyPart.Stomach
            };

            BodyPart[] vitalTargets = {
                BodyPart.Torso, BodyPart.Head
            };

            float remainingDamage = totalDamage;

            int activePrimaryTargets = 0;
            foreach (var part in primaryTargets)
            {
                var segment = GetSegment(part);
                if (segment.CurrentHP > LIMB_HP_FLOOR)
                    activePrimaryTargets++;
            }

            if (activePrimaryTargets > 0)
            {
                float damagePerSegment = remainingDamage / activePrimaryTargets;

                foreach (var part in primaryTargets)
                {
                    if (remainingDamage <= 0f) break;

                    var segment = GetSegment(part);
                    if (segment.CurrentHP > LIMB_HP_FLOOR)
                    {
                        float damageToApply = Mathf.Min(damagePerSegment, segment.CurrentHP - LIMB_HP_FLOOR);
                        damageToApply = Mathf.Max(0f, damageToApply);

                        if (damageToApply > 0f)
                        {
                            segment.ApplyDamage(damageToApply);
                            remainingDamage -= damageToApply;
                        }
                    }
                }
            }

            if (remainingDamage > 0f)
            {
                int activeVitalTargets = 0;
                foreach (var part in vitalTargets)
                {
                    var segment = GetSegment(part);
                    if (segment.CurrentHP > 0f)
                        activeVitalTargets++;
                }

                if (activeVitalTargets > 0)
                {
                    float damagePerSegment = remainingDamage / activeVitalTargets;

                    foreach (var part in vitalTargets)
                    {
                        if (remainingDamage <= 0f) break;

                        var segment = GetSegment(part);
                        if (segment.CurrentHP > 0f)
                        {
                            float damageToApply = Mathf.Min(damagePerSegment, segment.CurrentHP);

                            if (damageToApply > 0f)
                            {
                                segment.ApplyDamage(damageToApply);
                                remainingDamage -= damageToApply;
                            }
                        }
                    }
                }
            }

            CheckDeathConditions();
            NotifyChange();
        }

        // =====================================================================
        // ПЕРЕЛОМЫ И ШИНЫ
        // =====================================================================
        private bool CanPartFracture(BodyPart part)
        {
            return part == BodyPart.LeftArm || part == BodyPart.RightArm ||
                   part == BodyPart.LeftLeg || part == BodyPart.RightLeg;
        }

        public void ApplyFracture(BodyPart part)
        {
            if (!CanPartFracture(part)) return;

            if (IsFractured(part) && !IsSplinted(part))
                return;

            if (IsFractured(part) && IsSplinted(part))
                ResetFractureFlag(part);

            if (IsSplinted(part))
                RemoveSplint(part);

            switch (part)
            {
                case BodyPart.LeftArm:
                    _lArmFractured = true;
                    _lArmSplinted = false;
                    _leftArm.SetHP(0f);
                    break;
                case BodyPart.RightArm:
                    _rArmFractured = true;
                    _rArmSplinted = false;
                    _rightArm.SetHP(0f);
                    break;
                case BodyPart.LeftLeg:
                    _lLegFractured = true;
                    _lLegSplinted = false;
                    _leftLeg.SetHP(0f);
                    break;
                case BodyPart.RightLeg:
                    _rLegFractured = true;
                    _rLegSplinted = false;
                    _rightLeg.SetHP(0f);
                    break;
            }

            NotifyChange();
        }

        public void ApplySplint(BodyPart part)
        {
            if (!IsFractured(part))
            {
                Debug.LogWarning($"[Health] Cannot apply splint to {part} — not fractured!");
                return;
            }

            switch (part)
            {
                case BodyPart.LeftArm:
                    _lArmFractured = false;
                    _lArmSplinted = true;
                    if (_leftArm.CurrentHP <= 0f) _leftArm.SetHP(1f);
                    break;
                case BodyPart.RightArm:
                    _rArmFractured = false;
                    _rArmSplinted = true;
                    if (_rightArm.CurrentHP <= 0f) _rightArm.SetHP(1f);
                    break;
                case BodyPart.LeftLeg:
                    _lLegFractured = false;
                    _lLegSplinted = true;
                    if (_leftLeg.CurrentHP <= 0f) _leftLeg.SetHP(1f);
                    break;
                case BodyPart.RightLeg:
                    _rLegFractured = false;
                    _rLegSplinted = true;
                    if (_rightLeg.CurrentHP <= 0f) _rightLeg.SetHP(1f);
                    break;
            }

            NotifyChange();
        }

        public void RemoveSplint(BodyPart part)
        {
            switch (part)
            {
                case BodyPart.LeftArm: _lArmSplinted = false; break;
                case BodyPart.RightArm: _rArmSplinted = false; break;
                case BodyPart.LeftLeg: _lLegSplinted = false; break;
                case BodyPart.RightLeg: _rLegSplinted = false; break;
            }
            NotifyChange();
        }

        private void ResetFractureFlag(BodyPart part)
        {
            switch (part)
            {
                case BodyPart.LeftArm:
                    _lArmFractured = false;
                    _lArmSplinted = false;
                    break;
                case BodyPart.RightArm:
                    _rArmFractured = false;
                    _rArmSplinted = false;
                    break;
                case BodyPart.LeftLeg:
                    _lLegFractured = false;
                    _lLegSplinted = false;
                    break;
                case BodyPart.RightLeg:
                    _rLegFractured = false;
                    _rLegSplinted = false;
                    break;
            }
        }

        // =====================================================================
        // ЛЕЧЕНИЕ (ИСПРАВЛЕНИЕ: ИНДИВИДУАЛЬНАЯ ПРОВЕРКА КАЖДОЙ КОНЕЧНОСТИ)
        // =====================================================================
        public void HealSegment(BodyPart part, float amount)
        {
            if (IsDead || amount <= 0f) return;

            // Блокировки для КОНКРЕТНОЙ конечности:
            // 1. Рваная рана (глобальная блокировка)
            // 2. Перелом ЭТОЙ конечности без шины
            if (HasAnyLaceration()) return;
            if (IsFractured(part) && !IsSplinted(part))
            {
                Debug.Log($"[Health] Cannot heal {part} — fractured without splint!");
                return;
            }

            float segmentHealAmount = amount * LACERATION_HEAL_PENALTY;

            if (GetSegment(part).Heal(segmentHealAmount)) NotifyChange();
        }

        public void HealAll(float amount)
        {
            if (IsDead || amount <= 0f || HasAnyLaceration()) return;

            bool changed = false;

            // Лечим КАЖДУЮ конечность индивидуально
            // Если конечность сломана БЕЗ шины — пропускаем ТОЛЬКО её
            if (!_lArmFractured || _lArmSplinted) changed |= _leftArm.Heal(amount);
            if (!_rArmFractured || _rArmSplinted) changed |= _rightArm.Heal(amount);
            if (!_lLegFractured || _lLegSplinted) changed |= _leftLeg.Heal(amount);
            if (!_rLegFractured || _rLegSplinted) changed |= _rightLeg.Heal(amount);

            changed |= _head.Heal(amount);
            changed |= _torso.Heal(amount);
            changed |= _stomach.Heal(amount);

            if (changed) NotifyChange();
        }

        // =====================================================================
        // ПАССИВНОЕ ЛЕЧЕНИЕ (ИСПРАВЛЕНО: ПРОВЕРКА КАЖДОЙ КОНЕЧНОСТИ)
        // =====================================================================
        private bool HandlePassiveHealing()
        {
            bool isLowVitality = _cachedVitality != null && (_cachedVitality.Hunger <= 25f || _cachedVitality.Thirst <= 25f);
            bool isStarving = _cachedVitality != null && (_cachedVitality.Hunger <= 0f || _cachedVitality.Thirst <= 0f);

            // Глобальные блокировки
            if (HasAnyLaceration() || GetMaxBleedingLevel() > 0 || isLowVitality) return false;

            float passiveHealAmount = PASSIVE_HEAL_RATE * Time.deltaTime;
            bool changed = false;

            // Лечим КАЖДУЮ конечность индивидуально
            // Vitals (голова/торс/живот) — всегда лечатся если HP > 0
            if (_head.CurrentHP > 0f && _head.Heal(passiveHealAmount)) changed = true;
            if (_torso.CurrentHP > 0f && _torso.Heal(passiveHealAmount)) changed = true;
            if (_stomach.CurrentHP > 0f && _stomach.Heal(passiveHealAmount)) changed = true;

            // Конечности — лечатся только если НЕ сломаны ИЛИ наложена шина
            if (_leftArm.CurrentHP > 0f && (!_lArmFractured || _lArmSplinted) && _leftArm.Heal(passiveHealAmount)) changed = true;
            if (_rightArm.CurrentHP > 0f && (!_rArmFractured || _rArmSplinted) && _rightArm.Heal(passiveHealAmount)) changed = true;
            if (_leftLeg.CurrentHP > 0f && (!_lLegFractured || _lLegSplinted) && _leftLeg.Heal(passiveHealAmount)) changed = true;
            if (_rightLeg.CurrentHP > 0f && (!_rLegFractured || _rLegSplinted) && _rightLeg.Heal(passiveHealAmount)) changed = true;

            return changed;
        }

        // =====================================================================
        // КРОВОТЕЧЕНИЕ
        // =====================================================================
        private void ApplyBleedingDamage()
        {
            int maxLevel = GetMaxBleedingLevel();
            int bleedingLimbsCount = GetBleedingLimbsCount();

            float baseDamage = maxLevel switch
            {
                1 => BLEED_DAMAGE_RATE_LEVEL_1,
                2 => BLEED_DAMAGE_RATE_LEVEL_2,
                3 => BLEED_DAMAGE_RATE_LEVEL_3,
                _ => 0f
            };

            float additionalDamage = (bleedingLimbsCount - 1) * 0.01f;
            float totalDamage = baseDamage + Mathf.Max(0f, additionalDamage);

            float damage = totalDamage * Time.deltaTime;

            _head.ApplyDamage(damage);
            _torso.ApplyDamage(damage);
            _stomach.ApplyDamage(damage);
            _leftArm.ApplyDamage(damage);
            _rightArm.ApplyDamage(damage);
            _leftLeg.ApplyDamage(damage);
            _rightLeg.ApplyDamage(damage);

            CheckDeathConditions();
        }

        public void SetBleedingLevel(int level)
        {
            // Для обратной совместимости — ставим на все конечности
            foreach (BodyPart part in _allBodyParts)
            {
                LimbStatus status = GetLimbStatus(part);
                status.bleedingLevel = Mathf.Clamp(level, 0, 3);
                SetLimbStatus(part, status);
            }
            NotifyChange();
        }

        public void StopBleeding()
        {
            foreach (BodyPart part in _allBodyParts)
            {
                LimbStatus status = GetLimbStatus(part);
                status.bleedingLevel = 0;
                SetLimbStatus(part, status);
            }
            NotifyChange();
        }

        // =====================================================================
        // БИНТЫ (ЛОКАЛИЗОВАННЫЕ)
        // =====================================================================
        public bool UseBandage(BodyPart? targetPart = null)
        {
            if (targetPart == null)
            {
                targetPart = GetPartWithMaxBleeding();
                if (targetPart == null)
                {
                    Debug.Log("[Health] No bleeding to stop!");
                    return false;
                }
            }

            LimbStatus status = GetLimbStatus(targetPart.Value);

            if (status.bleedingLevel == 0)
            {
                Debug.Log($"[Health] No bleeding on {targetPart}!");
                return false;
            }

            status.bleedingLevel = Mathf.Max(0, status.bleedingLevel - 1);
            SetLimbStatus(targetPart.Value, status);

            NotifyChange();
            return true;
        }

        public BodyPart? GetPartWithMaxBleeding()
        {
            int maxLevel = 0;
            BodyPart? maxPart = null;

            foreach (BodyPart part in _allBodyParts)
            {
                int level = GetBleedingLevel(part);
                if (level > maxLevel)
                {
                    maxLevel = level;
                    maxPart = part;
                }
            }

            return maxPart;
        }

        // =====================================================================
        // ШОВНЫЙ НАБОР (ЛОКАЛИЗОВАННЫЙ)
        // =====================================================================
        public bool UseSutureKit(BodyPart? targetPart = null)
        {
            if (targetPart == null)
            {
                bool anyHealed = false;
                foreach (BodyPart part in _allBodyParts)
                {
                    if (UseSutureKit(part)) anyHealed = true;
                }
                return anyHealed;
            }

            if (!HasLaceration(targetPart.Value))
            {
                Debug.Log($"[Health] No laceration on {targetPart}!");
                return false;
            }

            LimbStatus status = GetLimbStatus(targetPart.Value);
            status.hasLaceration = false;
            SetLimbStatus(targetPart.Value, status);

            NotifyChange();
            return true;
        }

        // =====================================================================
        // РАДИАЦИЯ
        // =====================================================================
        public void ApplyRadiationClamp(float radiationPercent)
        {
            if (radiationPercent >= 100f)
            {
                _head.SetHP(0f);
                _torso.SetHP(0f);
                _stomach.SetHP(0f);
                _leftArm.SetHP(0f);
                _rightArm.SetHP(0f);
                _leftLeg.SetHP(0f);
                _rightLeg.SetHP(0f);
                Die();
                return;
            }

            float radiationFactor = Mathf.Clamp01(1.0f - (radiationPercent / 100f));

            _head.SetMaxHP(HEAD_BASE_HP * radiationFactor);
            _torso.SetMaxHP(TORSO_BASE_HP * radiationFactor);
            _stomach.SetMaxHP(STOMACH_BASE_HP * radiationFactor);
            _leftArm.SetMaxHP(ARM_BASE_HP * radiationFactor);
            _rightArm.SetMaxHP(ARM_BASE_HP * radiationFactor);
            _leftLeg.SetMaxHP(LEG_BASE_HP * radiationFactor);
            _rightLeg.SetMaxHP(LEG_BASE_HP * radiationFactor);

            ClampAllSegments();
            NotifyChange();
        }

        private void ClampAllSegments()
        {
            _head.ClampHP();
            _torso.ClampHP();
            _stomach.ClampHP();
            _leftArm.ClampHP();
            _rightArm.ClampHP();
            _leftLeg.ClampHP();
            _rightLeg.ClampHP();
        }

        // =====================================================================
        // ПРОВЕРКА СМЕРТИ
        // =====================================================================
        private void CheckDeathConditions()
        {
            if (_head.CurrentHP <= 0f || _torso.CurrentHP <= 0f) Die();
        }

        private void Die()
        {
            if (!IsDead)
            {
                IsDead = true;
                OnDeath?.Invoke();
                Debug.Log("[K_HealthSystem] PLAYER DEAD");
            }
        }

        // =====================================================================
        // ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ
        // =====================================================================
        private BodySegment GetSegment(BodyPart part) => part switch
        {
            BodyPart.Head => _head,
            BodyPart.Stomach => _stomach,
            BodyPart.LeftArm => _leftArm,
            BodyPart.RightArm => _rightArm,
            BodyPart.LeftLeg => _leftLeg,
            BodyPart.RightLeg => _rightLeg,
            _ => _torso
        };

        public bool IsFractured(BodyPart part) => part switch
        {
            BodyPart.LeftArm => _lArmFractured,
            BodyPart.RightArm => _rArmFractured,
            BodyPart.LeftLeg => _lLegFractured,
            BodyPart.RightLeg => _rLegFractured,
            _ => false
        };

        public bool IsSplinted(BodyPart part) => part switch
        {
            BodyPart.LeftArm => _lArmSplinted,
            BodyPart.RightArm => _rArmSplinted,
            BodyPart.LeftLeg => _lLegSplinted,
            BodyPart.RightLeg => _rLegSplinted,
            _ => false
        };

        public bool HasBlockingDebuffs()
        {
            return HasAnyLaceration() || GetMaxBleedingLevel() > 0 || HasFracture;
        }

        public bool CanPassiveHeal()
        {
            bool isLowVitality = _cachedVitality != null && (_cachedVitality.Hunger <= 25f || _cachedVitality.Thirst <= 25f);
            bool isStarving = _cachedVitality != null && (_cachedVitality.Hunger <= 0f || _cachedVitality.Thirst <= 0f);
            return !HasBlockingDebuffs() && !isLowVitality && !isStarving;
        }

        private void NotifyChange()
        {
            IsDirty = true;
            OnHealthChanged?.Invoke();
        }

        // =====================================================================
        // СОХРАНЕНИЕ / ЗАГРУЗКА
        // =====================================================================
        public void Save(BinaryWriter writer)
        {
            writer.Write(_head.CurrentHP);
            writer.Write(_torso.CurrentHP);
            writer.Write(_stomach.CurrentHP);
            writer.Write(_leftArm.CurrentHP);
            writer.Write(_rightArm.CurrentHP);
            writer.Write(_leftLeg.CurrentHP);
            writer.Write(_rightLeg.CurrentHP);

            writer.Write(_shockTimer);

            writer.Write(_headStatus.bleedingLevel);
            writer.Write(_headStatus.hasLaceration);
            writer.Write(_torsoStatus.bleedingLevel);
            writer.Write(_torsoStatus.hasLaceration);
            writer.Write(_stomachStatus.bleedingLevel);
            writer.Write(_stomachStatus.hasLaceration);
            writer.Write(_leftArmStatus.bleedingLevel);
            writer.Write(_leftArmStatus.hasLaceration);
            writer.Write(_rightArmStatus.bleedingLevel);
            writer.Write(_rightArmStatus.hasLaceration);
            writer.Write(_leftLegStatus.bleedingLevel);
            writer.Write(_leftLegStatus.hasLaceration);
            writer.Write(_rightLegStatus.bleedingLevel);
            writer.Write(_rightLegStatus.hasLaceration);

            writer.Write(_lArmFractured);
            writer.Write(_rArmFractured);
            writer.Write(_lLegFractured);
            writer.Write(_rLegFractured);

            writer.Write(_lArmSplinted);
            writer.Write(_rArmSplinted);
            writer.Write(_lLegSplinted);
            writer.Write(_rLegSplinted);
        }

        public void Load(BinaryReader reader)
        {
            _head.SetHP(reader.ReadSingle());
            _torso.SetHP(reader.ReadSingle());
            _stomach.SetHP(reader.ReadSingle());
            _leftArm.SetHP(reader.ReadSingle());
            _rightArm.SetHP(reader.ReadSingle());
            _leftLeg.SetHP(reader.ReadSingle());
            _rightLeg.SetHP(reader.ReadSingle());

            _shockTimer = reader.ReadSingle();

            _headStatus.bleedingLevel = reader.ReadInt32();
            _headStatus.hasLaceration = reader.ReadBoolean();
            _torsoStatus.bleedingLevel = reader.ReadInt32();
            _torsoStatus.hasLaceration = reader.ReadBoolean();
            _stomachStatus.bleedingLevel = reader.ReadInt32();
            _stomachStatus.hasLaceration = reader.ReadBoolean();
            _leftArmStatus.bleedingLevel = reader.ReadInt32();
            _leftArmStatus.hasLaceration = reader.ReadBoolean();
            _rightArmStatus.bleedingLevel = reader.ReadInt32();
            _rightArmStatus.hasLaceration = reader.ReadBoolean();
            _leftLegStatus.bleedingLevel = reader.ReadInt32();
            _leftLegStatus.hasLaceration = reader.ReadBoolean();
            _rightLegStatus.bleedingLevel = reader.ReadInt32();
            _rightLegStatus.hasLaceration = reader.ReadBoolean();

            _lArmFractured = reader.ReadBoolean();
            _rArmFractured = reader.ReadBoolean();
            _lLegFractured = reader.ReadBoolean();
            _rLegFractured = reader.ReadBoolean();

            _lArmSplinted = reader.ReadBoolean();
            _rArmSplinted = reader.ReadBoolean();
            _lLegSplinted = reader.ReadBoolean();
            _rLegSplinted = reader.ReadBoolean();

            ClampAllSegments();
            EnforceFractureHP();
            NotifyChange();
        }

        // =====================================================================
        // BODY SEGMENT
        // =====================================================================
        [Serializable]
        private class BodySegment
        {
            [SerializeField] private float _originalMaxHP;
            [SerializeField] private float _maxHP;
            [SerializeField] private float _currentHP;

            public float CurrentHP => _currentHP;
            public float MaxHP => _maxHP;
            public float OriginalMaxHP => _originalMaxHP;

            public BodySegment(float maxHP)
            {
                _originalMaxHP = maxHP;
                _maxHP = maxHP;
                _currentHP = maxHP;
            }

            public float ApplyDamageWithOverflow(float damage)
            {
                float actualDamage = Mathf.Min(_currentHP, damage);
                _currentHP = Mathf.Max(0f, _currentHP - actualDamage);
                return damage - actualDamage;
            }

            public void ApplyDamage(float damage)
            {
                _currentHP = Mathf.Max(0f, _currentHP - damage);
            }

            public bool Heal(float amount)
            {
                if (_currentHP <= 0f || _currentHP >= _maxHP) return false;

                float oldHP = _currentHP;
                _currentHP = Mathf.Min(_currentHP + amount, _maxHP);
                return _currentHP > oldHP;
            }

            public void SetHP(float value)
            {
                _currentHP = Mathf.Clamp(value, 0f, _maxHP);
            }

            public void SetMaxHP(float value)
            {
                _maxHP = Mathf.Max(1f, value);
                ClampHP();
            }

            public void ClampHP()
            {
                _currentHP = Mathf.Clamp(_currentHP, 0f, _maxHP);
            }
        }

        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Debug: Set Bleeding Level 3 (LeftArm)")]
        public void DebugSetBleeding()
        {
            LimbStatus status = _leftArmStatus;
            status.bleedingLevel = 3;
            status.hasLaceration = true;
            _leftArmStatus = status;
        }

        [ContextMenu("Debug: Stop All Bleeding")]
        public void DebugStopBleeding()
        {
            foreach (BodyPart part in _allBodyParts)
            {
                LimbStatus status = GetLimbStatus(part);
                status.bleedingLevel = 0;
                SetLimbStatus(part, status);
            }
        }

        [ContextMenu("Debug: Remove All Lacerations")]
        public void DebugRemoveLaceration()
        {
            foreach (BodyPart part in _allBodyParts)
            {
                LimbStatus status = GetLimbStatus(part);
                status.hasLaceration = false;
                SetLimbStatus(part, status);
            }
        }

        [ContextMenu("Debug: Fracture Left Leg")]
        public void DebugFractureLeftLeg() => ApplyFracture(BodyPart.LeftLeg);

        [ContextMenu("Debug: Splint Left Leg")]
        public void DebugSplintLeftLeg() => ApplySplint(BodyPart.LeftLeg);

        [ContextMenu("Debug: Apply 50 Radiation")]
        public void DebugRadiation50() => ApplyRadiationClamp(50f);

        [ContextMenu("Debug: Apply 100 Radiation (Death)")]
        public void DebugRadiation100() => ApplyRadiationClamp(100f);
    }
}