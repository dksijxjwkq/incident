using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core
{
    public interface IChunkEntity
    {
        void OnBucketUpdate();
    }

    public class K_WorldController : MonoBehaviour
    {
        public static K_WorldController Instance { get; private set; }

        // 4 ������ ��� ������������� ��������
        private readonly List<IChunkEntity>[] _updateBuckets = new List<IChunkEntity>[4];
        private int _currentBucketIndex = 0;

        // ������� ���������� �����������
        private readonly Queue<IChunkEntity> _pendingAdditions = new Queue<IChunkEntity>();
        private readonly Queue<IChunkEntity> _pendingRemovals = new Queue<IChunkEntity>();

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;

            for (int i = 0; i < 4; i++)
            {
                _updateBuckets[i] = new List<IChunkEntity>(256);
            }
        }

        // =====================================================================
        // ONDESTROY � ����� SINGLETON � �������
        // =====================================================================
        private void OnDestroy()
        {
            if (Instance == this) Instance = null;

            for (int i = 0; i < 4; i++)
            {
                if (_updateBuckets[i] != null)
                {
                    _updateBuckets[i].Clear();
                    _updateBuckets[i] = null;
                }
            }
            _pendingAdditions.Clear();
            _pendingRemovals.Clear();
        }

        private void Update()
        {
            if (_updateBuckets == null || _updateBuckets[0] == null) return;

            ProcessPendingModifications();

            List<IChunkEntity> currentBucket = _updateBuckets[_currentBucketIndex];

            if (currentBucket != null)
            {
                int count = currentBucket.Count;
                for (int i = 0; i < count; i++)
                {
                    var entity = currentBucket[i];
                    if (entity != null && !(entity is MonoBehaviour mb && mb == null))
                    {
                        entity.OnBucketUpdate();
                    }
                }
            }

            _currentBucketIndex = (_currentBucketIndex + 1) % 4;
        }

        public void RegisterEntity(IChunkEntity entity)
        {
            if (entity != null) _pendingAdditions.Enqueue(entity);
        }

        public void UnregisterEntity(IChunkEntity entity)
        {
            if (entity != null) _pendingRemovals.Enqueue(entity);
        }

        private void ProcessPendingModifications()
        {
            while (_pendingRemovals.Count > 0)
            {
                IChunkEntity entity = _pendingRemovals.Dequeue();
                for (int i = 0; i < 4; i++)
                {
                    if (_updateBuckets[i] != null && _updateBuckets[i].Remove(entity)) break;
                }
            }

            while (_pendingAdditions.Count > 0)
            {
                IChunkEntity entity = _pendingAdditions.Dequeue();
                int smallestBucket = 0;
                int minSize = _updateBuckets[0]?.Count ?? int.MaxValue;
                for (int i = 1; i < 4; i++)
                {
                    int bucketSize = _updateBuckets[i]?.Count ?? int.MaxValue;
                    if (bucketSize < minSize) { smallestBucket = i; minSize = bucketSize; }
                }
                _updateBuckets[smallestBucket]?.Add(entity);
            }
        }
    }
}