﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    [Serializable]
    public class InventoryData : ISaveable
    {
        [SerializeField] private int _width = 8;
        [SerializeField] private int _height = 10;
        [SerializeField] private List<SavedItem> _items = new List<SavedItem>();
        [SerializeField] private bool _isModified = false;

        [NonSerialized] private Dictionary<uint, int> _idToIndexMap;
        [NonSerialized] private ReadOnlyCollection<SavedItem> _readOnlyItems;
        [NonSerialized] private bool _isIndexMapValid = false;

        public string SaveID => $"InvData_{_width}x{_height}";
        public bool IsDirty { get => _isModified; set => _isModified = value; }

        public InventoryData() { _items = new List<SavedItem>(); }

        public InventoryData(int width, int height)
        {
            _width = width;
            _height = height;
            _items = new List<SavedItem>();
        }

        public int Width => _width;
        public int Height => _height;
        public bool IsModified => _isModified;

        public IReadOnlyList<SavedItem> GetItems()
        {
            if (_readOnlyItems == null) _readOnlyItems = _items.AsReadOnly();
            return _readOnlyItems;
        }

        public int GetItemCount() => _items.Count;

        public void Clear()
        {
            _items.Clear();
            MarkDirty();
            _isIndexMapValid = false;
        }

        public void MarkClean() => _isModified = false;
        public void MarkDirty() => _isModified = true;

        private void EnsureIndexMap()
        {
            if (_isIndexMapValid && _idToIndexMap != null && _idToIndexMap.Count == _items.Count) return;

            _idToIndexMap = new Dictionary<uint, int>(_items.Count);
            for (int i = 0; i < _items.Count; i++)
            {
                if (!_idToIndexMap.ContainsKey(_items[i].InstanceID))
                    _idToIndexMap[_items[i].InstanceID] = i;
            }
            _isIndexMapValid = true;
        }

        public bool HasItem(uint instanceID)
        {
            EnsureIndexMap();
            return _idToIndexMap.ContainsKey(instanceID);
        }

        public SavedItem GetItem(uint instanceID)
        {
            EnsureIndexMap();
            return _idToIndexMap.TryGetValue(instanceID, out int index) && index < _items.Count
                ? _items[index]
                : default;
        }

        public void AddItem(SavedItem item)
        {
#if UNITY_EDITOR
            Debug.Assert(item.InstanceID > 0, $"[InventoryData] Attempted to add item with InstanceID = 0");
            Debug.Assert(item.X >= 0 && item.X < _width && item.Y >= 0 && item.Y < _height,
                $"[InventoryData] Item {item.InstanceID} has invalid position ({item.X},{item.Y}) in {_width}x{_height} grid");
#endif

            if (HasItem(item.InstanceID))
            {
                Debug.LogWarning($"[InventoryData] Duplicate InstanceID {item.InstanceID} — skipping add");
                return;
            }

            _items.Add(item);
            MarkDirty();
            if (_isIndexMapValid) _idToIndexMap[item.InstanceID] = _items.Count - 1;
        }

        public void RemoveItem(uint instanceID)
        {
            EnsureIndexMap();
            if (_idToIndexMap.TryGetValue(instanceID, out int index) && index < _items.Count)
            {
                int last = _items.Count - 1;
                if (index < last)
                {
                    var swap = _items[last];
                    _items[index] = swap;
                    if (_isIndexMapValid) _idToIndexMap[swap.InstanceID] = index;
                }
                _items.RemoveAt(last);
                if (_isIndexMapValid) _idToIndexMap.Remove(instanceID);
            }
            MarkDirty();
        }

        public void UpdateItem(uint instanceID, int x, int y, int quantity, bool isRotated)
        {
            if (x < 0 || y < 0 || x >= _width || y >= _height)
            {
                Debug.LogWarning($"[InventoryData] UpdateItem: Invalid coordinates ({x},{y}) for {_width}x{_height} grid");
                return;
            }

            if (quantity <= 0)
            {
                Debug.LogWarning($"[InventoryData] UpdateItem: Invalid quantity {quantity} for {instanceID}");
                return;
            }

            EnsureIndexMap();

            if (!_idToIndexMap.TryGetValue(instanceID, out int index) || index >= _items.Count)
            {
                Debug.LogWarning($"[InventoryData] UpdateItem: InstanceID {instanceID} not found.");
                return;
            }

            var item = _items[index];
            item.X = x;
            item.Y = y;
            item.Quantity = quantity;
            item.IsRotated = isRotated;
            _items[index] = item;

            MarkDirty();
        }

        public void FillInstanceIDs(List<uint> results)
        {
            if (results == null) return;
            results.Clear();
            foreach (var item in _items) results.Add(item.InstanceID);
        }

        public void Save(BinaryWriter writer)
        {
            writer.Write(_width);
            writer.Write(_height);
            writer.Write(_items.Count);

            foreach (var item in _items)
            {
                writer.Write(item.ItemID);
                writer.Write(item.InstanceID);
                writer.Write(item.X);
                writer.Write(item.Y);
                writer.Write(item.Quantity);
                writer.Write(item.Durability);
                writer.Write(item.IsRotated);
            }
        }

        public void Load(BinaryReader reader)
        {
            int loadedWidth = reader.ReadInt32();
            int loadedHeight = reader.ReadInt32();

            const int MIN_GRID = 1, MAX_GRID = 20;
            _width = Mathf.Clamp(loadedWidth, MIN_GRID, MAX_GRID);
            _height = Mathf.Clamp(loadedHeight, MIN_GRID, MAX_GRID);

            if (loadedWidth != _width || loadedHeight != _height)
                Debug.LogWarning($"[InventoryData] Grid size clamped: {loadedWidth}x{loadedHeight} → {_width}x{_height}");

            int count = reader.ReadInt32();
            _items.Clear();

            for (int i = 0; i < count; i++)
            {
                var item = new SavedItem
                {
                    ItemID = reader.ReadString(),
                    InstanceID = reader.ReadUInt32(),
                    X = reader.ReadInt32(),
                    Y = reader.ReadInt32(),
                    Quantity = Mathf.Max(1, reader.ReadInt32()),
                    Durability = Mathf.Max(0, reader.ReadInt32()),
                    IsRotated = reader.ReadBoolean()
                };

                if (item.X < 0 || item.Y < 0 || item.X >= _width || item.Y >= _height)
                {
                    Debug.LogError($"[InventoryData] CRITICAL: Item {item.InstanceID} ({item.ItemID}) has invalid position ({item.X},{item.Y}) in {_width}x{_height} grid. Resetting to (0,0)");
                    item.X = 0;
                    item.Y = 0;
                }

                _items.Add(item);
            }

            _isIndexMapValid = false;
            _isModified = false;
        }
    }
}