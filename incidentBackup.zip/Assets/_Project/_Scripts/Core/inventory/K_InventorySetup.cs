﻿using K_Incident.Core;
using K_Incident.Core.Inventory;
using System;
using UnityEngine;

namespace K_Incident.Core
{
    public class K_InventorySetup : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private ItemDatabase _database;
        [SerializeField] private InventoryData _initialData;

        private InventoryController _controller;

        public static ItemDatabase DatabaseInstance { get; private set; }
        public static bool IsInitialized { get; private set; } = false;

        public InventoryController Controller => _controller;

        private void Awake()
        {
            if (_database == null)
            {
                Debug.LogError("[InventorySetup] CRITICAL: ItemDatabase NOT assigned in Inspector!");
                Debug.LogError("[InventorySetup] Please create ItemDatabase asset and assign it to the Database field.");
                Debug.LogError("[InventorySetup] GameObject: " + gameObject.name);
                enabled = false;
                return;
            }

            uint globalMaxId = FindGlobalMaxInstanceId();
            GlobalIDManager.InitWithMaxId(globalMaxId);

            DatabaseInstance = _database;
            _database.Initialize();

            _controller = new InventoryController(
                _initialData != null ? _initialData : new InventoryData(8, 10),
                _database
            );

            _controller.OnInventoryChanged += OnInventoryUpdated;
            _controller.OnWeightChanged += OnWeightUpdated;

            IsInitialized = true;
            Debug.Log($"[InventorySetup] ✅ Successfully initialized. Database: {_database.name}");
        }

        private void Start()
        {
            if (!IsInitialized)
            {
                Debug.LogError("[InventorySetup] Start() called but IsInitialized = false! Check Awake() errors.");
                return;
            }

            K_SaveManager.Instance?.Register(_controller);
            Debug.Log("[InventorySetup] Registered with SaveManager.");

            K_WeightManager weightManager = FindFirstObjectByType<K_WeightManager>();
            if (weightManager != null)
            {
                _controller.OnWeightChanged += weightManager.SetWeight;
                weightManager.SetWeight(_controller.CurrentWeightKg);
                Debug.Log("[InventorySetup] Connected to WeightManager.");
            }
            else
            {
                Debug.LogWarning("[InventorySetup] K_WeightManager not found! Movement speed will not be affected by weight.");
            }

            Debug.Log($"[InventorySetup] Initialized. Database loaded with items.");
        }

        private void OnInventoryUpdated()
        {
            Debug.Log($"[Inventory] Changed! Modified: {_controller.GetSaveData().IsModified}");
        }

        private void OnWeightUpdated(float kg)
        {
            Debug.Log($"[Inventory] Weight: {kg:F2} kg ({_controller.WeightRatio:P1})");
        }

        private uint FindGlobalMaxInstanceId()
        {
            uint maxId = 0;

            if (_initialData != null)
            {
                foreach (var item in _initialData.GetItems())
                {
                    if (item.InstanceID > maxId) maxId = item.InstanceID;
                }
            }

#if UNITY_EDITOR
            Debug.Assert(maxId < uint.MaxValue - 10000,
                "[InventorySetup] InstanceID pool exhausted! Implement full save scanning for production.");
#endif

            return maxId + 10000;
        }

        public static ItemDatabase GetDatabase()
        {
            if (!IsInitialized)
            {
                Debug.LogWarning("[InventorySetup] GetDatabase() called before initialization!");
                return null;
            }
            return DatabaseInstance;
        }

        [ContextMenu("Print Grid")]
        private void PrintGrid()
        {
            if (_controller == null)
            {
                Debug.LogWarning("[InventorySetup] Controller not initialized!");
                return;
            }
            _controller.DebugPrintGrid();
        }

        [ContextMenu("Give 3 Coagulants")]
        private void GiveTestCoagulant()
        {
            if (_controller == null)
            {
                Debug.LogWarning("[InventorySetup] Controller not initialized!");
                return;
            }

            var data = GetDatabase()?.GetItemData("Med_Coagulant");
            if (data == null)
            {
                Debug.LogError("[InventorySetup] Item 'Med_Coagulant' not found in database!");
                return;
            }
            var item = new InventoryItem(data, GlobalIDManager.GenerateID(), 3, 100, false);
            int remainder = _controller.TryPlaceItem(item, 0, 0);
            Debug.Log(remainder == 0
                ? "[InventorySetup] Placed 3 Coagulants successfully."
                : $"[InventorySetup] Remainder: {remainder}");
        }

        [ContextMenu("Clear Inventory")]
        private void ClearInventory()
        {
            if (_controller == null)
            {
                Debug.LogWarning("[InventorySetup] Controller not initialized!");
                return;
            }
            _controller.Clear();
            Debug.Log("[InventorySetup] Inventory cleared.");
        }

        private void OnDestroy()
        {
            if (_controller != null)
            {
                _controller.OnInventoryChanged -= OnInventoryUpdated;
                _controller.OnWeightChanged -= OnWeightUpdated;
                _controller.Dispose();
            }
            IsInitialized = false;
        }
    }
}