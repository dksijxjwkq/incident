﻿
using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// UI контроллер инвентаря. Управляет пулом, троттлингом, Drag&Drop и сеткой 80×80.
    /// </summary>
    [RequireComponent(typeof(CanvasGroup))]
    public class K_InventoryUI : MonoBehaviour
    {
        #region Inspector Fields
        [Header("Grid Config")]
        [SerializeField, Tooltip("Размер слота в пикселях (ТЗ: 80×80)")] private float _slotSize = 80f;
        [SerializeField, Tooltip("Отступ между слотами")] private float _slotSpacing = -16f;
        [SerializeField] private KeyCode _rotateKey = KeyCode.R;
        [SerializeField] private KeyCode _openCloseKey = KeyCode.Tab;

        [Header("References")]
        [SerializeField] private K_InventorySetup _inventorySetup;
        [SerializeField] private TextMeshProUGUI _weightText;
        [SerializeField] private GameObject _slotPrefab;
        [SerializeField] private GameObject _uiItemPrefab;
        [SerializeField] private GameObject _dragGhostPrefab;

        [Header("Player Inventory (LEFT PANE)")]
        [SerializeField] private Transform _pocketsGrid;
        [SerializeField] private Transform _backpackGridParent;
        [SerializeField] private Transform _backpackGrid;
        [SerializeField] private GameObject _backpackPanel;
        [SerializeField] private Transform _pocketsItemsContainer;
        [SerializeField] private Transform _backpackItemsContainer;

        [Header("Equipment Slots")]
        [SerializeField] private K_EquipmentSlotUI _primarySlot1;
        [SerializeField] private K_EquipmentSlotUI _primarySlot2;
        [SerializeField] private K_EquipmentSlotUI _pistolSlot;
        [SerializeField] private K_EquipmentSlotUI _backpackSlot;

        [Header("Surroundings/Container (RIGHT PANE)")]
        [SerializeField] private GameObject _surroundingsPanel;
        [SerializeField] private Transform _surroundingsGrid;
        [SerializeField] private Transform _surroundingsItemsContainer;
        [SerializeField] private TextMeshProUGUI _containerNameText;

        [Header("UI Colors")]
        [SerializeField] private Color _dragValidColor = new Color(0.33f, 0.55f, 0.33f, 0.7f);
        [SerializeField] private Color _dragInvalidColor = new Color(0.71f, 0.24f, 0.24f, 0.7f);
        #endregion

        #region Constants
        private const int POCKET_COLS = 4, POCKET_ROWS = 2;
        private const int BACKPACK_COLS = 8, BACKPACK_ROWS = 10;
        private const int POOL_SIZE = 100;
        private const float THROTTLE_TIME = 0.3f;
        private const float SLOT_HIT_TOLERANCE = 0.05f;
        #endregion

        #region Fields
        private InventoryController _playerController;
        private InventoryController _containerController;
        private CanvasGroup _canvasGroup;
        private bool _isOpen, _isLooting, _isDragging, _pendingRefresh;
        private UI_Item _draggedItem;

        private readonly Queue<UI_Item> _itemPool = new();
        private readonly Dictionary<string, UI_Item> _activeItems = new();
        private readonly List<RaycastResult> _raycastBuffer = new List<RaycastResult>(8);
        private PointerEventData _cachedEventData;

        private Coroutine _refreshCoroutine;
        private GameObject _dragGhost;
        private Image _dragGhostImage;
        private Coroutine _flashCoroutine;

        private Action _onInventoryChangedHandler;
        private Action<float> _onWeightChangedHandler;
        private Action<InventoryItem, int, int> _onItemPlacedHandler;
        private Action<InventoryItem> _onItemChangedHandler;
        #endregion

        #region Properties
        public bool IsOpen() => _isOpen;
        public float GetSlotSize() => _slotSize;
        public float GetSlotSpacing() => _slotSpacing;
        #endregion

        #region Unity Lifecycle
        private void Awake()
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            PreWarmPool(POOL_SIZE);
            DisableLayoutOnContainers();

            if (_dragGhostPrefab != null)
            {
                _dragGhost = Instantiate(_dragGhostPrefab, transform);
                _dragGhost.SetActive(false);
                _dragGhostImage = _dragGhost.GetComponent<Image>();
                var layout = _dragGhost.GetComponent<LayoutElement>();
                if (layout == null) layout = _dragGhost.AddComponent<LayoutElement>();
                layout.ignoreLayout = true;
            }

            _cachedEventData = null;
        }

        private void Start()
        {
            if (_inventorySetup == null || _inventorySetup.Controller == null)
            {
                Debug.LogError("[InventoryUI] InventorySetup or Controller missing. Disabling.");
                enabled = false;
                return;
            }

            _playerController = _inventorySetup.Controller;

            BuildGrid(_pocketsGrid, POCKET_COLS * POCKET_ROWS, POCKET_COLS, GridType.Pockets);
            BuildGrid(_backpackGrid, BACKPACK_COLS * BACKPACK_ROWS, BACKPACK_COLS, GridType.Backpack);

            SubscribeToEvents();
            UpdateWeightDisplay(_playerController.CurrentWeightKg);

            CloseInventory();

            if (_backpackPanel != null)
                _backpackPanel.SetActive(false);

            if (_canvasGroup == null)
                _canvasGroup = GetComponent<CanvasGroup>();

            if (_canvasGroup != null)
            {
                _canvasGroup.alpha = 0f;
                _canvasGroup.interactable = false;
                _canvasGroup.blocksRaycasts = false;
                Debug.Log("[InventoryUI] Canvas Group forced hidden. Alpha = 0");
            }
            else
            {
                Debug.LogError("[InventoryUI] CanvasGroup component NOT FOUND! Add it to this GameObject!");
            }
        }

        private void Update()
        {
            if (Input.GetKeyDown(_openCloseKey)) ToggleInventory();

            if (_isDragging && Input.GetKeyDown(_rotateKey) && _draggedItem?.Item?.Data?.CanRotate == true)
                RotateDraggedItem();
        }

        private void OnDestroy()
        {
            UnsubscribeFromEvents();

            if (_refreshCoroutine != null) StopCoroutine(_refreshCoroutine);
            if (_flashCoroutine != null) StopCoroutine(_flashCoroutine);

            foreach (var item in _itemPool) if (item != null) Destroy(item.gameObject);
            _itemPool.Clear();
            _activeItems.Clear();

            if (_dragGhost != null) { Destroy(_dragGhost); _dragGhost = null; }
        }
        #endregion

        #region Pool Management
        private void PreWarmPool(int count)
        {
            for (int i = 0; i < count; i++)
            {
                var item = Instantiate(_uiItemPrefab, transform).GetComponent<UI_Item>();
                item.gameObject.SetActive(false);
                _itemPool.Enqueue(item);
            }
        }

        private UI_Item GetPooledItem() => _itemPool.Count > 0 ? _itemPool.Dequeue() : CreateNewPooledItem();

        private UI_Item CreateNewPooledItem()
        {
            var item = Instantiate(_uiItemPrefab, transform).GetComponent<UI_Item>();
            item.gameObject.SetActive(false);
            return item;
        }

        private void ReturnToPool(UI_Item item)
        {
            if (item == null) return;
            item.ResetState();
            item.transform.SetParent(transform, false);
            _itemPool.Enqueue(item);
        }

        private void ReturnAllItemsToPool()
        {
            foreach (var item in _activeItems.Values) ReturnToPool(item);
            _activeItems.Clear();
        }
        #endregion

        #region Grid Management
        private void DisableLayoutOnContainers()
        {
            foreach (var container in new[] { _pocketsItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer })
            {
                if (container == null) continue;

                var grid = container.GetComponent<GridLayoutGroup>();
                if (grid != null) grid.enabled = false;

                foreach (var graphic in container.GetComponents<Graphic>()) graphic.raycastTarget = false;
            }
        }

        private void BuildGrid(Transform parent, int slotCount, int columns, GridType gridType)
        {
            if (parent == null || _slotPrefab == null) return;

            ClearGrid(parent);
            SetupGridLayout(parent, columns);

            for (int i = 0; i < slotCount; i++)
            {
                var slot = Instantiate(_slotPrefab, parent);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null) slotUI.Setup(i % columns, i / columns, gridType, this);
            }

            LayoutRebuilder.ForceRebuildLayoutImmediate(parent.GetComponent<RectTransform>());
        }

        private void ClearGrid(Transform parent) { if (parent == null) return; for (int i = parent.childCount - 1; i >= 0; i--) Destroy(parent.GetChild(i).gameObject); }

        private void SetupGridLayout(Transform parent, int columns)
        {
            var grid = parent.GetComponent<GridLayoutGroup>() ?? parent.gameObject.AddComponent<GridLayoutGroup>();
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = columns;
            grid.cellSize = new Vector2(_slotSize, _slotSize);
            grid.spacing = new Vector2(_slotSpacing, _slotSpacing);
            grid.childAlignment = TextAnchor.UpperLeft;
        }
        #endregion

        #region UI Control
        public void ToggleInventory() { if (_isOpen) CloseInventory(); else OpenInventory(); }

        private void OpenInventory()
        {
            _isOpen = true;
            _isLooting = false;
            _containerController = null;

            if (_backpackPanel != null)
                _backpackPanel.SetActive(true);

            SetCanvasActive(true);

            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);

            RefreshAll();
        }

        public void CloseInventory()
        {
            if (_isDragging)
            {
                _isDragging = false;
                _draggedItem = null;
                if (_dragGhost != null) _dragGhost.SetActive(false);
            }

            _isOpen = false;
            _isLooting = false;

            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);

            if (_backpackPanel != null)
                _backpackPanel.SetActive(false);

            SetCanvasActive(false);
            ReturnAllItemsToPool();
        }

        private void SetCanvasActive(bool active)
        {
            if (_canvasGroup == null) return;
            _canvasGroup.alpha = active ? 1f : 0f;
            _canvasGroup.interactable = active;
            _canvasGroup.blocksRaycasts = active;
        }

        public void OpenContainer(InventoryController container, string name, int width, int height)
        {
            if (container == null) return;

            _containerController = container;
            _isLooting = true;
            _isOpen = true;

            SetCanvasActive(true);

            if (_surroundingsPanel != null)
            {
                _surroundingsPanel.SetActive(true);
                if (_containerNameText != null && !string.IsNullOrEmpty(name))
                    _containerNameText.text = name.ToUpper();

                RebuildSurroundingsGrid(width, height);
            }

            RefreshAll();
        }

        private void RebuildSurroundingsGrid(int width, int height)
        {
            if (_surroundingsGrid == null || _slotPrefab == null) return;

            ClearGrid(_surroundingsGrid);
            SetupGridLayout(_surroundingsGrid, width);

            if (_surroundingsPanel != null)
            {
                float totalWidth = width * _slotSize + (width - 1) * _slotSpacing + 16f;
                float totalHeight = height * _slotSize + (height - 1) * _slotSpacing + 16f;
                var rect = _surroundingsPanel.GetComponent<RectTransform>();
                if (rect != null) rect.sizeDelta = new Vector2(totalWidth, totalHeight);
            }

            int totalSlots = width * height;
            for (int i = 0; i < totalSlots; i++)
            {
                var slot = Instantiate(_slotPrefab, _surroundingsGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null) slotUI.Setup(i % width, i / width, GridType.Container, this);
            }

            LayoutRebuilder.ForceRebuildLayoutImmediate(_surroundingsGrid.GetComponent<RectTransform>());
        }
        #endregion

        #region Refresh System
        public void RefreshAll()
        {
            if (_pendingRefresh) return;

            _pendingRefresh = true;

            if (_refreshCoroutine != null) StopCoroutine(_refreshCoroutine);
            _refreshCoroutine = StartCoroutine(RefreshNextFrame());
        }

        private IEnumerator RefreshNextFrame()
        {
            yield return null;

            _pendingRefresh = false;

            ReturnAllItemsToPool();
            ForceRebuildLayouts();

            RefreshGrid(GridType.Pockets, POCKET_COLS, POCKET_ROWS, _pocketsItemsContainer);
            RefreshGrid(GridType.Backpack, BACKPACK_COLS, BACKPACK_ROWS, _backpackItemsContainer);

            if (_isLooting && _surroundingsGrid != null)
            {
                var grid = _surroundingsGrid.GetComponent<GridLayoutGroup>();
                RefreshGrid(GridType.Container, grid.constraintCount, _surroundingsGrid.childCount / grid.constraintCount, _surroundingsItemsContainer);
            }

            Canvas.ForceUpdateCanvases();
        }

        private void ForceRebuildLayouts()
        {
            foreach (var grid in new[] { _pocketsGrid, _backpackGrid, _surroundingsGrid })
                if (grid != null) LayoutRebuilder.ForceRebuildLayoutImmediate(grid.GetComponent<RectTransform>());
        }

        private void RefreshGrid(GridType type, int cols, int rows, Transform container)
        {
            var controller = type == GridType.Container ? _containerController : _playerController;
            if (controller == null) return;

            for (int y = 0; y < rows; y++)
                for (int x = 0; x < cols; x++)
                    RefreshSlot(type, x, y, controller, container);
        }

        private void RefreshSlot(GridType type, int x, int y, InventoryController controller, Transform container)
        {
            string key = $"{type}_{x}_{y}";
            var item = controller.GetItemAt(x, y);

            if (_activeItems.TryGetValue(key, out var uiItem))
            {
                if (item == null)
                {
                    ReturnToPool(uiItem);
                    _activeItems.Remove(key);
                }
                else
                {
                    uiItem.UpdateData(item);
                    uiItem.gameObject.SetActive(true);
                }
            }
            else if (item != null && controller.IsRootCell(item.InstanceID, x, y))
            {
                CreateUIItem(item, x, y, type, container);
            }
        }

        private void CreateUIItem(InventoryItem item, int x, int y, GridType type, Transform container)
        {
            if (container == null) return;

            string key = $"{type}_{x}_{y}";
            if (_activeItems.ContainsKey(key)) return;

            var uiItem = GetPooledItem();
            uiItem.transform.SetParent(container, false);
            uiItem.transform.SetAsLastSibling();

            var rect = uiItem.GetComponent<RectTransform>();
            if (rect != null)
            {
                rect.anchorMin = rect.anchorMax = new Vector2(0f, 1f);
                rect.pivot = new Vector2(0f, 1f);

                Vector2Int size = item.CurrentSize;
                rect.sizeDelta = new Vector2(
                    size.x * _slotSize + (size.x - 1) * _slotSpacing,
                    size.y * _slotSize + (size.y - 1) * _slotSpacing
                );

                rect.anchoredPosition = new Vector2(x * (_slotSize + _slotSpacing), -y * (_slotSize + _slotSpacing));
                rect.localScale = Vector3.one;
                rect.localRotation = Quaternion.identity;

#if UNITY_EDITOR
                Debug.Assert(x + size.x <= GetGridWidth(type),
                    $"Item {item.InstanceID} exceeds grid width at ({x},{y})");
                Debug.Assert(y + size.y <= GetGridHeight(type),
                    $"Item {item.InstanceID} exceeds grid height at ({x},{y})");
#endif
            }

            uiItem.gameObject.SetActive(true);
            uiItem.Setup(item, this, type, x, y);
            _activeItems[key] = uiItem;
        }
        #endregion

        #region Drag & Drop
        public void StartDrag(UI_Item draggedItem)
        {
            if (draggedItem == null || draggedItem.Item == null) return;

            _draggedItem = draggedItem;
            _isDragging = true;

            if (_dragGhost != null && _dragGhostImage != null && draggedItem.Item.Data?.Icon != null)
            {
                _dragGhostImage.sprite = draggedItem.Item.Data.Icon;
                _dragGhost.SetActive(true);
                _dragGhost.transform.SetAsLastSibling();
                UpdateGhostSize();
                _dragGhost.transform.position = Input.mousePosition;
            }
        }

        private void RotateDraggedItem()
        {
            if (_draggedItem == null || !_draggedItem.Item.Data.CanRotate) return;

            _draggedItem.Item.Rotate();
            _draggedItem.UpdateVisuals();
            UpdateGhostSize();
        }

        private void UpdateGhostSize()
        {
            if (_draggedItem == null || _dragGhostImage == null) return;

            Vector2Int size = _draggedItem.Item.CurrentSize;
            float w = size.x * _slotSize + (size.x - 1) * _slotSpacing;
            float h = size.y * _slotSize + (size.y - 1) * _slotSpacing;

            _dragGhostImage.rectTransform.sizeDelta = new Vector2(w, h);
            _dragGhostImage.rectTransform.localRotation = Quaternion.Euler(0, 0, -_draggedItem.Item.RotationAngle);
        }

        private void UpdateDragGhost()
        {
            if (!_isDragging || _dragGhost == null || !_dragGhost.activeSelf) return;

            _dragGhost.transform.position = Input.mousePosition;
            UpdateGhostColor();
        }

        private void UpdateGhostColor()
        {
            if (_dragGhostImage == null || _draggedItem?.Item == null) return;
            if (EventSystem.current == null) return;

            if (_cachedEventData == null)
                _cachedEventData = new PointerEventData(EventSystem.current);

            _cachedEventData.position = Input.mousePosition;

            _raycastBuffer.Clear();
            EventSystem.current.RaycastAll(_cachedEventData, _raycastBuffer);

            Color targetColor = _dragInvalidColor;

            foreach (var result in _raycastBuffer)
            {
                var slot = result.gameObject.GetComponent<K_InventorySlotUI>();
                if (slot != null)
                {
                    Vector2Int itemSize = _draggedItem.Item.CurrentSize;
                    int gridWidth = GetGridWidth(slot.GridType);
                    int gridHeight = GetGridHeight(slot.GridType);

                    bool logicallyOutOfBounds = slot.X < 0 || slot.Y < 0 ||
                                                slot.X + itemSize.x > gridWidth ||
                                                slot.Y + itemSize.y > gridHeight;

                    if (logicallyOutOfBounds)
                    {
                        _dragGhostImage.color = _dragInvalidColor;
                        return;
                    }

                    float tolerance = SLOT_HIT_TOLERANCE * _slotSize;
                    bool visuallyOutOfBounds = slot.X < -tolerance || slot.Y < -tolerance ||
                                               slot.X + itemSize.x > gridWidth + tolerance ||
                                               slot.Y + itemSize.y > gridHeight + tolerance;

                    InventoryController controller = GetControllerForGrid(slot.GridType);
                    if (controller != null && controller.CanPlaceItem(_draggedItem.Item, slot.X, slot.Y))
                    {
                        if (visuallyOutOfBounds)
                        {
                            _dragGhostImage.color = Color.Lerp(_dragInvalidColor, _dragValidColor, 0.5f);
                        }
                        else
                        {
                            _dragGhostImage.color = _dragValidColor;
                        }
                    }
                    else
                    {
                        _dragGhostImage.color = _dragInvalidColor;
                    }

                    break;
                }

                var equipSlot = result.gameObject.GetComponent<K_EquipmentSlotUI>();
                if (equipSlot != null) { if (ValidateEquipItem(_draggedItem.Item, equipSlot)) targetColor = _dragValidColor; break; }
            }

            _dragGhostImage.color = targetColor;
        }

        public int GetGridWidth(GridType gridType)
        {
            var controller = GetControllerForGrid(gridType);

            if (gridType == GridType.Pockets) return POCKET_COLS;

            if (controller == null)
            {
#if UNITY_EDITOR
                Debug.LogWarning($"[InventoryUI] Controller not found for grid type {gridType}");
#endif
                return gridType == GridType.Backpack ? BACKPACK_COLS : 6;
            }

            return controller.GetSaveData().Width;
        }

        public int GetGridHeight(GridType gridType)
        {
            var controller = GetControllerForGrid(gridType);

            if (gridType == GridType.Pockets) return POCKET_ROWS;

            if (controller == null)
            {
#if UNITY_EDITOR
                Debug.LogWarning($"[InventoryUI] Controller not found for grid type {gridType}");
#endif
                return gridType == GridType.Backpack ? BACKPACK_ROWS : 8;
            }

            return controller.GetSaveData().Height;
        }

        private IEnumerator FlashSlotVisual(GridType type, int x, int y, Vector2Int size)
        {
            var flashedItems = new List<Image>();

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    var key = $"{type}_{x + dx}_{y + dy}";
                    if (_activeItems.TryGetValue(key, out var uiItem))
                    {
                        var img = uiItem.GetComponent<Image>();
                        if (img != null)
                        {
                            flashedItems.Add(img);
                            img.color = Color.green;
                        }
                    }
                }
            }

            yield return new WaitForSeconds(0.1f);

            foreach (var img in flashedItems)
            {
                if (img != null && img.gameObject.activeInHierarchy)
                {
                    img.color = Color.white;
                }
            }
        }

        private void FlashSlotVisualSafe(GridType type, int x, int y, Vector2Int size)
        {
            if (_flashCoroutine != null) StopCoroutine(_flashCoroutine);
            _flashCoroutine = StartCoroutine(FlashSlotVisual(type, x, y, size));
        }

        public bool TryPlaceItem(UI_Item draggedItem, GridType targetGrid, int targetX, int targetY)
        {
            if (draggedItem == null || draggedItem.Item == null) return false;

            InventoryItem item = draggedItem.Item;
            InventoryController sourceController = GetControllerForGrid(draggedItem.GridType);
            InventoryController targetController = GetControllerForGrid(targetGrid);

            if (targetController == null) return false;

            if (sourceController == targetController && draggedItem.X == targetX && draggedItem.Y == targetY)
                return true;

            int originX = draggedItem.X;
            int originY = draggedItem.Y;

            if (sourceController?.RemoveItem(item) == false) return false;

            int placedCount = targetController.TryPlaceItem(item, targetX, targetY);
            bool success = placedCount > 0;

            if (!success && sourceController != null)
                sourceController.TryPlaceItem(item, originX, originY);

            if (success && targetController == _playerController)
            {
                FlashSlotVisualSafe(targetGrid, targetX, targetY, item.CurrentSize);
            }

            if (_dragGhostImage != null)
                _dragGhostImage.color = success ? _dragValidColor : _dragInvalidColor;

            return success;
        }

        public void ForceEndDrag(UI_Item item)
        {
            if (item == null) return;

            var eventSystem = EventSystem.current;
            var eventData = eventSystem != null ? new PointerEventData(eventSystem) : new PointerEventData(null);

            item.OnEndDrag(eventData);
            EndDragComplete();
        }

        public bool TryEquipItem(UI_Item draggedItem, K_EquipmentSlotUI slot)
        {
            if (draggedItem == null || draggedItem.Item == null || slot == null) return false;

            InventoryItem item = draggedItem.Item;

            if (!ValidateEquipItem(item, slot)) { ReturnToPool(draggedItem); return false; }

            InventoryController sourceController = GetControllerForGrid(draggedItem.GridType);
            if (sourceController == null) { ReturnToPool(draggedItem); return false; }

            if (sourceController.RemoveItem(item))
            {
                slot.OnDropItem(item);
                draggedItem.gameObject.SetActive(false);
                ReturnToPool(draggedItem);
                return true;
            }

            ReturnToPool(draggedItem); return false;
        }

        /// <summary>
        /// Обработка дропа в слот экипировки (вызывается из K_EquipmentSlotUI.OnDrop).
        /// Валидация и визуальный фидбек инкапсулированы внутри слота.
        /// </summary>
        public void OnEquipmentSlotDrop(K_EquipmentSlotUI slot, PointerEventData eventData)
        {
            if (slot == null || eventData == null || eventData.pointerDrag == null) return;

            var draggedUI = eventData.pointerDrag.GetComponent<UI_Item>();
            if (draggedUI == null || draggedUI.Item == null) return;

            InventoryItem item = draggedUI.Item;

            // Валидация уже происходит внутри slot.OnDropItem(), поэтому просто передаём предмет
            InventoryController sourceController = GetControllerForGrid(draggedUI.GridType);
            if (sourceController == null) return;

            if (!sourceController.RemoveItem(item)) return;

            slot.OnDropItem(item);

            draggedUI.gameObject.SetActive(false);
            ReturnToPool(draggedUI);

            MarkForRefresh();
        }

        public void EndDragComplete()
        {
            _isDragging = false;
            _draggedItem = null;

            if (_dragGhost != null) _dragGhost.SetActive(false);

            MarkForRefresh();
        }

        private bool ValidateEquipItem(InventoryItem item, K_EquipmentSlotUI slot)
        {
            if (item == null || item.Data == null) return false;

            EquipmentSlotType slotType = slot.SlotType;

            if (slotType == EquipmentSlotType.Backpack) return item.Data.IsBackpack;
            else
            {
                if (item.Type != ItemType.Weapon) return false;
                if (slotType == EquipmentSlotType.Pistol && !item.Data.IsPistol) return false;
            }

            return true;
        }

        private void MarkForRefresh() { if (!_pendingRefresh) { _pendingRefresh = true; StartCoroutine(RefreshNextFrame()); } }

        public InventoryController GetControllerForGrid(GridType gridType) =>
            gridType == GridType.Container ? _containerController : _playerController;

        public void OnBackpackUnequipped()
        {
            if (_backpackPanel != null)
                _backpackPanel.SetActive(false);

            RebuildBackpackGrid(8, 10);
        }

        private void RebuildBackpackGrid(int width, int height)
        {
            if (_backpackGrid == null || _slotPrefab == null) return;

            ClearGrid(_backpackGrid);
            SetupGridLayout(_backpackGrid, width);

            if (_backpackPanel != null)
            {
                float totalWidth = width * _slotSize + (width - 1) * _slotSpacing + 16f;
                float totalHeight = height * _slotSize + (height - 1) * _slotSpacing + 16f;
                var rect = _backpackPanel.GetComponent<RectTransform>();
                if (rect != null) rect.sizeDelta = new Vector2(totalWidth, totalHeight);
            }

            int totalSlots = width * height;
            for (int i = 0; i < totalSlots; i++)
            {
                var slot = Instantiate(_slotPrefab, _backpackGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null) slotUI.Setup(i % width, i / width, GridType.Backpack, this);
            }

            LayoutRebuilder.ForceRebuildLayoutImmediate(_backpackGrid.GetComponent<RectTransform>());
            RefreshAll();
        }
        #endregion

        #region Event Handling
        private void SubscribeToEvents()
        {
            if (_playerController == null) return;

            _onInventoryChangedHandler = RefreshAll;
            _onWeightChangedHandler = UpdateWeightDisplay;
            _onItemPlacedHandler = (item, x, y) => RefreshAll();
            _onItemChangedHandler = _ => RefreshAll();

            _playerController.OnInventoryChanged += _onInventoryChangedHandler;
            _playerController.OnWeightChanged += _onWeightChangedHandler;
            _playerController.OnItemPlaced += _onItemPlacedHandler;
            _playerController.OnItemRemoved += _onItemChangedHandler;
            _playerController.OnItemRotated += _onItemChangedHandler;
            _playerController.OnItemQuantityChanged += _onItemChangedHandler;
        }

        private void UnsubscribeFromEvents()
        {
            if (_playerController == null) return;

            _playerController.OnInventoryChanged -= _onInventoryChangedHandler;
            _playerController.OnWeightChanged -= _onWeightChangedHandler;
            _playerController.OnItemPlaced -= _onItemPlacedHandler;
            _playerController.OnItemRemoved -= _onItemChangedHandler;
            _playerController.OnItemRotated -= _onItemChangedHandler;
            _playerController.OnItemQuantityChanged -= _onItemChangedHandler;
        }

        private void UpdateWeightDisplay(float kg)
        {
            if (_weightText == null || _playerController == null) return;

            float ratio = _playerController.WeightRatio;
            Color color = ratio > 1.1f ? Color.red : ratio > 0.9f ? Color.yellow : Color.white;
            float maxKg = _playerController.MaxCapacityGrams / 1000f;

            _weightText.text = $"<color=#{ColorUtility.ToHtmlStringRGB(color)}>{kg:F1} / {maxKg:F0} kg</color>";
        }
        #endregion
    }
}