using UnityEngine;

namespace K_Incident.Core.Inventory
{
    [CreateAssetMenu(fileName = "New_Item", menuName = "Incident/Inventory/Item Data", order = 1)]
    public class ItemStaticData : ScriptableObject
    {
        [Header("Identification")]
        [SerializeField] private string _itemID;
        [SerializeField] private ushort _prefabID;
        [SerializeField] private string _displayName;
        [SerializeField] private string _description;

        [Header("Physical Properties")]
        [SerializeField] private Vector2Int _size = new Vector2Int(1, 1);
        [SerializeField] private int _weightGrams = 500;
        [SerializeField] private int _hardStackLimit = 1;
        [SerializeField] private int _maxDurability = 100;

        [Header("Visual")]
        [SerializeField] private Sprite _icon;
        [SerializeField] private GameObject _prefab;

        [Header("Classification")]
        [SerializeField] private ItemType _type;
        [SerializeField] private bool _canRotate = true;

        [Header("Backpack Specific")]
        [SerializeField] private Vector2Int _backpackGridSize = Vector2Int.zero;

        [Header("Weapon Specific")]
        [SerializeField] private bool _isPistol = false;

        public string ItemID => _itemID;
        public ushort PrefabID => _prefabID;
        public string DisplayName => _displayName;
        public string Description => _description;
        public Vector2Int Size => _size;
        public int WeightGrams => _weightGrams;
        public int HardStackLimit => _hardStackLimit;
        public int MaxDurability => _maxDurability;
        public Sprite Icon => _icon;
        public GameObject Prefab => _prefab;
        public ItemType Type => _type;
        public bool CanRotate => _canRotate;
        public bool IsBackpack => _type == ItemType.Backpack || (_backpackGridSize.x > 0 && _backpackGridSize.y > 0);
        public bool IsPistol => _isPistol;

        public Vector2Int GetDimensions(bool isRotated)
        {
            return (isRotated && _canRotate) ? new Vector2Int(_size.y, _size.x) : _size;
        }

        private void OnValidate()
        {
            _weightGrams = Mathf.Max(0, _weightGrams);
            _hardStackLimit = Mathf.Max(1, _hardStackLimit);
            _size.x = Mathf.Max(1, _size.x);
            _size.y = Mathf.Max(1, _size.y);
            _maxDurability = Mathf.Max(0, _maxDurability);
        }
    }

    public enum ItemType
    {
        Misc = 0,
        Weapon = 1,
        Ammo = 2,
        Medical = 3,
        Consumable = 4,
        Clothing = 5,
        Backpack = 6,
        Currency = 7,
        Tool = 8,
        KeyItem = 9
    }
}