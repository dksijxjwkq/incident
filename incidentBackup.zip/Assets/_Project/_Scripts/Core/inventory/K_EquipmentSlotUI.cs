﻿using K_Incident.Core.Inventory;
using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Типы слотов экипировки.
    /// Используется для валидации размещения предметов в слотах экипировки.
    /// </summary>
    public enum EquipmentSlotType { Primary, Pistol, Backpack }

    /// <summary>
    /// UI слота экипировки.
    /// Поддерживает: снятие по ПКМ, валидацию типа предмета, Drag&Drop фидбек, троттлинг событий.
    /// Архитектура визуала: 
    /// - _icon: отвечает ТОЛЬКО за отображение иконки экипированного предмета
    /// - _label: текст подписи слота (показывается когда слот пуст)
    /// - _highlight: визуальный оверлей для валидации дропа (зелёный/красный)
    /// - Фон/рамка настраиваются отдельно в префабе (единая текстура)
    /// 
    /// 🔑 ВАЖНО: Когда слот пуст, _icon.enabled = false — это убирает белый квадрат-заглушку Unity.
    /// </summary>
    public class K_EquipmentSlotUI : MonoBehaviour,
        IPointerClickHandler,
        IPointerEnterHandler,
        IPointerExitHandler,
        IDropHandler
    {
        // ✅ Constants — выносим магические числа (ТЗ: "Никаких магических чисел")
        private const float FLASH_ERROR_DURATION = 0.15f;
        private const float HOVER_THROTTLE = 0.2f;
        private const float DROP_FEEDBACK_DURATION = 0.1f;

        // Цвета визуального фидбека (тактическая палитра)
        private static readonly Color COLOR_VALID_DROP = new Color(0.2f, 0.8f, 0.2f, 0.6f);
        private static readonly Color COLOR_INVALID_DROP = new Color(0.9f, 0.2f, 0.2f, 0.6f);
        private static readonly Color COLOR_HOVER = new Color(1f, 1f, 1f, 0.15f);

        // Размеры слотов (в пикселях) — настраиваются под визуальные требования
        private static readonly Vector2 SIZE_PRIMARY = new Vector2(130f, 315f);
        private static readonly Vector2 SIZE_PISTOL = new Vector2(120f, 120f);
        private static readonly Vector2 SIZE_BACKPACK = new Vector2(100f, 100f);

        [SerializeField] private Image _icon;
        [SerializeField] private TextMeshProUGUI _label;
        [SerializeField] private Image _highlight;
        [SerializeField, Tooltip("Тип слота: Primary (основное оружие), Pistol (пистолет), Backpack (рюкзак)")]
        private EquipmentSlotType _slotType;
        [SerializeField, Tooltip("Если нет места в инвентаре при снятии — попытаться вернуть предмет в инвентарь.")]
        private bool _spawnOnGroundIfNoSpace;
        [SerializeField] private string _interactableLayer = "Interactable";

        // ✅ События для троттлинга (ТЗ: "Обновление UI через события с троттлингом 0.2-0.5с")
        public event Action<K_EquipmentSlotUI, bool> OnHoverChanged;
        public event Action<K_EquipmentSlotUI, InventoryItem> OnValidDropPreview;
        public event Action<K_EquipmentSlotUI> OnDropAccepted;

        private K_InventoryUI _inventoryUI;
        private InventoryItem _equippedItem;
        private RectTransform _rectTransform;
        private Coroutine _hoverThrottleCoroutine;
        private Coroutine _flashErrorCoroutine;
        private Coroutine _dropFeedbackCoroutine;

        private bool _isHovering;
        private bool _isDraggingOver;

        public EquipmentSlotType SlotType => _slotType;
        public bool IsOccupied => _equippedItem != null;
        public InventoryItem EquippedItem => _equippedItem;

        private void Awake()
        {
            _rectTransform = GetComponent<RectTransform>();

            // ✅ Инициализация оверлея (если назначен)
            if (_highlight != null)
            {
                _highlight.enabled = false;
                _highlight.raycastTarget = false;
                _highlight.color = Color.clear;
            }

            // ✅ Гарантия: скрываем _icon при старте, чтобы не было белого квадрата
            if (_icon != null)
                _icon.enabled = false;
        }

        /// <summary>
        /// Инициализация слота экипировки.
        /// Вызывается из K_InventoryUI при старте.
        /// </summary>
        /// <param name="inventoryUI">Ссылка на главный контроллер инвентаря.</param>
        /// <param name="slotType">Тип слота для валидации и настройки размера.</param>
        public void Initialize(K_InventoryUI inventoryUI, EquipmentSlotType slotType)
        {
            _inventoryUI = inventoryUI;
            _slotType = slotType;

            if (_rectTransform != null)
                _rectTransform.sizeDelta = GetSlotSize(slotType);

            UpdateLabelText();
            Refresh();
        }

        /// <summary>
        /// Возвращает размер слота для заданного типа.
        /// </summary>
        private static Vector2 GetSlotSize(EquipmentSlotType type) => type switch
        {
            EquipmentSlotType.Primary => SIZE_PRIMARY,
            EquipmentSlotType.Pistol => SIZE_PISTOL,
            EquipmentSlotType.Backpack => SIZE_BACKPACK,
            _ => SIZE_PISTOL
        };

        /// <summary>
        /// Обновляет текст подписи в зависимости от типа слота.
        /// </summary>
        private void UpdateLabelText()
        {
            if (_label == null) return;

            _label.text = _slotType switch
            {
                EquipmentSlotType.Primary => gameObject.name.Contains("1") ? "ОСНОВНОЕ 1" : "ОСНОВНОЕ 2",
                EquipmentSlotType.Pistol => "ПИСТОЛЕТ",
                EquipmentSlotType.Backpack => "РЮКЗАК",
                _ => string.Empty
            };
        }

        /// <summary>
        /// IPointerEnterHandler — вход курсора (с троттлингом событий).
        /// </summary>
        public void OnPointerEnter(PointerEventData eventData)
        {
            _isHovering = true;

            if (_hoverThrottleCoroutine == null)
                _hoverThrottleCoroutine = StartCoroutine(ThrottledHoverUpdate());

            if (_highlight != null && _highlight.enabled)
                _highlight.color = COLOR_HOVER;
        }

        /// <summary>
        /// IPointerExitHandler — выход курсора.
        /// </summary>
        public void OnPointerExit(PointerEventData eventData)
        {
            _isHovering = false;
            _isDraggingOver = false;

            if (_hoverThrottleCoroutine != null)
            {
                StopCoroutine(_hoverThrottleCoroutine);
                _hoverThrottleCoroutine = null;
            }

            if (_highlight != null && _highlight.enabled)
                _highlight.color = Color.clear;

            OnHoverChanged?.Invoke(this, false);
        }

        /// <summary>
        /// Троттлинг hover-событий (интервал 0.2с) для оптимизации.
        /// </summary>
        private IEnumerator ThrottledHoverUpdate()
        {
            yield return new WaitForSeconds(HOVER_THROTTLE);

            while (_isHovering)
            {
                OnHoverChanged?.Invoke(this, true);
                yield return new WaitForSeconds(HOVER_THROTTLE);
            }
            _hoverThrottleCoroutine = null;
        }

        /// <summary>
        /// IDropHandler — обработка дропа предмета в слот.
        /// Делегирует валидацию и логику в K_InventoryUI.OnEquipmentSlotDrop().
        /// </summary>
        public void OnDrop(PointerEventData eventData)
        {
            // ✅ Визуальный фидбек (пока предмет валидируется в контроллере)
            TriggerDropFeedback(true);

            // ✅ Сигнал главному контроллеру: "В меня дропнули предмет, разберись"
            _inventoryUI?.OnEquipmentSlotDrop(this, eventData);
        }

        /// <summary>
        /// Запускает визуальный фидбек при дропе (зелёный/красный оверлей).
        /// </summary>
        public void TriggerDropFeedback(bool isValid)
        {
            if (_highlight == null || !_highlight.enabled) return;

            if (_dropFeedbackCoroutine != null) StopCoroutine(_dropFeedbackCoroutine);
            _dropFeedbackCoroutine = StartCoroutine(FlashDropFeedback(isValid ? COLOR_VALID_DROP : COLOR_INVALID_DROP));
        }

        private IEnumerator FlashDropFeedback(Color targetColor)
        {
            if (_highlight == null) yield break;

            var originalColor = _highlight.color;
            _highlight.color = targetColor;

            yield return new WaitForSeconds(DROP_FEEDBACK_DURATION);

            if (_highlight != null)
                _highlight.color = _isHovering ? COLOR_HOVER : Color.clear;

            _dropFeedbackCoroutine = null;
        }

        /// <summary>
        /// IPointerClickHandler — обработка клика ПКМ для снятия предмета.
        /// </summary>
        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Right) return;
            if (_equippedItem == null) return;
            Unequip();
        }

        /// <summary>
        /// Снимает предмет со слота и возвращает в инвентарь.
        /// </summary>
        public void Unequip()
        {
            if (_equippedItem == null) return;

            if (_inventoryUI == null)
            {
                Debug.LogWarning("[EquipmentSlot] inventoryUI is null — cannot unequip");
                return;
            }

            InventoryController playerController = _inventoryUI.GetControllerForGrid(GridType.Pockets);
            if (playerController != null)
            {
                if (!playerController.TryPlaceItemInFirstFreeSlot(_equippedItem))
                {
                    if (_spawnOnGroundIfNoSpace)
                    {
                        SpawnItemOnGround(_equippedItem);
                    }
                    else
                    {
                        if (_flashErrorCoroutine != null) StopCoroutine(_flashErrorCoroutine);
                        _flashErrorCoroutine = StartCoroutine(FlashSlotError());

                        Debug.LogWarning("[EquipmentSlot] No space in inventory! Item NOT unequipped.");
                        return;
                    }
                }
            }

            if (_slotType == EquipmentSlotType.Backpack)
                _inventoryUI.OnBackpackUnequipped();

            _equippedItem = null;
            Refresh();
        }

        /// <summary>
        /// Визуальный фидбек при ошибке (красная вспышка иконки).
        /// </summary>
        private IEnumerator FlashSlotError()
        {
            if (_icon == null) yield break;

            var originalColor = _icon.color;
            _icon.color = Color.red;

            yield return new WaitForSeconds(FLASH_ERROR_DURATION);

            if (_icon != null && _icon.gameObject.activeInHierarchy)
                _icon.color = originalColor;
        }

        /// <summary>
        /// Минимальная реализация спавна предмета на земле (прототип).
        /// </summary>
        private void SpawnItemOnGround(InventoryItem item)
        {
            if (item == null) return;

            Debug.LogWarning($"[EquipmentSlot] SpawnItemOnGround NOT IMPLEMENTED — returning {item.Data?.DisplayName ?? "Unknown"} to inventory");

            if (_inventoryUI != null)
            {
                var playerController = _inventoryUI.GetControllerForGrid(GridType.Pockets);
                if (playerController != null)
                {
                    bool placed = playerController.TryPlaceItemInFirstFreeSlot(item);
                    if (placed) return;
                }
            }

            Debug.LogError($"[EquipmentSlot] CRITICAL: Item {item.Data?.ItemID} could not be placed — ITEM LOST (prototype limitation)");
        }

        /// <summary>
        /// Вызывается из K_InventoryUI после успешной валидации предмета.
        /// Экипирует предмет и обновляет визуал.
        /// </summary>
        public void OnDropItem(InventoryItem item)
        {
#if UNITY_EDITOR
            Debug.Assert(item?.Data != null, $"[EquipmentSlot] OnDropItem called with invalid item data");
#endif
            if (!ValidateItemForSlot(item))
            {
                TriggerDropFeedback(false);
                return;
            }

            _equippedItem = item;
            Refresh();
            OnDropAccepted?.Invoke(this);
        }

        /// <summary>
        /// Валидация: подходит ли предмет для этого слота.
        /// Соответствует ТЗ: слоты оружия не входят в общую сетку.
        /// </summary>
        public bool ValidateItemForSlot(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;

            return _slotType switch
            {
                EquipmentSlotType.Primary or EquipmentSlotType.Pistol => item.Type == ItemType.Weapon,
                EquipmentSlotType.Backpack => item.Data.IsBackpack,
                _ => false
            };
        }

        /// <summary>
        /// Предварительная валидация для превью "призрака" при перетаскивании.
        /// </summary>
        public bool CanAcceptItemPreview(InventoryItem item)
        {
            if (IsOccupied) return false;
            return ValidateItemForSlot(item);
        }

        /// <summary>
        /// Обновление превью валидности (для "призрака" предмета).
        /// </summary>
        public void UpdateDropPreview(InventoryItem item, bool isValid)
        {
            if (_highlight == null || !_highlight.enabled) return;

            _isDraggingOver = true;
            _highlight.color = isValid ? COLOR_VALID_DROP : COLOR_INVALID_DROP;
            _highlight.enabled = true;

            OnValidDropPreview?.Invoke(this, isValid ? item : null);
        }

        /// <summary>
        /// Сброс превью (когда предмет убрали со слота).
        /// </summary>
        public void ClearDropPreview()
        {
            _isDraggingOver = false;
            if (_highlight != null && _highlight.enabled)
                _highlight.color = _isHovering ? COLOR_HOVER : Color.clear;
        }

        /// <summary>
        /// Обновляет визуал слота (иконка, текст, оверлей).
        /// 🔑 КЛЮЧЕВОЙ ФИКС: _icon.enabled = false когда слот пуст — убирает белый квадрат-заглушку Unity.
        /// </summary>
        public void Refresh()
        {
            if (_icon == null) return;

            bool hasItem = _equippedItem != null && _equippedItem.Data?.Icon != null;

            if (hasItem)
            {
                // ✅ Предмет экипирован: подставляем спрайт, включаем рендер, скрываем подпись
                _icon.sprite = _equippedItem.Data.Icon;
                _icon.enabled = true;
                _icon.color = Color.white; // ✅ Белый цвет не искажает арт предмета

                if (_label != null) _label.gameObject.SetActive(false);

                if (_highlight != null) _highlight.enabled = false;
            }
            else
            {
                // ✅ Слот пуст: очищаем спрайт, ОТКЛЮЧАЕМ рендер (убирает белый квад), показываем подпись
                _icon.sprite = null;
                _icon.enabled = false; // 🔪 КРИТИЧНО: отключает рендер UGUI-заглушки
                _icon.color = Color.white;

                if (_label != null) _label.gameObject.SetActive(true);

                if (_highlight != null)
                {
                    _highlight.enabled = _isHovering || _isDraggingOver;
                    _highlight.color = _isDraggingOver ? COLOR_VALID_DROP : (_isHovering ? COLOR_HOVER : Color.clear);
                }
            }
        }

        /// <summary>
        /// Публичный метод для внешней установки состояния (например, при загрузке сохранения).
        /// </summary>
        public void SetEquippedItem(InventoryItem item)
        {
            _equippedItem = item;
            Refresh();
        }

        /// <summary>
        /// Остановка корутин при уничтожении объекта (ТЗ: "Минимум логики в Update").
        /// </summary>
        private void OnDestroy()
        {
            if (_flashErrorCoroutine != null) StopCoroutine(_flashErrorCoroutine);
            if (_hoverThrottleCoroutine != null) StopCoroutine(_hoverThrottleCoroutine);
            if (_dropFeedbackCoroutine != null) StopCoroutine(_dropFeedbackCoroutine);
        }

#if UNITY_EDITOR
        /// <summary>
        /// Авто-поиск _highlight в редакторе для удобства.
        /// </summary>
        private void OnValidate()
        {
            if (_highlight == null)
                _highlight = transform.Find("Highlight")?.GetComponent<Image>();
        }
#endif
    }
}