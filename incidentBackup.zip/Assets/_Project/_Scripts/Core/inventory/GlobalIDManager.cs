using System;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public static class GlobalIDManager
    {
        private static uint _nextID = 1;
        private static readonly object _lock = new object();
        private static bool _isInitialized = false;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void OnDomainReload()
        {
            lock (_lock)
            {
                _nextID = 1;
                _isInitialized = false;
            }
        }

        public static uint GenerateID()
        {
            lock (_lock)
            {
                if (!_isInitialized)
                {
                    _nextID = 1;
                    _isInitialized = true;
                }

                if (_nextID == uint.MaxValue)
                    throw new OverflowException("GlobalIDManager: uint.MaxValue reached");

                return _nextID++;
            }
        }

        public static void InitWithMaxId(uint maxKnownId)
        {
            lock (_lock)
            {
                if (maxKnownId >= _nextID)
                    _nextID = maxKnownId + 1;
                _isInitialized = true;
            }
        }

        public static void Reset()
        {
            lock (_lock)
            {
                _nextID = 1;
                _isInitialized = false;
            }
        }
    }
}