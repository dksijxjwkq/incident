﻿using K_Incident.Core;
using K_Incident.Core.Inventory;
using System;
using System.Collections;
using UnityEngine;

public class K_LootBox : MonoBehaviour, IInteractable
{
    [Header("Container Settings")]
    [SerializeField] private string _containerName = "Деревянный ящик";
    [SerializeField] private int _gridWidth = 6;
    [SerializeField] private int _gridHeight = 8;

    [SerializeField] private string _saveID;

    public enum AcousticType { Soft, Medium, Hard }
    [SerializeField] private AcousticType _acousticType = AcousticType.Medium;

    [SerializeField] private InventoryData _containerData;

    private InventoryController _containerController;
    private bool _isOpen;
    private bool _isDestroyed;
    private bool _wasOpenedBefore;
    private Coroutine _lootingCoroutine;
    private K_InventoryUI _cachedInventoryUI;
    private string _uniqueSaveID;

    private void Awake()
    {
        // ✅ ИСПРАВЛЕНИЕ БАГА №9: Стабильный ID через явные координаты
        if (string.IsNullOrWhiteSpace(_saveID))
        {
            string sceneName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
            Vector3 p = transform.position;
            _uniqueSaveID = $"LootBox_{sceneName}_{p.x:F1}_{p.y:F1}_{p.z:F1}";
        }
        else
        {
            _uniqueSaveID = _saveID;
        }

        if (_containerData == null)
            _containerData = new InventoryData(_gridWidth, _gridHeight);

        _cachedInventoryUI = FindFirstObjectByType<K_InventoryUI>();
        StartCoroutine(InitializeWithRetry());
    }

    private void OnEnable()
    {
        K_InventoryUI.OnContainerClosed -= HandleContainerClosed;
        K_InventoryUI.OnContainerClosed += HandleContainerClosed;
    }

    private void OnDisable()
    {
        K_InventoryUI.OnContainerClosed -= HandleContainerClosed;
    }

    private void OnDestroy()
    {
        _isDestroyed = true;
        K_InventoryUI.OnContainerClosed -= HandleContainerClosed;

        if (_lootingCoroutine != null)
        {
            StopCoroutine(_lootingCoroutine);
            _lootingCoroutine = null;
        }

        CleanupController();
    }

    private void HandleContainerClosed(InventoryController closedController)
    {
        if (closedController == _containerController)
        {
            _isOpen = false;
        }
    }

    private IEnumerator InitializeWithRetry()
    {
        int attempts = 0;
        int maxAttempts = 10;

        while (attempts < maxAttempts)
        {
            if (_isDestroyed) yield break;

            var database = K_InventorySetup.DatabaseInstance;

            if (database != null)
            {
                _containerController = new InventoryController(_containerData, database, _uniqueSaveID);
                K_SaveManager.Instance?.Register(_containerController);
                _containerController.IsDirty = false;
                yield break;
            }

            attempts++;
            yield return new WaitForSeconds(0.1f);
        }

        Debug.LogError($"[LootBox] {_uniqueSaveID}: Init FAILED");
    }

    private void CleanupController()
    {
        if (_containerController == null) return;
        K_SaveManager.Instance?.Unregister(_containerController);
        _containerController.Dispose();
        _containerController = null;
    }

    public void OnInteract()
    {
        if (_isOpen || _isDestroyed || _containerController == null)
            return;

        if (_wasOpenedBefore)
        {
            _isOpen = true;
            OpenUIInstant();
            return;
        }

        _lootingCoroutine = StartCoroutine(LootingProcess());
    }

    public string GetInteractionPrompt() => "";

    public string GetHoldPrompt()
    {
        if (_isOpen) return "";
        return $"[Удерживать E] Открыть {_containerName}";
    }

    public float GetHoldDuration()
    {
        if (_isOpen) return 0f;
        return _wasOpenedBefore ? 0f : 0.6f;
    }

    private IEnumerator LootingProcess()
    {
        float timer = 0f;
        const float LOOT_DURATION = 0.6f;

        var playerMotor = FindFirstObjectByType<K_PlayerMotor>();
        var healthSystem = FindFirstObjectByType<K_HealthSystem>();

        while (timer < LOOT_DURATION)
        {
            if (_isDestroyed) yield break;

            if (healthSystem?.IsDead == true ||
                (playerMotor != null && playerMotor.CurrentVelocity.magnitude > 0.1f))
            {
                yield break;
            }

            timer += Time.deltaTime;
            yield return null;
        }

        if (!_isDestroyed)
        {
            EmitNoise();
            OpenUIInstant();
            _isOpen = true;
            _wasOpenedBefore = true;
            _containerController.IsDirty = true;
        }
    }

    private void OpenUIInstant()
    {
        if (_isDestroyed || _containerController == null) return;

        if (_cachedInventoryUI == null)
            _cachedInventoryUI = FindFirstObjectByType<K_InventoryUI>();

        if (_cachedInventoryUI != null)
        {
            _cachedInventoryUI.OpenContainer(_containerController, _containerName, _gridWidth, _gridHeight);
        }
    }

    private void EmitNoise()
    {
        if (_isDestroyed) return;

        float radius = _acousticType switch
        {
            AcousticType.Soft => 1.0f,
            AcousticType.Medium => 12.0f,
            AcousticType.Hard => 20.0f,
            _ => 12.0f
        };

        Debug.Log($"[LootBox] Noise emitted: {transform.position}, Radius: {radius}m, Type: {_acousticType}");
    }
}

public struct NoiseEvent
{
    public Vector3 Position;
    public float Intensity;
    public int Priority;
}