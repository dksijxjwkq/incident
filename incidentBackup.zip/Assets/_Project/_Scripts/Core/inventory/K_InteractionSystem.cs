﻿using UnityEngine;
using TMPro;
using System.Collections;

namespace K_Incident.Core
{
    public class K_InteractionSystem : MonoBehaviour
    {
        [Header("Interaction Settings")]
        [SerializeField, Tooltip("Радиус поиска интерактивных объектов от игрока (м)")]
        private float _interactionRange = 2.0f;

        [SerializeField, Tooltip("Клавиша взаимодействия")]
        private KeyCode _interactKey = KeyCode.E;

        [SerializeField, Tooltip("Слой, на котором находятся интерактивные объекты")]
        private LayerMask _interactableLayer;

        [Header("UI References")]
        [SerializeField] private TextMeshProUGUI _interactionPrompt;
        [SerializeField] private TextMeshProUGUI _holdProgressText;
        [SerializeField] private UnityEngine.Camera _playerCamera;

        private IInteractable _currentInteractable;
        private Transform _currentInteractableTransform;
        private Transform _playerTransform;

        // ✅ ИСПРАВЛЕНИЕ БАГА №6: Кэширование ссылки
        private K_InventoryUI _cachedInventoryUI;

        private bool _isHolding;
        private float _holdTimer;
        private Coroutine _holdCoroutine;
        private bool _isDestroyed;

        private void Awake()
        {
            _playerTransform = transform;
            _isDestroyed = false;

            // ✅ Кэшируем ссылку один раз
            _cachedInventoryUI = FindFirstObjectByType<K_InventoryUI>();

            if (_playerCamera == null)
                _playerCamera = UnityEngine.Camera.main;

            if (_interactionPrompt != null)
                _interactionPrompt.gameObject.SetActive(false);

            if (_holdProgressText != null)
                _holdProgressText.gameObject.SetActive(false);
        }

        private void Update()
        {
            if (IsInventoryOpen())
            {
                CancelHoldInteraction();
                HidePrompt();
                return;
            }

            CheckForNearbyInteractables();
            HandleHoldInput();
        }

        private void OnDestroy()
        {
            _isDestroyed = true;

            if (_holdCoroutine != null)
            {
                StopCoroutine(_holdCoroutine);
                _holdCoroutine = null;
            }

            _currentInteractable = null;
            _currentInteractableTransform = null;
        }

        private bool IsInventoryOpen()
        {
            // ✅ Ленивая инициализация на случай позднего спавна
            if (_cachedInventoryUI == null)
                _cachedInventoryUI = FindFirstObjectByType<K_InventoryUI>();
            return _cachedInventoryUI != null && _cachedInventoryUI.IsOpen();
        }

        private void CheckForNearbyInteractables()
        {
            Collider[] hits = Physics.OverlapSphere(
                _playerTransform.position,
                _interactionRange,
                _interactableLayer
            );

            if (hits.Length == 0)
            {
                ResetTarget();
                return;
            }

            IInteractable bestTarget = null;
            Transform bestTransform = null;
            float closestSqrDist = float.MaxValue;

            foreach (var hit in hits)
            {
                if (hit.TryGetComponent(out IInteractable interactable))
                {
                    float dist = Vector3.Distance(_playerTransform.position, hit.transform.position);
                    if (dist > _interactionRange) continue;

                    float sqrDist = dist * dist;
                    if (sqrDist < closestSqrDist)
                    {
                        closestSqrDist = sqrDist;
                        bestTarget = interactable;
                        bestTransform = hit.transform;
                    }
                }
            }

            if (bestTarget != null)
            {
                if (_currentInteractable != bestTarget)
                {
                    _currentInteractable = bestTarget;
                    _currentInteractableTransform = bestTransform;
                    ShowPrompt(_currentInteractable.GetHoldPrompt());
                }
            }
            else
            {
                ResetTarget();
            }
        }

        private void HandleHoldInput()
        {
            if (_currentInteractable == null) return;

            float requiredHold = _currentInteractable.GetHoldDuration();

            if (Input.GetKey(_interactKey) && !_isHolding && _holdCoroutine == null)
            {
                if (requiredHold <= 0f)
                {
                    CompleteHoldInteraction();
                }
                else
                {
                    _holdCoroutine = StartCoroutine(HoldRoutine(requiredHold));
                }
            }
            else if (!Input.GetKey(_interactKey) && _isHolding)
            {
                CancelHoldInteraction();
            }
        }

        private IEnumerator HoldRoutine(float duration)
        {
            _isHolding = true;
            _holdTimer = 0f;
            HidePrompt();
            ShowHoldProgress(0f);

            while (_holdTimer < duration)
            {
                if (_isDestroyed || _currentInteractable == null || _currentInteractableTransform == null)
                {
                    CancelHoldInteraction();
                    yield break;
                }

                float currentSqrDist = Vector3.SqrMagnitude(_playerTransform.position - _currentInteractableTransform.position);
                if (currentSqrDist > _interactionRange * _interactionRange)
                {
                    CancelHoldInteraction();
                    yield break;
                }

                _holdTimer += Time.deltaTime;
                ShowHoldProgress(_holdTimer / duration);
                yield return null;
            }

            CompleteHoldInteraction();
        }

        private void CompleteHoldInteraction()
        {
            _isHolding = false;
            _holdTimer = 0f;
            _holdCoroutine = null;

            HideHoldProgress();
            HidePrompt();

            _currentInteractable?.OnInteract();
            ResetTarget();
        }

        private void CancelHoldInteraction()
        {
            _isHolding = false;
            _holdTimer = 0f;

            if (_holdCoroutine != null)
            {
                StopCoroutine(_holdCoroutine);
                _holdCoroutine = null;
            }

            HideHoldProgress();
            if (_currentInteractable != null)
                ShowPrompt(_currentInteractable.GetHoldPrompt());
        }

        private void ResetTarget()
        {
            if (_currentInteractable != null)
            {
                CancelHoldInteraction();
                _currentInteractable = null;
                _currentInteractableTransform = null;
                HidePrompt();
            }
        }

        private void ShowPrompt(string text)
        {
            if (_interactionPrompt != null && !string.IsNullOrEmpty(text))
            {
                _interactionPrompt.text = text;
                _interactionPrompt.gameObject.SetActive(true);
            }
        }

        private void HidePrompt()
        {
            if (_interactionPrompt != null && _interactionPrompt.gameObject.activeSelf)
                _interactionPrompt.gameObject.SetActive(false);
        }

        private void ShowHoldProgress(float normalizedValue)
        {
            if (_holdProgressText != null)
            {
                _holdProgressText.text = $"{Mathf.RoundToInt(normalizedValue * 100)}%";
                if (!_holdProgressText.gameObject.activeSelf)
                    _holdProgressText.gameObject.SetActive(true);
            }
        }

        private void HideHoldProgress()
        {
            if (_holdProgressText != null && _holdProgressText.gameObject.activeSelf)
                _holdProgressText.gameObject.SetActive(false);
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(1f, 0.84f, 0f, 0.4f);
            Gizmos.DrawWireSphere(transform.position, _interactionRange);
        }
    }

    public interface IInteractable
    {
        void OnInteract();
        string GetInteractionPrompt();
        string GetHoldPrompt();
        float GetHoldDuration();
    }
}