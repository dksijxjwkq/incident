﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Ядро инвентаря. Управляет сеткой, весом, событиями и сериализацией.
    /// Все изменения транслируются через события (Action) для троттлинга в UI.
    /// </summary>
    public class InventoryController : IDisposable, ISaveable
    {
        #region Events & Constants
        public event Action OnInventoryChanged;
        public event Action<float> OnWeightChanged;
        public event Action<InventoryItem, int, int> OnItemPlaced;
        public event Action<InventoryItem> OnItemRemoved;
        public event Action<InventoryItem> OnItemRotated;
        public event Action<InventoryItem> OnItemQuantityChanged;

        private const int MAX_STACK_LIMIT = 90;
        private const int DEFAULT_MAX_CAPACITY_GRAMS = 30000;
        private const float GRAM_TO_KG = 0.001f;
        private const int MIN_GRID_INDEX = 0;
        #endregion

        #region Fields
        public string SaveID { get; private set; }
        public bool IsDirty { get; set; } = true;

        private InventoryData _data;
        private ItemDatabase _database;
        private InventoryItem[,] _grid;
        private readonly Dictionary<uint, InventoryItem> _itemCache = new();
        private readonly Dictionary<uint, (int x, int y)> _positionCache = new();
        private int _currentWeightGrams;
        private int _maxCapacityGrams = DEFAULT_MAX_CAPACITY_GRAMS;
        private bool _isDisposed;
        #endregion

        #region Properties
        public int Width => _data?.Width ?? 0;
        public int Height => _data?.Height ?? 0;
        public float CurrentWeightKg => _currentWeightGrams * GRAM_TO_KG;
        public float WeightRatio => _maxCapacityGrams > 0 ? _currentWeightGrams / (float)_maxCapacityGrams : 0f;

        // ✅ ИСПРАВЛЕНИЕ: Добавлено свойство MaxCapacityGrams
        public int MaxCapacityGrams => _maxCapacityGrams;
        #endregion

        #region Constructor
        public InventoryController(InventoryData data, ItemDatabase database, string saveID = null)
        {
            _data = data ?? throw new ArgumentNullException(nameof(data));
            _database = database ?? throw new ArgumentNullException(nameof(database));
            SaveID = saveID ?? $"Inv_{Guid.NewGuid():N}";
            InitializeGrid();
            LoadFromData();
        }

        private void InitializeGrid()
        {
            if (_data.Width <= 0 || _data.Height <= 0)
                throw new ArgumentException($"Invalid grid dimensions: {_data.Width}x{_data.Height}", nameof(_data));

            _grid = new InventoryItem[_data.Width, _data.Height];
            _currentWeightGrams = 0;
        }

        private void LoadFromData()
        {
            int skippedCount = 0;

            foreach (var saved in _data.GetItems())
            {
                var template = _database.GetItemData(saved.ItemID);
                if (template == null)
                {
                    LogWarning($"Template not found for ItemID: {saved.ItemID} (InstanceID: {saved.InstanceID})");
                    skippedCount++;
                    continue;
                }

                var item = InventoryItem.FromSaveData(saved, template);
                if (item == null)
                {
                    LogWarning($"Failed to create item from SavedData: {saved.ItemID}");
                    skippedCount++;
                    continue;
                }

                if (!CanPlaceInternal(item, saved.X, saved.Y, item.CurrentSize))
                {
                    LogWarning($"Cannot place item {saved.InstanceID} at ({saved.X},{saved.Y}) - bounds/collision conflict");
                    skippedCount++;
                    continue;
                }

                if (!BindToGrid(item, saved.X, saved.Y))
                {
                    LogWarning($"BindToGrid failed for item {saved.InstanceID} at ({saved.X},{saved.Y})");
                    skippedCount++;
                    continue;
                }
            }

            if (skippedCount > 0)
            {
                Debug.LogWarning($"[InventoryController] Load complete: {skippedCount} items skipped");
            }

            RecalculateWeight();
            _data.MarkClean();
            IsDirty = false;
        }
        #endregion

        #region Placement Logic
        public bool CanPlaceItem(InventoryItem item, int x, int y) =>
            item != null && item.Data != null && CanPlaceInternal(item, x, y, item.CurrentSize);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool IsValidCoordinate(int x, int y)
        {
            Debug.Assert(_data != null, "IsValidCoordinate called with null _data");
            return _data != null &&
                   x >= MIN_GRID_INDEX && y >= MIN_GRID_INDEX &&
                   x < _data.Width && y < _data.Height;
        }

        private bool CanPlaceInternal(InventoryItem item, int x, int y, Vector2Int size)
        {
            if (!IsValidCoordinate(x, y) || !IsValidCoordinate(x + size.x - 1, y + size.y - 1))
                return false;

            InventoryItem stackTarget = null;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    var existing = _grid[x + dx, y + dy];
                    if (existing == null || existing == item) continue;

                    if (!CanStack(existing, item)) return false;
                    if (stackTarget == null) stackTarget = existing;
                    else if (stackTarget.InstanceID != existing.InstanceID) return false;
                }
            }

            return true;
        }

        private bool CanPlaceInternalEmptyOnly(int x, int y, Vector2Int size)
        {
            if (!IsValidCoordinate(x, y) || !IsValidCoordinate(x + size.x - 1, y + size.y - 1))
                return false;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    if (_grid[x + dx, y + dy] != null)
                        return false;
                }
            }

            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool CanStack(InventoryItem target, InventoryItem source) =>
            target.PrefabID == source.PrefabID && target.Quantity < MAX_STACK_LIMIT;

        public int TryPlaceItem(InventoryItem source, int x, int y)
        {
            if (_isDisposed || source == null || source.Data == null || source.Quantity <= 0) return 0;
            if (!CanPlaceInternal(source, x, y, source.CurrentSize)) return 0;

            int remainder = source.Quantity;
            int placedCount = 0;

            var targetStack = FindStackTarget(source, x, y);
            if (targetStack != null)
            {
                int space = MAX_STACK_LIMIT - targetStack.Quantity;
                int toAdd = Mathf.Min(space, remainder);

                targetStack.AddQuantity(toAdd);
                AdjustWeight(source.Data.WeightGrams * toAdd);

                remainder -= toAdd;
                placedCount += toAdd;

                if (_positionCache.TryGetValue(targetStack.InstanceID, out var pos))
                    _data.UpdateItem(targetStack.InstanceID, pos.x, pos.y, targetStack.Quantity, targetStack.IsRotated);

                OnItemQuantityChanged?.Invoke(targetStack);
            }

            if (remainder > 0)
            {
                var newItem = new InventoryItem(
                    source.Data, GlobalIDManager.GenerateID(), remainder, source.Durability, source.IsRotated);

                if (!BindToGrid(newItem, x, y))
                {
                    LogWarning($"Failed to bind new item {newItem.InstanceID} at ({x},{y})");
                    return placedCount;
                }

                _data.AddItem(newItem.ToSaveData(x, y));
                AdjustWeight(source.Data.WeightGrams * remainder);
                OnItemPlaced?.Invoke(newItem, x, y);
                placedCount += remainder;
            }

            if (placedCount > 0)
            {
                MarkDirty();
                OnInventoryChanged?.Invoke();
            }

            return placedCount;
        }

        private InventoryItem FindStackTarget(InventoryItem item, int x, int y)
        {
            var size = item.CurrentSize;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    var existing = _grid[x + dx, y + dy];
                    if (existing != null && existing != item && CanStack(existing, item))
                        return existing;
                }

            return null;
        }

        private bool BindToGrid(InventoryItem item, int x, int y)
        {
            if (_itemCache.ContainsKey(item.InstanceID))
            {
                LogWarning($"Duplicate InstanceID {item.InstanceID} — skipping bind at ({x},{y})");
                return false;
            }

            var size = item.CurrentSize;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    _grid[x + dx, y + dy] = item;

            _itemCache[item.InstanceID] = item;
            _positionCache[item.InstanceID] = (x, y);
            return true;
        }
        #endregion

        #region Rotation & Removal
        public bool RotateItem(InventoryItem item)
        {
            if (_isDisposed || item == null || !item.Data.CanRotate || !_positionCache.ContainsKey(item.InstanceID))
                return false;

            var pos = _positionCache[item.InstanceID];
            var testSize = item.Data.GetDimensions(!item.IsRotated);

            if (!CanPlaceInternal(item, pos.x, pos.y, testSize)) return false;

            var oldSize = item.CurrentSize;
            var oldAngle = item.RotationAngle;

            ClearCellRange(pos.x, pos.y, oldSize);
            item.Rotate();

            if (!BindToGrid(item, pos.x, pos.y))
            {
                item.RestoreRotationState(oldAngle);
                BindToGrid(item, pos.x, pos.y);
                LogWarning($"BindToGrid failed during rotation for item {item.InstanceID} — state restored");
                return false;
            }

            _data.UpdateItem(item.InstanceID, pos.x, pos.y, item.Quantity, item.IsRotated);
            MarkDirty();
            OnItemRotated?.Invoke(item);
            OnInventoryChanged?.Invoke();
            return true;
        }

        public bool RemoveItem(InventoryItem item)
        {
            if (_isDisposed || item == null || !_positionCache.ContainsKey(item.InstanceID)) return false;

            var pos = _positionCache[item.InstanceID];
            ClearCellRange(pos.x, pos.y, item.CurrentSize);

            _itemCache.Remove(item.InstanceID);
            _positionCache.Remove(item.InstanceID);
            _data.RemoveItem(item.InstanceID);

            AdjustWeight(-item.TotalWeightGrams);
            OnItemRemoved?.Invoke(item);
            MarkDirty();
            OnInventoryChanged?.Invoke();
            return true;
        }

        private void ClearCellRange(int x, int y, Vector2Int size)
        {
            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    int gx = x + dx, gy = y + dy;
                    if (IsValidCoordinate(gx, gy))
                        _grid[gx, gy] = null;
                }
            }
        }
        #endregion

        #region Weight & Helpers
        public void AdjustWeight(int deltaGrams)
        {
            int oldWeight = _currentWeightGrams;
            _currentWeightGrams = Mathf.Max(0, _currentWeightGrams + deltaGrams);

            if (_currentWeightGrams != oldWeight)
                MarkDirty();

            OnWeightChanged?.Invoke(CurrentWeightKg);
        }

        private void RecalculateWeight()
        {
            int sum = 0;
            foreach (var item in _itemCache.Values) sum += item.TotalWeightGrams;
            _currentWeightGrams = sum;
            OnWeightChanged?.Invoke(CurrentWeightKg);
        }

        public InventoryItem GetItemAt(int x, int y)
        {
            if (_isDisposed || _data == null || _grid == null) return null;
            if (!IsValidCoordinate(x, y)) return null;
            return _grid[x, y];
        }

        public bool IsRootCell(uint id, int x, int y) =>
            _positionCache.TryGetValue(id, out var pos) && pos.x == x && pos.y == y;

        private void MarkDirty() => IsDirty = true;

        private void LogWarning(string message, [CallerMemberName] string method = "")
        {
            Debug.LogWarning($"[InventoryController.{method}] {message}");
        }
        #endregion

        #region UI Helper Methods
        public int GetItemCount() => _itemCache.Count;

        public bool CanFitItem(Vector2Int size)
        {
            if (size.x > _data.Width || size.y > _data.Height) return false;

            for (int x = 0; x <= _data.Width - size.x; x++)
                for (int y = 0; y <= _data.Height - size.y; y++)
                    if (CanPlaceInternalEmptyOnly(x, y, size))
                        return true;

            return false;
        }

        public int GetFreeCellCount()
        {
            int count = 0;
            for (int x = 0; x < _data.Width; x++)
                for (int y = 0; y < _data.Height; y++)
                    if (_grid[x, y] == null) count++;

            return count;
        }

        // ✅ ИСПРАВЛЕНИЕ: Добавлен метод для авто-размещения предмета в первой свободной ячейке
        public bool TryPlaceItemInFirstFreeSlot(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;

            Vector2Int size = item.CurrentSize;

            // Ищем первую свободную позицию, перебирая сетку слева-направо, сверху-вниз
            for (int y = 0; y < _data.Height; y++)
            {
                for (int x = 0; x < _data.Width; x++)
                {
                    if (CanPlaceItem(item, x, y))
                    {
                        return TryPlaceItem(item, x, y) > 0;
                    }
                }
            }

            return false;
        }

        public InventoryData GetSaveData() => _data;

        public void Clear()
        {
            if (_grid != null)
            {
                Array.Clear(_grid, 0, _grid.Length);
                _grid = new InventoryItem[_data.Width, _data.Height];
            }

            _itemCache.Clear();
            _positionCache.Clear();
            _currentWeightGrams = 0;
            _data.Clear();

            MarkDirty();
            OnInventoryChanged?.Invoke();
        }
        #endregion

        #region Serialization
        public void Save(BinaryWriter writer)
        {
            writer.Write(SaveID);
            writer.Write(IsDirty);
            _data.Save(writer);
        }

        public void Load(BinaryReader reader)
        {
            if (_isDisposed) return;

            SaveID = reader.ReadString();
            IsDirty = reader.ReadBoolean();

            var savedWidth = reader.ReadInt32();
            var savedHeight = reader.ReadInt32();

            if (savedWidth != _data.Width || savedHeight != _data.Height)
            {
                Debug.LogWarning($"[InventoryController] Grid size mismatch: Saved {savedWidth}x{savedHeight} != Current {_data.Width}x{_data.Height}");
            }

            if (_grid != null)
            {
                Array.Clear(_grid, 0, _grid.Length);
                _grid = null;
            }

            _data.Load(reader);
            _grid = new InventoryItem[_data.Width, _data.Height];
            _itemCache.Clear();
            _positionCache.Clear();
            LoadFromData();
        }
        #endregion

        #region Disposable
        public void Dispose()
        {
            if (_isDisposed) return;

            _isDisposed = true;
            _itemCache.Clear();
            _positionCache.Clear();

            if (_grid != null)
            {
                Array.Clear(_grid, 0, _grid.Length);
                _grid = null;
            }

            _data = null;
            _database = null;

            OnInventoryChanged = null;
            OnWeightChanged = null;
            OnItemPlaced = null;
            OnItemRemoved = null;
            OnItemRotated = null;
            OnItemQuantityChanged = null;
        }
        #endregion

        #region Debug
        [ContextMenu("Debug: Print Grid")]
        public void DebugPrintGrid()
        {
            if (_data == null || _grid == null) return;

            Debug.Log($"=== GRID {_data.Width}x{_data.Height} ===");
            for (int y = _data.Height - 1; y >= 0; y--)
            {
                var row = "";
                for (int x = 0; x < _data.Width; x++)
                    row += _grid[x, y] == null ? "[ ]" : $"[{_grid[x, y]?.PrefabID}]";
                Debug.Log(row);
            }
            Debug.Log($"Weight: {CurrentWeightKg:F1}kg | Items: {_itemCache.Count}");
        }
        #endregion
    }
}