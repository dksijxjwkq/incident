﻿using UnityEngine;
using K_Incident.Core.Inventory;

namespace K_Incident.Core
{
    /// <summary>
    /// Точка входа системы инвентаря.
    /// Инициализируется ПЕРВОЙ (настрой Script Execution Order: -100).
    /// </summary>
    public class K_InventorySetup : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private ItemDatabase _database;
        [SerializeField] private InventoryData _initialData;

        private InventoryController _controller;

        // =====================================================================
        // СТАТИЧЕСКИЙ ДОСТУП (Для глобального использования)
        // =====================================================================
        public static ItemDatabase DatabaseInstance { get; private set; }
        public static bool IsInitialized { get; private set; } = false;

        // ПУБЛИЧНОЕ СВОЙСТВО для доступа UI к контроллеру
        public InventoryController Controller => _controller;

        private void Awake()
        {
            // Проверка на наличие базы данных
            if (_database == null)
            {
                Debug.LogError("[InventorySetup] CRITICAL: ItemDatabase NOT assigned in Inspector!");
                Debug.LogError("[InventorySetup] Please create ItemDatabase asset and assign it to the Database field.");
                Debug.LogError("[InventorySetup] GameObject: " + gameObject.name);
                enabled = false;
                return;
            }

            // =====================================================================
            // ✅ ИНИЦИАЛИЗАЦИЯ GLOBAL ID MANAGER (ОДИН РАЗ НА ВСЮ ИГРУ)
            // =====================================================================
            uint globalMaxId = FindGlobalMaxInstanceId();
            GlobalIDManager.InitWithMaxId(globalMaxId);

            // Устанавливаем глобальную ссылку
            DatabaseInstance = _database;
            _database.Initialize();

            _controller = new InventoryController(
                _initialData != null ? _initialData : new InventoryData(8, 10),
                _database
            );

            // Подписка на события
            _controller.OnInventoryChanged += OnInventoryUpdated;
            _controller.OnWeightChanged += OnWeightUpdated;

            IsInitialized = true;
            Debug.Log($"[InventorySetup] ✅ Successfully initialized. Database: {_database.name}");
        }

        private void Start()
        {
            if (!IsInitialized)
            {
                Debug.LogError("[InventorySetup] Start() called but IsInitialized = false! Check Awake() errors.");
                return;
            }

            Debug.Log($"[InventorySetup] Initialized. Database loaded with items.");

            // ✅ ПРОТОТИП: Авто-выдача отключена — рюкзак теперь всегда виден как сетка
            // GiveTestBackpack();
        }

        private void OnInventoryUpdated()
        {
            Debug.Log($"[Inventory] Changed! Modified: {_controller.GetSaveData().IsModified}");
        }

        private void OnWeightUpdated(float kg)
        {
            Debug.Log($"[Inventory] Weight: {kg:F2} kg ({_controller.WeightRatio:P1})");
        }

        // =====================================================================
        // НОВЫЙ МЕТОД: Поиск максимального InstanceID во всех сейвах
        // =====================================================================
        private uint FindGlobalMaxInstanceId()
        {
            uint maxId = 0;

            // Сканируем данные инвентаря игрока
            if (_initialData != null)
            {
                foreach (var item in _initialData.GetItems())
                {
                    if (item.InstanceID > maxId) maxId = item.InstanceID;
                }
            }

            // TODO: Добавить сканирование сохранённых чанков/контейнеров
            // Пример: foreach (var chunkSave in SaveSystem.GetAllChunkSaves()) { ... }

            // Возвращаем с запасом +1000 для новых предметов
            return maxId + 10000;
        }

        // =====================================================================
        // ✅ УЛУЧШЕННЫЙ МЕТОД С ПРОВЕРКОЙ ИНИЦИАЛИЗАЦИИ
        // =====================================================================
        public static ItemDatabase GetDatabase()
        {
            if (!IsInitialized)
            {
                Debug.LogWarning("[InventorySetup] GetDatabase() called before initialization!");
                return null;
            }
            return DatabaseInstance;
        }

        // =====================================================================
        // ТЕСТОВЫЕ МЕТОДЫ (Context Menu)
        // =====================================================================

        [ContextMenu("Print Grid")]
        private void PrintGrid() => _controller.DebugPrintGrid();

        [ContextMenu("Give 3 Coagulants")]
        private void GiveTestCoagulant()
        {
            var data = GetDatabase()?.GetItemData("Med_Coagulant");
            if (data == null)
            {
                Debug.LogError("[InventorySetup] Item 'Med_Coagulant' not found in database!");
                return;
            }

            var item = new InventoryItem(data, GlobalIDManager.GenerateID(), 3, 100, false);
            int remainder = _controller.TryPlaceItem(item, 0, 0);

            Debug.Log(remainder == 0
                ? "[InventorySetup] Placed 3 Coagulants successfully."
                : $"[InventorySetup] Remainder: {remainder}");
        }

        [ContextMenu("Give Test Pistol")]
        private void GiveTestPistol()
        {
            if (_controller == null)
            {
                Debug.LogError("[InventorySetup] Controller is null!");
                return;
            }

            var weaponData = GetDatabase()?.GetItemData("Weapon_Pistol_Makarov");

            if (weaponData == null)
            {
                Debug.LogError("[InventorySetup] Weapon_Pistol_Makarov not found!");
                return;
            }

            var weapon = new InventoryItem(
                weaponData,
                GlobalIDManager.GenerateID(),
                1,      // quantity
                100,    // durability
                false   // isRotated
            );

            int remainder = _controller.TryPlaceItem(weapon, 0, 0);

            if (remainder == 0)
                Debug.Log("[InventorySetup] ✅ Pistol given!");
            else
                Debug.LogWarning($"[InventorySetup] ⚠️ Remainder: {remainder}");
        }

        [ContextMenu("Give Random Weapon")]
        private void GiveTestWeapon()
        {
            Debug.LogWarning("[InventorySetup] Weapon test not implemented yet.");
        }

        [ContextMenu("Clear Inventory")]
        private void ClearInventory()
        {
            _controller.Clear();
            Debug.Log("[InventorySetup] Inventory cleared.");
        }

        // =====================================================================
        // ✅ ТЕСТОВЫЙ МЕТОД: ВЫДАЧА РЮКЗАКА (доступен через контекстное меню)
        // =====================================================================
        [ContextMenu("Give Test Backpack")]
        private void GiveTestBackpack()
        {
            if (_controller == null)
            {
                Debug.LogError("[InventorySetup] Controller is null! Cannot give backpack.");
                return;
            }

            // Ищем рюкзак в базе данных по точному ItemID
            var backpackData = GetDatabase()?.GetItemData("Backpack_Small");

            if (backpackData == null)
            {
                Debug.LogError("[InventorySetup] Backpack_Small not found in database! Check ItemID.");
                Debug.LogWarning("[InventorySetup] Available items:");

                var allItems = GetDatabase()?.GetAllItems();
                if (allItems != null)
                {
                    foreach (var item in allItems)
                    {
                        Debug.LogWarning($"  - {item.ItemID} (Type: {item.Type})");
                    }
                }
                return;
            }

            // Создаем экземпляр рюкзака
            var backpack = new InventoryItem(
                backpackData,
                GlobalIDManager.GenerateID(),
                1,      // quantity
                100,    // durability
                false   // isRotated
            );

            // Пытаемся положить в инвентарь (начиная с координат 0,0)
            int remainder = _controller.TryPlaceItem(backpack, 0, 0);

            if (remainder == 0)
                Debug.Log("[InventorySetup] ✅ Test backpack given successfully!");
            else
                Debug.LogWarning($"[InventorySetup] ⚠️ Backpack placed with remainder: {remainder}");
        }

        // =====================================================================
        // ОЧИСТКА
        // =====================================================================

        private void OnDestroy()
        {
            if (_controller != null)
            {
                _controller.OnInventoryChanged -= OnInventoryUpdated;
                _controller.OnWeightChanged -= OnWeightUpdated;
                _controller.Dispose();
            }
            IsInitialized = false;
        }
    }
}