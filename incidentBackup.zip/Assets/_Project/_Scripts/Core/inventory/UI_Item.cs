﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using System.Collections.Generic;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Визуальное представление предмета в инвентаре.
    /// Поддерживает Drag&Drop, отображение количества и поворота.
    /// </summary>
    public class UI_Item : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerEnterHandler
    {
        [SerializeField] private Image _icon;
        [SerializeField] private TextMeshProUGUI _countText;
        [SerializeField] private Image _rotationIndicator;

        private InventoryItem _item;
        private K_InventoryUI _inventoryUI;
        private GridType _gridType;
        private CanvasGroup _canvasGroup;
        private RectTransform _rectTransform;
        private Canvas _rootCanvas;
        private RectTransform _rootCanvasRect;
        private Transform _originalParent;
        private Vector2 _originalAnchoredPos;
        private int _originalX;
        private int _originalY;
        private bool _isBeingDragged;

        private readonly List<RaycastResult> _raycastBuffer = new List<RaycastResult>(8);

        public InventoryItem Item => _item;
        public GridType GridType => _gridType;
        public int X => _originalX;
        public int Y => _originalY;

        public void Setup(InventoryItem item, K_InventoryUI inventoryUI, GridType gridType, int x, int y)
        {
            _item = item;
            _inventoryUI = inventoryUI;
            _gridType = gridType;
            _originalX = x;
            _originalY = y;

            _canvasGroup = GetComponent<CanvasGroup>();
            _rectTransform = GetComponent<RectTransform>();

            if (_canvasGroup != null)
            {
                _canvasGroup.alpha = 1f;
                _canvasGroup.interactable = true;
                _canvasGroup.blocksRaycasts = true;
            }

            _isBeingDragged = false;
            UpdateVisuals();
        }

        public void UpdateData(InventoryItem newItem)
        {
            if (newItem == null) return;
            _item = newItem;
            UpdateVisuals();
        }

        public void UpdateVisuals()
        {
            if (_item == null || _item.Data == null) return;

            if (_icon != null && _item.Data.Icon != null)
            {
                _icon.sprite = _item.Data.Icon;
                _icon.enabled = true;
                _icon.rectTransform.localRotation = Quaternion.Euler(0, 0, -_item.RotationAngle);
            }

            // ✅ Полное отключение объекта для _countText
            if (_countText != null)
            {
                if (_item.Quantity > 1)
                {
                    _countText.text = _item.Quantity.ToString();
                    _countText.enabled = true;
                    _countText.gameObject.SetActive(true);
                }
                else
                {
                    _countText.gameObject.SetActive(false);
                }
            }

            if (_rotationIndicator != null) _rotationIndicator.enabled = _item.IsRotated;

            if (_rectTransform != null && _inventoryUI != null)
            {
                float cellSize = _inventoryUI.GetSlotSize();
                float spacing = _inventoryUI.GetSlotSpacing();
                Vector2Int size = _item.CurrentSize;
                _rectTransform.sizeDelta = new Vector2(
                    size.x * cellSize + (size.x - 1) * spacing,
                    size.y * cellSize + (size.y - 1) * spacing
                );
            }
        }

        // ✅ Гарантированный сброс CanvasGroup и всех кэшированных ссылок
        public void ResetState()
        {
            // ✅ ИСПРАВЛЕНИЕ #4: Сбрасываем флаг в начале
            _isBeingDragged = false;

            // ✅ Гарантированно получаем или добавляем CanvasGroup
            var canvasGroup = GetComponent<CanvasGroup>();
            if (canvasGroup == null) canvasGroup = gameObject.AddComponent<CanvasGroup>();

            canvasGroup.alpha = 1f;
            canvasGroup.interactable = true;
            canvasGroup.blocksRaycasts = true;

            if (_icon != null)
            {
                _icon.sprite = null;
                _icon.enabled = false;
                _icon.rectTransform.localRotation = Quaternion.identity;
            }

            if (_countText != null)
            {
                _countText.gameObject.SetActive(false);
            }

            if (_rotationIndicator != null)
            {
                _rotationIndicator.enabled = false;
            }

            // ✅ Очистка всех кэшированных ссылок
            _canvasGroup = null;
            _rectTransform = null;
            _rootCanvas = null;
            _rootCanvasRect = null;
            _originalParent = null;

            gameObject.SetActive(false);
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (_inventoryUI == null || _item == null || _isBeingDragged) return;

            _isBeingDragged = true;

            if (_rootCanvas == null)
            {
                _rootCanvas = GetComponentInParent<Canvas>();
                // ✅ ИСПРАВЛЕНИЕ #2: Проверка на null после каста
                _rootCanvasRect = _rootCanvas?.transform as RectTransform;

                if (_rootCanvasRect == null)
                {
                    Debug.LogError("[UI_Item] Failed to get RectTransform from parent Canvas!");
                    _isBeingDragged = false;
                    return;
                }
            }

            _originalParent = transform.parent;
            _originalAnchoredPos = _rectTransform.anchoredPosition;

            transform.SetParent(_rootCanvas.transform, false);
            transform.SetAsLastSibling();

            if (_canvasGroup != null)
            {
                _canvasGroup.alpha = 0.6f;
                _canvasGroup.blocksRaycasts = false;
            }

            _inventoryUI.StartDrag(this);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!_isBeingDragged || _rootCanvasRect == null) return;

            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _rootCanvasRect, eventData.position, _rootCanvas.worldCamera, out Vector2 localPos))
            {
                _rectTransform.anchoredPosition = localPos;
            }
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (!_isBeingDragged) return;

            _isBeingDragged = false;
            _raycastBuffer.Clear();
            EventSystem.current?.RaycastAll(eventData, _raycastBuffer);

            bool placed = false;
            foreach (var result in _raycastBuffer)
            {
                var slot = result.gameObject.GetComponent<K_InventorySlotUI>();
                if (slot != null)
                {
                    placed = _inventoryUI.TryPlaceItem(this, slot.GridType, slot.X, slot.Y);
                    if (placed) break;
                }
            }

            if (placed)
            {
                gameObject.SetActive(false);
                _inventoryUI.EndDragComplete();
            }
            else
            {
                // ✅ Проверка на null перед SetParent с Debug.Assert
                if (_originalParent != null)
                {
                    transform.SetParent(_originalParent, false);
#if UNITY_EDITOR
                    Debug.Assert(transform.parent == _originalParent,
                        $"Failed to reparent UI_Item to {_originalParent.name}");
#endif
                }
                else
                {
                    transform.SetParent(_inventoryUI.transform, false);
                }

                if (_rectTransform != null)
                    _rectTransform.anchoredPosition = _originalAnchoredPos;

                if (_canvasGroup != null)
                {
                    _canvasGroup.alpha = 1f;
                    _canvasGroup.blocksRaycasts = true;
                }

                _inventoryUI.EndDragComplete();
            }
        }

        // ✅ Корректная реализация OnApplicationFocus через делегирование
        private void OnApplicationFocus(bool hasFocus)
        {
            // Если потеряли фокус во время драга — сбрасываем флаг и делегируем финализацию контроллеру
            if (!hasFocus && _isBeingDragged && _inventoryUI != null)
            {
                _isBeingDragged = false;
                _inventoryUI.ForceEndDrag(this);
            }
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
#if UNITY_EDITOR
            Debug.Log($"[UI_Item] OnPointerEnter: {gameObject.name} | Pos: {transform.position}");
#endif
        }
    }
}