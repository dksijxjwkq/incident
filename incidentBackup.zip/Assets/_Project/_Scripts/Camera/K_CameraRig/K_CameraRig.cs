using UnityEngine;
using UnityEngine.InputSystem;

namespace K_Incident.Camera
{
    [RequireComponent(typeof(UnityEngine.Camera))]
    public class K_CameraRig : MonoBehaviour
    {
        [Header("Targeting")]
        public Transform Target;
        [SerializeField] private float _smoothTime = 0.15f;

        [Header("Perspective & Orbit")]
        [SerializeField] private float _pitch = 55.0f;
        public float Yaw = 45.0f;
        [SerializeField] private float _fov = 32.0f;

        [Header("Zoom Constraints")]
        [SerializeField] private float _minZoom = 20.0f;
        [SerializeField] private float _maxZoom = 45.0f;
        [SerializeField] private float _zoomSensitivity = 0.01f;

        private UnityEngine.Camera _cam;
        private Vector3 _currentVelocity = Vector3.zero;
        private float _currentZoom;

        private void Awake()
        {
            _cam = GetComponent<UnityEngine.Camera>();
            _cam.fieldOfView = _fov;
            _cam.orthographic = false;

            // Safe initialization within the new 20-45 bounds
            _currentZoom = 30.0f;

            UpdateRotation();
        }

        private void Start()
        {
            if (Target == null)
            {
                Debug.LogError("[K_CameraRig] Critical Error: Target is not assigned in the Inspector!");
                return;
            }

            // Snap immediately on the first frame to prevent flying from the origin
            SnapToTarget();
        }

        private void LateUpdate()
        {
            if (Target == null) return;

            HandleZoom();
            FollowTarget();
        }

        private void HandleZoom()
        {
            if (Mouse.current == null) return;

            float scrollY = Mouse.current.scroll.ReadValue().y;
            if (Mathf.Abs(scrollY) > 0.01f)
            {
                _currentZoom = Mathf.Clamp(_currentZoom - scrollY * _zoomSensitivity, _minZoom, _maxZoom);
            }
        }

        private void FollowTarget()
        {
            // 1. Calculate the base offset using pure trigonometry (as if Yaw is 0)
            float angleRad = _pitch * Mathf.Deg2Rad;
            float height = _currentZoom * Mathf.Sin(angleRad);
            float distance = _currentZoom * Mathf.Cos(angleRad);

            Vector3 baseOffset = new Vector3(0, height, -distance);

            // 2. Rotate the offset around the Y-axis based on the Yaw
            Vector3 rotatedOffset = Quaternion.Euler(0, Yaw, 0) * baseOffset;

            // 3. Apply the final rotated offset to the Target's position
            Vector3 destination = Target.position + rotatedOffset;

            // 4. Smoothly move the camera
            transform.position = Vector3.SmoothDamp(transform.position, destination, ref _currentVelocity, _smoothTime);

            // 5. Sync the physical rotation of the camera lens
            UpdateRotation();
        }

        private void SnapToTarget()
        {
            float angleRad = _pitch * Mathf.Deg2Rad;
            float height = _currentZoom * Mathf.Sin(angleRad);
            float distance = _currentZoom * Mathf.Cos(angleRad);

            Vector3 baseOffset = new Vector3(0, height, -distance);
            Vector3 rotatedOffset = Quaternion.Euler(0, Yaw, 0) * baseOffset;

            transform.position = Target.position + rotatedOffset;
            UpdateRotation();
        }

        private void UpdateRotation()
        {
            // Forces the camera to look down at the pitch angle and face the correct horizontal yaw
            transform.rotation = Quaternion.Euler(_pitch, Yaw, 0);
        }
    }
}