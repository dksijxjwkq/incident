﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Коагулянт — восстанавливает 75 HP ВСЕГО за 60 секунд
    /// </summary>
    public class K_CoagulantItem : MonoBehaviour
    {
        // =====================================================================
        // КОНСТАНТЫ БАЛАНСА
        // =====================================================================
        private const float COAGULANT_DURATION = 60f;
        private const float TOTAL_HEAL_AMOUNT = 75f;
        private const float HEAL_PER_SECOND = TOTAL_HEAL_AMOUNT / COAGULANT_DURATION;

        // =====================================================================
        // СВЯЗЬ С ИНВЕНТАРЕМ (НОВОЕ!)
        // =====================================================================
        /// <summary>
        /// PrefabID для связи с ItemStaticData.
        /// Должен совпадать со значением в Item_Coagulant.asset
        /// </summary>
        public ushort RequiredPrefabID => 2001;

        // =====================================================================
        // ССЫЛКИ
        // =====================================================================
        [Header("System References")]
        [SerializeField] private K_HealthSystem _healthSystem;
        [SerializeField] private K_VitalitySystem _vitalitySystem;

        // =====================================================================
        // ВНУТРЕННИЕ ПЕРЕМЕННЫЕ
        // =====================================================================
        private bool _isActive = false;
        private float _remainingTime = 0f;
        private float _healedAmount = 0f;
        private Coroutine _coagulantCoroutine;

        private float _lastTotalHP = 0f;
        private float _lastCheckTime = 0f;

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
        {
            if (_healthSystem == null)
                _healthSystem = GetComponent<K_HealthSystem>();

            if (_vitalitySystem == null)
                _vitalitySystem = GetComponent<K_VitalitySystem>();
        }

        private void Update()
        {
            if (_isActive && _remainingTime > 0f)
            {
                CheckForNewDamage();
            }
        }

        // =====================================================================
        // ONDESTROY — ОЧИСТКА КОРУТИНЫ (ИСПРАВЛЕНИЕ УТЕЧКИ)
        // =====================================================================
        private void OnDestroy()
        {
            if (_coagulantCoroutine != null)
                StopCoroutine(_coagulantCoroutine);
        }

        // =====================================================================
        // ПРОВЕРКА НА НОВЫЙ УРОН
        // =====================================================================
        private void CheckForNewDamage()
        {
            if (Time.time - _lastCheckTime < 0.5f) return;

            _lastCheckTime = Time.time;

            float currentTotalHP = GetCurrentTotalHP();

            if (currentTotalHP < _lastTotalHP)
            {
                Debug.Log($"[Coagulant] New damage detected! Resuming healing.");
            }

            _lastTotalHP = currentTotalHP;
        }

        private float GetCurrentTotalHP()
        {
            return _healthSystem.HeadHP +
                   _healthSystem.TorsoHP +
                   _healthSystem.StomachHP +
                   _healthSystem.LeftArmHP +
                   _healthSystem.RightArmHP +
                   _healthSystem.LeftLegHP +
                   _healthSystem.RightLegHP;
        }

        // =====================================================================
        // ИСПОЛЬЗОВАНИЕ ПРЕДМЕТА
        // =====================================================================
        public bool UseCoagulant()
        {
            if (_healthSystem == null || _vitalitySystem == null)
            {
                Debug.LogWarning("[Coagulant] System references missing!");
                return false;
            }

            if (_isActive)
            {
                Debug.Log($"[Coagulant] Already active! {_remainingTime:F1}s remaining. Cannot stack.");
                return false;
            }

            if (!CanUseCoagulant())
            {
                Debug.Log("[Coagulant] Cannot use - blocking debuffs present!");
                return false;
            }

            _isActive = true;
            _remainingTime = COAGULANT_DURATION;
            _healedAmount = 0f;
            _lastTotalHP = GetCurrentTotalHP();
            _lastCheckTime = Time.time;

            if (_coagulantCoroutine != null) StopCoroutine(_coagulantCoroutine);
            _coagulantCoroutine = StartCoroutine(CoagulantTick());

            Debug.Log($"[Coagulant] ACTIVATED! Duration: {COAGULANT_DURATION}s | Total Heal: {TOTAL_HEAL_AMOUNT} HP (pool)");
            return true;
        }

        // =====================================================================
        // ПРОВЕРКА БЛОКИРОВОК
        // =====================================================================
        private bool CanUseCoagulant()
        {
            if (_healthSystem.GetMaxBleedingLevel() > 0)
            {
                Debug.Log("[Coagulant] Blocked: Bleeding active");
                return false;
            }

            if (_healthSystem.HasAnyLaceration())
            {
                Debug.Log("[Coagulant] Blocked: Laceration active");
                return false;
            }

            if (_healthSystem.HasFracture)
            {
                bool hasUnsplintedFracture =
                    (_healthSystem.IsFractured(BodyPart.LeftArm) && !_healthSystem.IsSplinted(BodyPart.LeftArm)) ||
                    (_healthSystem.IsFractured(BodyPart.RightArm) && !_healthSystem.IsSplinted(BodyPart.RightArm)) ||
                    (_healthSystem.IsFractured(BodyPart.LeftLeg) && !_healthSystem.IsSplinted(BodyPart.LeftLeg)) ||
                    (_healthSystem.IsFractured(BodyPart.RightLeg) && !_healthSystem.IsSplinted(BodyPart.RightLeg));

                if (hasUnsplintedFracture)
                {
                    Debug.Log("[Coagulant] Blocked: Unsplinted fracture present");
                    return false;
                }
            }

            return true;
        }

        // =====================================================================
        // ТИК ЛЕЧЕНИЯ
        // =====================================================================
        private System.Collections.IEnumerator CoagulantTick()
        {
            WaitForSeconds waitOneSec = new WaitForSeconds(1.0f);

            while (_isActive && _remainingTime > 0f)
            {
                yield return waitOneSec;

                _remainingTime -= 1.0f;

                bool canHealNow = CanUseCoagulant();
                bool hasDamagedSegments = HasDamagedSegments();

                if (canHealNow && hasDamagedSegments)
                {
                    int healedSegments = HealDamagedSegments();

                    if (healedSegments > 0)
                    {
                        _healedAmount += HEAL_PER_SECOND;
                        Debug.Log($"[Coagulant] Tick: {_remainingTime:F1}s | Healed: {_healedAmount:F1}/75 HP");
                    }
                }
                else if (!canHealNow)
                {
                    Debug.Log($"[Coagulant] Tick: {_remainingTime:F1}s | PAUSED (blocking debuffs: bleeding/laceration)");
                }
                else if (!hasDamagedSegments)
                {
                    Debug.Log($"[Coagulant] Tick: {_remainingTime:F1}s | Waiting for damage");
                }

                if (_remainingTime <= 0f || _healedAmount >= TOTAL_HEAL_AMOUNT - 0.01f)
                {
                    Debug.Log($"[Coagulant] FINISHED | Time: {_remainingTime:F1}s | Healed: {_healedAmount:F1}/75 HP");
                    Deactivate();
                    yield break;
                }
            }

            Deactivate();
        }

        // =====================================================================
        // ПРОВЕРКА НА ПОВРЕЖДЁННЫЕ СЕГМЕНТЫ
        // =====================================================================
        public bool HasDamagedSegments()
        {
            if (_healthSystem.HeadHP < _healthSystem.BaseHeadHP) return true;
            if (_healthSystem.TorsoHP < _healthSystem.BaseTorsoHP) return true;
            if (_healthSystem.StomachHP < _healthSystem.BaseStomachHP) return true;
            if (_healthSystem.LeftArmHP < _healthSystem.BaseLeftArmHP && CanHealLimb(BodyPart.LeftArm)) return true;
            if (_healthSystem.RightArmHP < _healthSystem.BaseRightArmHP && CanHealLimb(BodyPart.RightArm)) return true;
            if (_healthSystem.LeftLegHP < _healthSystem.BaseLeftLegHP && CanHealLimb(BodyPart.LeftLeg)) return true;
            if (_healthSystem.RightLegHP < _healthSystem.BaseRightLegHP && CanHealLimb(BodyPart.RightLeg)) return true;

            return false;
        }

        private bool CanHealLimb(BodyPart part)
        {
            if (_healthSystem.IsFractured(part) && !_healthSystem.IsSplinted(part)) return false;
            if (GetSegmentHP(part) <= 0f) return false;
            return true;
        }

        private float GetSegmentHP(BodyPart part)
        {
            return part switch
            {
                BodyPart.LeftArm => _healthSystem.LeftArmHP,
                BodyPart.RightArm => _healthSystem.RightArmHP,
                BodyPart.LeftLeg => _healthSystem.LeftLegHP,
                BodyPart.RightLeg => _healthSystem.RightLegHP,
                _ => 0f
            };
        }

        // =====================================================================
        // ЛЕЧЕНИЕ С ПРИОРИТЕТОМ
        // =====================================================================
        private int HealDamagedSegments()
        {
            var damagedSegments = new List<(BodyPart part, float hpPercent, float currentHP, float maxHP)>();

            AddIfDamaged(BodyPart.Head, _healthSystem.HeadHP, _healthSystem.BaseHeadHP, damagedSegments);
            AddIfDamaged(BodyPart.Torso, _healthSystem.TorsoHP, _healthSystem.BaseTorsoHP, damagedSegments);
            AddIfDamaged(BodyPart.Stomach, _healthSystem.StomachHP, _healthSystem.BaseStomachHP, damagedSegments);
            AddIfDamaged(BodyPart.LeftArm, _healthSystem.LeftArmHP, _healthSystem.BaseLeftArmHP, damagedSegments);
            AddIfDamaged(BodyPart.RightArm, _healthSystem.RightArmHP, _healthSystem.BaseRightArmHP, damagedSegments);
            AddIfDamaged(BodyPart.LeftLeg, _healthSystem.LeftLegHP, _healthSystem.BaseLeftLegHP, damagedSegments);
            AddIfDamaged(BodyPart.RightLeg, _healthSystem.RightLegHP, _healthSystem.BaseRightLegHP, damagedSegments);

            if (damagedSegments.Count == 0)
            {
                return 0;
            }

            damagedSegments.Sort((a, b) => a.hpPercent.CompareTo(b.hpPercent));

            float healPerSegment = HEAL_PER_SECOND / damagedSegments.Count;

            foreach (var segment in damagedSegments)
            {
                _healthSystem.HealSegment(segment.part, healPerSegment);
            }

            return damagedSegments.Count;
        }

        private void AddIfDamaged(BodyPart part, float currentHP, float maxHP,
            List<(BodyPart, float, float, float)> list)
        {
            if (currentHP <= 0f) return;
            if (currentHP >= maxHP) return;

            if (part == BodyPart.LeftArm || part == BodyPart.RightArm ||
                part == BodyPart.LeftLeg || part == BodyPart.RightLeg)
            {
                if (_healthSystem.IsFractured(part) && !_healthSystem.IsSplinted(part)) return;
            }

            float hpPercent = currentHP / maxHP;
            list.Add((part, hpPercent, currentHP, maxHP));
        }

        // =====================================================================
        // ДЕАКТИВАЦИЯ
        // =====================================================================
        private void Deactivate()
        {
            _isActive = false;
            _remainingTime = 0f;
            _healedAmount = 0f;
            _coagulantCoroutine = null;
            Debug.Log("[Coagulant] DEACTIVATED");
        }

        // =====================================================================
        // ГЕТТЕРЫ
        // =====================================================================
        public bool IsActive => _isActive;
        public float RemainingTime => _remainingTime;
        public float TotalHealed => _healedAmount;

        public bool ShouldShowIcon()
        {
            return _isActive && _remainingTime > 0f;
        }

        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Test: Use Coagulant")]
        public void DebugUseCoagulant() => UseCoagulant();

        [ContextMenu("Test: Check Status")]
        public void DebugCheckStatus()
        {
            Debug.Log($"[Coagulant] Active: {_isActive} | Time: {_remainingTime:F1}s | Healed: {_healedAmount:F1} HP");
            Debug.Log($"[Coagulant] Can Use: {CanUseCoagulant()}");
            Debug.Log($"[Coagulant] Should Show Icon: {ShouldShowIcon()}");
            Debug.Log($"[Coagulant] Has Damaged Segments: {HasDamagedSegments()}");
        }
    }
}