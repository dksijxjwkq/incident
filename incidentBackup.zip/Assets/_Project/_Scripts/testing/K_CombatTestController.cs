﻿using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace K_Incident.Core
{
    public class K_CombatTestController : MonoBehaviour
    {
        // =====================================================================
        // КОНСТАНТЫ БАЛАНСА
        // =====================================================================
        private const float PISTOL_DAMAGE = 30f;
        private const float ASSAULT_DAMAGE = 35f;
        private const float SHOTGUN_DAMAGE = 50f;
        private const float RIFLE_DAMAGE = 50f;

        private const float PISTOL_FRACTURE_CHANCE = 0.4f;
        private const float ASSAULT_FRACTURE_CHANCE = 0.6f;
        private const float SHOTGUN_FRACTURE_CHANCE = 0.8f;
        private const float RIFLE_FRACTURE_CHANCE = 0.8f;

        private const int PISTOL_BLEEDING_LEVEL = 1;
        private const int ASSAULT_BLEEDING_LEVEL = 2;
        private const int SHOTGUN_BLEEDING_LEVEL = 3;
        private const int RIFLE_BLEEDING_LEVEL = 3;

        // =====================================================================
        // ССЫЛКИ
        // =====================================================================
        [Header("System References")]
        [SerializeField] private K_HealthSystem _healthSystem;
        [SerializeField] private K_VitalitySystem _vitalitySystem;
        [SerializeField] private K_CoagulantItem _coagulantItem;

        // =====================================================================
        // ВНУТРЕННИЕ ПЕРЕМЕННЫЕ
        // =====================================================================
        private bool _shockOnCooldown = false;
        private float _shockCooldownTimer = 0f;

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
        {
            if (_healthSystem == null)
                _healthSystem = GetComponent<K_HealthSystem>();

            if (_vitalitySystem == null)
                _vitalitySystem = GetComponent<K_VitalitySystem>();

            if (_coagulantItem == null)
                _coagulantItem = GetComponent<K_CoagulantItem>();

            if (_healthSystem == null) Debug.LogError("[CombatTest] K_HealthSystem NOT FOUND!");
            if (_vitalitySystem == null) Debug.LogError("[CombatTest] K_VitalitySystem NOT FOUND!");
            if (_coagulantItem == null) Debug.LogWarning("[CombatTest] K_CoagulantItem NOT FOUND!");
        }

        private void Update()
        {
            if (_shockOnCooldown)
            {
                _shockCooldownTimer -= Time.deltaTime;
                if (_shockCooldownTimer <= 0f)
                {
                    _shockOnCooldown = false;
                    Debug.Log("[CombatTest] Shock cooldown finished!");
                }
            }

            HandleTestInput();
        }

        // =====================================================================
        // ВВОД (КЛАВИШИ 1-0, =)
        // =====================================================================
        private void HandleTestInput()
        {
            if (Keyboard.current == null) return;

            if (Keyboard.current.digit1Key.wasPressedThisFrame)
                TestFirearmHit("Pistol", PISTOL_DAMAGE, PISTOL_BLEEDING_LEVEL, PISTOL_FRACTURE_CHANCE, BodyPart.LeftArm);

            if (Keyboard.current.digit2Key.wasPressedThisFrame)
                TestFirearmHit("Assault Rifle", ASSAULT_DAMAGE, ASSAULT_BLEEDING_LEVEL, ASSAULT_FRACTURE_CHANCE, BodyPart.LeftLeg);

            if (Keyboard.current.digit3Key.wasPressedThisFrame)
                TestFirearmHit("Shotgun", SHOTGUN_DAMAGE, SHOTGUN_BLEEDING_LEVEL, SHOTGUN_FRACTURE_CHANCE, BodyPart.RightArm);

            if (Keyboard.current.digit4Key.wasPressedThisFrame)
                TestFirearmHit("Rifle", RIFLE_DAMAGE, RIFLE_BLEEDING_LEVEL, RIFLE_FRACTURE_CHANCE, BodyPart.RightLeg);

            if (Keyboard.current.digit5Key.wasPressedThisFrame)
                UseBandage();

            if (Keyboard.current.digit6Key.wasPressedThisFrame)
                UseSplint();

            if (Keyboard.current.digit7Key.wasPressedThisFrame)
                UseSutureKit();

            if (Keyboard.current.digit8Key.wasPressedThisFrame)
                UseCoagulant();

            if (Keyboard.current.digit9Key.wasPressedThisFrame)
                UseStimulatorEnhanced();

            if (Keyboard.current.digit0Key.wasPressedThisFrame)
                TestColdExposure();

            // = (равно) = Тест водки
            if (Keyboard.current.equalsKey.wasPressedThisFrame)
                UseVodka();
        }

        // =====================================================================
        // ТЕСТОВЫЙ ВЫСТРЕЛ
        // =====================================================================
        private void TestFirearmHit(string weaponName, float damage, int bleedingLevel, float fractureChance, BodyPart targetPart)
        {
            if (_healthSystem == null || _healthSystem.IsDead)
            {
                Debug.LogWarning("[CombatTest] HealthSystem not found or player is dead!");
                return;
            }

            Debug.Log($"[CombatTest] ============================================");
            Debug.Log($"[CombatTest] FIREARM HIT: {weaponName}");
            Debug.Log($"[CombatTest] Damage: {damage} HP | Bleeding: {bleedingLevel} | Fracture Chance: {fractureChance * 100:F0}%");
            Debug.Log($"[CombatTest] Target: {targetPart}");
            Debug.Log($"[CombatTest] ============================================");

            _healthSystem.TakeDamage(damage, targetPart, DamageType.Firearm, bleedingLevel);

            if (!_shockOnCooldown)
            {
                _shockOnCooldown = true;
                _shockCooldownTimer = 300f;
                Debug.Log($"[CombatTest] SHOCK ACTIVATED! 10s duration, 5min cooldown");
            }

            PrintHealthStatus();
        }

        // =====================================================================
        // МЕДИЦИНА (ИСПРАВЛЕНО: НОВЫЙ API)
        // =====================================================================
        private void UseBandage()
        {
            if (_healthSystem == null) return;

            // Получаем максимальный уровень кровотечения
            int maxBleedingLevel = _healthSystem.GetMaxBleedingLevel();

            if (maxBleedingLevel == 0)
            {
                Debug.Log("[CombatTest] No bleeding to stop!");
                return;
            }

            // Используем бинт на конечность с максимальным кровотечением
            bool success = _healthSystem.UseBandage();

            if (success)
            {
                Debug.Log($"[CombatTest] BANDAGE USED! Max bleeding level reduced by 1");
            }

            PrintHealthStatus();
        }

        private void UseSplint()
        {
            if (_healthSystem == null) return;

            BodyPart[] limbs = { BodyPart.LeftArm, BodyPart.RightArm, BodyPart.LeftLeg, BodyPart.RightLeg };
            bool foundFracture = false;

            foreach (var limb in limbs)
            {
                if (_healthSystem.IsFractured(limb) && !_healthSystem.IsSplinted(limb))
                {
                    _healthSystem.ApplySplint(limb);
                    Debug.Log($"[CombatTest] SPLINT APPLIED to {limb}!");
                    foundFracture = true;
                    break;
                }
            }

            if (!foundFracture)
            {
                Debug.Log("[CombatTest] No fractures to splint!");
            }

            PrintHealthStatus();
        }

        private void UseSutureKit()
        {
            if (_healthSystem == null) return;

            // Проверяем есть ли рваные раны
            if (!_healthSystem.HasAnyLaceration())
            {
                Debug.Log("[CombatTest] No laceration to treat!");
                return;
            }

            // Лечим все рваные раны (без параметра = все)
            _healthSystem.UseSutureKit();
            Debug.Log("[CombatTest] SUTURE KIT USED! All lacerations removed.");
            PrintHealthStatus();
        }

        private void UseCoagulant()
        {
            if (_coagulantItem == null)
            {
                Debug.Log("[CombatTest] CoagulantItem not found!");
                return;
            }

            bool success = _coagulantItem.UseCoagulant();

            if (success)
            {
                Debug.Log("[CombatTest] COAGULANT USED! Healing accelerated for 60 seconds.");
            }
            else
            {
                Debug.Log("[CombatTest] COAGULANT FAILED - Check blocking debuffs!");
            }
        }

        private void UseStimulatorEnhanced()
        {
            if (_vitalitySystem == null)
            {
                Debug.Log("[CombatTest] VitalitySystem not found!");
                return;
            }

            _vitalitySystem.UseStimulatorEnhanced();
            Debug.Log("[CombatTest] STIMULATOR USED! 85s ON + 200s OFF (Side Effects + Cooldown)");
        }

        private void TestColdExposure()
        {
            if (_vitalitySystem == null)
            {
                Debug.Log("[CombatTest] VitalitySystem not found!");
                return;
            }

            float current = _vitalitySystem.ColdExposure;
            float next = current >= 1.0f ? 0f : (current >= 0.5f ? 1.0f : 0.5f);

            _vitalitySystem.SetColdExposure(next);
            Debug.Log($"[CombatTest] Cold Exposure: {current:F2} → {next:F2}");
        }

        private void UseVodka()
        {
            if (_vitalitySystem == null)
            {
                Debug.Log("[CombatTest] VitalitySystem not found!");
                return;
            }

            _vitalitySystem.ConsumeVodka(100f);
            Debug.Log("[CombatTest] VODKA CONSUMED! 100ml | -5 Radiation | Drunk 120s");
        }

        // =====================================================================
        // СТАТУС (ИСПРАВЛЕНО: НОВЫЙ API)
        // =====================================================================
        private void PrintHealthStatus()
        {
            if (_healthSystem == null) return;

            Debug.Log($"[CombatTest] ========== HEALTH STATUS ==========");
            Debug.Log($"[CombatTest] Head: {_healthSystem.HeadHP:F1}/{_healthSystem.BaseHeadHP:F1}");
            Debug.Log($"[CombatTest] Torso: {_healthSystem.TorsoHP:F1}/{_healthSystem.BaseTorsoHP:F1}");
            Debug.Log($"[CombatTest] Stomach: {_healthSystem.StomachHP:F1}/{_healthSystem.BaseStomachHP:F1}");
            Debug.Log($"[CombatTest] L.Arm: {_healthSystem.LeftArmHP:F1}/{_healthSystem.BaseLeftArmHP:F1}");
            Debug.Log($"[CombatTest] R.Arm: {_healthSystem.RightArmHP:F1}/{_healthSystem.BaseRightArmHP:F1}");
            Debug.Log($"[CombatTest] L.Leg: {_healthSystem.LeftLegHP:F1}/{_healthSystem.BaseLeftLegHP:F1}");
            Debug.Log($"[CombatTest] R.Leg: {_healthSystem.RightLegHP:F1}/{_healthSystem.BaseRightLegHP:F1}");
            Debug.Log($"[CombatTest] -----------------------------------");
            Debug.Log($"[CombatTest] Max Bleeding Level: {_healthSystem.GetMaxBleedingLevel()}");
            Debug.Log($"[CombatTest] Bleeding Limbs Count: {_healthSystem.GetBleedingLimbsCount()}");
            Debug.Log($"[CombatTest] Has Any Laceration: {_healthSystem.HasAnyLaceration()}");
            Debug.Log($"[CombatTest] Fractures: {_healthSystem.FractureCount}");
            Debug.Log($"[CombatTest] Shock: {_healthSystem.IsShocked}");

            if (_vitalitySystem != null)
            {
                Debug.Log($"[CombatTest] -----------------------------------");
                Debug.Log($"[CombatTest] Stim ON: {_vitalitySystem.IsStimOn}");
                Debug.Log($"[CombatTest] Stim OFF: {_vitalitySystem.IsStimOff}");
                Debug.Log($"[CombatTest] Stim Ready: {_vitalitySystem.IsStimReady}");
                Debug.Log($"[CombatTest] Fatigue: {_vitalitySystem.IsFatigued}");
                Debug.Log($"[CombatTest] Hangover: {_vitalitySystem.IsHangover}");
                Debug.Log($"[CombatTest] Cold Exposure: {_vitalitySystem.ColdExposure:F2}");
                Debug.Log($"[CombatTest] Temperature: {_vitalitySystem.CurrentTemperature:F1}°C");
                Debug.Log($"[CombatTest] Overload: {_vitalitySystem.IsOverloaded}");
                Debug.Log($"[CombatTest] Hunger: {_vitalitySystem.Hunger:F1}");
                Debug.Log($"[CombatTest] Thirst: {_vitalitySystem.Thirst:F1}");
                Debug.Log($"[CombatTest] Radiation: {_vitalitySystem.Radiation:F1}%");
                Debug.Log($"[CombatTest] Alcohol: {_vitalitySystem.AlcoholConcentration:F2}");
                Debug.Log($"[CombatTest] Radiation Immunity: {_vitalitySystem.HasRadiationImmunity}");
            }

            Debug.Log($"[CombatTest] ===================================");
        }

        // =====================================================================
        // DEBUG CONTEXT MENUS (ИСПРАВЛЕНО: НОВЫЙ API)
        // =====================================================================
        [ContextMenu("Test: Pistol Shot (Left Arm)")]
        public void DebugPistolShot() => TestFirearmHit("Pistol", PISTOL_DAMAGE, PISTOL_BLEEDING_LEVEL, PISTOL_FRACTURE_CHANCE, BodyPart.LeftArm);

        [ContextMenu("Test: Assault Shot (Left Leg)")]
        public void DebugAssaultShot() => TestFirearmHit("Assault Rifle", ASSAULT_DAMAGE, ASSAULT_BLEEDING_LEVEL, ASSAULT_FRACTURE_CHANCE, BodyPart.LeftLeg);

        [ContextMenu("Test: Shotgun Shot (Right Arm)")]
        public void DebugShotgunShot() => TestFirearmHit("Shotgun", SHOTGUN_DAMAGE, SHOTGUN_BLEEDING_LEVEL, SHOTGUN_FRACTURE_CHANCE, BodyPart.RightArm);

        [ContextMenu("Test: Rifle Shot (Right Leg)")]
        public void DebugRifleShot() => TestFirearmHit("Rifle", RIFLE_DAMAGE, RIFLE_BLEEDING_LEVEL, RIFLE_FRACTURE_CHANCE, BodyPart.RightLeg);

        [ContextMenu("Test: Use Bandage")]
        public void DebugBandage() => UseBandage();

        [ContextMenu("Test: Use Splint")]
        public void DebugSplint() => UseSplint();

        [ContextMenu("Test: Use Suture Kit")]
        public void DebugSuture() => UseSutureKit();

        [ContextMenu("Test: Use Coagulant")]
        public void DebugCoagulant() => UseCoagulant();

        [ContextMenu("Test: Use Stimulator")]
        public void DebugStim() => UseStimulatorEnhanced();

        [ContextMenu("Test: Toggle Cold Exposure")]
        public void DebugCold() => TestColdExposure();

        [ContextMenu("Test: Consume Vodka (100ml)")]
        public void DebugVodka() => UseVodka();

        [ContextMenu("Test: Toggle Overload")]
        public void DebugOverload()
        {
            if (_vitalitySystem != null)
            {
                _vitalitySystem.SetOverload(!_vitalitySystem.IsOverloaded);
            }
        }

        [ContextMenu("Test: Print Status")]
        public void DebugPrintStatus() => PrintHealthStatus();

        [ContextMenu("Test: Reset All")]
        public void DebugResetAll()
        {
            if (_healthSystem != null)
            {
                // Сброс всех кровотечений
                _healthSystem.DebugStopBleeding();
                // Сброс всех рваных ран
                _healthSystem.DebugRemoveLaceration();
                // Сброс шин
                _healthSystem.RemoveSplint(BodyPart.LeftArm);
                _healthSystem.RemoveSplint(BodyPart.RightArm);
                _healthSystem.RemoveSplint(BodyPart.LeftLeg);
                _healthSystem.RemoveSplint(BodyPart.RightLeg);
            }
            _shockOnCooldown = false;
            _shockCooldownTimer = 0f;
            Debug.Log("[CombatTest] All statuses reset!");
        }
    }
}