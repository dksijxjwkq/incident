using UnityEngine;
using UnityEngine.UI;

public class DebugGridLayout : MonoBehaviour
{
    void Start()
    {
        var pocketsGrid = 
            FindObjectOfType<K_InventoryUI>().GetComponentInChildren<GridLayoutGroup>(true);
        var surroundingsGrid = FindObjectOfType<K_InventoryUI>().transform.Find("RightPane/SurroundingsGrid").GetComponent<GridLayoutGroup>();

        Debug.Log($"=== POCKETS GRID ===");
        Debug.Log($"Cell Size: {pocketsGrid.cellSize}");
        Debug.Log($"Spacing: {pocketsGrid.spacing}");
        Debug.Log($"Padding: {pocketsGrid.padding}");
        Debug.Log($"Canvas Scale: {pocketsGrid.GetComponentInParent<Canvas>().scaleFactor}");

        Debug.Log($"=== SURROUNDINGS GRID ===");
        Debug.Log($"Cell Size: {surroundingsGrid.cellSize}");
        Debug.Log($"Spacing: {surroundingsGrid.spacing}");
        Debug.Log($"Padding: {surroundingsGrid.padding}");
        Debug.Log($"Canvas Scale: {surroundingsGrid.GetComponentInParent<Canvas>().scaleFactor}");
    }
}