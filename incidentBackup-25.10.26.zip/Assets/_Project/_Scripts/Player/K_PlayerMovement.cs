﻿﻿using UnityEngine;
using UnityEngine.InputSystem;
using K_Incident.Core.Combat;

namespace K_Incident.Core
{
    [RequireComponent(typeof(CharacterController))]
    public class K_PlayerMotor : MonoBehaviour
    {
        [Header("Movement Speeds")]
        [SerializeField] private float _walkSpeed = 1.8f;
        [SerializeField] private float _runSpeed = 4.5f;
        [SerializeField] private float _crouchSpeed = 1.2f;

        [Header("Dynamics")]
        [SerializeField] private float _accelerationTime = 0.25f;
        [SerializeField] private float _decelerationTime = 0.1f;
        [SerializeField] private float _rotationSpeed = 720f;
        [SerializeField] private float _gravityMultiplier = 2.0f;

        [Header("References")]
        [SerializeField] private K_WeightManager _weightManager;
        [SerializeField] private K_VitalitySystem _vitalitySystem;
        [SerializeField] private K_BloodSystem _bloodSystem;
        [SerializeField] private K_DebuffSystem _debuffSystem;

        [Header("Footstep acoustics (distance per step, metres)")]
        [SerializeField, Min(.01f)] private float _footstepWalkDistance = 2f;
        [SerializeField, Min(.01f)] private float _footstepSprintDistance = 2.5f;
        [SerializeField, Min(.01f)] private float _footstepCrouchDistance = 1.5f;
        [SerializeField] private LayerMask _surfaceMask = ~0;
        [SerializeField, Tooltip("Неуказанный слой считается Wood. Metal использует существующий акустический множитель.")]
        private FootstepSurfaceLayer[] _surfaceByLayer = new FootstepSurfaceLayer[0];
        private readonly FootstepCadence _footstepCadence = new FootstepCadence();
        private K_PlayerCombatController _combatAcoustics;
        private bool _isCrouchingNow;

        [Header("Status (Read Only)")]
        [SerializeField] private bool _isLimping;
        [SerializeField] private bool _isShockActive;

        private CharacterController _controller;
        private UnityEngine.Camera _mainCamera;
        private K_InputActions _inputActions;
        private K_HealthSystem _health;
        private bool _warnedMissingMouse;

        private Vector3 _currentVelocityXZ;
        private Vector3 _smoothVelocityRef;
        private float _verticalVelocity;

        // Константа минимальной скорости (Аспект №2)
        private const float MIN_SPEED_FLOOR = 0.05f;

        // Для отладочного логирования (раз в секунду)
        private float _lastLogTime;

        // Stage 2 §4.5: активность для дренажа внутреннего кровотечения.
        private float _recentSprintTimer;
        private float _recentJumpTimer;
        private bool _isSprintingNow;
        private bool _prevSprintingNow;

        private const float RECENT_SPRINT_DURATION = 15f;
        private const float RECENT_JUMP_DURATION = 10f;

        // =====================================================================
        // БЛОКИРОВКА ДВИЖЕНИЯ (для инвентаря)
        // =====================================================================
        private bool _movementEnabled = true;

        private void Awake()
{
    _controller = GetComponent<CharacterController>();
    _health = GetComponent<K_HealthSystem>();

    if (_weightManager == null)
        _weightManager = GetComponent<K_WeightManager>();
    if (_vitalitySystem == null)
        _vitalitySystem = GetComponent<K_VitalitySystem>();
    if (_bloodSystem == null)
        _bloodSystem = GetComponent<K_BloodSystem>();

    if (_controller != null)
        _controller.stepOffset = 0.4f;

    _mainCamera = UnityEngine.Camera.main;
    _inputActions = new K_InputActions();
    if (_debuffSystem == null)
    _debuffSystem = GetComponent<K_DebuffSystem>();
}

        private void OnEnable() => _inputActions?.Enable();
        private void OnDisable() => _inputActions?.Disable();

        // =====================================================================
        // ONDESTROY — ДИСПОЗИЦИЯ INPUT ACTIONS (ИСПРАВЛЕНИЕ УТЕЧКИ)
        // =====================================================================
        private void OnDestroy()
        {
            // Критически важно: Dispose() освобождает внутренние ресурсы InputActionAsset
            _inputActions?.Dispose();
        }

        private void Update()
        {
            if (!_movementEnabled || _mainCamera == null || _inputActions == null || (_health != null && _health.IsDead))
                _footstepCadence.Reset();
            if (_recentSprintTimer > 0f)
                _recentSprintTimer = Mathf.Max(0f, _recentSprintTimer - Time.deltaTime);
            if (_recentJumpTimer > 0f)
                _recentJumpTimer = Mathf.Max(0f, _recentJumpTimer - Time.deltaTime);

            // ✅ ПРОВЕРКА: если движение заблокировано (инвентарь открыт)
            if (!_movementEnabled) return;

            if (_mainCamera == null || _inputActions == null || (_health != null && _health.IsDead))
                return;

            UpdateStatusFlags();
            ProcessMovement();
            ProcessRotation();
            ApplyGravityAndMove();
        }

             private void UpdateStatusFlags()
        {
            if (_health == null) return;

            _isShockActive = _health.IsShocked;
            // Stage 1 §7.5: хромота теперь = уровень зоны ног > 0.
            // HasLegFracture удалён (backward-compat свойство снято с K_HealthSystem).
            _isLimping = _health.GetLegZoneLevel() > 0 && !_isShockActive;
        }
        private void ProcessMovement()
        {
            if (_health == null) return;

            Vector2 input = _inputActions.Player.Move.ReadValue<Vector2>();
            bool isSprintingInput = _inputActions.Player.Sprint.ReadValue<float>() > 0.1f;
            bool isCrouching = _inputActions.Player.Crouch.ReadValue<float>() > 0.1f;
            _isCrouchingNow = isCrouching;

            // ── Спринт-гейты ──
            bool canSprint = true;
            if (_weightManager != null && _weightManager.IsOverloaded()) canSprint = false;
            if (_debuffSystem != null && _debuffSystem.IsSprintBlocked()) canSprint = false;
            // Stage 1 §7.5: спринт запрещён при уровне зоны ног 3.
            if (_health.IsSprintBlockedByLegZone()) canSprint = false;

            float targetSpeed = _walkSpeed;
            if (isCrouching)
                targetSpeed = _crouchSpeed;
            else if (isSprintingInput && canSprint)
                targetSpeed = _runSpeed;

            // Намерение бежать определяем до штрафов скорости. Ввод движения
            // исключает Shift на месте; реальную скорость проверяет геттер ниже.
            bool sprintingNow = !isCrouching && isSprintingInput && canSprint
                && input.sqrMagnitude >= 0.01f
                && (_weightManager == null || !_weightManager.IsFullyStopped());
            _isSprintingNow = sprintingNow;

            // Stage 1 §7.6: локальная логика хромоты ×0.6/×0.3 УДАЛЕНА.
            // Она дублировала K_WeightManager.ApplyLegInjurySynergy (тоже удалён).
            // Единый источник штрафа за травму ног — GetLegSpeedMultiplier() ниже.
            // _isLimping обновляется в UpdateStatusFlags для UI.

            // =================================================================
            // ИНТЕГРАЦИЯ ВЕСА (Аспект №2)
            // =================================================================
            if (_weightManager != null)
            {
                float weightMult = _weightManager.GetSpeedMultiplier();
                targetSpeed *= weightMult;

#if UNITY_EDITOR
                if (Time.time - _lastLogTime >= 1f)
                {
                    Debug.Log($"[Motor] Speed: Base={_runSpeed:F1} × WeightMult={weightMult:F2} = {targetSpeed:F2} m/s");
                    _lastLogTime = Time.time;
                }
#endif
            }

            // =================================================================
            // ИНТЕГРАЦИЯ КРОВИ
            // =================================================================
            if (_bloodSystem != null)
            {
                targetSpeed *= _bloodSystem.GetSpeedMultiplier();
            }

            // =================================================================
            // ИНТЕГРАЦИЯ ДЕБАФФОВ
            // =================================================================
            if (_debuffSystem != null)
            {
                targetSpeed *= _debuffSystem.GetSpeedMultiplier();
            }
            if (_vitalitySystem != null)
                targetSpeed *= _vitalitySystem.RadiationSpeedMult;

            // =================================================================
            // Stage 1 §7.5: ЗОНАЛЬНАЯ СИСТЕМА НОГ.
            // Заменяет старую пару хромоты ×0.6/×0.3 (K_WeightManager.ApplyLegInjurySynergy).
            // Учитывает: HP < 1, перелом без шины, авто-3 от таза/живота, опьянение/похмелье.
            // =================================================================
            targetSpeed *= _health.GetLegSpeedMultiplier();

            if (_vitalitySystem != null && _vitalitySystem.IsColdCritical)
            {
                float coldSpeedPenalty = 0.8f;
#if UNITY_EDITOR
                float speedBefore = targetSpeed;
#endif
                targetSpeed *= coldSpeedPenalty;

#if UNITY_EDITOR
                if (Time.time - _lastLogTime >= 1f)
                {
                    Debug.Log($"[Motor] COLD PENALTY: {speedBefore:F2} → {targetSpeed:F2} m/s (-20%)");
                    _lastLogTime = Time.time;
                }
#endif
            }

            // Полный стоп по весу — игрок не двигается, min-floor НЕ применяется.
            if (_weightManager != null && _weightManager.IsFullyStopped())
            {
                targetSpeed = 0f;
            }
            else if (input.sqrMagnitude < 0.01f)
            {
                targetSpeed = 0f;
            }
            else
            {
                float minSpeed = _runSpeed * MIN_SPEED_FLOOR;
                if (targetSpeed < minSpeed)
                    targetSpeed = minSpeed;
            }

            Vector3 camForward = _mainCamera.transform.forward;
            Vector3 camRight = _mainCamera.transform.right;
            camForward.y = 0;
            camRight.y = 0;
            camForward.Normalize();
            camRight.Normalize();

            Vector3 targetDirection = (camForward * input.y + camRight * input.x).normalized;
            Vector3 targetVelocity = targetDirection * targetSpeed;
            float smoothTime = targetSpeed > 0.01f ? _accelerationTime : _decelerationTime;
            _currentVelocityXZ = Vector3.SmoothDamp(_currentVelocityXZ, targetVelocity, ref _smoothVelocityRef, smoothTime);

            // Послеспринтовый эффект начинается лишь после фактического бега.
            bool activeSprint = sprintingNow && _currentVelocityXZ.sqrMagnitude > 0.01f;
            if (_prevSprintingNow && !activeSprint)
                _recentSprintTimer = RECENT_SPRINT_DURATION;
            _prevSprintingNow = activeSprint;
        }

        private void ProcessRotation()
        {
            var mouse = Mouse.current;
            if (mouse == null)
            {
                if (!_warnedMissingMouse)
                {
                    _warnedMissingMouse = true;
                    Debug.LogWarning("[K_PlayerMotor] Mouse input is unavailable; rotation is paused.");
                }
                return;
            }
            Plane groundPlane = new Plane(Vector3.up, transform.position);
            Ray ray = _mainCamera.ScreenPointToRay(mouse.position.ReadValue());

            if (groundPlane.Raycast(ray, out float hitDistance))
            {
                Vector3 lookPoint = ray.GetPoint(hitDistance);
                Vector3 direction = (lookPoint - transform.position);
                direction.y = 0;

                if (direction.sqrMagnitude > 0.01f)
                {
                    Quaternion targetRot = Quaternion.LookRotation(direction);
                    transform.rotation = Quaternion.RotateTowards(transform.rotation, targetRot, _rotationSpeed * Time.deltaTime);
                }
            }
        }

        private void ApplyGravityAndMove()
        {
            if (_controller == null) return;

            if (_controller.isGrounded)
                _verticalVelocity = -2.0f;
            else
                _verticalVelocity += Physics.gravity.y * _gravityMultiplier * Time.deltaTime;

            Vector3 finalMotion = _currentVelocityXZ;
            finalMotion.y = _verticalVelocity;

            Vector3 positionBeforeMove = transform.position;
            _controller.Move(finalMotion * Time.deltaTime);
            EmitFootsteps(transform.position - positionBeforeMove);
        }

        private void EmitFootsteps(Vector3 actualMotion)
        {
            if (!_movementEnabled || !_controller.isGrounded)
            {
                _footstepCadence.Reset();
                return;
            }
            actualMotion.y = 0f;
            float stride = _isCrouchingNow ? _footstepCrouchDistance :
                _isSprintingNow ? _footstepSprintDistance : _footstepWalkDistance;
            int steps = _footstepCadence.Advance(actualMotion.magnitude, stride);
            if (steps == 0) return;
            var acoustic = K_AcousticSystem.RegisteredInstance;
            if (acoustic == null) return;
            bool metal = false;
            if (Physics.Raycast(_controller.bounds.center, Vector3.down, out RaycastHit ground,
                _controller.bounds.extents.y + .25f, _surfaceMask, QueryTriggerInteraction.Ignore))
                metal = FootstepSurfaceMapping.Resolve(ground.collider.gameObject.layer, _surfaceByLayer) == FootstepSurfaceType.Metal;
            if (_combatAcoustics == null) _combatAcoustics = GetComponent<K_PlayerCombatController>();
            bool indoor = _combatAcoustics != null && _combatAcoustics.IsIndoor;
            for (int i = 0; i < steps && _movementEnabled; i++)
                acoustic.BroadcastFootstep(transform.position, _isCrouchingNow, _isSprintingNow, metal, indoor, gameObject);
        }

        // =====================================================================
        // ГЕТТЕРЫ ДЛЯ ДРУГИХ СИСТЕМ
        // =====================================================================
        public bool IsLimping => _isLimping;
        public bool IsShockActive => _isShockActive;
        public float CurrentSpeed => _currentVelocityXZ.magnitude;
        public Vector3 CurrentVelocity => _currentVelocityXZ;

        /// <summary>
        /// Stage 2 §4.5: максимум активности для дренажа IB.
        /// Покой ×1, ходьба ×2, бег ×3, 15 секунд после бега ×3,
        /// 10 секунд после прыжка ×3.
        /// </summary>
        public float CurrentActivityMultiplier
        {
            get
            {
                float mult = 1f;
                bool moving = _currentVelocityXZ.sqrMagnitude > 0.01f;
                if (moving) mult = 2f;
                if (moving && _isSprintingNow) mult = 3f;
                if (_recentSprintTimer > 0f) mult = Mathf.Max(mult, 3f);
                if (_recentJumpTimer > 0f) mult = Mathf.Max(mult, 3f);
                return mult;
            }
        }

        /// <summary>Учитывает прыжок в активности и системе здоровья.</summary>
        public void NotifyJumped()
        {
            _recentJumpTimer = RECENT_JUMP_DURATION;
            _health?.NotifyJump();
        }

        // =====================================================================
        // МЕТОД БЛОКИРОВКИ ДВИЖЕНИЯ
        // =====================================================================
        public void SetMovementEnabled(bool enabled)
        {
            _movementEnabled = enabled;
            if (!enabled)
            {
                _footstepCadence.Reset();
                _currentVelocityXZ = Vector3.zero;
                _smoothVelocityRef = Vector3.zero;
                _isSprintingNow = false;
                _prevSprintingNow = false;
            }
        }
    }
}
