using System;
using System.Collections.Generic;
using K_Incident.Core;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Запись о медицинском предмете в инвентаре игрока.
    /// Используется будущим UI-зеркалом (Этап 5) для отображения иконки,
    /// количества и инициирования drag.
    /// </summary>
    public readonly struct MedicalItemRecord
    {
        /// <summary>Живой предмет (или материализованный из SavedItem для закрытых рюкзаков).</summary>
        public readonly InventoryItem Item;

        /// <summary>Контроллер, в котором лежит предмет. null для SavedItem-записей.</summary>
        public readonly InventoryController Controller;

        /// <summary>Тип сетки: Pockets / Pocket2 / Backpack / Container.</summary>
        public readonly GridType GridType;

        /// <summary>Корневые координаты предмета в сетке.</summary>
        public readonly int X;

        /// <summary>Корневые координаты предмета в сетке.</summary>
        public readonly int Y;

        /// <summary>Рюкзак-владелец; для SavedTree — живой корень сериализованного дерева. null для корневых сеток.</summary>
        public readonly InventoryItem OwnerBackpack;

        /// <summary>true, если запись материализована из SavedItem-дерева закрытого рюкзака.</summary>
        public readonly bool IsFromSavedTree;

        /// <summary>Исходный SavedItem. Имеет смысл только при IsFromSavedTree = true.</summary>
        public readonly SavedItem SavedItem;

        public MedicalItemRecord(
            InventoryItem item,
            InventoryController controller,
            GridType gridType,
            int x,
            int y,
            InventoryItem ownerBackpack,
            bool isFromSavedTree,
            SavedItem savedItem)
        {
            Item = item;
            Controller = controller;
            GridType = gridType;
            X = x;
            Y = y;
            OwnerBackpack = ownerBackpack;
            IsFromSavedTree = isFromSavedTree;
            SavedItem = savedItem;
        }
    }

    /// <summary>
    /// Сервис сбора всех медицинских предметов инвентаря игрока.
    ///
    /// Источник данных: Pockets + Pocket2 + Backpack + вся матрёшка рюкзаков
    /// (открытых через BackpackContainerManager.GetLiveController и закрытых
    /// через InventoryItem.GetBackpackSavedItems).
    ///
    /// НЕ обходит SurroundingsPanel, активный лут (ActiveContainerController
    /// при IsLooting), внешние контейнеры (K_LootBox) и временные контроллеры
    /// (TempDrop_*).
    ///
    /// ВНИМАНИЕ: класс СИНХРОННЫЙ. Запрещено использовать async/await,
    /// Task, Coroutine, yield return.
    ///
    /// Не MonoBehaviour. Создаётся и владеется K_InventoryUI.
    /// </summary>
    public sealed class MedicalInventoryService
    {
        private const int MAX_RECURSION_DEPTH = 32;

        private readonly InventoryController _pockets;
        private readonly InventoryController _pocket2;
        private readonly InventoryController _backpack;
        private readonly BackpackContainerManager _backpackManager;
        private readonly MedicalDatabase _medicalDatabase;
        private readonly ItemDatabase _itemDatabase;

        private readonly List<MedicalItemRecord> _cache = new List<MedicalItemRecord>();
        private readonly HashSet<uint> _visited = new HashSet<uint>();
        private bool _isDirty = true;
        private bool _isBuilding;

        public MedicalInventoryService(
            InventoryController pockets,
            InventoryController pocket2,
            InventoryController backpack,
            BackpackContainerManager backpackManager,
            MedicalDatabase medicalDatabase,
            ItemDatabase itemDatabase)
        {
            _pockets = pockets;
            _pocket2 = pocket2;
            _backpack = backpack;
            _backpackManager = backpackManager;
            _medicalDatabase = medicalDatabase;
            _itemDatabase = itemDatabase;
        }

        /// <summary>
        /// Возвращает список всех медицинских предметов инвентаря игрока.
        /// После первого расчёта — O(1), пока данные не изменились.
        /// </summary>
        public IReadOnlyList<MedicalItemRecord> GetMedicalItems()
        {
            if (_isDirty)
                RebuildCache();
            return _cache;
        }

        /// <summary>
        /// Помечает кэш устаревшим. Следующий вызов GetMedicalItems перестроит его.
        /// Вызывается из K_InventoryUI.ForceRefresh() и RefreshAll().
        /// </summary>
        public void MarkDirty()
        {
            _isDirty = true;
        }

        private void RebuildCache()
        {
            if (_isBuilding) return;
            _isBuilding = true;
            try
            {
                _cache.Clear();
                _visited.Clear();

                if (_medicalDatabase == null)
                {
                    _isDirty = false;
                    return;
                }

                // Осознанно не обходим слоты экипировки (Primary, Pistol, Melee,
                // Armor, HeadGear). По дизайну медикаменты в них не хранятся —
                // там оружие, броня, каска. Если дизайн изменится — расширить
                // RebuildCache на обход слотов через K_InventoryUI.GetEquipmentSlotByType.
                TraverseController(_pockets, GridType.Pockets, null, 0);
                TraverseController(_pocket2, GridType.Pocket2, null, 0);
                TraverseController(_backpack, GridType.Backpack, null, 0);

                _isDirty = false;
            }
            finally
            {
                _isBuilding = false;
            }
        }

        private void TraverseController(
            InventoryController ctrl,
            GridType gridType,
            InventoryItem ownerBackpack,
            int depth)
        {
            if (ctrl == null || ctrl.IsDisposed || depth > MAX_RECURSION_DEPTH) return;

            for (int y = 0; y < ctrl.Height; y++)
            {
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var item = ctrl.GetItemAt(x, y);
                    if (item == null || item.Data == null) continue;
                    if (!ctrl.IsRootCell(item.InstanceID, x, y)) continue;
                    if (!_visited.Add(item.InstanceID)) continue;

                    if (_medicalDatabase.IsMedical(item.Data.ItemID))
                    {
                        _cache.Add(new MedicalItemRecord(
                            item,
                            ctrl,
                            gridType,
                            x,
                            y,
                            ownerBackpack,
                            false,
                            default));
                    }

                    if (item.Data.IsBackpack)
                    {
                        TraverseBackpackItem(item, depth);
                    }
                }
            }
        }

        private void TraverseBackpackItem(InventoryItem backpackItem, int depth)
        {
            if (backpackItem == null || backpackItem.Data == null || !backpackItem.Data.IsBackpack) return;
            if (depth > MAX_RECURSION_DEPTH) return;

            string idStr = backpackItem.InstanceID.ToString();
            var liveCtrl = _backpackManager?.GetLiveController(idStr);
            if (liveCtrl != null && !liveCtrl.IsDisposed)
            {
                TraverseController(liveCtrl, GridType.Container, backpackItem, depth + 1);
            }
            else
            {
                var savedItems = backpackItem.GetBackpackSavedItems();
                TraverseSavedItems(savedItems, backpackItem, depth + 1);
            }
        }

// ═══════════════════════════════════════════════════════════════
//  ЭТАП 6.5: СПИСАНИЕ МЕДИКАМЕНТА
// ═══════════════════════════════════════════════════════════════

/// <summary>
/// Списывает 1 единицу медикамента:
///   Quantity > 1 → Quantity -= 1.
///   Quantity == 1 → удаление предмета (живой контроллер или SavedTree).
/// Возвращает false, если предмет не найден / невалиден (best-effort).
/// </summary>
public bool Consume(MedicalItemRecord record)
{
    if (record.Item == null)
    {
        UnityEngine.Debug.LogWarning(
            "[MedicalInventoryService.Consume] record.Item is null — cannot consume.");
        return false;
    }

    // A cached view must still name the exact live owner before quantity changes.
    if (record.Item.Quantity <= 0) return false;
    if (!record.IsFromSavedTree && (record.Controller == null || record.Controller.IsDisposed ||
        !ReferenceEquals(record.Controller.GetItemByInstanceID(record.Item.InstanceID), record.Item)))
        return false;

    if (record.Item.Quantity > 1)
    {
        if (record.IsFromSavedTree)
        {
            if (record.OwnerBackpack == null)
            {
                UnityEngine.Debug.LogWarning(
                    $"[MedicalInventoryService.Consume] OwnerBackpack is null for SavedTree item {record.Item.InstanceID}.");
                return false;
            }

            int newQuantity = record.Item.Quantity - 1;
            if (!UpdateSavedItemQuantity(record.OwnerBackpack, record.Item.InstanceID, newQuantity))
            {
                UnityEngine.Debug.LogWarning(
                    $"[MedicalInventoryService.Consume] SavedItem {record.Item.InstanceID} not found in owner backpack for quantity update.");
                return false;
            }

            record.Item.RemoveQuantity(1);
            MarkDirty();
            return true;
        }

        if (record.Controller == null)
        {
            UnityEngine.Debug.LogWarning(
                $"[MedicalInventoryService.Consume] Controller is null for non-SavedTree item {record.Item.InstanceID}.");
            return false;
        }

        record.Item.RemoveQuantity(1);

        if (!record.Controller.RefreshItemInData(record.Item))
        {
            UnityEngine.Debug.LogWarning(
                $"[MedicalInventoryService.Consume] RefreshItemInData failed for item {record.Item.InstanceID}.");
        }
        else
        {
            record.Controller.AdjustWeight(-record.Item.Data.WeightGrams);
            record.Controller.NotifyItemQuantityChanged(record.Item);
        }

        MarkDirty();
        return true;
    }

    // Quantity == 1
    if (record.IsFromSavedTree)
    {
        if (record.OwnerBackpack == null)
        {
            UnityEngine.Debug.LogWarning(
                $"[MedicalInventoryService.Consume] OwnerBackpack is null for SavedTree item {record.Item.InstanceID}.");
            return false;
        }

        if (!RemoveSavedItem(record.OwnerBackpack, record.Item.InstanceID))
        {
            UnityEngine.Debug.LogWarning(
                $"[MedicalInventoryService.Consume] SavedItem {record.Item.InstanceID} not found in owner backpack.");
            return false;
        }

        MarkDirty();
        return true;
    }

    if (record.Controller == null)
    {
        UnityEngine.Debug.LogWarning(
            $"[MedicalInventoryService.Consume] Controller is null for live item {record.Item.InstanceID}.");
        return false;
    }

    if (!record.Controller.RemoveItem(record.Item))
    {
        UnityEngine.Debug.LogWarning(
            $"[MedicalInventoryService.Consume] RemoveItem failed for item {record.Item.InstanceID}.");
        return false;
    }

    MarkDirty();
    return true;
}

/// <summary>Uses exact charge from the current live item or authoritative closed-backpack DTO.</summary>
public bool TryConsumeCharge(MedicalItemRecord record, float amount, Action applyEffect)
{
    var item = record.Item;
    if (item?.Data == null || !item.Data.HasIndividualCharge || item.Quantity != 1 || applyEffect == null ||
        float.IsNaN(amount) || float.IsInfinity(amount) || amount <= 0f || amount > item.RemainingChargeAmount)
        return false;
    if (!record.IsFromSavedTree)
    {
        if (record.Controller == null || !record.Controller.TryConsumeCharge(item, amount, applyEffect)) return false;
        MarkDirty();
        return true;
    }
    var ownerController = FindBackpackOwner(record.OwnerBackpack, _pockets, 0) ??
        FindBackpackOwner(record.OwnerBackpack, _pocket2, 0) ?? FindBackpackOwner(record.OwnerBackpack, _backpack, 0);
    if (ownerController == null) return false;
    float remaining = UnityEngine.Mathf.Max(0f, item.RemainingChargeAmount - amount);
    var replacement = ReplaceSavedCharge(record.OwnerBackpack.GetBackpackContentsRaw(), record.SavedItem,
        item.RemainingChargeAmount, remaining, item.FullChargeCapacity, 0, out bool updated);
    if (!updated) return false;
    record.OwnerBackpack.ReplaceBackpackContents(replacement);
    ownerController.RefreshItemInData(record.OwnerBackpack);
    item.RemainingChargeAmount = remaining;
    MarkDirty();
    try { applyEffect(); } catch (Exception exception) { UnityEngine.Debug.LogException(exception); }
    try { ownerController.NotifyItemQuantityChanged(record.OwnerBackpack); }
    catch (Exception exception) { UnityEngine.Debug.LogException(exception); }
    return true;
}

private InventoryController FindBackpackOwner(InventoryItem backpack, InventoryController controller, int depth)
{
    if (backpack == null || controller == null || controller.IsDisposed || depth > MAX_RECURSION_DEPTH) return null;
    if (ReferenceEquals(controller.GetItemByInstanceID(backpack.InstanceID), backpack)) return controller;
    for (int y = 0; y < controller.Height; y++)
    for (int x = 0; x < controller.Width; x++)
    {
        var candidate = controller.GetItemAt(x, y);
        if (candidate?.Data?.IsBackpack != true || !controller.IsRootCell(candidate.InstanceID, x, y)) continue;
        var found = FindBackpackOwner(backpack, _backpackManager?.GetLiveController(candidate.InstanceID.ToString()), depth + 1);
        if (found != null) return found;
    }
    return null;
}

private List<SavedItem> ReplaceSavedCharge(IReadOnlyList<SavedItem> source, SavedItem expected,
    float before, float remaining, float capacity, int depth, out bool updated)
{
    updated = false;
    if (source == null || depth > MAX_RECURSION_DEPTH) return null;
    var result = new List<SavedItem>(source.Count);
    foreach (var entry in source)
    {
        var child = entry;
        if (!updated && child.InstanceID == expected.InstanceID)
        {
            float stored = child.RemainingChargeSeconds == -1f ? child.ChargePercent / 100f * capacity : child.RemainingChargeSeconds;
            if (child.ItemID != expected.ItemID || child.Quantity != 1 || stored != before) return null;
            updated = true;
            if (remaining <= 0f) continue;
            child.RemainingChargeSeconds = remaining;
            child.ChargePercent = UnityEngine.Mathf.Clamp(UnityEngine.Mathf.CeilToInt(remaining / capacity * 100f), 1, 100);
        }
        else if (!updated && child.BackpackContents != null)
        {
            var nested = ReplaceSavedCharge(child.BackpackContents, expected, before, remaining, capacity,
                depth + 1, out bool nestedUpdated);
            if (nestedUpdated) { child.BackpackContents = nested; updated = true; }
        }
        result.Add(child);
    }
    return result;
}

/// <summary>Удаляет SavedItem с указанным InstanceID из дерева OwnerBackpack.</summary>
private bool RemoveSavedItem(InventoryItem ownerBackpack, uint targetInstanceId)
{
    if (ownerBackpack == null) return false;

    var raw = ownerBackpack.GetBackpackContentsRaw();
    if (raw == null) return false;

    var newList = RemoveSavedItemRecursive(raw, targetInstanceId, 0, out bool removed);
    if (!removed) return false;

    ownerBackpack.ReplaceBackpackContents(newList);
    return true;
}

private List<SavedItem> RemoveSavedItemRecursive(
    IReadOnlyList<SavedItem> source,
    uint targetInstanceId,
    int depth,
    out bool removed)
{
    removed = false;
    if (source == null || depth > MAX_RECURSION_DEPTH)
        return null;

    var result = new List<SavedItem>(source.Count);

    for (int i = 0; i < source.Count; i++)
    {
        var child = source[i];

        if (!removed && child.InstanceID == targetInstanceId)
        {
            removed = true;
            continue;
        }

        if (!removed && child.BackpackContents != null && child.BackpackContents.Count > 0)
        {
            var nested = RemoveSavedItemRecursive(
                child.BackpackContents, targetInstanceId, depth + 1, out bool nestedRemoved);

            if (nestedRemoved)
            {
                child.BackpackContents = nested;
                removed = true;
            }
        }

        result.Add(child);
    }

    return result;
}

/// <summary>Обновляет Quantity у SavedItem с указанным InstanceID в дереве OwnerBackpack.</summary>
private bool UpdateSavedItemQuantity(
    InventoryItem ownerBackpack,
    uint targetInstanceId,
    int newQuantity)
{
    if (ownerBackpack == null) return false;

    var raw = ownerBackpack.GetBackpackContentsRaw();
    if (raw == null) return false;

    var newList = UpdateSavedItemQuantityRecursive(
        raw, targetInstanceId, newQuantity, 0, out bool updated);

    if (!updated) return false;

    ownerBackpack.ReplaceBackpackContents(newList);
    return true;
}

private List<SavedItem> UpdateSavedItemQuantityRecursive(
    IReadOnlyList<SavedItem> source,
    uint targetInstanceId,
    int newQuantity,
    int depth,
    out bool updated)
{
    updated = false;
    if (source == null || depth > MAX_RECURSION_DEPTH)
        return null;

    var result = new List<SavedItem>(source.Count);

    for (int i = 0; i < source.Count; i++)
    {
        var child = source[i];

        if (!updated && child.InstanceID == targetInstanceId)
        {
            child.Quantity = newQuantity;
            updated = true;
        }
        else if (!updated && child.BackpackContents != null && child.BackpackContents.Count > 0)
        {
            var nested = UpdateSavedItemQuantityRecursive(
                child.BackpackContents, targetInstanceId, newQuantity, depth + 1, out bool nestedUpdated);

            if (nestedUpdated)
            {
                child.BackpackContents = nested;
                updated = true;
            }
        }

        result.Add(child);
    }

    return result;
}
        private void TraverseSavedItems(
            List<SavedItem> items,
            InventoryItem ownerBackpack,
            int depth)
        {
            if (items == null || depth > MAX_RECURSION_DEPTH) return;
            if (_itemDatabase == null) return;

            for (int i = 0; i < items.Count; i++)
            {
                var saved = items[i];
                if (saved.InstanceID == 0) continue;
                if (!_visited.Add(saved.InstanceID)) continue;

                var template = _itemDatabase.GetItemData(saved.ItemID);
                if (template == null) continue;

                bool isMedical = _medicalDatabase.IsMedical(saved.ItemID);
                bool isNonEmptyBackpack = template.IsBackpack
                    && saved.BackpackContents != null
                    && saved.BackpackContents.Count > 0;

                // Материализация нужна только если предмет попадёт в кэш (медикамент)
                // или если внутрь него нужно рекурсивно спуститься (непустой рюкзак).
                // В остальных случаях FromSaveData не вызывается вообще — это
                // устраняет двойную аллокацию и, что важнее, двойной InventoryItem
                // с одинаковым InstanceID для одного SavedItem (аптечка-контейнер).
                // UI Этапа 5 теперь получает ровно одну ссылку на предмет.
                if (!isMedical && !isNonEmptyBackpack) continue;

                var item = InventoryItem.FromSaveData(saved, template);
                if (item == null) continue;

                if (isMedical)
                {
                    _cache.Add(new MedicalItemRecord(
                        item,
                        null,
                        GridType.Container,
                        saved.X,
                        saved.Y,
                        ownerBackpack,
                        true,
                        saved));
                }

                if (isNonEmptyBackpack)
                {
                    // Materialized nested backpacks are copies. Commit consumption
                    // through the original live owner and its complete saved tree.
                    TraverseSavedItems(saved.BackpackContents, ownerBackpack, depth + 1);
                }
            }
        }
    }
}
