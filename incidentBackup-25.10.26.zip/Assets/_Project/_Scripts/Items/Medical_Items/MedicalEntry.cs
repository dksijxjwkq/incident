
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Одна запись матрицы совместимости:
    /// какой ItemID к каким зонам применим, что лечит, сколько применяется,
    /// прерывается ли уроном.
    ///
    /// 6.4.2: добавлены 3 опциональных поля — HPRestoreAmount, BloodRestoreMl,
    /// EffectDuration. В конструктор не вынесены (defaults из SerializeField).
    /// </summary>
    [System.Serializable]
    public class MedicalEntry
    {
        [SerializeField] private string _itemID;
        [SerializeField] private string _displayName;

        [SerializeField] private BodyPartMask _validParts = BodyPartMask.None;
        [SerializeField] private MedicalEffect _effects = MedicalEffect.None;

        [SerializeField, Min(0f)] private float _useDuration = 1f;
        [SerializeField] private bool _cancelableByDamage = true;

        // ═══ Этап 6.4: параметры эффектов ═══
        [SerializeField, Min(0f), Tooltip("Сколько HP восстановить при HPRestore (за один apply).")]
        private float _hpRestoreAmount = 20f;

        [SerializeField, Min(0f), Tooltip("Сколько мл крови восстановить при BloodRestore.")]
        private float _bloodRestoreMl = 500f;

        [SerializeField, Min(0f), Tooltip("Длительность эффекта для Painkiller / HealBoost (сек).")]
        private float _effectDuration = 120f;

        public string ItemID => _itemID;
        public string DisplayName => _displayName;
        // Compatibility rules are resolved on read, so existing scene/asset data
        // and every consumer of the entry agree without rewriting serialized fields.
        public BodyPartMask ValidParts => MedicalDatabase.ResolveValidParts(_itemID, Effects, _validParts);
        public MedicalEffect Effects => MedicalDatabase.ResolveEffects(_itemID, _effects);
        public float UseDuration => _useDuration;
        public bool CancelableByDamage => _cancelableByDamage;

        // ═══ Этап 6.4: геттеры параметров эффектов ═══
        public float HPRestoreAmount => _hpRestoreAmount;
        public float BloodRestoreMl => _bloodRestoreMl;
        public float EffectDuration => _effectDuration;

        // Only the freshly generated template is repaired; configured assets are not migrated here.
        internal void ConfigureTransamachaTemplate()
        {
            if (_displayName == "Трансамача") _effects = MedicalEffect.Transamacha;
        }

        // Stage 4: narrow asset repair preserves every unrelated serialized field.
        internal bool ConfigureMechanicalJETT()
        {
            var parents = BodyPartMask.LeftShoulder | BodyPartMask.RightShoulder |
                BodyPartMask.LeftQuadriceps | BodyPartMask.RightQuadriceps;
            var effects = (_effects & ~MedicalEffect.InternalBleeding) | MedicalEffect.JETT;
            if (_validParts == parents && _effects == effects) return false;
            _validParts = parents;
            _effects = effects;
            return true;
        }

        public MedicalEntry() { }

        public MedicalEntry(
            string itemID,
            string displayName,
            BodyPartMask validParts,
            MedicalEffect effects,
            float useDuration,
            bool cancelableByDamage)
        {
            _itemID = itemID;
            _displayName = displayName;
            _validParts = validParts;
            _effects = effects;
            _useDuration = Mathf.Max(0f, useDuration);
            _cancelableByDamage = cancelableByDamage;
        }
    }
}
