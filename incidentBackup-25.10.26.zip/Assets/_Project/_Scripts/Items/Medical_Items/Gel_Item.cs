using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Stage 1 (§10.4): гель per-segment.
    /// Активирует HealBoost только на указанном сегменте.
    ///
    /// НЕ реализует drag-drop — это задача UI-итерации
    /// (K_BodyPartDragOut на Image сегмента куклы).
    ///
    /// Интеграция с MedicalDatabase / MedicalEffectApplier — отдельная задача
    /// UI/инвентарь-этапа. Сейчас API применяется напрямую (см. K_CombatTestController).
    ///
    /// TODO(Stage 11/13): при интеграции с ItemDatabase назначить уникальный
    /// PrefabID. Значение 2001 — временный placeholder, НЕ совпадает с
    /// реальным ItemData в проекте. Не использовать как ключ в ассетах.
    /// </summary>
    public class K_GelItem : MonoBehaviour
    {
        // Stage 1: используется будущим Inventory-слоем. Сейчас — placeholder.
        // TODO(Stage 11/13): заменить на ID из ItemDatabase при интеграции.
        public ushort RequiredPrefabID => 2001;

        [Header("References")]
        [SerializeField] private K_HealthSystem _healthSystem;

        [Header("Icon (placeholder)")]
        [SerializeField] private bool _iconVisible;
        [SerializeField] private float _iconShowTimer;

        public bool IsIconVisible => _iconVisible;
        public float IconShowTimer => _iconShowTimer;

        private void Awake()
        {
            if (_healthSystem == null)
                _healthSystem = GetComponent<K_HealthSystem>();
        }

        private void Update()
        {
            if (!_iconVisible) return;
            if (_iconShowTimer <= 0f) return;

            _iconShowTimer -= Time.deltaTime;
            if (_iconShowTimer <= 0f)
            {
                _iconShowTimer = 0f;
                _iconVisible = false;
            }
        }

        /// <summary>
        /// Применить гель на конкретный сегмент.
        /// duration &lt;= 0 → K_HealthSystem возьмёт _healBoostDuration.
        /// Default = 120с (спека ч.10.4).
        /// </summary>
        public bool UseGel(BodyPart part, float duration = 120f)
        {
            if (_healthSystem == null)
            {
                Debug.LogWarning("[K_GelItem] K_HealthSystem not found — gel skipped.");
                return false;
            }

            if (!_healthSystem.TryResolveHealBoostDuration(part, duration, out float acceptedDuration)) return false;
            duration = acceptedDuration;
            _healthSystem.ActivateHealBoost(part, duration);

            _iconVisible = true;
            _iconShowTimer = duration;

            Debug.Log($"[K_GelItem] Gel applied on {part} for {duration:F1}s.");
            return true;
        }

        public bool ShouldShowIcon() => _iconVisible && _iconShowTimer > 0f;

        [ContextMenu("Debug: Use Gel on Chest")]
        private void DebugUseGelChest() => UseGel(BodyPart.Chest);

        [ContextMenu("Debug: Use Gel on Left Quadriceps")]
        private void DebugUseGelLeftQuad() => UseGel(BodyPart.LeftQuadriceps);
    }
}
