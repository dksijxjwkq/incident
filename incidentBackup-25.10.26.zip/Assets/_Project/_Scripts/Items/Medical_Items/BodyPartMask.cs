namespace K_Incident.Core
{
    /// <summary>
    /// Маска 20 анатомических сегментов.
    /// Один бит = один BodyPart. Группы Arms/Legs/All — только удобные алиасы,
    /// они не заменяют отдельные сегменты.
    /// </summary>
    [System.Flags]
    public enum BodyPartMask : uint
    {
        None = 0u,

        Head = 1u << 0,
        Chest = 1u << 1,
        Stomach = 1u << 2,
        Pelvis = 1u << 3,

        LeftShoulder = 1u << 4,
        RightShoulder = 1u << 5,
        LeftBiceps = 1u << 6,
        RightBiceps = 1u << 7,
        LeftForearm = 1u << 8,
        RightForearm = 1u << 9,
        LeftHand = 1u << 10,
        RightHand = 1u << 11,

        LeftQuadriceps = 1u << 12,
        RightQuadriceps = 1u << 13,
        LeftKnee = 1u << 14,
        RightKnee = 1u << 15,
        LeftShin = 1u << 16,
        RightShin = 1u << 17,
        LeftFoot = 1u << 18,
        RightFoot = 1u << 19,

        Arms = LeftShoulder | RightShoulder |
               LeftBiceps | RightBiceps |
               LeftForearm | RightForearm |
               LeftHand | RightHand,

        Legs = LeftQuadriceps | RightQuadriceps |
               LeftKnee | RightKnee |
               LeftShin | RightShin |
               LeftFoot | RightFoot,

        All = Arms | Legs | Head | Chest | Stomach | Pelvis
    }

    public static class BodyPartMaskExtensions
    {
        /// <summary>
        /// Проверяет, входит ли конкретный BodyPart в маску.
        /// </summary>
        public static bool Has(this BodyPartMask mask, BodyPart part)
            => (mask & part.ToMask()) != 0;

        /// <summary>
        /// Преобразует BodyPart в один бит маски.
        /// </summary>
        public static BodyPartMask ToMask(this BodyPart part)
            => (BodyPartMask)(1u << (int)part);
    }
}