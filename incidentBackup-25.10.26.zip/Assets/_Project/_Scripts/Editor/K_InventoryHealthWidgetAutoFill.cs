#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using K_Incident.Core;
using K_Incident.Core.UI;   // ← K_HealthWidget

namespace K_Incident.EditorTools
{
    /// <summary>
    /// Умное автозаполнение K_InventoryHealthWidget.
    ///
    /// Логика:
    ///   1. Image/TMP сегментов и иконок — ищем в ПОДДЕРЕВЕ целевой куклы по имени.
    ///   2. Градиенты/цвета — копируем с любого K_HealthWidget в сцене (HUD).
    ///   3. Системные ссылки — FindFirstObjectByType.
    ///
    /// Меню: Incident → Tools → Auto-Fill Inventory Health Widget (Smart)
    /// </summary>
    public static class K_InventoryHealthWidgetAutoFill
    {
        // Имена Image-иконок в поддереве (правь под свою сцену при необходимости).
        private static readonly string[] IconNames =
        {
            "Icon_Hunger", "Icon_Thirst", "Icon_Radiation", "Icon_Cold",
            "Icon_Overload", "Icon_Bleeding", "Icon_Laceration", "Icon_Hangover",
            "Icon_Drunk", "Icon_Stim_On", "Icon_Stim_Off", "Icon_Coagulant",
            "Icon_Fracture", "Icon_Gunshot",
            "Debuff_Concussion", "Debuff_TBI", "Debuff_Breathing",
            "Debuff_Immobilized", "Debuff_InternalBleeding",
        };

        // Соответствие "поле виджета" → "имя GameObject в поддереве".
        private static readonly (string field, string[] candidateNames)[] IconFields =
        {
            ("_iconHunger",              new[]{ "Icon_Hunger" }),
            ("_iconThirst",              new[]{ "Icon_Thirst" }),
            ("_iconRadiation",           new[]{ "Icon_Radiation" }),
            ("_iconCold",                new[]{ "Icon_Cold" }),
            ("_iconOverload",            new[]{ "Icon_Overload" }),
            ("_iconBleeding",            new[]{ "Icon_Bleeding" }),
            ("_iconLaceration",          new[]{ "Icon_Laceration" }),
            ("_iconHangover",            new[]{ "Icon_Hangover" }),
            ("_iconDrunk",               new[]{ "Icon_Drunk" }),
            ("_iconStimOn",              new[]{ "Icon_Stim_On", "Icon_StimOn" }),
            ("_iconStimOff",             new[]{ "Icon_Stim_Off", "Icon_StimOff" }),
            ("_iconCoagulant",           new[]{ "Icon_Coagulant" }),
            ("_iconFracture",            new[]{ "Icon_Fracture", "Debuff_Fracture" }),
            ("_iconGunshot",             new[]{ "Icon_Gunshot" }),
            ("_iconConcussion",          new[]{ "Debuff_Concussion" }),
            ("_iconTBI",                 new[]{ "Debuff_TBI" }),
            ("_iconBreathingDifficulty", new[]{ "Debuff_Breathing" }),
            ("_iconImmobilized",         new[]{ "Debuff_Immobilized" }),
            ("_iconInternalBleeding",    new[]{ "Debuff_InternalBleeding" }),
        };

        private static readonly (string field, string[] candidateNames)[] TextFields =
        {
            ("_bloodText",         new[]{ "BloodText", "Text_Blood" }),
            ("_ibCountText",       new[]{ "IbCountText", "IB_Count", "IbCount" }),
            ("_fractureCountText", new[]{ "FractureCountText", "Fracture_Count" }),
        };

        [MenuItem("Incident/Tools/Auto-Fill Inventory Health Widget (Smart)")]
        public static void AutoFill()
        {
            var widgets = Object.FindObjectsByType<K_InventoryHealthWidget>(
                FindObjectsInactive.Include, FindObjectsSortMode.None);

            if (widgets == null || widgets.Length == 0)
            {
                Debug.LogError("[AutoFill] K_InventoryHealthWidget не найден в сцене. " +
                               "Сначала Add Component на куклу инвентаря.");
                return;
            }

            // Найти любой HUD-виджет для копирования градиентов/цветов.
            var hudWidgets = Object.FindObjectsByType<K_HealthWidget>(
                FindObjectsInactive.Include, FindObjectsSortMode.None);
            K_HealthWidget hudSrc = null;
            foreach (var h in hudWidgets)
            {
                if (h.gameObject.GetComponent<K_InventoryHealthWidget>() != null) continue;
                hudSrc = h; break;
            }
            if (hudSrc == null)
                Debug.LogWarning("[AutoFill] HUD-виджет K_HealthWidget не найден — " +
                                 "градиенты/цвета придётся назначить вручную.");

            foreach (var widget in widgets)
                FillWidget(widget, hudSrc);
        }

        private static void FillWidget(K_InventoryHealthWidget widget, K_HealthWidget hudSrc)
        {
            var so = new SerializedObject(widget);
            var root = widget.gameObject;
            Debug.Log($"[AutoFill] === Обрабатываю '{root.name}' ===");
            PreviewSubtreeAssignments(so, root);

            // 1. Системные ссылки.
            FillRefIfEmpty(so, "_healthSystem",   Object.FindFirstObjectByType<K_HealthSystem>(FindObjectsInactive.Include));
            FillRefIfEmpty(so, "_vitalitySystem", Object.FindFirstObjectByType<K_VitalitySystem>(FindObjectsInactive.Include));
            FillRefIfEmpty(so, "_weightManager",  Object.FindFirstObjectByType<K_WeightManager>(FindObjectsInactive.Include));
            FillRefIfEmpty(so, "_bloodSystem",    Object.FindFirstObjectByType<K_BloodSystem>(FindObjectsInactive.Include));
            FillRefIfEmpty(so, "_debuffSystem",   Object.FindFirstObjectByType<K_DebuffSystem>(FindObjectsInactive.Include));

            // 2. Градиенты/цвета — копируем с HUD.
            if (hudSrc != null)
                CopyVisualAssets(new SerializedObject(hudSrc), so);

            // 3. 20 Image сегментов — автопоиск по имени в поддереве.
            FillSegmentImages(so, root);

            // 4. Иконки.
            int foundIcons = 0;
            foreach (var (field, candidates) in IconFields)
                if (FillImage(so, field, candidates, root)) foundIcons++;
            Debug.Log($"[AutoFill] Иконки: найдено {foundIcons}/{IconFields.Length}.");

            // 5. TMP.
            int foundText = 0;
            foreach (var (field, candidates) in TextFields)
                if (FillTmp(so, field, candidates, root)) foundText++;
            Debug.Log($"[AutoFill] TMP: найдено {foundText}/{TextFields.Length}.");

            // 6. Спрайты оверлеев Этапа 4 — оставим на пользователя.
            WarnIfMissing(so, "_tourniquetAppliedIcon");
            WarnIfMissing(so, "_jettAppliedIcon");

            so.ApplyModifiedProperties();
            EditorUtility.SetDirty(widget);
            Debug.Log($"[AutoFill] Готово для '{root.name}'.");
        }

        // ─── helpers ───

        private static void FillRefIfEmpty(SerializedObject so, string field, Object value)
        {
            if (value == null) return;
            var prop = so.FindProperty(field);
            if (prop == null || prop.objectReferenceValue != null) return;
            prop.objectReferenceValue = value;
        }

        private static void WarnIfMissing(SerializedObject so, string field)
        {
            var prop = so.FindProperty(field);
            if (prop != null && prop.objectReferenceValue == null)
                Debug.LogWarning($"[AutoFill] Поле '{field}' пустое — назначь вручную.");
        }

        private static bool FillImage(SerializedObject so, string field, string[] candidates, GameObject root)
        {
            var prop = so.FindProperty(field);
            if (prop == null) return false;
            if (!IsReferenceInSubtree(prop, root, field)) return false;
            if (prop.objectReferenceValue != null) return true;

            foreach (var name in candidates)
            {
                var img = FindComponentInChildren<Image>(root, name);
                if (img != null) { prop.objectReferenceValue = img; return true; }
            }
            return false;
        }

        private static bool FillTmp(SerializedObject so, string field, string[] candidates, GameObject root)
        {
            var prop = so.FindProperty(field);
            if (prop == null) return false;
            if (!IsReferenceInSubtree(prop, root, field)) return false;
            if (prop.objectReferenceValue != null) return true;

            foreach (var name in candidates)
            {
                var tmp = FindComponentInChildren<TextMeshProUGUI>(root, name);
                if (tmp != null) { prop.objectReferenceValue = tmp; return true; }
            }
            return false;
        }

        private static T FindComponentInChildren<T>(GameObject root, string name) where T : Component
        {
            var all = root.GetComponentsInChildren<T>(true);
            T unique = null;
            foreach (var candidate in all)
            {
                if (!MatchesCurrentName(candidate.gameObject.name, name)) continue;
                if (unique != null)
                {
                    Debug.LogError($"[AutoFill] Неоднозначное имя/alias '{name}' в '{root.name}'; назначение не выполнено.");
                    return null;
                }
                unique = candidate;
            }
            if (unique != null) return unique;
            foreach (var c in all)
                if (c.gameObject.name == name) return c;
            return null;
        }

        private static bool MatchesCurrentName(string actual, string expected)
        {
            if (actual == expected) return true;
            return (expected == "Icon_Gunshot" && actual == "Icon_GunShot") ||
                   (expected == "Icon_Coagulant" && actual == "Icon_Gel") ||
                   ((expected == "FractureCountText" || expected == "Fracture_Count") &&
                    (actual == "FractureCountText" || actual == "Fracture_Count" || actual == "IconFractureText"));
        }

        private static bool IsReferenceInSubtree(SerializedProperty property, GameObject root, string label)
        {
            if (property.objectReferenceValue == null) return true;
            var component = property.objectReferenceValue as Component;
            if (component != null && (component.gameObject == root || component.transform.IsChildOf(root.transform))) return true;
            Debug.LogWarning($"[AutoFill] PREVIEW: '{label}' у '{root.name}' ссылается вне своего поддерева; назначение сохранено. Исправьте через C06 или вручную.");
            return false;
        }

        private static void PreviewSubtreeAssignments(SerializedObject serialized, GameObject root)
        {
            int foreign = 0;
            foreach (var entry in IconFields)
            {
                var property = serialized.FindProperty(entry.field);
                if (property != null && !IsReferenceInSubtree(property, root, entry.field)) foreign++;
            }
            foreach (var entry in TextFields)
            {
                var property = serialized.FindProperty(entry.field);
                if (property != null && !IsReferenceInSubtree(property, root, entry.field)) foreign++;
            }
            var segments = serialized.FindProperty("_segmentImages");
            if (segments != null && segments.isArray)
                for (int i = 0; i < segments.arraySize; i++)
                    if (!IsReferenceInSubtree(segments.GetArrayElementAtIndex(i), root, "_segmentImages[" + i + "]")) foreign++;
            Debug.Log($"[AutoFill] PREVIEW '{root.name}': внешних visual references {foreign}; они не переназначаются автоматически.");
        }

        [MenuItem("Incident/Tools/Preview Inventory Health Widget References (read only)")]
        public static void PreviewReferences()
        {
            var widgets = Object.FindObjectsByType<K_InventoryHealthWidget>(FindObjectsInactive.Include, FindObjectsSortMode.None);
            if (widgets == null || widgets.Length == 0)
            {
                Debug.LogError("[AutoFill] K_InventoryHealthWidget не найден; preview не выполнен.");
                return;
            }
            foreach (var widget in widgets)
                PreviewSubtreeAssignments(new SerializedObject(widget), widget.gameObject);
        }

        /// <summary>
        /// Заполнить _segmentImages[20] — ищет Image по префиксу:
        /// Seg_00_*, Segment_00_*, Part_00_*, BodyPart_00_* и т.п.
        /// Также подстраховывается: любой Image, содержащий "00" или "Head", и т.д.
        /// </summary>
        private static void FillSegmentImages(SerializedObject so, GameObject root)
        {
            var prop = so.FindProperty("_segmentImages");
            if (prop == null || !prop.isArray) return;

            bool needsFill = prop.arraySize != 20;
            if (!needsFill)
                for (int i = 0; i < 20; i++)
                    if (prop.GetArrayElementAtIndex(i).objectReferenceValue == null)
                    { needsFill = true; break; }
            if (!needsFill) { Debug.Log("[AutoFill] Сегменты уже заполнены."); return; }

            prop.arraySize = 20;

            // BodyPart-имена по индексу — для fallback-поиска.
            string[] bodyPartNames =
            {
                "Head", "Chest", "Stomach", "Pelvis",
                "LeftShoulder", "RightShoulder",
                "LeftBiceps", "RightBiceps",
                "LeftForearm", "RightForearm",
                "LeftHand", "RightHand",
                "LeftQuadriceps", "RightQuadriceps",
                "LeftKnee", "RightKnee",
                "LeftShin", "RightShin",
                "LeftFoot", "RightFoot"
            };

            var allImages = root.GetComponentsInChildren<Image>(true);
            int found = 0;

            for (int i = 0; i < 20; i++)
            {
                var el = prop.GetArrayElementAtIndex(i);
                if (el.objectReferenceValue != null) { found++; continue; }

                // Кандидаты префиксов (разные проекты — разные конвенции).
                string idx2 = i.ToString("D2");
                string[] prefixes =
                {
                    $"Seg_{idx2}_",
                    $"Segment_{idx2}_",
                    $"Part_{idx2}_",
                    $"BodyPart_{idx2}_",
                    $"Seg_{i}_",
                    $"Segment_{i}_",
                    $"Part_{i}_",
                };

                Image best = null;
                foreach (var img in allImages)
                {
                    foreach (var p in prefixes)
                        if (img.gameObject.name.StartsWith(p)) { best = img; break; }
                    if (best != null) break;
                }

                // Fallback: искать по имени BodyPart (без индекса).
                if (best == null)
                {
                    string bp = bodyPartNames[i];
                    foreach (var img in allImages)
                        if (img.gameObject.name.Contains(bp)) { best = img; break; }
                }

                if (best != null) { el.objectReferenceValue = best; found++; }
            }
            Debug.Log($"[AutoFill] Сегменты: найдено {found}/20.");
            if (found < 20)
                Debug.LogWarning("[AutoFill] Часть сегментов не найдена — " +
                                 "проверь имена Image в иерархии куклы.");
        }

        /// <summary>
        /// Копирует Gradient'ы и Color'ы с HUD-виджета. Image/TMP НЕ копирует —
        /// они принадлежат разным куклам.
        /// </summary>
        private static void CopyVisualAssets(SerializedObject src, SerializedObject dst)
        {
            string[] gradientFields =
            {
                "_healthGradient", "_statusGradient", "_bleedingGradient",
                "_hungerGradient", "_thirstGradient", "_radiationGradient",
                "_overloadGradient", "_bloodTextGradient",
            };

            int copied = 0;
            foreach (var field in gradientFields)
            {
                var srcProp = src.FindProperty(field);
                var dstProp = dst.FindProperty(field);
                if (srcProp == null || dstProp == null) continue;
                if (srcProp.propertyType != SerializedPropertyType.Gradient) continue;

                dstProp.gradientValue = srcProp.gradientValue;
                copied++;
            }

            // Цвета-константы копируем как Color.
            string[] colorFields = { "_coagulantIconColor" };
            foreach (var field in colorFields)
            {
                var srcProp = src.FindProperty(field);
                var dstProp = dst.FindProperty(field);
                if (srcProp == null || dstProp == null) continue;
                if (srcProp.propertyType != SerializedPropertyType.Color) continue;
                dstProp.colorValue = srcProp.colorValue;
                copied++;
            }

            Debug.Log($"[AutoFill] Скопировано визуальных ассетов с HUD: {copied}.");
        }
    }
}
#endif
