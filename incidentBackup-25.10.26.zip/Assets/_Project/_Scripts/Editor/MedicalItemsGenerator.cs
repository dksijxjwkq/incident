#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;
using System.IO;
using K_Incident.Core.Inventory;
using System;
using System.Collections.Generic;

namespace K_Incident.EditorTools
{
    public static class MedicalItemsGenerator
    {
        // Папка для новых ItemStaticData. Скрипт создаст её, если нет.
        private const string OUTPUT_FOLDER = "Assets/_Project/_Scripts/Items/Medical_Items/Data";

        private struct MedDef
        {
            public string itemID;
            public string displayName;
            public int sizeX, sizeY;
            public int weightGrams;
            public int stackLimit;
            public ushort prefabID;
            public ChargeCategory chargeCategory;
            public float fullChargeSeconds;
        }

        private static readonly MedDef[] Definitions = new[]
        {
            new MedDef { itemID = "splint_wood",     displayName = "Деревянная шина",      sizeX=2, sizeY=1, weightGrams=300, stackLimit=1,  prefabID=3001 },
            new MedDef { itemID = "splint_sam",      displayName = "SAM Splint",            sizeX=1, sizeY=1, weightGrams=150, stackLimit=1,  prefabID=3002 },
            new MedDef { itemID = "collar_neck",     displayName = "Шейный воротник",       sizeX=2, sizeY=1, weightGrams=250, stackLimit=1,  prefabID=3003 },
            new MedDef { itemID = "surgery_kit",     displayName = "Хирургический набор",   sizeX=2, sizeY=2, weightGrams=800, stackLimit=1,  prefabID=3004 },
            new MedDef { itemID = "tourniquet",      displayName = "Жгут / Турникет",       sizeX=1, sizeY=1, weightGrams=100, stackLimit=3,  prefabID=3005 },
            new MedDef { itemID = "bandage",         displayName = "Бинт",                  sizeX=1, sizeY=1, weightGrams=50,  stackLimit=10, prefabID=3006 },
            new MedDef { itemID = "hemostatic",      displayName = "Гемостатик",            sizeX=1, sizeY=1, weightGrams=80,  stackLimit=5,  prefabID=3007 },
            new MedDef { itemID = "glue_medical",    displayName = "Медицинский клей",      sizeX=1, sizeY=1, weightGrams=40,  stackLimit=5,  prefabID=3008 },
            new MedDef { itemID = "strips_wound",    displayName = "Шовные пластыри",       sizeX=1, sizeY=1, weightGrams=30,  stackLimit=10, prefabID=3009 },
            new MedDef { itemID = "stapler_medical", displayName = "Медицинский степлер",   sizeX=1, sizeY=2, weightGrams=400, stackLimit=1,  prefabID=3010 },
            new MedDef { itemID = "transfusion",     displayName = "Трансфузия",            sizeX=1, sizeY=1, weightGrams=200, stackLimit=1,  prefabID=3011 },
            new MedDef { itemID = "stimulator",      displayName = "Стимулятор",            sizeX=1, sizeY=1, weightGrams=60,  stackLimit=3,  prefabID=3012 },
            new MedDef { itemID = "painkiller",      displayName = "Обезбол",               sizeX=1, sizeY=1, weightGrams=30,  stackLimit=5,  prefabID=3013 },
            new MedDef { itemID = "gel_heal",        displayName = "Гель / Аптечка HP",     sizeX=1, sizeY=1, weightGrams=80,  stackLimit=3,  prefabID=3014 },
            // ── Этап 3: спец-средства IB ──
            new MedDef { itemID = "coagulant",       displayName = "Коагулянт",             sizeX=1, sizeY=1, weightGrams=80,  stackLimit=3,  prefabID=3015 },
            new MedDef { itemID = "transamacha",     displayName = "Трансамача",            sizeX=1, sizeY=1, weightGrams=100, stackLimit=3,  prefabID=3016 },
            new MedDef { itemID = "jett",            displayName = "JETT",                  sizeX=1, sizeY=2, weightGrams=250, stackLimit=1,  prefabID=3017 },
        };

        // D-ED01: retain the original definition literals; normalize the complete
        // mechanical-device schema once before any generation. Existing assets
        // are never migrated by this generator.
        static MedicalItemsGenerator()
        {
            for (int i = 0; i < Definitions.Length; i++)
            {
                var def = Definitions[i];
                bool timed = def.itemID == "tourniquet" || def.itemID == "jett";
                def.chargeCategory = timed ? ChargeCategory.DurationPercent : ChargeCategory.None;
                def.fullChargeSeconds = 420f;
                if (timed) def.stackLimit = 1;
                Definitions[i] = def;
            }
        }

        [MenuItem("Incident/Tools/Generate Medical ItemStaticData")]
        public static void GenerateAll()
        {
            // ── 1. Найти ItemDatabase.asset в проекте ──
            var guids = AssetDatabase.FindAssets("t:ItemDatabase");
            if (guids == null || guids.Length == 0)
            {
                Debug.LogError("[MedicalGen] ItemDatabase.asset НЕ НАЙДЕН в проекте. Проверь, что он вообще создан (Create → Incident → Inventory → Item Database).");
                return;
            }
            if (guids.Length > 1)
            {
                Debug.LogError("[MedicalGen] Найдено несколько ItemDatabase; выбор неоднозначен. Ничего не изменено.");
                return;
            }
            if (guids.Length > 1)
            {
                Debug.LogWarning($"[MedicalGen] Найдено {guids.Length} ItemDatabase.asset. Использую первый.");
            }
            string dbPath = AssetDatabase.GUIDToAssetPath(guids[0]);
            Debug.Log($"[MedicalGen] ItemDatabase найден: {dbPath}");

            var db = AssetDatabase.LoadAssetAtPath<ItemDatabase>(dbPath);
            if (db == null)
            {
                Debug.LogError($"[MedicalGen] Не удалось загрузить ItemDatabase из {dbPath}");
                return;
            }

            if (!PrepareDefinitions(db, dbPath, out var existingDefinitions)) return;

            // ── 2. Создать папку для выходных ассетов ──
            if (!Directory.Exists(OUTPUT_FOLDER))
            {
                Directory.CreateDirectory(OUTPUT_FOLDER);
                AssetDatabase.Refresh();
                Debug.Log($"[MedicalGen] Создана папка: {OUTPUT_FOLDER}");
            }

            int created = 0;
            int skipped = 0;
            int restoredRegistrations = 0;

            foreach (var def in Definitions)
            {
                string path = $"{OUTPUT_FOLDER}/{def.itemID}.asset";

                // D-ED02: existence and registration are independent stages.
                // Reuse the unique exact-identity asset even if it was moved.
                if (existingDefinitions.TryGetValue(def.itemID, out var existing))
                {
                    if (EnsureRegistration(db, existing)) restoredRegistrations++;
                    Debug.Log($"[MedicalGen] EXISTING: {def.itemID}, authored settings preserved.");
                    skipped++;
                    continue;
                }

                if (File.Exists(path))
                {
                    Debug.Log($"[MedicalGen] SKIP (существует): {def.itemID}");
                    skipped++;
                    continue;
                }

                var asset = ScriptableObject.CreateInstance<ItemStaticData>();
                AssetDatabase.CreateAsset(asset, path);

                var so = new SerializedObject(asset);
                so.FindProperty("_itemID").stringValue = def.itemID;
                so.FindProperty("_displayName").stringValue = def.displayName;
                so.FindProperty("_size").vector2IntValue = new Vector2Int(def.sizeX, def.sizeY);
                so.FindProperty("_weightGrams").intValue = def.weightGrams;
                so.FindProperty("_hardStackLimit").intValue = def.stackLimit;
                so.FindProperty("_type").enumValueIndex = (int)ItemType.Medical;
                so.FindProperty("_canRotate").boolValue = true;
                so.FindProperty("_prefabID").intValue = def.prefabID;
                so.FindProperty("_chargeCategory").intValue = (int)def.chargeCategory;
                so.FindProperty("_fullChargeSeconds").floatValue = def.fullChargeSeconds;
                so.ApplyModifiedProperties();

                // ── 3. Добавить в ItemDatabase._items ──
                var dbSo = new SerializedObject(db);
                var itemsProp = dbSo.FindProperty("_items");
                int idx = itemsProp.arraySize;
                itemsProp.InsertArrayElementAtIndex(idx);
                itemsProp.GetArrayElementAtIndex(idx).objectReferenceValue = asset;
                dbSo.ApplyModifiedProperties();

                created++;
                Debug.Log($"[MedicalGen] Создан: {def.itemID} → {def.displayName}");
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log($"[MedicalGen] ГОТОВО. Создано: {created}, пропущено: {skipped}. Всего в Definitions: {Definitions.Length}.");
            EditorUtility.DisplayDialog("Medical generator: отчёт",
                $"Создано {created}, восстановлено регистраций {restoredRegistrations}, существующих сохранено {skipped}.\nBackup базы указан в Console.", "OK");
        }

        private static bool PrepareDefinitions(ItemDatabase db, string dbPath, out Dictionary<string, ItemStaticData> existing)
        {
            existing = new Dictionary<string, ItemStaticData>(StringComparer.Ordinal);
            try
            {
                var all = new List<ItemStaticData>();
                foreach (string guid in AssetDatabase.FindAssets("t:ItemStaticData"))
                {
                    string path = AssetDatabase.GUIDToAssetPath(guid);
                    var item = AssetDatabase.LoadAssetAtPath<ItemStaticData>(path);
                    if (item == null) throw new InvalidOperationException("ItemStaticData не импортирован: " + path);
                    all.Add(item);
                }
                var database = new SerializedObject(db);
                var items = database.FindProperty("_items");
                if (items == null || !items.isArray) throw new InvalidOperationException("Не найден ItemDatabase._items.");
                var preview = new System.Text.StringBuilder();
                bool changesDatabase = false;
                foreach (var def in Definitions)
                {
                    ItemStaticData found = null;
                    foreach (var item in all)
                    {
                        if (item.ItemID != def.itemID && item.PrefabID != def.prefabID) continue;
                        if (found != null || item.ItemID != def.itemID || item.PrefabID != def.prefabID || item.Type != ItemType.Medical)
                            throw new InvalidOperationException("Конфликт ItemID/PrefabID/type: " + def.itemID + "/" + def.prefabID);
                        found = item;
                    }
                    if (found != null)
                    {
                        existing.Add(def.itemID, found);
                        int references = 0;
                        for (int i = 0; i < items.arraySize; i++)
                            if (items.GetArrayElementAtIndex(i).objectReferenceValue == found) references++;
                        if (references > 1) throw new InvalidOperationException("Дублирующая регистрация: " + def.itemID);
                        changesDatabase |= references == 0;
                        preview.AppendLine(def.itemID + (references == 0 ? ": восстановить регистрацию" : ": уже зарегистрирован") + "; настройки сохранить.");
                    }
                    else
                    {
                        string target = OUTPUT_FOLDER + "/" + def.itemID + ".asset";
                        if (File.Exists(target) || File.Exists(target + ".meta") || AssetDatabase.LoadMainAssetAtPath(target) != null)
                            throw new InvalidOperationException("Целевой путь занят или повреждён: " + target);
                        changesDatabase = true;
                        preview.AppendLine($"Создать {def.itemID}/{def.prefabID}: charge={def.chargeCategory}, duration={def.fullChargeSeconds}, stack={def.stackLimit}.");
                    }
                }
                if (changesDatabase && EditorUtility.IsDirty(db))
                    throw new InvalidOperationException("Сохраните ручные изменения ItemDatabase перед backup.");
                Debug.Log("[MedicalGen] PREVIEW\n" + preview);
                if (!EditorUtility.DisplayDialog("Medical generator: preview", preview + "\nПродолжить?", "Продолжить", "Отмена")) return false;
                if (changesDatabase)
                {
                    if (!File.Exists(dbPath) || !File.Exists(dbPath + ".meta"))
                        throw new InvalidOperationException("Для парного backup отсутствует база или .meta: " + dbPath);
                    string backup = "ReviewBackups/Iteration6MedicalGenerator/" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fff") + "_" + Guid.NewGuid().ToString("N");
                    string destination = Path.Combine(backup, dbPath);
                    Directory.CreateDirectory(Path.GetDirectoryName(destination));
                    File.Copy(dbPath, destination, false);
                    File.Copy(dbPath + ".meta", destination + ".meta", false);
                    Debug.Log("[MedicalGen] Backup ItemDatabase + meta: " + destination);
                }
                return true;
            }
            catch (Exception error)
            {
                Debug.LogError("[MedicalGen] Preflight остановлен без изменений: " + error.Message);
                return false;
            }
        }

        private static bool EnsureRegistration(ItemDatabase db, ItemStaticData asset)
        {
            var serialized = new SerializedObject(db);
            var items = serialized.FindProperty("_items");
            for (int i = 0; i < items.arraySize; i++)
                if (items.GetArrayElementAtIndex(i).objectReferenceValue == asset) return false;
            int index = items.arraySize;
            items.InsertArrayElementAtIndex(index);
            items.GetArrayElementAtIndex(index).objectReferenceValue = asset;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            EditorUtility.SetDirty(db);
            Debug.Log("[MedicalGen] Восстановлена регистрация: " + asset.ItemID);
            return true;
        }

        [MenuItem("Incident/Tools/Fix ItemDatabase Path (info)")]
        public static void ShowDbPath()
        {
            var guids = AssetDatabase.FindAssets("t:ItemDatabase");
            if (guids == null || guids.Length == 0)
            {
                Debug.LogError("[MedicalGen] ItemDatabase.asset не найден.");
                return;
            }
            foreach (var g in guids)
                Debug.Log($"[MedicalGen] ItemDatabase: {AssetDatabase.GUIDToAssetPath(g)}");
        }
    }
}
#endif
