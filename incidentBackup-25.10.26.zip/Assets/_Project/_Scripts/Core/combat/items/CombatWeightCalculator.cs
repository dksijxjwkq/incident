using System;
using System.Collections.Generic;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>
    /// Calculates actual ownership weight from the supplied player roots (equipment, pockets,
    /// backpack). Do not pass ground/container roots unless the player actually owns them.
    /// Repeated roots and attached-magazine projections are counted once by InstanceID.
    /// </summary>
    public sealed class CombatWeightCalculator
    {
        private readonly CombatItemStateRegistry _states;
        private readonly Func<string, ItemStaticData> _resolveItem;

        public CombatWeightCalculator(CombatItemStateRegistry states, Func<string, ItemStaticData> resolveItem)
        {
            _states = states ?? throw new ArgumentNullException(nameof(states));
            _resolveItem = resolveItem ?? throw new ArgumentNullException(nameof(resolveItem));
        }

        public long GetTotalWeightGrams(IEnumerable<InventoryItem> playerRoots)
            => GetTotalWeightGrams(playerRoots, null);

        public long GetTotalWeightGrams(IEnumerable<InventoryItem> playerRoots,
            IEnumerable<AppliedMedicalRecord> appliedMedical)
        {
            if (playerRoots == null) throw new ArgumentNullException(nameof(playerRoots));
            var roots = new List<InventoryItem>();
            var rootIds = new HashSet<uint>();
            var ownedWeapons = new HashSet<uint>();
            foreach (var item in playerRoots)
            {
                if (item == null) continue;
                if (!rootIds.Add(item.InstanceID)) continue;
                roots.Add(item);
                CollectWeapons(item.InstanceID, item.Data, item.GetBackpackSavedItems(), ownedWeapons, new HashSet<uint>(), 0);
            }
            var counted = new HashSet<uint>();
            long total = 0;
            foreach (var item in roots)
            {
                if (counted.Contains(item.InstanceID)) continue;
                total = checked(total + Count(item.InstanceID, item.Data, item.Quantity, counted, ownedWeapons));
                total = checked(total + CountSaved(item.GetBackpackSavedItems(), counted, ownedWeapons, 0));
            }
            return checked(total + CountAppliedMedical(appliedMedical, counted));
        }

        /// <summary>Additional mass for legacy callers which already summed physical roots.</summary>
        public long GetAdditionalAppliedMedicalWeightGrams(IEnumerable<InventoryItem> playerRoots,
            IEnumerable<AppliedMedicalRecord> appliedMedical)
        {
            if (playerRoots == null) throw new ArgumentNullException(nameof(playerRoots));
            var counted = new HashSet<uint>();
            foreach (var item in playerRoots)
                if (item != null) CollectOwnedIds(item.InstanceID, item.GetBackpackSavedItems(), counted, 0);
            return CountAppliedMedical(appliedMedical, counted);
        }

        private long CountAppliedMedical(IEnumerable<AppliedMedicalRecord> records, HashSet<uint> counted)
        {
            if (records == null) return 0;
            long total = 0;
            foreach (var record in records)
            {
                if (record == null || counted.Contains(record.InstanceID)) continue;
                if (record.InstanceID == 0 || record.VirtualQuantity < 1)
                    throw new InvalidOperationException("Invalid applied medical weight data.");
                var data = Resolve(record.VirtualItemID);
                counted.Add(record.InstanceID);
                total = checked(total + (long)data.WeightGrams * record.VirtualQuantity);
            }
            return total;
        }

        private static void CollectOwnedIds(uint id, IReadOnlyList<SavedItem> children,
            HashSet<uint> counted, int depth)
        {
            if (depth > 64) throw new InvalidOperationException("Owned backpack nesting is too deep.");
            if (!counted.Add(id) || children == null) return;
            foreach (var child in children)
                CollectOwnedIds(child.InstanceID, child.BackpackContents, counted, depth + 1);
        }

        private long Count(uint id, ItemStaticData data, int quantity, HashSet<uint> counted, HashSet<uint> ownedWeapons)
        {
            if (id == 0 || data == null || quantity < 1) throw new InvalidOperationException("Invalid owned item weight data.");
            if (!counted.Add(id)) return 0;
            if (_states.TryGetWeapon(id, out var weapon))
            {
                if (quantity != 1 || !ReferenceEquals(weapon.Data, data)) throw new InvalidOperationException("Weapon identity/quantity mismatch.");
                return weapon.WeightGrams;
            }
            if (_states.TryGetMagazine(id, out var magazine))
            {
                if (quantity != 1 || !ReferenceEquals(magazine.Data, data)) throw new InvalidOperationException("Magazine identity/quantity mismatch.");
                if (magazine.OwnerWeaponID != 0)
                {
                    if (ownedWeapons.Contains(magazine.OwnerWeaponID)) return 0;
                    throw new InvalidOperationException("An attached magazine cannot be a player root without its owning weapon.");
                }
                return magazine.WeightGrams;
            }
            return checked((long)data.WeightGrams * quantity);
        }

        private long CountSaved(IReadOnlyList<SavedItem> children, HashSet<uint> counted, HashSet<uint> ownedWeapons, int depth)
        {
            if (children == null) return 0;
            if (depth > 64) throw new InvalidOperationException("Owned backpack nesting is too deep.");
            long total = 0;
            foreach (var child in children)
            {
                if (counted.Contains(child.InstanceID)) continue;
                total = checked(total + Count(child.InstanceID, Resolve(child.ItemID), child.Quantity, counted, ownedWeapons));
                total = checked(total + CountSaved(child.BackpackContents, counted, ownedWeapons, depth + 1));
            }
            return total;
        }

        private void CollectWeapons(uint id, ItemStaticData data, IReadOnlyList<SavedItem> children,
            HashSet<uint> ownedWeapons, HashSet<uint> visited, int depth)
        {
            if (depth > 64) throw new InvalidOperationException("Owned backpack nesting is too deep.");
            if (!visited.Add(id)) return;
            if (data != null && data.Type == ItemType.Weapon) ownedWeapons.Add(id);
            if (children == null) return;
            foreach (var child in children)
                CollectWeapons(child.InstanceID, Resolve(child.ItemID), child.BackpackContents, ownedWeapons, visited, depth + 1);
        }

        private ItemStaticData Resolve(string id) => _resolveItem(id) ??
            throw new InvalidOperationException("Missing static data for owned item '" + id + "'.");
    }
}
