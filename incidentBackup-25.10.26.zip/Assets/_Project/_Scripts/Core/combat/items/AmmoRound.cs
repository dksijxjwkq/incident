using System;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>A single round, without durability or an inventory stack wrapper.</summary>
    public sealed class AmmoRound
    {
        public ItemStaticData Data { get; }
        public string Caliber => Data.Caliber;
        public AmmoType Type => Data.Ammunition.Type;
        public int WeightGrams => Data.WeightGrams;

        public AmmoRound(ItemStaticData data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (data.Type != ItemType.Ammo || data.Ammunition == null ||
                string.IsNullOrWhiteSpace(data.Caliber) || data.WeightGrams < 0)
                throw new ArgumentException("Round requires configured ammunition data.", nameof(data));
            Data = data;
        }
    }
}
