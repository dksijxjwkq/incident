namespace K_Incident.Core.Combat
{
    // Serialized values are append-only.
    public enum WeaponType { Pistol = 0, AssaultRifle = 1, Shotgun = 2, Rifle = 3, SubmachineGun = 4, DoubleBarrel = 5, BoltAction = 6 }
    public enum WeaponClass { Pistol = 0, AssaultRifle = 1, Shotgun = 2, Rifle = 3, SubmachineGun = 4 }
    public enum FireMode { Single = 0, Auto = 1, Burst = 2, Safe = 3 }
    public enum AmmoType { Standard = 0, ArmorPiercing = 1, Expanding = 2, Improvised = 3 }

    public static class CaliberIds
    {
        public const string Pm9x18 = "9x18";
        public const string Parabellum9x19 = "9x19";
        public const string Ak545x39 = "5.45x39";
        public const string Ar556x45 = "5.56x45";
        public const string Akm762x39 = "7.62x39";
        public const string Rifle762x54R = "7.62x54R";
        public const string Gauge12 = "12g";
    }
}
