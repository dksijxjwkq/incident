using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>Container ownership and chamber data only. No firing or reload execution.</summary>
    public sealed class WeaponState
    {
        private readonly AmmoRound[] _chambers;
        private readonly ReadOnlyCollection<AmmoRound> _readOnlyChambers;
        private readonly List<AmmoRound> _internalRounds = new List<AmmoRound>();
        private readonly ReadOnlyCollection<AmmoRound> _readOnlyInternal;
        public uint InstanceID { get; }
        public ItemStaticData Data { get; }
        public FireMode CurrentFireMode { get; private set; }
        public MagazineState Magazine { get; private set; }
        public IReadOnlyList<AmmoRound> Chambers => _readOnlyChambers;
        public IReadOnlyList<AmmoRound> InternalRounds => _readOnlyInternal;
        public int InternalMagazineCapacity { get; }

        // Stage 5.2 persists condition independently from reconstructed InventoryItem wrappers.
        // Per-shot wear and misfire rolls are executed by WeaponFiringController.
        public float MaximumDurability => Math.Max(0, Data.MaxDurability);
        public float Durability { get; private set; }
        public bool IsBroken => Durability <= 0f;
        public bool IsMisfired { get; private set; }
        public bool RequiresBoltCycle => Data.Weapon.Type == WeaponType.BoltAction &&
            Data.Weapon.MagazineCapacity == 0 && _chambers.Length == 1 && InternalMagazineCapacity > 0;
        public event Action Changed;

        public WeaponState(uint instanceID, ItemStaticData data)
        {
            if (instanceID == 0) throw new ArgumentOutOfRangeException(nameof(instanceID));
            if (data == null) throw new ArgumentNullException(nameof(data));
            var definition = data.Weapon;
            if (data.Type != ItemType.Weapon || definition == null || string.IsNullOrWhiteSpace(data.Caliber) ||
                definition.ChamberCapacity < 0 || definition.InternalMagazineCapacity < 0 ||
                definition.MagazineCapacity < 0 || data.WeightGrams < 0 ||
                (definition.Type == WeaponType.DoubleBarrel && (definition.ChamberCapacity != 2 ||
                    definition.MagazineCapacity != 0 || definition.InternalMagazineCapacity != 0)) ||
                (definition.MagazineCapacity > 0 && definition.InternalMagazineCapacity > 0) ||
                !definition.Supports(definition.DefaultFireMode))
                throw new ArgumentException("Weapon requires valid caliber, capacities and fire modes.", nameof(data));
            InstanceID = instanceID;
            Data = data;
            CurrentFireMode = definition.DefaultFireMode;
            _chambers = new AmmoRound[definition.ChamberCapacity];
            _readOnlyChambers = Array.AsReadOnly(_chambers);
            InternalMagazineCapacity = definition.InternalMagazineCapacity;
            _readOnlyInternal = _internalRounds.AsReadOnly();
            Durability = MaximumDurability;
        }

        public bool TrySetFireMode(FireMode mode)
        {
            if (!Data.Weapon.Supports(mode)) return false;
            CurrentFireMode = mode;
            Changed?.Invoke();
            return true;
        }

        // These operations change the data graph. The inventory transaction and R input
        // that transfer actual items are deliberately left to stage 5.2.
        public bool TrySetMagazine(MagazineState magazine)
        {
            if (magazine == null || Magazine != null || magazine.InstanceID == InstanceID ||
                magazine.OwnerWeaponID != 0 || !magazine.IsCompatibleWith(Data)) return false;
            Magazine = magazine;
            magazine.OwnerWeaponID = InstanceID;
            Changed?.Invoke();
            return true;
        }

        public bool TryRemoveMagazine(out MagazineState magazine)
        {
            magazine = Magazine;
            if (magazine == null) return false;
            magazine.OwnerWeaponID = 0;
            Magazine = null;
            Changed?.Invoke();
            return true;
        }

        // Legacy, использовать TryLoadEmptyChamber / TrySetChamberPrivileged.
        // The current serializer still calls this setter; removing it would break restore.
        [Obsolete("Privileged replacement setter. Use TryLoadEmptyChamber for gameplay, or TrySetChamberPrivileged for explicit restore access.")]
        public bool TrySetChamber(int index, AmmoRound round)
        {
            if (index < 0 || index >= _chambers.Length || (round != null && !Accepts(round))) return false;
            _chambers[index] = round;
            Changed?.Invoke();
            return true;
        }

        /// <summary>Gameplay loading never replaces an occupied chamber or clears one.</summary>
        public bool TryLoadEmptyChamber(int index, AmmoRound round)
        {
            if (index < 0 || index >= _chambers.Length || _chambers[index] != null || !Accepts(round)) return false;
#pragma warning disable CS0618
            return TrySetChamber(index, round);
#pragma warning restore CS0618
        }

        public bool TrySetChamberPrivileged(int index, AmmoRound round)
        {
#pragma warning disable CS0618
            return TrySetChamber(index, round);
#pragma warning restore CS0618
        }

        internal void ReleaseForPermanentDeletion()
        {
            if (Magazine != null) Magazine.OwnerWeaponID = 0;
            Magazine = null;
            Array.Clear(_chambers, 0, _chambers.Length);
            _internalRounds.Clear();
            Durability = 0f;
            Changed = null;
        }

        /// <summary>Chambers one already-carried round without selecting or replacing a magazine.</summary>
        public bool TryChamberAttachedRound()
        {
            if (IsBroken || IsMisfired) return false;
            int index = FirstEmptyChamber();
            if (index < 0) return false;
            if (Magazine != null && Magazine.TryPeek(out AmmoRound round))
            {
                // Complete both sides before publishing either owner's change.
                _chambers[index] = round;
                if (!Magazine.TryPop(out AmmoRound consumed) || !ReferenceEquals(round, consumed))
                {
                    _chambers[index] = null;
                    throw new InvalidOperationException("Attached ammunition changed during chambering.");
                }
                Changed?.Invoke();
                return true;
            }
            int count = _internalRounds.Count;
            if (count == 0) return false;
            _chambers[index] = _internalRounds[count - 1];
            _internalRounds.RemoveAt(count - 1);
            Changed?.Invoke();
            return true;
        }

        public int FirstEmptyChamber()
        {
            for (int i = 0; i < _chambers.Length; i++) if (_chambers[i] == null) return i;
            return -1;
        }

        public bool TryPushInternalRound(AmmoRound round)
        {
            if (!Accepts(round) || _internalRounds.Count >= InternalMagazineCapacity) return false;
            _internalRounds.Add(round);
            Changed?.Invoke();
            return true;
        }

        public bool TryPopInternalRound(out AmmoRound round)
        {
            int count = _internalRounds.Count;
            round = count == 0 ? null : _internalRounds[count - 1];
            if (round == null) return false;
            _internalRounds.RemoveAt(count - 1);
            Changed?.Invoke();
            return true;
        }

        private bool Accepts(AmmoRound round) => round != null &&
            string.Equals(round.Caliber, Data.Caliber, StringComparison.Ordinal);

        public long WeightGrams
        {
            get
            {
                long total = Data.WeightGrams;
                if (Magazine != null) total = checked(total + Magazine.WeightGrams);
                for (int i = 0; i < _chambers.Length; i++)
                    if (_chambers[i] != null) total = checked(total + _chambers[i].WeightGrams);
                for (int i = 0; i < _internalRounds.Count; i++) total = checked(total + _internalRounds[i].WeightGrams);
                return total;
            }
        }

        /// <summary>A shot always originates in a chamber. Feeding is part of a successful self-loading shot.</summary>
        public bool TryPeekShotRound(out AmmoRound round)
        {
            for (int i = 0; i < _chambers.Length; i++)
            {
                if (_chambers[i] == null) continue;
                round = _chambers[i];
                return true;
            }
            round = null;
            return false;
        }

        public bool TryConsumeShotRound(out AmmoRound round)
        {
            for (int i = 0; i < _chambers.Length; i++)
            {
                if (_chambers[i] == null) continue;
                round = _chambers[i];
                _chambers[i] = null;
                // Bolt actions and break-open double barrels retain an empty fired chamber.
                if (Data.Weapon.Type != WeaponType.BoltAction && Data.Weapon.Type != WeaponType.DoubleBarrel)
                    TryChamberAttachedRound();
                Changed?.Invoke();
                return true;
            }
            round = null;
            return false;
        }

        public bool TryTakeChamberRound(int index, AmmoRound expected)
        {
            if (expected == null || index < 0 || index >= _chambers.Length ||
                !ReferenceEquals(_chambers[index], expected)) return false;
            _chambers[index] = null;
            Changed?.Invoke();
            return true;
        }

        /// <summary>Move the top internal round into an empty bolt-action chamber as one observable change.</summary>
        public bool TryCycleBolt()
        {
            int count = _internalRounds.Count;
            if (!RequiresBoltCycle || IsBroken || IsMisfired || _chambers[0] != null || count == 0) return false;
            _chambers[0] = _internalRounds[count - 1];
            _internalRounds.RemoveAt(count - 1);
            Changed?.Invoke();
            return true;
        }

        public void RestoreDurability(float durability)
        {
            if (float.IsNaN(durability) || float.IsInfinity(durability) || durability < 0f)
                throw new ArgumentOutOfRangeException(nameof(durability));
            Durability = Math.Min(MaximumDurability, durability);
            Changed?.Invoke();
        }

        public void ApplyDurabilityDamage(float damage)
        {
            if (float.IsNaN(damage) || float.IsInfinity(damage) || damage < 0f)
                throw new ArgumentOutOfRangeException(nameof(damage));
            Durability = Math.Max(0f, Durability - damage);
            Changed?.Invoke();
        }

        public void SetMisfire(bool isMisfired = true)
        {
            if (IsMisfired == isMisfired) return;
            IsMisfired = isMisfired;
            Changed?.Invoke();
        }
        public void ClearMisfire() => SetMisfire(false);
    }
}
