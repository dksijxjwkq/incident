using System;

namespace K_Incident.Core.Combat
{
    [Serializable]
    public sealed class ArmorItemDefinition
    {
        // Class and durability reuse ItemStaticData.ArmorClass / MaxDurability.
        // The class balance durability is only the fallback for an unspecified concrete maximum (0).
        // NPC provenance does not prevent a player equipping a looted armor item.
        public bool CoversAbdomen;
        public bool NpcStartingEquipment;
    }
}
