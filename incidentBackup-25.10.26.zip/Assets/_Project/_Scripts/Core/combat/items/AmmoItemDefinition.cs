using System;

namespace K_Incident.Core.Combat
{
    [Serializable]
    public sealed class AmmoItemDefinition
    {
        public AmmoType Type = AmmoType.Standard;
    }
}
