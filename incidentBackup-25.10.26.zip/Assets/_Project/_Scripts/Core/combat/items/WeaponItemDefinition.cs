using System;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core.Combat
{
    [Serializable]
    public sealed class WeaponItemDefinition
    {
        public WeaponType Type = WeaponType.Pistol;
        public WeaponClass Class = WeaponClass.Pistol;
        public EquipmentSlotType EquipmentSlot = EquipmentSlotType.Primary;
        public FireMode DefaultFireMode = FireMode.Single;
        public FireMode[] AllowedFireModes = { FireMode.Single, FireMode.Safe };
        [Min(0)] public int MagazineCapacity;
        [Min(0)] public int InternalMagazineCapacity;
        [Min(0)] public int ChamberCapacity = 1;
        [Min(0)] public float MisfireChance;
        [Min(0)] public float BaseWearPerShot = .3f;
        public bool Suppressed = false;

        [Header("Stage 5.2 firing (damage is per pellet)")]
        [Min(0)] public float BaseDamage = 25f;
        [Min(.001f)] public float ShotInterval = .12f;
        [Min(1)] public int BurstCount = 3;
        [Min(.001f)] public float BurstPause = .3f;
        [Min(0)] public float WeaponLength = .6f;
        [Min(.001f)] public float Range = 100f;
        [Min(1)] public int PelletCount = 1;
        [Range(0f, 89f)] public float SpreadAngleDegrees;
        [Range(1, 3)] public int ExternalBleedingLevel = 1;
        [Range(0f, 1f)] public float FractureChance = .15f;
        public WeaponFractureChance[] FractureChanceByPart = Array.Empty<WeaponFractureChance>();
        [Range(0f, 1f)] public float HeadTraumaChanceMultiplier = 1f;
        [Min(0)] public float ShockDuration = 10f;

        public float GetFractureChance(BodyPart part)
        {
            DamageValidation.PartIndex(part);
            if (FractureChanceByPart != null)
                foreach (var entry in FractureChanceByPart)
                    if (entry.Part == part) return entry.Chance;
            return FractureChance;
        }

        public void ValidateFiring()
        {
            NonNegative(BaseWearPerShot, nameof(BaseWearPerShot));
            Unit(MisfireChance, nameof(MisfireChance));
            NonNegative(BaseDamage, nameof(BaseDamage));
            Positive(ShotInterval, nameof(ShotInterval));
            Positive(BurstPause, nameof(BurstPause));
            NonNegative(WeaponLength, nameof(WeaponLength));
            Positive(Range, nameof(Range));
            NonNegative(SpreadAngleDegrees, nameof(SpreadAngleDegrees));
            if (BurstCount < 1 || PelletCount < 1 || SpreadAngleDegrees > 89f ||
                ExternalBleedingLevel < 1 || ExternalBleedingLevel > 3)
                throw new InvalidOperationException("Invalid weapon firing count, spread or bleeding level.");
            Unit(FractureChance, nameof(FractureChance));
            Unit(HeadTraumaChanceMultiplier, nameof(HeadTraumaChanceMultiplier));
            NonNegative(ShockDuration, nameof(ShockDuration));
            if (FractureChanceByPart != null)
                foreach (var entry in FractureChanceByPart)
                {
                    DamageValidation.PartIndex(entry.Part);
                    Unit(entry.Chance, "part fracture chance");
                }
        }

        private static void NonNegative(float value, string label)
        {
            if (float.IsNaN(value) || float.IsInfinity(value) || value < 0f)
                throw new InvalidOperationException("Invalid configured weapon " + label + ".");
        }

        private static void Positive(float value, string label)
        {
            NonNegative(value, label);
            if (value == 0f) throw new InvalidOperationException("Weapon " + label + " must be positive.");
        }

        private static void Unit(float value, string label)
        {
            NonNegative(value, label);
            if (value > 1f) throw new InvalidOperationException("Weapon " + label + " must be at most one.");
        }

        public bool Supports(FireMode mode)
        {
            if (AllowedFireModes == null) return false;
            for (int i = 0; i < AllowedFireModes.Length; i++)
                if (AllowedFireModes[i] == mode) return true;
            return false;
        }
    }

    [Serializable]
    public struct WeaponFractureChance
    {
        public BodyPart Part;
        [Range(0f, 1f)] public float Chance;

        public WeaponFractureChance(BodyPart part, float chance) { Part = part; Chance = chance; }
    }
}
