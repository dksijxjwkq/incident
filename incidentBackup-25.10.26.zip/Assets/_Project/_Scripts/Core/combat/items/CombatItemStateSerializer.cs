using System;
using System.Collections.Generic;
using System.IO;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>Engine-free V10 combat graph payload. References precede their round data on disk.</summary>
    public static class CombatItemStateSerializer
    {
        private const int PayloadRevision = 1;
        private const int MaximumRecords = 100000;

        public static void Save(BinaryWriter writer, CombatItemStateRegistry registry)
        {
            if (writer == null) throw new ArgumentNullException(nameof(writer));
            if (registry == null) throw new ArgumentNullException(nameof(registry));
            var rounds = new List<AmmoRound>();
            var indices = new Dictionary<AmmoRound, int>();
            var weapons = Sorted(registry.Weapons);
            var magazines = Sorted(registry.Magazines);
            var armor = Sorted(registry.Armor);

            writer.Write(PayloadRevision);
            writer.Write(weapons.Count);
            foreach (var entry in weapons)
            {
                var weapon = entry.Value;
                writer.Write(weapon.InstanceID);
                writer.Write(weapon.Data.ItemID);
                writer.Write((int)weapon.CurrentFireMode);
                writer.Write(weapon.Magazine?.InstanceID ?? 0);
                writer.Write(weapon.Durability);
                writer.Write(weapon.IsMisfired);
                WriteRounds(writer, weapon.Chambers, rounds, indices);
                WriteRounds(writer, weapon.InternalRounds, rounds, indices);
            }
            writer.Write(magazines.Count);
            foreach (var entry in magazines)
            {
                var magazine = entry.Value;
                writer.Write(magazine.InstanceID);
                writer.Write(magazine.Data.ItemID);
                writer.Write(magazine.OwnerWeaponID);
                WriteRounds(writer, magazine.Rounds, rounds, indices);
            }
            writer.Write(rounds.Count);
            foreach (var round in rounds) writer.Write(round.Data.ItemID);
            writer.Write(armor.Count);
            foreach (var entry in armor)
            {
                writer.Write(entry.Key);
                writer.Write(entry.Value.Definition.ItemID);
                writer.Write(entry.Value.Durability);
                writer.Write(entry.Value.IsConditionRevealed);
            }
        }

        public static void Load(BinaryReader reader, CombatItemStateRegistry registry,
            Func<string, ItemStaticData> findData, WeaponBalanceConfig balance)
        {
            if (reader == null) throw new ArgumentNullException(nameof(reader));
            if (registry == null) throw new ArgumentNullException(nameof(registry));
            if (findData == null) throw new ArgumentNullException(nameof(findData));
            if (balance == null) throw new ArgumentNullException(nameof(balance));
            if (reader.ReadInt32() != PayloadRevision)
                throw new InvalidDataException("Unsupported combat payload revision.");

            // Read all reference records first. No live graph is changed by a malformed payload.
            var weapons = new WeaponRecord[ReadCount(reader)];
            var ids = new HashSet<uint>();
            for (int i = 0; i < weapons.Length; i++)
            {
                weapons[i] = new WeaponRecord
                {
                    ID = ReadID(reader, ids), Data = RequireData(reader.ReadString(), ItemType.Weapon, findData),
                    Mode = (FireMode)reader.ReadInt32(), MagazineID = reader.ReadUInt32(),
                    Durability = ReadCondition(reader), Misfired = reader.ReadBoolean(),
                    Chambers = ReadRoundReferences(reader), Internal = ReadRoundReferences(reader)
                };
            }
            var magazines = new MagazineRecord[ReadCount(reader)];
            for (int i = 0; i < magazines.Length; i++)
            {
                magazines[i] = new MagazineRecord
                {
                    ID = ReadID(reader, ids), Data = RequireData(reader.ReadString(), ItemType.Magazine, findData),
                    OwnerID = reader.ReadUInt32(), Rounds = ReadRoundReferences(reader)
                };
            }
            var rounds = new AmmoRound[ReadCount(reader)];
            for (int i = 0; i < rounds.Length; i++)
                rounds[i] = new AmmoRound(RequireData(reader.ReadString(), ItemType.Ammo, findData));

            // Reconstruction order: magazines with ordered rounds, weapons, then ownership links.
            var restored = new CombatItemStateRegistry();
            foreach (var record in magazines)
            {
                var magazine = new MagazineState(record.ID, record.Data);
                foreach (int index in record.Rounds)
                    if (!magazine.TryPush(ResolveRound(index, rounds, false)))
                        throw new InvalidDataException("Magazine contains incompatible or excess ammunition.");
                restored.Restore(magazine);
            }
            foreach (var record in weapons)
            {
                var weapon = new WeaponState(record.ID, record.Data);
                if (!weapon.TrySetFireMode(record.Mode) || record.Chambers.Length != weapon.Chambers.Count)
                    throw new InvalidDataException("Weapon mode or chamber count does not match its definition.");
                if (record.Durability > weapon.MaximumDurability)
                    throw new InvalidDataException("Weapon durability exceeds its maximum.");
                weapon.RestoreDurability(record.Durability);
                weapon.SetMisfire(record.Misfired);
                for (int i = 0; i < record.Chambers.Length; i++)
                    if (!weapon.TrySetChamber(i, ResolveRound(record.Chambers[i], rounds, true)))
                        throw new InvalidDataException("Chamber contains incompatible ammunition.");
                foreach (int index in record.Internal)
                    if (!weapon.TryPushInternalRound(ResolveRound(index, rounds, false)))
                        throw new InvalidDataException("Internal magazine contains incompatible or excess ammunition.");
                restored.Restore(weapon);
            }
            var magazineOwners = new Dictionary<uint, uint>();
            foreach (var record in magazines) magazineOwners.Add(record.ID, record.OwnerID);
            foreach (var record in weapons)
            {
                if (record.MagazineID == 0) continue;
                if (!restored.TryGetMagazine(record.MagazineID, out var magazine) ||
                    magazineOwners[record.MagazineID] != record.ID ||
                    !restored.TryGetWeapon(record.ID, out var weapon) || !weapon.TrySetMagazine(magazine))
                    throw new InvalidDataException("Invalid magazine ownership or compatibility.");
            }
            foreach (var record in magazines)
                if (!restored.TryGetMagazine(record.ID, out var magazine) || magazine.OwnerWeaponID != record.OwnerID)
                    throw new InvalidDataException("Magazine owner has no matching weapon reference.");

            int armorCount = ReadCount(reader);
            for (int i = 0; i < armorCount; i++)
            {
                uint id = ReadID(reader, ids);
                var data = RequireData(reader.ReadString(), ItemType.Armor, findData);
                float durability = ReadCondition(reader);
                bool revealed = reader.ReadBoolean();
                var state = new ArmorState(data, balance, durability, !revealed);
                if (durability > state.MaximumDurability)
                    throw new InvalidDataException("Armor durability exceeds its maximum.");
                restored.Restore(id, state);
            }
            registry.ReplaceWith(restored);
            foreach (uint id in ids) GlobalIDManager.ObserveID(id);
        }

        private static void WriteRounds(BinaryWriter writer, IReadOnlyList<AmmoRound> source,
            List<AmmoRound> rounds, Dictionary<AmmoRound, int> indices)
        {
            writer.Write(source.Count);
            for (int i = 0; i < source.Count; i++)
            {
                var round = source[i];
                if (round == null) { writer.Write(-1); continue; }
                if (!indices.TryGetValue(round, out int index))
                {
                    if (rounds.Count >= MaximumRecords) throw new InvalidDataException("Too many combat ammunition records.");
                    index = rounds.Count;
                    indices.Add(round, index);
                    rounds.Add(round);
                }
                writer.Write(index);
            }
        }

        private static int[] ReadRoundReferences(BinaryReader reader)
        {
            var indices = new int[ReadCount(reader)];
            for (int i = 0; i < indices.Length; i++) indices[i] = reader.ReadInt32();
            return indices;
        }

        private static AmmoRound ResolveRound(int index, AmmoRound[] rounds, bool allowEmpty)
        {
            if (index == -1 && allowEmpty) return null;
            if (index < 0 || index >= rounds.Length) throw new InvalidDataException("Invalid ammunition reference.");
            return rounds[index];
        }

        private static ItemStaticData RequireData(string id, ItemType type, Func<string, ItemStaticData> findData)
        {
            var data = findData(id);
            if (data == null || string.IsNullOrWhiteSpace(id) || data.ItemID != id || data.Type != type)
                throw new InvalidDataException("Missing or incompatible combat item definition: " + id);
            return data;
        }

        private static int ReadCount(BinaryReader reader)
        {
            int count = reader.ReadInt32();
            if (count < 0 || count > MaximumRecords) throw new InvalidDataException("Invalid combat record count.");
            return count;
        }

        private static uint ReadID(BinaryReader reader, HashSet<uint> ids)
        {
            uint id = reader.ReadUInt32();
            if (id == 0 || id == uint.MaxValue || !ids.Add(id))
                throw new InvalidDataException("Invalid or duplicated combat instance ID.");
            return id;
        }

        private static float ReadCondition(BinaryReader reader)
        {
            float value = reader.ReadSingle();
            if (float.IsNaN(value) || float.IsInfinity(value) || value < 0f)
                throw new InvalidDataException("Invalid combat durability.");
            return value;
        }

        private static List<KeyValuePair<uint, T>> Sorted<T>(IReadOnlyDictionary<uint, T> source)
        {
            var list = new List<KeyValuePair<uint, T>>(source);
            list.Sort((a, b) => a.Key.CompareTo(b.Key));
            return list;
        }

        private sealed class WeaponRecord
        {
            public uint ID, MagazineID;
            public ItemStaticData Data;
            public FireMode Mode;
            public float Durability;
            public bool Misfired;
            public int[] Chambers, Internal;
        }

        private sealed class MagazineRecord
        {
            public uint ID, OwnerID;
            public ItemStaticData Data;
            public int[] Rounds;
        }
    }
}
