using System;
using UnityEngine;

namespace K_Incident.Core.Combat
{
    [Serializable]
    public sealed class MagazineItemDefinition
    {
        [Min(1)] public int Capacity = 1;
        public WeaponClass WeaponClass = WeaponClass.Pistol;
        public bool IsOpenType = false;
    }
}
