using System;
using System.Collections.Generic;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>
    /// Session-owned state keyed by persistent item identity. Moving/dropping/reconstructing
    /// InventoryItem wrappers does not detach a magazine. K_CombatContext owns its framed Save section.
    /// </summary>
    public sealed class CombatItemStateRegistry
    {
        private readonly Dictionary<uint, WeaponState> _weapons = new Dictionary<uint, WeaponState>();
        private readonly Dictionary<uint, MagazineState> _magazines = new Dictionary<uint, MagazineState>();
        private readonly Dictionary<uint, ArmorState> _armor = new Dictionary<uint, ArmorState>();
        private int _changeDeferralDepth;
        private bool _pendingChanges;

        public event Action Changed;
        public event Action SessionReset;
        public IReadOnlyDictionary<uint, WeaponState> Weapons => _weapons;
        public IReadOnlyDictionary<uint, MagazineState> Magazines => _magazines;
        public IReadOnlyDictionary<uint, ArmorState> Armor => _armor;

        /// <summary>Notify the owner after a service mutates a contained combat state.</summary>
        public void MarkDirty()
        {
            if (_changeDeferralDepth > 0) { _pendingChanges = true; return; }
            Changed?.Invoke();
        }

        /// <summary>Publishes one stable graph after an inventory/round transfer has committed.</summary>
        public IDisposable DeferChanges()
        {
            _changeDeferralDepth++;
            return new ChangeScope(this);
        }

        private void CompleteChanges()
        {
            _changeDeferralDepth--;
            if (_changeDeferralDepth != 0 || !_pendingChanges) return;
            _pendingChanges = false;
            Changed?.Invoke();
        }

        private sealed class ChangeScope : IDisposable
        {
            private CombatItemStateRegistry _owner;
            public ChangeScope(CombatItemStateRegistry owner) => _owner = owner;
            public void Dispose()
            {
                if (_owner == null) return;
                var owner = _owner;
                _owner = null;
                owner.CompleteChanges();
            }
        }

        public WeaponState GetOrCreateWeapon(InventoryItem item)
        {
            RequireSingleItem(item, ItemType.Weapon);
            if (_armor.ContainsKey(item.InstanceID)) throw new InvalidOperationException("InstanceID already belongs to armor.");
            if (_magazines.ContainsKey(item.InstanceID)) throw new InvalidOperationException("InstanceID already belongs to a magazine.");
            if (_weapons.TryGetValue(item.InstanceID, out var existing))
            {
                RequireSameDefinition(existing.Data, item.Data);
                return existing;
            }
            var state = new WeaponState(item.InstanceID, item.Data);
            state.RestoreDurability(item.Durability);
            _weapons.Add(item.InstanceID, state);
            state.Changed += MarkDirty;
            MarkDirty();
            return state;
        }

        public MagazineState GetOrCreateMagazine(InventoryItem item)
        {
            RequireSingleItem(item, ItemType.Magazine);
            if (_armor.ContainsKey(item.InstanceID)) throw new InvalidOperationException("InstanceID already belongs to armor.");
            if (_weapons.ContainsKey(item.InstanceID)) throw new InvalidOperationException("InstanceID already belongs to a weapon.");
            if (_magazines.TryGetValue(item.InstanceID, out var existing))
            {
                RequireSameDefinition(existing.Data, item.Data);
                return existing;
            }
            var state = new MagazineState(item.InstanceID, item.Data);
            _magazines.Add(item.InstanceID, state);
            state.Changed += MarkDirty;
            MarkDirty();
            return state;
        }

        public bool TryGetWeapon(uint instanceID, out WeaponState state) => _weapons.TryGetValue(instanceID, out state);
        public bool TryGetMagazine(uint instanceID, out MagazineState state) => _magazines.TryGetValue(instanceID, out state);

        public ArmorState GetOrCreateArmor(InventoryItem item, WeaponBalanceConfig balance,
            bool isConditionRevealed = true)
        {
            RequireSingleItem(item, ItemType.Armor);
            if (_weapons.ContainsKey(item.InstanceID) || _magazines.ContainsKey(item.InstanceID))
                throw new InvalidOperationException("InstanceID already belongs to another combat item.");
            if (_armor.TryGetValue(item.InstanceID, out var existing))
            {
                RequireSameDefinition(existing.Definition, item.Data);
                return existing;
            }
            // A zero authored maximum opts new armor into its class fallback. Saved
            // condition is restored by the serializer and never passes through here.
            float? initialDurability = item.Data.MaxDurability == 0 ? (float?)null : item.Durability;
            var state = new ArmorState(item.Data, balance, initialDurability, !isConditionRevealed);
            _armor.Add(item.InstanceID, state);
            state.Changed += MarkDirty;
            MarkDirty();
            return state;
        }

        public bool TryGetArmor(uint instanceID, out ArmorState state) => _armor.TryGetValue(instanceID, out state);

        // Used only by the validated serializer after its complete graph has been reconstructed.
        internal void Restore(WeaponState weapon)
        {
            _weapons.Add(weapon.InstanceID, weapon);
            weapon.Changed += MarkDirty;
        }
        internal void Restore(MagazineState magazine)
        {
            _magazines.Add(magazine.InstanceID, magazine);
            magazine.Changed += MarkDirty;
        }
        internal void Restore(uint instanceID, ArmorState armor)
        {
            _armor.Add(instanceID, armor);
            armor.Changed += MarkDirty;
        }

        internal void ReplaceWith(CombatItemStateRegistry restored)
        {
            using (DeferChanges())
            {
                Clear();
                foreach (var entry in restored._magazines) { entry.Value.Changed -= restored.MarkDirty; Restore(entry.Value); }
                foreach (var entry in restored._weapons) { entry.Value.Changed -= restored.MarkDirty; Restore(entry.Value); }
                foreach (var entry in restored._armor) { entry.Value.Changed -= restored.MarkDirty; Restore(entry.Key, entry.Value); }
                MarkDirty();
            }
        }

        /// <summary>Explicit session reset; call when starting/loading a world, never on item drop.</summary>
        public void Clear()
        {
            SessionReset?.Invoke();
            foreach (var state in _weapons.Values) state.Changed -= MarkDirty;
            foreach (var state in _magazines.Values) state.Changed -= MarkDirty;
            foreach (var state in _armor.Values) state.Changed -= MarkDirty;
            _weapons.Clear();
            _magazines.Clear();
            _armor.Clear();
            MarkDirty();
        }

        /// <summary>Final deletion only: ordinary inventory moves, drops and world despawns retain combat state.</summary>
        public bool RemovePermanently(uint instanceID)
        {
            if (_magazines.TryGetValue(instanceID, out var attached) && attached.OwnerWeaponID != 0)
                return false;
            bool removed = false;
            using (DeferChanges())
            {
                if (_weapons.TryGetValue(instanceID, out var weapon))
                {
                    weapon.Changed -= MarkDirty;
                    _weapons.Remove(instanceID);
                    var magazine = weapon.Magazine;
                    weapon.ReleaseForPermanentDeletion();
                    if (magazine != null)
                    {
                        magazine.Changed -= MarkDirty;
                        _magazines.Remove(magazine.InstanceID);
                    }
                    removed = true;
                }
                if (_magazines.TryGetValue(instanceID, out var magazineState))
                {
                    magazineState.Changed -= MarkDirty;
                    _magazines.Remove(instanceID);
                    removed = true;
                }
                if (_armor.TryGetValue(instanceID, out var armor))
                {
                    armor.Changed -= MarkDirty;
                    _armor.Remove(instanceID);
                    removed = true;
                }
                if (removed) MarkDirty();
            }
            return removed;
        }

        private static void RequireSingleItem(InventoryItem item, ItemType type)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));
            if (item.Type != type || item.Quantity != 1)
                throw new ArgumentException("Weapon/magazine state requires a single matching inventory item.", nameof(item));
        }

        private static void RequireSameDefinition(ItemStaticData existing, ItemStaticData incoming)
        {
            if (!ReferenceEquals(existing, incoming))
                throw new InvalidOperationException("InstanceID was reused with a different static definition. Clear session state on world load.");
        }
    }
}
