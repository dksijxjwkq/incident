using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>Ordered container data; index 0 is the bottom, the last index is the top.</summary>
    public sealed class MagazineState
    {
        private readonly List<AmmoRound> _rounds = new List<AmmoRound>();
        private readonly ReadOnlyCollection<AmmoRound> _readOnlyRounds;
        public uint InstanceID { get; }
        public ItemStaticData Data { get; }
        public int Capacity { get; }
        public int Count => _rounds.Count;
        public IReadOnlyList<AmmoRound> Rounds => _readOnlyRounds;
        public uint OwnerWeaponID { get; internal set; }
        public event Action Changed;
        public long WeightGrams
        {
            get
            {
                long total = Data.WeightGrams;
                for (int i = 0; i < _rounds.Count; i++) total = checked(total + _rounds[i].WeightGrams);
                return total;
            }
        }

        public MagazineState(uint instanceID, ItemStaticData data)
        {
            if (instanceID == 0) throw new ArgumentOutOfRangeException(nameof(instanceID));
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (data.Type != ItemType.Magazine || data.Magazine == null ||
                data.Magazine.Capacity < 1 || string.IsNullOrWhiteSpace(data.Caliber) || data.WeightGrams < 0)
                throw new ArgumentException("Magazine requires caliber, capacity and base weight.", nameof(data));
            InstanceID = instanceID;
            Data = data;
            Capacity = data.Magazine.Capacity;
            _readOnlyRounds = _rounds.AsReadOnly();
        }

        public bool TryPush(AmmoRound round)
        {
            if (round == null || Count >= Capacity || !string.Equals(round.Caliber, Data.Caliber, StringComparison.Ordinal))
                return false;
            _rounds.Add(round);
            Changed?.Invoke();
            return true;
        }

        public bool TryPeek(out AmmoRound round)
        {
            round = Count == 0 ? null : _rounds[Count - 1];
            return round != null;
        }

        public bool TryPop(out AmmoRound round)
        {
            if (!TryPeek(out round)) return false;
            _rounds.RemoveAt(Count - 1);
            Changed?.Invoke();
            return true;
        }

        public bool IsCompatibleWith(ItemStaticData weapon)
        {
            return weapon != null && weapon.Type == ItemType.Weapon && weapon.Weapon != null &&
                weapon.Weapon.MagazineCapacity > 0 &&
                string.Equals(Data.Caliber, weapon.Caliber, StringComparison.Ordinal) &&
                Data.Magazine.WeaponClass == weapon.Weapon.Class;
        }
    }
}
