using System;
using System.Collections.Generic;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>The player's ownership boundary. Container and ground controllers never enter this list.</summary>
    public static class CombatPlayerInventory
    {
        public static List<InventoryItem> CollectOwnedRoots(IEnumerable<InventoryItem> equipment,
            InventoryController pockets, InventoryController pocket2, InventoryController wornBackpack,
            Action<InventoryItem> synchronizeBackpack = null)
        {
            var roots = new List<InventoryItem>();
            var seen = new HashSet<uint>();
            if (equipment != null)
                foreach (var item in equipment) Add(item, roots, seen, synchronizeBackpack);
            AddController(pockets, roots, seen, synchronizeBackpack);
            AddController(pocket2, roots, seen, synchronizeBackpack);
            AddController(wornBackpack, roots, seen, synchronizeBackpack);
            return roots;
        }

        private static void AddController(InventoryController controller, List<InventoryItem> roots,
            HashSet<uint> seen, Action<InventoryItem> synchronize)
        {
            if (controller == null || controller.IsDisposed) return;
            for (int y = 0; y < controller.Height; y++)
                for (int x = 0; x < controller.Width; x++)
                {
                    var item = controller.GetItemAt(x, y);
                    if (item != null && controller.IsRootCell(item.InstanceID, x, y))
                        Add(item, roots, seen, synchronize);
                }
        }

        private static void Add(InventoryItem item, List<InventoryItem> roots, HashSet<uint> seen,
            Action<InventoryItem> synchronize)
        {
            if (item == null || !seen.Add(item.InstanceID)) return;
            if (item.Data != null && item.Data.IsBackpack) synchronize?.Invoke(item);
            roots.Add(item);
        }
    }
}
