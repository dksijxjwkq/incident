using System;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    public static class AmmoStackRules
    {
        public static bool CanStack(ItemStaticData first, ItemStaticData second)
        {
            return first != null && second != null && first.Type == ItemType.Ammo && second.Type == ItemType.Ammo &&
                first.Ammunition != null && second.Ammunition != null && !string.IsNullOrWhiteSpace(first.Caliber) &&
                string.Equals(first.Caliber, second.Caliber, StringComparison.Ordinal) &&
                first.Ammunition.Type == second.Ammunition.Type;
        }

        public static int GetAvailableSpace(ItemStaticData ammunition, int currentQuantity,
            WeaponBalanceConfig balance, bool largeStack = false)
        {
            if (balance == null) throw new ArgumentNullException(nameof(balance));
            if (ammunition == null || ammunition.Type != ItemType.Ammo || currentQuantity < 0)
                throw new ArgumentException("Expected ammunition and a nonnegative count.");
            return Math.Max(0, balance.GetStackLimit(ammunition, largeStack) - currentQuantity);
        }
    }
}
