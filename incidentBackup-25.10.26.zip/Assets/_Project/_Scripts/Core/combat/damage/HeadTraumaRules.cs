using System;

namespace K_Incident.Core.Combat
{
    /// <summary>Threshold/status policy only; does not apply HP damage or perform a shot.</summary>
    public static class HeadTraumaRules
    {
        public static void Apply(IDamageReceiver receiver, BodyPart part, float firearmDamage,
            float chanceMultiplier = 1f, float probabilitySample = 0f, K_HealthConfig healthConfig = null)
        {
            if (receiver == null) throw new ArgumentNullException(nameof(receiver));
            DamageValidation.PartIndex(part);
            DamageValidation.NonNegative(firearmDamage, nameof(firearmDamage));
            DamageValidation.Probability(chanceMultiplier, nameof(chanceMultiplier));
            DamageValidation.Probability(probabilitySample, nameof(probabilitySample));
            if (part != BodyPart.Head || probabilitySample >= chanceMultiplier) return;

            K_HealthConfig config = healthConfig != null ? healthConfig : K_HealthConfig.Instance;
            float concussionThreshold = config != null ? config.ConcussionDamageThreshold : 15f;
            float tbiThreshold = config != null ? config.TbiDamageThreshold : 20f;
            DamageValidation.NonNegative(concussionThreshold, "concussionThreshold");
            DamageValidation.NonNegative(tbiThreshold, "tbiThreshold");
            if (firearmDamage >= concussionThreshold)
                receiver.ApplyStatus(BodyPart.Head, new DamageStatus(DamageType.Concussion));
            if (firearmDamage >= tbiThreshold)
                receiver.ApplyStatus(BodyPart.Head, new DamageStatus(DamageType.TraumaticBrainInjury));
        }
    }
}
