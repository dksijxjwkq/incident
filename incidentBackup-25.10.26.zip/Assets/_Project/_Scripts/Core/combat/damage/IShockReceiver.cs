namespace K_Incident.Core.Combat
{
    /// <summary>Optional timer capability; keeps the stage 5.1 HP/status contract intact.</summary>
    public interface IShockReceiver
    {
        void ApplyShock(float duration);
    }
}
