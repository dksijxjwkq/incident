using System;

namespace K_Incident.Core.Combat
{
    /// <summary>NPC health data only. A future NPC owner supplies Tick; no behaviour or spawning.</summary>
    public sealed class NpcDamageReceiver : IDamageReceiver, IShockReceiver
    {
        private sealed class Segment
        {
            internal float HP;
            internal float MaxHP;
            internal bool Fractured;
            internal bool Gunshot;
            internal LacerationType Laceration;
            internal int BleedingLevel;
            internal bool InternalBleeding;
            internal bool InternalBleedingRevealed;
            internal float RevealTimer;
        }

        private readonly Segment[] _segments = new Segment[DamageValidation.SegmentCount];
        private readonly K_HealthConfig _healthConfig;
        private readonly Func<float> _random01;
        private float _concussionTimer;
        private bool _tbi;
        private float _shockTimer;

        public bool IsShocked => _shockTimer > 0f;

        public void ApplyShock(float duration)
        {
            DamageValidation.NonNegative(duration, nameof(duration));
            _shockTimer = Math.Max(_shockTimer, duration);
        }

        public NpcDamageReceiver(K_HealthSystem healthTemplate = null,
            K_HealthConfig healthConfig = null, Func<float> random01 = null)
        {
            _healthConfig = healthConfig;
            _random01 = random01 ?? (() => UnityEngine.Random.value);
            for (int i = 0; i < _segments.Length; i++)
            {
                float hp = healthTemplate != null ? healthTemplate.GetMaxHP((BodyPart)i) : K_HealthSystem.GetDefaultBaseHP((BodyPart)i);
                DamageValidation.NonNegative(hp, "baseHP");
                if (hp == 0f) throw new ArgumentException("Every segment must have positive base HP.", nameof(healthTemplate));
                _segments[i] = new Segment { HP = hp, MaxHP = hp };
            }
        }

        public event Action OnDeath;
        public bool IsDead { get; private set; }
        public float GetHP(BodyPart part) => _segments[DamageValidation.PartIndex(part)].HP;
        public float GetMaxHP(BodyPart part) => _segments[DamageValidation.PartIndex(part)].MaxHP;

        public DamageStatusState GetStatus(BodyPart part)
        {
            Segment state = _segments[DamageValidation.PartIndex(part)];
            bool head = part == BodyPart.Head;
            return new DamageStatusState(state.Fractured, state.Gunshot, state.Laceration,
                state.BleedingLevel, state.InternalBleeding, state.InternalBleedingRevealed,
                head && (_concussionTimer > 0f || state.Fractured), head && _tbi);
        }

        public void ApplyDamage(BodyPart part, float damage, DamageType source = DamageType.Generic)
        {
            int index = DamageValidation.PartIndex(part);
            DamageValidation.NonNegative(damage, nameof(damage));
            DamageValidation.Source(source);
            if (IsDead || damage == 0f) return;

            Segment segment = _segments[index];
            float applied = Math.Min(segment.HP, damage);
            segment.HP -= applied;
            float overflow = damage - applied;
            if (overflow > 0f && part != BodyPart.Head && part != BodyPart.Chest)
            {
                Segment chest = _segments[(int)BodyPart.Chest];
                chest.HP = Math.Max(0f, chest.HP - overflow);
            }
            if (_segments[(int)BodyPart.Head].HP <= 0f || _segments[(int)BodyPart.Chest].HP <= 0f)
            {
                IsDead = true;
                OnDeath?.Invoke();
            }
        }

        public void ApplyStatus(BodyPart part, DamageStatus status)
        {
            Segment state = _segments[DamageValidation.PartIndex(part)];
            status.Validate();
            switch (status.Type)
            {
                case DamageType.Fracture:
                    if (part == BodyPart.Stomach || state.Fractured) return;
                    float sample = _random01();
                    DamageValidation.Probability(sample, "random01");
                    state.Fractured = true;
                    if (sample < 0.15f) SetInternalBleeding(state);
                    break;
                case DamageType.Gunshot: state.Gunshot = true; break;
                case DamageType.Laceration: state.Laceration = status.Laceration; break;
                case DamageType.ExternalBleeding: state.BleedingLevel = status.BleedingLevel; break;
                case DamageType.InternalBleeding: SetInternalBleeding(state); break;
                case DamageType.Concussion:
                    RequireHead(part);
                    K_HealthConfig config = _healthConfig != null ? _healthConfig : K_HealthConfig.Instance;
                    if (config != null && !config.GetDebuff(DebuffKind.Concussion).enabled) return;
                    float duration = config != null ? config.GetDebuff(DebuffKind.Concussion).duration : 60f;
                    DamageValidation.NonNegative(duration, "concussionDuration");
                    if (duration == 0f) throw new InvalidOperationException("Concussion duration must be positive.");
                    _concussionTimer = Math.Max(_concussionTimer, duration);
                    break;
                case DamageType.TraumaticBrainInjury:
                    RequireHead(part);
                    K_HealthConfig tbiConfig = _healthConfig != null ? _healthConfig : K_HealthConfig.Instance;
                    if (tbiConfig == null || tbiConfig.GetDebuff(DebuffKind.TBI).enabled) _tbi = true;
                    break;
            }
        }

        public void Tick(float deltaTime)
        {
            DamageValidation.NonNegative(deltaTime, nameof(deltaTime));
            if (IsDead || deltaTime == 0f) return;
            _shockTimer = Math.Max(0f, _shockTimer - deltaTime);
            _concussionTimer = Math.Max(0f, _concussionTimer - deltaTime);
            foreach (Segment state in _segments)
            {
                if (!state.InternalBleeding || state.InternalBleedingRevealed) continue;
                state.RevealTimer = Math.Max(0f, state.RevealTimer - deltaTime);
                if (state.RevealTimer == 0f) state.InternalBleedingRevealed = true;
            }
        }

        private static void SetInternalBleeding(Segment state)
        {
            if (state.InternalBleeding) return;
            state.InternalBleeding = true;
            state.InternalBleedingRevealed = false;
            state.RevealTimer = 120f;
        }

        private static void RequireHead(BodyPart part)
        {
            if (part != BodyPart.Head) throw new ArgumentException("Head trauma requires the head segment.", nameof(part));
        }
    }
}
