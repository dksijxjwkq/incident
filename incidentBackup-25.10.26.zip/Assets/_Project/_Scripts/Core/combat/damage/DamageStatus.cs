using System;

namespace K_Incident.Core.Combat
{
    /// <summary>One status command. Existing health enums retain their original IDs.</summary>
    public readonly struct DamageStatus
    {
        public DamageType Type { get; }
        public LacerationType Laceration { get; }
        public int BleedingLevel { get; }

        public DamageStatus(DamageType type, LacerationType laceration = LacerationType.Open, int bleedingLevel = 1)
        {
            Type = type;
            Laceration = laceration;
            BleedingLevel = bleedingLevel;
            Validate();
        }

        public void Validate()
        {
            if (Type < DamageType.Fracture || Type > DamageType.TraumaticBrainInjury)
                throw new ArgumentOutOfRangeException(nameof(Type), "Use ApplyDamage for HP damage.");
            if (Type == DamageType.Laceration && (Laceration < LacerationType.Open || Laceration > LacerationType.Sealed))
                throw new ArgumentOutOfRangeException(nameof(Laceration));
            if (Type == DamageType.ExternalBleeding && (BleedingLevel < 1 || BleedingLevel > 3))
                throw new ArgumentOutOfRangeException(nameof(BleedingLevel));
        }
    }

    /// <summary>Value snapshot of existing statuses, without ownership of their runtime state.</summary>
    public readonly struct DamageStatusState
    {
        public bool Fractured { get; }
        public bool Gunshot { get; }
        public LacerationType Laceration { get; }
        public int BleedingLevel { get; }
        public bool InternalBleeding { get; }
        public bool InternalBleedingRevealed { get; }
        public bool Concussion { get; }
        public bool TraumaticBrainInjury { get; }

        public DamageStatusState(bool fractured, bool gunshot, LacerationType laceration,
            int bleedingLevel, bool internalBleeding, bool internalBleedingRevealed,
            bool concussion, bool traumaticBrainInjury)
        {
            Fractured = fractured;
            Gunshot = gunshot;
            Laceration = laceration;
            BleedingLevel = bleedingLevel;
            InternalBleeding = internalBleeding;
            InternalBleedingRevealed = internalBleedingRevealed;
            Concussion = concussion;
            TraumaticBrainInjury = traumaticBrainInjury;
        }
    }
}
