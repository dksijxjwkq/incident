using System;

namespace K_Incident.Core.Combat
{
    /// <summary>Shared player/NPC contract. HP and injury statuses are independent calls.</summary>
    public interface IDamageReceiver
    {
        event Action OnDeath;
        bool IsDead { get; }
        float GetHP(BodyPart part);
        float GetMaxHP(BodyPart part);
        DamageStatusState GetStatus(BodyPart part);
        void ApplyDamage(BodyPart part, float damage, DamageType source = DamageType.Generic);
        void ApplyStatus(BodyPart part, DamageStatus status);
    }
}
