using System;

namespace K_Incident.Core.Combat
{
    /// <summary>Plain adapter: all player HP/status/timer ownership remains in existing systems.</summary>
    public sealed class PlayerDamageReceiver : IDamageReceiver, IShockReceiver
    {
        private readonly K_HealthSystem _health;
        private readonly K_DebuffSystem _debuffs;
        private readonly K_HealthConfig _healthConfig;
        private readonly Func<float> _random01;

        public PlayerDamageReceiver(K_HealthSystem health, K_DebuffSystem debuffs,
            Func<float> random01 = null, K_HealthConfig healthConfig = null)
        {
            _health = health != null ? health : throw new ArgumentNullException(nameof(health));
            _debuffs = debuffs != null ? debuffs : throw new ArgumentNullException(nameof(debuffs));
            _healthConfig = healthConfig;
            _random01 = random01 ?? (() => UnityEngine.Random.value);
        }

        public event Action OnDeath
        {
            add { _health.OnDeath += value; }
            remove { _health.OnDeath -= value; }
        }

        public bool IsDead => _health.IsDead;

        public void ApplyShock(float duration) => _health.ApplyShock(duration);

        public float GetHP(BodyPart part)
        {
            DamageValidation.PartIndex(part);
            return _health.GetHP(part);
        }

        public float GetMaxHP(BodyPart part)
        {
            DamageValidation.PartIndex(part);
            return _health.GetMaxHP(part);
        }

        public DamageStatusState GetStatus(BodyPart part)
        {
            DamageValidation.PartIndex(part);
            return new DamageStatusState(_health.IsFractured(part), _health.IsGunshot(part),
                _health.GetLacerationType(part), _health.GetBleedingLevel(part),
                _health.HasInternalBleeding(part), _health.IsInternalBleedingRevealed(part),
                part == BodyPart.Head && _debuffs.HasConcussion,
                part == BodyPart.Head && _debuffs.HasTBI);
        }

        public void ApplyDamage(BodyPart part, float damage, DamageType source = DamageType.Generic)
            => _health.ApplySegmentDamage(damage, part, source);

        // Status commands may record the injuries of the same fatal impact after HP reaches zero.
        public void ApplyStatus(BodyPart part, DamageStatus status)
        {
            DamageValidation.PartIndex(part);
            status.Validate();
            switch (status.Type)
            {
                case DamageType.Fracture:
                    if (!_health.IsFractured(part) && part != BodyPart.Stomach)
                    {
                        float sample = _random01();
                        DamageValidation.Probability(sample, "random01");
                        _health.ApplyCombatFracture(part, sample);
                        _debuffs.RefreshCombatDerivedDebuffs();
                    }
                    break;
                case DamageType.Gunshot:
                    _health.ApplyGunshot(part);
                    _debuffs.RefreshCombatDerivedDebuffs();
                    break;
                case DamageType.Laceration:
                    _health.SetCombatLaceration(part, status.Laceration);
                    break;
                case DamageType.ExternalBleeding:
                    _health.SetBleedingLevelOnPart(part, status.BleedingLevel);
                    break;
                case DamageType.InternalBleeding:
                    _health.ApplyCombatInternalBleeding(part);
                    break;
                case DamageType.Concussion:
                    RequireHead(part);
                    _debuffs.ApplyCombatConcussion(_healthConfig);
                    break;
                case DamageType.TraumaticBrainInjury:
                    RequireHead(part);
                    _debuffs.ApplyCombatTBI(_healthConfig);
                    break;
            }
        }

        private static void RequireHead(BodyPart part)
        {
            if (part != BodyPart.Head) throw new ArgumentException("Head trauma requires the head segment.", nameof(part));
        }
    }
}
