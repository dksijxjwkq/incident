using System;

namespace K_Incident.Core.Combat
{
    internal static class DamageValidation
    {
        internal const int SegmentCount = 20;

        internal static int PartIndex(BodyPart part)
        {
            int index = (int)part;
            if (index < 0 || index >= SegmentCount) throw new ArgumentOutOfRangeException(nameof(part));
            return index;
        }

        internal static void NonNegative(float value, string name)
        {
            if (float.IsNaN(value) || float.IsInfinity(value) || value < 0f)
                throw new ArgumentOutOfRangeException(name);
        }

        internal static void Probability(float value, string name)
        {
            if (float.IsNaN(value) || value < 0f || value > 1f)
                throw new ArgumentOutOfRangeException(name);
        }

        internal static void Source(DamageType source)
        {
            if (source < DamageType.Generic || source > DamageType.Cold)
                throw new ArgumentOutOfRangeException(nameof(source), "HP damage requires a source, not a status.");
        }
    }
}
