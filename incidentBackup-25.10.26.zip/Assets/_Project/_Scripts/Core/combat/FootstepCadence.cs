using System;

namespace K_Incident.Core.Combat
{
    public enum FootstepSurfaceType { Wood, Metal }

    [Serializable]
    public struct FootstepSurfaceLayer
    {
        public int Layer;
        public FootstepSurfaceType Surface;
    }

    public static class FootstepSurfaceMapping
    {
        public static FootstepSurfaceType Resolve(int layer, FootstepSurfaceLayer[] mapping)
        {
            if (mapping != null)
                foreach (var entry in mapping)
                    if (entry.Layer == layer) return entry.Surface;
            return FootstepSurfaceType.Wood;
        }
    }

    /// <summary>Distance already travelled, independent of frame rate, input intent or Unity physics.</summary>
    public sealed class FootstepCadence
    {
        private double _distance;
        public void Reset() => _distance = 0;

        public int Advance(float horizontalDistance, float distancePerStep)
        {
            if (float.IsNaN(horizontalDistance) || float.IsInfinity(horizontalDistance) || horizontalDistance < 0f)
                throw new ArgumentOutOfRangeException(nameof(horizontalDistance));
            if (float.IsNaN(distancePerStep) || float.IsInfinity(distancePerStep) || distancePerStep <= 0f)
                throw new ArgumentOutOfRangeException(nameof(distancePerStep));
            double distance = _distance + horizontalDistance;
            double count = Math.Floor(distance / distancePerStep);
            if (count > int.MaxValue) throw new ArgumentOutOfRangeException(nameof(horizontalDistance));
            _distance = distance - count * distancePerStep;
            return (int)count;
        }
    }
}
