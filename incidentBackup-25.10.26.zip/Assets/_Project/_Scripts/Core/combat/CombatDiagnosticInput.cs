using System;

namespace K_Incident.Core.Combat
{
    /// <summary>One explicit diagnostic owner supplies the live Inspector mode to both input paths.</summary>
    public static class CombatDiagnosticInput
    {
        private static object _owner;
        private static Func<bool> _isEnabled;

        public static bool IsDiagnosticsEnabled => _owner != null && _isEnabled != null && _isEnabled();

        public static bool IsReservedControlChord(bool controlPressed) => controlPressed && IsDiagnosticsEnabled;

        public static void RegisterOwner(object owner, Func<bool> isEnabled)
        {
            if (owner == null) throw new ArgumentNullException(nameof(owner));
            if (isEnabled == null) throw new ArgumentNullException(nameof(isEnabled));
            _owner = owner;
            _isEnabled = isEnabled;
        }

        public static void UnregisterOwner(object owner)
        {
            if (!ReferenceEquals(owner, _owner)) return;
            _owner = null;
            _isEnabled = null;
        }
    }
}
