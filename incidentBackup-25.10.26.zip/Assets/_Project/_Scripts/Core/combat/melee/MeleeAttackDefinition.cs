using System;
using UnityEngine;

namespace K_Incident.Core.Combat
{
    /// <summary>Independent authoring data for one melee item or the player's fist.</summary>
    [Serializable]
    public sealed class MeleeAttackDefinition
    {
        [Min(.001f)] public float Damage = 25f;
        [Min(.001f)] public float Range = 1.5f;
        [Min(.001f)] public float Interval = .5f;

        public void Validate()
        {
            Positive(Damage, nameof(Damage));
            Positive(Range, nameof(Range));
            Positive(Interval, nameof(Interval));
        }

        private static void Positive(float value, string name)
        {
            if (float.IsNaN(value) || float.IsInfinity(value) || value <= 0f)
                throw new InvalidOperationException("Configured melee " + name + " must be finite and positive.");
        }
    }
}
