using System;

namespace K_Incident.Core.Combat
{
    public enum MeleeAttackOutcome { Hit = 0, Miss = 1, Blocked = 2, Cooldown = 3 }

    public readonly struct MeleeAttackResult
    {
        public readonly MeleeAttackOutcome Outcome;
        public readonly ShotHit? Hit;
        public bool Attacked => Outcome != MeleeAttackOutcome.Cooldown;

        public MeleeAttackResult(MeleeAttackOutcome outcome, ShotHit? hit = null)
        {
            Outcome = outcome;
            Hit = hit;
        }
    }

    /// <summary>One player-owned cooldown and one HP-only ray per accepted melee/fist click.</summary>
    public sealed class MeleeAttackController
    {
        private readonly IShotWorld _world;
        private float _cooldown;

        public float CooldownRemaining => _cooldown;

        public MeleeAttackController(IShotWorld world)
        {
            _world = world ?? throw new ArgumentNullException(nameof(world));
        }

        public void Tick(float deltaTime)
        {
            DamageValidation.NonNegative(deltaTime, nameof(deltaTime));
            _cooldown = Math.Max(0f, _cooldown - deltaTime);
        }

        public MeleeAttackResult TryAttack(MeleeAttackDefinition definition, ShotRay playerRay)
        {
            if (definition == null) throw new ArgumentNullException(nameof(definition));
            definition.Validate();
            // Reconstruct to reject a default/zero-direction ray before touching cooldown or physics.
            var ray = new ShotRay(playerRay.Origin, playerRay.Direction);
            if (_cooldown > 0f) return new MeleeAttackResult(MeleeAttackOutcome.Cooldown);

            // A miss, wall or corpse still consumes the swing; changing items does not reset it.
            _cooldown = definition.Interval;
            if (!_world.Raycast(ray, definition.Range, out ShotHit hit) || hit.Distance > definition.Range)
                return new MeleeAttackResult(MeleeAttackOutcome.Miss);
            if (hit.Receiver == null || hit.Receiver.IsDead)
                return new MeleeAttackResult(MeleeAttackOutcome.Blocked, hit);

            hit.Receiver.ApplyDamage(hit.Part, definition.Damage, DamageType.Generic);
            return new MeleeAttackResult(MeleeAttackOutcome.Hit, hit);
        }
    }
}
