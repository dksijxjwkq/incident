using System;

namespace K_Incident.Core.Combat
{
    [Serializable]
    public struct ArmorClassBalance
    {
        public int Class;
        public float DamageReduction;
        public float BaseDurability;
        public float FractureMultiplier;
        public float ConcussionMultiplier;

        public ArmorClassBalance(int armorClass, float reduction, float durability, float injuryMultiplier)
        {
            Class = armorClass;
            DamageReduction = reduction;
            BaseDurability = durability;
            FractureMultiplier = injuryMultiplier;
            ConcussionMultiplier = injuryMultiplier;
        }
    }

    [Serializable]
    public struct CaliberBalance
    {
        public string Id;
        public float ArmorDamageMultiplier;
        public int DefaultStackLimit;
        public int LargeStackLimit;

        public CaliberBalance(string id, float armorMultiplier, int stack, int largeStack)
        {
            Id = id;
            ArmorDamageMultiplier = armorMultiplier;
            DefaultStackLimit = stack;
            LargeStackLimit = largeStack;
        }
    }

    [Serializable]
    public struct AmmoTypeBalance
    {
        public AmmoType Id;
        public float ArmorDamageMultiplier;
        public float DamageMultiplier;
        public float AdditionalMisfireChance;
        public float WearMultiplier;

        public AmmoTypeBalance(AmmoType id, float damage, float armorDamage, float jam = 0f, float wear = 1f)
        {
            Id = id;
            DamageMultiplier = damage;
            ArmorDamageMultiplier = armorDamage;
            AdditionalMisfireChance = jam;
            WearMultiplier = wear;
        }
    }

    [Serializable]
    public struct ItemStackLimit
    {
        public string ItemId;
        public int Limit;
    }

    [Serializable]
    public struct WeaponTypeBalance
    {
        public WeaponType Id;
        public FireMode FireMode;
        public int MagazineCapacity;
        public int InternalMagazineCapacity;
        public int ChamberCapacity;
        public WeaponClass Class;

        public WeaponTypeBalance(WeaponType id, WeaponClass weaponClass, FireMode mode,
            int capacity, int chambers = 1, int internalCapacity = 0)
        {
            Id = id;
            Class = weaponClass;
            FireMode = mode;
            MagazineCapacity = capacity;
            ChamberCapacity = chambers;
            InternalMagazineCapacity = internalCapacity;
        }
    }
}
