using System;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core.Combat
{
    /// <summary>Stage 5.1 balance data. No shooting, reload, wear or persistence.</summary>
    [CreateAssetMenu(fileName = "WeaponBalanceConfig", menuName = "INCIDENT/Weapon Balance Config")]
    public sealed class WeaponBalanceConfig : ScriptableObject
    {
        [Header("Armor classes")]
        public ArmorClassBalance[] ArmorClasses =
        {
            new ArmorClassBalance(1, .10f, 100f, .95f),
            new ArmorClassBalance(2, .20f, 120f, .90f),
            new ArmorClassBalance(3, .30f, 150f, .80f),
            new ArmorClassBalance(4, .40f, 180f, .70f),
            new ArmorClassBalance(5, .50f, 220f, .60f)
        };

        [Header("Calibers and stack presets")]
        public CaliberBalance[] Calibers =
        {
            new CaliberBalance("9x18", 1f, 30, 60),
            new CaliberBalance("9x19", 1f, 30, 60),
            new CaliberBalance("5.45x39", 1.2f, 30, 60),
            new CaliberBalance("5.56x45", 1.2f, 30, 60),
            new CaliberBalance("7.62x39", 1.2f, 30, 60),
            new CaliberBalance("7.62x54R", 1.5f, 10, 20),
            new CaliberBalance("12g", 1.3f, 8, 12)
        };

        [Header("Ammunition types")]
        public AmmoTypeBalance[] AmmoTypes =
        {
            new AmmoTypeBalance(AmmoType.Standard, 1f, 1f),
            new AmmoTypeBalance(AmmoType.ArmorPiercing, .8f, 1.5f),
            new AmmoTypeBalance(AmmoType.Expanding, 1.3f, .7f),
            new AmmoTypeBalance(AmmoType.Improvised, .9f, .8f, .05f, 2f)
        };

        [Header("Item ID stack overrides")]
        public ItemStackLimit[] StackLimits = Array.Empty<ItemStackLimit>();

        [Header("Weapon type templates (item definitions may override)")]
        public WeaponTypeBalance[] WeaponTypes =
        {
            new WeaponTypeBalance(WeaponType.Pistol, WeaponClass.Pistol, FireMode.Single, 8),
            new WeaponTypeBalance(WeaponType.AssaultRifle, WeaponClass.AssaultRifle, FireMode.Auto, 30),
            new WeaponTypeBalance(WeaponType.Shotgun, WeaponClass.Shotgun, FireMode.Single, 0, 1, 5),
            new WeaponTypeBalance(WeaponType.Rifle, WeaponClass.Rifle, FireMode.Single, 10),
            new WeaponTypeBalance(WeaponType.SubmachineGun, WeaponClass.SubmachineGun, FireMode.Auto, 30),
            new WeaponTypeBalance(WeaponType.DoubleBarrel, WeaponClass.Shotgun, FireMode.Single, 0, 2),
            new WeaponTypeBalance(WeaponType.BoltAction, WeaponClass.Rifle, FireMode.Single, 0, 1, 5)
        };

        [Header("Reload speed data only")]
        [Min(0f)] public float ReloadSpeed = 1f;

        public ArmorClassBalance GetArmorClass(int armorClass)
        {
            foreach (var entry in ArmorClasses)
                if (entry.Class == armorClass)
                {
                    RequireUnit(entry.DamageReduction, "armor damage reduction");
                    RequirePositive(entry.BaseDurability, "armor base durability");
                    RequireUnit(entry.FractureMultiplier, "armor fracture multiplier");
                    RequireUnit(entry.ConcussionMultiplier, "armor concussion multiplier");
                    return entry;
                }
            throw new ArgumentOutOfRangeException(nameof(armorClass), "Armor class is not configured.");
        }

        public CaliberBalance GetCaliber(string id)
        {
            foreach (var entry in Calibers)
                if (string.Equals(entry.Id, id, StringComparison.Ordinal))
                {
                    RequireNonNegative(entry.ArmorDamageMultiplier, "caliber armor multiplier");
                    if (entry.DefaultStackLimit < 1 || entry.LargeStackLimit < entry.DefaultStackLimit)
                        throw new InvalidOperationException("Caliber stack limits are invalid.");
                    return entry;
                }
            throw new ArgumentException("Caliber is not configured: " + id, nameof(id));
        }

        public AmmoTypeBalance GetAmmoType(AmmoType type)
        {
            foreach (var entry in AmmoTypes)
                if (entry.Id == type)
                {
                    RequireNonNegative(entry.DamageMultiplier, "ammo damage multiplier");
                    RequireNonNegative(entry.ArmorDamageMultiplier, "ammo armor multiplier");
                    RequireUnit(entry.AdditionalMisfireChance, "ammo misfire chance");
                    RequireNonNegative(entry.WearMultiplier, "ammo wear multiplier");
                    return entry;
                }
            throw new ArgumentOutOfRangeException(nameof(type), "Ammo type is not configured.");
        }

        public WeaponTypeBalance GetWeaponType(WeaponType type)
        {
            foreach (var entry in WeaponTypes)
                if (entry.Id == type) return entry;
            throw new ArgumentOutOfRangeException(nameof(type), "Weapon type is not configured.");
        }

        public int GetStackLimit(ItemStaticData item, bool largeStack = false)
        {
            if (item == null) throw new ArgumentNullException(nameof(item));
            foreach (var entry in StackLimits)
                if (entry.ItemId == item.ItemID) return Math.Max(1, entry.Limit);
            if (item.Type != ItemType.Ammo) return item.HardStackLimit;
            var caliber = GetCaliber(item.Caliber);
            return largeStack ? caliber.LargeStackLimit : caliber.DefaultStackLimit;
        }

        // The existing arm aim array has the specified .85/.65/.40 progression.
        // A direct reference avoids a second, independently drifting copy.
        public float GetReloadSpeedMultiplier(int armLevel, K_HealthConfig healthConfig)
        {
            if (healthConfig == null) throw new ArgumentNullException(nameof(healthConfig));
            RequireNonNegative(ReloadSpeed, "reload speed");
            float armMultiplier = healthConfig.GetArmAimMultiplier(armLevel);
            RequireNonNegative(armMultiplier, "health arm multiplier");
            return ReloadSpeed * armMultiplier;
        }

        private static void RequireNonNegative(float value, string label)
        {
            if (float.IsNaN(value) || float.IsInfinity(value) || value < 0f)
                throw new InvalidOperationException("Invalid configured " + label + ".");
        }

        private static void RequirePositive(float value, string label)
        {
            RequireNonNegative(value, label);
            if (value == 0f) throw new InvalidOperationException("Configured " + label + " must be positive.");
        }

        private static void RequireUnit(float value, string label)
        {
            RequireNonNegative(value, label);
            if (value > 1f) throw new InvalidOperationException("Configured " + label + " must be at most one.");
        }
    }
}
