using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Combat
{
    /// <summary>Physics boundary; plain firing rules always receive the nearest non-shooter contact.</summary>
    public sealed class UnityShotWorld : IShotWorld
    {
        private readonly Transform _shooter;
        private readonly int _mask;
        private readonly Dictionary<K_HealthSystem, PlayerDamageReceiver> _players =
            new Dictionary<K_HealthSystem, PlayerDamageReceiver>();

        public UnityShotWorld(Transform shooter, int mask) { _shooter = shooter; _mask = mask; }

        public bool Raycast(ShotRay ray, float maxDistance, out ShotHit hit)
        {
            PruneDestroyedTargets();
            var origin = ToUnity(ray.Origin);
            // Unity rays omit a collider containing their origin. A tiny overlap also
            // treats touching the surface (2 mm tolerance) as a contact, for all collider types.
            ShotHit? overlappingReceiver = null;
            foreach (var containing in Physics.OverlapSphere(origin, .002f, _mask, QueryTriggerInteraction.Ignore))
            {
                if (Ignored(containing)) continue;
                var overlap = Resolve(containing, origin, 0f);
                if (overlap.Receiver != null) { overlappingReceiver = overlap; continue; }
                hit = overlap; return true;
            }
            if (overlappingReceiver.HasValue) { hit = overlappingReceiver.Value; return true; }
            var contacts = Physics.RaycastAll(ToUnity(ray.Origin), ToUnity(ray.Direction), maxDistance,
                _mask, QueryTriggerInteraction.Ignore);
            Array.Sort(contacts, (a, b) => a.distance.CompareTo(b.distance));
            foreach (var contact in contacts)
            {
                var collider = contact.collider;
                if (Ignored(collider)) continue;
                hit = Resolve(collider, contact.point, contact.distance);
                return true;
            }
            hit = default;
            return false;
        }

        private bool Ignored(Collider collider) => collider == null ||
            (_shooter != null && collider.transform.IsChildOf(_shooter));

        private ShotHit Resolve(Collider collider, Vector3 point, float distance)
        {
            var marker = collider.GetComponentInParent<K_DamageHitbox>();
            var part = marker != null ? marker.Part : BodyPart.Chest;
            IDamageReceiver receiver = marker?.Receiver ?? collider.GetComponentInParent<IDamageReceiver>();
            ArmorState armor = marker?.GetArmor();
            var owner = collider.GetComponentInParent<K_PlayerCombatController>();
            if (receiver == null && owner != null) receiver = owner.Receiver;
            if (armor == null && owner != null) armor = owner.GetArmor(part);
            if (receiver == null)
            {
                var health = collider.GetComponentInParent<K_HealthSystem>();
                var debuffs = health != null ? health.GetComponent<K_DebuffSystem>() : null;
                if (health != null && debuffs != null)
                {
                    if (!_players.TryGetValue(health, out var player))
                    {
                        player = new PlayerDamageReceiver(health, debuffs);
                        _players.Add(health, player);
                    }
                    receiver = player;
                }
            }
            return new ShotHit(FromUnity(point), distance, collider, receiver, part, armor,
                blocksBarrel: receiver == null);
        }

        public static ShotVector FromUnity(Vector3 value) => new ShotVector(value.x, value.y, value.z);
        public void PruneDestroyedTargets()
        {
            if (_players.Count == 0) return;
            var destroyed = new List<K_HealthSystem>();
            foreach (var target in _players.Keys) if (target == null) destroyed.Add(target);
            foreach (var target in destroyed) _players.Remove(target);
        }

        public void ForgetTarget(K_HealthSystem target)
        {
            if (!ReferenceEquals(target, null)) _players.Remove(target);
        }

        public void Dispose() => _players.Clear();
        public static Vector3 ToUnity(ShotVector value) => new Vector3(value.X, value.Y, value.Z);
    }
}
