using System;

namespace K_Incident.Core.Combat
{
    public enum ActiveCombatSlot { Primary1 = 0, Primary2 = 1, Pistol = 2, Melee = 3, None = 4 }

    /// <summary>Transient hand selection; empty equipment slots remain selectable.</summary>
    public sealed class ActiveWeaponSelection
    {
        public ActiveCombatSlot Current { get; private set; } = ActiveCombatSlot.Primary1;

        public bool Select(ActiveCombatSlot slot)
        {
            if (slot < ActiveCombatSlot.Primary1 || slot > ActiveCombatSlot.None)
                return false;
            if (Current == slot) return false;
            Current = slot;
            return true;
        }

        public bool Cycle(int direction)
        {
            int step = direction % 5;
            int next = ((int)Current + step + 5) % 5;
            return Select((ActiveCombatSlot)next);
        }
    }
}
