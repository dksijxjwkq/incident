using System;

namespace K_Incident.Core.Combat
{
    public enum ReloadKeyAction { None, Reload, Check }

    /// <summary>Reserves the first R for .3s so a second press can check without starting reload.</summary>
    public sealed class ReloadKeyGesture
    {
        public const float DoublePressSeconds = .3f;
        private bool _pending;
        private float _remaining;

        public ReloadKeyAction Tick(float deltaTime, bool available, bool pressed)
        {
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime < 0f)
                throw new ArgumentOutOfRangeException(nameof(deltaTime));
            if (!available) { Cancel(); return ReloadKeyAction.None; }
            if (_pending)
            {
                _remaining -= deltaTime;
                if (pressed && _remaining >= 0f) { Cancel(); return ReloadKeyAction.Check; }
                if (_remaining <= 0f) { Cancel(); return ReloadKeyAction.Reload; }
            }
            if (pressed) { _pending = true; _remaining = DoublePressSeconds; }
            return ReloadKeyAction.None;
        }

        public void Cancel() { _pending = false; _remaining = 0f; }
    }
}
