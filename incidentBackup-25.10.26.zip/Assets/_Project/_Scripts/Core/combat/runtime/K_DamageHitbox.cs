using System;
using UnityEngine;

namespace K_Incident.Core.Combat
{
    /// <summary>Authorable collider segment marker. A future NPC owner can bind its plain receiver.</summary>
    public sealed class K_DamageHitbox : MonoBehaviour
    {
        [SerializeField] private BodyPart _part = BodyPart.Chest;
        private Func<BodyPart, ArmorState> _armor;
        public BodyPart Part => _part;
        public IDamageReceiver Receiver { get; private set; }

        public void Bind(IDamageReceiver receiver, Func<BodyPart, ArmorState> armor = null)
        {
            if (Receiver != null) Receiver.OnDeath -= RevealArmor;
            Receiver = receiver;
            _armor = armor;
            if (Receiver != null)
            {
                Receiver.OnDeath += RevealArmor;
                if (Receiver.IsDead) RevealArmor();
            }
        }

        public ArmorState GetArmor() => _armor?.Invoke(_part);

        private void RevealArmor()
        {
            _armor?.Invoke(BodyPart.Head)?.RevealCondition();
            _armor?.Invoke(BodyPart.Chest)?.RevealCondition();
            _armor?.Invoke(BodyPart.Stomach)?.RevealCondition();
        }

        private void OnDestroy()
        {
            if (Receiver != null) Receiver.OnDeath -= RevealArmor;
        }
    }
}
