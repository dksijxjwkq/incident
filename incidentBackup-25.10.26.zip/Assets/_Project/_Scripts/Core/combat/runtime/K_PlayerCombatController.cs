using System;
using System.Collections.Generic;
using K_Incident.Core.Inventory;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;

namespace K_Incident.Core.Combat
{
    /// <summary>Only the Unity input/lifetime boundary; firing and reload execution remain plain classes.</summary>
    public sealed class K_PlayerCombatController : MonoBehaviour
    {
        [SerializeField] private UnityEngine.Camera _aimCamera;
        [SerializeField] private Transform _muzzle;
        [SerializeField] private Vector3 _capsuleMuzzleOffset = new Vector3(0f, 1.2f, .35f);
        [SerializeField] private LayerMask _hitMask = ~0;
        [SerializeField] private Key _reloadKey = Key.R;
        [SerializeField] private Key _fireModeKey = Key.B;
        [SerializeField] private Key _cancelReloadKey = Key.Escape;
        [SerializeField] private CombatReloadSettings _reloadSettings = new CombatReloadSettings();
        [SerializeField] private bool _isIndoor;
        [SerializeField, Min(0f), Tooltip("Базовый радиус одного события при успешном старте перезарядки, в метрах.")]
        private float _reloadNoiseRadius = 5f;
        private int _lastReloadNoiseSerial;
        public bool IsIndoor => _isIndoor;

        [Header("Fist attack")]
        [SerializeField] private MeleeAttackDefinition _fistAttack = new MeleeAttackDefinition
            { Damage = 10f, Range = 1.2f, Interval = .6f };
        [SerializeField] private Vector3 _meleeOriginOffset = new Vector3(0f, 1.2f, 0f);

        private K_InventoryUI _inventory;
        private K_CombatContext _context;
        private K_HealthSystem _health;
        private K_VitalitySystem _vitality;
        private WeaponState _weapon;
        private WeaponFiringController _firing;
        private UnityShotWorld _world;
        private CombatReloadService _reload;
        private bool _changingInventory;
        private readonly ActiveWeaponSelection _selection = new ActiveWeaponSelection();
        private MeleeAttackController _melee;
        private readonly Dictionary<WeaponState, WeaponFiringController> _firingByWeapon =
            new Dictionary<WeaponState, WeaponFiringController>();
        private readonly List<WeaponState> _obsoleteFiring = new List<WeaponState>();
        public ActiveCombatSlot ActiveSlot => _selection.Current;
        public InventoryItem ActiveCombatItem => _inventory?.GetCombatItem(ActiveSlot);
        public IDamageReceiver Receiver { get; private set; }
        public bool IsAimBlocked => _firing != null && _firing.IsAimBlocked;
        public ShotBlockReason AimBlockReason => _firing != null ? _firing.AimStatus.BlockReason : ShotBlockReason.None;
        public bool IsReloading => _reload != null && _reload.IsReloading;
        public float ReloadProgress => _reload?.Progress ?? 0f;
        public string LastReloadError => _reload?.LastError;
        public event Action<ShotResult> ShotResolved;
        private K_InputActions _combatInput;
        private readonly ReloadKeyGesture _reloadGesture = new ReloadKeyGesture();
        private string _combatHint;
        private float _combatHintRemaining;
        public string CombatHint => _combatHintRemaining > 0f ? _combatHint : null;

        public void Initialize(K_InventoryUI inventory, K_CombatContext context, K_HealthSystem health)
        {
            if (_context != null) _context.OnItemsChanged -= OnCombatChanged;
            if (_reload != null) { _reload.StateChanged -= OnReloadChanged; _reload.Cancel(); }
            _reload?.Dispose();
            _world?.Dispose();
            _inventory = inventory;
            if (_combatInput == null) _combatInput = new K_InputActions();
            _combatInput.Player.CycleBolt.Enable();
            _context = context;
            _health = health;
            _vitality = health != null ? health.GetComponent<K_VitalitySystem>() : null;
            var debuffs = health != null ? health.GetComponent<K_DebuffSystem>() : null;
            Receiver = health != null && debuffs != null ? new PlayerDamageReceiver(health, debuffs) : null;
            _world = new UnityShotWorld(transform, _hitMask.value);
            _melee = new MeleeAttackController(_world);
            _firingByWeapon.Clear();
            _weapon = null;
            _firing = null;
            _reload = new CombatReloadService(context.Items, context.Balance, K_HealthConfig.Instance,
                settings: _reloadSettings, speedProvider: GetReloadSpeed);
            _lastReloadNoiseSerial = 0;
            _reload.StateChanged += OnReloadChanged;
            _context.OnItemsChanged += OnCombatChanged;
            if (_aimCamera == null) _aimCamera = UnityEngine.Camera.main;
            SynchronizeWeapon();
        }

        private void Update()
        {
            _combatHintRemaining = Math.Max(0f, _combatHintRemaining - Time.deltaTime);
            _world?.PruneDestroyedTargets();
            if (_inventory == null || _context == null) return;
            if (_health != null && _health.IsDead)
            {
                _reloadGesture.Cancel();
                _reload.Cancel(); _firing?.CancelBurst(); return;
            }
            _melee.Tick(Time.deltaTime);
            var keyboard = Keyboard.current;
            var mouse = Mouse.current;
            bool overUI = EventSystem.current != null && EventSystem.current.IsPointerOverGameObject();
            bool worldInput = !_inventory.IsOpen && !_inventory.IsDragging;
            bool gameplayInput = worldInput && !overUI && !IsDebugModifierPressed(keyboard);
            HandleSlotInput(keyboard, mouse, gameplayInput);
            SynchronizeWeapon();
            if (keyboard != null && keyboard[_cancelReloadKey].wasPressedThisFrame) _reload.Cancel();
            AdvanceInactiveFirearms(Time.deltaTime);
            _reload.Tick(Time.deltaTime);
            HandleReloadGesture(gameplayInput, keyboard != null && keyboard[_reloadKey].wasPressedThisFrame,
                Time.deltaTime);
            if (gameplayInput && _combatInput != null && _combatInput.Player.CycleBolt.WasPressedThisFrame())
            {
                if (!TryCycleWeaponChamber(ActiveCombatItem, out var reason)) ShowCombatHint(reason);
            }
            if (gameplayInput && keyboard != null && keyboard[_fireModeKey].wasPressedThisFrame)
                CycleFireMode(ActiveCombatItem);
            bool pressed = gameplayInput && mouse != null && mouse.leftButton.wasPressedThisFrame;
            bool held = gameplayInput && mouse != null && mouse.leftButton.isPressed;
            if (pressed && IsReloading) _reload.Cancel();
            if (ActiveSlot == ActiveCombatSlot.None || ActiveCombatItem?.Data?.IsMelee == true)
            {
                HandleMeleeInput(pressed);
                return;
            }
            if (_firing == null || _aimCamera == null) return;
            Vector2 screen = mouse != null ? mouse.position.ReadValue() : new Vector2(Screen.width / 2f, Screen.height / 2f);
            var cameraRay = _aimCamera.ScreenPointToRay(screen);
            Vector3 position = _muzzle != null ? _muzzle.position : transform.TransformPoint(_capsuleMuzzleOffset);
            Vector3 forward = _muzzle != null ? _muzzle.forward : transform.forward;
            var aim = new ShotAim(new ShotRay(UnityShotWorld.FromUnity(cameraRay.origin),
                UnityShotWorld.FromUnity(cameraRay.direction)), UnityShotWorld.FromUnity(position),
                UnityShotWorld.FromUnity(forward));
            if (!gameplayInput || IsReloading)
            {
                _firing.CancelBurst(); pressed = false; held = false;
            }
            _firing.SetArmAimMultiplier(_health != null ? _health.GetArmAimMultiplier() : 1f);
            _firing.Tick(Time.deltaTime, pressed, held, aim);
        }

        public bool SelectSlot(ActiveCombatSlot slot)
        {
            if (!_selection.Select(slot)) return false;
            OnActiveSlotChanged();
            return true;
        }

        public bool CycleSlot(int direction)
        {
            if (!_selection.Cycle(direction)) return false;
            OnActiveSlotChanged();
            return true;
        }

        private void OnActiveSlotChanged()
        {
            _reloadGesture.Cancel();
            // Empty-to-empty changes also interrupt a reload started from an inventory menu.
            _reload?.Cancel();
            _firing?.CancelBurst();
            if (_inventory != null && _context != null) SynchronizeWeapon();
            Debug.Log($"[Combat] Active slot: {ActiveSlot}, item: {ActiveCombatItem?.Data?.ItemID ?? "none"}");
        }

        private void HandleSlotInput(Keyboard keyboard, Mouse mouse, bool gameplayInput)
        {
            if (!gameplayInput) return;
            if (keyboard != null)
            {
                for (int i = 0; i < 5; i++)
                    if (keyboard[(Key)((int)Key.Digit1 + i)].wasPressedThisFrame)
                    {
                        SelectSlot((ActiveCombatSlot)i);
                        return;
                    }
            }
            if (mouse == null || IsZoomModifierPressed(keyboard)) return;
            float scroll = mouse.scroll.ReadValue().y;
            if (scroll < -.01f) CycleSlot(1);
            else if (scroll > .01f) CycleSlot(-1);
        }

        private static bool IsDebugModifierPressed(Keyboard keyboard) => CombatDiagnosticInput.IsReservedControlChord(
            keyboard != null && (keyboard[Key.LeftCtrl].isPressed || keyboard[Key.RightCtrl].isPressed));

        private static bool IsZoomModifierPressed(Keyboard keyboard) => keyboard != null &&
            (keyboard[Key.LeftAlt].isPressed || keyboard[Key.RightAlt].isPressed);

        private void HandleMeleeInput(bool pressed)
        {
            if (!pressed) return;
            var definition = ActiveSlot == ActiveCombatSlot.None ? _fistAttack : ActiveCombatItem?.Data?.Melee;
            if (definition == null) return;
            var ray = new ShotRay(UnityShotWorld.FromUnity(transform.TransformPoint(_meleeOriginOffset)),
                UnityShotWorld.FromUnity(transform.forward));
            _melee.TryAttack(definition, ray);
        }

        private static bool IsFirearm(InventoryItem item) =>
            item?.Data?.Type == ItemType.Weapon && !item.Data.IsMelee;

        private void AdvanceInactiveFirearms(float deltaTime)
        {
            foreach (var entry in _firingByWeapon)
                if (!ReferenceEquals(entry.Value, _firing)) entry.Value.AdvanceCooldown(deltaTime);
        }

        private void SynchronizeWeapon()
        {
            PruneFiringCache();
            var item = ActiveCombatItem;
            WeaponState state = ActiveSlot != ActiveCombatSlot.Melee && IsFirearm(item)
                ? _context.Items.GetOrCreateWeapon(item) : null;
            if (ReferenceEquals(state, _weapon)) return;
            _reloadGesture.Cancel();
            _reload.Cancel(); _firing?.CancelBurst();
            _weapon = state;
            _firing = null;
            if (state != null && !_firingByWeapon.TryGetValue(state, out _firing))
            {
                _firing = new WeaponFiringController(state, _world,
                    new FirearmDamageResolver(_context.Balance, K_HealthConfig.Instance));
                _firing.ShotResolved += OnShot;
                _firingByWeapon.Add(state, _firing);
            }
        }

        private void PruneFiringCache()
        {
            _obsoleteFiring.Clear();
            foreach (var entry in _firingByWeapon)
                if (!_context.Items.TryGetWeapon(entry.Key.InstanceID, out var current) ||
                    !ReferenceEquals(current, entry.Key))
                    _obsoleteFiring.Add(entry.Key);
            foreach (var state in _obsoleteFiring)
            {
                var firing = _firingByWeapon[state];
                firing.CancelBurst();
                firing.ShotResolved -= OnShot;
                _firingByWeapon.Remove(state);
                if (ReferenceEquals(state, _weapon)) { _weapon = null; _firing = null; }
            }
            _obsoleteFiring.Clear();
        }

        private float GetReloadSpeed()
        {
            float armMultiplier = _health == null ? 1f
                : _reloadSettings.ArmPenalty == ReloadArmPenaltyMode.Speed
                    ? _health.GetArmSpeedMultiplier() : _health.GetArmAimMultiplier();
            return _context.Balance.ReloadSpeed * armMultiplier *
                (_vitality != null ? _vitality.ActionSpeedMult : 1f);
        }

        public bool TryBeginWeaponReload(InventoryItem item)
        {
            if (!CanUse(item, ItemType.Weapon)) return false;
            return _reload.BeginGameplayWeaponReload(_context.Items.GetOrCreateWeapon(item), _inventory.GetCombatReloadSources(),
                _health != null ? _health.GetArmZoneLevel() : 0, out _, ReloadTargetValidator(item, ItemType.Weapon));
        }

        private void HandleReloadGesture(bool gameplayInput, bool pressed, float deltaTime)
        {
            var action = _reloadGesture.Tick(deltaTime, gameplayInput && !IsReloading, pressed);
            if (action == ReloadKeyAction.Reload) TryBeginWeaponReload(ActiveCombatItem);
            else if (action == ReloadKeyAction.Check)
            {
                if (TryCheckWeaponMagazine(ActiveCombatItem, out var text, out var reason)) ShowCombatHint(text);
                else ShowCombatHint(reason);
            }
        }

        public bool TryCycleWeaponChamber(InventoryItem item, out string reason)
        {
            if (!CanUse(item, ItemType.Weapon)) { reason = "Weapon is not owned or available."; return false; }
            bool result = _reload.TryCycleWeaponChamber(_context.Items.GetOrCreateWeapon(item), out reason);
            if (result) _inventory.ForceRefresh();
            return result;
        }

        public bool TryDetachWeaponMagazine(InventoryItem item, out string reason)
        {
            if (!CanUse(item, ItemType.Weapon)) { reason = "Weapon is not owned or available."; return false; }
            bool result = _reload.TryDetachWeaponMagazine(_context.Items.GetOrCreateWeapon(item),
                _inventory.GetCombatReloadSources(), out reason);
            if (result) _inventory.ForceRefresh();
            return result;
        }

        public bool TryClearWeaponChamber(InventoryItem item, out string reason)
        {
            if (!CanUse(item, ItemType.Weapon)) { reason = "Weapon is not owned or available."; return false; }
            bool result = _reload.TryClearWeaponChamber(_context.Items.GetOrCreateWeapon(item),
                _inventory.GetCombatReloadSources(), out reason);
            if (result) _inventory.ForceRefresh();
            return result;
        }

        public bool TryCheckWeaponMagazine(InventoryItem item, out string text, out string reason)
        {
            text = null;
            if (!CanUse(item, ItemType.Weapon) || IsReloading)
            { reason = "Weapon is not owned, available, or is reloading."; return false; }
            text = CombatReloadService.CheckWeaponMagazine(_context.Items.GetOrCreateWeapon(item));
            reason = null;
            ShowCombatHint(text);
            return true;
        }

        private void ShowCombatHint(string text) { _combatHint = text; _combatHintRemaining = 2f; }

        private void OnGUI()
        {
            if (!string.IsNullOrEmpty(CombatHint))
                GUI.Box(new Rect((Screen.width - 520f) * .5f, Screen.height * .75f, 520f, 42f), CombatHint);
        }

        public bool TryBeginMagazineLoad(InventoryItem item)
        {
            if (!CanUse(item, ItemType.Magazine)) return false;
            return _reload.BeginMagazineLoad(_context.Items.GetOrCreateMagazine(item), _inventory.GetCombatReloadSources(),
                _health != null ? _health.GetArmZoneLevel() : 0, out _, ReloadTargetValidator(item, ItemType.Magazine));
        }

        public bool TryBeginChamberLoad(InventoryItem item)
        {
            if (!CanUse(item, ItemType.Weapon)) return false;
            SynchronizeWeapon();
            return _reload.BeginGameplayChamberLoad(_context.Items.GetOrCreateWeapon(item), _inventory.GetCombatReloadSources(),
                _health != null ? _health.GetArmZoneLevel() : 0, out _, ReloadTargetValidator(item, ItemType.Weapon));
        }

        public bool TryBeginAmmoDrop(InventoryItem ammo, InventoryItem target)
        {
            if (_inventory == null || !_inventory.OwnsCombatTarget(target)) return false;
            if (target?.Data?.IsMelee == true) return false;
            var origin = _inventory.FindControllerForItem(ammo);
            var sources = _inventory.GetCombatReloadSources();
            int level = _health != null ? _health.GetArmZoneLevel() : 0;
            if (target.Type == ItemType.Weapon)
                return _reload.BeginGameplayAmmoDrop(ammo, origin, _context.Items.GetOrCreateWeapon(target), sources,
                    level, out _, ReloadTargetValidator(target, ItemType.Weapon));
            if (target.Type == ItemType.Magazine)
                return _reload.BeginGameplayAmmoDrop(ammo, origin, _context.Items.GetOrCreateMagazine(target), sources,
                    level, out _, ReloadTargetValidator(target, ItemType.Magazine));
            return false;
        }

        private Func<bool> ReloadTargetValidator(InventoryItem item, ItemType type)
        {
            var backpack = _inventory.BackpackEquipmentSlot?.EquippedItem;
            return () => CanUse(item, type) && ReferenceEquals(backpack, _inventory.BackpackEquipmentSlot?.EquippedItem);
        }

        private bool CanUse(InventoryItem item, ItemType type) => _inventory != null && _context != null &&
            (_health == null || !_health.IsDead) && item?.Data?.Type == type && _inventory.OwnsCombatTarget(item) &&
            (type != ItemType.Weapon || !item.Data.IsMelee);

        public void CycleFireMode(InventoryItem item)
        {
            if (!CanUse(item, ItemType.Weapon)) return;
            var state = _context.Items.GetOrCreateWeapon(item);
            var modes = item.Data.Weapon.AllowedFireModes;
            if (modes == null || modes.Length == 0) return;
            for (int i = 0; i < modes.Length; i++)
                if (modes[i] == state.CurrentFireMode)
                {
                    state.TrySetFireMode(modes[(i + 1) % modes.Length]);
                    _firing?.CancelBurst(); _context.Items.MarkDirty(); return;
                }
        }

        public void ClearMisfire(InventoryItem item)
        {
            if (!CanUse(item, ItemType.Weapon)) return;
            _context.Items.GetOrCreateWeapon(item).ClearMisfire();
            _context.Items.MarkDirty();
        }

        public bool IsWeaponMisfired(InventoryItem item) => CanUse(item, ItemType.Weapon) &&
            _context.Items.GetOrCreateWeapon(item).IsMisfired;

        public ArmorState GetArmor(BodyPart part)
        {
            if (_inventory == null || _context == null) return null;
            var slot = _inventory.GetEquipmentSlotByType(part == BodyPart.Head ?
                EquipmentSlotType.HeadGear : EquipmentSlotType.BodyArmor);
            var item = slot?.EquippedItem;
            if (item?.Data?.Armor == null || item.Type != ItemType.Armor) return null;
            var state = _context.Items.GetOrCreateArmor(item, _context.Balance);
            return state.Covers(part) ? state : null;
        }

        private void OnShot(ShotResult result)
        {
            if (result.Fired)
            {
                _context.Items.MarkDirty();
                Vector3 position = _muzzle != null ? _muzzle.position : transform.position;
                K_AcousticSystem.Instance?.BroadcastGunshot(position, MapToAcousticType(_weapon.Data),
                    _weapon.Data.Weapon.Suppressed, _isIndoor, gameObject);
            }
            if (result.Outcome == ShotOutcome.DryClick)
            {
                K_AcousticSystem.Instance?.BroadcastMisfire(transform.position, _isIndoor, gameObject);
                if (_weapon != null && !_weapon.TryPeekShotRound(out _) &&
                    ((_weapon.Magazine != null && _weapon.Magazine.Count > 0) || _weapon.InternalRounds.Count > 0))
                {
                    string binding = _combatInput?.Player.CycleBolt.GetBindingDisplayString();
                    ShowCombatHint("Передёрните затвор [" + (string.IsNullOrEmpty(binding) ? "T" : binding) + "]");
                }
            }
            ShotResolved?.Invoke(result);
        }

        private static K_AcousticSystem.WeaponAcousticType MapToAcousticType(ItemStaticData data)
        {
            if (data.Weapon.Type == WeaponType.Shotgun) return K_AcousticSystem.WeaponAcousticType.Shotgun;
            if (data.Weapon.Type == WeaponType.Rifle) return K_AcousticSystem.WeaponAcousticType.Rifle;
            if (data.Weapon.Type == WeaponType.DoubleBarrel) return K_AcousticSystem.WeaponAcousticType.DoubleBarrel;
            if (data.Weapon.Type == WeaponType.BoltAction) return K_AcousticSystem.WeaponAcousticType.BoltAction;
            switch (data.Weapon.Type)
            {
                case WeaponType.AssaultRifle:
                case WeaponType.SubmachineGun:
                    return K_AcousticSystem.WeaponAcousticType.AssaultRifle;
                case WeaponType.Pistol:
                default:
                    return K_AcousticSystem.WeaponAcousticType.Handgun;
            }
        }

        private void OnReloadChanged()
        {
            EmitReloadStartNoise();
            if (_inventory == null || _changingInventory) return;
            _changingInventory = true;
            try { _inventory.ForceRefresh(); }
            finally { _changingInventory = false; }
        }

        private void EmitReloadStartNoise()
        {
            if (_reload == null || !_reload.IsReloading || _reload.OperationSerial == _lastReloadNoiseSerial) return;
            _lastReloadNoiseSerial = _reload.OperationSerial;
            if (float.IsNaN(_reloadNoiseRadius) || float.IsInfinity(_reloadNoiseRadius) || _reloadNoiseRadius < 0f)
                throw new InvalidOperationException("Reload noise radius must be finite and nonnegative.");
            K_AcousticSystem.RegisteredInstance?.BroadcastNoise(transform.position, _reloadNoiseRadius,
                NoiseSourceType.Reload, gameObject, _isIndoor);
        }

        private void OnCombatChanged() => _inventory?.RefreshCombatWeight();

        private void OnEnable() { _combatInput?.Player.CycleBolt.Enable(); }
        private void OnDisable()
        { _reload?.Cancel(); _firing?.CancelBurst(); _reloadGesture.Cancel(); _combatInput?.Player.CycleBolt.Disable(); }
        public void DetachInventory(K_InventoryUI owner)
        {
            if (!ReferenceEquals(_inventory, owner)) return;
            if (_context != null) _context.OnItemsChanged -= OnCombatChanged;
            _reload?.Dispose(); _world?.Dispose(); _firing?.CancelBurst();
            foreach (var firing in _firingByWeapon.Values) firing.ShotResolved -= OnShot;
            _firingByWeapon.Clear();
            _inventory = null; _context = null; _reload = null; _world = null; _firing = null; _weapon = null;
            _reloadGesture.Cancel();
            DisposeCombatInput();
        }
        private void OnDestroy()
        {
            if (_context != null) _context.OnItemsChanged -= OnCombatChanged;
            if (_reload != null) { _reload.StateChanged -= OnReloadChanged; _reload.Cancel(); }
            _reload?.Dispose();
            _world?.Dispose();
            DisposeCombatInput();
        }

        private void DisposeCombatInput()
        {
            if (_combatInput == null) return;
            _combatInput.Player.CycleBolt.Disable();
            _combatInput.Dispose();
            _combatInput = null;
        }
    }
}
