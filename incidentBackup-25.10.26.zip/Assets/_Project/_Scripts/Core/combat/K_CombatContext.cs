using System;
using System.Collections.Generic;
using System.IO;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core.Combat
{
    /// <summary>Unity lifetime and framed Save owner for the otherwise plain combat data layer.</summary>
    public sealed class K_CombatContext : MonoBehaviour, ISaveable, IPreLoad, IPostLoad
        , ISavePayloadValidator
    {
        [SerializeField] private WeaponBalanceConfig _balance;
        [SerializeField] private NpcLoadoutDefinition _npcLoadout = new NpcLoadoutDefinition();
        private readonly CombatItemStateRegistry _items = new CombatItemStateRegistry();
        [SerializeField] private ItemDatabase _database;
        private K_SaveManager _registeredSaveManager;
        private WeaponBalanceConfig _ownedRuntimeBalance;

        public string SaveID => "CombatItemState";
        public bool IsDirty { get; set; } = true;
        public event Action OnItemsChanged;

        public WeaponBalanceConfig Balance => _balance;
        public CombatItemStateRegistry Items => _items;
        public NpcLoadoutDefinition NpcLoadout => _npcLoadout;

        /// <summary>Explicit bridge for a complete set of player-owned roots; kilograms at the existing boundary.</summary>
        public long UpdateCarriedWeight(IEnumerable<InventoryItem> playerRoots, ItemDatabase database,
            K_WeightManager weightManager)
            => UpdateCarriedWeight(playerRoots, database, weightManager, null);

        public long UpdateCarriedWeight(IEnumerable<InventoryItem> playerRoots, ItemDatabase database,
            K_WeightManager weightManager, IEnumerable<AppliedMedicalRecord> appliedMedical)
        {
            if (database == null) throw new ArgumentNullException(nameof(database));
            if (weightManager == null) throw new ArgumentNullException(nameof(weightManager));
            var calculator = new CombatWeightCalculator(_items, database.GetItemData);
            long grams = calculator.GetTotalWeightGrams(playerRoots, appliedMedical);
            weightManager.SetWeight(grams / 1000f);
            return grams;
        }

        public void ConfigureBalance(WeaponBalanceConfig balance)
            => _balance = balance ?? throw new ArgumentNullException(nameof(balance));

        public void ConfigureDatabase(ItemDatabase database)
            => _database = database ?? throw new ArgumentNullException(nameof(database));

        /// <summary>The context, rather than a replaceable UI, owns a runtime-created fallback until its destruction.</summary>
        public void AdoptRuntimeBalance(WeaponBalanceConfig balance)
        {
            if (balance == null || !ReferenceEquals(balance, _balance))
                throw new ArgumentException("Only this context's configured runtime balance can be adopted.", nameof(balance));
            if (_ownedRuntimeBalance != null && !ReferenceEquals(_ownedRuntimeBalance, balance))
                Destroy(_ownedRuntimeBalance);
            _ownedRuntimeBalance = balance;
        }

        public bool PermanentlyDeleteItem(uint instanceID) => _items.RemovePermanently(instanceID);

        private void DisposeRuntimeBalance()
        {
            var owned = _ownedRuntimeBalance;
            _ownedRuntimeBalance = null;
            if (ReferenceEquals(_balance, owned)) _balance = null;
            if (owned != null) Destroy(owned);
        }

        /// <summary>Safe for dynamically added contexts and either Start ordering.</summary>
        public void EnsureSaveRegistration()
        {
            var manager = K_SaveManager.Instance;
            if (ReferenceEquals(_registeredSaveManager, manager)) return;
            _registeredSaveManager?.Unregister(this);
            _registeredSaveManager = manager;
            _registeredSaveManager?.Register(this);
        }

        private void OnEnable()
        {
            _items.Changed -= HandleItemsChanged;
            _items.Changed += HandleItemsChanged;
            EnsureSaveRegistration();
        }

        private void Start() => EnsureSaveRegistration();

        public void MarkDirty()
        {
            IsDirty = true;
            OnItemsChanged?.Invoke();
        }

        private void HandleItemsChanged() => MarkDirty();

        public void Save(BinaryWriter writer) => CombatItemStateSerializer.Save(writer, _items);

        public void Load(BinaryReader reader)
        {
            var database = _database != null ? _database : K_InventorySetup.DatabaseInstance;
            if (database == null) throw new InvalidDataException("Combat state load requires the item database.");
            if (_balance == null) throw new InvalidDataException("Combat state load requires weapon balance configuration.");
            CombatItemStateSerializer.Load(reader, _items, database.GetItemData, _balance);
            IsDirty = false;
        }

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            var database = _database != null ? _database : K_InventorySetup.DatabaseInstance;
            if (database == null || _balance == null)
                throw new InvalidDataException("Combat validation requires item database and balance.");
            var pending = new CombatItemStateRegistry();
            using (GlobalIDManager.PreserveAllocationForValidation())
                CombatItemStateSerializer.Load(reader, pending, database.GetItemData, _balance);
            foreach (var entry in pending.Magazines)
                if (entry.Value.OwnerWeaponID != 0)
                    context.Own(entry.Key, "CombatItemState attached magazine");
        }

        // V9 has no combat section. Clearing in the common preload phase gives it empty defaults.
        public void OnBeforeLoad() => ResetSession();

        public void OnAfterLoad() => OnItemsChanged?.Invoke();

        // Explicitly called for a new world; an ordinary item drop must retain the graph.
        public void ResetSession() => _items.Clear();

        private void OnDestroy()
        {
            DisposeRuntimeBalance();
            _registeredSaveManager?.Unregister(this);
            _items.Changed -= HandleItemsChanged;
            ResetSession();
        }
    }
}
