using System;

namespace K_Incident.Core.Combat
{
    /// <summary>Explicit Tick state machine. The owner supplies input, aim, physics and UI callbacks.</summary>
    public sealed class WeaponFiringController
    {
        private readonly WeaponState _weapon;
        private readonly IShotWorld _world;
        private readonly FirearmDamageResolver _damage;
        private readonly Func<float> _random01;
        private float _cooldown;
        private bool _publishingShotResolved;
        private int _burstRemaining;
        private bool _wasTriggerHeld;
        private FireMode _previousMode;
        private float _armAimMultiplier = 1f;
        public event Action<ShotResult> ShotResolved;
        public event Action<ShotHit> Impact;
        public ShotResult LastResult { get; private set; }
        public ShotAimResult AimStatus { get; private set; }
        public bool IsAimBlocked => AimStatus.IsBlocked;
        public int BurstRemaining => _burstRemaining;
        public float CooldownRemaining => Math.Max(0f, _cooldown);

        public WeaponFiringController(WeaponState weapon, IShotWorld world, FirearmDamageResolver damage,
            Func<float> random01 = null)
        {
            _weapon = weapon ?? throw new ArgumentNullException(nameof(weapon));
            _world = world ?? throw new ArgumentNullException(nameof(world));
            _damage = damage ?? throw new ArgumentNullException(nameof(damage));
            _random01 = random01 ?? (() => UnityEngine.Random.value);
            _previousMode = weapon.CurrentFireMode;
            weapon.Data.Weapon.ValidateFiring();
        }

        public ShotAimResult EvaluateAim(ShotAim aim)
        {
            WeaponItemDefinition definition = _weapon.Data.Weapon;
            definition.ValidateFiring();
            bool hasCameraHit = _world.Raycast(aim.CameraRay, definition.Range, out ShotHit cameraHit);
            ShotVector target = hasCameraHit ? cameraHit.Point : aim.CameraRay.PointAt(definition.Range);
            ShotVector offset = target - aim.MuzzlePosition;
            if (offset.Length < .0001f)
                return AimStatus = new ShotAimResult(ShotBlockReason.MuzzleObstructed,
                    new ShotRay(aim.MuzzlePosition, aim.MuzzleForward), target);
            var muzzleRay = new ShotRay(aim.MuzzlePosition, offset);
            if (definition.WeaponLength > 0f &&
                _world.Raycast(new ShotRay(aim.MuzzlePosition, aim.MuzzleForward), definition.WeaponLength, out ShotHit wall) &&
                wall.BlocksBarrel && wall.Receiver == null && wall.Distance < definition.WeaponLength)
                return AimStatus = new ShotAimResult(ShotBlockReason.WallAvoidance, muzzleRay, target);

            if (_world.Raycast(muzzleRay, Math.Min(definition.Range, offset.Length), out ShotHit obstruction) &&
                obstruction.Distance + .01f < offset.Length && !SameContact(hasCameraHit, cameraHit, obstruction))
                return AimStatus = new ShotAimResult(ShotBlockReason.MuzzleObstructed, muzzleRay, target);
            return AimStatus = new ShotAimResult(ShotBlockReason.None, muzzleRay, target);
        }

        public ShotResult TryFire(ShotAim aim)
        {
            if (_publishingShotResolved) return new ShotResult(ShotOutcome.Cooldown);
            if (_cooldown > 0f) return Publish(new ShotResult(ShotOutcome.Cooldown));
            ShotResult result = ExecuteShot(aim);
            if (result.Fired || result.Outcome == ShotOutcome.DryClick) _cooldown = _weapon.Data.Weapon.ShotInterval;
            return result;
        }

        /// <summary>Sets the live arm input without changing weapon data or legacy firing signatures.</summary>
        public void SetArmAimMultiplier(float armAimMultiplier)
        {
            DamageValidation.NonNegative(armAimMultiplier, nameof(armAimMultiplier));
            if (armAimMultiplier == 0f) throw new ArgumentOutOfRangeException(nameof(armAimMultiplier));
            _armAimMultiplier = armAimMultiplier;
        }

        public ShotResult TryFire(ShotAim aim, float armAimMultiplier)
        {
            if (_publishingShotResolved) return new ShotResult(ShotOutcome.Cooldown);
            SetArmAimMultiplier(armAimMultiplier);
            return TryFire(aim);
        }

        public int Tick(float deltaTime, bool triggerPressed, bool triggerHeld, ShotAim aim, float armAimMultiplier)
        {
            if (_publishingShotResolved) return 0;
            SetArmAimMultiplier(armAimMultiplier);
            return Tick(deltaTime, triggerPressed, triggerHeld, aim);
        }

        public int Tick(float deltaTime, bool triggerPressed, bool triggerHeld, ShotAim aim)
        {
            if (_publishingShotResolved) return 0;
            DamageValidation.NonNegative(deltaTime, nameof(deltaTime));
            WeaponItemDefinition definition = _weapon.Data.Weapon;
            definition.ValidateFiring();
            FireMode mode = _weapon.CurrentFireMode;
            if (mode != _previousMode)
            {
                _burstRemaining = 0;
                _wasTriggerHeld = false;
                _previousMode = mode;
            }
            bool continuing = (mode == FireMode.Auto && _wasTriggerHeld) || _burstRemaining > 0;
            _cooldown = continuing ? _cooldown - deltaTime : Math.Max(0f, _cooldown - deltaTime);
            _wasTriggerHeld = triggerHeld;
            EvaluateAim(aim);
            if (mode == FireMode.Safe)
            {
                if (triggerPressed) Publish(new ShotResult(ShotOutcome.Safe));
                return 0;
            }
            if (mode == FireMode.Single)
                return triggerPressed && _cooldown <= 0f && TryFire(aim).Fired ? 1 : 0;
            if (mode == FireMode.Burst && triggerPressed && _burstRemaining == 0 && _cooldown <= 0f)
                _burstRemaining = definition.BurstCount;
            if (mode == FireMode.Auto && !triggerHeld) { _cooldown = Math.Max(0f, _cooldown); return 0; }
            int fired = 0;
            while (_cooldown <= 0f && (mode == FireMode.Auto || _burstRemaining > 0))
            {
                int burstBeforeShot = _burstRemaining;
                bool triggerBeforeShot = _wasTriggerHeld;
                ShotResult result = ExecuteShot(aim);
                if (!result.Fired)
                {
                    _burstRemaining = 0;
                    _cooldown = definition.ShotInterval;
                    break;
                }
                fired++;
                // A published shot may cancel the queue or change the active fire mode.
                // That completed shot still counts, but its old operation must stop here.
                if (_burstRemaining != burstBeforeShot || _wasTriggerHeld != triggerBeforeShot ||
                    _weapon.CurrentFireMode != mode)
                {
                    _cooldown = Math.Max(0f, _cooldown) + definition.ShotInterval;
                    break;
                }
                if (mode == FireMode.Burst) _burstRemaining--;
                _cooldown += mode == FireMode.Burst && _burstRemaining == 0
                    ? Math.Max(definition.ShotInterval, definition.BurstPause) : definition.ShotInterval;
            }
            return fired;
        }

        public void CancelBurst() { _burstRemaining = 0; _wasTriggerHeld = false; }

        /// <summary>Advances a holstered weapon without aim queries or firing input.</summary>
        public void AdvanceCooldown(float deltaTime)
        {
            DamageValidation.NonNegative(deltaTime, nameof(deltaTime));
            _cooldown = Math.Max(0f, _cooldown - deltaTime);
        }

        private ShotResult ExecuteShot(ShotAim aim)
        {
            if (_weapon.CurrentFireMode == FireMode.Safe) return Publish(new ShotResult(ShotOutcome.Safe));
            ShotAimResult check = EvaluateAim(aim);
            if (check.IsBlocked) return Publish(new ShotResult(ShotOutcome.AimBlocked, blockReason: check.BlockReason));
            if (_weapon.IsMisfired || _weapon.IsBroken) return Publish(new ShotResult(ShotOutcome.DryClick));
            if (!_weapon.TryPeekShotRound(out AmmoRound round)) return Publish(new ShotResult(ShotOutcome.DryClick));
            var definition = _weapon.Data.Weapon;
            _damage.ValidateRound(definition, round);
            AmmoTypeBalance ammunition = _damage.GetAmmoTypeBalance(round);
            float wear = definition.BaseWearPerShot * ammunition.WearMultiplier;
            if (float.IsNaN(wear) || float.IsInfinity(wear))
                throw new InvalidOperationException("Configured per-shot weapon wear must be finite.");
            // The 80% gate takes precedence over every ammo misfire modifier.
            if (_weapon.Durability < .8f * _weapon.MaximumDurability)
            {
                float chance = Math.Min(1f, definition.MisfireChance + ammunition.AdditionalMisfireChance);
                if (chance > 0f && Math.Min(Sample(), .99999994f) < chance)
                {
                    _weapon.SetMisfire();
                    return Publish(new ShotResult(ShotOutcome.DryClick));
                }
            }
            if (!_weapon.TryConsumeShotRound(out AmmoRound consumed) || !ReferenceEquals(round, consumed))
                throw new InvalidOperationException("Shot ammunition changed between peek and consumption.");
            int hits = 0;
            for (int i = 0; i < definition.PelletCount; i++)
            {
                var ray = new ShotRay(check.MuzzleRay.Origin, Spread(check.MuzzleRay.Direction, definition.SpreadAngleDegrees));
                if (!_world.Raycast(ray, definition.Range, out ShotHit hit)) continue;
                hits++;
                if (hit.Receiver != null) _damage.Apply(definition, round, hit);
                Impact?.Invoke(hit);
            }
            _weapon.ApplyDurabilityDamage(wear);
            return Publish(new ShotResult(ShotOutcome.Fired, round, definition.PelletCount, hits));
        }

        private ShotVector Spread(ShotVector forward, float degrees)
        {
            degrees /= _armAimMultiplier;
            if (degrees == 0f) return forward;
            double cosine = 1.0 - Sample() * (1.0 - Math.Cos(degrees * Math.PI / 180.0));
            double sine = Math.Sqrt(Math.Max(0.0, 1.0 - cosine * cosine));
            double angle = Sample() * Math.PI * 2.0;
            var reference = Math.Abs(forward.Y) < .99f ? new ShotVector(0f, 1f, 0f) : new ShotVector(1f, 0f, 0f);
            ShotVector right = ShotVector.Cross(reference, forward).Normalized;
            ShotVector up = ShotVector.Cross(forward, right).Normalized;
            return forward * (float)cosine + right * (float)(Math.Cos(angle) * sine) + up * (float)(Math.Sin(angle) * sine);
        }

        private float Sample()
        {
            float sample = _random01();
            DamageValidation.Probability(sample, "random01");
            return sample;
        }

        private ShotResult Publish(ShotResult result)
        {
            LastResult = result;
            _publishingShotResolved = true;
            try { ShotResolved?.Invoke(result); }
            finally { _publishingShotResolved = false; }
            return result;
        }

        private static bool SameContact(bool hasCameraHit, ShotHit camera, ShotHit muzzle)
            => hasCameraHit && ((camera.CollisionIdentity != null && Equals(camera.CollisionIdentity, muzzle.CollisionIdentity) &&
                    (camera.Point - muzzle.Point).Length <= .05f) ||
                (camera.Receiver != null && ReferenceEquals(camera.Receiver, muzzle.Receiver)));
    }
}
