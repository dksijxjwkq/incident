namespace K_Incident.Core.Combat
{
    public interface IShotWorld
    {
        /// <summary>Returns the first non-shooter collider along the normalized ray.</summary>
        bool Raycast(ShotRay ray, float maxDistance, out ShotHit hit);
    }

    public readonly struct ShotHit
    {
        public readonly ShotVector Point;
        public readonly float Distance;
        public readonly object CollisionIdentity;
        public readonly IDamageReceiver Receiver;
        public readonly BodyPart Part;
        public readonly ArmorState Armor;
        public readonly bool BlocksBarrel;

        public ShotHit(ShotVector point, float distance, object collisionIdentity,
            IDamageReceiver receiver = null, BodyPart part = BodyPart.Chest, ArmorState armor = null,
            bool blocksBarrel = true)
        {
            DamageValidation.NonNegative(distance, nameof(distance));
            DamageValidation.PartIndex(part);
            Point = point; Distance = distance; CollisionIdentity = collisionIdentity;
            Receiver = receiver; Part = part; Armor = armor; BlocksBarrel = blocksBarrel;
        }
    }

    public enum ShotBlockReason { None = 0, WallAvoidance = 1, MuzzleObstructed = 2 }

    public readonly struct ShotAimResult
    {
        public readonly ShotBlockReason BlockReason;
        public readonly ShotRay MuzzleRay;
        public readonly ShotVector TargetPoint;
        public bool IsBlocked => BlockReason != ShotBlockReason.None;
        public ShotAimResult(ShotBlockReason reason, ShotRay muzzleRay, ShotVector targetPoint)
        { BlockReason = reason; MuzzleRay = muzzleRay; TargetPoint = targetPoint; }
    }

    public enum ShotOutcome { None = 0, Fired = 1, DryClick = 2, Safe = 3, AimBlocked = 4, Cooldown = 5 }

    public readonly struct ShotResult
    {
        public readonly ShotOutcome Outcome;
        public readonly AmmoRound Round;
        public readonly int PelletCount;
        public readonly int HitCount;
        public readonly ShotBlockReason BlockReason;
        public bool Fired => Outcome == ShotOutcome.Fired;
        public float NoiseRadius => Outcome == ShotOutcome.DryClick ? 3f : 0f;
        public ShotResult(ShotOutcome outcome, AmmoRound round = null, int pelletCount = 0,
            int hitCount = 0, ShotBlockReason blockReason = ShotBlockReason.None)
        { Outcome = outcome; Round = round; PelletCount = pelletCount; HitCount = hitCount; BlockReason = blockReason; }
    }
}
