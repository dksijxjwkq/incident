using System;

namespace K_Incident.Core.Combat
{
    /// <summary>One firearm impact: armor, HP, wound statuses, shock, then independent trauma rolls.</summary>
    public sealed class FirearmDamageResolver
    {
        private readonly WeaponBalanceConfig _balance;
        private readonly ArmorDamageResolver _armor;
        private readonly K_HealthConfig _healthConfig;
        private readonly Func<float> _random01;

        public FirearmDamageResolver(WeaponBalanceConfig balance, K_HealthConfig healthConfig = null,
            Func<float> random01 = null)
        {
            _balance = balance ?? throw new ArgumentNullException(nameof(balance));
            _armor = new ArmorDamageResolver(balance);
            _healthConfig = healthConfig;
            _random01 = random01 ?? (() => UnityEngine.Random.value);
        }

        public void ValidateRound(WeaponItemDefinition weapon, AmmoRound round)
        {
            if (weapon == null) throw new ArgumentNullException(nameof(weapon));
            if (round == null) throw new ArgumentNullException(nameof(round));
            weapon.ValidateFiring();
            _balance.GetCaliber(round.Caliber);
            _balance.GetAmmoType(round.Type);
        }

        // Firing condition uses the same authoritative ammo balance as impact damage.
        internal AmmoTypeBalance GetAmmoTypeBalance(AmmoRound round) => _balance.GetAmmoType(round.Type);

        public ArmorDamageResult Apply(WeaponItemDefinition weapon, AmmoRound round, ShotHit hit)
        {
            ValidateRound(weapon, round);
            if (hit.Receiver == null) return default;
            ArmorDamageResult impact = _armor.Resolve(weapon.BaseDamage, round.Caliber, round.Type, hit.Part, hit.Armor);
            IDamageReceiver receiver = hit.Receiver;
            receiver.ApplyDamage(hit.Part, impact.HealthDamage, DamageType.Firearm);
            receiver.ApplyStatus(hit.Part, new DamageStatus(DamageType.Gunshot));
            receiver.ApplyStatus(hit.Part, new DamageStatus(DamageType.Laceration, LacerationType.Open));
            int bleeding = Math.Max(receiver.GetStatus(hit.Part).BleedingLevel, weapon.ExternalBleedingLevel);
            receiver.ApplyStatus(hit.Part, new DamageStatus(DamageType.ExternalBleeding, bleedingLevel: bleeding));
            if (receiver is IShockReceiver shock) shock.ApplyShock(weapon.ShockDuration);
            impact.TryApplyFracture(receiver, hit.Part, weapon.GetFractureChance(hit.Part), NextSample());
            var trauma = new ArmorDamageResult(impact.HealthDamage, impact.ArmorDamage,
                impact.FractureMultiplier, impact.ConcussionMultiplier * weapon.HeadTraumaChanceMultiplier, impact.WasProtected);
            trauma.ApplyHeadTrauma(receiver, hit.Part, NextSample(), _healthConfig);
            return impact;
        }

        private float NextSample()
        {
            float sample = _random01();
            DamageValidation.Probability(sample, "random01");
            // Unity's inclusive Random.value endpoint represents the final bin, not a guaranteed success.
            return sample >= 1f ? .99999994f : sample;
        }
    }
}
