using System;

namespace K_Incident.Core.Combat
{
    /// <summary>Engine-independent world coordinates for raycast adapters and deterministic regressions.</summary>
    public readonly struct ShotVector
    {
        public readonly float X;
        public readonly float Y;
        public readonly float Z;

        public ShotVector(float x, float y, float z)
        {
            if (!Finite(x) || !Finite(y) || !Finite(z)) throw new ArgumentOutOfRangeException(nameof(x));
            X = x; Y = y; Z = z;
        }

        public float Length => (float)Math.Sqrt((double)X * X + (double)Y * Y + (double)Z * Z);
        public ShotVector Normalized
        {
            get
            {
                double length = Math.Sqrt((double)X * X + (double)Y * Y + (double)Z * Z);
                if (length < .000001) throw new ArgumentException("Shot direction must be nonzero.");
                return new ShotVector((float)(X / length), (float)(Y / length), (float)(Z / length));
            }
        }

        public static ShotVector operator +(ShotVector a, ShotVector b) => new ShotVector(a.X + b.X, a.Y + b.Y, a.Z + b.Z);
        public static ShotVector operator -(ShotVector a, ShotVector b) => new ShotVector(a.X - b.X, a.Y - b.Y, a.Z - b.Z);
        public static ShotVector operator *(ShotVector a, float scale) => new ShotVector(a.X * scale, a.Y * scale, a.Z * scale);
        public static float Dot(ShotVector a, ShotVector b) => a.X * b.X + a.Y * b.Y + a.Z * b.Z;
        public static ShotVector Cross(ShotVector a, ShotVector b) => new ShotVector(
            a.Y * b.Z - a.Z * b.Y, a.Z * b.X - a.X * b.Z, a.X * b.Y - a.Y * b.X);
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }

    public readonly struct ShotRay
    {
        public readonly ShotVector Origin;
        public readonly ShotVector Direction;
        public ShotRay(ShotVector origin, ShotVector direction) { Origin = origin; Direction = direction.Normalized; }
        public ShotVector PointAt(float distance) => Origin + Direction * distance;
    }

    public readonly struct ShotAim
    {
        public readonly ShotRay CameraRay;
        public readonly ShotVector MuzzlePosition;
        public readonly ShotVector MuzzleForward;
        public ShotAim(ShotRay cameraRay, ShotVector muzzlePosition, ShotVector muzzleForward)
        {
            CameraRay = cameraRay;
            MuzzlePosition = muzzlePosition;
            MuzzleForward = muzzleForward.Normalized;
        }
    }
}
