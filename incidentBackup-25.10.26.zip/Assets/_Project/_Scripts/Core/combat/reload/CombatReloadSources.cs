using System;
using System.Collections.Generic;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>Only direct player roots. Callers pass the worn backpack, never an open container.</summary>
    public sealed class CombatReloadSources
    {
        private readonly List<InventoryController> _controllers = new List<InventoryController>();
        public IReadOnlyList<InventoryController> Controllers { get; }

        public CombatReloadSources(InventoryController pockets, InventoryController pocket2,
            InventoryController wornBackpack)
        {
            Add(pockets); Add(pocket2); Add(wornBackpack);
            Controllers = _controllers.AsReadOnly();
        }

        private void Add(InventoryController controller)
        {
            if (controller != null && !_controllers.Contains(controller)) _controllers.Add(controller);
        }

        public bool Contains(InventoryController controller) => controller != null &&
            !controller.IsDisposed && _controllers.Contains(controller);

        public bool Contains(InventoryItem item)
        {
            if (item == null) return false;
            for (int i = 0; i < _controllers.Count; i++)
                if (ReferenceEquals(_controllers[i].GetItemByInstanceID(item.InstanceID), item)) return true;
            return false;
        }

        internal void Visit(Action<InventoryItem, InventoryController> visit)
        {
            for (int i = 0; i < _controllers.Count; i++)
            {
                var controller = _controllers[i];
                if (controller.IsDisposed) continue;
                for (int y = 0; y < controller.Height; y++)
                    for (int x = 0; x < controller.Width; x++)
                    {
                        var item = controller.GetItemAt(x, y);
                        if (item != null && controller.IsRootCell(item.InstanceID, x, y)) visit(item, controller);
                    }
            }
        }

        internal bool TryFindAmmo(string caliber, out InventoryItem ammo, out InventoryController origin)
        {
            InventoryItem found = null;
            InventoryController source = null;
            Visit((item, controller) =>
            {
                if (found == null && item.Quantity > 0 && item.Type == ItemType.Ammo &&
                    item.Data.Ammunition != null && string.Equals(item.Data.Caliber, caliber, StringComparison.Ordinal))
                { found = item; source = controller; }
            });
            ammo = found; origin = source;
            return found != null;
        }
    }
}
