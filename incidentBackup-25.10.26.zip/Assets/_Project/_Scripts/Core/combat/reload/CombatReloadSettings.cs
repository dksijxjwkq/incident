using System;
using UnityEngine;

namespace K_Incident.Core.Combat
{
    public enum ReloadArmPenaltyMode { Aim, Speed }

    /// <summary>Durations are seconds at speed 1. Arm injury reduces speed, never capacity.</summary>
    [Serializable]
    public sealed class CombatReloadSettings
    {
        [Min(.01f)] public float MagazineSwapSeconds = 1.5f;
        [Min(.01f)] public float WeaponRoundSeconds = 1f;
        [Min(.01f)] public float MagazineRoundSeconds = .5f;
        [Min(.01f)] public float BoltCycleSeconds = .75f;
        public ReloadArmPenaltyMode ArmPenalty = ReloadArmPenaltyMode.Aim;

        public float GetSpeed(WeaponBalanceConfig balance, K_HealthConfig health, int armLevel)
        {
            if (balance == null) throw new ArgumentNullException(nameof(balance));
            float speed = health == null ? balance.ReloadSpeed :
                ArmPenalty == ReloadArmPenaltyMode.Speed
                    ? balance.ReloadSpeed * health.GetArmSpeedMultiplier(armLevel)
                    : balance.GetReloadSpeedMultiplier(armLevel, health);
            if (float.IsNaN(speed) || float.IsInfinity(speed) || speed <= 0f)
                throw new InvalidOperationException("Reload speed must be positive and finite.");
            return speed;
        }

        internal static float Duration(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds <= 0f)
                throw new InvalidOperationException("Reload duration must be positive and finite.");
            return seconds;
        }
    }
}
