using System;
using System.Collections.Generic;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>Manual, interruptible reload state machine. Call Tick from the existing player owner.</summary>
    public sealed class CombatReloadService
    {
        private enum Operation { None, MagazineSwap, WeaponRounds, MagazineRounds, BoltCycle, ChamberRound }
        private readonly CombatItemStateRegistry _items;
        private readonly WeaponBalanceConfig _balance;
        private readonly K_HealthConfig _health;
        private readonly Func<float> _random01;
        private readonly Func<float> _speedProvider;
        private readonly Dictionary<uint, InventoryItem> _detachedMagazines = new Dictionary<uint, InventoryItem>();
        private Operation _operation;
        private CombatReloadSources _sources;
        private WeaponState _weapon;
        private MagazineState _magazine;
        private InventoryItem _selectedMagazine;
        private InventoryController _selectedOrigin;
        private MagazineState _originalMagazine;
        private InventoryItem _returnMagazine;
        private InventoryItem _specificAmmo;
        private InventoryController _specificOrigin;
        private Func<bool> _validateTarget;
        private float _elapsed;
        private float _stepSeconds;
        private float _speed;
        public int OperationSerial { get; private set; }

        public CombatReloadSettings Settings { get; }
        public bool IsReloading => _operation != Operation.None;
        public float Progress => IsReloading ? Math.Min(1f, _elapsed / _stepSeconds) : 0f;
        public int TransferredRounds { get; private set; }
        public string LastError { get; private set; }
        public event Action StateChanged;

        public CombatReloadService(CombatItemStateRegistry items, WeaponBalanceConfig balance,
            K_HealthConfig health = null, Func<float> random01 = null, CombatReloadSettings settings = null,
            Func<float> speedProvider = null)
        {
            _items = items ?? throw new ArgumentNullException(nameof(items));
            _balance = balance ?? throw new ArgumentNullException(nameof(balance));
            _health = health;
            var random = new Random();
            _random01 = random01 ?? (() => (float)random.NextDouble());
            _speedProvider = speedProvider;
            Settings = settings ?? new CombatReloadSettings();
            _items.SessionReset += ResetSession;
        }

        /// <summary>Starts a gameplay reload only while the caller confirms ownership of the weapon.</summary>
        public bool BeginGameplayWeaponReload(WeaponState weapon, CombatReloadSources sources, int armLevel,
            out string error, Func<bool> validateTarget)
        {
            if (validateTarget == null)
                return Reject("Weapon ownership validator is required for gameplay reload.", out error);
            if (!validateTarget())
                return Reject("Weapon reload target is not owned or available.", out error);
#pragma warning disable CS0618 // Intentional delegation to the unchanged compatibility implementation.
            return BeginWeaponReload(weapon, sources, armLevel, out error, validateTarget);
#pragma warning restore CS0618
        }

        /// <summary>Trusted data/test path: explicitly starts a reload without checking weapon ownership.</summary>
        public bool BeginPrivilegedWeaponReload(WeaponState weapon, CombatReloadSources sources, int armLevel,
            out string error)
        {
#pragma warning disable CS0618 // Intentional delegation to the unchanged compatibility implementation.
            return BeginWeaponReload(weapon, sources, armLevel, out error);
#pragma warning restore CS0618
        }

        // Legacy, использовать BeginGameplayWeaponReload / BeginPrivilegedWeaponReload.
        // Kept because those live wrappers still delegate to this implementation.
        [Obsolete("Use BeginGameplayWeaponReload with an ownership validator for gameplay, or BeginPrivilegedWeaponReload for trusted data/test access.")]
        public bool BeginWeaponReload(WeaponState weapon, CombatReloadSources sources, int armLevel,
            out string error, Func<bool> validateTarget = null)
        {
            if (!CanBegin(sources, out error)) return false;
            if (weapon == null) return Reject("Weapon is missing.", out error);
            if (weapon.IsBroken) return Reject("Weapon is broken and requires repair.", out error);
            if (weapon.IsMisfired)
            {
                weapon.ClearMisfire(); _items.MarkDirty(); LastError = null;
                StateChanged?.Invoke(); error = null; return true;
            }
            if (weapon.RequiresBoltCycle && weapon.Chambers[0] == null && weapon.InternalRounds.Count > 0)
            {
                Start(Operation.BoltCycle, weapon, null, sources, armLevel,
                    Settings.BoltCycleSeconds, validateTarget);
            }
            else if (weapon.Data.Weapon.MagazineCapacity > 0)
            {
                if (!TrySelectMagazine(weapon, sources, out var candidate, out var origin))
                    return Reject("No compatible magazine in player inventory.", out error);
                var previous = weapon.Magazine;
                var returned = previous == null ? null : GetMagazineItem(previous);
                if (!InventoryController.CanExchangeDetachedItem(origin, candidate, returned, sources.Controllers))
                    return Reject("No space for the current magazine.", out error);
                Start(Operation.MagazineSwap, weapon, null, sources, armLevel,
                    Settings.MagazineSwapSeconds, validateTarget);
                _selectedMagazine = candidate; _selectedOrigin = origin;
                _originalMagazine = previous; _returnMagazine = returned;
            }
            else
            {
                if (!HasWeaponSpace(weapon) || !sources.TryFindAmmo(weapon.Data.Caliber, out _, out _))
                    return Reject("Weapon is full or compatible ammunition is missing.", out error);
                Start(Operation.WeaponRounds, weapon, null, sources, armLevel,
                    Settings.WeaponRoundSeconds, validateTarget);
            }
            StateChanged?.Invoke(); error = null; return true;
        }

        public bool BeginMagazineLoad(MagazineState magazine, CombatReloadSources sources, int armLevel,
            out string error, Func<bool> validateTarget = null)
        {
            if (!CanBegin(sources, out error)) return false;
            if (!IsStandaloneMagazineOwned(magazine, sources) || magazine.Count >= magazine.Capacity ||
                !sources.TryFindAmmo(magazine.Data.Caliber, out _, out _))
                return Reject("Magazine is full, unavailable or compatible ammunition is missing.", out error);
            Start(Operation.MagazineRounds, null, magazine, sources, armLevel,
                Settings.MagazineRoundSeconds, validateTarget);
            StateChanged?.Invoke(); error = null; return true;
        }

        public bool BeginGameplayChamberLoad(WeaponState weapon, CombatReloadSources sources, int armLevel,
            out string error, Func<bool> validateTarget)
        {
            if (!CanBegin(sources, out error)) return false;
            if (validateTarget == null || !validateTarget())
                return Reject("Weapon ownership validator is required for chamber loading.", out error);
            if (weapon == null || weapon.IsBroken || weapon.IsMisfired || weapon.FirstEmptyChamber() < 0)
                return Reject("An available weapon with an empty chamber is required.", out error);
            if ((weapon.Magazine == null || weapon.Magazine.Count == 0) && weapon.InternalRounds.Count == 0 &&
                !sources.TryFindAmmo(weapon.Data.Caliber, out _, out _))
                return Reject("No ammunition is available for the chamber.", out error);
            Start(Operation.ChamberRound, weapon, null, sources, armLevel, Settings.BoltCycleSeconds, validateTarget);
            StateChanged?.Invoke(); error = null; return true;
        }

        [Obsolete("Use BeginGameplayAmmoDrop with a mandatory validator, or BeginPrivilegedAmmoDrop for trusted data access.")]
        public bool BeginAmmoDrop(InventoryItem ammo, InventoryController origin, WeaponState weapon,
            CombatReloadSources sources, int armLevel, out string error, Func<bool> validateTarget = null)
        {
            if (validateTarget == null || !validateTarget())
                return Reject("Ammo-drop target ownership validator is required and must accept the target.", out error);
            if (!CanBegin(sources, out error)) return false;
            if (!IsAmmoOwned(ammo, origin, sources) || !CanLoadAmmo(ammo, weapon))
                return Reject("Ammunition cannot be loaded into this weapon.", out error);
            Start(Operation.WeaponRounds, weapon, null, sources, armLevel,
                weapon.Magazine == null ? Settings.WeaponRoundSeconds : Settings.MagazineRoundSeconds,
                validateTarget);
            _specificAmmo = ammo; _specificOrigin = origin;
            StateChanged?.Invoke(); error = null; return true;
        }

        [Obsolete("Use BeginGameplayAmmoDrop with a mandatory validator, or BeginPrivilegedAmmoDrop for trusted data access.")]
        public bool BeginAmmoDrop(InventoryItem ammo, InventoryController origin, MagazineState magazine,
            CombatReloadSources sources, int armLevel, out string error, Func<bool> validateTarget = null)
        {
            if (validateTarget == null || !validateTarget())
                return Reject("Ammo-drop target ownership validator is required and must accept the target.", out error);
            if (!CanBegin(sources, out error)) return false;
            if (!IsAmmoOwned(ammo, origin, sources) || !IsStandaloneMagazineOwned(magazine, sources) ||
                !CanLoadAmmo(ammo, magazine))
                return Reject("Ammunition cannot be loaded into this magazine.", out error);
            Start(Operation.MagazineRounds, null, magazine, sources, armLevel,
                Settings.MagazineRoundSeconds, validateTarget);
            _specificAmmo = ammo; _specificOrigin = origin;
            StateChanged?.Invoke(); error = null; return true;
        }

        public static bool CanLoadAmmo(InventoryItem ammo, MagazineState magazine) =>
            IsAmmo(ammo) && magazine != null && magazine.Count < magazine.Capacity &&
            string.Equals(ammo.Data.Caliber, magazine.Data.Caliber, StringComparison.Ordinal);

        public static bool CanLoadAmmo(InventoryItem ammo, WeaponState weapon) =>
            IsAmmo(ammo) && weapon != null && string.Equals(ammo.Data.Caliber, weapon.Data.Caliber,
                StringComparison.Ordinal) && (weapon.Magazine != null
                    ? CanLoadAmmo(ammo, weapon.Magazine) : HasWeaponSpace(weapon));

        public void Tick(float deltaTime)
        {
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime < 0f)
                throw new ArgumentOutOfRangeException(nameof(deltaTime));
            if (!IsReloading) return;
            if (!TargetStillValid()) { Stop("Reload target is no longer available."); return; }
            float speed = _speedProvider != null ? GetProvidedSpeed() : _speed;
            float elapsed = _elapsed + deltaTime * speed;
            if (float.IsInfinity(elapsed)) throw new ArgumentOutOfRangeException(nameof(deltaTime));
            _elapsed = elapsed;
            while (IsReloading && _elapsed >= _stepSeconds)
            {
                _elapsed -= _stepSeconds;
                if (!TargetStillValid()) { Stop("Reload target is no longer available."); return; }
                if (_operation == Operation.ChamberRound)
                {
                    bool loaded;
                    using (_items.DeferChanges()) loaded = TransferChamberRound();
                    if (loaded) TransferredRounds++;
                    Stop(loaded ? null : "Chamber or ammunition is no longer available.");
                    return;
                }
                if (_operation == Operation.MagazineSwap)
                {
                    bool swapped = CompleteMagazineSwap();
                    Stop(swapped ? null : "Magazine or return space changed during reload.");
                    return;
                }
                if (_operation == Operation.BoltCycle)
                {
                    bool cycled = _weapon.TryCycleBolt();
                    if (cycled) TransferredRounds++;
                    Stop(cycled ? null : "Bolt-action chamber or weapon condition changed during cycling.");
                    return;
                }
                if (!TransferRound()) { Stop("Ammunition or free capacity is no longer available."); return; }
                TransferredRounds++;
                if (!IsReloading) return;
                if (!CanContinueRounds()) { Stop(null); return; }
                StateChanged?.Invoke();
            }
        }

        public void Cancel()
        {
            if (IsReloading) Stop(null);
        }

        public bool TryCycleWeaponChamber(WeaponState weapon, out string reason)
        {
            if (IsReloading) return Reject("A reload is already in progress.", out reason);
            using (_items.DeferChanges())
            {
                if (weapon == null || weapon.FirstEmptyChamber() < 0 || !weapon.TryChamberAttachedRound())
                    return Reject("The chamber is occupied, the weapon is unavailable, or its magazine has no ammunition.", out reason);
                _items.MarkDirty();
            }
            reason = null;
            return true;
        }

        public bool TryDetachWeaponMagazine(WeaponState weapon, CombatReloadSources sources, out string reason)
        {
            if (IsReloading || weapon == null || sources == null || weapon.Data.Weapon.MagazineCapacity <= 0 ||
                weapon.Magazine == null) return Reject("No detachable magazine is available.", out reason);
            var magazine = weapon.Magazine;
            var wrapper = GetMagazineItem(magazine);
            using (_items.DeferChanges())
            {
                if (!InventoryController.TryReturnDetachedCombatItem(wrapper, sources.Controllers,
                    () => ReferenceEquals(weapon.Magazine, magazine) && weapon.TryRemoveMagazine(out _),
                    () => { if (weapon.Magazine == null) weapon.TrySetMagazine(magazine); }))
                    return Reject("No space for the magazine in player inventory.", out reason);
                _detachedMagazines.Remove(magazine.InstanceID);
                _items.MarkDirty();
            }
            reason = null;
            return true;
        }

        public bool TryClearWeaponChamber(WeaponState weapon, CombatReloadSources sources, out string reason)
        {
            if (IsReloading || weapon == null || sources == null)
                return Reject("The weapon is unavailable or reloading.", out reason);
            int chamber = -1;
            for (int i = 0; i < weapon.Chambers.Count; i++)
                if (weapon.Chambers[i] != null) { chamber = i; break; }
            if (chamber < 0) return Reject("The chamber is empty.", out reason);
            var round = weapon.Chambers[chamber];
            var wrapper = new InventoryItem(round.Data, GlobalIDManager.GenerateID(), 1, round.Data.MaxDurability, false);
            using (_items.DeferChanges())
            {
                if (!InventoryController.TryReturnDetachedCombatItem(wrapper, sources.Controllers,
                    () => weapon.TryTakeChamberRound(chamber, round),
                    () => { if (weapon.Chambers[chamber] == null) weapon.TryLoadEmptyChamber(chamber, round); }))
                    return Reject("No space for the chamber round in player inventory.", out reason);
                _items.MarkDirty();
            }
            reason = null;
            return true;
        }

        public static string CheckWeaponMagazine(WeaponState weapon)
        {
            if (weapon == null) throw new ArgumentNullException(nameof(weapon));
            if (weapon.Data.Weapon.Type == WeaponType.DoubleBarrel)
            {
                int count = 0;
                for (int i = 0; i < weapon.Chambers.Count; i++) if (weapon.Chambers[i] != null) count++;
                return count == 0 ? "Пустой" : FormatRoundCount(count);
            }
            if (weapon.Data.Weapon.MagazineCapacity > 0)
                return weapon.Magazine == null ? "Магазин отсутствует" : weapon.Magazine.Data.Magazine.IsOpenType
                    ? FormatRoundCount(weapon.Magazine.Count) : FormatFullness(weapon.Magazine.Count, weapon.Magazine.Capacity);
            int rounds = weapon.InternalRounds.Count;
            for (int i = 0; i < weapon.Chambers.Count; i++) if (weapon.Chambers[i] != null) rounds++;
            return FormatFullness(rounds, weapon.InternalMagazineCapacity + weapon.Chambers.Count);
        }

        public static string FormatRoundCount(int count)
        {
            if (count < 0) throw new ArgumentOutOfRangeException(nameof(count));
            int lastTwo = count % 100, last = count % 10;
            string ending = lastTwo >= 11 && lastTwo <= 14 ? "патронов" :
                last == 1 ? "патрон" : last >= 2 && last <= 4 ? "патрона" : "патронов";
            return count + " " + ending;
        }

        public static string FormatFullness(int count, int capacity)
        {
            if (count < 0 || capacity < 0 || count > capacity) throw new ArgumentOutOfRangeException(nameof(count));
            if (count == 0) return "Пустой";
            if (count == capacity) return "Полный";
            // Compare the actual ratio: a fractional percent must not become falsely empty/full.
            float percent = count * 100f / capacity;
            if (percent > 75f) return "Почти полный";
            if (percent > 50f) return "Больше половины";
            if (percent > 25f) return "Меньше половины";
            return "Почти пустой";
        }

        private void Start(Operation operation, WeaponState weapon, MagazineState magazine,
            CombatReloadSources sources, int armLevel, float seconds, Func<bool> validateTarget)
        {
            OperationSerial = unchecked(OperationSerial + 1);
            _speed = _speedProvider != null ? GetProvidedSpeed() : Settings.GetSpeed(_balance, _health, armLevel);
            _stepSeconds = CombatReloadSettings.Duration(seconds);
            _operation = operation; _weapon = weapon; _magazine = magazine; _sources = sources;
            _specificAmmo = null; _specificOrigin = null; _validateTarget = validateTarget;
            _selectedMagazine = null; _selectedOrigin = null; _originalMagazine = null; _returnMagazine = null;
            _elapsed = 0f; TransferredRounds = 0; LastError = null;
        }

        private float GetProvidedSpeed()
        {
            float speed = _speedProvider();
            if (float.IsNaN(speed) || float.IsInfinity(speed) || speed <= 0f)
                throw new InvalidOperationException("Reload speed must be positive and finite.");
            return speed;
        }

        private bool CanBegin(CombatReloadSources sources, out string error)
        {
            PruneDetachedMagazineCache();
            if (IsReloading) return Reject("A reload is already in progress.", out error);
            if (sources == null) return Reject("Player inventory sources are missing.", out error);
            error = null; return true;
        }

        private bool Reject(string message, out string error)
        { LastError = error = message; return false; }

        private void Stop(string error)
        {
            _operation = Operation.None; _elapsed = 0f; LastError = error;
            ClearOperationReferences();
            StateChanged?.Invoke();
        }

        private void ClearOperationReferences()
        {
            _sources = null; _weapon = null; _magazine = null;
            _selectedMagazine = null; _selectedOrigin = null; _originalMagazine = null; _returnMagazine = null;
            _specificAmmo = null; _specificOrigin = null; _validateTarget = null;
        }

        /// <summary>New/load session boundary. Clears callbacks into the abandoned inventory graph without publishing it.</summary>
        public void ResetSession()
        {
            _operation = Operation.None; _elapsed = 0f; TransferredRounds = 0; LastError = null;
            ClearOperationReferences();
            _detachedMagazines.Clear();
        }

        public void Dispose()
        {
            _items.SessionReset -= ResetSession;
            ResetSession();
            StateChanged = null;
        }

        private void PruneDetachedMagazineCache()
        {
            var stale = new List<uint>();
            foreach (var entry in _detachedMagazines)
                if (!_items.TryGetMagazine(entry.Key, out var state) || entry.Value == null ||
                    entry.Value.InstanceID != state.InstanceID || !ReferenceEquals(entry.Value.Data, state.Data))
                    stale.Add(entry.Key);
            foreach (uint id in stale) _detachedMagazines.Remove(id);
        }

        public bool BeginGameplayAmmoDrop(InventoryItem ammo, InventoryController origin, WeaponState weapon,
            CombatReloadSources sources, int armLevel, out string error, Func<bool> validateTarget)
        {
#pragma warning disable CS0618
            return BeginAmmoDrop(ammo, origin, weapon, sources, armLevel, out error, validateTarget);
#pragma warning restore CS0618
        }

        public bool BeginGameplayAmmoDrop(InventoryItem ammo, InventoryController origin, MagazineState magazine,
            CombatReloadSources sources, int armLevel, out string error, Func<bool> validateTarget)
        {
#pragma warning disable CS0618
            return BeginAmmoDrop(ammo, origin, magazine, sources, armLevel, out error, validateTarget);
#pragma warning restore CS0618
        }

        public bool BeginPrivilegedAmmoDrop(InventoryItem ammo, InventoryController origin, WeaponState weapon,
            CombatReloadSources sources, int armLevel, out string error)
        {
            return BeginGameplayAmmoDrop(ammo, origin, weapon, sources, armLevel, out error, () => true);
        }

        public bool BeginPrivilegedAmmoDrop(InventoryItem ammo, InventoryController origin, MagazineState magazine,
            CombatReloadSources sources, int armLevel, out string error)
        {
            return BeginGameplayAmmoDrop(ammo, origin, magazine, sources, armLevel, out error, () => true);
        }

        private bool TargetStillValid() => (_validateTarget == null || _validateTarget()) &&
            (_operation != Operation.MagazineRounds || IsStandaloneMagazineOwned(_magazine, _sources));

        private bool TransferRound()
        {
            InventoryItem ammo; InventoryController origin;
            if (_specificAmmo != null) { ammo = _specificAmmo; origin = _specificOrigin; }
            else if (!_sources.TryFindAmmo(_weapon?.Data.Caliber ?? _magazine.Data.Caliber, out ammo, out origin)) return false;
            if (!IsAmmoOwned(ammo, origin, _sources)) return false;
            var round = new AmmoRound(ammo.Data);
            using (_items.DeferChanges())
                return origin.TryConsumeSingleForTransfer(ammo, () => _operation == Operation.MagazineRounds
                    ? _magazine.TryPush(round) : PushWeaponRound(_weapon, round));
        }

        private bool TransferChamberRound()
        {
            int chamber = _weapon.FirstEmptyChamber();
            if (chamber < 0) return false;
            if ((_weapon.Magazine != null && _weapon.Magazine.Count > 0) || _weapon.InternalRounds.Count > 0)
                return _weapon.TryChamberAttachedRound();
            if (!_sources.TryFindAmmo(_weapon.Data.Caliber, out var ammo, out var origin) || !IsAmmoOwned(ammo, origin, _sources))
                return false;
            return origin.TryConsumeSingleForTransfer(ammo, () => _weapon.TryLoadEmptyChamber(chamber, new AmmoRound(ammo.Data)));
        }

        private bool CanContinueRounds()
        {
            bool space = _operation == Operation.MagazineRounds ? _magazine.Count < _magazine.Capacity :
                _weapon.Magazine != null ? _weapon.Magazine.Count < _weapon.Magazine.Capacity : HasWeaponSpace(_weapon);
            if (!space) return false;
            return _specificAmmo != null ? IsAmmoOwned(_specificAmmo, _specificOrigin, _sources) :
                _sources.TryFindAmmo(_weapon?.Data.Caliber ?? _magazine.Data.Caliber, out _, out _);
        }

        private bool CompleteMagazineSwap()
        {
            if (!ReferenceEquals(_weapon.Magazine, _originalMagazine) || !_sources.Contains(_selectedOrigin) ||
                !_items.TryGetMagazine(_selectedMagazine.InstanceID, out var next) || next.OwnerWeaponID != 0 ||
                !next.IsCompatibleWith(_weapon.Data)) return false;
            using (_items.DeferChanges())
            {
                bool swapped = InventoryController.TryExchangeDetachedItem(_selectedOrigin, _selectedMagazine,
                    _returnMagazine, _sources.Controllers, () =>
                    {
                        if (_originalMagazine != null && !_weapon.TryRemoveMagazine(out _)) return false;
                        if (_weapon.TrySetMagazine(next)) return true;
                        if (_originalMagazine != null) _weapon.TrySetMagazine(_originalMagazine);
                        return false;
                    });
                if (swapped)
                {
                    // R completes the magazine exchange with an automatic empty-chamber cycle.
                    if (_weapon.FirstEmptyChamber() >= 0) _weapon.TryChamberAttachedRound();
                    _detachedMagazines[next.InstanceID] = _selectedMagazine;
                    if (_returnMagazine != null) _detachedMagazines.Remove(_returnMagazine.InstanceID);
                    _items.MarkDirty();
                }
                return swapped;
            }
        }

        private bool TrySelectMagazine(WeaponState weapon, CombatReloadSources sources,
            out InventoryItem selected, out InventoryController origin)
        {
            InventoryItem best = null; InventoryController bestOrigin = null;
            int bestCount = -1, ties = 0;
            sources.Visit((item, controller) =>
            {
                if (item.Type != ItemType.Magazine || item.Quantity != 1) return;
                var state = _items.GetOrCreateMagazine(item);
                if (state.OwnerWeaponID != 0 || !state.IsCompatibleWith(weapon.Data)) return;
                if (state.Count > bestCount) { bestCount = state.Count; ties = 1; best = item; bestOrigin = controller; }
                else if (state.Count == bestCount)
                {
                    ties++;
                    if (_random01() < 1f / ties) { best = item; bestOrigin = controller; }
                }
            });
            selected = best; origin = bestOrigin;
            return best != null;
        }

        private InventoryItem GetMagazineItem(MagazineState magazine) =>
            _detachedMagazines.TryGetValue(magazine.InstanceID, out var item) ? item :
                new InventoryItem(magazine.Data, magazine.InstanceID, 1, magazine.Data.MaxDurability, false);

        private static bool IsAmmo(InventoryItem ammo) => ammo != null && ammo.Type == ItemType.Ammo &&
            ammo.Quantity > 0 && ammo.Data.Ammunition != null;

        private static bool IsAmmoOwned(InventoryItem ammo, InventoryController origin, CombatReloadSources sources) =>
            IsAmmo(ammo) && sources.Contains(origin) && ReferenceEquals(origin.GetItemByInstanceID(ammo.InstanceID), ammo);

        private static bool IsStandaloneMagazineOwned(MagazineState magazine, CombatReloadSources sources)
        {
            if (magazine == null || magazine.OwnerWeaponID != 0) return false;
            for (int i = 0; i < sources.Controllers.Count; i++)
            {
                var item = sources.Controllers[i].GetItemByInstanceID(magazine.InstanceID);
                if (item != null && item.Quantity == 1 && ReferenceEquals(item.Data, magazine.Data)) return true;
            }
            return false;
        }

        private static bool HasWeaponSpace(WeaponState weapon)
        {
            for (int i = 0; i < weapon.Chambers.Count; i++) if (weapon.Chambers[i] == null) return true;
            return weapon.InternalRounds.Count < weapon.InternalMagazineCapacity;
        }

        private static bool PushWeaponRound(WeaponState weapon, AmmoRound round)
        {
            if (weapon.Magazine != null) return weapon.Magazine.TryPush(round);
            for (int i = 0; i < weapon.Chambers.Count; i++)
                if (weapon.Chambers[i] == null) return weapon.TryLoadEmptyChamber(i, round);
            return weapon.TryPushInternalRound(round);
        }
    }
}
