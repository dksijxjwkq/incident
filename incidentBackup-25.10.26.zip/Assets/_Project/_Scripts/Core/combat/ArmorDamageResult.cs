using System;

namespace K_Incident.Core.Combat
{
    public readonly struct ArmorDamageResult
    {
        public readonly float HealthDamage;
        public readonly float ArmorDamage;
        public readonly float FractureMultiplier;
        public readonly float ConcussionMultiplier;
        public readonly bool WasProtected;

        public ArmorDamageResult(float healthDamage, float armorDamage, float fracture, float concussion, bool protectedPart)
        {
            HealthDamage = healthDamage;
            ArmorDamage = armorDamage;
            FractureMultiplier = fracture;
            ConcussionMultiplier = concussion;
            WasProtected = protectedPart;
        }

        public bool TryApplyFracture(IDamageReceiver receiver, BodyPart part, float baseChance, float probabilitySample)
        {
            if (receiver == null) throw new ArgumentNullException(nameof(receiver));
            if (float.IsNaN(baseChance) || baseChance < 0f || baseChance > 1f)
                throw new ArgumentOutOfRangeException(nameof(baseChance));
            ValidateProbability(probabilitySample, nameof(probabilitySample));
            if (receiver.GetStatus(part).Fractured || probabilitySample >= baseChance * FractureMultiplier) return false;
            receiver.ApplyStatus(part, new DamageStatus(DamageType.Fracture));
            return receiver.GetStatus(part).Fractured;
        }

        public void ApplyHeadTrauma(IDamageReceiver receiver, BodyPart part, float probabilitySample,
            K_HealthConfig healthConfig = null)
        {
            ValidateProbability(probabilitySample, nameof(probabilitySample));
            HeadTraumaRules.Apply(receiver, part, HealthDamage, ConcussionMultiplier, probabilitySample, healthConfig);
        }

        private static void ValidateProbability(float value, string name)
        {
            if (float.IsNaN(value) || value < 0f || value >= 1f) throw new ArgumentOutOfRangeException(name);
        }
    }
}
