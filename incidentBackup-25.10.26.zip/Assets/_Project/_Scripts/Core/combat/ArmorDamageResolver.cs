using System;

namespace K_Incident.Core.Combat
{
    /// <summary>Pure impact calculation plus armor condition loss; callers apply HP and statuses separately.</summary>
    public sealed class ArmorDamageResolver
    {
        private readonly WeaponBalanceConfig _config;

        public ArmorDamageResolver(WeaponBalanceConfig config)
        {
            _config = config ?? throw new ArgumentNullException(nameof(config));
        }

        public ArmorDamageResult Resolve(float baseDamage, string caliber, AmmoType ammoType,
            BodyPart part, ArmorState armor = null)
        {
            if (float.IsNaN(baseDamage) || float.IsInfinity(baseDamage) || baseDamage < 0f)
                throw new ArgumentOutOfRangeException(nameof(baseDamage));
            if ((int)part < 0 || (int)part >= 20) throw new ArgumentOutOfRangeException(nameof(part));
            var ammo = _config.GetAmmoType(ammoType);
            var caliberData = _config.GetCaliber(caliber);
            float healthDamage = CheckedDamage((double)baseDamage * ammo.DamageMultiplier);
            if (armor == null || armor.IsBroken || !armor.Covers(part))
                return new ArmorDamageResult(healthDamage, 0f, 1f, 1f, false);

            var protection = _config.GetArmorClass(armor.Definition.ArmorClass);
            float durabilityDamage = CheckedDamage((double)baseDamage * caliberData.ArmorDamageMultiplier * ammo.ArmorDamageMultiplier);
            armor.ApplyDurabilityDamage(durabilityDamage);
            // The impact uses the class at contact; the following impact sees broken armor.
            return new ArmorDamageResult(healthDamage * (1f - protection.DamageReduction), durabilityDamage,
                protection.FractureMultiplier, protection.ConcussionMultiplier, true);
        }

        private static float CheckedDamage(double value)
        {
            if (double.IsNaN(value) || double.IsInfinity(value) || value > float.MaxValue || value < 0)
                throw new OverflowException("Resolved damage is outside the finite float range.");
            return (float)value;
        }
    }
}
