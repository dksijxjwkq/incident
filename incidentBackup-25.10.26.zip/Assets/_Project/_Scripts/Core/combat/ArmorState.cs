using System;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    /// <summary>Runtime armor condition. A living NPC may conceal, but never ignore, real condition.</summary>
    public sealed class ArmorState
    {
        public ItemStaticData Definition { get; }
        public float MaximumDurability { get; }
        public float Durability { get; private set; }
        public bool IsConditionRevealed { get; private set; }
        public bool IsBroken => Durability <= 0f;
        public event Action Changed;

        public ArmorState(ItemStaticData definition, WeaponBalanceConfig config,
            float? durability = null, bool concealLivingNpcCondition = false)
        {
            Definition = definition ?? throw new ArgumentNullException(nameof(definition));
            if (config == null) throw new ArgumentNullException(nameof(config));
            if (definition.EquipAffinity != EquipAffinity.BodyArmor && definition.EquipAffinity != EquipAffinity.HeadGear)
                throw new ArgumentException("Armor must use BodyArmor or HeadGear.", nameof(definition));
            MaximumDurability = config.GetArmorClass(definition.ArmorClass).BaseDurability;
            if (definition.MaxDurability > 0) MaximumDurability = definition.MaxDurability;
            if (MaximumDurability <= 0f || float.IsNaN(MaximumDurability) || float.IsInfinity(MaximumDurability))
                throw new ArgumentException("Configured durability must be finite and positive.", nameof(config));
            float initial = durability ?? MaximumDurability;
            if (float.IsNaN(initial) || float.IsInfinity(initial)) throw new ArgumentOutOfRangeException(nameof(durability));
            Durability = Math.Max(0f, Math.Min(MaximumDurability, initial));
            IsConditionRevealed = !concealLivingNpcCondition;
        }

        public bool Covers(BodyPart part)
        {
            if (Definition.EquipAffinity == EquipAffinity.HeadGear) return part == BodyPart.Head;
            return part == BodyPart.Chest || (part == BodyPart.Stomach && Definition.Armor.CoversAbdomen);
        }

        public void RevealCondition()
        {
            if (IsConditionRevealed) return;
            IsConditionRevealed = true;
            Changed?.Invoke();
        }

        public void ApplyDurabilityDamage(float damage)
        {
            if (float.IsNaN(damage) || float.IsInfinity(damage) || damage < 0f)
                throw new ArgumentOutOfRangeException(nameof(damage));
            Durability = Math.Max(0f, Durability - damage);
            Changed?.Invoke();
        }
    }
}
