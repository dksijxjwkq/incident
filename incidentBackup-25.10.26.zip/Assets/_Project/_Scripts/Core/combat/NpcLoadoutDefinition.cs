using System;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Combat
{
    [Serializable]
    public struct NpcStateRange
    {
        public float Minimum;
        public float Maximum;

        public NpcStateRange(float minimum, float maximum)
        {
            Minimum = minimum;
            Maximum = maximum;
        }
    }

    [Serializable]
    public sealed class NpcLoadoutEntry
    {
        public ItemStaticData Item;
        public int Quantity = 1;
        public bool Equipped;
        public EquipmentSlotType Slot;
        // Fractions of configured maximum; sampled by a future spawn system.
        public NpcStateRange DurabilityFraction = new NpcStateRange(.3f, 1f);
        public NpcStateRange MagazineFillFraction = new NpcStateRange(0f, 1f);
        public NpcStateRange RemainingConsumableFraction = new NpcStateRange(0f, 1f);
        public ItemStaticData InsertedMagazine;
        // Bottom to top. Entries may have different ammunition types.
        public ItemStaticData[] MagazineAmmunition = Array.Empty<ItemStaticData>();
    }

    /// <summary>Fixed set, with state ranges only. No NPC spawner/AI/loot UI is introduced in 5.1.</summary>
    [Serializable]
    public sealed class NpcLoadoutDefinition
    {
        public string Id;
        public NpcLoadoutEntry[] Items = Array.Empty<NpcLoadoutEntry>();
        public bool ConcealArmorConditionWhileAlive = true;
    }
}
