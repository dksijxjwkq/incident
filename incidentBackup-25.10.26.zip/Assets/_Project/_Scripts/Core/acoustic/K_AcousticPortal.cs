using UnityEngine;
using System.Collections.Generic;

namespace K_Incident.Core
{
    // =====================================================================
    //  ACOUSTIC PORTAL — Blind Relay (ТЗ Аспект #7)
    // =====================================================================

    /// <summary>
    /// Акустический портал (дверь/окно).
    /// ТЗ: Portal.ExteriorPosition + (Portal.Forward * 2.0f)
    /// </summary>
    [DefaultExecutionOrder(-90)]
    public class K_AcousticPortal : MonoBehaviour
    {
        private static readonly List<K_AcousticPortal> _enabledPortals = new List<K_AcousticPortal>();
        internal static K_AcousticPortal[] EnabledPortals
        {
            get
            {
                _enabledPortals.RemoveAll(portal => portal == null || !portal.isActiveAndEnabled);
                return _enabledPortals.ToArray();
            }
        }
        private void OnEnable()
        {
            if (!_enabledPortals.Contains(this)) _enabledPortals.Add(this);
            K_AcousticSystem.RegisteredInstance?.RegisterPortal(this);
        }
        private void OnDisable()
        {
            _enabledPortals.Remove(this);
            K_AcousticSystem.RegisteredInstance?.UnregisterPortal(this);
        }
        private void OnDestroy() => OnDisable();
        [Header("Portal Anchors")]
        [SerializeField, Tooltip("Точка выхода со стороны улицы")]
        private Transform _exteriorAnchor;

        [Header("Portal State")]
        [SerializeField, Tooltip("Дверь закрыта?")]
        private bool _isClosed;

        [Header("Occlusion Presets")]
        [SerializeField, Tooltip("Множитель при закрытой двери")]
        private float _closedMultiplier = 0.2f;

        [SerializeField, Tooltip("Множитель при открытой двери")]
        private float _openMultiplier = 0.7f;

        [Header("Tags")]
        [SerializeField, Tooltip("Является ли портал Indoor-зоной")]
        private bool _isIndoor = true;

        public Vector3 Forward => transform.forward;
        public Vector3 ExteriorPosition => _exteriorAnchor != null ? _exteriorAnchor.position : transform.position;
        public Vector3 RelayPoint => ExteriorPosition + Forward * 2.0f;
        public float OcclusionMultiplier => _isClosed ? _closedMultiplier : _openMultiplier;
        public bool IsIndoor => _isIndoor;
        public bool IsClosed => _isClosed;

        public void SetOpen(bool open) => _isClosed = !open;

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.cyan;
            Gizmos.DrawWireSphere(ExteriorPosition, 0.5f);
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(RelayPoint, 0.8f);
            Gizmos.DrawLine(ExteriorPosition, RelayPoint);
            Gizmos.color = Color.green;
            Gizmos.DrawRay(transform.position, Forward * 2f);
            Gizmos.color = _isClosed ? Color.red : Color.green;
            Gizmos.DrawWireCube(transform.position, Vector3.one * 0.6f);
        }
#endif
    }

}
