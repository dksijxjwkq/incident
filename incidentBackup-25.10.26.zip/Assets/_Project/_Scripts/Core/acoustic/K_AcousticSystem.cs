using UnityEngine;
using System.Collections.Generic;

namespace K_Incident.Core
{
    // =====================================================================
    //  NOISE TYPES — строго по ТЗ проекта «INCIDENT»
    // =====================================================================

    /// <summary>
    /// Типы источников шума.
    /// Уникальные значения enum (без дубликатов!).
    /// Приоритет получается через GetPriority().
    ///
    /// Маппинг приоритетов (Аспект №8):
    ///   P:5 — Gunshot, Explosion
    ///   P:4 — Shout
    ///   P:3 — Footstep, Sprint, Looting, Reload, Throw, Misfire
    ///   P:2 — Speech
    ///   P:0 — Thought
    /// </summary>
    public enum NoiseSourceType
    {
        Thought = 0,
        Speech = 1,
        Footstep = 2,
        Sprint = 3,
        Looting = 4,
        Reload = 5,
        Throw = 6,
        Misfire = 7,
        Shout = 8,
        Gunshot = 9,
        Explosion = 10
    }

    // =====================================================================
    //  NOISE EVENT — строго по ТЗ: {Position, Intensity, SourceType}
    // =====================================================================

    /// <summary>
    /// Событие шума. ТЗ требует именно эту структуру:
    ///   Vector3 Position, float Intensity, SourceType Type
    /// </summary>
    public struct NoiseEvent
    {
        /// <summary>Позиция источника шума в мировых координатах</summary>
        public Vector3 Position;

        /// <summary>
        /// Интенсивность (0..1). Рассчитывается из базового радиуса через
        /// окклюзию и множители поверхности/состояния.
        /// Если finalIntensity &lt; 0.1f — ИИ игнорирует.
        /// </summary>
        public float Intensity;

        /// <summary>Actual source radius, retained for direct and relayed events.</summary>
        public float BaseRadius;

        /// <summary>Тип источника (определяет приоритет и реакцию AI)</summary>
        public NoiseSourceType Type;

        /// <summary>Время возникновения (Time.time)</summary>
        public float Timestamp;

        /// <summary>GameObject-источник (опционально)</summary>
        public GameObject Source;

        /// <summary>Является ли этот шум ретранслированным через портал</summary>
        public bool IsRelayed;
    }

    // =====================================================================
    //  INOISE LISTENER
    // =====================================================================

    /// <summary>
    /// Интерфейс для AI-агентов, способных "слышать" шум.
    /// </summary>
    public interface INoiseListener
    {
        void OnNoiseHeard(NoiseEvent noiseEvent);
        Vector3 ListenerPosition { get; }
    }

    // =====================================================================
    //  K_ACOUSTIC SYSTEM — строго по ТЗ проекта «INCIDENT»
    // =====================================================================

    /// <summary>
    /// Глобальная система распространения шума.
    /// ТЗ-требования:
    ///   - Event-Based: NoiseEvent {Position, Intensity, SourceType}
    ///   - Occlusion: Physics.Linecast, Heavy 0.2x, Cover 0.7x, discard &lt; 0.1
    ///   - Acoustic Bridge (Blind Relay): через K_AcousticPortal
    ///   - Surface: Crouch 0.3x, Metal 2.0x, Suppressor 0.35x
    ///   - Weapon signatures: Handgun 25m, AR 50m, Shotgun/Rifle 60m
    ///   - Indoor wall modifier: 0.7x
    ///   - AudioMixer Snapshots: Default/Occluded, 0.15s
    /// </summary>
    [DefaultExecutionOrder(-100)]
    public class K_AcousticSystem : MonoBehaviour
    {
        #region Singleton

        private static K_AcousticSystem _instance;

        public static K_AcousticSystem RegisteredInstance => _instance;

        public static K_AcousticSystem Instance
        {
            get
            {
                return _instance;
            }
        }

        #endregion

        #region Priority Helper

        /// <summary>
        /// Возвращает приоритет шума (ТЗ Аспект #8).
        /// P:0 Thought, P:2 Speech, P:3 Mechanical, P:4 Shout, P:5 Weapon/Explosion
        /// </summary>
        public static int GetPriority(NoiseSourceType type)
        {
            return type switch
            {
                NoiseSourceType.Thought => 0,
                NoiseSourceType.Speech => 2,
                NoiseSourceType.Footstep => 3,
                NoiseSourceType.Sprint => 3,
                NoiseSourceType.Looting => 3,
                NoiseSourceType.Reload => 3,
                NoiseSourceType.Throw => 3,
                NoiseSourceType.Misfire => 3,
                NoiseSourceType.Shout => 4,
                NoiseSourceType.Gunshot => 5,
                NoiseSourceType.Explosion => 5,
                _ => 0
            };
        }

        #endregion

        #region Inspector

        [Header("Occlusion Layers (ТЗ Аспект #7)")]
        [SerializeField, Tooltip("LayerMask для тяжёлой окклюзии (стены)")]
        private LayerMask _heavyOcclusionMask;

        [SerializeField, Tooltip("LayerMask для лёгкой окклюзии (укрытия)")]
        private LayerMask _coverOcclusionMask;

        [Header("Occlusion Multipliers (ТЗ)")]
        [SerializeField] private float _heavyOcclusionMultiplier = 0.2f;
        [SerializeField] private float _coverOcclusionMultiplier = 0.7f;
        [SerializeField, Tooltip("Порог отбрасывания (finalIntensity < этого = ИИ не слышит)")]
        private float _discardThreshold = 0.1f;

        [Header("Surface Multipliers (ТЗ Аспект #7)")]
        [SerializeField, Tooltip("Множитель при приседе (0.3x)")]
        private float _crouchMultiplier = 0.3f;

        [SerializeField, Tooltip("Множитель на металлических поверхностях (2.0x)")]
        private float _metalSurfaceMultiplier = 2.0f;

        [Header("Indoor Modifier (ТЗ Аспект #8)")]
        [SerializeField, Tooltip("Множитель для источников внутри здания (0.7x)")]
        private float _indoorWallModifier = 0.7f;

        [Header("Suppressor (ТЗ Аспект #8, #10)")]
        [SerializeField, Tooltip("Множитель с глушителем (0.35x, кроме дробовиков)")]
        private float _suppressorMultiplier = 0.35f;

        [Header("Weapon Acoustic Signatures (ТЗ Аспект #8)")]
        [SerializeField] private float _handgunRadius = 25f;
        [SerializeField] private float _assaultRifleRadius = 50f;
        [SerializeField] private float _shotgunRifleRadius = 60f;

        [Header("Footstep Radii (ТЗ Аспект #8)")]
        [SerializeField] private float _footstepWalkRadius = 7f;
        [SerializeField] private float _footstepCrouchRadius = 2.1f;
        [SerializeField] private float _footstepSprintRadius = 20f;

        [Header("Looting Radii (ТЗ Аспект #2)")]
        [SerializeField] private float _lootSoftRadius = 1f;
        [SerializeField] private float _lootMediumRadius = 12f;
        [SerializeField] private float _lootHardRadius = 20f;

        [Header("Other Radii")]
        [SerializeField] private float _speechRadius = 5f;
        [SerializeField] private float _shoutRadius = 25f;
        [SerializeField] private float _misfireRadius = 3f;

        [Header("AudioMixer Snapshots (ТЗ Аспект #12)")]
        [SerializeField] private UnityEngine.Audio.AudioMixer _audioMixer;
        [SerializeField] private string _defaultSnapshotName = "Default";
        [SerializeField] private string _occludedSnapshotName = "Occluded";
        [SerializeField, Tooltip("Время перехода (0.15с)")]
        private float _snapshotTransitionTime = 0.15f;

        [Header("Portal System")]
        [SerializeField] private K_AcousticPortal[] _portals;

        [Header("Debug")]
        [SerializeField] private bool _debugDrawGizmos;
        [SerializeField] private bool _debugLogBroadcasts;

        #endregion

        #region WeaponType

        public enum WeaponAcousticType
        {
            Handgun,
            AssaultRifle,
            ShotgunRifle,
            Knife
            // Preserve the existing numeric values and the legacy combined category.
            , Rifle
            , BoltAction
            , Shotgun
            , DoubleBarrel
        }

        #endregion

        #region Fields

        private readonly List<INoiseListener> _listeners = new List<INoiseListener>();
        private readonly Dictionary<INoiseListener, UnityEngine.Object> _listenerOwners =
            new Dictionary<INoiseListener, UnityEngine.Object>();
        private readonly Dictionary<INoiseListener, ListenerRegistration> _listenerRegistrations =
            new Dictionary<INoiseListener, ListenerRegistration>();
        private readonly List<NoiseEvent> _recentNoises = new List<NoiseEvent>();
        private const float NOISE_EVENT_LIFETIME = 2f;
        private UnityEngine.Audio.AudioMixerSnapshot _defaultSnapshot;
        private UnityEngine.Audio.AudioMixerSnapshot _occludedSnapshot;
        private bool _snapshotsInitialized;

        #endregion

        #region Properties

        public int ListenerCount => _listeners.Count;
        public float CrouchMultiplier => _crouchMultiplier;
        public float MetalSurfaceMultiplier => _metalSurfaceMultiplier;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (_instance != null && _instance != this)
            {
                Debug.LogWarning("[AcousticSystem] Duplicate detected. Destroying.");
                Destroy(gameObject);
                return;
            }
            _instance = this;

            if (_portals == null || _portals.Length == 0)
                _portals = FindObjectsByType<K_AcousticPortal>(FindObjectsSortMode.None);
            foreach (var portal in K_AcousticPortal.EnabledPortals) RegisterPortal(portal);
        }

        private void Start()
        {
            InitializeSnapshots();
        }

        private void Update()
        {
            PruneDestroyedListeners();
            float now = Time.time;
            for (int i = _recentNoises.Count - 1; i >= 0; i--)
            {
                if (now - _recentNoises[i].Timestamp > NOISE_EVENT_LIFETIME)
                    _recentNoises.RemoveAt(i);
            }
        }

        private void OnDisable()
        {
            _recentNoises.Clear();
        }

        private void OnDestroy()
        {
            if (_instance == this) _instance = null;
            _listeners.Clear();
            _recentNoises.Clear();
            _listenerOwners.Clear();
            _listenerRegistrations.Clear();
        }

        #endregion

        #region Core Broadcast

        /// <summary>
        /// Основной метод вещания шума.
        /// </summary>
        public void BroadcastNoise(
            Vector3 position,
            float baseRadius,
            NoiseSourceType type,
            GameObject source = null,
            bool isIndoor = false,
            bool isCrouching = false,
            bool isOnMetal = false,
            bool hasSuppressor = false)
        {
            if (!isActiveAndEnabled) return;
            ValidateBroadcast(position, baseRadius, isIndoor);
            if (baseRadius <= 0f)
            {
                if (_debugLogBroadcasts)
                    Debug.Log($"[AcousticSystem] Skipped {type}: radius=0");
                return;
            }

            float intensity = 1f;

            if (isIndoor) intensity *= _indoorWallModifier;
            if (isCrouching) intensity *= _crouchMultiplier;
            if (isOnMetal) intensity *= _metalSurfaceMultiplier;

            if (hasSuppressor && type == NoiseSourceType.Gunshot)
            {
                bool isShotgun = Mathf.Approximately(baseRadius, _shotgunRifleRadius);
                if (!isShotgun)
                    intensity *= _suppressorMultiplier;
            }

            intensity = Mathf.Clamp01(intensity);

            if (_debugLogBroadcasts)
            {
                Debug.Log($"[AcousticSystem] Noise: {type} at {position} " +
                          $"R={baseRadius:F1}m Int={intensity:F2}");
            }

            var noiseEvent = new NoiseEvent
            {
                Position = position,
                Intensity = intensity,
                BaseRadius = baseRadius,
                Type = type,
                Timestamp = Time.time,
                Source = source
            };

            _recentNoises.Add(noiseEvent);

            // Acoustic Bridge (Blind Relay) — ТЗ Аспект #7
            if (isIndoor)
            {
                K_AcousticPortal nearestPortal = FindNearestPortal(position);
                if (nearestPortal != null)
                {
                    float relayedIntensity = intensity * nearestPortal.OcclusionMultiplier;
                    if (relayedIntensity >= _discardThreshold)
                    {
                        var relayedEvent = new NoiseEvent
                        {
                            Position = nearestPortal.RelayPoint,
                            Intensity = relayedIntensity,
                            BaseRadius = baseRadius,
                            Type = type,
                            Timestamp = Time.time,
                            Source = source,
                            IsRelayed = true
                        };
                        _recentNoises.Add(relayedEvent);
                        NotifyListeners(relayedEvent);
                    }
                }
            }

            NotifyListeners(noiseEvent);
        }

        #endregion

        #region Convenience Methods (ТЗ Аспект #8)

        /// <summary>
        /// Explicit weapon-category overload. The legacy general broadcast stays unchanged;
        /// this path preserves its delivery, relay, clamp and occlusion rules.
        /// </summary>
        public void BroadcastNoise(
            Vector3 position,
            float baseRadius,
            NoiseSourceType type,
            GameObject source,
            bool isIndoor,
            bool isCrouching,
            bool isOnMetal,
            bool hasSuppressor,
            bool isShotgunLike)
        {
            if (!isActiveAndEnabled) return;
            ValidateBroadcast(position, baseRadius, isIndoor);
            if (baseRadius <= 0f)
            {
                if (_debugLogBroadcasts)
                    Debug.Log($"[AcousticSystem] Skipped {type}: radius=0");
                return;
            }

            float intensity = 1f;
            if (isIndoor) intensity *= _indoorWallModifier;
            if (isCrouching) intensity *= _crouchMultiplier;
            if (isOnMetal) intensity *= _metalSurfaceMultiplier;
            if (hasSuppressor && type == NoiseSourceType.Gunshot && !isShotgunLike)
                intensity *= _suppressorMultiplier;
            intensity = Mathf.Clamp01(intensity);

            if (_debugLogBroadcasts)
            {
                Debug.Log($"[AcousticSystem] Noise: {type} at {position} " +
                          $"R={baseRadius:F1}m Int={intensity:F2}");
            }

            var noiseEvent = new NoiseEvent
            {
                Position = position,
                Intensity = intensity,
                BaseRadius = baseRadius,
                Type = type,
                Timestamp = Time.time,
                Source = source
            };
            _recentNoises.Add(noiseEvent);

            if (isIndoor)
            {
                K_AcousticPortal nearestPortal = FindNearestPortal(position);
                if (nearestPortal != null)
                {
                    float relayedIntensity = intensity * nearestPortal.OcclusionMultiplier;
                    if (relayedIntensity >= _discardThreshold)
                    {
                        var relayedEvent = new NoiseEvent
                        {
                            Position = nearestPortal.RelayPoint,
                            Intensity = relayedIntensity,
                            BaseRadius = baseRadius,
                            Type = type,
                            Timestamp = Time.time,
                            Source = source,
                            IsRelayed = true
                        };
                        _recentNoises.Add(relayedEvent);
                        NotifyListeners(relayedEvent);
                    }
                }
            }

            NotifyListeners(noiseEvent);
        }

        /// <summary>Source-aware footsteps: arm noise and hangover affect the radius only.</summary>
        public void BroadcastFootstep(Vector3 position, bool isCrouching, bool isSprinting,
            bool isOnMetal, bool isIndoor, GameObject source)
        {
            float radius;
            NoiseSourceType noiseType;
            if (isCrouching)
            {
                radius = _footstepCrouchRadius;
                noiseType = NoiseSourceType.Footstep;
            }
            else if (isSprinting)
            {
                radius = _footstepSprintRadius;
                noiseType = NoiseSourceType.Sprint;
            }
            else
            {
                radius = _footstepWalkRadius;
                noiseType = NoiseSourceType.Footstep;
            }

            if (isOnMetal) radius *= _metalSurfaceMultiplier;
            radius *= GetSourceArmNoiseMultiplier(source);
            K_VitalitySystem vitality = source != null ? source.GetComponent<K_VitalitySystem>() : null;
            if (vitality != null) radius *= vitality.HangoverFootstepNoiseMultiplier;
            float sourceRadius = isCrouching && _crouchMultiplier > 0f
                ? radius / _crouchMultiplier : radius;
            BroadcastNoise(position, sourceRadius, noiseType,
                source: source, isIndoor: isIndoor, isCrouching: isCrouching, isOnMetal: false);
        }

        private void BroadcastTypedGunshot(Vector3 position, WeaponAcousticType weaponType,
            bool hasSuppressor, bool isIndoor, GameObject source)
        {
            float radius = weaponType switch
            {
                WeaponAcousticType.Handgun => _handgunRadius,
                WeaponAcousticType.AssaultRifle => _assaultRifleRadius,
                WeaponAcousticType.Rifle => _shotgunRifleRadius,
                WeaponAcousticType.BoltAction => _shotgunRifleRadius,
                WeaponAcousticType.Shotgun => _shotgunRifleRadius,
                WeaponAcousticType.DoubleBarrel => _shotgunRifleRadius,
                WeaponAcousticType.Knife => 0f,
                _ => 25f
            };
            radius *= GetSourceArmNoiseMultiplier(source);
            bool isShotgunLike = weaponType == WeaponAcousticType.Shotgun ||
                weaponType == WeaponAcousticType.DoubleBarrel;
            BroadcastNoise(position, radius, NoiseSourceType.Gunshot, source, isIndoor,
                false, false, hasSuppressor, isShotgunLike);
        }

        private static float GetSourceArmNoiseMultiplier(GameObject source)
        {
            K_HealthSystem health = source != null ? source.GetComponent<K_HealthSystem>() : null;
            return health != null ? health.GetArmNoiseMultiplier() : 1f;
        }

        /// <summary>Шаги. ТЗ: Crouch 2.1м / Walk 7.0м / Run 20.0м</summary>
        public void BroadcastFootstep(Vector3 position, bool isCrouching, bool isSprinting, bool isOnMetal, bool isIndoor)
        {
            float radius;
            NoiseSourceType noiseType;

            if (isCrouching)
            {
                radius = _footstepCrouchRadius;
                noiseType = NoiseSourceType.Footstep;
            }
            else if (isSprinting)
            {
                radius = _footstepSprintRadius;
                noiseType = NoiseSourceType.Sprint;
            }
            else
            {
                radius = _footstepWalkRadius;
                noiseType = NoiseSourceType.Footstep;
            }

            // Metal changes the step radius, before the existing crouch compensation.
            if (isOnMetal) radius *= _metalSurfaceMultiplier;
            isOnMetal = false;

            // Keep crouch intensity, but do not reduce the configured crouch radius twice.
            float sourceRadius = isCrouching && _crouchMultiplier > 0f
                ? radius / _crouchMultiplier : radius;
            BroadcastNoise(position, sourceRadius, noiseType,
                isIndoor: isIndoor, isCrouching: isCrouching, isOnMetal: isOnMetal);
        }

        /// <summary>Выстрел. ТЗ: Handgun 25м / AR 50м / Shotgun-Rifle 60м. Knife = 0м.</summary>
        public void BroadcastGunshot(Vector3 position, WeaponAcousticType weaponType,
            bool hasSuppressor, bool isIndoor, GameObject source = null)
        {
            // Explicit categories use weapon identity, including when configured radii coincide.
            if (weaponType != WeaponAcousticType.ShotgunRifle)
            {
                BroadcastTypedGunshot(position, weaponType, hasSuppressor, isIndoor, source);
                return;
            }

            float radius = weaponType switch
            {
                WeaponAcousticType.Handgun => _handgunRadius,
                WeaponAcousticType.AssaultRifle => _assaultRifleRadius,
                WeaponAcousticType.ShotgunRifle => _shotgunRifleRadius,
                WeaponAcousticType.Knife => 0f,
                _ => 25f
            };

            radius *= GetSourceArmNoiseMultiplier(source);
            // The old combined category cannot distinguish rifles from shotguns.
            // Keep its historical shotgun-like suppressor exclusion for compatibility.
            if (weaponType == WeaponAcousticType.ShotgunRifle) hasSuppressor = false;

            BroadcastNoise(position, radius, NoiseSourceType.Gunshot,
                source: source, isIndoor: isIndoor, hasSuppressor: hasSuppressor);
        }

        /// <summary>Вскрытие контейнера (enum). ТЗ: Soft 1м / Medium 12м / Hard 20м</summary>
        public void BroadcastLooting(Vector3 position, LootBoxType boxType, bool isIndoor, GameObject source = null)
        {
            float radius = boxType switch
            {
                LootBoxType.Soft => _lootSoftRadius,
                LootBoxType.Hard => _lootHardRadius,
                _ => _lootMediumRadius
            };

            BroadcastNoise(position, radius, NoiseSourceType.Looting,
                source: source, isIndoor: isIndoor);
        }

        /// <summary>Вскрытие контейнера (string-версия)</summary>
        public void BroadcastLooting(Vector3 position, string lootBoxType, bool isIndoor, GameObject source = null)
        {
            float radius = lootBoxType?.ToLower() switch
            {
                "soft" => _lootSoftRadius,
                "hard" => _lootHardRadius,
                _ => _lootMediumRadius
            };

            BroadcastNoise(position, radius, NoiseSourceType.Looting,
                source: source, isIndoor: isIndoor);
        }

        /// <summary>Осечка. ТЗ: R=3м.</summary>
        public void BroadcastMisfire(Vector3 position, bool isIndoor, GameObject source = null)
        {
            BroadcastNoise(position, _misfireRadius, NoiseSourceType.Misfire,
                source: source, isIndoor: isIndoor);
        }

        /// <summary>Речь. ТЗ: R=5м.</summary>
        public void BroadcastSpeech(Vector3 position, bool isIndoor, GameObject source = null)
        {
            BroadcastNoise(position, _speechRadius, NoiseSourceType.Speech,
                source: source, isIndoor: isIndoor);
        }

        /// <summary>Крик. ТЗ: R=25м, P:4.</summary>
        public void BroadcastShout(Vector3 position, bool isIndoor, GameObject source = null)
        {
            BroadcastNoise(position, _shoutRadius, NoiseSourceType.Shout,
                source: source, isIndoor: isIndoor);
        }

        /// <summary>Бросок предмета. ТЗ: Интенсивность зависит от массы.</summary>
        public void BroadcastThrowableImpact(Vector3 position, float mass, bool isIndoor, GameObject source = null)
        {
            float massClamped = Mathf.Clamp(mass, 0.1f, 10f);
            float radius = Mathf.Lerp(3f, 15f, massClamped / 10f);
            BroadcastNoise(position, radius, NoiseSourceType.Throw,
                source: source, isIndoor: isIndoor);
        }

        /// <summary>Общий шум</summary>
        public void BroadcastGeneric(Vector3 position, float radius, bool isIndoor, GameObject source = null)
        {
            BroadcastNoise(position, radius, NoiseSourceType.Footstep,
                source: source, isIndoor: isIndoor);
        }

        #endregion

        #region Listener Management

        public void RegisterListener(INoiseListener listener)
        {
            PruneDestroyedListeners();
            if (!IsListenerAlive(listener)) return;
            if (listener == null) return;
            if (_listeners.Contains(listener))
            {
                Debug.LogWarning("[AcousticSystem] Listener already registered!");
                return;
            }
            _listeners.Add(listener);
        }

        public void UnregisterListener(INoiseListener listener)
        {
            if (listener == null) return;
            _listenerOwners.Remove(listener);
            _listenerRegistrations.Remove(listener);
            _listeners.Remove(listener);
        }

        /// <summary>Store the returned lease in the owner's OnEnable, and Dispose it in OnDisable/OnDestroy.</summary>
        public System.IDisposable RegisterListener(INoiseListener listener, UnityEngine.Object owner)
        {
            if (owner == null) throw new System.ArgumentNullException(nameof(owner));
            if (!IsListenerAlive(listener)) throw new System.ArgumentNullException(nameof(listener));
            if (_listeners.Contains(listener)) throw new System.InvalidOperationException("Listener already has an active registration.");
            RegisterListener(listener);
            _listenerOwners.Add(listener, owner);
            var registration = new ListenerRegistration(this, listener, owner);
            _listenerRegistrations.Add(listener, registration);
            return registration;
        }

        private sealed class ListenerRegistration : System.IDisposable
        {
            private K_AcousticSystem _system;
            private INoiseListener _listener;
            private UnityEngine.Object _owner;
            public ListenerRegistration(K_AcousticSystem system, INoiseListener listener, UnityEngine.Object owner)
            { _system = system; _listener = listener; _owner = owner; }
            public void Dispose()
            {
                var system = _system; var listener = _listener; var owner = _owner;
                _system = null; _listener = null; _owner = null;
                if (system != null && listener != null && system._listenerOwners.TryGetValue(listener, out var current) &&
                    ReferenceEquals(current, owner) && system._listenerRegistrations.TryGetValue(listener, out var registration) &&
                    ReferenceEquals(registration, this)) system.UnregisterListener(listener);
            }
        }

        private bool IsListenerAlive(INoiseListener listener) => listener != null &&
            (!(listener is UnityEngine.Object unityListener) || unityListener != null) &&
            (!_listenerOwners.TryGetValue(listener, out var owner) || owner != null);

        private void PruneDestroyedListeners()
        {
            for (int i = _listeners.Count - 1; i >= 0; i--)
                if (!IsListenerAlive(_listeners[i]))
                {
                    _listenerOwners.Remove(_listeners[i]);
                    _listenerRegistrations.Remove(_listeners[i]);
                    _listeners.RemoveAt(i);
                }
        }

        public void RegisterPortal(K_AcousticPortal portal)
        {
            if (portal == null || !portal.isActiveAndEnabled) return;
            var portals = new List<K_AcousticPortal>(_portals ?? new K_AcousticPortal[0]);
            if (!portals.Contains(portal)) portals.Add(portal);
            _portals = portals.ToArray();
        }

        public void UnregisterPortal(K_AcousticPortal portal)
        {
            var portals = new List<K_AcousticPortal>(_portals ?? new K_AcousticPortal[0]);
            portals.RemoveAll(candidate => candidate == null || ReferenceEquals(candidate, portal));
            _portals = portals.ToArray();
        }

        #endregion

        #region Query API

        public bool TryGetLastNoiseOfType(NoiseSourceType type, out NoiseEvent noiseEvent)
        {
            for (int i = _recentNoises.Count - 1; i >= 0; i--)
            {
                if (_recentNoises[i].Type == type)
                {
                    noiseEvent = _recentNoises[i];
                    return true;
                }
            }
            noiseEvent = default;
            return false;
        }

        /// <summary>Legacy global diagnostic; it does not establish that an AI listener heard the result.</summary>
        [System.Obsolete("Global diagnostic only. AI must use TryGetHighestPriorityNoise(listener, out noiseEvent).")]
        public bool TryGetHighestPriorityNoise(out NoiseEvent noiseEvent)
        {
            PruneDestroyedListeners();
            if (_recentNoises.Count == 0)
            {
                noiseEvent = default;
                return false;
            }

            int bestPriority = -1;
            int bestIndex = -1;
            float bestDistSq = float.MaxValue;

            Vector3 listenerPos = _listeners.Count > 0
                ? _listeners[_listeners.Count - 1].ListenerPosition
                : Vector3.zero;

            for (int i = 0; i < _recentNoises.Count; i++)
            {
                var n = _recentNoises[i];
                int p = GetPriority(n.Type);
                float distSq = (n.Position - listenerPos).sqrMagnitude;

                if (p > bestPriority || (p == bestPriority && distSq < bestDistSq))
                {
                    bestPriority = p;
                    bestIndex = i;
                    bestDistSq = distSq;
                }
            }

            if (bestIndex >= 0)
            {
                noiseEvent = _recentNoises[bestIndex];
                return true;
            }

            noiseEvent = default;
            return false;
        }

        /// <summary>Highest priority currently audible source for this listener, with the same gates as delivery.</summary>
        public bool TryGetHighestPriorityNoise(INoiseListener listener, out NoiseEvent noiseEvent)
        {
            PruneDestroyedListeners();
            noiseEvent = default;
            if (!IsListenerAlive(listener) || !IsFinite(listener.ListenerPosition)) return false;
            ValidateSettings();
            int bestPriority = -1;
            float bestDistance = float.MaxValue;
            foreach (var candidate in _recentNoises)
            {
                if (Time.time - candidate.Timestamp > NOISE_EVENT_LIFETIME) continue;
                float distance = Vector3.Distance(candidate.Position, listener.ListenerPosition);
                if (distance > candidate.BaseRadius * candidate.Intensity) continue;
                float intensity = ApplyOcclusion(candidate.Position, listener.ListenerPosition, candidate.Intensity);
                if (intensity < _discardThreshold) continue;
                int priority = GetPriority(candidate.Type);
                if (priority < bestPriority || (priority == bestPriority && distance >= bestDistance)) continue;
                noiseEvent = candidate; noiseEvent.Intensity = intensity;
                bestPriority = priority; bestDistance = distance;
            }
            return bestPriority >= 0;
        }

        #endregion

        #region AudioMixer Snapshot (ТЗ Аспект #12)

        public void SetOccludedSnapshot(bool occluded)
        {
            if (!_snapshotsInitialized) InitializeSnapshots();

            if (occluded && _occludedSnapshot != null)
                _occludedSnapshot.TransitionTo(_snapshotTransitionTime);
            else if (!occluded && _defaultSnapshot != null)
                _defaultSnapshot.TransitionTo(_snapshotTransitionTime);
        }

        private void InitializeSnapshots()
        {
            if (_audioMixer == null) return;

            // FindSnapshot возвращает snapshot напрямую (без out)
            _defaultSnapshot = _audioMixer.FindSnapshot(_defaultSnapshotName);
            if (_defaultSnapshot == null)
                Debug.LogWarning($"[AcousticSystem] Snapshot '{_defaultSnapshotName}' not found.");

            _occludedSnapshot = _audioMixer.FindSnapshot(_occludedSnapshotName);
            if (_occludedSnapshot == null)
                Debug.LogWarning($"[AcousticSystem] Snapshot '{_occludedSnapshotName}' not found.");

            _snapshotsInitialized = true;
        }

        #endregion

        #region Internal

        private void NotifyListeners(NoiseEvent noiseEvent)
        {
            PruneDestroyedListeners();
            var copy = new List<INoiseListener>(_listeners);

            for (int i = 0; i < copy.Count; i++)
            {
                var listener = copy[i];
                if (!IsListenerAlive(listener) || !_listeners.Contains(listener) || !IsFinite(listener.ListenerPosition)) continue;
                if (listener == null) continue;

                float distance = Vector3.Distance(noiseEvent.Position, listener.ListenerPosition);

                // Scale this source's own radius, including relayed sources.
                // Intensity 0.5 halves its hearing distance.
                float effectiveMaxRadius = noiseEvent.BaseRadius * noiseEvent.Intensity;

                if (distance > effectiveMaxRadius) continue;

                float finalIntensity = ApplyOcclusion(noiseEvent.Position, listener.ListenerPosition, noiseEvent.Intensity);

                if (finalIntensity < _discardThreshold) continue;

                var finalEvent = noiseEvent;
                finalEvent.Intensity = finalIntensity;

                listener.OnNoiseHeard(finalEvent);
            }
        }

        private float ApplyOcclusion(Vector3 from, Vector3 to, float intensity)
        {
            Vector3 direction = to - from;
            float distance = direction.magnitude;
            if (distance <= 0f) return intensity;

            // ТЗ Аспект #12: вертикальность > 3.0m → Heavy
            if (Mathf.Abs(from.y - to.y) > 3.0f)
                return intensity * _heavyOcclusionMultiplier;

            Vector3 dir = direction / distance;

            if (_heavyOcclusionMask != 0 && Physics.Linecast(from, to, _heavyOcclusionMask))
                return intensity * _heavyOcclusionMultiplier;

            if (_coverOcclusionMask != 0 && Physics.Linecast(from, to, _coverOcclusionMask))
                return intensity * _coverOcclusionMultiplier;

            return intensity;
        }

        private K_AcousticPortal FindNearestPortal(Vector3 position)
        {
            if (_portals == null || _portals.Length == 0) return null;

            // ФИКС БАГ #37: Используем быстрый поиск по sqrMagnitude вместо Distance
            K_AcousticPortal nearest = null;
            float nearestSqrDist = float.MaxValue;

            for (int i = 0; i < _portals.Length; i++)
            {
                var portal = _portals[i];
                if (portal != null && !portal.isActiveAndEnabled) continue;
                if (portal == null) continue;

                // Вычисляем квадрат расстояния (без дорогого sqrt)
                Vector3 offset = portal.transform.position - position;
                float sqrDist = offset.x * offset.x + offset.y * offset.y + offset.z * offset.z;

                if (sqrDist < nearestSqrDist)
                {
                    nearestSqrDist = sqrDist;
                    nearest = portal;
                }
            }

            return nearest;
        }

        private static bool IsFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        private static bool IsFinite(Vector3 value) => IsFinite(value.x) && IsFinite(value.y) && IsFinite(value.z);

        private void ValidateSettings()
        {
            foreach (float multiplier in new[] { _heavyOcclusionMultiplier, _coverOcclusionMultiplier, _discardThreshold,
                _crouchMultiplier, _indoorWallModifier, _suppressorMultiplier })
                if (!IsFinite(multiplier) || multiplier < 0f || multiplier > 1f)
                    throw new System.InvalidOperationException("Acoustic attenuation and threshold must be finite values in [0, 1].");
            if (!IsFinite(_metalSurfaceMultiplier) || _metalSurfaceMultiplier < 0f)
                throw new System.InvalidOperationException("Metal surface multiplier must be finite and nonnegative.");
        }

        private void ValidateBroadcast(Vector3 position, float baseRadius, bool isIndoor)
        {
            if (!IsFinite(position)) throw new System.ArgumentOutOfRangeException(nameof(position), "Noise position must be finite.");
            if (!IsFinite(baseRadius) || baseRadius < 0f)
                throw new System.ArgumentOutOfRangeException(nameof(baseRadius), "Noise radius must be finite and nonnegative.");
            ValidateSettings();
            if (isIndoor)
            {
                var portal = FindNearestPortal(position);
                if (portal != null && (!IsFinite(portal.RelayPoint) || !IsFinite(portal.OcclusionMultiplier) ||
                    portal.OcclusionMultiplier < 0f || portal.OcclusionMultiplier > 1f))
                    throw new System.InvalidOperationException("Acoustic portal relay point and attenuation must be finite and valid.");
            }
        }

        #endregion

        #region Gizmos

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (!_debugDrawGizmos) return;

            foreach (var noise in _recentNoises)
            {
                float age = Time.time - noise.Timestamp;
                float alpha = Mathf.Clamp01(1f - age / NOISE_EVENT_LIFETIME);

                Gizmos.color = GetNoiseColor(noise.Type, alpha);
                Gizmos.DrawWireSphere(noise.Position, noise.BaseRadius * noise.Intensity);

                if (noise.IsRelayed)
                {
                    Gizmos.color = Color.yellow * alpha;
                    Gizmos.DrawLine(noise.Position, noise.Position + Vector3.up * 2f);
                }
            }
        }

        private static Color GetNoiseColor(NoiseSourceType type, float alpha)
        {
            return type switch
            {
                NoiseSourceType.Footstep => new Color(0.5f, 0.8f, 0.5f, alpha * 0.3f),
                NoiseSourceType.Sprint => new Color(0.8f, 0.8f, 0.2f, alpha * 0.3f),
                NoiseSourceType.Looting => new Color(0.2f, 0.7f, 1f, alpha * 0.4f),
                NoiseSourceType.Reload => new Color(0.6f, 0.7f, 0.3f, alpha * 0.3f),
                NoiseSourceType.Throw => new Color(0.8f, 0.6f, 0.2f, alpha * 0.3f),
                NoiseSourceType.Misfire => new Color(1f, 0.8f, 0.2f, alpha * 0.3f),
                NoiseSourceType.Gunshot => new Color(1f, 0.2f, 0.1f, alpha * 0.5f),
                NoiseSourceType.Explosion => new Color(1f, 0.5f, 0f, alpha * 0.6f),
                NoiseSourceType.Shout => new Color(1f, 0.4f, 0.8f, alpha * 0.4f),
                NoiseSourceType.Speech => new Color(0.6f, 0.6f, 0.8f, alpha * 0.2f),
                _ => new Color(0.7f, 0.7f, 0.7f, alpha * 0.3f)
            };
        }
#endif

        #endregion
    }
}
