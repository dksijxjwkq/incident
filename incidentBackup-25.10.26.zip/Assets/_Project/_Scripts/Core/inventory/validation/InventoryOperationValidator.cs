using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
/// <summary>
/// ЕДИНСТВЕННАЯ read-only точка валидации операций swap и drop-into-backpack-icon.
/// Используется и DragHighlightController (обводка), и InventoryTransactionService
/// (pre-check перед исполнением). Расхождение highlight/транзакция исключено
/// конструктивно: оба вызывают одни и те же детерминированные методы.
///
/// Zero-alloc в hot-path: только static scratch-массив и struct'ы.
/// НЕ мутирует предметы (проверка поворота — через транспонирование размера).
/// </summary>
public static class InventoryOperationValidator
{
      private const int MaxGrid = 20; // совпадает с клампом InventoryData
    private static readonly bool[] _occ = new bool[MaxGrid * MaxGrid];
    // ═══ Bug A FIX: scratch-буфер для сортировки 3rd-party при симуляции
    // одновременного размещения. Zero-alloc: переиспользуется. ═══
    private static readonly List<InventoryItem> _thirdPartySortBuf = new List<InventoryItem>(8);
    private static bool IsUnfoldedBackpack(InventoryItem item) =>
        item != null && item.Data != null && item.Data.IsBackpack && !item.IsFolded;

    

public static bool TryResolveSwap(
    InventoryItem dragged,
    InventoryItem target,
    InventoryController targetCtrl,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    List<InventoryController> relocationCtrls,
    out int swapX, out int swapY,
    out string reason)
{
    var tRoot = targetCtrl != null && target != null
        ? targetCtrl.FindItemRootPosition(target.InstanceID)
        : (x: -1, y: -1);

    return TryResolveSwapPositions(dragged, target, targetCtrl, sourceCtrl,
        srcX, srcY, relocationCtrls, tRoot.x, tRoot.y,
        out swapX, out swapY, out _, out reason);
}

public static bool TryResolveSwapPositions(
    InventoryItem dragged,
    InventoryItem target,
    InventoryController targetCtrl,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    List<InventoryController> relocationCtrls,
    int anchorX, int anchorY,
    out int swapX, out int swapY,
    out int draggedRotation,
    out string reason)
{
    return TryResolveSwapPositions(
        dragged, target, targetCtrl, sourceCtrl, srcX, srcY,
        relocationCtrls, anchorX, anchorY,
        out swapX, out swapY, out draggedRotation, out reason,
        out _, out _, out _, null);
}

public static bool TryResolveSwapPositions(
    InventoryItem dragged,
    InventoryItem target,
    InventoryController targetCtrl,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    List<InventoryController> relocationCtrls,
    int anchorX, int anchorY,
    out int swapX, out int swapY,
    out int draggedRotation,
    out string reason,
    BackpackContainerManager backpackManager)
{
    return TryResolveSwapPositions(
        dragged, target, targetCtrl, sourceCtrl, srcX, srcY,
        relocationCtrls, anchorX, anchorY,
        out swapX, out swapY, out draggedRotation, out reason,
        out _, out _, out _, backpackManager);
}

// ═══ НОВАЯ 14-арг перегрузка: + targetPlaceX/Y/Rotation для случая B ═══
// Случай A (dragged.area >= target.area): существующая строгая семантика.
// Случай B (dragged.area < target.area): dragged → tRoot, target → любое
//   empty-only место в sourceCtrl (авто-поворот). Паритет highlight==transaction
//   обеспечивается тем, что ОБА вызывающих читают один результат.
// ═══ 14-арг перегрузка: + targetPlaceX/Y/Rotation для случая B ═══
// Случай A (dragged.area >= target.area): существующая строгая семантика.
// Случай B (dragged.area < target.area): dragged → clamp(anchor) внутрь
//   футпринта таргета, target → любое empty-only место в sourceCtrl.
//   Паритет highlight==transaction: ОБА вызывающих читают один результат.
// ═══════════════════════════════════════════════════════════════
//  TryResolveSwapPositions (14-arg overload)
//  R1: anchor — ЕДИНСТВЕННАЯ кандидатная позиция для grid-drag.
//  R2: на anchor — bounds, intersect-target, no 3rd-party, relocation.
//  R3: auto-rotate dragged УБРАН. draggedRotation = dragged.RotationAngle.
// ═══════════════════════════════════════════════════════════════
public static bool TryResolveSwapPositions(
    InventoryItem dragged,
    InventoryItem target,
    InventoryController targetCtrl,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    List<InventoryController> relocationCtrls,
    int anchorX, int anchorY,
    out int swapX, out int swapY,
    out int draggedRotation,
    out string reason,
    out int targetPlaceX, out int targetPlaceY, out int targetRotation,
    BackpackContainerManager backpackManager)
{
    swapX = anchorX;
    swapY = anchorY;
    draggedRotation = dragged?.RotationAngle ?? 0;
    targetPlaceX = targetPlaceY = -1;
    targetRotation = target?.RotationAngle ?? 0;
    reason = string.Empty;

    if (dragged == null || target == null || targetCtrl == null || sourceCtrl == null)
    { reason = "null refs"; return false; }
    if (ReferenceEquals(dragged, target))
    { reason = "same item"; return false; }
    if (IsUnfoldedBackpack(dragged))
    { reason = "Unfolded backpack cannot be swapped (dragged)"; return false; }
    if (IsUnfoldedBackpack(target))
    { reason = "Unfolded backpack cannot be swapped (target)"; return false; }

    var tRoot = targetCtrl.FindItemRootPosition(target.InstanceID);
    if (tRoot.x == -1)
    { reason = "target not found in controller"; return false; }

    InventoryValidationService.PrepareSnapshotsForValidation(dragged, target);
    if (!InventoryValidationService.NestingCheckBidirectional(dragged, target))
    { reason = "Nesting cycle: cannot swap backpack with its descendant"; return false; }

    var dSize = dragged.CurrentSize;
    if (dSize.x <= 0 || dSize.y <= 0)
    { reason = "dragged has zero size"; return false; }

    bool isCaseB = (dSize.x * dSize.y) < (target.CurrentSize.x * target.CurrentSize.y);
    bool sameGrid = ReferenceEquals(sourceCtrl, targetCtrl);

    int px, py, rot;

       // ── 1) Primary anchor (CaseB — clamp внутрь футпринта target) ──
    if (TryResolveCaseBAtAnchor(
            dragged, target, targetCtrl, sourceCtrl, tRoot, dSize,
            anchorX, anchorY, isCaseB, sameGrid,
            out px, out py, out rot,
            out reason,
            out int dragX, out int dragY))
    {
        swapX = dragX;
        swapY = dragY;
        draggedRotation = dragged.RotationAngle;
        targetPlaceX = px;
        targetPlaceY = py;
        targetRotation = rot;
        return true;
    }

    // reason уже заполнен неудачным вызовом
    return false;}

    // ── Fallback УДАЛЕН ──
    // Раньше здесь был цикл по соседним клеткам (r=1..2), из-за которого
    // обводка "прыгала" в соседнюю ячейку, чтобы стать зеленой, и ломался reason.
    // В инвентаре типа Tarkov preview должен быть жестко привязан к курсору:
    // если не влезает прямо здесь — swap невалиден, обводка красная.
    // reason уже корректно заполнен последним вызовом TryResolveCaseBAtAnchor.
    
  
private static bool TryResolveCaseBAtAnchor(
    InventoryItem dragged,
    InventoryItem target,
    InventoryController targetCtrl,
    InventoryController sourceCtrl,
    (int x, int y) tRoot,
    Vector2Int dSize,
    int anchorX, int anchorY,
    bool isCaseB,
    bool sameGrid,
    out int targetPlaceX, out int targetPlaceY, out int targetRotation,
    out string reason,
    out int dragPlaceX, out int dragPlaceY)
{
    targetPlaceX = targetPlaceY = -1;
    targetRotation = target?.RotationAngle ?? 0;
    reason = string.Empty;

    // ═══ R1 (исправлено): anchor — ЕДИНСТВЕННАЯ кандидатная позиция для
    // grid-drag. Никакого clamp в футпринт target: обводка обязана следовать
    // за курсором без магнитинга. Пересечение с target гарантируется тем, что
    // ResolveSnapTargets выбрал цель ИЗ оккупантов anchor-футпринта, а проверка
    // ниже (`intersectsTarget`) это подтверждает.
    // Паритет highlight↔transaction: возвращаем anchor как dragPlaceX/Y. ═══
    int cx = anchorX, cy = anchorY;
    dragPlaceX = cx;
    dragPlaceY = cy;

    // Bounds
    if (cx < 0 || cy < 0
        || cx + dSize.x > targetCtrl.Width
        || cy + dSize.y > targetCtrl.Height)
    { reason = "dragged does not fit at anchor (bounds)"; return false; }

    // Footprint пересекает target и НЕ содержит 3rd-party
    bool intersectsTarget = false;
    for (int dy = 0; dy < dSize.y; dy++)
    for (int dx = 0; dx < dSize.x; dx++)
    {
        var occ = targetCtrl.GetItemAt(cx + dx, cy + dy);
        if (occ == null) continue;
        if (ReferenceEquals(occ, dragged)) continue;
        if (ReferenceEquals(occ, target)) { intersectsTarget = true; continue; }
        reason = "3rd-party item in dragged footprint";
        return false;
    }
    if (!intersectsTarget)
    { reason = "dragged at anchor does not intersect target"; return false; }

    // CaseA: строгая семантика без clamp (cx,cy == anchor), только переменные переименованы
    if (!isCaseB)
    {
        RectInt freed = sourceCtrl.GetActualFootprint(dragged);
        if (freed.width <= 0 || freed.height <= 0)
        { reason = "dragged has no footprint in source controller"; return false; }
        if (freed.width * freed.height > _occ.Length)
        { reason = "freed footprint too large"; return false; }

        System.Array.Clear(_occ, 0, freed.width * freed.height);

        if (sameGrid)
        {
            RectInt draggedNewFPA = new RectInt(cx, cy, dSize.x, dSize.y);
            int ox0 = Mathf.Max(draggedNewFPA.x, freed.x);
            int oy0 = Mathf.Max(draggedNewFPA.y, freed.y);
            int ox1 = Mathf.Min(draggedNewFPA.x + draggedNewFPA.width,  freed.x + freed.width);
            int oy1 = Mathf.Min(draggedNewFPA.y + draggedNewFPA.height, freed.y + freed.height);
            for (int yy = oy0; yy < oy1; yy++)
            for (int xx = ox0; xx < ox1; xx++)
                _occ[(yy - freed.y) * freed.width + (xx - freed.x)] = true;
        }

        if (!TryFitTargetInFreed(sourceCtrl, target, dragged, freed, _occ,
                out targetPlaceX, out targetPlaceY, out targetRotation))
        { reason = "target does not fit in freed footprint"; return false; }
        return true;
    }

    // CaseB: target уходит в любое empty-only место source-грида,
    // не пересекая draggedNewFP (куда встанет dragged после swap'а).
    // Поиск идёт по ВСЕЙ source-сетке (ScanEmptyIgnoringItem),
    // т.е. «target остаётся без места» не может возникнуть из-за формы
    // draggedNewFP — clamp для этого больше не нужен.
    RectInt draggedNewFP = sameGrid
        ? new RectInt(cx, cy, dSize.x, dSize.y)
        : default;

    if (!TryFindEmptyPlacementIgnoring(
            sourceCtrl, target, dragged,
            avoidRectActive: sameGrid, avoidRect: draggedNewFP,
            out targetPlaceX, out targetPlaceY, out targetRotation))
    {
        reason = "no free space for target in source grid";
        return false;
    }
    return true;
}
private static bool TryFitTargetInFreed(
    InventoryController ctrl, InventoryItem item, InventoryItem dragged,
    RectInt freed, bool[] occ,
    out int px, out int py, out int rotationAngle)
{
    px = py = -1;
    rotationAngle = item?.RotationAngle ?? 0;
    if (ctrl == null || item == null || item.Data == null) return false;

    var size = item.CurrentSize;
    if (ScanFreedWithOcc(ctrl, item, dragged, freed, occ, size, out px, out py))
        return true;

    if (item.Data.CanRotate && size.x != size.y)
    {
        var rot = new Vector2Int(size.y, size.x);
        if (ScanFreedWithOcc(ctrl, item, dragged, freed, occ, rot, out px, out py))
        {
            rotationAngle = (item.RotationAngle == 0) ? -90 : 0;
            return true;
        }
    }
    return false;
}

private static bool ScanFreedWithOcc(
    InventoryController ctrl, InventoryItem item, InventoryItem dragged,
    RectInt freed, bool[] occ, Vector2Int size,
    out int px, out int py)
{
    px = py = -1;
    if (size.x <= 0 || size.y <= 0) return false;
    if (size.x > freed.width || size.y > freed.height) return false;
    int fw = freed.width;

    for (int y = 0; y <= freed.height - size.y; y++)
    {
        for (int x = 0; x <= freed.width - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
            for (int dx = 0; dx < size.x; dx++)
            {
                if (occ[(y + dy) * fw + (x + dx)]) { free = false; break; }

                int cx = freed.x + x + dx;
                int cy = freed.y + y + dy;
                var occupant = ctrl.GetItemAt(cx, cy);
                if (occupant != null
                    && !ReferenceEquals(occupant, dragged)
                    && !ReferenceEquals(occupant, item))
                { free = false; break; }
            }
            if (free) { px = freed.x + x; py = freed.y + y; return true; }
        }
    }
    return false;
}
private static bool TryFindEmptyPlacementIgnoring(
    InventoryController ctrl,
    InventoryItem item,
    InventoryItem ignored,
    bool avoidRectActive,
    RectInt avoidRect,
    out int px, out int py, out int rotationAngle)
{
    px = py = -1;
    rotationAngle = item?.RotationAngle ?? 0;
    if (ctrl == null || item == null || item.Data == null) return false;

    var size = item.CurrentSize;
    if (ScanEmptyIgnoringItem(ctrl, size, ignored, item, avoidRectActive, avoidRect, out px, out py))
        return true;

    if (item.Data.CanRotate && size.x != size.y)
    {
        var rot = new Vector2Int(size.y, size.x);
        if (ScanEmptyIgnoringItem(ctrl, rot, ignored, item, avoidRectActive, avoidRect, out px, out py))
        {
            rotationAngle = (item.RotationAngle == 0) ? -90 : 0;
            return true;
        }
    }
    return false;
}
private static bool ScanEmptyIgnoringItem(
    InventoryController ctrl,
    Vector2Int size,
    InventoryItem ignored,
    InventoryItem self,
    bool avoidRectActive,
    RectInt avoidRect,
    out int px, out int py)
{
    px = py = -1;
    if (ctrl == null) return false;
    if (size.x <= 0 || size.y <= 0) return false;
    if (size.x > ctrl.Width || size.y > ctrl.Height) return false;

    for (int y = 0; y <= ctrl.Height - size.y; y++)
    {
        for (int x = 0; x <= ctrl.Width - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    int cx = x + dx;
                    int cy = y + dy;

                    if (avoidRectActive &&
                        cx >= avoidRect.x && cy >= avoidRect.y &&
                        cx < avoidRect.x + avoidRect.width &&
                        cy < avoidRect.y + avoidRect.height)
                    {
                        free = false; break;
                    }

                    var occ = ctrl.GetItemAt(cx, cy);
                    if (occ == null) continue;
                    if (ReferenceEquals(occ, ignored)) continue;
                    if (ReferenceEquals(occ, self)) continue;
                    free = false; break;
                }
            }
            if (free) { px = x; py = y; return true; }
        }
    }
    return false;
}




// InventoryOperationValidator.cs — ПОЛНАЯ ЗАМЕНА ValidateDropIntoBackpack()
// БАГ 3: цель с открытым окном (live-контроллер) НЕ отклоняется по глубине.
public static bool ValidateDropIntoBackpack(
    InventoryItem item,
    InventoryItem targetBackpack,
    BackpackContainerManager backpacks,
    out string reason)
{
    reason = string.Empty;
    if (item == null || targetBackpack == null ||
        targetBackpack.Data == null || !targetBackpack.Data.IsBackpack)
    { reason = "Invalid target"; return false; }
    if (ReferenceEquals(item, targetBackpack))
    { reason = "Self drop"; return false; }
    if (targetBackpack.IsFolded && !targetBackpack.Data.AlwaysShowGrid)
    { reason = "Cannot drop into folded backpack"; return false; }
    if (!targetBackpack.HasInternalGrid)
    { reason = "Invalid target"; return false; }

    InventoryController live = backpacks != null
        ? backpacks.GetLiveController(targetBackpack.InstanceID.ToString())
        : null;

    if (backpacks != null)
    {
        // Лимит матрёшки для РАЗВЁРНУТОГО тащимого — единая точка правды. НЕ ТРОГАЕМ.
        if (IsUnfoldedBackpack(item))
        {
            if (!backpacks.CanPlaceUnfoldedBackpack(targetBackpack, item, out reason))
                return false;
        }
        // БАГ 3 ФИКС: глубина режет ТОЛЬКО когда окно цели закрыто (live == null).
        // Открытое окно = сетка физически доступна, item упадёт в live-контроллер.
        if (live == null)
        {
            int targetDepth = backpacks.GetNestingDepth(targetBackpack);
            if (targetDepth >= BackpackContainerManager.MaxOpenFloatingWindows)
            {
                reason = $"Целевой рюкзак на глубине {targetDepth} — физически недоступен " +
                         $"(лимит {BackpackContainerManager.MaxOpenFloatingWindows} переносные сетки).";
                return false;
            }
        }
    }

    if (item.Data != null && item.Data.IsBackpack)
    {
        InventoryValidationService.PrepareSnapshotsForValidation(item, targetBackpack);
        if (item.ContainsDescendantStrict(targetBackpack.InstanceID))
        { reason = "Nesting cycle: cannot drop backpack into its descendant"; return false; }
    }

    if (live != null)
        return FitEmptyAnywhere(live, item);
    return FitEmptyInSnapshot(targetBackpack.GetBackpackSavedItems(), targetBackpack.Data, item);
}
    
    private static bool FitEmptyAnywhere(InventoryController ctrl, InventoryItem item)
    {
        if (ctrl == null || item.Data == null) return false;
        var size = item.CurrentSize;
        if (ScanEmpty(ctrl, size)) return true;
        if (item.Data.CanRotate && size.x != size.y)
            return ScanEmpty(ctrl, new Vector2Int(size.y, size.x));
        return false;
    }

    private static bool ScanEmpty(InventoryController ctrl, Vector2Int size)
    {
        for (int y = 0; y <= ctrl.Height - size.y; y++)
        {
            for (int x = 0; x <= ctrl.Width - size.x; x++)
            {
                bool free = true;
                for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    if (ctrl.GetItemAt(x + dx, y + dy) != null) { free = false; break; }
                }
                if (free) return true;
            }
        }
        return false;
    }

    private static bool FitEmptyInSnapshot(
        List<SavedItem> saved, ItemStaticData targetData, InventoryItem item)
    {
        int w = targetData.BackpackWidth;
        int h = targetData.BackpackHeight;
        if (w <= 0 || h <= 0 || w > MaxGrid || h > MaxGrid) return false;
        if (item.Data == null) return false;

        System.Array.Clear(_occ, 0, w * h);
        if (saved != null)
        {
            var db = K_InventorySetup.DatabaseInstance;
            for (int i = 0; i < saved.Count; i++)
            {
                var s = saved[i];
                var d = db != null ? db.GetItemData(s.ItemID) : null;
                if (d == null) continue;
                var sz = SavedItemFootprint(s, d);
                for (int dy = 0; dy < sz.y; dy++)
                for (int dx = 0; dx < sz.x; dx++)
                {
                    int cx = s.X + dx, cy = s.Y + dy;
                    if (cx >= 0 && cy >= 0 && cx < w && cy < h)
                        _occ[cy * w + cx] = true;
                }
            }
        }

        var size = item.CurrentSize;
        if (ScanEmptySnapshot(w, h, size)) return true;
        if (item.Data.CanRotate && size.x != size.y)
            return ScanEmptySnapshot(w, h, new Vector2Int(size.y, size.x));
        return false;
    }

    private static bool ScanEmptySnapshot(int w, int h, Vector2Int size)
    {
        for (int y = 0; y <= h - size.y; y++)
        {
            for (int x = 0; x <= w - size.x; x++)
            {
                bool free = true;
                for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    if (_occ[(y + dy) * w + (x + dx)]) { free = false; break; }
                }
                if (free) return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Футпринт SavedItem в сетке рюкзака — зеркалит InventoryItem.CacheSizes:
    /// folded→SizeFolded, рюкзак→UnfoldedIconSize/BackpackW×H, иначе Size;
    /// IsRotated транспонирует. Без аллокации InventoryItem.
    /// </summary>
    private static Vector2Int SavedItemFootprint(SavedItem s, ItemStaticData d)
    {
        Vector2Int n;
        if (s.IsFolded && d.CanFold)
            n = d.SizeFolded;
        else if (d.IsBackpack && d.UnfoldedIconSize.x > 0 && d.UnfoldedIconSize.y > 0)
            n = d.UnfoldedIconSize;
        else if (d.IsBackpack && d.BackpackWidth > 0 && d.BackpackHeight > 0)
            n = new Vector2Int(d.BackpackWidth, d.BackpackHeight);
        else
            n = d.Size;
        return (s.IsRotated && d.CanRotate) ? new Vector2Int(n.y, n.x) : n;
    }
    // ═══════════════════════════════════════════════════════════
//  EQUIP SWAP: рюкзак на занятый слот рюкзака
// ═══════════════════════════════════════════════════════════

/// <summary>
/// Валидация свапа рюкзака через слот экипировки.
/// Вызывается И из DragHighlightController.HighlightEquipmentSlot,
/// И из InventoryTransactionService.TryEquipFromDrag.
///
/// Правила:
///   1. Тащимый НЕ должен быть потомком экипированного.
///   2. Старый экипированный рюкзак (развёрнутый) должен помещаться
///      в ИСХОДНУЮ сетку тащимого: родная клетка → скан с авто-поворотом.
///   3. Если не помещается — свап запрещён.
///
/// out placeX/placeY — позиция размещения старого рюкзака.
/// </summary>
public static bool TryResolveEquipSwap(
    InventoryItem draggedBackpack,
    InventoryItem equippedBackpack,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    out int placeX, out int placeY,
    out string reason)
{
    placeX = placeY = -1;
    reason = string.Empty;

    if (draggedBackpack == null || equippedBackpack == null || sourceCtrl == null)
    { reason = "null refs"; return false; }

    if (draggedBackpack.Data == null || !draggedBackpack.Data.IsBackpack)
    { reason = "dragged item is not a backpack"; return false; }

    if (equippedBackpack.Data == null || !equippedBackpack.Data.IsBackpack)
    { reason = "equipped item is not a backpack"; return false; }

    // УДАЛЕНА проверка IsUnfoldedBackpack(draggedBackpack)
    // Развёрнутый тащимый разрешён (спека п.4.4)

    // Цикл: тащимый не должен быть потомком экипированного и наоборот
    InventoryValidationService.PrepareSnapshotsForValidation(draggedBackpack, equippedBackpack);
    if (!InventoryValidationService.NestingCheckBidirectional(draggedBackpack, equippedBackpack))
    { reason = "Nesting cycle: dragged backpack is inside equipped backpack"; return false; }

    // Старый рюкзак будет размещён РАЗВЁРНУТЫМ. Его CurrentSize = развёрнутый.
    // Проверяем размещение в ИСХОДНОЙ сетке тащимого.

    // 1. Родная клетка тащимого (игнорируем тащимый — он будет удалён)
    var oldSize = equippedBackpack.CurrentSize;
    if (FitIgnoringExact(sourceCtrl, equippedBackpack, srcX, srcY, draggedBackpack))
    {
        placeX = srcX;
        placeY = srcY;
        return true;
    }

    // 2. Скан исходной сетки (текущая ориентация)
    if (ScanFreeIgnoringItem(sourceCtrl, oldSize, draggedBackpack, out placeX, out placeY))
        return true;

    // 3. Скан с авто-поворотом
    if (equippedBackpack.Data.CanRotate && oldSize.x != oldSize.y)
    {
        var rotSize = new Vector2Int(oldSize.y, oldSize.x);
        if (ScanFreeIgnoringItem(sourceCtrl, rotSize, draggedBackpack, out placeX, out placeY))
            return true;
    }

    reason = "No space for old equipped backpack in source grid";
    return false;
}
private static bool FitIgnoringExact(
    InventoryController ctrl, InventoryItem item, int x, int y, InventoryItem ignored)
{
    if (ctrl == null || item == null) return false;
    var size = item.CurrentSize;
    if (x < 0 || y < 0 || x + size.x > ctrl.Width || y + size.y > ctrl.Height)
        return false;
    for (int dy = 0; dy < size.y; dy++)
        for (int dx = 0; dx < size.x; dx++)
        {
            var occ = ctrl.GetItemAt(x + dx, y + dy);
            if (occ == null) continue;
            if (ReferenceEquals(occ, ignored)) continue;
            if (ReferenceEquals(occ, item)) continue;
            return false;
        }
    return true;
}

/// <summary>
/// Скан сетки на свободное место заданного размера, игнорируя один предмет.
/// Zero-alloc: только стеловые переменные.
/// </summary>
private static bool ScanFreeIgnoringItem(
    InventoryController ctrl, Vector2Int size, InventoryItem ignored,
    out int px, out int py)
{
    px = py = -1;
    if (ctrl == null || size.x <= 0 || size.y <= 0) return false;
    if (size.x > ctrl.Width || size.y > ctrl.Height) return false;

    for (int y = 0; y <= ctrl.Height - size.y; y++)
    {
        for (int x = 0; x <= ctrl.Width - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    var occ = ctrl.GetItemAt(x + dx, y + dy);
                    if (occ != null && !ReferenceEquals(occ, ignored))
                    { free = false; break; }
                }
            if (free) { px = x; py = y; return true; }
        }
    }
    return false;
}

// ═══════════════════════════════════════════════════════════
//  DROP INTO EQUIPPED BACKPACK: обычный предмет → сетка экипированного
// ═══════════════════════════════════════════════════════════

/// <summary>
/// Валидация дропа ОБЫЧНОГО предмета (не рюкзак) в сетку экипированного рюкзака.
/// Empty-only скан с авто-поворотом — зеркалирует логику размещения.
///
/// Вызывается И из DragHighlightController.HighlightEquipmentSlot,
/// И из InventoryTransactionService.TryDropIntoEquippedBackpack.
/// </summary>
public static bool ValidateDropIntoEquippedBackpack(
    InventoryItem item,
    InventoryController backpackCtrl,
    out int placeX, out int placeY,
    out string reason)
{
    placeX = placeY = -1;
    reason = string.Empty;

    if (item == null || backpackCtrl == null)
    { reason = "null refs"; return false; }

    if (item.Data == null)
    { reason = "invalid item"; return false; }

    // Рюкзаки не идут по этому пути — для них TryResolveEquipSwap
    if (item.Data.IsBackpack)
    { reason = "backpack items use equip swap path"; return false; }

    var size = item.CurrentSize;

    // Скан текущей ориентации
    if (ScanEmptyWithPosition(backpackCtrl, size, out placeX, out placeY))
        return true;

    // Авто-поворот
    if (item.Data.CanRotate && size.x != size.y)
    {
        if (ScanEmptyWithPosition(backpackCtrl, new Vector2Int(size.y, size.x), out placeX, out placeY))
            return true;
    }

    reason = "No free space in equipped backpack";
    return false;
}

/// <summary>
/// Empty-only скан с возвратом позиции. Zero-alloc.
/// </summary>
private static bool ScanEmptyWithPosition(
    InventoryController ctrl, Vector2Int size, out int px, out int py)
{
    px = py = -1;
    if (ctrl == null || size.x <= 0 || size.y <= 0) return false;
    if (size.x > ctrl.Width || size.y > ctrl.Height) return false;

    for (int y = 0; y <= ctrl.Height - size.y; y++)
    {
        for (int x = 0; x <= ctrl.Width - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    if (ctrl.GetItemAt(x + dx, y + dy) != null)
                    { free = false; break; }
                }
            if (free) { px = x; py = y; return true; }
        }
    }
    return false;
}
// ═══════════════════════════════════════════════════════════════
//  EQUIPMENT → GRID SWAP
//  Dragged предмет берётся из equipment slot (source — не grid).
//  Целевой item уходит в этот же слот. Dragged занимает футпринт
//  target'а в grid'е с авто-поворотом; 3rd-party items должны
//  разместиться в relocationCtrls.
//
//  Возвращает: placeX/placeY — куда встанет dragged после swap'а;
//              draggedRotation — целевой угол (0 или -90);
//              reason — при отказе.
// ═══════════════════════════════════════════════════════════════
public static bool TryResolveEquipmentGridSwap(
    InventoryItem draggedFromSlot,
    InventoryItem targetInGrid,
    InventoryController targetCtrl,
    int anchorX, int anchorY,
    List<InventoryController> relocationCtrls,
    BackpackContainerManager backpackManager,
    out int placeX, out int placeY,
    out int draggedRotation,
    out string reason)
{
    placeX = placeY = -1;
    draggedRotation = draggedFromSlot?.RotationAngle ?? 0;
    reason = string.Empty;

    if (draggedFromSlot == null || targetInGrid == null || targetCtrl == null)
    { reason = "null refs"; return false; }
    if (ReferenceEquals(draggedFromSlot, targetInGrid))
    { reason = "same item"; return false; }

    var tRoot = targetCtrl.FindItemRootPosition(targetInGrid.InstanceID);
    if (tRoot.x == -1)
    { reason = "target not found in controller"; return false; }

    InventoryValidationService.PrepareSnapshotsForValidation(draggedFromSlot, targetInGrid);
    if (!InventoryValidationService.NestingCheckBidirectional(draggedFromSlot, targetInGrid))
    { reason = "Nesting cycle: cannot swap backpack with its descendant"; return false; }

#if UNITY_EDITOR
    Debug.Log($"[VLD-EQSWAP] enter: anchor=({anchorX},{anchorY}) " +
              $"dragged id={draggedFromSlot.InstanceID} " +
              $"size=({draggedFromSlot.CurrentSize.x}x{draggedFromSlot.CurrentSize.y}) " +
              $"rot={draggedFromSlot.RotationAngle} " +
              $"target id={targetInGrid.InstanceID} " +
              $"size=({targetInGrid.CurrentSize.x}x{targetInGrid.CurrentSize.y}) " +
              $"tRoot=({tRoot.x},{tRoot.y})");
#endif

    // Текущая ориентация.
    var s = draggedFromSlot.CurrentSize;
    if (TryFindEquipmentGridPlacement(
            draggedFromSlot, targetInGrid, targetCtrl, tRoot, s,
            anchorX, anchorY, relocationCtrls, backpackManager,
            out placeX, out placeY))
    {
        draggedRotation = draggedFromSlot.RotationAngle;
#if UNITY_EDITOR
        Debug.Log($"[VLD-EQSWAP] accepted (current orientation): " +
                  $"swap=({placeX},{placeY}) rot={draggedRotation} " +
                  $"size=({s.x}x{s.y})");
#endif
        return true;
    }

    // Auto-rotate dragged.
    if (draggedFromSlot.Data != null && draggedFromSlot.Data.CanRotate && s.x != s.y)
    {
        var sRot = new Vector2Int(s.y, s.x);
        if (TryFindEquipmentGridPlacement(
                draggedFromSlot, targetInGrid, targetCtrl, tRoot, sRot,
                anchorX, anchorY, relocationCtrls, backpackManager,
                out placeX, out placeY))
        {
            draggedRotation = (draggedFromSlot.RotationAngle == 0) ? -90 : 0;
#if UNITY_EDITOR
            Debug.Log($"[VLD-EQSWAP] accepted (auto-rotated): " +
                      $"swap=({placeX},{placeY}) rot={draggedRotation} " +
                      $"size=({sRot.x}x{sRot.y})");
#endif
            return true;
        }
    }

    reason = "no feasible equipment→grid swap placement";
#if UNITY_EDITOR
    Debug.Log($"[VLD-EQSWAP] rejected: reason='{reason}'");
#endif
    return false;
}
private static bool TryFindEquipmentGridPlacement(
    InventoryItem dragged, InventoryItem target, InventoryController targetCtrl,
    (int x, int y) tRoot, Vector2Int s,
    int anchorX, int anchorY,
    List<InventoryController> relocationCtrls,
    BackpackContainerManager backpackManager,
    out int placeX, out int placeY)
{
    placeX = placeY = -1;
    if (targetCtrl == null || s.x <= 0 || s.y <= 0) return false;

    // Диапазон позиций: dragged должен НАКРЫТЬ хотя бы одну клетку target'а.
    int minX = Mathf.Max(0, tRoot.x - s.x + 1);
    int maxX = Mathf.Min(targetCtrl.Width - s.x, tRoot.x + target.CurrentSize.x - 1);
    int minY = Mathf.Max(0, tRoot.y - s.y + 1);
    int maxY = Mathf.Min(targetCtrl.Height - s.y, tRoot.y + target.CurrentSize.y - 1);

    if (minX > maxX || minY > maxY) return false;

    var thirdParty = new List<InventoryItem>(4);
    int bestDist = int.MaxValue;

    for (int y = minY; y <= maxY; y++)
    {
        for (int x = minX; x <= maxX; x++)
        {
            thirdParty.Clear();
            bool hasTarget = false;
            bool invalid = false;

            for (int dy = 0; dy < s.y && !invalid; dy++)
            for (int dx = 0; dx < s.x; dx++)
            {
                var occ = targetCtrl.GetItemAt(x + dx, y + dy);
                if (occ == null) continue;
                if (ReferenceEquals(occ, dragged)) continue;
                if (IsUnfoldedBackpack(occ)) { invalid = true; break; }
                if (ReferenceEquals(occ, target)) { hasTarget = true; continue; }
                if (!thirdParty.Contains(occ)) thirdParty.Add(occ);
            }
            if (invalid || !hasTarget) continue;

            RectInt draggedNewFP = new RectInt(x, y, s.x, s.y);

            // ═══ Bug A FIX: СИМУЛЯЦИЯ всех 3rd-party ОДНОВРЕМЕННО.
            // Раньше каждый 3rd-party проверялся независимо,
            // из-за чего два предмета, конкурирующие за одну свободную клетку,
            // оба «помещались» в валидаторе → highlight синий, а транзакция
            // падала в TryPlaceItemInAnyPlayerGrid → Rollback. ═══
            if (!CanRelocateAllThirdPartiesSimultaneously(
                    thirdParty, targetCtrl, dragged, target,
                    draggedNewFP, relocationCtrls))
            {
#if UNITY_EDITOR
                Debug.Log($"[VLD-EQSWAP] candidate ({x},{y}) rejected: " +
                          $"3rdPartySim failed (count={thirdParty.Count})");
#endif
                continue;
            }

            int d = Mathf.Abs(x - anchorX) + Mathf.Abs(y - anchorY);
            if (d < bestDist)
            {
                bestDist = d;
                placeX = x;
                placeY = y;
            }
        }
    }

#if UNITY_EDITOR
    if (bestDist == int.MaxValue)
        Debug.Log($"[VLD-EQSWAP] no candidate: anchor=({anchorX},{anchorY}) " +
                  $"tRoot=({tRoot.x},{tRoot.y}) " +
                  $"draggedSize=({s.x}x{s.y}) " +
                  $"targetSize=({target.CurrentSize.x}x{target.CurrentSize.y})");
#endif

    return bestDist != int.MaxValue;
}

/// <summary>
/// Симуляция одновременного размещения ВСЕХ 3rd-party.
///
/// Клетки targetCtrl, занятые в момент проверки (кроме dragged/target/самих
/// 3rd-party), помечаются в статическом `_occ`. Клетки newFP dragged также
/// помечаются. Затем 3rd-party сортируются по площади desc и раскладываются
/// по одной: либо в bitmap (реальный targetCtrl), либо в relocationCtrls
/// (empty-only). Если хотя бы одна не размещается — false.
///
/// Zero-alloc: `_occ` (MaxGrid×MaxGrid) и `_thirdPartySortBuf` статические.
/// </summary>
private static bool CanRelocateAllThirdPartiesSimultaneously(
    List<InventoryItem> thirdParty,
    InventoryController targetCtrl,
    InventoryItem dragged,
    InventoryItem target,
    RectInt avoidRect,
    List<InventoryController> relocationCtrls)
{
    if (thirdParty == null || thirdParty.Count == 0) return true;
    if (targetCtrl == null) return false;

    int w = targetCtrl.Width;
    int h = targetCtrl.Height;
    if (w <= 0 || h <= 0 || w * h > _occ.Length) return false;

    // 1) Занятые клетки — все живые предметы, КРОМЕ dragged/target/3rd-party.
    System.Array.Clear(_occ, 0, w * h);
    for (int y = 0; y < h; y++)
    for (int x = 0; x < w; x++)
    {
        var occ = targetCtrl.GetItemAt(x, y);
        if (occ == null) continue;
        if (ReferenceEquals(occ, dragged)) continue;
        if (ReferenceEquals(occ, target)) continue;
        if (thirdParty.Contains(occ)) continue;
        _occ[y * w + x] = true;
    }

    // 2) Клетки newFP dragged — после swap'а там будет dragged.
    int ax0 = Mathf.Max(avoidRect.x, 0);
    int ax1 = Mathf.Min(avoidRect.x + avoidRect.width, w);
    int ay0 = Mathf.Max(avoidRect.y, 0);
    int ay1 = Mathf.Min(avoidRect.y + avoidRect.height, h);
    for (int yy = ay0; yy < ay1; yy++)
        for (int xx = ax0; xx < ax1; xx++)
            _occ[yy * w + xx] = true;

    // 3) Сортировка по площади desc (крупные сначала).
    _thirdPartySortBuf.Clear();
    for (int i = 0; i < thirdParty.Count; i++)
        _thirdPartySortBuf.Add(thirdParty[i]);
    _thirdPartySortBuf.Sort((a, b) =>
    {
        int areaA = a.CurrentSize.x * a.CurrentSize.y;
        int areaB = b.CurrentSize.x * b.CurrentSize.y;
        return areaB.CompareTo(areaA);
    });

    // 4) Раскладка по одной.
    for (int i = 0; i < _thirdPartySortBuf.Count; i++)
    {
        var item = _thirdPartySortBuf[i];
        if (item == null || item.Data == null) return false;

        var size = item.CurrentSize;
        bool placed = TryPlaceInOccBitmap(w, h, size, out _, out _);

        if (!placed && item.Data.CanRotate && size.x != size.y)
        {
            var rot = new Vector2Int(size.y, size.x);
            placed = TryPlaceInOccBitmap(w, h, rot, out _, out _);
        }

        if (!placed && relocationCtrls != null)
        {
            for (int j = 0; j < relocationCtrls.Count; j++)
            {
                var ctrl = relocationCtrls[j];
                if (ctrl == null || ctrl == targetCtrl) continue;

                if (ScanEmptyIgnoringItem(ctrl, item.CurrentSize, null, item,
                                          false, default, out _, out _))
                { placed = true; break; }

                if (item.Data.CanRotate && item.CurrentSize.x != item.CurrentSize.y)
                {
                    var rot = new Vector2Int(item.CurrentSize.y, item.CurrentSize.x);
                    if (ScanEmptyIgnoringItem(ctrl, rot, null, item,
                                              false, default, out _, out _))
                    { placed = true; break; }
                }
            }
        }

        if (!placed) return false;
    }
    return true;
}

/// <summary>
/// Пытается разместить прямоугольник size в bitmap `_occ` (w×h).
/// При успехе помечает клетки занятыми и возвращает top-left в (px,py).
/// Zero-alloc: только локальные переменные.
/// </summary>
private static bool TryPlaceInOccBitmap(
    int w, int h, Vector2Int size,
    out int px, out int py)
{
    px = py = -1;
    if (size.x <= 0 || size.y <= 0) return false;
    if (size.x > w || size.y > h) return false;

    for (int y = 0; y <= h - size.y; y++)
    {
        for (int x = 0; x <= w - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
            for (int dx = 0; dx < size.x; dx++)
            {
                if (_occ[(y + dy) * w + (x + dx)]) { free = false; break; }
            }
            if (!free) continue;

            for (int dy = 0; dy < size.y; dy++)
            for (int dx = 0; dx < size.x; dx++)
                _occ[(y + dy) * w + (x + dx)] = true;

            px = x;
            py = y;
            return true;
        }
    }
    return false;
}

// ═══════════════════════════════════════════════════════════
//  EQUIP SLOT SWAP: универсальный grid→slot swap (любой тип)
//  Displaced item (equipped) обязан поместиться в РЕАЛЬНЫЙ
//  freed-footprint dragged в sourceCtrl с авто-поворотом.
//  Zero-alloc, read-only. Используется и highlight, и transaction.
// ═══════════════════════════════════════════════════════════
public static bool TryResolveEquipSlotSwap(
    InventoryItem dragged,
    InventoryItem equipped,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    out int placeX, out int placeY, out int placeRotation,
    out string reason)
{
    placeX = placeY = -1;
    placeRotation = equipped?.RotationAngle ?? 0;
    reason = string.Empty;

    if (dragged == null || equipped == null || sourceCtrl == null)
    { reason = "null refs"; return false; }
    if (ReferenceEquals(dragged, equipped))
    { reason = "same item"; return false; }

    // Cycle pre-check (безопасно для любых типов; для не-рюкзаков тривиально true).
    InventoryValidationService.PrepareSnapshotsForValidation(dragged, equipped);
    if (!InventoryValidationService.NestingCheckBidirectional(dragged, equipped))
    { reason = "nesting cycle"; return false; }

    // РЕАЛЬНЫЙ footprint dragged в sourceCtrl — что освободится после RemoveItem.
    RectInt freed = sourceCtrl.GetActualFootprint(dragged);
    if (freed.width <= 0 || freed.height <= 0)
    { reason = "dragged has no footprint in source controller"; return false; }

    if (TryFitInFreed(sourceCtrl, equipped, dragged, freed,
                      out placeX, out placeY, out placeRotation))
        return true;

    reason = "equipped item does not fit in freed footprint (even with auto-rotate)";
    return false;
}

private static bool TryFitInFreed(
    InventoryController ctrl, InventoryItem item, InventoryItem ignored,
    RectInt freed,
    out int px, out int py, out int rotation)
{
    px = py = -1;
    rotation = item?.RotationAngle ?? 0;
    if (item == null || item.Data == null) return false;

    if (TryFitOneOrientationInFreed(ctrl, item, ignored, freed, item.CurrentSize, out px, out py))
        return true;

    if (item.Data.CanRotate && item.CurrentSize.x != item.CurrentSize.y)
    {
        var rot = new Vector2Int(item.CurrentSize.y, item.CurrentSize.x);
        if (TryFitOneOrientationInFreed(ctrl, item, ignored, freed, rot, out px, out py))
        {
            rotation = (item.RotationAngle == 0) ? -90 : 0;
            return true;
        }
    }
    return false;
}

private static bool TryFitOneOrientationInFreed(
    InventoryController ctrl, InventoryItem item, InventoryItem ignored,
    RectInt freed, Vector2Int size,
    out int px, out int py)
{
    px = py = -1;
    if (size.x <= 0 || size.y <= 0) return false;
    if (size.x > freed.width || size.y > freed.height) return false;

    for (int y = 0; y <= freed.height - size.y; y++)
    {
        for (int x = 0; x <= freed.width - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    int cx = freed.x + x + dx;
                    int cy = freed.y + y + dy;
                    if (cx < 0 || cy < 0 || cx >= ctrl.Width || cy >= ctrl.Height)
                    { free = false; break; }

                    var occ = ctrl.GetItemAt(cx, cy);
                    if (occ == null) continue;
                    if (ReferenceEquals(occ, ignored)) continue;
                    if (ReferenceEquals(occ, item)) continue;
                    free = false; break;
                }
            }
            if (free) { px = freed.x + x; py = freed.y + y; return true; }
        }
    }
    return false;
}

    public static bool TryResolveEquipmentGridSwapPlan(
        InventoryItem dragged, InventoryItem target, InventoryController controller,
        int anchorX, int anchorY, List<InventoryController> relocationControllers,
        BackpackContainerManager backpackManager, out int placeX, out int placeY,
        out int rotation, out string reason, out EquipmentGridSwapPlan plan)
    {
        bool result = EquipmentGridSwapPlanner.TryResolve(dragged, target, controller,
            anchorX, anchorY, relocationControllers, out plan, out reason);
        placeX = plan != null ? plan.X : -1;
        placeY = plan != null ? plan.Y : -1;
        rotation = plan != null ? plan.Rotation : dragged?.RotationAngle ?? 0;
        return result;
    }
}
}
