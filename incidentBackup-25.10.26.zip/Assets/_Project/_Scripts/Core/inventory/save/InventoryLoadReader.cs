using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace K_Incident.Core.Inventory
{
    /// <summary>Pure bounded parser for the existing inventory/equipment byte layout.</summary>
    public static partial class InventoryLoadReader
    {
        public const int MaximumGridSize = 20;
        public const int MaximumDepth = 32;
        public const int MaximumItems = 100000;
        public const int MaximumIdentifierBytes = 512;
        private const int MinimumSavedItemBytes = 35;
        private static readonly Encoding StrictUtf8 = new UTF8Encoding(false, true);

        public sealed class InventoryDto
        {
            public readonly int Width;
            public readonly int Height;
            public readonly List<SavedItem> Items;

            internal InventoryDto(int width, int height, List<SavedItem> items)
            { Width = width; Height = height; Items = items; }
        }

        public sealed class ControllerDto
        {
            public readonly string SaveID;
            public readonly bool WasDirty;
            public readonly InventoryDto Inventory;

            internal ControllerDto(string saveID, bool wasDirty, InventoryDto inventory)
            { SaveID = saveID; WasDirty = wasDirty; Inventory = inventory; }
        }

        public static ControllerDto ReadController(BinaryReader reader)
        {
            RequireReader(reader);
            string saveID = ReadIdentifier(reader);
            bool wasDirty = ReadBoolean(reader);
            return new ControllerDto(saveID, wasDirty, ReadInventory(reader));
        }

        /// <summary>Reads only; does not allocate IDs or alter any live inventory state.</summary>
        public static InventoryDto ReadInventory(BinaryReader reader)
        {
            RequireReader(reader);
            int width = reader.ReadInt32();
            int height = reader.ReadInt32();
            if (width < 1 || height < 1 || width > MaximumGridSize || height > MaximumGridSize)
                throw new InvalidDataException("Inventory dimensions are outside 1..20.");
            int remaining = MaximumItems;
            int count = ReadCount(reader, Math.Min(width * height, remaining));
            var ids = new HashSet<uint>();
            var items = new List<SavedItem>(count);
            for (int i = 0; i < count; i++)
            {
                var item = ReadItem(reader, 0, true, ref remaining, ids);
                if (item.X >= width || item.Y >= height)
                    throw new InvalidDataException("Inventory root is outside its grid.");
                items.Add(item);
            }
            return new InventoryDto(width, height, items);
        }

        /// <summary>Validates the complete controller record before its live caches are cleared.</summary>
        public static void ValidateControllerAndRewind(BinaryReader reader)
        {
            RequireSeekable(reader);
            long start = reader.BaseStream.Position;
            try
            {
                ReadController(reader);
            }
            finally { reader.BaseStream.Position = start; }
        }

        /// <summary>Parses every slot before the existing equipment loader removes its first owner.</summary>
        public static SavedItem?[] ReadEquipment(BinaryReader reader, int saveVersion, int schemaRevision)
        {
            RequireReader(reader);
            int slotCount = saveVersion >= 2 ? 7 : 5;
            var slots = new SavedItem?[slotCount];
            var ids = new HashSet<uint>();
            int remaining = MaximumItems;
            for (int i = 0; i < slotCount; i++)
            {
                int present = reader.ReadInt32();
                if (present == 0) continue;
                if (present != 1) throw new InvalidDataException("Equipment slot marker must be 0 or 1.");
                slots[i] = ReadEquipmentItem(reader, 0, saveVersion >= 2, schemaRevision >= 5,
                    ref remaining, ids);
            }
            return slots;
        }

        public static void ValidateEquipmentAndRewind(BinaryReader reader, int saveVersion, int schemaRevision)
        {
            RequireSeekable(reader);
            long start = reader.BaseStream.Position;
            try { ReadEquipment(reader, saveVersion, schemaRevision); }
            finally { reader.BaseStream.Position = start; }
        }

        private static SavedItem ReadItem(BinaryReader reader, int depth, bool hasCharge,
            ref int remaining, HashSet<uint> ids)
        {
            return ReadEquipmentItem(reader, depth, true, hasCharge, ref remaining, ids);
        }

        private static SavedItem ReadEquipmentItem(BinaryReader reader, int depth, bool hasCoordinates,
            bool hasCharge, ref int remaining, HashSet<uint> ids)
        {
            if (depth > MaximumDepth || remaining <= 0)
                throw new InvalidDataException("Inventory tree exceeds depth/item limits.");
            remaining--;
            var item = new SavedItem
            {
                ItemID = ReadIdentifier(reader),
                InstanceID = reader.ReadUInt32(),
                X = hasCoordinates ? reader.ReadInt32() : 0,
                Y = hasCoordinates ? reader.ReadInt32() : 0,
                Quantity = reader.ReadInt32(),
                Durability = reader.ReadInt32(),
                IsRotated = ReadBoolean(reader),
                IsFolded = ReadBoolean(reader),
                ChargePercent = hasCharge ? reader.ReadInt32() : 100,
                RemainingChargeSeconds = hasCharge ? reader.ReadSingle() : -1f
            };
            if (item.InstanceID == 0 || item.InstanceID == uint.MaxValue || !ids.Add(item.InstanceID))
                throw new InvalidDataException("Inventory tree has an invalid or duplicate instance ID.");
            if (item.X < 0 || item.Y < 0 || item.X >= MaximumGridSize || item.Y >= MaximumGridSize ||
                item.Quantity < 1 || item.Durability < 0 || item.ChargePercent < 0 || item.ChargePercent > 100)
                throw new InvalidDataException("Inventory item has invalid coordinates/quantity/durability/charge.");
            float seconds = item.RemainingChargeSeconds;
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) ||
                (seconds < 0f && seconds != -1f) || (hasCharge && seconds == 0f && item.ChargePercent > 0))
                throw new InvalidDataException("Inventory item has invalid exact charge duration.");

            int count = ReadCount(reader, remaining, hasCoordinates, hasCharge);
            if (count > 0)
            {
                // Reject the next depth before allocating a child collection or recursing.
                if (depth >= MaximumDepth)
                    throw new InvalidDataException("Inventory tree exceeds the maximum depth.");
                item.BackpackContents = new List<SavedItem>(count);
                for (int i = 0; i < count; i++)
                    item.BackpackContents.Add(ReadEquipmentItem(reader, depth + 1, hasCoordinates,
                        hasCharge, ref remaining, ids));
            }
            return item;
        }

        private static int ReadCount(BinaryReader reader, int remaining,
            bool hasCoordinates = true, bool hasCharge = true)
        {
            int count = reader.ReadInt32();
            if (count < 0 || count > remaining)
                throw new InvalidDataException("Inventory item count exceeds its remaining budget.");
            int minimum = MinimumSavedItemBytes - (hasCoordinates ? 0 : 8) - (hasCharge ? 0 : 8);
            if (reader.BaseStream.CanSeek && count >
                (reader.BaseStream.Length - reader.BaseStream.Position) / minimum)
                throw new InvalidDataException("Inventory item count exceeds the remaining payload.");
            return count;
        }

        private static bool ReadBoolean(BinaryReader reader)
        {
            byte value = reader.ReadByte();
            if (value > 1) throw new InvalidDataException("Invalid serialized boolean.");
            return value != 0;
        }

        private static string ReadIdentifier(BinaryReader reader)
        {
            uint length = 0;
            for (int index = 0; index < 5; index++)
            {
                byte value = reader.ReadByte();
                if (index == 4 && value > 0x0f)
                    throw new InvalidDataException("Invalid string length prefix.");
                length |= (uint)(value & 0x7f) << (index * 7);
                if ((value & 0x80) != 0) continue;
                if (length == 0 || length > MaximumIdentifierBytes)
                    throw new InvalidDataException("Inventory identifier length exceeds its limit.");
                if (reader.BaseStream.CanSeek && length >
                    reader.BaseStream.Length - reader.BaseStream.Position)
                    throw new EndOfStreamException("Truncated inventory identifier.");
                byte[] bytes = reader.ReadBytes((int)length);
                if (bytes.Length != length) throw new EndOfStreamException("Truncated inventory identifier.");
                try { return StrictUtf8.GetString(bytes); }
                catch (DecoderFallbackException ex) { throw new InvalidDataException("Invalid identifier UTF-8.", ex); }
            }
            throw new InvalidDataException("Invalid string length prefix.");
        }

        private static void RequireReader(BinaryReader reader)
        {
            if (reader == null) throw new ArgumentNullException(nameof(reader));
        }

        private static void RequireSeekable(BinaryReader reader)
        {
            RequireReader(reader);
            if (!reader.BaseStream.CanSeek)
                throw new InvalidDataException("Inventory preflight requires a seekable save payload.");
        }
    }
}
