using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public static partial class InventoryLoadReader
    {
        /// <summary>Validates templates and empty-only geometry without creating live items or IDs.</summary>
        public static void ValidateTree(IReadOnlyList<SavedItem> items, int width, int height,
            ItemDatabase database, SaveLoadValidationContext context, string source,
            bool registerOwnership = true)
        {
            int remaining = MaximumItems;
            ValidateGridCore(items, width, height, database, context, source, registerOwnership, 0, ref remaining);
        }

        private static void ValidateGridCore(IReadOnlyList<SavedItem> items, int width, int height,
            ItemDatabase database, SaveLoadValidationContext context, string source,
            bool registerOwnership, int depth, ref int remaining, bool transientGroundRoot = false)
        {
            if (database == null) throw new InvalidDataException("Inventory load requires its item database.");
            if (width < 1 || height < 1 || width > MaximumGridSize ||
                (!transientGroundRoot && height > MaximumGridSize) ||
                (long)width * height > (long)MaximumItems * MaximumGridSize * MaximumGridSize)
                throw new InvalidDataException("Inventory grid is outside supported bounds.");
            var occupied = new bool[width, height];
            if (items == null) return;
            foreach (var item in items)
            {
                var template = ValidateItemCore(item, database, context, source, registerOwnership, depth, ref remaining);
                Vector2Int size;
                if (item.IsFolded && template.CanFold) size = template.SizeFolded;
                else if (template.IsBackpack && template.UnfoldedIconSize.x > 0 && template.UnfoldedIconSize.y > 0)
                    size = template.UnfoldedIconSize;
                else if (template.IsBackpack && template.BackpackWidth > 0 && template.BackpackHeight > 0)
                    size = new Vector2Int(template.BackpackWidth, template.BackpackHeight);
                else size = template.Size;
                if (item.IsRotated) size = new Vector2Int(size.y, size.x);
                if (size.x < 1 || size.y < 1 || item.X < 0 || item.Y < 0 ||
                    item.X > width - size.x || item.Y > height - size.y)
                    throw new InvalidDataException($"Item {item.InstanceID} does not fit in '{source}'.");
                for (int y = item.Y; y < item.Y + size.y; y++)
                    for (int x = item.X; x < item.X + size.x; x++)
                    {
                        if (occupied[x, y]) throw new InvalidDataException($"Overlapping items in '{source}'.");
                        occupied[x, y] = true;
                    }
            }
        }

        public static void ValidateTransientGroundGrid(IReadOnlyList<SavedItem> items, int width, int height,
            ItemDatabase database, SaveLoadValidationContext context)
        {
            int remaining = MaximumItems;
            ValidateGridCore(items, width, height, database, context, "WorldLoot_Transient",
                true, 0, ref remaining, true);
        }

        public static ItemStaticData ValidateItemTree(SavedItem item, ItemDatabase database,
            SaveLoadValidationContext context, string source, bool registerOwnership = true)
        {
            int remaining = MaximumItems;
            return ValidateItemCore(item, database, context, source, registerOwnership, 0, ref remaining);
        }

        private static ItemStaticData ValidateItemCore(SavedItem item, ItemDatabase database,
            SaveLoadValidationContext context, string source, bool registerOwnership, int depth, ref int remaining)
        {
            if (depth > MaximumDepth || remaining-- <= 0)
                throw new InvalidDataException("Inventory contents exceed validation depth/item limits.");
            if (database == null) throw new InvalidDataException("Inventory load requires its item database.");
            var template = database.GetItemData(item.ItemID);
            if (template == null) throw new InvalidDataException($"Missing item template '{item.ItemID}'.");
            if (!InventoryGridBounds.IsValidBackpack(template))
                throw new InvalidDataException("Backpack dimensions must be between 1 and 20.");
            if (item.Quantity < 1 || item.Quantity > template.HardStackLimit)
                throw new InvalidDataException($"Item {item.InstanceID} exceeds its hard stack limit.");
            if (item.Durability < 0 || item.Durability > template.MaxDurability)
                throw new InvalidDataException($"Invalid durability for item {item.InstanceID}.");
            if (item.IsRotated && !template.CanRotate)
                throw new InvalidDataException($"Item {item.InstanceID} cannot be rotated.");
            if (item.IsFolded && !template.IsBackpack)
                throw new InvalidDataException($"Non-backpack {item.InstanceID} cannot be folded.");
            if (item.IsFolded && !template.CanFold)
                throw new InvalidDataException($"Item {item.InstanceID} cannot be folded.");
            if (registerOwnership) context.Own(item.InstanceID, source);
            if (item.BackpackContents != null && item.BackpackContents.Count > 0)
            {
                if (!template.IsBackpack)
                    throw new InvalidDataException($"Non-backpack {item.InstanceID} contains inventory items.");
                ValidateGridCore(item.BackpackContents, template.BackpackWidth, template.BackpackHeight,
                    database, context, source + "/" + item.InstanceID, registerOwnership, depth + 1, ref remaining);
            }
            return template;
        }

        /// <summary>Order-independent exact signature for the legacy worn-backpack projection alias.</summary>
        public static string Fingerprint(IReadOnlyList<SavedItem> items)
        {
            if (items == null || items.Count == 0) return string.Empty;
            using (var stream = new MemoryStream())
            using (var writer = new BinaryWriter(stream))
            {
                WriteFingerprintItems(writer, items, 0);
                writer.Flush();
                using (var hash = SHA256.Create())
                    return Convert.ToBase64String(hash.ComputeHash(stream.ToArray()));
            }
        }

        private static void WriteFingerprintItems(BinaryWriter writer, IReadOnlyList<SavedItem> items, int depth)
        {
            if (depth > MaximumDepth) throw new InvalidDataException("Fingerprint tree is too deep.");
            var ordered = items == null ? new List<SavedItem>() : new List<SavedItem>(items);
            ordered.Sort((a, b) => a.InstanceID.CompareTo(b.InstanceID));
            writer.Write(ordered.Count);
            foreach (var item in ordered)
            {
                writer.Write(item.ItemID ?? string.Empty);
                writer.Write(item.InstanceID);
                writer.Write(item.X); writer.Write(item.Y); writer.Write(item.Quantity); writer.Write(item.Durability);
                writer.Write(item.IsRotated); writer.Write(item.IsFolded); writer.Write(item.ChargePercent);
                writer.Write(item.RemainingChargeSeconds);
                WriteFingerprintItems(writer, item.BackpackContents, depth + 1);
            }
        }
    }
}
