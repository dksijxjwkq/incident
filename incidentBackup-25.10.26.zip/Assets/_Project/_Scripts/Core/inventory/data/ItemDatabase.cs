﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// База данных предметов (ScriptableObject).
    /// Кэширует предметы по ItemID и PrefabID для быстрого поиска.
    /// </summary>
    [CreateAssetMenu(fileName = "ItemDatabase", menuName = "Incident/Inventory/Item Database", order = 2)]
    public class ItemDatabase : ScriptableObject
    {
        [SerializeField] private List<ItemStaticData> _items = new List<ItemStaticData>();

        [System.NonSerialized] private Dictionary<string, ItemStaticData> _itemCache;
        [System.NonSerialized] private Dictionary<ushort, ItemStaticData> _prefabCache;
        [System.NonSerialized] private ReadOnlyCollection<ItemStaticData> _readOnlyItems;
        [System.NonSerialized] private bool _isInitialized = false;
        public bool IsInitialized => _isInitialized;

        /// <summary>
        /// Инициализирует кэши базы данных.
        /// </summary>
        public void Initialize()
        {
            if (_isInitialized) return;
            _isInitialized = BuildCache();
        }

        private bool BuildCache()
        {
            var itemCache = new Dictionary<string, ItemStaticData>();
            var prefabCache = new Dictionary<ushort, ItemStaticData>();

            // ✅ УПРОЩЁННАЯ ПРОВЕРКА: убрана избыточная логика
            var idSet = new HashSet<ushort>();

            foreach (var item in _items)
            {
                if (item == null) continue;

                if (!string.IsNullOrEmpty(item.ItemID))
                {
                    if (itemCache.TryGetValue(item.ItemID, out var first))
                    {
                        Debug.LogError($"[ItemDatabase] Duplicate ItemID '{item.ItemID}' in assets '{first.name}' and '{item.name}'. Initialization refused.");
                        _itemCache = null;
                        _prefabCache = null;
                        _readOnlyItems = null;
                        return false;
                    }
                    itemCache.Add(item.ItemID, item);
                }

                // ✅ ПРЯМАЯ ПРОВЕРКА: без вложенных условий
                if (!idSet.Add(item.PrefabID))
                {
                    Debug.LogError($"[ItemDatabase] Duplicate PrefabID {item.PrefabID} for item '{item.name}'!");
                    continue;
                }

                prefabCache[item.PrefabID] = item;
            }

            _itemCache = itemCache;
            _prefabCache = prefabCache;
            _readOnlyItems = _items.AsReadOnly();
            return true;
        }

        /// <summary>
        /// Возвращает статические данные предмета по его текстовому ID.
        /// </summary>
        /// <param name="itemID">Уникальный идентификатор предмета</param>
        /// <returns>ItemStaticData или null если не найден</returns>
        public ItemStaticData GetItemData(string itemID)
        {
            if (!_isInitialized) Initialize();
            if (!_isInitialized) return null;
            return string.IsNullOrEmpty(itemID) ? null : (_itemCache.TryGetValue(itemID, out var d) ? d : null);
        }

        /// <summary>
        /// Возвращает статические данные предмета по его числовому PrefabID.
        /// </summary>
        /// <param name="prefabID">Числовой идентификатор префаба</param>
        /// <returns>ItemStaticData или null если не найден</returns>
        public ItemStaticData GetItemDataByPrefabID(ushort prefabID)
        {
            if (!_isInitialized) Initialize();
            if (!_isInitialized) return null;

            if (prefabID == 0)
            {
                Debug.LogWarning("[ItemDatabase] GetItemDataByPrefabID called with PrefabID = 0. This is invalid.");
                return null;
            }

            _prefabCache.TryGetValue(prefabID, out var d);
            return d;
        }

        /// <summary>
        /// Возвращает неизменяемый список всех предметов в базе.
        /// </summary>
        public IReadOnlyList<ItemStaticData> GetAllItems()
        {
            if (!_isInitialized) Initialize();
            return _isInitialized ? _readOnlyItems : System.Array.Empty<ItemStaticData>();
        }
    }
}
