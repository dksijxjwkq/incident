using System;

namespace K_Incident.Core.Inventory
{
    public static class InventoryGridBounds
    {
        public const int Minimum = 1;
        public const int Maximum = 20;

        public static bool IsValid(int width, int height) =>
            width >= Minimum && height >= Minimum && width <= Maximum && height <= Maximum;

        public static bool IsValidBackpack(ItemStaticData data) => data != null &&
            (!data.IsBackpack || IsValid(data.BackpackWidth, data.BackpackHeight));

        public static void Require(int width, int height)
        {
            if (!IsValid(width, height))
                throw new ArgumentOutOfRangeException(nameof(width), "Inventory dimensions must be between 1 and 20.");
        }
    }
}
