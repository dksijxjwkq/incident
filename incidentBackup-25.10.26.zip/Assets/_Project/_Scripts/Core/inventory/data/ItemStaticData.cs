﻿
using UnityEngine;
using K_Incident.Core.Combat;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Статические данные предмета (конфигурация из ScriptableObject).
    /// Используется для инициализации экземпляров инвентаря.
    ///
    /// ФИКС: Добавлена поддержка свёрнутого/развёрнутого состояния рюкзака.
    /// Свёрнутый рюкзак занимает меньше места в сетке (SizeFolded),
    /// но его внутренняя сетка недоступна (BackpackGridSizeFolded = 0x0).
    /// Развёрнутый рюкзак занимает больше места, но предоставляет внутреннюю сетку.
    ///
    /// ФИЧА #1 (AlwaysShowGrid):
    /// Добавлен флаг AlwaysShowGrid — внутренняя сетка рюкзака НЕ исчезает
    /// при сворачивании. Полезно для рюкзаков-сумок без крышки. Флаг
    /// настраивается в Инспекторе и легко отключается для возврата к старому
    /// поведению.
    /// </summary>
    [CreateAssetMenu(fileName = "NewItem", menuName = "K Inventory/Item Static Data")]
    public class ItemStaticData : ScriptableObject
    {
        #region Inspector Fields

        [Header("Identification")]
        [SerializeField] private string _itemID;
        [SerializeField] private ushort _prefabID;
        [SerializeField] private string _displayName;
        [SerializeField] private string _description;

        [Header("Physical Properties")]
        [SerializeField] private Vector2Int _size = new Vector2Int(1, 1);
        [SerializeField] private int _weightGrams = 500;
        [SerializeField] private int _hardStackLimit = 1;
        [Tooltip("Прочность конкретного предмета. Для брони это абсолютный runtime maximum; BaseDurability класса используется только при пустом значении 0.")]
        [SerializeField] private int _maxDurability = 100;

        // Stage 4: заряд механических средств хранится отдельно от прочности.
        [Header("Charge")]
        [SerializeField] private ChargeCategory _chargeCategory = ChargeCategory.None;
        [SerializeField, Min(0.01f)] private float _fullChargeSeconds = 420f;

        [Header("Visual")]
        [SerializeField] private Sprite _icon;
        [SerializeField] private GameObject _prefab;

        [Header("Classification")]
        [SerializeField] private ItemType _type;
        [SerializeField] private bool _canRotate = true;

        [Header("Backpack Specific")]
        [SerializeField] private Vector2Int _backpackGridSize = Vector2Int.zero;

        [Header("Backpack Folded State")]
        [SerializeField, Tooltip("Размер свёрнутого рюкзака в сетке (меньше развёрнутого). " +
            "Если (0,0) — сворачивание не поддерживается.")]
        private Vector2Int _sizeFolded = Vector2Int.zero;
        [SerializeField, Tooltip("Размер внутренней сетки свёрнутого рюкзака. " +
            "Обычно (0,0) — свёрнутый рюкзак не предоставляет слоты.")]
        private Vector2Int _backpackGridSizeFolded = Vector2Int.zero;
        [SerializeField, Tooltip("Иконка свёрнутого рюкзака. Если null — используется обычная иконка.")]
        private Sprite _iconFolded;
        [SerializeField] private Vector2Int _unfoldedIconSize = new Vector2Int(0, 0);
        public Vector2Int UnfoldedIconSize => _unfoldedIconSize;

        // ═══════════════════════════════════════════════════════════════
        //  ФИЧА #1: ALWAYS-SHOW-GRID
        //  Если true — внутренняя сетка рюкзака остаётся доступной даже
        //  когда рюкзак свёрнут. Соответствует поведению сумки/кофра без
        //  крышки: размер иконки маленький, но содержимое всё ещё можно
        //  перекладывать через Открыть. По умолчанию false — обратная
        //  совместимость со старым поведением.
        // ═══════════════════════════════════════════════════════════════
        [Header("Always Show Internal Grid")]
        [SerializeField, Tooltip("Если true — внутренняя сетка рюкзака остаётся доступной " +
            "даже в свёрнутом состоянии (ПКМ → Открыть работает всегда). " +
            "Полезно для рюкзаков-сумок без крышки. По умолчанию false — старое поведение.")]
        private bool _alwaysShowGrid = false;

        [Header("Icon Rotation")]
        [SerializeField, Tooltip("Базовый угол поворота иконки (градусы). 0 = как есть.")]
        private float _iconBaseRotation = 0f;

        [Header("Weapon Specific")]
        [SerializeField] private bool _isPistol = false;
        [SerializeField, Tooltip("Является ли предмет холодным оружием (нож, топор и т.д.)")]
        private bool _isMelee = false;
        [SerializeField, Tooltip("Калибр оружия (например: 12x70, 7.62x39)")]
        private string _caliber = "";

        // НОВЫЕ ПОЛЯ ДЛЯ БРОНИ (без дублирования _maxDurability)
        [Header("Armor Specific")]
        [SerializeField] private EquipAffinity _equipAffinity = EquipAffinity.None;
        [SerializeField] private int _armorClass = 0;

        [Header("Combat Data (Stage 5.1)")]
        [SerializeField] private WeaponItemDefinition _weapon = new WeaponItemDefinition();
        [SerializeField] private MagazineItemDefinition _magazine = new MagazineItemDefinition();
        [SerializeField] private AmmoItemDefinition _ammunition = new AmmoItemDefinition();
        [SerializeField] private ArmorItemDefinition _armor = new ArmorItemDefinition();

        [Header("Melee attack (per item)")]
        [SerializeField] private MeleeAttackDefinition _melee = new MeleeAttackDefinition();
        public MeleeAttackDefinition Melee => _melee;

        public WeaponItemDefinition Weapon => _weapon;
        public MagazineItemDefinition Magazine => _magazine;
        public AmmoItemDefinition Ammunition => _ammunition;
        public ArmorItemDefinition Armor => _armor;
        // Ammo has no durability in the combat contract, even if an old asset retains
        // a generic inventory durability value. Author new ammo assets with MaxDurability = 0.
        public bool UsesDurability => _type != ItemType.Ammo && _maxDurability > 0;

        public EquipAffinity EquipAffinity => _equipAffinity;
        public int ArmorClass => _armorClass;

        [Header("Consumables (Iteration 8c)")]
        [SerializeField, Min(0.01f)] private float _fullChargeMl = 500f;
        [SerializeField] private ConsumableType _consumableType = ConsumableType.None;
        [SerializeField, Min(0f)] private float _consumableTotalValue = 0f;
        [SerializeField] private bool _isRepairKit = false;

        public float FullChargeMl => _fullChargeMl;
        public ConsumableType ConsumableType => _consumableType;
        public float ConsumableTotalValue => _consumableTotalValue;
        public bool IsRepairKit => _isRepairKit;
        public bool HasIndividualCharge => _chargeCategory == ChargeCategory.DurationPercent ||
            _chargeCategory == ChargeCategory.AmountAbsolute || _chargeCategory == ChargeCategory.ConsumablePercent ||
            _consumableType != ConsumableType.None;

        #endregion

        #region Public Properties

        public string ItemID => _itemID;
        public ushort PrefabID => _prefabID;
        public string DisplayName => _displayName;
        public string Description => _description;
        public Vector2Int Size => _size;
        public int WeightGrams => _weightGrams;
        // A charge belongs to one InstanceID, never to an ambiguous partial stack.
        public int HardStackLimit => _chargeCategory == ChargeCategory.AmountAbsolute ||
            _chargeCategory == ChargeCategory.ConsumablePercent || _consumableType != ConsumableType.None ? 1 : _hardStackLimit;
        public int MaxDurability => _maxDurability; // уже существовало
        public ChargeCategory ChargeCategory => _chargeCategory;
        public float FullChargeSeconds => _fullChargeSeconds;
        public Sprite Icon => _icon;
        public GameObject Prefab => _prefab;
        public ItemType Type => _type;
        public bool CanRotate => _canRotate;
        public bool IsBackpack => _type == ItemType.Backpack || (_backpackGridSize.x > 0 && _backpackGridSize.y > 0);
        public bool IsPistol => _isPistol;
        public bool IsMelee => _isMelee;
        public float IconBaseRotation => _iconBaseRotation;
        public string Caliber => _caliber;

        // Развёрнутый рюкзак
        public int BackpackWidth => _backpackGridSize.x;
        public int BackpackHeight => _backpackGridSize.y;

        // Свёрнутый рюкзак
        /// <summary>Размер свёрнутого рюкзака в сетке. (0,0) = сворачивание не поддерживается.</summary>
        public Vector2Int SizeFolded => _sizeFolded;
        /// <summary>Внутренняя сетка свёрнутого рюкзака. Обычно (0,0).</summary>
        public Vector2Int BackpackGridSizeFolded => _backpackGridSizeFolded;
        /// <summary>Иконка свёрнутого рюкзака. Null = обычная иконка.</summary>
        public Sprite IconFolded => _iconFolded;
        /// <summary>Поддерживает ли этот рюкзак сворачивание.</summary>
        public bool CanFold => IsBackpack && _sizeFolded.x > 0 && _sizeFolded.y > 0;

        /// <summary>
        /// ФИЧА #1: Если true — внутренняя сетка рюкзака остаётся доступной
        /// даже в свёрнутом состоянии. См. поле _alwaysShowGrid выше.
        /// </summary>
        public bool AlwaysShowGrid => _alwaysShowGrid;

        #endregion

        #region Public Methods

        /// <summary>
        /// Возвращает габариты предмета с учётом вращения.
        /// </summary>
        public Vector2Int GetDimensions(bool isRotated)
        {
            return (isRotated && _canRotate) ? new Vector2Int(_size.y, _size.x) : _size;
        }

        /// <summary>
        /// Возвращает габариты свёрнутого рюкзака с учётом вращения.
        /// </summary>
        public Vector2Int GetDimensionsFolded(bool isRotated)
        {
            if (_sizeFolded.x <= 0 || _sizeFolded.y <= 0) return _size; // fallback
            return (isRotated && _canRotate) ? new Vector2Int(_sizeFolded.y, _sizeFolded.x) : _sizeFolded;
        }

        #endregion

        #region Unity Lifecycle

        private void OnValidate()
        {
            if (IsBackpack)
            {
                _backpackGridSize.x = Mathf.Clamp(_backpackGridSize.x, InventoryGridBounds.Minimum, InventoryGridBounds.Maximum);
                _backpackGridSize.y = Mathf.Clamp(_backpackGridSize.y, InventoryGridBounds.Minimum, InventoryGridBounds.Maximum);
            }
            _weightGrams = Mathf.Max(0, _weightGrams);
            _hardStackLimit = Mathf.Max(1, _hardStackLimit);
            _size.x = Mathf.Max(1, _size.x);
            _size.y = Mathf.Max(1, _size.y);
            _maxDurability = Mathf.Max(0, _maxDurability);
            // Stage 4: DurationPercent всегда имеет положительный полный срок.
            _fullChargeSeconds = Mathf.Max(0.01f, _fullChargeSeconds);
            if (float.IsNaN(_fullChargeMl) || float.IsInfinity(_fullChargeMl) || _fullChargeMl <= 0f)
                _fullChargeMl = 500f;
            if (float.IsNaN(_consumableTotalValue) || float.IsInfinity(_consumableTotalValue) || _consumableTotalValue < 0f)
                _consumableTotalValue = 0f;
            if (_chargeCategory == ChargeCategory.AmountAbsolute || _chargeCategory == ChargeCategory.ConsumablePercent ||
                _consumableType != ConsumableType.None) _hardStackLimit = 1;
            // Свёрнутый размер не может быть больше развёрнутого
            if (_sizeFolded.x > 0 && _sizeFolded.y > 0)
            {
                _sizeFolded.x = Mathf.Clamp(_sizeFolded.x, 1, _size.x);
                _sizeFolded.y = Mathf.Clamp(_sizeFolded.y, 1, _size.y);
            }

            // ФИЧА #1: AlwaysShowGrid имеет смысл только для рюкзаков.
            // Если предмет не рюкзак — сбрасываем в false (в Инспекторе).
            if (!IsBackpack && _alwaysShowGrid)
                _alwaysShowGrid = false;
        }

        #endregion
    }

    // Stage 4: тип расходования заряда, значения сохраняют asset-совместимость.
    public enum ChargeCategory
    {
        None = 0,
        StackableCount = 1,
        DurationPercent = 2,
        AmountAbsolute = 3,
        ConsumablePercent = 4
    }

    public enum ConsumableType { None = 0, Food = 1, Drink = 2 }

    /// <summary>
    /// Типы предметов для классификации в инвентаре.
    /// </summary>
    public enum ItemType
    {
        Misc = 0,
        Weapon = 1,
        Ammo = 2,
        Medical = 3,
        Consumable = 4,
        Clothing = 5,
        Backpack = 6,
        Currency = 7,
        Tool = 8,
        KeyItem = 9,
        Armor = 10, // добавлено
        Magazine = 11,
    }

    // Новый enum для принадлежности к слотам брони
    public enum EquipAffinity
    {
        None,
        BodyArmor,
        HeadGear
    }
}
