
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using UnityEngine;
namespace K_Incident.Core.Inventory
{
    [Serializable]
    public class InventoryData : ISaveable
        , ISavePayloadValidator
    {
        [SerializeField] private int _width = 8;
        [SerializeField] private int _height = 10;
        [SerializeField] private List<SavedItem> _items = new List<SavedItem>();
        [SerializeField] private bool _isModified = false;
        [NonSerialized] private Dictionary<uint, int> _idToIndexMap;
        [NonSerialized] private ReadOnlyCollection<SavedItem> _readOnlyItems;
        [NonSerialized] private bool _isIndexMapValid = false;
        public string SaveID => $"InvData_{_width}x{_height}";
        public bool IsDirty { get => _isModified; set => _isModified = value; }
        public InventoryData() { _items = new List<SavedItem>(); }
        public InventoryData(int width, int height)
        {
            InventoryGridBounds.Require(width, height);
            _width = width;
            _height = height;
            _items = new List<SavedItem>();
        }
        private InventoryData(int width, int height, bool transientGround)
        {
            if (!transientGround || width < InventoryGridBounds.Minimum || width > InventoryGridBounds.Maximum ||
                height < InventoryGridBounds.Minimum ||
                (long)width * height > (long)InventoryLoadReader.MaximumItems * InventoryGridBounds.Maximum * InventoryGridBounds.Maximum)
                throw new ArgumentOutOfRangeException(nameof(height), "Invalid transient ground grid dimensions.");
            _width = width;
            _height = height;
            _items = new List<SavedItem>();
        }

        /// <summary>Explicitly privileged tall projection. Never use for a persistent backpack/grid.</summary>
        public static InventoryData CreateTransientGroundGrid(int width, int height) => new InventoryData(width, height, true);

        /// <summary>Materializes authored initial data into independently owned runtime roots and descendants.</summary>
        public void AssignFreshRuntimeIdentities()
        {
            var replacement = SavedItem.CloneContentsWithFreshInstanceIDs(_items);
            _items.Clear();
            if (replacement != null) _items.AddRange(replacement);
            _isIndexMapValid = false;
            MarkDirty();
        }
        public int Width => _width;
        public int Height => _height;
        public bool IsModified => _isModified;
        public IReadOnlyList<SavedItem> GetItems()
        {
            if (_readOnlyItems == null) _readOnlyItems = _items.AsReadOnly();
            return _readOnlyItems;
        }
        public int GetItemCount() => _items.Count;
        public void Clear()
        {
            _items.Clear();
            MarkDirty();
            _isIndexMapValid = false;
        }
        public void MarkClean() => _isModified = false;
        public void MarkDirty() => _isModified = true;
        // >>> FIX «разные рюкзаки»: рантайм-ресайз сетки <<<
        // Контроллер рюкзака создаётся один раз 8x10, а реальный рюкзак может быть
        // любого размера. Без Resize правые/нижние колонки большого рюкзака не
        // работают (TryPlaceItem отклоняет по targetX >= controller.Width).
        // ВАЖНО: чистим _items — вызывающий контроллер сам перенаполнит список
        // через AddItem для каждого размещённого предмета (см. InventoryController.Resize).
        public void Resize(int newWidth, int newHeight)
        {
            newWidth = Mathf.Clamp(newWidth, 1, 20);
            newHeight = Mathf.Clamp(newHeight, 1, 20);
            _width = newWidth;
            _height = newHeight;
            _items.Clear();
            _isIndexMapValid = false;
            _readOnlyItems = null;
            MarkDirty();
        }
        // >>> END FIX <<<
        private void EnsureIndexMap()
        {
            if (_isIndexMapValid && _idToIndexMap != null && _idToIndexMap.Count == _items.Count) return;
            _idToIndexMap = new Dictionary<uint, int>(_items.Count);
            for (int i = 0; i < _items.Count; i++)
            {
                if (!_idToIndexMap.ContainsKey(_items[i].InstanceID))
                    _idToIndexMap[_items[i].InstanceID] = i;
            }
            _isIndexMapValid = true;
        }
        public bool HasItem(uint instanceID)
        {
            EnsureIndexMap();
            return _idToIndexMap.ContainsKey(instanceID);
        }
        public SavedItem GetItem(uint instanceID)
        {
            EnsureIndexMap();
            return _idToIndexMap.TryGetValue(instanceID, out int index) && index < _items.Count
            ? _items[index]
            : default;
        }
        public void AddItem(SavedItem item)
        {
#if UNITY_EDITOR
            Debug.Assert(item.InstanceID > 0, $"[InventoryData] Attempted to add item with InstanceID = 0");
            Debug.Assert(item.X >= 0 && item.X < _width && item.Y >= 0 && item.Y < _height,
            $"[InventoryData] Item {item.InstanceID} has invalid position ({item.X},{item.Y}) in {_width}x{_height} grid");
#endif
            if (HasItem(item.InstanceID))
            {
                Debug.LogWarning($"[InventoryData] Duplicate InstanceID {item.InstanceID} — skipping add");
                return;
            }
            _items.Add(item);
            MarkDirty();
            if (_isIndexMapValid) _idToIndexMap[item.InstanceID] = _items.Count - 1;
        }
        public void RemoveItem(uint instanceID)
        {
            EnsureIndexMap();
            if (_idToIndexMap.TryGetValue(instanceID, out int index) && index < _items.Count)
            {
                int last = _items.Count - 1;
                if (index < last)
                {
                    var swap = _items[last];
                    _items[index] = swap;
                    if (_isIndexMapValid) _idToIndexMap[swap.InstanceID] = index;
                }
                _items.RemoveAt(last);
                if (_isIndexMapValid) _idToIndexMap.Remove(instanceID);
            }
            MarkDirty();
        }
        public void UpdateItem(uint instanceID, int x, int y, int quantity, bool isRotated)
        {
            if (x < 0 || y < 0 || x >= _width || y >= _height)
            {
                Debug.LogWarning($"[InventoryData] UpdateItem: Invalid coordinates ({x},{y}) for {_width}x{_height} grid");
                return;
            }
            if (quantity <= 0)
            {
                Debug.LogWarning($"[InventoryData] UpdateItem: Invalid quantity {quantity} for {instanceID}");
                return;
            }
            EnsureIndexMap();
            if (!_idToIndexMap.TryGetValue(instanceID, out int index) || index >= _items.Count)
            {
                Debug.LogWarning($"[InventoryData] UpdateItem: InstanceID {instanceID} not found.");
                return;
            }
            var item = _items[index];
            item.X = x;
            item.Y = y;
            item.Quantity = quantity;
            item.IsRotated = isRotated;
            _items[index] = item;
            MarkDirty();
        }
        public void FillInstanceIDs(List<uint> results)
        {
            if (results == null) return;
            results.Clear();
            foreach (var item in _items) results.Add(item.InstanceID);
        }
        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            var pending = InventoryLoadReader.ReadInventory(reader);
            InventoryLoadReader.ValidateTree(pending.Items, pending.Width, pending.Height,
                K_InventorySetup.DatabaseInstance, context, SaveID);
        }

        public void Save(BinaryWriter writer)
        {
            writer.Write(_width);
            writer.Write(_height);
            writer.Write(_items.Count);
            foreach (var item in _items)
            {
                writer.Write(item.ItemID);
                writer.Write(item.InstanceID);
                writer.Write(item.X);
                writer.Write(item.Y);
                writer.Write(item.Quantity);
                writer.Write(item.Durability);
                writer.Write(item.IsRotated);
                writer.Write(item.IsFolded);
                // Stage 4: V8 — заряд следует сразу за IsFolded.
                writer.Write(Mathf.Clamp(item.ChargePercent, 0, 100));
                writer.Write(item.RemainingChargeSeconds); // Stage 4: schema revision 2, exact idle charge.
                int contentsCount = item.BackpackContents?.Count ?? 0;
                writer.Write(contentsCount);
                if (contentsCount > 0)
                {
                    foreach (var inner in item.BackpackContents)
                        WriteSavedItemRecursive(writer, inner);
                }
            }
        }
        private void WriteSavedItemRecursive(BinaryWriter writer, SavedItem item)
        {
            writer.Write(item.ItemID);
            writer.Write(item.InstanceID);
            writer.Write(item.X);
            writer.Write(item.Y);
            writer.Write(item.Quantity);
            writer.Write(item.Durability);
            writer.Write(item.IsRotated);
            writer.Write(item.IsFolded);
            // Stage 4: тот же V8-layout на любой глубине рюкзака.
            writer.Write(Mathf.Clamp(item.ChargePercent, 0, 100));
            writer.Write(item.RemainingChargeSeconds);
            int contentsCount = item.BackpackContents?.Count ?? 0;
            writer.Write(contentsCount);
            if (contentsCount > 0)
            {
                foreach (var inner in item.BackpackContents)
                    WriteSavedItemRecursive(writer, inner);
            }
        }
        public void Load(BinaryReader reader)
        {
            // Parse/validate the complete DTO before changing live fields. Errors propagate.
            var pending = InventoryLoadReader.ReadInventory(reader);
            _width = pending.Width;
            _height = pending.Height;
            _items = pending.Items;
            _idToIndexMap = null;
            _readOnlyItems = null;
            _isIndexMapValid = false;
            _isModified = false;
        }
       public void UpdateItemWithContents(
    uint instanceID,
    int x,
    int y,
    int quantity,
    bool isRotated,
    bool isFolded,
    List<SavedItem> contents,
    int? chargePercent = null,
    float? remainingChargeSeconds = null)
{
    EnsureIndexMap();

    if (!_idToIndexMap.TryGetValue(instanceID, out int index) ||
        index >= _items.Count)
    {
        return;
    }

    var item = _items[index];

    item.X = x;
    item.Y = y;
    item.Quantity = quantity;
    item.IsRotated = isRotated;
    item.IsFolded = isFolded;
    // Stage 4: старые вызовы сохраняют текущий заряд, новые передают live-значение.
    if (chargePercent.HasValue)
        item.ChargePercent = Mathf.Clamp(chargePercent.Value, 0, 100);
    // Stage 4: старые вызовы сохраняют точные секунды; controller передаёт оба поля.
    if (remainingChargeSeconds.HasValue)
    {
        float remaining = remainingChargeSeconds.Value;
        if (float.IsNaN(remaining) || float.IsInfinity(remaining)
            || (remaining < 0f && remaining != -1f))
            throw new ArgumentOutOfRangeException(nameof(remainingChargeSeconds));
        item.RemainingChargeSeconds = remaining;
    }

    if (contents == null || contents.Count == 0)
    {
        item.BackpackContents = null;
    }
    else
    {
        item.BackpackContents = new List<SavedItem>(contents.Count);

        for (int i = 0; i < contents.Count; i++)
        {
            var source = contents[i];
            item.BackpackContents.Add(SavedItem.DeepClone(in source));
        }
    }

    _items[index] = item;
    MarkDirty();
}
        private SavedItem ReadSavedItemRecursive(BinaryReader reader)
        {
            var item = new SavedItem
            {
                ItemID = reader.ReadString(),
                InstanceID = reader.ReadUInt32(),
                X = reader.ReadInt32(),
                Y = reader.ReadInt32(),
                Quantity = Mathf.Max(1, reader.ReadInt32()),
                Durability = Mathf.Max(0, reader.ReadInt32()),
                IsRotated = reader.ReadBoolean(),
                IsFolded = reader.ReadBoolean(),
                ChargePercent = Mathf.Clamp(reader.ReadInt32(), 0, 100)
            };
            item.RemainingChargeSeconds = ReadRemainingChargeSeconds(reader, item.ChargePercent);
            int contentsCount = reader.ReadInt32();
            if (contentsCount > 0)
            {
                item.BackpackContents = new List<SavedItem>(contentsCount);
                for (int j = 0; j < contentsCount; j++)
                    item.BackpackContents.Add(ReadSavedItemRecursive(reader));
            }
            return item;
        }
        /// <summary>Captures runtime DTO order and dirty state without serializing or notifying.</summary>
        internal Action CaptureAtomicRestore()
        {
            int width = _width, height = _height;
            bool dirty = _isModified;
            var items = new List<SavedItem>(_items.Count);
            foreach (var item in _items) items.Add(SavedItem.DeepClone(item));
            return () =>
            {
                _width = width;
                _height = height;
                _items = new List<SavedItem>(items.Count);
                foreach (var item in items) _items.Add(SavedItem.DeepClone(item));
                _idToIndexMap = null;
                _readOnlyItems = null;
                _isIndexMapValid = false;
                _isModified = dirty;
            };
        }

        private static float ReadRemainingChargeSeconds(BinaryReader reader, int chargePercent)
        {
            float remaining = reader.ReadSingle();
            if (float.IsNaN(remaining) || float.IsInfinity(remaining)
                || (remaining < 0f && remaining != -1f)
                || (remaining == 0f && chargePercent > 0))
                throw new InvalidDataException("Stage 4: invalid exact item charge in V8 schema revision 2.");
            return remaining;
        }
    }
}
// === EOF: InventoryData.cs ===
