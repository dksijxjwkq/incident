﻿

using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Сериализуемые данные предмета для сохранения/загрузки.
    ///
    /// ФИКС v2: Добавлены:
    /// - IsFolded (поле было, но не сериализовалось в InventoryData.Save/Load — нужно добавить)
    /// - BackpackContents: List<SavedItem> — рекурсивное содержимое рюкзака.
    ///   null если предмет не рюкзак или рюкзак пустой.
    ///
    /// ФИКС БАГ (audit) #25 SavedItem: добавлен [Serializable] и DeepClone.
    /// Без [Serializable] BinaryFormatter/Unity-serialization молча теряют
    /// структуру, а shallow-копия struct с mutable List<SavedItem> расшаривает
    /// один и тот же список между всеми копиями, что приводит к перекрёстному
    /// изменению содержимого рюкзаков.
    /// </summary>
    [Serializable]
    public struct SavedItem
    {
        public string ItemID;
        public uint InstanceID;
        public int X, Y;
        public int Quantity;
        public int Durability;
        public bool IsRotated;
        public bool IsFolded;
        // Stage 4: заряд 0–100; конструктор новых предметов задаёт 100.
        public int ChargePercent;
        // Stage 4: точный остаток не квантуется при снятии/повторном применении.
        // -1 означает: вывести секунды из процента и шаблона при создании live item.
        public float RemainingChargeSeconds;

        /// <summary>
        /// Содержимое рюкзака (рекурсивно).
        /// null для не-рюкзаков или пустых рюкзаков.
        /// ВАЖНО: SavedItem — struct, поэтому присваивание копирует список по ссылке
        /// (List — reference type). Используйте new List(...) при присваивании,
        /// чтобы избежать случайного расшаривания.
        ///
        /// ФИКС БАГ (audit #25 → user feedback):
        /// Поле помечено [NonSerialized], потому что:
        ///   1) Unity-сериализатор видит `List<SavedItem>` внутри `SavedItem`
        ///      как потенциальную бесконечную рекурсию (Serialization depth 10).
        ///      Warning засорял консоль и не давал редактировать InventoryData в инспекторе.
        ///   2) BackpackContents в любом случае сериализуется через BinaryWriter/Reader
        ///      в InventoryData.Save/Load (см. WriteSavedItemRecursive).
        ///      Unity-сериализация здесь не нужна.
        /// </summary>
        [NonSerialized]
        public List<SavedItem> BackpackContents;

        public SavedItem(string itemID, uint instanceID, int x, int y, int quantity, int durability, bool isRotated, bool isFolded = false, int chargePercent = 100, float remainingChargeSeconds = -1f)
        {
            ItemID = itemID;
            InstanceID = instanceID;
            X = x; Y = y;
            Quantity = quantity;
            Durability = durability;
            IsRotated = isRotated;
            IsFolded = isFolded;
            ChargePercent = Mathf.Clamp(chargePercent, 0, 100);
            if (float.IsNaN(remainingChargeSeconds) || float.IsInfinity(remainingChargeSeconds)
                || (remainingChargeSeconds < 0f && remainingChargeSeconds != -1f))
                throw new ArgumentOutOfRangeException(nameof(remainingChargeSeconds));
            RemainingChargeSeconds = remainingChargeSeconds;
            if (remainingChargeSeconds == 0f) ChargePercent = 0;
            BackpackContents = null;
        }

        /// <summary>
        /// Проверяет валидность данных предмета.
        /// </summary>
        public bool IsValid()
        {
            if (string.IsNullOrEmpty(ItemID)) return false;
            if (InstanceID == 0) return false;
            if (X < 0 || Y < 0) return false;
            if (Quantity <= 0) return false;
            if (float.IsNaN(RemainingChargeSeconds) || float.IsInfinity(RemainingChargeSeconds)
                || (RemainingChargeSeconds < 0f && RemainingChargeSeconds != -1f)) return false;
            return true;
        }

        public override string ToString()
        {
            string contents = BackpackContents != null ? $", Contents={BackpackContents.Count}" : "";
            return $"SavedItem[{InstanceID}] {ItemID} @ ({X},{Y}) Qty:{Quantity} Rot:{IsRotated} Fold:{IsFolded} Charge:{ChargePercent}% Remaining:{RemainingChargeSeconds:F3}s{contents}";
        }

        // ═══════════════════════════════════════════════════════════════
        //  ФИКС БАГ (audit) #25: DeepClone — глубокое копирование SavedItem
        //  с рекурсивным клонированием BackpackContents.
        //
        //  SavedItem — struct с mutable List<SavedItem> BackpackContents.
        //  Shallow-копия (просто присваивание struct) копирует ссылку на List,
        //  и две «копии» оказываются с одним и тем же списком содержимого.
        //  Это приводило к смешиванию содержимого разных рюкзаков в:
        //    - InventoryItem.FromSaveData → _backpackContentsSerialized
        //    - K_InventoryUI.SwapBackpackContents
        //    - Resize/serialization paths
        //
        //  Глубина рекурсии ограничена 32 — этого достаточно для любого
        //  реального инвентаря. При превышении кидается InvalidDataException,
        //  чтобы повреждённое сохранение не дошло до live-state.
        // ═══════════════════════════════════════════════════════════════
        private const int MAX_DEEP_CLONE_DEPTH = 32;

        /// <summary>Creates independent ownership identities; transfer paths keep their existing IDs.</summary>
        public static void ReserveSourceInstanceIDs(in SavedItem source) => ObserveCloneSourceIDs(source, 0);

        public static SavedItem CloneWithFreshInstanceIDs(in SavedItem source)
        {
            var copy = DeepClone(source);
            ObserveCloneSourceIDs(copy, 0);
            AssignFreshInstanceIDs(ref copy, 0);
            return copy;
        }

        public static List<SavedItem> CloneContentsWithFreshInstanceIDs(IReadOnlyList<SavedItem> source)
        {
            if (source == null) return null;
            var copies = new List<SavedItem>(source.Count);
            foreach (var saved in source) copies.Add(DeepClone(saved));
            foreach (var saved in copies) ObserveCloneSourceIDs(saved, 0);
            for (int i = 0; i < copies.Count; i++)
            {
                var copy = copies[i];
                AssignFreshInstanceIDs(ref copy, 0);
                copies[i] = copy;
            }
            return copies;
        }

        private static void ObserveCloneSourceIDs(SavedItem source, int depth)
        {
            if (depth > MAX_DEEP_CLONE_DEPTH) throw new InvalidDataException("Clone tree exceeds maximum depth.");
            if (source.InstanceID != 0 && source.InstanceID != uint.MaxValue) GlobalIDManager.ObserveID(source.InstanceID);
            if (source.BackpackContents != null)
                foreach (var child in source.BackpackContents) ObserveCloneSourceIDs(child, depth + 1);
        }

        private static void AssignFreshInstanceIDs(ref SavedItem item, int depth)
        {
            if (depth > MAX_DEEP_CLONE_DEPTH) throw new InvalidDataException("Clone tree exceeds maximum depth.");
            item.InstanceID = GlobalIDManager.GenerateID();
            if (item.BackpackContents == null) return;
            for (int i = 0; i < item.BackpackContents.Count; i++)
            {
                var child = item.BackpackContents[i];
                AssignFreshInstanceIDs(ref child, depth + 1);
                item.BackpackContents[i] = child;
            }
        }

        public static SavedItem DeepClone(in SavedItem source) => DeepClone(source, depth: 0);

        private static SavedItem DeepClone(in SavedItem source, int depth)
        {
            if (depth > MAX_DEEP_CLONE_DEPTH)
                throw new InvalidDataException(
                    "SavedItem.DeepClone: backpack nesting is too deep " +
                    $"(>{MAX_DEEP_CLONE_DEPTH}). Save data is corrupted.");

            SavedItem copy = source; // struct copy — копирует value-поля
            // Stage 4: struct copy сохраняет процент и точные секунды на любой глубине.

            if (source.BackpackContents == null)
            {
                copy.BackpackContents = null;
                return copy;
            }

            copy.BackpackContents = new List<SavedItem>(source.BackpackContents.Count);
            foreach (var child in source.BackpackContents)
                copy.BackpackContents.Add(DeepClone(child, depth + 1));

            return copy;
        }

        /// <summary>
        /// Возвращает true, если в дереве SavedItem встречается InstanceID
        /// с таким же значением как rootInstanceId (защита от циклов в сохранении).
        /// </summary>
        public static bool ContainsInstanceId(List<SavedItem> contents, uint targetInstanceId, int depth = 0)
        {
            if (contents == null || contents.Count == 0) return false;
            if (depth > MAX_DEEP_CLONE_DEPTH) return true; // считаем цикл как «содержит» — fail-closed

            foreach (var child in contents)
            {
                if (child.InstanceID == targetInstanceId) return true;
                if (child.BackpackContents != null && child.BackpackContents.Count > 0)
                    if (ContainsInstanceId(child.BackpackContents, targetInstanceId, depth + 1))
                        return true;
            }
            return false;
        }
    }
}
