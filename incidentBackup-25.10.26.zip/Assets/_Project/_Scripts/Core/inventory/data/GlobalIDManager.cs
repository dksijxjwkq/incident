﻿
using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public static class GlobalIDManager
    {
        private static uint _nextID = 1;
        private static readonly object _lock = new object();
        private static bool _isInitialized = false;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void OnDomainReload()
        {
            lock (_lock)
            {
                _nextID = 1;
                _isInitialized = false;
            }
        }

        public static uint GenerateID()
        {
            lock (_lock)
            {
                if (!_isInitialized)
                {
                    _nextID = 1;
                    _isInitialized = true;
                }

                // ФИКС БАГ #23 (audit): uint.MaxValue тоже невалиден —
                // мы резервируем его как «no-id» sentinel. Кроме того,
                // переход через uint.MaxValue + 1 → 0 молча ломал бы
                // все новые предметы. Явно кидаем исключение.
                if (_nextID == 0 || _nextID == uint.MaxValue)
                    throw new OverflowException(
                        "GlobalIDManager: Instance ID space exhausted.");

                return _nextID++;
            }
        }

        /// <summary>
        /// ФИКС БАГ #23 (audit): Замена старого InitWithMaxId.
        /// Использует checked-арифметику, чтобы переполнение uint.MaxValue
        /// не превращалось молча в 0. Отбрасывает 0 и uint.MaxValue
        /// как невалидные известные ID.
        /// </summary>
        public static void ObserveID(uint knownId)
        {
            lock (_lock)
            {
                if (knownId == 0 || knownId == uint.MaxValue)
                    throw new InvalidDataException(
                        $"GlobalIDManager: invalid or exhausted ID: {knownId}");

                // checked: если knownId == uint.MaxValue — OverflowException
                uint candidate = checked(knownId + 1);

                if (!_isInitialized || candidate > _nextID)
                    _nextID = candidate;

                _isInitialized = true;
            }
        }

        /// <summary>
        /// Совместимость со старым API. Делегирует в ObserveID.
        /// </summary>
        public static void InitWithMaxId(uint maxKnownId) => ObserveID(maxKnownId);

        public static void Reset()
        {
            lock (_lock)
            {
                _nextID = 1;
                _isInitialized = false;
            }
        }

        /// <summary>Isolates a detached serializer's identity observations from the live allocator.</summary>
        public static IDisposable PreserveAllocationForValidation() => new ValidationAllocationScope();

        /// <summary>Contains one synchronous load; disposal rolls allocation back unless committed.</summary>
        public static LoadAllocationScope BeginLoadAllocationScope() => new LoadAllocationScope();

        public sealed class LoadAllocationScope : IDisposable
        {
            private readonly uint _savedNext;
            private readonly bool _savedInitialized;
            private bool _committed;
            private bool _disposed;

            internal LoadAllocationScope()
            {
                System.Threading.Monitor.Enter(_lock);
                _savedNext = _nextID;
                _savedInitialized = _isInitialized;
            }

            public void Commit()
            {
                if (_disposed) throw new ObjectDisposedException(nameof(LoadAllocationScope));
                _committed = true;
            }

            public void Dispose()
            {
                if (_disposed) return;
                if (!_committed)
                {
                    _nextID = _savedNext;
                    _isInitialized = _savedInitialized;
                }
                _disposed = true;
                System.Threading.Monitor.Exit(_lock);
            }
        }

        private sealed class ValidationAllocationScope : IDisposable
        {
            private readonly uint _savedNext;
            private readonly bool _savedInitialized;
            private bool _disposed;
            public ValidationAllocationScope()
            {
                System.Threading.Monitor.Enter(_lock);
                _savedNext = _nextID;
                _savedInitialized = _isInitialized;
            }
            public void Dispose()
            {
                if (_disposed) return;
                _nextID = _savedNext;
                _isInitialized = _savedInitialized;
                _disposed = true;
                System.Threading.Monitor.Exit(_lock);
            }
        }
    }
}
