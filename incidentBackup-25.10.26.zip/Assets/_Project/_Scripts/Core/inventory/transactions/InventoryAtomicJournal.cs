using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Runtime ownership journal for the new gameplay APIs. Legacy transaction methods stay frozen.</summary>
    public sealed class InventoryAtomicJournal
    {
        private static InventoryAtomicJournal _active;
        private readonly List<Action> _restoreControllers = new List<Action>();
        private readonly List<Action> _restoreItems = new List<Action>();
        private readonly List<Action> _restoreSlots = new List<Action>();
        private readonly List<Action> _deferred = new List<Action>();
        private readonly List<Action> _detachObservers = new List<Action>();
        private readonly HashSet<InventoryController> _controllers = new HashSet<InventoryController>();
        private readonly HashSet<InventoryItem> _items = new HashSet<InventoryItem>();
        private readonly Action _restoreLifecycle;
        private readonly Action<InventoryItem> _retainReference;

        public static bool IsActive => _active != null;

        public InventoryAtomicJournal(K_InventoryUI ui, IReadOnlyList<K_EquipmentSlotUI> slots,
            IEnumerable<InventoryController> additionalControllers, IEnumerable<InventoryItem> additionalItems,
            Action<InventoryItem> retainReference)
        {
            if (IsActive) throw new InvalidOperationException("Another atomic inventory operation is active.");
            if (ui == null) throw new ArgumentNullException(nameof(ui));
            _retainReference = retainReference;
            _restoreLifecycle = ui.CaptureAtomicLifecycleRestore();
            CaptureController(ui.PocketsController);
            CaptureController(ui.Pocket2Controller);
            CaptureController(ui.BackpackController);
            CaptureController(ui.ActiveContainerController);
            if (ui.BackpackManager != null)
            {
                foreach (var pair in ui.BackpackManager.OpenedBackpacks) CaptureController(pair.Value);
                foreach (var window in ui.BackpackManager.OpenWindows) CaptureController(window?.Controller);
            }
            if (additionalControllers != null)
                foreach (var controller in additionalControllers) CaptureController(controller);
            if (slots != null)
                foreach (var slot in slots)
                {
                    if (slot == null) continue;
                    CaptureItem(slot.EquippedItem);
                    _restoreSlots.Add(slot.CaptureAtomicRestore());
                }
            if (additionalItems != null)
                foreach (var item in additionalItems) CaptureItem(item);
            foreach (var controller in _controllers)
                _detachObservers.Add(controller.ObserveAtomicMutation(_retainReference));
            _active = this;
        }

        private void CaptureController(InventoryController controller)
        {
            if (controller == null || controller.IsDisposed || !_controllers.Add(controller)) return;
            _restoreControllers.Add(controller.CaptureAtomicRestore());
            for (int y = 0; y < controller.Height; y++)
                for (int x = 0; x < controller.Width; x++) CaptureItem(controller.GetItemAt(x, y));
        }

        private void CaptureItem(InventoryItem item)
        {
            if (item == null || !_items.Add(item)) return;
            _restoreItems.Add(item.CaptureAtomicRestore());
            CaptureController(item.GetBackpackController());
        }

        /// <summary>Retains the original reference before RemoveItem can publish its first callback.</summary>
        public static void BeforeMutation(InventoryItem item)
        {
            if (item != null) _active?._retainReference?.Invoke(item);
        }

        /// <summary>Destructive UI/controller cleanup is deferred until ownership commits.</summary>
        public static bool DeferLifecycle(Action cleanup)
        {
            if (_active == null) return false;
            _active._deferred.Add(cleanup ?? throw new ArgumentNullException(nameof(cleanup)));
            return true;
        }

        public void Restore()
        {
            // Keep the operation guard until rollback rendering has also finished.
            // A refresh subscriber must not commit a new transaction into restored grids.
            DetachObservers();
            _deferred.Clear();
            foreach (var restore in _restoreItems) restore();
            foreach (var restore in _restoreControllers) restore();
            foreach (var restore in _restoreSlots) restore();
            _restoreLifecycle();
        }

        public void EndRollback()
        {
            if (ReferenceEquals(_active, this)) _active = null;
            _deferred.Clear();
        }

        public void Complete()
        {
            if (ReferenceEquals(_active, this)) _active = null;
            DetachObservers();
            // Deferred cleanup cannot invalidate committed item ownership. Each cleanup
            // remains best-effort UI retirement, with real exceptions reported explicitly.
            foreach (var cleanup in _deferred)
                try { cleanup(); } catch (Exception error) { Debug.LogException(error); }
            _deferred.Clear();
        }

        private void DetachObservers()
        {
            foreach (var detach in _detachObservers) detach();
            _detachObservers.Clear();
        }
    }
}
