using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public readonly struct InventoryRelocationPlacement
    {
        public readonly InventoryItem Item;
        public readonly InventoryController Controller;
        public readonly int X, Y, Rotation;
        public InventoryRelocationPlacement(InventoryItem item, InventoryController controller, int x, int y, int rotation)
        { Item = item; Controller = controller; X = x; Y = y; Rotation = rotation; }
    }

    public sealed class EquipmentGridSwapPlan
    {
        public readonly InventoryItem Dragged, TargetItem;
        public readonly InventoryController TargetController;
        public readonly int X, Y, Rotation;
        public readonly IReadOnlyList<InventoryRelocationPlacement> Relocations;
        internal EquipmentGridSwapPlan(InventoryItem dragged, InventoryItem target, InventoryController controller,
            int x, int y, int rotation, List<InventoryRelocationPlacement> relocations)
        {
            Dragged = dragged; TargetItem = target; TargetController = controller;
            X = x; Y = y; Rotation = rotation; Relocations = relocations.AsReadOnly();
        }
    }

    /// <summary>Reserves every destination while planning; never rotates or mutates live items.</summary>
    internal static class EquipmentGridSwapPlanner
    {
        internal static bool TryResolve(InventoryItem dragged, InventoryItem target, InventoryController controller,
            int anchorX, int anchorY, List<InventoryController> fallback, out EquipmentGridSwapPlan plan, out string error)
        {
            plan = null; error = "No feasible equipment-grid placement";
            if (!InventoryItem.IsValidLiveQuantity(dragged) || !InventoryItem.IsValidLiveQuantity(target) ||
                controller == null || controller.IsDisposed || ReferenceEquals(dragged, target) ||
                !ReferenceEquals(controller.GetItemByInstanceID(target.InstanceID), target)) return false;
            if (target.Data.IsBackpack && !target.IsFolded) return false;
            if (!InventoryValidationService.NestingCheckBidirectional(dragged, target)) return false;
            var root = controller.FindItemRootPosition(target.InstanceID);
            if (root.x < 0 || !controller.AcceptsItemForPlacement(dragged)) return false;
            var normal = dragged.CurrentSize;
            int orientations = dragged.Data.CanRotate && normal.x != normal.y ? 2 : 1;
            for (int orientation = 0; orientation < orientations; orientation++)
            {
                var size = orientation == 0 ? normal : new Vector2Int(normal.y, normal.x);
                int rotation = orientation == 0 ? dragged.RotationAngle : (dragged.RotationAngle == 0 ? -90 : 0);
                int minX = Math.Max(0, root.x - size.x + 1);
                int maxX = Math.Min(controller.Width - size.x, root.x + target.CurrentSize.x - 1);
                int minY = Math.Max(0, root.y - size.y + 1);
                int maxY = Math.Min(controller.Height - size.y, root.y + target.CurrentSize.y - 1);
                int bestDistance = int.MaxValue;
                for (int y = minY; y <= maxY; y++)
                    for (int x = minX; x <= maxX; x++)
                    {
                        var displaced = new List<InventoryItem>();
                        bool foundTarget = false, invalid = false;
                        for (int row = y; row < y + size.y && !invalid; row++)
                            for (int column = x; column < x + size.x; column++)
                            {
                                var item = controller.GetItemAt(column, row);
                                if (item == null || ReferenceEquals(item, dragged)) continue;
                                if (ReferenceEquals(item, target)) { foundTarget = true; continue; }
                                if (item.Data?.IsBackpack == true && !item.IsFolded) { invalid = true; break; }
                                if (!displaced.Contains(item)) displaced.Add(item);
                            }
                        if (invalid || !foundTarget) continue;
                        int distance = Math.Abs(x - anchorX) + Math.Abs(y - anchorY);
                        if (distance >= bestDistance) continue;
                        if (!TryReserve(dragged, target, controller, x, y, size, displaced, fallback, out var relocations)) continue;
                        bestDistance = distance;
                        plan = new EquipmentGridSwapPlan(dragged, target, controller, x, y, rotation, relocations);
                    }
                if (plan != null) { error = string.Empty; return true; }
            }
            return false;
        }

        private static bool TryReserve(InventoryItem dragged, InventoryItem target, InventoryController primary,
            int x, int y, Vector2Int size, List<InventoryItem> displaced, List<InventoryController> fallback,
            out List<InventoryRelocationPlacement> result)
        {
            result = new List<InventoryRelocationPlacement>();
            var controllers = new List<InventoryController> { primary };
            if (fallback != null)
                foreach (var controller in fallback)
                    if (controller != null && !controller.IsDisposed && !controllers.Contains(controller)) controllers.Add(controller);
            var occupied = new Dictionary<InventoryController, bool[,]>();
            foreach (var controller in controllers)
            {
                if (controller.Width < 1 || controller.Height < 1 || (long)controller.Width * controller.Height > 1000000) return false;
                var grid = new bool[controller.Width, controller.Height];
                for (int row = 0; row < controller.Height; row++)
                    for (int column = 0; column < controller.Width; column++)
                    {
                        var item = controller.GetItemAt(column, row);
                        grid[column, row] = item != null && !(ReferenceEquals(controller, primary) &&
                            (ReferenceEquals(item, dragged) || ReferenceEquals(item, target) || displaced.Contains(item)));
                    }
                occupied.Add(controller, grid);
            }
            Reserve(occupied[primary], x, y, size);
            displaced.Sort((a, b) =>
            {
                int area = (b.CurrentSize.x * b.CurrentSize.y).CompareTo(a.CurrentSize.x * a.CurrentSize.y);
                return area != 0 ? area : a.InstanceID.CompareTo(b.InstanceID);
            });
            foreach (var item in displaced)
            {
                bool placed = false;
                foreach (var controller in controllers)
                {
                    if (!controller.AcceptsItemForPlacement(item)) continue;
                    var original = item.CurrentSize;
                    int orientations = item.Data.CanRotate && original.x != original.y ? 2 : 1;
                    for (int orientation = 0; orientation < orientations; orientation++)
                    {
                        var candidate = orientation == 0 ? original : new Vector2Int(original.y, original.x);
                        if (!FindEmpty(occupied[controller], candidate, out int placeX, out int placeY)) continue;
                        Reserve(occupied[controller], placeX, placeY, candidate);
                        result.Add(new InventoryRelocationPlacement(item, controller, placeX, placeY,
                            orientation == 0 ? item.RotationAngle : (item.RotationAngle == 0 ? -90 : 0)));
                        placed = true; break;
                    }
                    if (placed) break;
                }
                if (!placed) return false;
            }
            return true;
        }

        private static bool FindEmpty(bool[,] occupied, Vector2Int size, out int x, out int y)
        {
            x = y = -1;
            if (size.x < 1 || size.y < 1) return false;
            for (int row = 0; row <= occupied.GetLength(1) - size.y; row++)
                for (int column = 0; column <= occupied.GetLength(0) - size.x; column++)
                {
                    bool free = true;
                    for (int yy = row; yy < row + size.y && free; yy++)
                        for (int xx = column; xx < column + size.x; xx++)
                            if (occupied[xx, yy]) { free = false; break; }
                    if (free) { x = column; y = row; return true; }
                }
            return false;
        }

        private static void Reserve(bool[,] occupied, int x, int y, Vector2Int size)
        {
            for (int row = y; row < y + size.y; row++)
                for (int column = x; column < x + size.x; column++) occupied[column, row] = true;
        }
    }
}
