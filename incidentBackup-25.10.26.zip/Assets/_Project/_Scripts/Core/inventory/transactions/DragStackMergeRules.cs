using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public enum DragStackMergeDecision { NotMerge, Merge, Rejected }

    /// <summary>Read-only drag policy shared by drop routing and its preview.</summary>
    public static class DragStackMergeRules
    {
        public static DragStackMergeDecision Evaluate(InventoryItem source, InventoryController sourceController,
            InventoryItem target, InventoryController targetController, bool sourceIsGround, bool targetIsGround,
            out int moved, out string error)
        {
            moved = 0;
            error = string.Empty;
            if (targetIsGround && (!sourceIsGround || !ReferenceEquals(sourceController, targetController)))
                return Reject("Нельзя переносить предметы в сетку подбора с земли", out error);
            if (source?.Data == null || target?.Data == null || sourceController == null || targetController == null ||
                sourceController.IsDisposed || targetController.IsDisposed || ReferenceEquals(source, target) ||
                source.InstanceID == target.InstanceID || source.Quantity <= 0 || target.Quantity <= 0 ||
                !ReferenceEquals(sourceController.GetItemByInstanceID(source.InstanceID), source) ||
                !ReferenceEquals(targetController.GetItemByInstanceID(target.InstanceID), target))
                return Reject("Исходная или целевая стопка больше не находится в своей сетке", out error);

            if (source.Quantity > source.Data.HardStackLimit || target.Quantity > target.Data.HardStackLimit)
                return Reject("Количество превышает допустимый размер стопки", out error);
            bool compatible = source.Data.HardStackLimit > 1 && target.Data.HardStackLimit > 1 &&
                !source.Data.IsBackpack && !target.Data.IsBackpack &&
                !source.Data.HasIndividualCharge && !target.Data.HasIndividualCharge &&
                source.PrefabID == target.PrefabID && source.IsFolded == target.IsFolded &&
                source.Durability == target.Durability && source.ChargePercent == target.ChargePercent &&
                source.RemainingChargeSeconds == target.RemainingChargeSeconds;
            if (!compatible || target.Quantity >= target.Data.HardStackLimit)
                return sourceIsGround
                    ? Reject("Обмен предметов с землёй запрещён", out error)
                    : DragStackMergeDecision.NotMerge;
            var origin = sourceController.FindItemRootPosition(source.InstanceID);
            var destination = targetController.FindItemRootPosition(target.InstanceID);
            var targetFootprint = targetController.GetActualFootprint(target);
            if (origin.x < 0 || destination.x < 0 || targetFootprint.x != destination.x ||
                targetFootprint.y != destination.y || targetFootprint.width != target.CurrentSize.x ||
                targetFootprint.height != target.CurrentSize.y)
                return Reject("Сначала завершите перемещение целевой стопки", out error);

            int quantity = Mathf.Min(source.Quantity, target.Data.HardStackLimit - target.Quantity);
            if (source.Quantity > quantity && !FitsRemainder(source, sourceController, origin.x, origin.y, target.CurrentSize))
                return Reject("Остаток в ориентации цели не помещается в исходную ячейку", out error);
            try
            {
                // Public placement queries also enforce custom storage filters.
                // A metadata probe preserves the source identity without changing
                // the live drag, allocating an ID or relaxing ordinary auto-stack rules.
                bool accepted;
                if (source.RotationAngle == target.RotationAngle && source.CurrentSize == target.CurrentSize)
                    accepted = targetController.CanMergeStack(source, target);
                else
                {
                    var probe = new InventoryItem(source.Data, source.InstanceID, source.Quantity, source.Durability,
                        target.IsRotated, source.ChargePercent, source.RemainingChargeSeconds);
                    probe.RestoreRotationState(target.RotationAngle);
                    probe.SetFolded(source.IsFolded);
                    accepted = probe.CurrentSize == target.CurrentSize &&
                        targetController.CanPlaceItem(probe, destination.x, destination.y);
                }
                if (!accepted)
                    return Reject("Целевая сетка не принимает эту стопку", out error);
            }
            catch (System.Exception ex) { return Reject(ex.Message, out error); }
            moved = quantity;
            return DragStackMergeDecision.Merge;
        }

        private static bool FitsRemainder(InventoryItem source, InventoryController controller,
            int x, int y, Vector2Int size)
        {
            if (size.x <= 0 || size.y <= 0 || x < 0 || y < 0 ||
                x > controller.Width - size.x || y > controller.Height - size.y) return false;
            for (int dy = 0; dy < size.y; dy++)
            for (int dx = 0; dx < size.x; dx++)
            {
                var occupant = controller.GetItemAt(x + dx, y + dy);
                if (occupant != null && !ReferenceEquals(occupant, source)) return false;
            }
            return true;
        }

        private static DragStackMergeDecision Reject(string reason, out string error)
        { error = reason; return DragStackMergeDecision.Rejected; }
    }
}
