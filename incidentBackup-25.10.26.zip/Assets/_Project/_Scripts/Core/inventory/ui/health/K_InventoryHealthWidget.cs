
using K_Incident.Core;
using K_Incident.Core.Inventory;   // ← ДОБАВИТЬ: K_MedicalMirrorPanel, K_BodyPartDragOut
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

/// <summary>
/// Виджет здоровья для окна инвентаря.
/// Отличается от HUD-версии K_HealthWidget (нет fade, часов и т.д.),
/// но использует тот же API K_HealthSystem / K_VitalitySystem / K_WeightManager.
/// </summary>
public class K_InventoryHealthWidget : MonoBehaviour
{
    private const int SEGMENT_COUNT = 20;

    #region System References

    [Header("System References")]
    [SerializeField] private K_HealthSystem _healthSystem;
    [SerializeField] private K_VitalitySystem _vitalitySystem;
    // Stage 1: _coagulantItem удалён (K_CoagulantItem.cs удалён из проекта).
    [SerializeField] private K_WeightManager _weightManager;
    [SerializeField] private K_BloodSystem _bloodSystem;

    [Header("Blood UI")]
    [SerializeField] private TextMeshProUGUI _bloodText;
    [SerializeField] private Gradient _bloodTextGradient;

    [Header("Debuff Icons (Iteration 4 — placeholders)")]
    [SerializeField] private Image _iconConcussion;
    [SerializeField] private Image _iconTBI;
    [SerializeField] private Image _iconBreathingDifficulty;
    [SerializeField] private Image _iconImmobilized;
    [SerializeField] private Image _iconInternalBleeding;
    [SerializeField] private TextMeshProUGUI _ibCountText;
    [SerializeField] private K_DebuffSystem _debuffSystem;

    #endregion

    #region Health Doll

    [Header("Health Doll (Segments) — index = (int)BodyPart")]
    [SerializeField]
    private Image[] _segmentImages = new Image[20];

    [SerializeField] private Gradient _healthGradient;

    [Header("Stage 4: Applied mechanical icons (optional overrides)")]
    [SerializeField] private Sprite _tourniquetAppliedIcon;
    [SerializeField] private Sprite _jettAppliedIcon;
    private readonly Image[] _appliedOverlayImages = new Image[SEGMENT_COUNT];

    #endregion

    #region Status Icons

    [Header("Metabolism & Status Icons")]
    [SerializeField] private Gradient _statusGradient;
    [SerializeField] private Gradient _bleedingGradient;
    [SerializeField] private Gradient _hungerGradient;
    [SerializeField] private Gradient _thirstGradient;
    [SerializeField] private Gradient _radiationGradient;
    [SerializeField] private Gradient _overloadGradient;

    [Space]
    [SerializeField] private Image _iconHunger;
    [SerializeField] private Image _iconThirst;
    [SerializeField] private Image _iconRadiation;
    [SerializeField] private Image _iconCold;
    [SerializeField] private Image _iconOverload;
    [SerializeField] private Image _iconBleeding;
    [SerializeField] private Image _iconLaceration;
    [SerializeField] private Image _iconHangover;
    [SerializeField] private Image _iconDrunk;
    [SerializeField] private Image _iconStimOn;
    [SerializeField] private Image _iconStimOff;
    [SerializeField] private Image _iconCoagulant;
    [SerializeField, Tooltip("Цвет иконки коагулянта при показе.")]
    private Color _coagulantIconColor = Color.white;

    #endregion

    #region Fracture Icon

    [Header("Fracture Icon (Iteration 5)")]
    [SerializeField] private Image _iconFracture;
    [SerializeField] private TextMeshProUGUI _fractureCountText;

      [Header("Gunshot Icon (Iteration 6)")]
    [SerializeField] private Image _iconGunshot;

    #endregion

    #region Segment State (Stage 1)

    // Stage 1: блокировка сегмента во время apply (не влияет на цвет напрямую —
    // цвет ставит K_BodyPartDragOut.SetApplyVisual через SetSegmentColor).
    private readonly bool[] _locked = new bool[SEGMENT_COUNT];

    // Оригинальные цвета Image сегментов — кеш при первом изменении,
    // чтобы RestoreSegmentColor вернул именно ИСХОДНЫЙ цвет, а не хардкод.
    private readonly Color[] _originalColors = new Color[SEGMENT_COUNT];
    private readonly bool[] _hasOriginalColor = new bool[SEGMENT_COUNT];

    // Stage 1 диагностика: one-shot логи по каждому полю-иконке.
    private readonly HashSet<Image> _iconSetLog = new HashSet<Image>();
    private bool _fractureLogged;
    private bool _gunshotLogged;
    private bool _debuffLogged;

    #endregion

    #region Unity Lifecycle

    // ---------------------------------------------------------------------
    // ПРАВКА: авто-файнд перенесён из Start() в Awake(),
    //         добавлен первичный RefreshDebuffIcons().
    // ---------------------------------------------------------------------
    private void Awake()
    {
        // Stage 1 инвариант №9: никаких scene-wide Find* в Awake.
        // Всё, что зависит от других систем, — в Start.
        if (_iconCoagulant != null)
            _iconCoagulant.gameObject.SetActive(false);
    }

    private void SetupSegmentClickHandlers()
    {
        if (_segmentImages == null || _segmentImages.Length == 0) return;

        int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
        for (int i = 0; i < count; i++)
        {
            var img = _segmentImages[i];
            if (img == null) continue;

            img.raycastTarget = true;

            var trigger = img.gameObject.GetComponent<EventTrigger>();
            if (trigger == null) trigger = img.gameObject.AddComponent<EventTrigger>();

            var entry = new EventTrigger.Entry { eventID = EventTriggerType.PointerClick };
            int capturedIndex = i;
            entry.callback.AddListener(_ =>
            {
                var part = (BodyPart)capturedIndex;
                K_CombatTestController.SetTargetPart(part);
            });
            trigger.triggers.Add(entry);
            img.alphaHitTestMinimumThreshold = 0.1f;
        }
    }

    // ---------------------------------------------------------------------
    // ПРАВКА: Start() больше не ищет ссылки. Оставлены:
    //         warning + RefreshAll() (страховка отложенного OnEnable).
    // ---------------------------------------------------------------------
      private void Start()
    {
        if (_segmentImages == null || _segmentImages.Length != SEGMENT_COUNT)
        {
            Debug.LogError($"[K_InventoryHealthWidget] _segmentImages должен быть размером {SEGMENT_COUNT}, сейчас {_segmentImages?.Length ?? 0}. Компонент отключён.");
            Unsubscribe();
            enabled = false;
            return;
        }

        // Stage 1 инвариант №9: FindFirstObjectByType — только в Start.
        if (_healthSystem   == null) _healthSystem   = FindFirstObjectByType<K_HealthSystem>();
        if (_vitalitySystem == null) _vitalitySystem = FindFirstObjectByType<K_VitalitySystem>();
        if (_weightManager  == null) _weightManager  = FindFirstObjectByType<K_WeightManager>();
        if (_bloodSystem    == null) _bloodSystem    = FindFirstObjectByType<K_BloodSystem>();
        if (_debuffSystem   == null) _debuffSystem   = FindFirstObjectByType<K_DebuffSystem>();

        SetupSegmentClickHandlers();
        EnsureDragOutComponents();          // Stage 1: навесить K_BodyPartDragOut на каждый Image
        EnsureAppliedOverlays();            // Stage 4: косметика только на родителях конечностей
        ValidateIconReferences();           // Stage 1: диагностика null-полей / без спрайта
        RefreshDebuffIcons();

        if (_healthSystem == null || _vitalitySystem == null)
        {
            Debug.LogWarning("[K_InventoryHealthWidget] Core systems missing even after auto-find. " +
                $"HealthSystem={_healthSystem != null}, VitalitySystem={_vitalitySystem != null}. " +
                "Assign them in Inspector or ensure they exist in scene.");
        }

        // Повторная подписка — OnEnable подписаться не мог.
        Subscribe();

        RefreshAll();
    }

    private void OnEnable()
    {
        // Stage 1: подписка до Start — no-op, если системы ещё не найдены.
        Subscribe();
        RefreshAll();
    }

    private void OnDisable()
    {
        Unsubscribe();
    }

    /// <summary>
    /// Stage 1: идемпотентная подписка. Сначала снимаем — потом ставим заново.
    /// </summary>
    private void Subscribe()
    {
        if (_vitalitySystem != null)
        {
            _vitalitySystem.OnMetabolismChanged -= RefreshMetabolism;
            _vitalitySystem.OnStimulatorChanged -= RefreshMetabolism;
            _vitalitySystem.OnHangoverChanged -= RefreshMetabolism;
            _vitalitySystem.OnColdExposureChanged -= RefreshMetabolism;
            _vitalitySystem.OnOverloadChanged -= RefreshMetabolism;
            _vitalitySystem.OnMetabolismChanged += RefreshMetabolism;
            _vitalitySystem.OnStimulatorChanged += RefreshMetabolism;
            _vitalitySystem.OnHangoverChanged += RefreshMetabolism;
            _vitalitySystem.OnColdExposureChanged += RefreshMetabolism;
            _vitalitySystem.OnOverloadChanged += RefreshMetabolism;
        }
        if (_healthSystem != null) _healthSystem.OnHealthChanged -= RefreshHealth;
        if (_weightManager != null) _weightManager.OnWeightChanged -= RefreshMetabolism;
        if (_bloodSystem != null)   _bloodSystem.OnBloodChanged    -= RefreshBloodUI;
        if (_debuffSystem != null)  _debuffSystem.OnDebuffsChanged -= RefreshDebuffIcons;

        if (_healthSystem != null) _healthSystem.OnHealthChanged += RefreshHealth;
        if (_weightManager != null) _weightManager.OnWeightChanged += RefreshMetabolism;
        if (_bloodSystem != null)   _bloodSystem.OnBloodChanged    += RefreshBloodUI;
        if (_debuffSystem != null)  _debuffSystem.OnDebuffsChanged += RefreshDebuffIcons;
    }

    private void Unsubscribe()
    {
        if (_vitalitySystem != null)
        {
            _vitalitySystem.OnMetabolismChanged -= RefreshMetabolism;
            _vitalitySystem.OnStimulatorChanged -= RefreshMetabolism;
            _vitalitySystem.OnHangoverChanged -= RefreshMetabolism;
            _vitalitySystem.OnColdExposureChanged -= RefreshMetabolism;
            _vitalitySystem.OnOverloadChanged -= RefreshMetabolism;
        }
        if (_healthSystem != null) _healthSystem.OnHealthChanged -= RefreshHealth;
        if (_weightManager != null) _weightManager.OnWeightChanged -= RefreshMetabolism;
        if (_bloodSystem != null)   _bloodSystem.OnBloodChanged    -= RefreshBloodUI;
        if (_debuffSystem != null)  _debuffSystem.OnDebuffsChanged -= RefreshDebuffIcons;
    }

    #endregion

    #region Refresh

    public void RefreshAll()
    {
        RefreshHealth();
        RefreshMetabolism();
        RefreshBloodUI();
        RefreshDebuffIcons();
    }

    private void RefreshHealth()
    {
        UpdateHealthUI();
        UpdateFractureIcon();
        UpdateGunshotIcon();
        // Stage 3: revealed IB count can change without changing the debuff boolean.
        RefreshDebuffIcons();
        // Stage 1: UpdateCoagulantIcon() удалён.
        RefreshAppliedOverlays();
    }

    private void RefreshMetabolism()
    {
        UpdateMetabolismUI();
    }

      private void RefreshDebuffIcons()
    {
        if (_debuffSystem == null)
        {
            if (_ibCountText != null) _ibCountText.gameObject.SetActive(false);
            return;
        }

        SetIconActive(_iconConcussion,          _debuffSystem.HasConcussion);
        SetIconActive(_iconTBI,                 _debuffSystem.HasTBI);
        SetIconActive(_iconBreathingDifficulty, _debuffSystem.HasBreathingDifficulty);
        SetIconActive(_iconImmobilized,         _debuffSystem.HasImmobilized);
        SetIconActive(_iconInternalBleeding,    _debuffSystem.HasInternalBleeding);

        int count = _healthSystem != null ? _healthSystem.GetInternalBleedingRevealedCount() : 0;
        if (_ibCountText != null)
        {
            _ibCountText.gameObject.SetActive(count > 1);
            if (count > 1) _ibCountText.text = count.ToString();
        }

        if (!_debuffLogged)
        {
            _debuffLogged = true;
            Debug.Log($"[K_InventoryHealthWidget] RefreshDebuffIcons FIRST: " +
                      $"Concussion={_debuffSystem.HasConcussion}, TBI={_debuffSystem.HasTBI}, " +
                      $"Breathing={_debuffSystem.HasBreathingDifficulty}, " +
                      $"Immobilized={_debuffSystem.HasImmobilized}, IB={_debuffSystem.HasInternalBleeding}");
        }
    }

   
    #endregion

    private void RefreshBloodUI()
    {
        if (_bloodText == null || _bloodSystem == null) return;

        float p = _bloodSystem.BloodPercent;
        int percentInt = Mathf.RoundToInt(p * 100f);
        _bloodText.text = $"{percentInt}%";

        if (_bloodTextGradient != null)
        {
            Color c = _bloodTextGradient.Evaluate(p);
            _bloodText.color = c;
        }
    }

    #region Health Doll UI

    // Stage 4: отдельные Images не мешают hit-test/drag и не содержат таймеров.
    private void EnsureAppliedOverlays()
    {
        if (_segmentImages == null) return;
        int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
        for (int i = 0; i < count; i++)
        {
            var segment = _segmentImages[i];
            if (segment == null || _appliedOverlayImages[i] != null) continue;
            var child = segment.transform.Find("Stage4AppliedOverlay");
            GameObject go;
            if (child == null)
            {
                go = new GameObject("Stage4AppliedOverlay", typeof(RectTransform), typeof(Image));
                go.transform.SetParent(segment.transform, false);
            }
            else go = child.gameObject;
            var overlay = go.GetComponent<Image>();
            if (overlay == null) overlay = go.AddComponent<Image>();
            var rect = overlay.rectTransform;
            rect.anchorMin = new Vector2(0.5f, 0.5f);
            rect.anchorMax = new Vector2(0.5f, 0.5f);
            rect.pivot = new Vector2(0.5f, 0.5f);
            rect.anchoredPosition = Vector2.zero;
            rect.sizeDelta = new Vector2(24f, 24f);
            rect.localScale = Vector3.one;
            overlay.raycastTarget = false;
            overlay.preserveAspect = true;
            overlay.color = Color.white;
            _appliedOverlayImages[i] = overlay;
            go.SetActive(false);
        }
    }

    private void RefreshAppliedOverlays()
    {
        for (int i = 0; i < SEGMENT_COUNT; i++) RefreshAppliedOverlay((BodyPart)i);
    }

    /// <summary>Stage 4: parent-only cosmetic marker, no charge bar or timer.</summary>
    public void RefreshAppliedOverlay(BodyPart part)
    {
        int index = (int)part;
        if (index < 0 || index >= SEGMENT_COUNT) return;
        var overlay = _appliedOverlayImages[index];
        if (overlay == null) return;
        var record = _healthSystem?.AppliedMedical?.GetRecordForPart(part);
        // Основной UI-контракт: иконка на Image родителя, подавление на всей цепочке.
        if (record == null || record.AppliedTo != part)
        {
            overlay.gameObject.SetActive(false);
            return;
        }
        var icon = record.Kind == AppliedGhostKind.JETT ? _jettAppliedIcon : _tourniquetAppliedIcon;
        if (icon == null)
            icon = K_InventorySetup.DatabaseInstance?.GetItemData(record.VirtualItemID)?.Icon;
        overlay.sprite = icon;
        overlay.gameObject.SetActive(icon != null);
    }

    private void UpdateHealthUI()
    {
        if (_healthSystem == null) return;
        if (_healthGradient == null)
        {
            Debug.LogWarning("[K_InventoryHealthWidget] HealthGradient is null!");
            return;
        }

        if (_segmentImages == null) return;

        int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
        for (int i = 0; i < count; i++)
        {
            var part = (BodyPart)i;
            UpdateSegmentColor(_segmentImages[i], part);
        }
    }

    private void UpdateSegmentColor(Image img, BodyPart part)
    {
        if (img == null || _healthSystem == null || _healthGradient == null) return;

        float cur = _healthSystem.GetHP(part);
        float max = _healthSystem.GetMaxHP(part);
        if (max <= 0f) return;

        float ratio = Mathf.Clamp01(cur / max);
        Color c = _healthGradient.Evaluate(ratio);
        img.enabled = true;
        img.color = new Color(c.r, c.g, c.b, 1f);
    }

    #endregion

    #region Fractures

   



    #endregion

    #region Coagulant (Stage 1: deprecated)

    // Stage 1: UpdateCoagulantIcon() удалён вместе с K_CoagulantItem.
    // Поля _iconCoagulant / _coagulantIconColor оставлены как placeholder
    // под Icon_Gel (правка .asset в UI-итерации).

    #endregion

    #region Metabolism UI

    private void UpdateMetabolismUI()
    {
        if (_vitalitySystem == null) return;

        SafeUpdateIcon(_iconHunger, _vitalitySystem.Icon_Hunger, _vitalitySystem.Hunger / 100f, _hungerGradient);
        SafeUpdateIcon(_iconThirst, _vitalitySystem.Icon_Thirst, _vitalitySystem.Thirst / 100f, _thirstGradient);
        SafeUpdateIcon(_iconRadiation, _vitalitySystem.Icon_Radiation, 1f - (_vitalitySystem.Radiation / 100f), _radiationGradient);
        if (_vitalitySystem.Icon_Bleeding > 0)
            SafeUpdateIcon(_iconBleeding, true, _vitalitySystem.Icon_Bleeding / 3f, _bleedingGradient);
        else
            SafeUpdateIcon(_iconBleeding, false);

        SafeUpdateIcon(_iconLaceration, _vitalitySystem.Icon_Laceration);
        SafeUpdateIcon(_iconStimOn, _vitalitySystem.Icon_StimOn);
        SafeUpdateIcon(_iconStimOff, _vitalitySystem.Icon_StimOff);
        SafeUpdateIcon(_iconHangover, _vitalitySystem.Icon_Hangover);
        SafeUpdateIcon(_iconCold, _vitalitySystem.Icon_Cold);

        if (_weightManager != null)
        {
            float ratio = _weightManager.GetCurrentWeightRatio();
            bool overloaded = ratio >= 0.9f;
            if (overloaded)
            {
                float norm = Mathf.Clamp01(Mathf.InverseLerp(0.9f, 1.1f, ratio));
                SafeUpdateIcon(_iconOverload, true, norm, _overloadGradient);
            }
            else
                SafeUpdateIcon(_iconOverload, false);
        }
        else
            SafeUpdateIcon(_iconOverload, _vitalitySystem.Icon_Overload);

        SafeUpdateIcon(_iconDrunk, _vitalitySystem.Icon_Drunk);
    }

    private void SafeUpdateIcon(Image img, bool isActive, float? colorT = null, Gradient customGradient = null)
    {
        if (img == null) return;
        if (img.gameObject.activeSelf != isActive)
            img.gameObject.SetActive(isActive);
        if (isActive && colorT.HasValue)
        {
            Gradient g = customGradient != null ? customGradient : _statusGradient;
            if (g != null)
                img.color = g.Evaluate(Mathf.Clamp01(colorT.Value));
        }
    }

    #endregion
    
        #region Public API for K_MedicalMirrorPanel (Stage 1)

    // ─────────────────────────────────────────────────────────────────
    //  Stage 1: публичный API drop-цели на Image сегмента.
    //  Заменяет K_DropZoneRegistry.
    // ─────────────────────────────────────────────────────────────────

    /// <summary>Image сегмента или null.</summary>
    public Image GetSegmentImage(BodyPart part)
    {
        int i = (int)part;
        if (_segmentImages == null || i < 0 || i >= SEGMENT_COUNT || i >= _segmentImages.Length) return null;
        return _segmentImages[i];
    }

    /// <summary>RectTransform сегмента или null.</summary>
    public RectTransform GetSegmentRect(BodyPart part)
    {
        var img = GetSegmentImage(part);
        return img != null ? img.rectTransform : null;
    }

    /// <summary>
    /// Обратный поиск: какая BodyPart соответствует этому Image.
    /// Возвращает -1, если Image не из _segmentImages.
    /// </summary>
    public int GetPartIndexByImage(Image img)
    {
        if (img == null || _segmentImages == null) return -1;
        int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
        for (int i = 0; i < count; i++)
            if (_segmentImages[i] == img) return i;
        return -1;
    }

    /// <summary>
    /// Hit-test: содержит ли какой-либо Image сегмента точку screen-координат.
    /// Работает независимо от raycastTarget. Камера — авто из корневого Canvas
    /// (overlay → null, camera → worldCamera).
    /// </summary>
    public bool TryGetPartAtScreenPoint(Vector2 screenPos, out BodyPart part)
    {
        part = default;
        if (_segmentImages == null) return false;

        var cam = ResolveScreenCamera();
        int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
        for (int i = 0; i < count; i++)
        {
            var img = _segmentImages[i];
            if (img == null) continue;
            if (!img.gameObject.activeInHierarchy) continue;
            if (RectTransformUtility.RectangleContainsScreenPoint(img.rectTransform, screenPos, cam))
            {
                part = (BodyPart)i;
                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Ленивый резолв камеры корневого Canvas.
    /// Overlay → null. ScreenSpaceCamera / WorldSpace → worldCamera.
    /// </summary>
    private UnityEngine.Camera _screenCameraCache;
    private bool _screenCameraResolved;
    private UnityEngine.Camera ResolveScreenCamera()
    {
        if (_screenCameraResolved) return _screenCameraCache;
        _screenCameraResolved = true;

        var canvas = GetComponentInParent<Canvas>();
        if (canvas == null) return _screenCameraCache = null;
        var root = canvas.rootCanvas != null ? canvas.rootCanvas : canvas;
        _screenCameraCache = root.renderMode == RenderMode.ScreenSpaceOverlay
            ? null
            : root.worldCamera;
        return _screenCameraCache;
    }

    // ── Lock ──

    public bool IsSegmentLocked(BodyPart part)
    {
        int i = (int)part;
        if (i < 0 || i >= SEGMENT_COUNT) return false;
        return _locked[i];
    }

    public void SetSegmentLocked(BodyPart part, bool locked)
    {
        int i = (int)part;
        if (i < 0 || i >= SEGMENT_COUNT) return;
        _locked[i] = locked;
    }

    // ── Цвет ──

    /// <summary>
    /// Установить цвет Image сегмента. При первом изменении кеширует
    /// оригинальный цвет, чтобы RestoreSegmentColor() вернул именно его.
    /// </summary>
    public void SetSegmentColor(BodyPart part, Color color)
    {
        var img = GetSegmentImage(part);
        if (img == null) return;

        int i = (int)part;
        if (!_hasOriginalColor[i])
        {
            _originalColors[i] = img.color;
            _hasOriginalColor[i] = true;
        }
        img.color = color;
    }

    /// <summary>
    /// Вернуть оригинальный цвет конкретного сегмента. Locked-сегменты не трогает.
    /// </summary>
    public void RestoreSegmentColor(BodyPart part)
    {
        int i = (int)part;
        if (i < 0 || i >= SEGMENT_COUNT) return;
        if (_locked[i]) return;
        if (!_hasOriginalColor[i]) return;

        var img = GetSegmentImage(part);
        if (img != null) img.color = _originalColors[i];
        _hasOriginalColor[i] = false;
    }

    /// <summary>
    /// Вернуть оригинальные цвета ВСЕХ подсвеченных сегментов. Locked не трогает.
    /// </summary>
    public void RestoreAllSegmentColors()
    {
        for (int i = 0; i < SEGMENT_COUNT; i++)
        {
            if (_locked[i]) continue;
            if (!_hasOriginalColor[i]) continue;

            var img = GetSegmentImage((BodyPart)i);
            if (img != null) img.color = _originalColors[i];
            _hasOriginalColor[i] = false;
        }
    }

    // ── Компоненты DragOut ──

    /// <summary>
    /// Идемпотентно: навесить K_BodyPartDragOut на каждый Image сегмента.
    /// Форсирует raycastTarget = true и alphaHitTestMinimumThreshold = 0.1f.
    /// </summary>
    public void EnsureDragOutComponents()
    {
        if (_segmentImages == null) return;
        int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
        for (int i = 0; i < count; i++)
        {
            var img = _segmentImages[i];
            if (img == null) continue;

            img.raycastTarget = true;
            img.alphaHitTestMinimumThreshold = 0.1f;

            var drag = img.GetComponent<K_BodyPartDragOut>();
            if (drag == null)
                drag = img.gameObject.AddComponent<K_BodyPartDragOut>();
        }
    }

    /// <summary>
    /// Забиндить все K_BodyPartDragOut на panel+widget+part и передать конфиг визуала.
    /// Вызывается K_MedicalMirrorPanel после резолва виджета.
    /// </summary>
    public void ConfigureDragOuts(
        K_MedicalMirrorPanel panel,
        Color progressColor,
        Sprite progressSprite,
        Image.FillMethod fillMethod,
        int fillOrigin,
        bool clockwise,
        float ghostAlpha,
        float ghostPadding)
    {
        if (_segmentImages == null) return;
        int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
        for (int i = 0; i < count; i++)
        {
            var img = _segmentImages[i];
            if (img == null) continue;

            var drag = img.GetComponent<K_BodyPartDragOut>();
            if (drag == null) drag = img.gameObject.AddComponent<K_BodyPartDragOut>();

            drag.Bind(panel, this, (BodyPart)i);
            drag.SetVisualConfig(progressColor, progressSprite,
                fillMethod, fillOrigin, clockwise, ghostAlpha, ghostPadding);
        }
    }

    /// <summary>Компонент K_BodyPartDragOut для сегмента (или null).</summary>
    public K_BodyPartDragOut GetDragOutComponent(BodyPart part)
    {
        var img = GetSegmentImage(part);
        return img != null ? img.GetComponent<K_BodyPartDragOut>() : null;
    }

    #endregion

    #region Icon Diagnostics (Stage 1)

    // ─────────────────────────────────────────────────────────────────
    //  Stage 1: диагностика иконок — «в инспекторе заполнено, а не видно».
    // ─────────────────────────────────────────────────────────────────

    /// <summary>
    /// Однократно (в Start) проходит по всем полям-иконкам и логирует
    /// null-поля и поля без спрайта. Не влияет на логику.
    /// </summary>
    private void ValidateIconReferences()
    {
        var ctx = "[K_InventoryHealthWidget]";
        CheckIcon(_iconHunger,             nameof(_iconHunger),             ctx);
        CheckIcon(_iconThirst,             nameof(_iconThirst),             ctx);
        CheckIcon(_iconRadiation,          nameof(_iconRadiation),          ctx);
        CheckIcon(_iconCold,               nameof(_iconCold),               ctx);
        CheckIcon(_iconOverload,           nameof(_iconOverload),           ctx);
        CheckIcon(_iconBleeding,           nameof(_iconBleeding),           ctx);
        CheckIcon(_iconLaceration,         nameof(_iconLaceration),         ctx);
        CheckIcon(_iconHangover,           nameof(_iconHangover),           ctx);
        CheckIcon(_iconDrunk,              nameof(_iconDrunk),              ctx);
        CheckIcon(_iconStimOn,             nameof(_iconStimOn),             ctx);
        CheckIcon(_iconStimOff,            nameof(_iconStimOff),            ctx);
        CheckIcon(_iconCoagulant,          nameof(_iconCoagulant),          ctx);
        CheckIcon(_iconFracture,           nameof(_iconFracture),           ctx);
        CheckIcon(_iconGunshot,            nameof(_iconGunshot),            ctx);
        CheckIcon(_iconConcussion,         nameof(_iconConcussion),         ctx);
        CheckIcon(_iconTBI,                nameof(_iconTBI),                ctx);
        CheckIcon(_iconBreathingDifficulty,nameof(_iconBreathingDifficulty),ctx);
        CheckIcon(_iconImmobilized,        nameof(_iconImmobilized),        ctx);
        CheckIcon(_iconInternalBleeding,   nameof(_iconInternalBleeding),   ctx);
        if (_ibCountText == null)
            Debug.LogWarning($"{ctx} Count text reference '{nameof(_ibCountText)}' is NULL. Назначь TextMeshProUGUI в инспекторе.");
    }

    private void CheckIcon(Image icon, string fieldName, string ctx)
    {
        if (icon == null)
        {
            Debug.LogWarning($"{ctx} Icon reference '{fieldName}' is NULL. Назначь Image в инспекторе.");
            return;
        }
        if (icon.sprite == null)
        {
            Debug.LogWarning($"{ctx} Icon '{fieldName}' has no Sprite assigned. Иконка не будет видна.");
        }
    }

    // ─────────────────────────────────────────────────────────────────
    //  One-shot логи в runtime-методах.
    // ─────────────────────────────────────────────────────────────────

    private void SetIconActive(Image icon, bool active)
    {
        if (icon == null) return;
        if (icon.gameObject.activeSelf != active)
            icon.gameObject.SetActive(active);

        if (_iconSetLog.Add(icon))
            Debug.Log($"[K_InventoryHealthWidget] SetIconActive FIRST: {icon.name} → {active}");
    }

    private void UpdateFractureIcon()
    {
        if (_healthSystem == null) return;
        int count = _healthSystem.FractureCount;

        if (_iconFracture != null)
            _iconFracture.gameObject.SetActive(count > 0);

        if (_fractureCountText != null)
        {
            _fractureCountText.gameObject.SetActive(count > 1);
            if (count > 1) _fractureCountText.text = count.ToString();
        }

        if (!_fractureLogged)
        {
            _fractureLogged = true;
            Debug.Log($"[K_InventoryHealthWidget] UpdateFractureIcon FIRST: count={count}, " +
                      $"_iconFracture={(  _iconFracture != null ? "ok" : "NULL")}");
        }
    }

    private void UpdateGunshotIcon()
    {
        if (_healthSystem == null) return;
        if (_iconGunshot == null) return;

        bool any = _healthSystem.HasGunshot;
        if (_iconGunshot.gameObject.activeSelf != any)
            _iconGunshot.gameObject.SetActive(any);

        if (!_gunshotLogged)
        {
            _gunshotLogged = true;
            Debug.Log($"[K_InventoryHealthWidget] UpdateGunshotIcon FIRST: any={any}");
        }
    }

    #endregion
}
