using UnityEngine;
using UnityEngine.EventSystems;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Этап 6.1: drag-сессия зеркала медикаментов.
    ///
    /// Хранит активную сессию (виджет-источник + запись предмета) и
    /// владеет ghost'ом. НЕ выполняет drop / apply / подсветку / списание —
    /// это подэтапы 6.2–6.5.
    ///
    /// СИНХРОННЫЙ. Без Coroutine / async / Task / yield.
    /// </summary>
    public sealed class K_MedicalMirrorDragController
    {
        private const float DEFAULT_GHOST_SIZE = 64f;

        private readonly K_MedicalMirrorGhost _ghost = new K_MedicalMirrorGhost();
        private readonly float _ghostSize;

        private K_MedicalMirrorItem _widget;
        private MedicalItemRecord _record;
        private bool _isDragging;

        public bool IsDragging => _isDragging;
        public K_MedicalMirrorItem SourceWidget => _widget;
        public MedicalItemRecord Record => _record;

       public K_MedicalMirrorDragController(
    Transform canvasTransform, UnityEngine.Camera canvasCamera, float ghostSize)
        {
            _ghostSize = ghostSize > 0f ? ghostSize : DEFAULT_GHOST_SIZE;
            _ghost.Initialize(canvasTransform, canvasCamera);
        }

        /// <summary>
        /// Пытается начать сессию. Возвращает false, если событие не LMB,
        /// виджет / запись невалидны, либо ghost недоступен.
        /// </summary>
        public bool Begin(
            K_MedicalMirrorItem widget, MedicalItemRecord record, PointerEventData eventData)
        {
            if (eventData == null) return false;
            if (eventData.button != PointerEventData.InputButton.Left) return false;
            if (widget == null || record.Item == null) return false;
            if (!_ghost.IsValid) return false;

            // Защита от рассинхрона — если по какой-то причине уже dragging,
            // закрываем предыдущую сессию.
            if (_isDragging) End();

            _widget = widget;
            _record = record;
            _isDragging = true;

            _ghost.Show(record.Item, _ghostSize);
            _ghost.SetScreenPosition(eventData.position);
            return true;
        }

        /// <summary>Обновляет позицию ghost по текущему положению курсора.</summary>
        public void Update(PointerEventData eventData)
        {
            if (!_isDragging || eventData == null) return;
            _ghost.SetScreenPosition(eventData.position);
        }

        /// <summary>
        /// Завершает сессию (нормальный или отменённый финал).
        /// Идемпотентно.
        /// </summary>
        public void End()
        {
            if (!_isDragging && !_ghost.IsValid) return;
            _ghost.Hide();
            _widget = null;
            _record = default;
            _isDragging = false;
        }

        /// <summary>
        /// Полное освобождение: End + уничтожение ghost-Canvas'а.
        /// Вызывается из K_MedicalMirrorPanel.OnDestroy.
        /// </summary>
        public void Dispose()
        {
            End();
            _ghost.Destroy();
        }
    }
}