using System;
using System.Collections.Generic;
using K_Incident.Core;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    // Stage 4: adaptation of existing controllers; transaction services stay unchanged.
    public static class K_AppliedMedicalInventoryBridge
    {
        private sealed class Location
        {
            public InventoryItem Item;
            public InventoryController Controller;
            public List<SavedItem> Saved;
            public int Index;
            public Action Commit;
        }

        public static void Initialize(K_InventoryUI ui, K_HealthSystem health)
        {
            if (ui == null || health == null || health.AppliedMedical == null) return;
            health.AppliedMedical.ConfigureInventory(
                id => FindItem(ui, id),
                (id, charge, seconds) => UpdateCharge(ui, id, charge, seconds),
                record => ReturnVirtual(ui, record, false),
                record => ReturnVirtual(ui, record, true),
                id => RemoveItem(ui, id),
                () => { if (ui != null) ui.ForceRefresh(); });
            health.AppliedMedical.ConfigureItemDatabase(K_InventorySetup.DatabaseInstance);
        }

        public static InventoryItem FindItem(K_InventoryUI ui, uint id)
            => FindLocation(ui, id)?.Item;

        public static InventoryController FindController(K_InventoryUI ui, uint id)
            => FindLocation(ui, id)?.Controller;

        public static bool IsPlayerItem(K_InventoryUI ui, uint id)
            => FindLocation(ui, id) != null;

        public static bool TryApply(K_InventoryUI ui, K_HealthSystem health,
            InventoryItem item, InventoryController source, BodyPart parent,
            AppliedGhostKind kind, out string reason)
        {
            reason = null;
            if (ui == null || health == null || item?.Data == null)
            { reason = "Система применения недоступна"; return false; }
            Initialize(ui, health);
            if (!health.AppliedMedical.CanApply(item, parent, kind, out reason)) return false;
            if (IsPlayerItem(ui, item.InstanceID))
                return health.AppliedMedical.TryApply(item, parent, kind, out reason);

            source = source ?? ui.FindControllerForItem(item);
            if (source == null || source.IsDisposed)
            { reason = "Исходный контейнер недоступен"; return false; }
            var position = source.FindItemRootPosition(item.InstanceID);
            if (position.x < 0 || position.y < 0 ||
                !ReferenceEquals(source.GetItemAt(position.x, position.y), item))
            { reason = "Предмет отсутствует в исходном контейнере"; return false; }

            // Stage 4: remove ownership before publishing the virtual record.
            if (!source.RemoveItem(item))
            { reason = "Не удалось удалить предмет из контейнера"; return false; }
            if (health.AppliedMedical.TryApplyFromContainer(item.Data.ItemID,
                item.Quantity, item.Durability, item.ChargePercent, item.RemainingChargeSeconds, item.InstanceID,
                parent, kind, out reason))
            { ui.ForceRefresh(); return true; }
            if (!source.PlaceExistingItem(item, position.x, position.y))
                throw new InvalidOperationException("Stage 4: failed to restore source item after rejected apply.");
            return false;
        }

        /// <summary>
        /// Stage 4: test hotkeys inspect actual opened loot only, after player items.
        /// No closed loot is reconstructed: the returned controller owns the exact item.
        /// </summary>
        public static bool TryFindMechanicalItemInLoot(K_InventoryUI ui, AppliedGhostKind kind,
            out InventoryItem item, out InventoryController source)
        {
            item = null;
            source = null;
            if (ui == null) return false;
            var visited = new HashSet<InventoryController>();
            if (TryFindMechanicalInLiveController(ui, ui.LootSession?.GetLootControllerFromSlots(),
                kind, visited, out item, out source)) return true;
            if (TryFindMechanicalInLiveController(ui, ui.ActiveContainerController,
                kind, visited, out item, out source)) return true;
            var windows = ui.BackpackManager?.OpenWindows;
            if (windows != null)
                foreach (var window in windows)
                    if (TryFindMechanicalInLiveController(ui, window?.Controller,
                        kind, visited, out item, out source)) return true;
            return false;
        }

        private static bool TryFindMechanicalInLiveController(K_InventoryUI ui,
            InventoryController controller, AppliedGhostKind kind, HashSet<InventoryController> visited,
            out InventoryItem foundItem, out InventoryController source)
        {
            foundItem = null;
            source = null;
            if (controller == null || controller.IsDisposed || !visited.Add(controller)) return false;
            for (int y = 0; y < controller.Height; y++)
                for (int x = 0; x < controller.Width; x++)
                {
                    var candidate = controller.GetItemAt(x, y);
                    if (candidate?.Data == null || !controller.IsRootCell(candidate.InstanceID, x, y)
                        || IsPlayerItem(ui, candidate.InstanceID)) continue;
                    if (candidate.Quantity == 1 && candidate.RemainingChargeSeconds > 0f &&
                        K_AppliedMedicalManager.TryGetKind(candidate.Data.ItemID, out var candidateKind)
                        && candidateKind == kind)
                    {
                        foundItem = candidate;
                        source = controller;
                        return true;
                    }
                    if (candidate.Data.IsBackpack && TryFindMechanicalInLiveController(ui,
                        candidate.GetBackpackController(), kind, visited, out foundItem, out source)) return true;
                }
            return false;
        }

        private static InventoryController[] Roots(K_InventoryUI ui)
            => new[] { ui.PocketsController, ui.Pocket2Controller,
                ui.HasEquippedBackpack ? ui.BackpackController : null };

        private static Location FindLocation(K_InventoryUI ui, uint id)
        {
            if (ui == null || id == 0) return null;
            var visited = new HashSet<uint>();
            foreach (var root in Roots(ui))
            {
                var found = FindInController(root, id, visited, 0);
                if (found != null) return found;
            }
            return null;
        }

        private static Location FindInController(InventoryController controller,
            uint id, HashSet<uint> visited, int depth)
        {
            if (controller == null || controller.IsDisposed || depth > 32) return null;
            for (int y = 0; y < controller.Height; y++)
                for (int x = 0; x < controller.Width; x++)
                {
                    var item = controller.GetItemAt(x, y);
                    if (item == null || !controller.IsRootCell(item.InstanceID, x, y)) continue;
                    if (item.InstanceID == id) return new Location { Item = item, Controller = controller };
                    if (item.Data == null || !item.Data.IsBackpack || !visited.Add(item.InstanceID)) continue;
                    var inner = item.GetBackpackController();
                    if (inner != null && !inner.IsDisposed)
                    {
                        var found = FindInController(inner, id, visited, depth + 1);
                        if (found != null)
                        {
                            var innerCommit = found.Commit;
                            found.Commit = () =>
                            {
                                innerCommit?.Invoke();
                                item.MarkBackpackContentsDirty();
                                item.SyncBackpackContentsIfDirty();
                                controller.RefreshItemInData(item);
                            };
                            return found;
                        }
                    }
                    else
                    {
                        // Work on a detached tree: Commit can run more than once for rollback.
                        var contents = new List<SavedItem>();
                        foreach (var saved in item.GetBackpackSavedItems())
                            contents.Add(SavedItem.DeepClone(saved));
                        Action commit = () =>
                        {
                            // Stage 4: Replace clears its own source list; pass an independent list.
                            item.ReplaceBackpackContents(new List<SavedItem>(contents));
                            controller.RefreshItemInData(item);
                        };
                        var found = FindInSaved(contents, id, commit, depth + 1);
                        if (found != null) return found;
                    }
                }
            return null;
        }

        private static Location FindInSaved(List<SavedItem> items, uint id, Action commit, int depth)
        {
            if (items == null || depth > 32) return null;
            for (int i = 0; i < items.Count; i++)
            {
                var saved = items[i];
                if (saved.InstanceID == id)
                {
                    var data = K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID);
                    if (data == null) return null;
                    return new Location { Item = InventoryItem.FromSaveData(saved, data),
                        Saved = items, Index = i, Commit = commit };
                }
                var found = FindInSaved(saved.BackpackContents, id, commit, depth + 1);
                if (found != null) return found;
            }
            return null;
        }

        private static void UpdateCharge(K_InventoryUI ui, uint id, int charge, float seconds)
        {
            var location = FindLocation(ui, id);
            if (location == null) return;
            charge = Mathf.Clamp(charge, 0, 100);
            // Stage 4: compare persisted cache, not only the live item; the manager
            // can assign live seconds before this callback. Frozen sync is idempotent.
            var persisted = location.Controller != null
                ? location.Controller.GetSaveData().GetItem(id)
                : location.Saved[location.Index];
            bool alreadySaved = persisted.InstanceID == id && persisted.ChargePercent == charge &&
                persisted.RemainingChargeSeconds == seconds;
            // Stage 4: exact seconds are authoritative; assigning percent would round
            // the item back up to the next whole percentage on every reapplication.
            if (location.Item.RemainingChargeSeconds != seconds)
                location.Item.RemainingChargeSeconds = seconds;
            if (alreadySaved) return;
            if (location.Controller != null)
            { location.Controller.RefreshItemInData(location.Item); location.Commit?.Invoke(); }
            else
            {
                var saved = location.Saved[location.Index];
                saved.ChargePercent = charge;
                saved.RemainingChargeSeconds = location.Item.RemainingChargeSeconds;
                location.Saved[location.Index] = saved;
                location.Commit();
            }
        }

        private static void RemoveItem(K_InventoryUI ui, uint id)
        {
            var location = FindLocation(ui, id);
            if (location == null) return;
            if (location.Controller != null)
            { location.Controller.RemoveItem(location.Item); location.Commit?.Invoke(); }
            else { location.Saved.RemoveAt(location.Index); location.Commit(); }
            ui.ForceRefresh();
        }

        public static bool TryDetachForWorldDrop(K_InventoryUI ui, uint id, out Func<bool> rollback)
        {
            rollback = null;
            var location = FindLocation(ui, id);
            if (location == null) return false;

            if (location.Controller != null)
            {
                var controller = location.Controller;
                var position = controller.FindItemRootPosition(id);
                if (position.x < 0 || !controller.RemoveItem(location.Item)) return false;
                location.Commit?.Invoke();
                rollback = () =>
                {
                    if (controller.IsDisposed ||
                        !controller.PlaceExistingItem(location.Item, position.x, position.y)) return false;
                    location.Commit?.Invoke();
                    return true;
                };
            }
            else
            {
                var original = location.Saved[location.Index];
                location.Saved.RemoveAt(location.Index);
                location.Commit();
                rollback = () =>
                {
                    location.Saved.Insert(location.Index, original);
                    location.Commit();
                    return true;
                };
            }
            return true;
        }

        private static bool ReturnVirtual(K_InventoryUI ui, AppliedMedicalRecord record, bool place)
        {
            var data = K_InventorySetup.DatabaseInstance?.GetItemData(record.VirtualItemID);
            if (data == null || record.InstanceID == 0 || record.VirtualQuantity <= 0) return false;
            var item = new InventoryItem(data, record.InstanceID, record.VirtualQuantity,
                record.VirtualDurability, false, record.ChargePercent, record.RemainingSeconds);
            var roots = Roots(ui);
            // Stage 4: all three root grids have priority over every nested backpack.
            foreach (var root in roots)
                if (TryPlaceInController(root, item, place)) return true;
            var visited = new HashSet<uint>();
            foreach (var root in roots)
                if (TryPlaceInBackpacks(root, item, place, visited, 0)) return true;
            return false;
        }

        private static bool TryPlaceInController(InventoryController controller, InventoryItem item, bool place)
        {
            if (controller == null || controller.IsDisposed) return false;
            for (int orientation = 0; orientation < (item.Data.CanRotate ? 2 : 1); orientation++)
            {
                for (int y = 0; y <= controller.Height - item.CurrentSize.y; y++)
                    for (int x = 0; x <= controller.Width - item.CurrentSize.x; x++)
                    {
                        bool empty = true;
                        for (int dy = 0; dy < item.CurrentSize.y && empty; dy++)
                            for (int dx = 0; dx < item.CurrentSize.x; dx++)
                                if (controller.GetItemAt(x + dx, y + dy) != null) { empty = false; break; }
                        if (empty && (!place || controller.PlaceExistingItem(item, x, y))) return true;
                    }
                if (item.Data.CanRotate) item.Rotate();
            }
            return false;
        }

        private static bool TryPlaceInBackpacks(InventoryController controller, InventoryItem item,
            bool place, HashSet<uint> visited, int depth)
        {
            if (controller == null || controller.IsDisposed || depth > 32) return false;
            for (int y = 0; y < controller.Height; y++)
                for (int x = 0; x < controller.Width; x++)
                {
                    var owner = controller.GetItemAt(x, y);
                    if (owner?.Data == null || !owner.Data.IsBackpack ||
                        !controller.IsRootCell(owner.InstanceID, x, y) || !visited.Add(owner.InstanceID)) continue;
                    var inner = owner.GetBackpackController();
                    bool found;
                    if (inner != null && !inner.IsDisposed)
                    {
                        found = TryPlaceInController(inner, item, place) ||
                            TryPlaceInBackpacks(inner, item, place, visited, depth + 1);
                        if (found && place)
                        { owner.MarkBackpackContentsDirty(); owner.SyncBackpackContentsIfDirty(); controller.RefreshItemInData(owner); }
                    }
                    else
                    {
                        var contents = owner.GetBackpackSavedItems();
                        found = TryPlaceInSaved(contents, owner.Data, item, place, depth + 1);
                        if (found && place)
                        { owner.ReplaceBackpackContents(new List<SavedItem>(contents)); controller.RefreshItemInData(owner); }
                    }
                    if (found) return true;
                }
            return false;
        }

        private static bool TryPlaceInSaved(List<SavedItem> contents, ItemStaticData owner,
            InventoryItem item, bool place, int depth)
        {
            if (contents == null || owner == null || depth > 32) return false;
            int width = owner.BackpackWidth, height = owner.BackpackHeight;
            if (width > 0 && height > 0)
            {
                var occupied = new bool[width, height];
                foreach (var saved in contents)
                {
                    var template = K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID);
                    if (template == null) return false; // Unknown footprints cannot be treated as empty.
                    var existing = InventoryItem.FromSaveData(saved, template);
                    var size = existing.CurrentSize;
                    if (saved.X < 0 || saved.Y < 0 || saved.X + size.x > width || saved.Y + size.y > height) return false;
                    for (int dy = 0; dy < size.y; dy++)
                        for (int dx = 0; dx < size.x; dx++) occupied[saved.X + dx, saved.Y + dy] = true;
                }
                for (int orientation = 0; orientation < (item.Data.CanRotate ? 2 : 1); orientation++)
                {
                    var size = item.CurrentSize;
                    for (int y = 0; y <= height - size.y; y++)
                        for (int x = 0; x <= width - size.x; x++)
                        {
                            bool empty = true;
                            for (int dy = 0; dy < size.y && empty; dy++)
                                for (int dx = 0; dx < size.x; dx++)
                                    if (occupied[x + dx, y + dy]) { empty = false; break; }
                            if (!empty) continue;
                            if (place) contents.Add(item.ToSaveData(x, y));
                            return true;
                        }
                    if (item.Data.CanRotate) item.Rotate();
                }
            }
            for (int i = 0; i < contents.Count; i++)
            {
                var saved = contents[i];
                var template = K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID);
                if (template == null || !template.IsBackpack) continue;
                if (saved.BackpackContents == null)
                {
                    if (!place)
                    {
                        if (TryPlaceInSaved(new List<SavedItem>(), template, item, false, depth + 1)) return true;
                        continue;
                    }
                    saved.BackpackContents = new List<SavedItem>();
                }
                if (!TryPlaceInSaved(saved.BackpackContents, template, item, place, depth + 1)) continue;
                if (place) contents[i] = saved;
                return true;
            }
            return false;
        }
    }
}
