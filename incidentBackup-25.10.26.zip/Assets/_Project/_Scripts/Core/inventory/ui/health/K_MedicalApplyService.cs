
using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Этап 6.6: сервис применения медикаментов.
    /// Инкапсулирует apply-сессию: прогресс, эффекты, списание, отмену по урону.
    ///
    /// Не MonoBehaviour. Не рисует UI. Не работает с K_DropZoneRegistry —
    /// визуал делает K_MedicalMirrorPanel через события сервиса.
    ///
    /// СИНХРОННЫЙ. Без Coroutine / async / Task / yield.
    /// </summary>
    public sealed class K_MedicalApplyService
    {
        private const float APPLY_LOG_INTERVAL = 0.25f;

        private readonly K_HealthSystem _health;
        private readonly K_BloodSystem _blood;
        private readonly K_VitalitySystem _vitality;
        private readonly K_DebuffSystem _debuff;
        private readonly MedicalDatabase _medicalDatabase;
        private readonly K_InventoryUI _inventoryUI;
        private readonly MedicalInventoryService _fallbackMedicalInventoryService;

        private K_MedicalApplyController _applyController;
        private MedicalItemRecord _appliedRecord;
        private BodyPart _appliedPart;
        private MedicalEffectApplier _effectApplier;
        private float _applyLogTimer;
        private bool _healthSubscribed;
        private bool _healthSystemWarned;
        private bool _publishingProgress;

        public event Action<MedicalItemRecord, BodyPart> OnApplyStarted;
        public event Action<MedicalItemRecord, float>    OnApplyProgress;
        public event Action<MedicalItemRecord, BodyPart> OnApplyCompleted;
        public event Action<MedicalItemRecord, BodyPart> OnApplyCancelled;

        public bool IsApplying => _applyController != null && _applyController.IsRunning;
        public BodyPart AppliedPart => _appliedPart;
        public MedicalItemRecord AppliedRecord => _appliedRecord;
        public K_MedicalMirrorItem SourceWidget => _applyController?.SourceWidget;
        public float Progress => _applyController != null ? _applyController.Progress : 0f;
        // Stage 4: контекстное меню использует тот же экземпляр здоровья.
        public K_HealthSystem HealthSystem => _health;
        private bool _transfusionCommitting;
        public K_BloodSystem BloodSystem => _blood;
        public K_VitalitySystem VitalitySystem => _vitality;
        public MedicalDatabase MedicalDatabase => _medicalDatabase;

        public K_MedicalApplyService(
            K_HealthSystem health,
            K_BloodSystem blood,
            K_VitalitySystem vitality,
            K_DebuffSystem debuff,
            MedicalDatabase medicalDatabase,
            K_InventoryUI inventoryUI)
        {
            _health = health;
            _blood = blood;
            _vitality = vitality;
            _debuff = debuff;
            _medicalDatabase = medicalDatabase;
            _inventoryUI = inventoryUI;
            // Stage 4: explicit DB injection also works before the health tab Start.
            (_medicalDatabase ?? MedicalDatabase.Instance)?.Initialize();
            K_AppliedMedicalInventoryBridge.Initialize(_inventoryUI, _health);
            _health?.AppliedMedical?.ConfigureMedicalDatabase(_medicalDatabase ?? MedicalDatabase.Instance);
        }

        /// <summary>Supports explicit inventory ownership when no inventory UI is present.</summary>
        public K_MedicalApplyService(
            K_HealthSystem health,
            K_BloodSystem blood,
            K_VitalitySystem vitality,
            K_DebuffSystem debuff,
            MedicalDatabase medicalDatabase,
            K_InventoryUI inventoryUI,
            MedicalInventoryService medicalInventoryService)
            : this(health, blood, vitality, debuff, medicalDatabase, inventoryUI)
        {
            _fallbackMedicalInventoryService = medicalInventoryService;
        }

        public void Subscribe()
        {
            if (_healthSubscribed) return;

            if (_health == null)
            {
                if (!_healthSystemWarned)
                {
                    _healthSystemWarned = true;
                    Debug.LogWarning("[K_MedicalApplyService] K_HealthSystem not assigned — " +
                                     "damage cancellation for apply is disabled.");
                }
                return;
            }

            _health.OnDamageTaken += HandleDamageDuringApply;
            _health.OnSegmentDamageApplied += HandleDamageDuringApply;
            _health.OnDeath += HandleDeathDuringApply;
            _healthSubscribed = true;
        }

        public void Unsubscribe()
        {
            if (!_healthSubscribed) return;
            if (_health != null)
                _health.OnDamageTaken -= HandleDamageDuringApply;
            if (_health != null)
            {
                _health.OnSegmentDamageApplied -= HandleDamageDuringApply;
                _health.OnDeath -= HandleDeathDuringApply;
            }
            _healthSubscribed = false;
        }

        public bool TryStartApply(
            MedicalItemRecord record, BodyPart part, K_MedicalMirrorItem sourceWidget)
        {
            if (IsApplying) return false;
            if (record.Item == null || record.Item.Data == null) return false;

            // Stage 4: механические средства устанавливаются мгновенно и остаются
            // в своём слоте. Обычный progress/Consume для этой ветки не запускается.
            if (K_AppliedMedicalManager.TryGetKind(
                _medicalDatabase ?? MedicalDatabase.Instance, record.Item.Data.ItemID, out var kind))
            {
                var source = K_AppliedMedicalInventoryBridge.FindController(
                    _inventoryUI, record.Item.InstanceID);
                if (!K_AppliedMedicalInventoryBridge.TryApply(
                    _inventoryUI, _health, record.Item, source, part, kind, out var reason))
                {
                    Debug.LogWarning($"[K_MedicalApplyService] {reason}");
                    return false;
                }
                Debug.Log($"[K_MedicalApplyService] Applied {kind}: " +
                          $"{record.Item.Data.DisplayName} → {part}");
                OnApplyCompleted?.Invoke(record, part);
                return true;
            }
            if (_medicalDatabase == null ||
                !_medicalDatabase.IsApplicable(record.Item.Data.ItemID, part)) return false;

            if (_health != null && _health.IsDead)
            {
                Debug.LogWarning("[K_MedicalApplyService] Cannot apply medicine: player is dead.");
                return false;
            }
            if (!CanApplyItem(record.Item.Data.ItemID, part, out _, out var applyReason))
            {
                Debug.LogWarning($"[K_MedicalApplyService] Нельзя применить: {applyReason}");
                return false;
            }

            if (record.Item.Data.ChargeCategory == ChargeCategory.AmountAbsolute &&
                (_medicalDatabase.GetEffects(record.Item.Data.ItemID) & MedicalEffect.BloodRestore) != 0)
            {
                if (record.Item.Quantity != 1 || record.Item.RemainingChargeAmount <= 0f) return false;
                if (_inventoryUI != null) return _inventoryUI.TryOpenTransfusionQuantity(record, part);
                // Without a UI the existing timed apply remains available, but commits
                // only the volume actually transferred rather than consuming the bag.
            }

            float duration = _medicalDatabase.GetUseDuration(record.Item.Data.ItemID);
            if (float.IsNaN(duration) || float.IsInfinity(duration) || duration <= 0f)
            {
                Debug.LogWarning(
                    $"[K_MedicalApplyService] Cannot apply '{record.Item.Data.ItemID}': duration must be finite and > 0.");
                return false;
            }

            if (_applyController == null)
                _applyController = new K_MedicalApplyController();

            // The item owns the apply session. Its pooled view may be rebuilt or
            // hidden while the same item continues to be used.
            if (!_applyController.Begin(record, part, duration, null))
                return false;

            _appliedRecord = record;
            _appliedPart = part;
            _applyLogTimer = 0f;

            Debug.Log($"[K_MedicalApplyService] Apply started: " +
                      $"{record.Item.Data.DisplayName} → {part} (duration={duration:F2}s)");
            OnApplyStarted?.Invoke(record, part);
            return true;
        }

        public void CancelApply(string reason)
        {
            if (_applyController == null || !_applyController.IsRunning) return;

            var rec = _applyController.Record;
            var part = _applyController.Part;
            _applyController.Cancel();

            HandleApplyCancelled(rec, part, reason);
        }

        public void Tick(float deltaTime)
        {
            if (_publishingProgress) return;
            if (_applyController == null || !_applyController.IsRunning) return;

            ulong generation = _applyController.Generation;

            bool completed = _applyController.Tick(deltaTime * (_vitality != null ? _vitality.ActionSpeedMult : 1f));

            var rec = _applyController.Record;
            float progress = _applyController.Progress;

            _applyLogTimer += deltaTime;
            if (_applyLogTimer >= APPLY_LOG_INTERVAL || completed)
            {
                _applyLogTimer = 0f;
#if UNITY_EDITOR
                Debug.Log($"[K_MedicalApplyService] Apply progress: {progress:P0} " +
                          $"({_applyController.Elapsed:F2}/{_applyController.Duration:F2}s)");
#endif
            }

            _publishingProgress = true;
            try
            {
            OnApplyProgress?.Invoke(rec, progress);
            }
            finally { _publishingProgress = false; }

            if (_applyController.Generation != generation) return;

            // A progress listener can synchronously cause damage/death and cancel.
            if (!_applyController.IsRunning) return;

            if (completed)
            {
                var part = _applyController.Part;
                _applyController.Cancel();
                HandleApplyCompleted(rec, part);
            }
        }

        /// <summary>
        /// Возвращает сегменты, на которые медикамент реально поможет в текущем
        /// состоянии игрока. Пустой список — если ничего не подходит.
        /// Уже отсортирован по приоритету: голова → грудь → торс → конечности.
        /// </summary>
        public List<BodyPart> GetValidPartsForItem(string itemID)
        {
            var result = new List<BodyPart>();
            if (string.IsNullOrEmpty(itemID)) return result;

            // Stage 4: подсветка только четырёх родителей и только по текущей травме.
            if (K_AppliedMedicalManager.TryGetKind(
                _medicalDatabase ?? MedicalDatabase.Instance, itemID, out var kind))
            {
                var manager = _health?.AppliedMedical;
                if (manager == null) return result;
                var parents = new[] { BodyPart.LeftShoulder, BodyPart.RightShoulder,
                    BodyPart.LeftQuadriceps, BodyPart.RightQuadriceps };
                foreach (var parent in parents)
                    if (manager.CanApplyOnPart(parent, kind, out _)) result.Add(parent);
                return result;
            }
            if (_medicalDatabase == null) return result;
            if (!_medicalDatabase.TryGetEntry(itemID, out var entry) || entry == null) return result;

            var effects = entry.Effects;
            if (effects == MedicalEffect.None) return result;

            for (int i = 0; i < 20; i++)
            {
                var part = (BodyPart)i;
                if (!_medicalDatabase.IsApplicable(itemID, part)) continue;
                if (!EnsureEffectApplier().CanApplyEffects(effects, part, itemID, out _)) continue;
                if (!IsEffectUsefulOnPart(effects, part, itemID)) continue;
                result.Add(part);
            }

            result.Sort((a, b) => GetPartPriority(a).CompareTo(GetPartPriority(b)));
            return result;
        }

        public void Dispose()
        {
            CancelApply("service-disposed");
            Unsubscribe();
        }

        public bool CanTransfuse(MedicalItemRecord record, BodyPart part, out float maximumMl, out string reason)
        {
            maximumMl = 0f;
            reason = "переливание недоступно";
            if (IsApplying || _transfusionCommitting || (_health != null && _health.IsDead)) return false;
            var inventory = _inventoryUI?.MedicalInventoryService ?? _fallbackMedicalInventoryService;
            if (!TryGetCurrentRecord(inventory, record, out var current) ||
                !CanApplyItem(current.Item.Data.ItemID, part, out var effects, out reason) ||
                (effects & MedicalEffect.BloodRestore) == 0) return false;
            maximumMl = K_ConsumableService.GetTransfusionMaximum(current.Item, _blood,
                _medicalDatabase.GetBloodRestoreMl(current.Item.Data.ItemID));
            if (maximumMl > 0f) { reason = null; return true; }
            reason = "кровь уже заполнена, пакет пуст или настройка заряда недопустима";
            return false;
        }

        public bool TryTransfuse(MedicalItemRecord record, BodyPart part, float selectedMl,
            out float transferredMl, out string reason)
        {
            transferredMl = 0f;
            reason = "переливание недоступно";
            if (IsApplying || _transfusionCommitting || (_health != null && _health.IsDead)) return false;
            var inventory = _inventoryUI?.MedicalInventoryService ?? _fallbackMedicalInventoryService;
            if (!TryGetCurrentRecord(inventory, record, out var current) ||
                !CanApplyItem(current.Item.Data.ItemID, part, out var effects, out reason) ||
                (effects & MedicalEffect.BloodRestore) == 0) return false;
            _transfusionCommitting = true;
            try
            {
            if (!K_ConsumableService.TryTransfuse(current.Item, selectedMl, _blood,
                _medicalDatabase.GetBloodRestoreMl(current.Item.Data.ItemID),
                (amount, applyBlood) => inventory.TryConsumeCharge(current, amount, () =>
                {
                    // Each effect mutates state before its own notification. Preserve
                    // all declared effects if an observer of one of them throws.
                    try { applyBlood(); } catch (Exception exception) { Debug.LogException(exception); }
                    EnsureEffectApplier().ApplyEffects(effects & ~MedicalEffect.BloodRestore, part, current.Item.Data.ItemID);
                }), out transferredMl, out reason)) return false;
            _appliedRecord = default;
            _appliedPart = default;
            _applyLogTimer = 0f;
            try { _inventoryUI?.ForceRefresh(); } catch (Exception exception) { Debug.LogException(exception); }
            Debug.Log($"[Medical] Transfused {transferredMl:F1} ml; bag remaining {current.Item.RemainingChargeAmount:F1} ml");
            try { OnApplyCompleted?.Invoke(current, part); } catch (Exception exception) { Debug.LogException(exception); }
            return true;
            }
            finally { _transfusionCommitting = false; }
        }

        // ── internal ──

        private static int GetPartPriority(BodyPart part) => part switch
        {
            BodyPart.Head    => 0,
            BodyPart.Chest   => 1,
            BodyPart.Stomach => 2,
            BodyPart.Pelvis  => 3,
            _                => 4,
        };

        private bool IsEffectUsefulOnPart(MedicalEffect effects, BodyPart part, string itemID)
        {
            if (_health != null && _health.IsDead) return false;
            if (_health != null)
            {
                var laceration = _health.GetLacerationType(part);
                if ((effects & (MedicalEffect.Laceration_Strips | MedicalEffect.Laceration_Staples)) != 0
                    && (laceration == LacerationType.Open || laceration == LacerationType.Glued))
                    return true;

                if ((effects & MedicalEffect.Laceration_Glue) != 0 && laceration == LacerationType.Open)
                    return true;

                if ((effects & MedicalEffect.InternalBleeding) != 0
                    && _health.HasInternalBleeding(part) && _health.CanApplyCoagulant())
                    return true;
                if ((effects & MedicalEffect.Transamacha) != 0 && _health.HasInternalBleeding(part))
                    return true;

                if ((effects & MedicalEffect.Collar) != 0 && part == BodyPart.Head
                    && (_health.IsFractured(BodyPart.Head) || (_debuff != null && _debuff.HasTBI)))
                    return true;

                if ((effects & MedicalEffect.Fracture) != 0
                    && _health.IsFractured(part) && !_health.IsSplinted(part))
                    return true;

                if ((effects & MedicalEffect.Gunshot) != 0 && _health.IsGunshot(part))
                    return true;

                // 6.6 (уточнение 3): бинт — только L1-L2.
                if ((effects & MedicalEffect.BleedingLight) != 0)
                {
                    int lvl = _health.GetBleedingLevel(part);
                    // Iteration 1 IH02: core bandaging also accepts L3.
                    if (lvl == 3) return true;
                    if (lvl >= 1 && lvl <= 2) return true;
                }

                if ((effects & MedicalEffect.BleedingArterial) != 0
                    && _health.GetBleedingLevel(part) == 3)
                    return true;

                if ((effects & MedicalEffect.BleedingFull) != 0
                    && _health.GetBleedingLevel(part) > 0)
                    return true;

                if ((effects & MedicalEffect.Laceration) != 0 &&
                    (laceration == LacerationType.Open || laceration == LacerationType.Glued))
                    return true;

                if ((effects & MedicalEffect.HPRestore) != 0) // deprecated 6.4.2
                {
                    if (_health.CanRestoreHP(part)) return true;
                }
            }

            if ((effects & MedicalEffect.BloodRestore) != 0
                && _blood != null && _blood.BloodPercent < 1f)
                return true;

            if ((effects & MedicalEffect.Stimulator) != 0 && _vitality != null && _vitality.IsStimReady) return true;
            if ((effects & MedicalEffect.Painkiller) != 0 && _debuff != null && _medicalDatabase != null &&
                _debuff.CanActivatePainkiller(_medicalDatabase.GetEffectDuration(itemID))) return true;
            if ((effects & MedicalEffect.HealBoost) != 0 && _health != null && _medicalDatabase != null &&
                _health.CanExtendHealBoost(part, _medicalDatabase.GetEffectDuration(itemID))) return true;

            return false;
        }

        private bool CanApplyItem(string itemID, BodyPart part, out MedicalEffect effects, out string reason)
        {
            effects = _medicalDatabase != null ? _medicalDatabase.GetEffects(itemID) : MedicalEffect.None;
            reason = "медикамент не подходит для выбранной зоны";
            if (_medicalDatabase == null || !_medicalDatabase.IsApplicable(itemID, part)) return false;
            if (!EnsureEffectApplier().CanApplyEffects(effects, part, itemID, out reason)) return false;
            if (IsEffectUsefulOnPart(effects, part, itemID)) return true;
            reason = "эффект больше не нужен";
            return false;
        }

        private MedicalEffectApplier EnsureEffectApplier()
        {
            if (_effectApplier == null)
                _effectApplier = new MedicalEffectApplier(
                    _health, _blood, _vitality, _debuff, _medicalDatabase);
            return _effectApplier;
        }

        private void HandleApplyCompleted(MedicalItemRecord record, BodyPart part)
        {
            if (_health != null && _health.IsDead)
            {
                HandleApplyCancelled(record, part, "death-before-commit");
                return;
            }

            var medicalService = _inventoryUI?.MedicalInventoryService;
            if (medicalService == null)
                medicalService = _fallbackMedicalInventoryService;
            if (!TryGetCurrentRecord(medicalService, record, out var currentRecord))
            {
                HandleApplyCancelled(record, part, "item-unavailable");
                return;
            }

            var itemData = currentRecord.Item.Data;
            if (!CanApplyItem(itemData.ItemID, part, out var effects, out _))
            {
                Debug.Log("[Medical] Effect no longer useful, cancelled");
                HandleApplyCancelled(record, part, "effect-no-longer-useful");
                return;
            }
            if (itemData.ChargeCategory == ChargeCategory.AmountAbsolute &&
                (effects & MedicalEffect.BloodRestore) != 0)
            {
                if (!TryTransfuse(currentRecord, part, float.MaxValue, out _, out var reason))
                    HandleApplyCancelled(record, part, reason);
                return;
            }
            if (!medicalService.Consume(currentRecord))
            {
                HandleApplyCancelled(record, part, "item-unavailable");
                return;
            }

            _appliedRecord = default;
            _appliedPart = default;
            _applyLogTimer = 0f;

            EnsureEffectApplier().ApplyEffects(effects, part, itemData.ItemID);

            _inventoryUI?.ForceRefresh();

            Debug.Log($"[K_MedicalApplyService] Apply completed: " +
                      $"{currentRecord.Item?.Data?.DisplayName} → {part}");
            OnApplyCompleted?.Invoke(currentRecord, part);
        }

        private static bool TryGetCurrentRecord(MedicalInventoryService medicalService,
            MedicalItemRecord originalRecord, out MedicalItemRecord currentRecord)
        {
            currentRecord = default;
            if (medicalService == null || originalRecord.Item == null) return false;

            // Resolve ownership again: the item may have moved between grids or
            // its backpack may have switched from a live controller to saved data.
            medicalService.MarkDirty();
            var records = medicalService.GetMedicalItems();
            for (int i = 0; i < records.Count; i++)
            {
                var candidate = records[i];
                if (candidate.Item != null && candidate.Item.Quantity > 0 &&
                    candidate.Item.InstanceID == originalRecord.Item.InstanceID)
                {
                    currentRecord = candidate;
                    return true;
                }
            }
            return false;
        }

        private void HandleApplyCancelled(
            MedicalItemRecord record, BodyPart part, string reason)
        {
            _appliedRecord = default;
            _appliedPart = default;
            _applyLogTimer = 0f;

            Debug.Log($"[K_MedicalApplyService] Apply cancelled ({reason}): " +
                      $"{record.Item?.Data?.DisplayName} → {part}");
            OnApplyCancelled?.Invoke(record, part);
        }

        private void HandleDamageDuringApply(BodyPart part, float damage, DamageType type)
        {
            if (!IsApplying) return;
            if (_medicalDatabase == null) return;

            var rec = _applyController.Record;
            if (rec.Item == null || rec.Item.Data == null) return;

            if (_medicalDatabase.IsCancelableByDamage(rec.Item.Data.ItemID))
                CancelApply("damage");
        }

        private void HandleDeathDuringApply()
        {
            if (!IsApplying) return;
            CancelApply("death");
        }
    }
}
