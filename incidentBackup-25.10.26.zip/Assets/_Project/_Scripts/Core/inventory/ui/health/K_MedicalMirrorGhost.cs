using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Этап 6.1: лёгкий ghost для drag-сессии зеркала медикаментов.
    ///
    /// Программная генерация: Canvas (ScreenSpaceOverlay, overrideSorting)
    ///   → Icon (Image, preserveAspect)
    ///   → Qty  (TMP, в правом-нижнем углу)
    ///
    /// Отдельный Canvas с sortingOrder = 32000 — по образцу
    /// DragGhostPresenter.GHOST_SORTING_ORDER. Ghost всегда поверх любого UI.
    ///
    /// Все Graphic — raycastTarget = false. CanvasGroup.blocksRaycasts = false.
    /// Курсор и события мыши проходят сквозь ghost.
    ///
    /// СИНХРОННЫЙ. Без Coroutine / async / Task / yield.
    /// </summary>
    public sealed class K_MedicalMirrorGhost
    {
        /// <summary>По образцу DragGhostPresenter.GHOST_SORTING_ORDER.</summary>
        public const int GHOST_SORTING_ORDER = 32000;

        private GameObject _root;
        private RectTransform _rootRT;
        private Image _icon;
        private TextMeshProUGUI _qty;

        private RectTransform _canvasRect;      // родительский root-canvas RT
      private UnityEngine.Camera _canvasCamera;  // null для ScreenSpaceOverlay     // null для ScreenSpaceOverlay

        public bool IsValid => _root != null && _rootRT != null;

        /// <summary>
        /// Создаёт ghost-объект и парентит его под указанный canvas.
        /// Идемпотентно: повторный вызов — no-op.
        /// </summary>
       public void Initialize(Transform parentCanvas, UnityEngine.Camera canvasCamera)
        {
            if (_root != null) return;

            _canvasRect = parentCanvas as RectTransform;
            _canvasCamera = canvasCamera;

            _root = new GameObject("K_MedicalMirrorGhost",
                typeof(RectTransform), typeof(Canvas), typeof(CanvasGroup));
            _rootRT = _root.GetComponent<RectTransform>();
            _rootRT.anchorMin = new Vector2(0.5f, 0.5f);
            _rootRT.anchorMax = new Vector2(0.5f, 0.5f);
            _rootRT.pivot     = new Vector2(0.5f, 0.5f);
            _rootRT.anchoredPosition = Vector2.zero;
            _rootRT.sizeDelta = new Vector2(64f, 64f);
            _rootRT.localScale = Vector3.one;
            _rootRT.localRotation = Quaternion.identity;

            var canvas = _root.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.overrideSorting = true;
            canvas.sortingOrder = GHOST_SORTING_ORDER;

            var cg = _root.GetComponent<CanvasGroup>();
            cg.alpha = 1f;
            cg.interactable = false;
            cg.blocksRaycasts = false;

            if (parentCanvas != null)
                _root.transform.SetParent(parentCanvas, false);

            // ── Icon ──
            var iconGo = new GameObject("Icon", typeof(RectTransform), typeof(Image));
            iconGo.transform.SetParent(_root.transform, false);
            var iconRT = iconGo.GetComponent<RectTransform>();
            iconRT.anchorMin = Vector2.zero;
            iconRT.anchorMax = Vector2.one;
            iconRT.offsetMin = Vector2.zero;
            iconRT.offsetMax = Vector2.zero;
            iconRT.localScale = Vector3.one;
            _icon = iconGo.GetComponent<Image>();
            _icon.raycastTarget = false;
            _icon.preserveAspect = true;
            _icon.color = Color.white;
            _icon.enabled = false;

            // ── Qty ──
            var qtyGo = new GameObject("Qty", typeof(RectTransform), typeof(TextMeshProUGUI));
            qtyGo.transform.SetParent(_root.transform, false);
            var qtyRT = qtyGo.GetComponent<RectTransform>();
            qtyRT.anchorMin = new Vector2(1f, 0f);
            qtyRT.anchorMax = new Vector2(1f, 0f);
            qtyRT.pivot     = new Vector2(1f, 0f);
            qtyRT.anchoredPosition = new Vector2(-2f, 2f);
            qtyRT.sizeDelta = new Vector2(32f, 16f);
            qtyRT.localScale = Vector3.one;
            _qty = qtyGo.GetComponent<TextMeshProUGUI>();
            _qty.alignment = TextAlignmentOptions.BottomRight;
            _qty.fontSize = 12f;
            _qty.fontStyle = FontStyles.Bold;
            _qty.color = Color.white;
            _qty.raycastTarget = false;
            _qty.textWrappingMode = TextWrappingModes.NoWrap;
            _qty.overflowMode = TextOverflowModes.Overflow;
            _qty.outlineColor = new Color(0f, 0f, 0f, 0.85f);
            _qty.outlineWidth = 0.2f;
            if (_qty.font == null && TMP_Settings.defaultFontAsset != null)
                _qty.font = TMP_Settings.defaultFontAsset;

            _root.SetActive(false);
        }

        /// <summary>
        /// Показывает ghost с иконкой и количеством указанного предмета.
        /// </summary>
        public void Show(InventoryItem item, float size)
        {
            if (!IsValid || item == null || item.Data == null) return;

            float s = size > 0f ? size : 64f;
            _rootRT.sizeDelta = new Vector2(s, s);

            if (_icon != null)
            {
                _icon.sprite = item.CurrentIcon;
                _icon.enabled = _icon.sprite != null;
            }

            if (_qty != null)
            {
                if (item.Quantity > 1)
                {
                    _qty.text = item.Quantity.ToString();
                    if (!_qty.gameObject.activeSelf) _qty.gameObject.SetActive(true);
                }
                else
                {
                    _qty.text = string.Empty;
                    if (_qty.gameObject.activeSelf) _qty.gameObject.SetActive(false);
                }
            }

            if (!_root.activeSelf) _root.SetActive(true);
            _rootRT.SetAsLastSibling();
        }

        /// <summary>
        /// Переводит ghost в точку screen space (eventData.position).
        /// </summary>
        public void SetScreenPosition(Vector2 screenPos)
        {
            if (!IsValid || _canvasRect == null) return;
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    _canvasRect, screenPos, _canvasCamera, out Vector2 local))
            {
                _rootRT.anchoredPosition = local;
            }
        }

        public void Hide()
        {
            if (_root != null && _root.activeSelf)
                _root.SetActive(false);
        }

        public void Destroy()
        {
            if (_root != null)
            {
                Object.Destroy(_root);
                _root = null;
                _rootRT = null;
                _icon = null;
                _qty = null;
                _canvasRect = null;
                _canvasCamera = null;
            }
        }
    }
}