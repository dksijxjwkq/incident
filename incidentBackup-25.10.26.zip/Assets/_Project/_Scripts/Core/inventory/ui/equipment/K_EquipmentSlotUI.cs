
using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
  public enum EquipmentSlotType { Primary, Pistol, Melee, Backpack, BodyArmor, HeadGear }

    /// <summary>
    /// UI слота экипировки.
    /// Поддерживает силуэты для пустых слотов, кастомные метки.
    /// </summary>
    public class K_EquipmentSlotUI : MonoBehaviour,
        IPointerClickHandler,
        IPointerEnterHandler,
        IPointerExitHandler,
        IDropHandler,
        IBeginDragHandler,
        IDragHandler,
        IEndDragHandler
    {
        #region Constants

        private const float FLASH_ERROR_DURATION = 0.15f;
        private const float HOVER_THROTTLE = 0.2f;
        private const float DROP_FEEDBACK_DURATION = 0.1f;

        private static readonly Color COLOR_VALID_DROP = new Color(0.2f, 0.8f, 0.2f, 0.6f);
        private static readonly Color COLOR_INVALID_DROP = new Color(0.9f, 0.2f, 0.2f, 0.6f);
        private static readonly Color COLOR_HOVER = new Color(1f, 1f, 1f, 0.15f);
        private static readonly Color COLOR_ITEM_HOVER = new Color(1f, 0.85f, 0f, 0.35f);

        private static readonly Vector2 SIZE_PRIMARY = new Vector2(130f, 315f);
        private static readonly Vector2 SIZE_PISTOL = new Vector2(120f, 120f);
        private static readonly Vector2 SIZE_MELEE = new Vector2(120f, 120f);
        private static readonly Vector2 SIZE_BACKPACK = new Vector2(100f, 100f);

        #endregion

        #region Inspector Fields

        [SerializeField] private Image _icon;
        [SerializeField] private TextMeshProUGUI _label;
        [SerializeField] private Image _highlight;
        [SerializeField, Tooltip("Тип слота: Primary, Pistol, Melee, Backpack")]
        private EquipmentSlotType _slotType;

        [Header("Custom Label")]
        [SerializeField, Tooltip("Кастомная метка слота. Если пусто — используется стандартная по типу.")]
        private string _customLabel = "";

       [Header("Empty Slot Silhouette")]
[SerializeField, Tooltip("Силуэт предмета для пустого слота. Показывается полупрозрачным, чтобы игрок понимал что сюда можно положить.")]
private Sprite _emptySlotSprite;
[SerializeField, Tooltip("Цвет силуэта в пустом слоте.")]
private Color _emptySlotColor = new Color(0.5f, 0.5f, 0.5f, 0.5f);
[SerializeField, Range(0f, 1f), Tooltip("Множитель яркости силуэта пустого слота. " +
    "1 = как задано в _emptySlotColor; меньше — темнее. " +
    "Используется для выравнивания яркости между спрайтами из разных источников.")]
private float _emptySlotBrightness = 1f;
[SerializeField, Tooltip("Поворот силуэта (градусы по Z). Для оружия обычно -90.")]
private float _emptySlotRotation = -90f;

        [Header("Item Hover Highlight")]
        [SerializeField, Tooltip("Цвет подсветки при наведении на занятый слот. По умолчанию совпадает с UI_Item.")]
        private Color _itemHoverColor = new Color(1f, 0.85f, 0f, 0.35f);

        [Header("Pixel Perfect Bottom Border Fix")]
        [SerializeField, Tooltip("Цвет нижней границы. Подбери под цвет рамки слота.")]
        private Color _bottomBorderColor = new Color(0.3f, 0.3f, 0.3f, 1f);
        [SerializeField, Tooltip("Толщина нижней границы (px).")]
        private float _bottomBorderHeight = 1f;
        [SerializeField, Tooltip("Сдвиг границы вверх от математического низа (px).")]
        private float _bottomBorderOffset = 1f;

        #endregion

        #region Fields

   public event Action<K_EquipmentSlotUI, InventoryItem, InventoryItem> OnEquipmentChanged;
        public event Action<K_EquipmentSlotUI, bool> OnHoverChanged;
        public event Action<K_EquipmentSlotUI, InventoryItem> OnValidDropPreview;
        public event Action<K_EquipmentSlotUI> OnDropAccepted;
        private K_InventoryUI _inventoryUI;
        private InventoryItem _equippedItem;
        private RectTransform _rectTransform;
        private Coroutine _hoverThrottleCoroutine;
        private Coroutine _flashErrorCoroutine;
        private Coroutine _dropFeedbackCoroutine;
        private bool _isHovering;
        private bool _isDraggingOver;
        private bool _isDraggingFromSlot;
        private Image _itemHoverOverlay;


        #endregion

        #region Properties

        public EquipmentSlotType SlotType => _slotType;
        public bool IsOccupied => _equippedItem != null;
        public InventoryItem EquippedItem => _equippedItem;
        public float IconEulerZ => _icon != null ? _icon.rectTransform.localEulerAngles.z : 0f;

        #endregion

        #region Unity Lifecycle

     private void Awake()
{
    _rectTransform = GetComponent<RectTransform>();

    // ГАРАНТИЯ НАЛИЧИЯ ПОДПИСИ: если _label не привязан в префабе —
    // пытаемся найти дочерний "SlotLabel" или создать его программно.
    // ВАЖНО: вызывается ПОСЛЕ получения _rectTransform и ДО бордеров/оверлеев,
    // чтобы подпись оказалась под ними в иерархии.
    EnsureLabelExists();

    // R1: НЕ гасим _highlight/_icon здесь — их состоянием владеет Refresh().
    // Рамка/силуэт из префаба должны оставаться видимыми с момента Awake.
    EnsureRaycastTarget();
    DrawBottomBorderFix();
    EnsureItemHoverOverlay();

#if UNITY_EDITOR
    Debug.Log($"[SLOT-DIAG] Awake: name='{gameObject.name}' instanceID={gameObject.GetInstanceID()} " +
              $"iconRef='{(_icon != null ? _icon.gameObject.name : "null")}' iconID={(_icon != null ? _icon.gameObject.GetInstanceID() : 0)} " +
              $"emptySprite='{(_emptySlotSprite != null ? _emptySlotSprite.name : "null")}' " +
              $"emptySpriteID={(_emptySlotSprite != null ? _emptySlotSprite.GetInstanceID() : 0)} " +
              $"label='{(_label != null ? _label.gameObject.name + "/" + _label.gameObject.GetInstanceID() : "null")}'");
#endif
}

private void EnsureRaycastTarget()
{
    var allImages = GetComponents<Image>();
    foreach (var img in allImages)
    {
        if (img == null) continue;
        // R1: только отключаем raycast — НЕ трогаем sprite/color/enabled.
        img.raycastTarget = false;
    }
    Transform existing = transform.Find("SlotRaycastTarget");
    if (existing != null)
    {
        var existingImg = existing.GetComponent<Image>();
        if (existingImg != null)
        {
            existingImg.sprite = null;
            existingImg.type = Image.Type.Simple;
            existingImg.color = Color.clear;
            existingImg.raycastTarget = true;
            existingImg.enabled = true; // R2/B2: без enabled слот невидим для EventSystem
            return;
        }
    }
    var raycastObj = new GameObject("SlotRaycastTarget", typeof(RectTransform), typeof(Image));
    raycastObj.transform.SetParent(transform, false);
    raycastObj.transform.SetAsFirstSibling();
    var rt = raycastObj.GetComponent<RectTransform>();
    rt.anchorMin = Vector2.zero;
    rt.anchorMax = Vector2.one;
    rt.pivot = new Vector2(0.5f, 0.5f);
    rt.anchoredPosition = Vector2.zero;
    rt.sizeDelta = Vector2.zero;
    var img2 = raycastObj.GetComponent<Image>();
    img2.sprite = null;
    img2.type = Image.Type.Simple;
    img2.color = Color.clear;
    img2.raycastTarget = true;
    img2.enabled = true;
}
        private void DrawBottomBorderFix()
        {
            if (_rectTransform == null) return;

            Transform existing = transform.Find("SlotBottomBorderFix");
            if (existing != null) Destroy(existing);

            var obj = new GameObject("SlotBottomBorderFix", typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(transform, false);

            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(1f, 0f);
            rt.pivot = new Vector2(0.5f, 0f);
            rt.anchoredPosition = new Vector2(0f, _bottomBorderOffset);
            rt.sizeDelta = new Vector2(0f, _bottomBorderHeight);

            var img = obj.GetComponent<Image>();
            img.color = _bottomBorderColor;
            img.raycastTarget = false;
            img.maskable = true;
        }

           public void Initialize(K_InventoryUI inventoryUI, EquipmentSlotType slotType)
{
    _inventoryUI = inventoryUI;
    _slotType = slotType;

#if UNITY_EDITOR
    Debug.Log($"[SLOT-DIAG] Init: name='{gameObject.name}' instanceID={gameObject.GetInstanceID()} " +
              $"slotType={_slotType} " +
              $"iconObj='{(_icon != null ? _icon.gameObject.name : "null")}' iconID={(_icon != null ? _icon.gameObject.GetInstanceID() : 0)} " +
              $"emptySprite='{(_emptySlotSprite != null ? _emptySlotSprite.name : "null")}' emptySpriteID={(_emptySlotSprite != null ? _emptySlotSprite.GetInstanceID() : 0)} " +
              $"rotation={_emptySlotRotation} " +
              $"label='{_label?.text}'");
#endif

    if (_rectTransform != null)
        _rectTransform.sizeDelta = GetSlotSize(slotType);
    UpdateLabelText();
    Refresh();
}

      private static Vector2 GetSlotSize(EquipmentSlotType type) => type switch
{
    EquipmentSlotType.Primary => new Vector2(130f, 315f),
    EquipmentSlotType.Pistol => new Vector2(120f, 120f),
    EquipmentSlotType.Melee => new Vector2(120f, 120f),
    EquipmentSlotType.Backpack => new Vector2(100f, 100f),
    EquipmentSlotType.BodyArmor => new Vector2(120f, 120f),
    EquipmentSlotType.HeadGear => new Vector2(120f, 120f),
    _ => new Vector2(120f, 120f)
};

  /// <summary>
/// Обновляет текст подписи слота по трём состояниям:
///   1. Слот ЗАНЯТ  → DisplayName экипированного предмета (_customLabel игнорируется).
///   2. Слот ПУСТ и задан _customLabel → _customLabel.
///   3. Слот ПУСТ и _customLabel пуст → дефолт по _slotType.
/// </summary>
private void UpdateLabelText()
{
    if (_label == null) return;

    // (1) Занятый слот: имя предмета имеет приоритет над кастомной меткой.
    if (_equippedItem != null && _equippedItem.Data != null)
    {
        _label.text = _equippedItem.Data.DisplayName;
        return;
    }

    // (2) Пустой слот + кастомная метка.
    if (!string.IsNullOrEmpty(_customLabel))
    {
        _label.text = _customLabel;
        return;
    }

    // (3) Пустой слот + дефолт по типу. Хак gameObject.name.Contains("1") удалён —
    // для различия Primary-1 / Primary-2 используйте _customLabel в инспекторе.
    _label.text = _slotType switch
    {
        EquipmentSlotType.Primary   => "ПЕРВИЧНОЕ",
        EquipmentSlotType.Pistol    => "ПИСТОЛЕТ",
        EquipmentSlotType.Melee     => "ХОЛОДНОЕ",
        EquipmentSlotType.Backpack  => "РЮКЗАК",
        EquipmentSlotType.BodyArmor => "БРОНЯ",
        EquipmentSlotType.HeadGear  => "КАСКА",
        _ => string.Empty
    };
}

        #endregion

        /// <summary>
/// Гарантирует существование TMP-объекта подписи слота.
/// Порядок работы:
///   1. Если _label уже привязан — выходим.
///   2. Ищем существующий дочерний TMP с именем "SlotLabel" — привязываем.
///   3. Иначе создаём программно: GameObject "SlotLabel" (RectTransform + TextMeshProUGUI)
///      дочерний к _rectTransform, с параметрами из ТЗ.
/// </summary>
private void EnsureLabelExists()
{
    if (_label != null) return;

    // (1) Ищем существующий дочерний TMP с именем "SlotLabel".
    Transform existing = transform.Find("SlotLabel");
    if (existing != null)
    {
        _label = existing.GetComponent<TextMeshProUGUI>();
        if (_label != null) return;
    }

    // (2) Создаём программно.
    if (_rectTransform == null) _rectTransform = GetComponent<RectTransform>();
    if (_rectTransform == null) return; // защита от отсутствия RectTransform

    var labelObj = new GameObject("SlotLabel", typeof(RectTransform), typeof(TextMeshProUGUI));
    labelObj.transform.SetParent(_rectTransform, false);

    var rt = labelObj.GetComponent<RectTransform>();
    rt.anchorMin        = new Vector2(0f, 1f);
    rt.anchorMax        = new Vector2(1f, 1f);
    rt.pivot            = new Vector2(0.5f, 1f);
    rt.anchoredPosition = new Vector2(0f, 0f);
    rt.sizeDelta        = new Vector2(0f, 18f);
    rt.localScale       = Vector3.one;
    rt.localRotation    = Quaternion.identity;

    var tmp = labelObj.GetComponent<TextMeshProUGUI>();

    // Шрифт: как в UI_Item.EnsureNameLabel — сначала TMP_Settings.defaultFontAsset,
    // затем fallback на Resources.
    TMP_FontAsset fontAsset = TMP_Settings.defaultFontAsset;
    if (fontAsset == null)
    {
        fontAsset = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
        if (fontAsset == null)
            Debug.LogError("[K_EquipmentSlotUI] TMP font asset not found!");
    }
    tmp.font = fontAsset;

    tmp.fontSize          = 12f;
    tmp.fontStyle         = FontStyles.Bold;
    tmp.alignment         = TextAlignmentOptions.Center;
    tmp.color             = new Color(0.86f, 0.86f, 0.90f, 1f);
    tmp.raycastTarget     = false;
    tmp.overflowMode      = TextOverflowModes.Truncate;
    tmp.textWrappingMode  = TextWrappingModes.NoWrap;

    _label = tmp;
}

        #region Pointer Handlers

        public void OnPointerEnter(PointerEventData eventData)
        {
            _isHovering = true;
            if (_hoverThrottleCoroutine == null)
                _hoverThrottleCoroutine = StartCoroutine(ThrottledHoverUpdate());

            if (IsOccupied && !_isDraggingFromSlot)
                ShowItemHover();
            else if (_highlight != null && _highlight.enabled)
                _highlight.color = COLOR_HOVER;
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            _isHovering = false;
            _isDraggingOver = false;
            if (_hoverThrottleCoroutine != null)
            {
                StopCoroutine(_hoverThrottleCoroutine);
                _hoverThrottleCoroutine = null;
            }

            HideItemHover();

            if (!IsOccupied && _highlight != null && _highlight.enabled)
                _highlight.color = Color.clear;

            OnHoverChanged?.Invoke(this, false);
        }

        private IEnumerator ThrottledHoverUpdate()
        {
            yield return new WaitForSeconds(HOVER_THROTTLE);
            while (_isHovering)
            {
                OnHoverChanged?.Invoke(this, true);
                yield return new WaitForSeconds(HOVER_THROTTLE);
            }
            _hoverThrottleCoroutine = null;
        }

        #endregion

        #region Drop Handler

        public void OnDrop(PointerEventData eventData)
        {
            TriggerDropFeedback(true);
            _inventoryUI?.OnEquipmentSlotDrop(this);   
        }

        public void TriggerDropFeedback(bool isValid)
        {
            if (_highlight == null || !_highlight.enabled) return;
            if (_dropFeedbackCoroutine != null) StopCoroutine(_dropFeedbackCoroutine);
            _dropFeedbackCoroutine = StartCoroutine(FlashDropFeedback(isValid ? COLOR_VALID_DROP : COLOR_INVALID_DROP));
        }

        private IEnumerator FlashDropFeedback(Color targetColor)
        {
            if (_highlight == null) yield break;
            var originalColor = _highlight.color;
            _highlight.color = targetColor;
            yield return new WaitForSeconds(DROP_FEEDBACK_DURATION);
            if (_highlight != null)
                _highlight.color = _isHovering ? COLOR_HOVER : Color.clear;
            _dropFeedbackCoroutine = null;
        }

        #endregion

        #region Click Handler

        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Right) return;
            if (_equippedItem == null) return;

            if (K_ContextMenu.Instance != null)
            {
                K_ContextMenu.Instance.Show(_equippedItem, eventData.position, _inventoryUI, this);
            }
            else
            {
                Unequip();
            }
        }

        public void Unequip()
        {
            if (_equippedItem == null) return;
            if (_inventoryUI == null)
            {
                Debug.LogWarning("[EquipmentSlot] inventoryUI is null - cannot unequip");
                return;
            }

            bool placed = InventoryTransactionService.Instance.TryUnequipAtomic(this, out string reason);
            if (!placed)
            {
                if (_flashErrorCoroutine != null) StopCoroutine(_flashErrorCoroutine);
                _flashErrorCoroutine = StartCoroutine(FlashSlotError());
                Debug.LogWarning("[EquipmentSlot] Item stays equipped: " + reason);
            }
        }

        private IEnumerator FlashSlotError()
        {
            if (_icon == null) yield break;
            var originalColor = _icon.color;
            _icon.color = Color.red;
            yield return new WaitForSeconds(FLASH_ERROR_DURATION);
            if (_icon != null && _icon.gameObject.activeInHierarchy)
                _icon.color = originalColor;
        }

        #endregion

        #region Drag from slot

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Left) return;
            if (_equippedItem == null || _inventoryUI == null) return;
            if (_isDraggingFromSlot) return;

            _inventoryUI.StartDragFromEquipmentSlot(this, eventData);
            if (!_inventoryUI.IsDragging || _inventoryUI.DraggedFromEquipmentSlot != this) return;

            _isDraggingFromSlot = true;
            HideItemHover();

            if (_icon != null)
                _icon.color = new Color(1f, 1f, 1f, 0.5f);

        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!_isDraggingFromSlot || _inventoryUI == null) return;
            _inventoryUI.UpdateDragGhostPosition(eventData);
        }

        public void MarkDragFinished()
        {
            _isDraggingFromSlot = false;
            Refresh();
        }

        private void OnDisable()
        {
            if (_isDraggingFromSlot && _inventoryUI != null &&
                _inventoryUI.DraggedFromEquipmentSlot == this)
                _inventoryUI.EndDragFromEquipmentSlot();
            _isDraggingFromSlot = false;
        }

       public void OnEndDrag(PointerEventData eventData)
{
    if (!_isDraggingFromSlot) return;

    _isDraggingFromSlot = false;

    if (_icon != null)
    {
        // Восстанавливаем цвет только если слот всё ещё занят (отмена драга).
        // Если слот пуст (успешный дроп), не трогаем цвет — он уже установлен Refresh как силуэт.
        if (_equippedItem != null)
            _icon.color = Color.white;
        // else: оставляем как есть, потому что Refresh уже установил силуэт.
    }

    _inventoryUI?.EndDragFromEquipmentSlot();
}

        #endregion

        #region Item Management

        public void OnDropItem(InventoryItem item)
        {
#if UNITY_EDITOR
            Debug.Assert(item?.Data != null, $"[EquipmentSlot] OnDropItem called with invalid item data");
#endif
            if (!ValidateItemForSlot(item))
            {
                TriggerDropFeedback(false);
                return;
            }

            _equippedItem = item;
            Refresh();
            OnDropAccepted?.Invoke(this);
        }

      public bool ValidateItemForSlot(InventoryItem item)
{
    return InventoryValidationService.TypeMatchCheck(item, _slotType);
}

        public bool CanAcceptItemPreview(InventoryItem item)
        {
            if (IsOccupied) return false;
            return ValidateItemForSlot(item);
        }

        public void UpdateDropPreview(InventoryItem item, bool isValid)
        {
            if (_highlight == null || !_highlight.enabled) return;
            _isDraggingOver = true;
            _highlight.color = isValid ? COLOR_VALID_DROP : COLOR_INVALID_DROP;
            _highlight.enabled = true;
            OnValidDropPreview?.Invoke(this, isValid ? item : null);
        }

        public void ClearDropPreview()
        {
            _isDraggingOver = false;
            if (_highlight != null && _highlight.enabled)
                _highlight.color = _isHovering ? COLOR_HOVER : Color.clear;
        }

      public void Refresh()
{
    // НАДПИСЬ: обновляем ДО работы с _icon, чтобы текст был актуален
    // в любом состоянии. Refresh() вызывается из SetEquippedItem(),
    // значит при экипировке / снятии / swap надпись обновится автоматически.
    UpdateLabelText();

    if (_icon == null) return;

    // ФИКС v8: В слоте экипировки рюкзак ВСЕГДА показывает РАЗВЁРНУТУЮ иконку (Data.Icon),
    // независимо от IsFolded. Слот — это визуальное представление надетого рюкзака.
    Sprite displayIcon = null;
    if (_equippedItem != null)
    {
        if (_equippedItem.Data != null && _equippedItem.Data.IsBackpack && _equippedItem.CanFold)
            displayIcon = _equippedItem.Data.Icon;
        else
            displayIcon = _equippedItem.CurrentIcon;
    }

    bool hasItem = displayIcon != null;

    if (hasItem)
    {
        _icon.sprite = displayIcon;
        _icon.enabled = true;
        _icon.color = Color.white;

        float iconRotation = _slotType switch
        {
            EquipmentSlotType.Primary => -90f,
            EquipmentSlotType.Pistol  => 0f,
            EquipmentSlotType.Melee   => 0f,
            EquipmentSlotType.Backpack=> 0f,
            _ => 0f
        };

        if (_icon.rectTransform != null)
            _icon.rectTransform.localRotation = Quaternion.Euler(0f, 0f, iconRotation);
        _icon.preserveAspect = true;

        if (_label != null)
        {
            _label.gameObject.SetActive(true);
            _label.color = Color.white;
        }

        if (_isHovering && !_isDraggingFromSlot)
            ShowItemHover();
        else
            HideItemHover();
    }
    else
    {
        if (_emptySlotSprite != null)
        {
            _icon.sprite = _emptySlotSprite;
            _icon.enabled = true;

            float b = Mathf.Clamp01(_emptySlotBrightness);
            _icon.color = new Color(
                _emptySlotColor.r * b,
                _emptySlotColor.g * b,
                _emptySlotColor.b * b,
                _emptySlotColor.a);

            if (_icon.rectTransform != null)
                _icon.rectTransform.localRotation = Quaternion.Euler(0f, 0f, _emptySlotRotation);
            _icon.preserveAspect = true;
        }
        else
        {
            _icon.sprite = null;
            _icon.enabled = false;
            _icon.color = Color.white;
        }

        if (_label != null)
        {
            _label.gameObject.SetActive(true);
            _label.color = Color.white;
        }
        if (_highlight != null)
        {
            _highlight.enabled = _isHovering || _isDraggingOver;
            _highlight.color = _isDraggingOver ? COLOR_VALID_DROP : (_isHovering ? COLOR_HOVER : Color.clear);
        }
    }
}
        internal Action CaptureAtomicRestore()
        {
            var item = _equippedItem;
            return () => _equippedItem = item;
        }

      public void SetEquippedItem(InventoryItem item)
{
    if (item != null && !InventoryGridBounds.IsValidBackpack(item.Data))
        throw new System.ArgumentOutOfRangeException(nameof(item), "Equipment requires backpack dimensions between 1 and 20.");
    if (item != null && !InventoryItem.IsValidLiveQuantity(item))
        throw new System.ArgumentOutOfRangeException(nameof(item), "Equipment requires a bounded live quantity.");
    InventoryAtomicJournal.BeforeMutation(_equippedItem);
    InventoryItem oldItem = _equippedItem;
    _equippedItem = item;
    Refresh();

    if (oldItem != item)
        OnEquipmentChanged?.Invoke(this, oldItem, item);

    if (_inventoryUI is ISaveable saveable)
        saveable.IsDirty = true;
}

        private void OnDestroy()
        {
            if (_flashErrorCoroutine != null) StopCoroutine(_flashErrorCoroutine);
            if (_hoverThrottleCoroutine != null) StopCoroutine(_hoverThrottleCoroutine);
            if (_dropFeedbackCoroutine != null) StopCoroutine(_dropFeedbackCoroutine);
        }

        #endregion

        #region Item Hover Overlay

        private void EnsureItemHoverOverlay()
        {
            if (_itemHoverOverlay != null) return;

            var obj = new GameObject("ItemHoverOverlay", typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(transform, false);
            obj.transform.SetAsLastSibling();

            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = Vector2.zero;

            _itemHoverOverlay = obj.GetComponent<Image>();
            _itemHoverOverlay.sprite = null;
            _itemHoverOverlay.type = Image.Type.Simple;
            _itemHoverOverlay.color = Color.clear;
            _itemHoverOverlay.raycastTarget = false;
        }

        private void ShowItemHover()
        {
            if (_itemHoverOverlay == null) return;
            _itemHoverOverlay.transform.SetAsLastSibling();
            _itemHoverOverlay.color = _itemHoverColor;
        }

        private void HideItemHover()
        {
            if (_itemHoverOverlay == null) return;
            _itemHoverOverlay.color = Color.clear;
        }

        #endregion

        #region Editor Helpers

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (_highlight == null)
                _highlight = transform.Find("Highlight")?.GetComponent<Image>();
        }
#endif

        #endregion
    }
}














