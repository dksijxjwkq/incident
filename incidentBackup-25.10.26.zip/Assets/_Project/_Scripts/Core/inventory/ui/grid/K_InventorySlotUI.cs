using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// UI-слот инвентаря. Отображает ячейку сетки, подсветку при drag и tint занятости.
    /// Реализует IDropHandler для приёма перетаскиваемых предметов.
    /// Цель выбирается общим snap-резолвером. Для стопок общий preflight определяет
    /// merge или отказ; остальные предметы используют существующие swap / move пути.
    /// В ground-сетке разрешён только merge существующих стопок одной сессии.
    /// </summary>
    public class K_InventorySlotUI : MonoBehaviour, IDropHandler
    {
        #region Fields
        private K_InventoryUI _inventoryUI;
        private Image _backgroundImage;
        private Color _originalColor;
        private Image _cellOverlay;
        private InventoryController _boundController;
        public void BindController(InventoryController c) { _boundController = c; }
        private int _lastDropFrame = -1;
        #endregion

        #region Properties
        public int X { get; private set; }
        public int Y { get; private set; }
        public GridType GridType { get; private set; }
        public Image BackgroundImage => _backgroundImage;
        public Color CellOverlayColor => _cellOverlay != null ? _cellOverlay.color : Color.clear;
        public InventoryController BoundController => _boundController;
        #endregion

        #region Initialization
        public void Setup(int x, int y, GridType gridType, K_InventoryUI inventoryUI)
        {
            X = x;
            Y = y;
            GridType = gridType;
            _inventoryUI = inventoryUI;
            if (_backgroundImage == null)
                _backgroundImage = GetComponent<Image>();
            if (_backgroundImage != null)
            {
                _originalColor = _backgroundImage.color;
                _backgroundImage.raycastTarget = false;
            }
            EnsureCellOverlay();
        }

        public void SetRaycastEnabled(bool enabled)
        {
            if (_backgroundImage != null)
                _backgroundImage.raycastTarget = enabled;
        }

        private void EnsureCellOverlay()
        {
            Transform existing = transform.Find("CellOverlay");
            if (existing != null)
            {
                _cellOverlay = existing.GetComponent<Image>();
                if (_cellOverlay == null)
                    _cellOverlay = existing.gameObject.AddComponent<Image>();
                _cellOverlay.color = Color.clear;
                _cellOverlay.raycastTarget = false;
                return;
            }
            var overlayObj = new GameObject("CellOverlay", typeof(RectTransform), typeof(Image));
            overlayObj.transform.SetParent(transform, false);
            var rt = overlayObj.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = Vector2.zero;
            rt.localScale = Vector3.one;
            _cellOverlay = overlayObj.GetComponent<Image>();
            _cellOverlay.sprite = null;
            _cellOverlay.type = Image.Type.Simple;
            _cellOverlay.color = Color.clear;
            _cellOverlay.raycastTarget = false;
        }
        #endregion

        #region Cell Color API
        public void SetCellColor(Color color)
        {
            if (_cellOverlay != null)
                _cellOverlay.color = color;
        }

        public void ResetCellColor()
        {
            if (_cellOverlay != null)
                _cellOverlay.color = Color.clear;
        }

        public void TintOccupied(Color tint)
        {
            if (_cellOverlay == null) return;
            if (tint.a <= 0f)
            {
                _cellOverlay.color = Color.clear;
                return;
            }
            _cellOverlay.color = tint;
        }
        #endregion

        #region Event Handlers (Unity UI)
 public void OnDrop(PointerEventData eventData)
{
    if (_inventoryUI == null || !_inventoryUI.IsDragging) return;
    if (Time.frameCount == _lastDropFrame) return;
    _lastDropFrame = Time.frameCount;

    var draggedUI = _inventoryUI.DraggedUIItem;
    bool isFromEquipment = _inventoryUI.IsDraggingFromEquipmentSlot;
    InventoryItem draggedItem;
    if (draggedUI != null) draggedItem = draggedUI.Item;
    else if (isFromEquipment) draggedItem = _inventoryUI.DraggedFromSlotItem;
    else return;
    if (draggedItem == null) return;
    if (K_SplitStackDialog.IsItemLocked(draggedItem))
    {
        _inventoryUI.EndDragComplete(true);
        return;
    }

    if (DragHighlightController.Instance != null)
    {
        var topWin = DragHighlightController.Instance.GetTopmostWindow(eventData);
        if (topWin != null && !transform.IsChildOf(topWin.transform))
            return;
    }

    var targetController = _boundController ?? _inventoryUI.GetControllerForGrid(GridType);
    if (targetController == null || targetController.IsDisposed)
    {
        var restored = _inventoryUI.LootSession?.GetLootControllerFromSlots();
        if (restored != null && !restored.IsDisposed)
        {
            targetController = restored;
            _inventoryUI.SetActiveContainerController(restored);
        }
        else
        {
            Debug.LogWarning($"[OnDrop] Target controller is null or disposed for GridType={GridType}");
            _inventoryUI.EndDragComplete(true);
            return;
        }
    }

    var (tx, ty) = _inventoryUI.GetAdjustedDropPosition(
        X, Y, draggedItem.CurrentSize, GridType, targetController);

    // A merge/swap through an underlying cell must not move a locked window source.
    for (int row = 0; row < draggedItem.CurrentSize.y; row++)
        for (int column = 0; column < draggedItem.CurrentSize.x; column++)
            if (K_SplitStackDialog.IsItemLocked(targetController.GetItemAt(tx + column, ty + row)))
            {
                _inventoryUI.EndDragComplete(true);
                return;
            }

    if (_inventoryUI.IsGroundLootController(targetController))
    {
        // A ground grid accepts only the shared policy's same-session merge.
        // Every other ground drop cancels here, before swap or placement routes.
        if (draggedUI != null && !isFromEquipment && DragHighlightController.Instance != null)
        {
            DragHighlightController.Instance.ResolveSnapTargets(
                draggedItem, targetController, tx, ty, out var groundTargetUI, out _);
            if (groundTargetUI != null && groundTargetUI.Item != null)
            {
                var sourceController = draggedUI.BoundController
                                       ?? _inventoryUI.GetControllerForGrid(draggedUI.GridType);
                var decision = DragStackMergeRules.Evaluate(
                    draggedItem, sourceController, groundTargetUI.Item, targetController,
                    _inventoryUI.IsGroundLootController(sourceController), true, out _, out _);
                if (decision == DragStackMergeDecision.Merge)
                {
                    CompleteStackMerge(draggedUI, groundTargetUI);
                    return;
                }
            }
        }
        _inventoryUI.EndDragComplete(true);
        return;
    }

    // ═══ EQUIPMENT DROP PATH: единый маршрут через TransactionService ═══
    if (isFromEquipment && draggedUI == null)
    {
#if UNITY_EDITOR
        var cellOcc = targetController.GetItemAt(tx, ty);
        Debug.Log($"[EQ-DROP-AUDIT] enter: grid={GridType} tx={tx} ty={ty} " +
                  $"dragged id={draggedItem.InstanceID} rot={draggedItem.RotationAngle} " +
                  $"size=({draggedItem.CurrentSize.x}x{draggedItem.CurrentSize.y}) " +
                  $"target={(cellOcc != null ? cellOcc.InstanceID.ToString() : "null")}");
#endif
        // Определяем swap/backpack-цель по снап-футпринту.
        UI_Item swapTargetUI = null;
        UI_Item backpackTargetUI = null;
        if (DragHighlightController.Instance != null)
            DragHighlightController.Instance.ResolveSnapTargets(
                draggedItem, targetController, tx, ty,
                out swapTargetUI, out backpackTargetUI);

        // (1) Drop-into-backpack — как и раньше.
        if (backpackTargetUI != null && backpackTargetUI.Item != null)
        {
#if UNITY_EDITOR
            Debug.Log($"[EQ-DROP-AUDIT] route=DropIntoBackpack targetId={backpackTargetUI.Item.InstanceID}");
#endif
            bool dropSuccess = InventoryTransactionService.Instance.TryDropFromEquipmentIntoBackpackAtomic(
                draggedItem, backpackTargetUI.Item, out string dropErr);
            if (dropSuccess)
            {
                _inventoryUI.EndDragComplete();
                _inventoryUI.ForceRefresh();
            }
            else
            {
                Debug.LogWarning($"[OnDrop] Drop into backpack failed: {dropErr}");
                _inventoryUI.EndDragComplete(true);
            }
            return;
        }

        // (2) Swap с grid-item — через единый TransactionService.
        //     anchor = (tx,ty) — паритет с highlight, который тоже получает (tx,ty).
        if (swapTargetUI != null && swapTargetUI.Item != null)
        {
#if UNITY_EDITOR
            Debug.Log($"[EQ-DROP-AUDIT] route=TransactionService swapTargetId={swapTargetUI.Item.InstanceID} " +
                      $"anchor=({tx},{ty})");
#endif
            bool swapSuccess = InventoryTransactionService.Instance.TrySwapEquipmentItemWithGridItemAtomic(
                swapTargetUI, tx, ty, out string swapErr);
            if (swapSuccess)
            {
                _inventoryUI.EndDragComplete();
                _inventoryUI.ForceRefresh();
            }
            else
            {
                Debug.LogWarning($"[OnDrop] Equipment→grid swap failed: {swapErr}");
                _inventoryUI.EndDragComplete(true);
            }
            return;
        }

        // (3) Простая посадка в пустую клетку — legacy-путь остаётся.
#if UNITY_EDITOR
        Debug.Log($"[EQ-DROP-AUDIT] route=TPSI (simple placement, no swap target)");
#endif
        bool placed = _inventoryUI.TryPlaceItemFromEquipmentSlotAtomic(GridType, tx, ty, targetController);
        if (placed) _inventoryUI.FinalizeEquipSlotDrag();
        else _inventoryUI.EndDragComplete(true);
        return;
    }
    // ═══ END EQUIPMENT DROP PATH ═══

    // Grid drag: shared merge policy, then the existing backpack / swap / move paths.
    UI_Item swapTargetUI2 = null;
    UI_Item backpackTargetUI2 = null;
    if (DragHighlightController.Instance != null)
        DragHighlightController.Instance.ResolveSnapTargets(
            draggedItem, targetController, tx, ty, out swapTargetUI2, out backpackTargetUI2);

    if (backpackTargetUI2 != null && backpackTargetUI2.Item != null)
    {
        if (draggedItem.Data != null && draggedItem.Data.IsBackpack && !draggedItem.IsFolded
            && _inventoryUI != null && _inventoryUI.WouldExceedMaxNestingDepth(draggedItem, backpackTargetUI2.Item))
        {
            _inventoryUI.EndDragComplete(true);
            return;
        }

        bool successDrop = InventoryTransactionService.Instance.TryDropIntoBackpackAtomic(
            draggedUI, backpackTargetUI2.Item, out string dropError);
        if (successDrop)
        {
            _inventoryUI.EndDragComplete();
            _inventoryUI.ForceRefresh();
        }
        else
        {
            Debug.LogWarning($"[OnDrop] Drop into backpack failed: {dropError}");
            _inventoryUI.EndDragComplete(true);
        }
        return;
    }

    if (swapTargetUI2 != null && swapTargetUI2.Item != null)
    {
        var sourceController = draggedUI.BoundController
                               ?? _inventoryUI.GetControllerForGrid(draggedUI.GridType);
        var mergeDecision = DragStackMergeRules.Evaluate(
            draggedItem, sourceController, swapTargetUI2.Item, targetController,
            _inventoryUI.IsGroundLootController(sourceController),
            _inventoryUI.IsGroundLootController(targetController), out _, out _);
        if (mergeDecision == DragStackMergeDecision.Rejected)
        {
            _inventoryUI.EndDragComplete(true);
            return;
        }
        if (mergeDecision == DragStackMergeDecision.Merge)
        {
            CompleteStackMerge(draggedUI, swapTargetUI2);
            return;
        }
        bool successSwap = InventoryTransactionService.Instance.TrySwapItemsAtomic(
            draggedUI, swapTargetUI2, tx, ty, out string errorMessage);
        if (successSwap)
        {
            _inventoryUI.EndDragComplete();
            _inventoryUI.ForceRefresh();
        }
        else
        {
            Debug.LogWarning($"[OnDrop] Swap failed: {errorMessage}");
            _inventoryUI.EndDragComplete(true);
        }
        return;
    }

    if (targetController.CanPlaceItem(draggedItem, tx, ty))
    {
        bool moveSuccess = InventoryTransactionService.Instance.TryMoveItemAtomic(
            draggedUI, targetController, tx, ty, out string moveError);
        if (moveSuccess)
        {
            _inventoryUI.EndDragComplete();
            _inventoryUI.ForceRefresh();
        }
        else
        {
            Debug.LogWarning($"[OnDrop] Move failed: {moveError}");
            _inventoryUI.EndDragComplete(true);
        }
    }
    else
    {
        _inventoryUI.EndDragComplete(true);
    }
}
        private void CompleteStackMerge(UI_Item sourceUI, UI_Item targetUI)
        {
            bool merged = InventoryTransactionService.Instance.TryMergeStacksAtomic(sourceUI, targetUI, out string error);
            if (merged)
            {
                _inventoryUI.EndDragComplete();
                _inventoryUI.ForceRefresh();
            }
            else
            {
                Debug.LogWarning($"[OnDrop] Stack merge failed: {error}");
                _inventoryUI.EndDragComplete(true);
            }
        }
        #endregion
    }
    }
