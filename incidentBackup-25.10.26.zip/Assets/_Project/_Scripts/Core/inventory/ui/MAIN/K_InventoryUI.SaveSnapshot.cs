namespace K_Incident.Core.Inventory
{
    public partial class K_InventoryUI
    {
        public void SyncAllBackpacksForRollbackSnapshot()
        {
            _saveSync?.SyncAllBackpacksForRollbackSnapshot();
        }
    }
}
