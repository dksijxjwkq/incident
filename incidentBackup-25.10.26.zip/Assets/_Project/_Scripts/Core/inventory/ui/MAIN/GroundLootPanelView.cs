using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Temporarily adds scrolling to the existing E-loot panel.</summary>
    public sealed class GroundLootPanelView : IDisposable
    {
        private readonly RectTransform _panel, _grid;
        private readonly RectTransform _oldParent;
        private readonly int _oldSibling, _oldPanelSibling;
        private readonly Vector2 _oldGridPosition, _oldPanelSize, _fixedPanelPosition;
        private readonly GameObject _host;
        private readonly ScrollRect _scroll;
        private readonly Scrollbar _bar;
        private readonly float _headerHeight, _visibleHeight;
        private readonly List<KeyValuePair<K_DraggablePanel, bool>> _draggables = new List<KeyValuePair<K_DraggablePanel, bool>>();
        private readonly MaskableGraphic _gridGraphic;
        private readonly bool _wasMaskable;
        private const float BarWidth = 12f;

        public GroundLootPanelView(RectTransform panel, RectTransform grid, float slotSize,
            float slotSpacing, float headerHeight, float maximumHeight, Color borderColor)
        {
            _panel = panel; _grid = grid; _headerHeight = headerHeight;
            _oldParent = grid.parent as RectTransform; _oldSibling = grid.GetSiblingIndex();
            _oldPanelSibling = panel.GetSiblingIndex();
            _oldGridPosition = grid.anchoredPosition; _oldPanelSize = panel.sizeDelta;
            _fixedPanelPosition = panel.anchoredPosition;
            var layout = grid.GetComponent<GridLayoutGroup>();
            float padding = layout != null ? layout.padding.top + layout.padding.bottom : 0f;
            _visibleHeight = Mathf.Min(padding + 8 * slotSize + 7 * slotSpacing,
                Mathf.Max(slotSize * 2, maximumHeight - headerHeight));
            foreach (var drag in panel.GetComponentsInChildren<K_DraggablePanel>(true))
            {
                _draggables.Add(new KeyValuePair<K_DraggablePanel, bool>(drag, drag.enabled));
                drag.enabled = false;
            }
            _gridGraphic = grid.GetComponent<MaskableGraphic>();
            if (_gridGraphic != null) { _wasMaskable = _gridGraphic.maskable; _gridGraphic.maskable = true; }

            _host = new GameObject("GroundLootScroll", typeof(RectTransform), typeof(Image), typeof(ScrollRect));
            var hostRect = (RectTransform)_host.transform;
            hostRect.SetParent(panel, false);
            TopLeft(hostRect);
            hostRect.anchoredPosition = new Vector2(0, -headerHeight);
            _host.GetComponent<Image>().color = Color.clear;

            var viewport = new GameObject("Viewport", typeof(RectTransform), typeof(RectMask2D));
            var viewportRect = (RectTransform)viewport.transform;
            viewportRect.SetParent(hostRect, false); TopLeft(viewportRect);
            grid.SetParent(viewportRect, false); TopLeft(grid); grid.anchoredPosition = Vector2.zero;

            var barObject = new GameObject("VerticalScrollbar", typeof(RectTransform), typeof(Image), typeof(Scrollbar));
            var barRect = (RectTransform)barObject.transform;
            barRect.SetParent(hostRect, false);
            barRect.anchorMin = new Vector2(1, 0); barRect.anchorMax = Vector2.one;
            barRect.pivot = new Vector2(1, .5f); barRect.sizeDelta = new Vector2(BarWidth, 0);
            barObject.GetComponent<Image>().color = new Color(borderColor.r, borderColor.g, borderColor.b, .2f);
            var handle = new GameObject("Handle", typeof(RectTransform), typeof(Image));
            handle.transform.SetParent(barRect, false);
            var handleRect = (RectTransform)handle.transform;
            handleRect.anchorMin = Vector2.zero; handleRect.anchorMax = Vector2.one;
            handleRect.offsetMin = Vector2.zero; handleRect.offsetMax = Vector2.zero;
            handle.GetComponent<Image>().color = borderColor;
            _bar = barObject.GetComponent<Scrollbar>();
            _bar.direction = Scrollbar.Direction.BottomToTop;
            _bar.handleRect = handleRect; _bar.targetGraphic = handle.GetComponent<Image>();

            _scroll = _host.GetComponent<ScrollRect>();
            _scroll.viewport = viewportRect; _scroll.content = grid;
            _scroll.horizontal = false; _scroll.vertical = true;
            _scroll.inertia = false; _scroll.movementType = ScrollRect.MovementType.Clamped;
            _scroll.scrollSensitivity = slotSize + slotSpacing;
            _scroll.verticalScrollbar = _bar;
            Resize();
            _scroll.verticalNormalizedPosition = 1f;
            panel.SetAsLastSibling();
        }

        private static void TopLeft(RectTransform rect)
        {
            rect.anchorMin = new Vector2(0, 1); rect.anchorMax = new Vector2(0, 1);
            rect.pivot = new Vector2(0, 1); rect.localScale = Vector3.one;
            rect.localRotation = Quaternion.identity;
        }

        public void Resize()
        {
            // The scroll view owns this hierarchy for the entire ground session.
            // Legacy backpack layout helpers must not pull content onto the panel.
            if (_grid.parent != _scroll.viewport) _grid.SetParent(_scroll.viewport, false);
            TopLeft(_grid);
            _panel.anchoredPosition = _fixedPanelPosition;
            if (_gridGraphic != null) _gridGraphic.maskable = true;
            float width = _grid.sizeDelta.x;
            ((RectTransform)_host.transform).sizeDelta = new Vector2(width + BarWidth, _visibleHeight);
            _scroll.viewport.sizeDelta = new Vector2(width, _visibleHeight);
            _panel.sizeDelta = new Vector2(width + BarWidth, _visibleHeight + _headerHeight);
            float maximumOffset = Mathf.Max(0, _grid.sizeDelta.y - _visibleHeight);
            _grid.anchoredPosition = new Vector2(0, Mathf.Clamp(_grid.anchoredPosition.y, 0, maximumOffset));
            _scroll.StopMovement();
            _bar.gameObject.SetActive(_grid.sizeDelta.y > _visibleHeight + .1f);
        }

        public void Dispose()
        {
            if (_host == null) return;
            _scroll.enabled = false;
            _grid.SetParent(_oldParent, false); _grid.SetSiblingIndex(_oldSibling);
            _grid.anchoredPosition = _oldGridPosition;
            _panel.sizeDelta = _oldPanelSize;
            _panel.anchoredPosition = _fixedPanelPosition;
            _panel.SetSiblingIndex(_oldPanelSibling);
            if (_gridGraphic != null) _gridGraphic.maskable = _wasMaskable;
            foreach (var pair in _draggables)
                if (pair.Key != null) pair.Key.enabled = pair.Value;
            _host.SetActive(false);
            UnityEngine.Object.Destroy(_host);
        }
    }
}
