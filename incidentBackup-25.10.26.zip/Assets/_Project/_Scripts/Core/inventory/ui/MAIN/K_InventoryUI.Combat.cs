using System.Collections.Generic;
using K_Incident.Core.Combat;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public partial class K_InventoryUI
    {
        [Header("Combat 5.2")]
        [SerializeField] private WeaponBalanceConfig _combatBalance;
        private K_CombatContext _combatContext;
        public K_PlayerCombatController CombatController { get; private set; }
        public InventoryItem PrimaryCombatItem => _primarySlot1?.EquippedItem ?? _primarySlot2?.EquippedItem;

        public InventoryItem GetCombatItem(ActiveCombatSlot slot) => slot switch
        {
            ActiveCombatSlot.Primary1 => _primarySlot1?.EquippedItem,
            ActiveCombatSlot.Primary2 => _primarySlot2?.EquippedItem,
            ActiveCombatSlot.Pistol => _pistolSlot?.EquippedItem,
            ActiveCombatSlot.Melee => _meleeSlot?.EquippedItem,
            ActiveCombatSlot.None => null,
            _ => throw new System.ArgumentOutOfRangeException(nameof(slot))
        };

        // Called by Start, after controllers and equipment references have been initialized.
        private void InitializeCombatIntegration()
        {
            var owner = AppliedHealth != null ? AppliedHealth.gameObject :
                (_playerMotor != null ? _playerMotor.gameObject : gameObject);
            if (_combatContext == null) _combatContext = owner.GetComponent<K_CombatContext>();
            if (_combatContext == null) _combatContext = owner.AddComponent<K_CombatContext>();
            bool createdRuntimeBalance = _combatContext.Balance == null && _combatBalance == null;
            if (_combatContext.Balance == null)
                _combatContext.ConfigureBalance(_combatBalance != null ? _combatBalance :
                    ScriptableObject.CreateInstance<WeaponBalanceConfig>());
            if (createdRuntimeBalance) _combatContext.AdoptRuntimeBalance(_combatContext.Balance);
            _combatContext.ConfigureDatabase(K_InventorySetup.DatabaseInstance);
            _combatContext.EnsureSaveRegistration();
            CombatController = owner.GetComponent<K_PlayerCombatController>();
            if (CombatController == null) CombatController = owner.AddComponent<K_PlayerCombatController>();
            CombatController.Initialize(this, _combatContext, AppliedHealth);
        }

        private void DisposeCombatIntegration()
        {
            CombatController?.DetachInventory(this);
            CombatController = null;
            _combatContext = null;
        }

        public List<InventoryItem> GetCombatOwnedRoots()
        {
            var equipment = new[] { _primarySlot1?.EquippedItem, _primarySlot2?.EquippedItem,
                _pistolSlot?.EquippedItem, _meleeSlot?.EquippedItem, _backpackSlot?.EquippedItem,
                _armorSlot?.EquippedItem, _headgearSlot?.EquippedItem };
            return CombatPlayerInventory.CollectOwnedRoots(equipment, _pocketsController, _pocket2Controller,
                HasEquippedBackpack ? _backpackController : null, SyncBackpackForValidation);
        }

        public CombatReloadSources GetCombatReloadSources() => new CombatReloadSources(
            _pocketsController, _pocket2Controller, HasEquippedBackpack ? _backpackController : null);

        public bool TryCycleWeaponChamber(InventoryItem item, out string reason)
        {
            reason = "Combat controller is unavailable.";
            return CombatController != null && CombatController.TryCycleWeaponChamber(item, out reason);
        }

        public bool TryDetachWeaponMagazine(InventoryItem item, out string reason)
        {
            reason = "Combat controller is unavailable.";
            return CombatController != null && CombatController.TryDetachWeaponMagazine(item, out reason);
        }

        public bool TryClearWeaponChamber(InventoryItem item, out string reason)
        {
            reason = "Combat controller is unavailable.";
            return CombatController != null && CombatController.TryClearWeaponChamber(item, out reason);
        }

        public bool TryCheckWeaponMagazine(InventoryItem item, out string text, out string reason)
        {
            text = null;
            reason = "Combat controller is unavailable.";
            return CombatController != null && CombatController.TryCheckWeaponMagazine(item, out text, out reason);
        }

        public bool OwnsCombatTarget(InventoryItem target)
        {
            if (target == null) return false;
            foreach (var item in GetCombatOwnedRoots())
                if (ReferenceEquals(item, target)) return true;
            return false;
        }

        public void RefreshCombatWeight()
        {
            if (_combatContext == null || K_InventorySetup.DatabaseInstance == null || _cachedWeightManager == null)
            {
                // Initialization-only fallback; the legacy method is kept intact for old callers.
                RefreshTotalWeight();
                return;
            }
            _combatContext.UpdateCarriedWeight(GetCombatOwnedRoots(), K_InventorySetup.DatabaseInstance,
                _cachedWeightManager, AppliedHealth?.AppliedMedical?.Records);
            UpdateWeightDisplay();
        }

        public bool CanPreviewCombatAmmoDrop(InventoryItem ammo, InventoryItem target)
        {
            if (target?.Data?.IsMelee == true) return false;
            if (_combatContext == null || !OwnsCombatTarget(target) || ammo?.Data?.Type != ItemType.Ammo)
                return false;
            var source = _draggedItem?.BoundController ?? FindControllerForItem(ammo);
            if (source != _pocketsController && source != _pocket2Controller &&
                !(HasEquippedBackpack && source == _backpackController)) return false;
            if (target.Data.Type == ItemType.Weapon)
                return CombatReloadService.CanLoadAmmo(ammo, _combatContext.Items.GetOrCreateWeapon(target));
            if (target.Data.Type == ItemType.Magazine)
                return CombatReloadService.CanLoadAmmo(ammo, _combatContext.Items.GetOrCreateMagazine(target));
            return false;
        }

        /// <summary>Recognized ammo drops always finish the drag, including refused loads.</summary>
        public bool TryHandleCombatAmmoDrop(InventoryItem target)
        {
            var ammo = _draggedItem?.Item;
            if (ammo?.Data?.Type != ItemType.Ammo || target?.Data == null ||
                (target.Data.Type != ItemType.Weapon && target.Data.Type != ItemType.Magazine)) return false;
            bool valid = CanPreviewCombatAmmoDrop(ammo, target);
            // A drag temporarily removes the stack from its controller. Restore it before the
            // timed service takes ownership, so cancellation and partial loading conserve rounds.
            CancelDrag();
            if (valid && CombatController != null)
                CombatController.TryBeginAmmoDrop(ammo, target);
            ForceRefresh();
            return true;
        }
    }
}
