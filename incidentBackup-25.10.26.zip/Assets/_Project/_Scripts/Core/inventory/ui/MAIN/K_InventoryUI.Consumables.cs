using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public partial class K_InventoryUI
    {
        public bool TryOpenConsumableQuantity(InventoryItem item, Vector2 screenPosition)
        {
            if (!CanUseFoodSource(item))
            {
                Debug.LogWarning("[Consumable] Сначала переместите еду или напиток в свой инвентарь; проверьте настройки расходника и Vitality.");
                return false;
            }
            var vitality = MedicalApplyService.VitalitySystem;
            bool food = item.Data.ConsumableType == ConsumableType.Food;
            string verb = food ? "Съесть" : "Выпить";
            return K_SplitStackDialog.ShowQuantity(item, this, screenPosition, new K_QuantityDialogOptions
            {
                Mode = food ? K_QuantityDialogMode.Eat : K_QuantityDialogMode.Drink,
                Title = verb + ": " + item.Data.DisplayName,
                QuantityLabel = "Количество (%)",
                ConfirmLabel = verb,
                Minimum = 1f,
                InitialValue = item.RemainingConsumablePercent,
                Maximum = () => CanUseFoodSource(item) ? item.RemainingConsumablePercent : 0f,
                SourceAvailable = () => CanUseFoodSource(item),
                CanApply = () => CanUseFoodSource(item),
                Preview = amount => FormatConsumablePreview(item.Data.ConsumableTotalValue, amount,
                    food ? vitality.Hunger : vitality.Thirst),
                WholeNumbers = false,
                ClampInputToRange = true,
                OnConfirm = amount =>
                {
                    if (!CanUseFoodSource(item)) return;
                    var controller = FindControllerForItem(item);
                    if (!K_ConsumableService.TryConsumeFood(item, amount, vitality,
                        (charge, apply) => controller.TryConsumeCharge(item, charge, apply), out _, out string reason))
                        Debug.LogWarning("[Consumable] " + reason);
                    ForceRefresh();
                }
            }) != null;
        }

        public bool TryOpenTransfusionQuantity(MedicalItemRecord record, BodyPart part)
        {
            var service = MedicalApplyService;
            string reason = "сервис применения недоступен";
            if (service == null || !service.CanTransfuse(record, part, out _, out reason))
            {
                Debug.LogWarning("[Medical] " + reason);
                return false;
            }
            float Maximum() => service.CanTransfuse(record, part, out float maximum, out _) ? maximum : 0f;
            bool Available() => service.CanTransfuse(record, part, out _, out _);
            var blood = service.BloodSystem;
            var canvas = RootCanvasTransform as RectTransform;
            Vector2 position = canvas != null
                ? RectTransformUtility.WorldToScreenPoint(null, canvas.position) : Vector2.zero;
            return K_SplitStackDialog.ShowQuantity(record.Item, this, position, new K_QuantityDialogOptions
            {
                Mode = K_QuantityDialogMode.Transfusion,
                Title = "Переливание: " + record.Item.Data.DisplayName,
                QuantityLabel = "Количество (мл)",
                ConfirmLabel = "Перелить",
                Minimum = 1f,
                InitialValue = Maximum(),
                Maximum = Maximum,
                SourceAvailable = Available,
                CanApply = Available,
                Preview = amount => FormatTransfusionPreview(amount, record.Item.FullChargeCapacity,
                    blood.CurrentVolumeMl, blood.MaxVolumeMl),
                WholeNumbers = false,
                ClampInputToRange = true,
                OnConfirm = amount =>
                {
                    if (!service.TryTransfuse(record, part, amount, out _, out string refusal))
                        Debug.LogWarning("[Medical] " + refusal);
                }
            }) != null;
        }

        internal static string FormatConsumablePreview(float totalValue, float selectedPercent, float current)
        {
            float gain = totalValue * (selectedPercent / 100f);
            return "+" + QuantityText(gain) + "% (до " + QuantityText(Mathf.Clamp(current + gain, 0f, 100f)) + "%)";
        }

        internal static string FormatTransfusionPreview(float amount, float capacity, float current, float maximum)
        {
            float next = Mathf.Min(maximum, current + amount);
            return "Перелить: " + QuantityText(amount) + " мл (" + QuantityText(capacity > 0f ? amount / capacity * 100f : 0f) +
                "%)\nСтанет: " + QuantityText(next) + " мл (" + QuantityText(maximum > 0f ? next / maximum * 100f : 0f) + "%)";
        }

        private static string QuantityText(float value) => value.ToString("0.##", CultureInfo.InvariantCulture);

        private bool CanUseFoodSource(InventoryItem item)
        {
            if (item?.Data == null || item.Data.IsBackpack || item.Quantity != 1 || AppliedHealth?.IsDead == true ||
                MedicalApplyService?.VitalitySystem == null ||
                (item.Data.ConsumableType != ConsumableType.Food && item.Data.ConsumableType != ConsumableType.Drink) ||
                !IsPositiveQuantity(item.Data.ConsumableTotalValue) || !IsPositiveQuantity(item.RemainingConsumablePercent)) return false;
            var controller = FindControllerForItem(item);
            if (controller == null || controller.IsDisposed ||
                !ReferenceEquals(controller.GetItemByInstanceID(item.InstanceID), item)) return false;
            // External loot and ground projections require their own transfer contract.
            // A nested, open player backpack remains a player-owned source.
            foreach (var root in GetCombatOwnedRoots())
            {
                if (ReferenceEquals(root, item)) return true;
                if (root != null && SavedTreeContains(root.GetBackpackSavedItems(), item.InstanceID, false,
                    new HashSet<uint>(), 0)) return true;
            }
            return false;
        }

        private static bool IsPositiveQuantity(float value) => !float.IsNaN(value) && !float.IsInfinity(value) && value > 0f;

        public bool HasRepairKit()
        {
            foreach (var root in GetCombatOwnedRoots())
            {
                if (root?.Data?.IsRepairKit == true) return true;
                if (root != null && SavedTreeContains(root.GetBackpackSavedItems(), 0, true,
                    new HashSet<uint>(), 0)) return true;
            }
            return false;
        }

        private static bool SavedTreeContains(IReadOnlyList<SavedItem> items, uint targetID, bool repairKit,
            HashSet<uint> visited, int depth)
        {
            if (items == null || depth > 32) return false;
            foreach (var saved in items)
            {
                if (!visited.Add(saved.InstanceID)) continue;
                if (repairKit ? K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID)?.IsRepairKit == true :
                    saved.InstanceID == targetID) return true;
                if (SavedTreeContains(saved.BackpackContents, targetID, repairKit, visited, depth + 1)) return true;
            }
            return false;
        }
    }
}
