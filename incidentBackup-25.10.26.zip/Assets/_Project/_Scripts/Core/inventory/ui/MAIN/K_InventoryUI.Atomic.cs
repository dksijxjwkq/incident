using System;
using System.Collections.Generic;

namespace K_Incident.Core.Inventory
{
    public partial class K_InventoryUI
    {
        /// <summary>Explicit Inspector slots plus active dynamic descendants belonging to this owner.</summary>
        public IReadOnlyList<K_EquipmentSlotUI> GetTransactionEquipmentSlots()
        {
            var result = new List<K_EquipmentSlotUI>(8);
            foreach (var slot in new[] { _primarySlot1, _primarySlot2, _pistolSlot, _meleeSlot,
                _backpackSlot, _armorSlot, _headgearSlot })
            {
                if (slot == null || !slot.isActiveAndEnabled || result.Contains(slot)) continue;
                var parentOwner = slot.GetComponentInParent<K_InventoryUI>();
                if (parentOwner == null || parentOwner == this) result.Add(slot);
            }
            // Deliberately uses the active-only overload, per the approved 8b.11 constraints.
            foreach (var slot in GetComponentsInChildren<K_EquipmentSlotUI>())
                if (slot != null && slot.isActiveAndEnabled && !result.Contains(slot) &&
                    slot.GetComponentInParent<K_InventoryUI>() == this) result.Add(slot);
            return result;
        }

        internal Action CaptureAtomicLifecycleRestore()
        {
            var loaded = _loadedBackpackItem;
            bool equipped = _backpackEquipped;
            int columns = _currentBackpackCols, rows = _currentBackpackRows;
            var target = _dropTargetController;
            bool dragging = _isDragging, removed = _dragItemRemoved;
            var dragged = _draggedItem;
            var sourceSlot = _draggedFromEquipmentSlot;
            var sourceItem = _draggedFromSlotItem;
            return () =>
            {
                _loadedBackpackItem = loaded;
                _backpackEquipped = equipped;
                _currentBackpackCols = columns;
                _currentBackpackRows = rows;
                _dropTargetController = target;
                _isDragging = dragging;
                _dragItemRemoved = removed;
                _draggedItem = dragged;
                _draggedFromEquipmentSlot = sourceSlot;
                _draggedFromSlotItem = sourceItem;
            };
        }

        internal void SynchronizeAtomicBackpacks()
        {
            // Avoid ground-session repacking: the journal owns the current exact controllers.
            _saveSync?.SyncAllBackpacksForSave();
        }

        internal void RefreshAtomicInventoryViews()
        {
            if (HasEquippedBackpack && _currentBackpackCols > 0 && _currentBackpackRows > 0)
                RebuildBackpackGrid(_currentBackpackCols, _currentBackpackRows);
            else if (_backpackGrid != null)
                ClearGrid(_backpackGrid, _backpackItemsContainer);
            RefreshEquipmentSlots();
            ForceRefresh();
        }

        public bool TryPlaceItemFromEquipmentSlotAtomic(GridType targetGrid, int targetX, int targetY,
            InventoryController boundController = null)
        {
            if (!_isDragging || _draggedFromEquipmentSlot == null || _draggedFromSlotItem == null
                || !ReferenceEquals(_draggedFromEquipmentSlot.EquippedItem, _draggedFromSlotItem)) return false;
            var controller = boundController ??
                ((targetGrid == GridType.Container && _dropTargetController != null)
                    ? _dropTargetController : GetControllerForGrid(targetGrid));
            return InventoryTransactionService.Instance.TryPlaceEquipmentIntoGridAtomic(
                _draggedFromEquipmentSlot, controller, targetX, targetY, out _);
        }
    }
}
