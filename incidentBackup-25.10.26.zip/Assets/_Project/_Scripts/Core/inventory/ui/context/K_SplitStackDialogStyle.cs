using TMPro;
using UnityEngine;

/// <summary>Appearance and pixel layout of the generated split stack dialog.</summary>
[CreateAssetMenu(fileName = "SplitStackDialogStyle", menuName = "INCIDENT/UI/Split Stack Dialog Style")]
public sealed class K_SplitStackDialogStyle : ScriptableObject
{
    [Header("Layout (UI scale stays 1)")]
    public Vector2 WindowSize = new Vector2(360f, 212f);
    public Vector2 OffsetFromCursor = new Vector2(8f, -8f);
    [Min(0f)] public float Padding = 12f;
    [Min(0f)] public float Spacing = 10f;
    [Min(1f)] public float HeaderHeight = 32f;
    [Min(1f)] public float LabelHeight = 18f;
    [Min(1f)] public float ControlHeight = 30f;
    [Min(1f)] public float InputWidth = 90f;
    public Vector2 InputTextPadding = new Vector2(6f, 3f);
    [Min(1f)] public float WarningHeight = 28f;
    public Vector2 ButtonSize = new Vector2(160f, 32f);
    public Vector2 CloseButtonSize = new Vector2(28f, 28f);
    [Min(0f)] public float TrackThickness = 6f;
    public Vector2 HandleSize = new Vector2(14f, 28f);

    [Header("Window and header")]
    public Color BackgroundColor = new Color(0.94f, 0.93f, 0.88f, 1f);
    public Color HeaderColor = new Color(0.89f, 0.88f, 0.82f, 1f);
    public Color TitleColor = new Color(0.12f, 0.13f, 0.14f, 1f);
    public Color BorderColor = new Color(0.24f, 0.25f, 0.23f, 1f);
    [Min(0f)] public float BorderThickness = 1f;
    public Color HeaderDividerColor = new Color(0.24f, 0.25f, 0.23f, 1f);
    [Min(0f)] public float HeaderDividerThickness = 1f;

    [Header("Slider")]
    public Color SliderLabelColor = new Color(0.18f, 0.19f, 0.17f, 1f);
    public Color TrackColor = new Color(0.68f, 0.69f, 0.64f, 1f);
    public Color FillColor = new Color(0.31f, 0.43f, 0.37f, 1f);
    public Color HandleColor = new Color(0.24f, 0.32f, 0.27f, 1f);
    public Color HandleHoverColor = new Color(0.35f, 0.46f, 0.39f, 1f);
    public Color HandlePressedColor = new Color(0.17f, 0.24f, 0.20f, 1f);

    [Header("Input")]
    public Color InputNormalColor = Color.white;
    public Color InputHoverColor = new Color(0.98f, 0.98f, 0.93f, 1f);
    public Color InputFocusedColor = new Color(0.88f, 0.94f, 0.89f, 1f);
    public Color InputPressedColor = new Color(0.83f, 0.89f, 0.84f, 1f);
    public Color InputTextColor = new Color(0.10f, 0.12f, 0.10f, 1f);
    public Color InputFocusedTextColor = new Color(0.05f, 0.10f, 0.06f, 1f);
    public Color InputCaretColor = new Color(0.05f, 0.10f, 0.06f, 1f);
    [Min(0.1f)] public float InputCaretBlinkRate = 1.5f;
    [Min(1)] public int InputCaretWidth = 2;
    [Min(0f), Tooltip("Высота каретки в пикселях UI. 0 — автоматически по высоте текста.")]
    public float InputCaretHeight = 0f;
    public Color InputSelectionColor = new Color(0.33f, 0.53f, 0.40f, 0.35f);

    [Header("Confirm button")]
    public Color ButtonNormalColor = new Color(0.30f, 0.40f, 0.33f, 1f);
    public Color ButtonHoverColor = new Color(0.38f, 0.49f, 0.40f, 1f);
    public Color ButtonPressedColor = new Color(0.22f, 0.31f, 0.25f, 1f);
    public Color ButtonTextColor = Color.white;

    [Header("Close button")]
    public Color CloseNormalColor = new Color(0.89f, 0.88f, 0.82f, 1f);
    public Color CloseHoverColor = new Color(0.85f, 0.65f, 0.58f, 1f);
    public Color ClosePressedColor = new Color(0.73f, 0.47f, 0.40f, 1f);
    public Color CloseTextColor = new Color(0.20f, 0.16f, 0.14f, 1f);
    public Color CloseBorderColor = new Color(0.35f, 0.29f, 0.25f, 1f);
    [Min(0f)] public float CloseBorderThickness = 1f;

    [Header("Typography")]
    public TMP_FontAsset Font;
    [Min(1f)] public float TitleFontSize = 16f;
    [Min(1f)] public float LabelFontSize = 13f;
    [Min(1f)] public float InputFontSize = 15f;
    [Min(1f)] public float ButtonFontSize = 14f;
    [Min(1f)] public float CloseFontSize = 20f;
    [Min(1f)] public float WarningFontSize = 12f;
    public Color WarningColor = new Color(0.65f, 0.20f, 0.12f, 1f);

    [SerializeField, Tooltip("Смещение крестика от стандартной позиции в пикселях UI.")]
    private Vector2 _closeButtonOffset = Vector2.zero;
    public Vector2 CloseButtonOffset => _closeButtonOffset;

    private static K_SplitStackDialogStyle _default;
    public static K_SplitStackDialogStyle Default()
    {
        if (_default == null)
        {
            _default = CreateInstance<K_SplitStackDialogStyle>();
            _default.name = "(Default Split Stack Dialog Style)";
            _default.hideFlags = HideFlags.HideAndDontSave;
        }
        return _default;
    }
}
