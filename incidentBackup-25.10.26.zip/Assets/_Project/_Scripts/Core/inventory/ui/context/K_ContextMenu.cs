using K_Incident.Core;
using K_Incident.Core.Inventory;
using K_Incident.Core.World;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class K_ContextMenu : MonoBehaviour
{
    #region Singleton

    public static K_ContextMenu Instance { get; private set; }

    private void Awake()
    {
        if (GetComponent<RectTransform>() == null)
        {
            Debug.LogError("[K_ContextMenu] RectTransform is required. Add the menu to a UI object.");
            enabled = false;
            return;
        }
        if (Instance != null && Instance != this)
        {
            gameObject.SetActive(false);
            return;
        }
        Instance = this;
        SetupInternals();
    }

    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }

    #endregion

    #region Style Configuration

    [Header("Style Configuration")]
    [SerializeField, Tooltip("Ассет стиля контекстного меню. Создайте через Create > K Context Menu Style " +
        "и перетащите сюда. Если null — используются дефолтные значения. " +
        "Этот ассет редактируется в Inspector в любое время, даже вне Play-режима!")]
    private K_ContextMenuStyle _style;

    [SerializeField, Tooltip("Стиль окна разделения. Если не задан, берётся из ассета стиля контекстного меню.")]
    private K_SplitStackDialogStyle _splitStyle;

    private K_ContextMenuStyle S => _style != null ? _style : (_styleDefault ?? (_styleDefault = K_ContextMenuStyle.Default()));
    private static K_ContextMenuStyle _styleDefault;

    public void SetStyle(K_ContextMenuStyle style) => _style = style;
    public K_ContextMenuStyle GetStyle() => S;
    public K_SplitStackDialogStyle GetSplitStyle() => _splitStyle != null ? _splitStyle : S.SplitDialogStyle;

    #endregion

    #region Internal

    private RectTransform _rectTransform;
    private CanvasGroup _canvasGroup;
    private Canvas _canvas;
    private RectTransform _contentRect;
    private List<GameObject> _spawnedItems = new List<GameObject>();
    private Coroutine _hideCoroutine;
    private Coroutine _rebuildCoroutine;
    private InventoryItem _currentItem;
    private K_InventoryUI _currentInventoryUI;
    private K_EquipmentSlotUI _currentEquipmentSlot;
    private bool _isInitialized;

    private Vector2 _lastScreenPosition;

    /// <summary>Список записей текущего меню — нужен чтобы определить последнюю кнопку.</summary>
    private List<MenuEntry> _currentEntries = new List<MenuEntry>();

    // Stage 4.5.1: кэш transform-а игрока для позиции дропа.
    // Stage 4.5.1c: заполняется только в Start (EnsureCaches). Lazy-fallback убран.
    private Transform _cachedPlayerTransform;

    // Stage 4.5.1b: кэш pickup-системы для NotifyItemDropped.
    // Stage 4.5.1c: заполняется только в Start (EnsureCaches). Отсутствие — не ошибка.
    private K_WorldItemPickupSystem _cachedPickup;

    #endregion

    #region Context Action Definition

    public enum ContextAction
    {
        InspectWeapon, ReloadMagazine, UnloadMagazine, LoadMagazine,
        CheckMagazine, ChamberRound, ClearChamber, ToggleFireMode, CockWeapon,
        Eat, Drink, Use,
        ApplyToPart,             // 6.6: было ApplyToSelf
        Equip, Unequip,
        Fold, Unfold, OpenBackpack, CloseBackpack, EmptyBackpack,
        Inspect, Drop, Description, Discard, Split,
        Repair,
        TransferAmmo,
        RemoveApplied,          // Stage 4: release a reusable mechanical device.
        LoadLooseMagazine,
    }

    private struct MenuEntry
    {
        public string Label;
        public ContextAction Action;
        public bool IsDanger;
        public bool IsSeparator;
        public bool IsDisabled;
        public string DisabledReason;
        public BodyPart? TargetPart;   // 6.6
    }

    private MedicalItemRecord? _currentMedicalRecord;   // 6.6
    private AppliedMedicalRecord _currentAppliedRecord;
    private K_HealthSystem _currentAppliedHealth;
    private GameObject _stage4Tooltip;

    #endregion

    #region Public API

    public void Show(InventoryItem item, Vector2 screenPosition, K_InventoryUI inventoryUI,
        K_EquipmentSlotUI equipmentSlot = null,
        MedicalItemRecord? medicalRecord = null,
        K_HealthSystem appliedHealth = null)   // Stage 4: explicit virtual context owner.
    {
        if (!enabled || item == null || item.Data == null || K_SplitStackDialog.IsItemLocked(item)) return;
        if (!_isInitialized) SetupInternals();
        if (!_isInitialized) return;

        _currentItem = item;
        _currentInventoryUI = inventoryUI;
        _currentEquipmentSlot = equipmentSlot;
        // Stage 4: live grid items and virtual mirror items share one context.
        _currentAppliedHealth = appliedHealth ?? (inventoryUI != null ? inventoryUI.AppliedHealth : null);
        _currentAppliedRecord = _currentAppliedHealth?.AppliedMedical?.GetRecordForInstance(item.InstanceID);
        if (_stage4Tooltip != null) _stage4Tooltip.SetActive(false);

        // 6.6: источник MedicalItemRecord для ПКМ-применения.
        _currentMedicalRecord = medicalRecord;
        if (_currentMedicalRecord == null && item.Type == ItemType.Medical)
        {
            var svc = inventoryUI?.MedicalInventoryService;
            if (svc != null)
            {
                var records = svc.GetMedicalItems();
                for (int i = 0; i < records.Count; i++)
                {
                    var r = records[i];
                    if (r.Item != null && r.Item.InstanceID == item.InstanceID)
                    {
                        _currentMedicalRecord = r;
                        break;
                    }
                }
            }
        }

        if (!_isInitialized) SetupInternals();

        if (_hideCoroutine != null) { StopCoroutine(_hideCoroutine); _hideCoroutine = null; }
        if (_rebuildCoroutine != null) { StopCoroutine(_rebuildCoroutine); _rebuildCoroutine = null; }

        BuildMenu();

        _lastScreenPosition = screenPosition;

        transform.SetAsLastSibling();
        gameObject.SetActive(true);
        EnsureRootVerticalLayoutGroup();

        if (_contentRect != null)
            LayoutRebuilder.ForceRebuildLayoutImmediate(_contentRect);
        if (_rectTransform != null)
            LayoutRebuilder.ForceRebuildLayoutImmediate(_rectTransform);

        ForceRecomputeRootSize();

        _rebuildCoroutine = StartCoroutine(RebuildNextFrame());

        if (_canvasGroup != null)
        {
            _canvasGroup.alpha = 0f;
            StartCoroutine(FadeInRoutine());
        }
    }

    private void EnsureRootVerticalLayoutGroup()
    {
        var vlg = GetComponent<VerticalLayoutGroup>();
        if (vlg == null)
        {
            vlg = gameObject.AddComponent<VerticalLayoutGroup>();
        }

        vlg.childAlignment = TextAnchor.UpperLeft;
        vlg.childControlWidth = true;
        vlg.childControlHeight = true;
        vlg.childForceExpandWidth = true;
        vlg.childForceExpandHeight = true;
        vlg.spacing = 0f;

        int pad = Mathf.RoundToInt(S.Padding);
        vlg.padding = new RectOffset(pad, pad, pad, pad);
    }

    private void ForceRecomputeRootSize()
    {
        if (_rectTransform == null || _contentRect == null) return;

        float contentWidth = _contentRect.rect.width;
        float contentHeight = _contentRect.rect.height;

        if (contentHeight <= 0.5f && _contentRect.childCount > 0)
        {
            contentHeight = 0f;
            for (int i = 0; i < _contentRect.childCount; i++)
            {
                var child = _contentRect.GetChild(i) as RectTransform;
                if (child != null)
                    contentHeight += child.rect.height;
            }
        }

        float padding = S.Padding * 2f;
        float targetWidth = Mathf.Max(S.MinWidth, contentWidth + padding);
        float targetHeight = contentHeight + padding;

        _rectTransform.sizeDelta = new Vector2(targetWidth, targetHeight);

        if (S.MaxWidth > 0 && targetWidth > S.MaxWidth)
            _rectTransform.sizeDelta = new Vector2(S.MaxWidth, targetHeight);

        LayoutRebuilder.ForceRebuildLayoutImmediate(_rectTransform);
    }

    private IEnumerator RebuildNextFrame()
    {
        yield return null;
        if (!gameObject.activeSelf) yield break;

        if (_contentRect != null)
            LayoutRebuilder.ForceRebuildLayoutImmediate(_contentRect);

        if (_rectTransform != null)
            LayoutRebuilder.ForceRebuildLayoutImmediate(_rectTransform);

        ForceRecomputeRootSize();

        // ФИКС: Повторно позиционируем меню после того, как Layout полностью пересчитан
        PositionMenu(_lastScreenPosition);

        _rebuildCoroutine = null;
    }

    public void Hide()
    {
        if (_stage4Tooltip != null) _stage4Tooltip.SetActive(false);
        // 6.6: сброс медицинского контекста.
        _currentMedicalRecord = null;

        if (_hideCoroutine != null)
        {
            StopCoroutine(_hideCoroutine);
            _hideCoroutine = null;
        }
        if (!gameObject.activeSelf) return;
        _hideCoroutine = StartCoroutine(HideRoutine());
    }

    public void ShowDescription(InventoryItem item)
    {
        if (item == null || item.Data == null) return;
        gameObject.SetActive(false);
        ShowDescriptionPanel(item);
    }

    // Stage 4: virtual items are display data only; they never enter an inventory here.
    public void ShowApplied(AppliedMedicalRecord record, Vector2 screenPosition,
        K_InventoryUI inventoryUI, K_HealthSystem health)
    {
        if (record == null || inventoryUI == null || health == null) return;
        var item = K_AppliedMedicalInventoryBridge.FindItem(inventoryUI, record.InstanceID);
        if (item == null)
        {
            var data = K_InventorySetup.DatabaseInstance?.GetItemData(record.VirtualItemID);
            if (data == null) return;
            item = new InventoryItem(data, record.InstanceID, record.VirtualQuantity,
                record.VirtualDurability, false, record.ChargePercent,
                record.RemainingSeconds); // Stage 4 revision: keep exact display-item data.
        }
        Show(item, screenPosition, inventoryUI, appliedHealth: health);
    }

    #endregion

    #region Menu Building

    private void BuildMenu()
    {
        ClearMenuItems();
        _currentEntries = GetEntriesForItem(_currentItem);
        _currentEntries.RemoveAll(entry => !entry.IsSeparator && !IsImplementedAction(entry.Action));
        for (int i = _currentEntries.Count - 1; i >= 0; i--)
            if (_currentEntries[i].IsSeparator && (i == 0 || i == _currentEntries.Count - 1 ||
                _currentEntries[i - 1].IsSeparator)) _currentEntries.RemoveAt(i);

        int lastButtonIndex = -1;
        for (int i = _currentEntries.Count - 1; i >= 0; i--)
        {
            if (!_currentEntries[i].IsSeparator)
            {
                lastButtonIndex = i;
                break;
            }
        }

        for (int i = 0; i < _currentEntries.Count; i++)
        {
            var entry = _currentEntries[i];
            if (entry.IsSeparator)
            {
                CreateSeparator();
                continue;
            }
            bool isLast = (i == lastButtonIndex);
            CreateButton(entry, isLast);
        }
    }

   private List<MenuEntry> GetEntriesForItem(InventoryItem item)
{
    var entries = new List<MenuEntry>();
    ItemType type = item.Type;
    bool isEquipped = _currentEquipmentSlot != null && _currentEquipmentSlot.EquippedItem == item;

    switch (type)
    {
        case ItemType.Weapon: BuildWeaponEntries(entries, item, isEquipped); break;
        case ItemType.Ammo: BuildAmmoEntries(entries, item, isEquipped); break;
        case ItemType.Medical: BuildMedicalEntries(entries, item, isEquipped); break;
        case ItemType.Consumable: BuildConsumableEntries(entries, item, isEquipped); break;
        case ItemType.Clothing: BuildClothingEntries(entries, item, isEquipped); break;
        case ItemType.Backpack: BuildBackpackEntries(entries, item, isEquipped); break;
        case ItemType.Tool: BuildToolEntries(entries, item, isEquipped); break;
        case ItemType.Armor: BuildArmorEntries(entries, item, isEquipped); break;
        case ItemType.Magazine:
            entries.Add(new MenuEntry { Label = "Зарядить", Action = ContextAction.LoadLooseMagazine,
                IsDisabled = _currentInventoryUI?.CombatController == null ||
                    !_currentInventoryUI.OwnsCombatTarget(item) });
            break;
        default: BuildDefaultEntries(entries, item, isEquipped); break;
    }

    // A single shared rule covers every type builder, including early-returning medical menus.
    if (!isEquipped && _currentAppliedRecord == null &&
        K_SplitStackDialog.CanSplitItem(item, _currentInventoryUI))
        entries.Add(new MenuEntry { Label = "Разделить", Action = ContextAction.Split });

    if (_currentInventoryUI != null && !_currentInventoryUI.CanEquipGroundLootItem(item))
        for (int i = 0; i < entries.Count; i++)
            if (entries[i].Action == ContextAction.Equip)
            {
                var entry = entries[i];
                entry.IsDisabled = true;
                entry.DisabledReason = "Сначала освободите подходящий слот экипировки";
                entries[i] = entry;
            }

    AddSeparatorIfNotEmpty(entries);
    entries.Add(new MenuEntry { Label = "Описание", Action = ContextAction.Description, IsDanger = false });
    if (_currentInventoryUI == null || !_currentInventoryUI.IsGroundLootItem(item))
        entries.Add(new MenuEntry { Label = "Выбросить", Action = ContextAction.Drop, IsDanger = true });
    return entries;
}
private void BuildArmorEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
{
    entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
    entries.Add(new MenuEntry { IsSeparator = true });
    if (isEquipped)
        entries.Add(new MenuEntry { Label = "Снять", Action = ContextAction.Unequip });
    else
        entries.Add(new MenuEntry { Label = "Надеть", Action = ContextAction.Equip });
}

    #endregion

    #region Per-Type Entry Builders

    private void BuildWeaponEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.InspectWeapon });
        entries.Add(new MenuEntry { IsSeparator = true });
        entries.Add(new MenuEntry { Label = "Перезарядить", Action = ContextAction.ReloadMagazine });
        entries.Add(new MenuEntry { Label = "Проверить магазин", Action = ContextAction.CheckMagazine });
        if (item.Data.Weapon != null && item.Data.Weapon.MagazineCapacity > 0)
        {
            entries.Add(new MenuEntry { Label = "Извлечь магазин", Action = ContextAction.UnloadMagazine });
            entries.Add(new MenuEntry { Label = "Вставить магазин", Action = ContextAction.LoadMagazine });
        }
        entries.Add(new MenuEntry { IsSeparator = true });
        entries.Add(new MenuEntry { Label = "Дослать патрон", Action = ContextAction.ChamberRound });
        entries.Add(new MenuEntry { Label = "Очистить патронник", Action = ContextAction.ClearChamber });
        if (_currentInventoryUI?.CombatController?.IsWeaponMisfired(item) == true)
            entries.Add(new MenuEntry { Label = "Устранить осечку", Action = ContextAction.CockWeapon });
        entries.Add(new MenuEntry { Label = "Режим огня", Action = ContextAction.ToggleFireMode });
        entries.Add(new MenuEntry { Label = "Починить", Action = ContextAction.Repair,
            IsDisabled = true, DisabledReason = "Требуется ремонтный комплект" });
        entries.Add(new MenuEntry { IsSeparator = true });
    }

    private void BuildAmmoEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { IsSeparator = true });
        entries.Add(new MenuEntry { Label = "Переложить патроны", Action = ContextAction.TransferAmmo });
    }

    private void BuildMedicalEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        // Stage 4: only removal, description and the common drop stub for active items.
        if (_currentAppliedRecord != null && _currentAppliedHealth?.AppliedMedical != null)
        {
            bool enabled = _currentAppliedHealth.AppliedMedical.CanRemove(_currentAppliedRecord, out string reason);
            entries.Add(new MenuEntry { Label = "Снять", Action = ContextAction.RemoveApplied,
                IsDisabled = !enabled, DisabledReason = reason });
            return;
        }
        if (item?.Data != null && K_AppliedMedicalManager.TryGetKind(item.Data.ItemID, out var kind))
        {
            if (_currentAppliedHealth?.AppliedMedical == null) return;
            var parents = new[] { BodyPart.LeftShoulder, BodyPart.RightShoulder,
                BodyPart.LeftQuadriceps, BodyPart.RightQuadriceps };
            var labels = new[] { "Использовать на левое плечо", "Использовать на правое плечо",
                "Использовать на левое бедро", "Использовать на правое бедро" };
            for (int i = 0; i < parents.Length; i++)
                if (_currentAppliedHealth.AppliedMedical.CanApply(item, parents[i], kind, out _))
                    entries.Add(new MenuEntry { Label = labels[i], Action = ContextAction.ApplyToPart,
                        TargetPart = parents[i] });
            return;
        }
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { IsSeparator = true });

        var svc = _currentInventoryUI?.MedicalApplyService;
        if (svc == null)
        {
            entries.Add(new MenuEntry
            {
                Label = "Применить (сервис недоступен)",
                Action = ContextAction.ApplyToPart,
                TargetPart = null,
                IsDisabled = true,
                DisabledReason = "Сервис применения недоступен"
            });
            return;
        }

        string itemID = item?.Data?.ItemID;
        var validParts = svc.GetValidPartsForItem(itemID);

        if (item.Data.ChargeCategory == ChargeCategory.AmountAbsolute)
        {
            string reason = "Сначала переместите предмет в свой инвентарь";
            bool available = _currentMedicalRecord.HasValue && validParts != null && validParts.Count > 0 &&
                svc.CanTransfuse(_currentMedicalRecord.Value, validParts[0], out _, out reason);
            entries.Add(new MenuEntry { Label = "Перелить кровь", Action = ContextAction.Use,
                IsDisabled = !available, DisabledReason = reason });
            return;
        }

        if (validParts == null || validParts.Count == 0)
        {
            entries.Add(new MenuEntry
            {
                Label = "Применить (нет подходящих травм)",
                Action = ContextAction.ApplyToPart,
                TargetPart = null,
                IsDisabled = true,
                DisabledReason = "Нет подходящих травм"
            });
            return;
        }

        for (int i = 0; i < validParts.Count; i++)
        {
            var part = validParts[i];
            entries.Add(new MenuEntry
            {
                Label = $"Применить на {BodyPartLocalization.GetRussian(part)}",
                Action = ContextAction.ApplyToPart,
                TargetPart = part
            });
        }
    }

    private void BuildConsumableEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        string value = item.Data.ConsumableTotalValue.ToString("0.##", System.Globalization.CultureInfo.InvariantCulture);
        if (item.Data.ConsumableType == ConsumableType.Drink)
            entries.Add(new MenuEntry { Label = $"Выпить (+{value}%)", Action = ContextAction.Drink });
        else if (item.Data.ConsumableType == ConsumableType.Food)
            entries.Add(new MenuEntry { Label = $"Съесть (+{value}%)", Action = ContextAction.Eat });
        else entries.Add(new MenuEntry { Label = "Использовать", Action = ContextAction.Use });

    }

    private void BuildClothingEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { IsSeparator = true });
        if (isEquipped) entries.Add(new MenuEntry { Label = "Снять", Action = ContextAction.Unequip });
        else entries.Add(new MenuEntry { Label = "Надеть", Action = ContextAction.Equip });
    }

   private void BuildBackpackEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
{
    entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
    entries.Add(new MenuEntry { IsSeparator = true });

    // ═══ ФИКС: Определяем, открыт ли рюкзак как окно ═══
    bool isWindowOpen = _currentInventoryUI != null
                        && _currentInventoryUI.IsBackpackWindowOpen(item);

    if (item.CanFold)
    {
        bool isContentsEmpty = _currentInventoryUI?.IsBackpackContentsEmpty(item) ?? true;
        bool alwaysShowGrid = item.Data != null && item.Data.AlwaysShowGrid;
        
        // ⬇️ НОВАЯ ПРОВЕРКА
        bool isAtMaxDepth = _currentInventoryUI?.IsAtMaxNestingDepth(item) ?? false;

        if (item.IsFolded)
        {
            if (!isEquipped && alwaysShowGrid)
            {
                // ═══ ФИКС: "Закрыть" если открыт, "Открыть" если закрыт ═══
                if (isWindowOpen)
                    entries.Add(new MenuEntry { Label = "Закрыть", Action = ContextAction.CloseBackpack });
                else
                    entries.Add(new MenuEntry { Label = "Открыть", Action = ContextAction.OpenBackpack });
            }

            bool canUnfold = _currentInventoryUI?.CanUnfoldInCurrentGrid(item) ?? true;
            
            // ⬇️ ИЗМЕНЕНО: учитываем лимит вложенности
            if (canUnfold && !isAtMaxDepth)
                entries.Add(new MenuEntry { Label = "Развернуть", Action = ContextAction.Unfold });
            else
                entries.Add(new MenuEntry
                {
                    Label = "Развернуть",
                    Action = ContextAction.Unfold,
                    IsDisabled = true,
                    DisabledReason = isAtMaxDepth ? "Достигнут лимит вложенности" : "Не хватает места в сетке"
                });

            if (!isContentsEmpty && !isEquipped && alwaysShowGrid)
                entries.Add(new MenuEntry { Label = "Опустошить", Action = ContextAction.EmptyBackpack });
        }
        else
        {
            if (!isEquipped)
            {
                // ═══ ФИКС: "Закрыть" если открыт, "Открыть" если закрыт ═══
                if (isWindowOpen)
                    entries.Add(new MenuEntry { Label = "Закрыть", Action = ContextAction.CloseBackpack });
                else
                    entries.Add(new MenuEntry { Label = "Открыть", Action = ContextAction.OpenBackpack });
            }

            if (!isContentsEmpty && !isEquipped)
                entries.Add(new MenuEntry { Label = "Опустошить", Action = ContextAction.EmptyBackpack });

            if (!isEquipped && isContentsEmpty)
                entries.Add(new MenuEntry { Label = "Свернуть", Action = ContextAction.Fold });
            else if (!isEquipped)
                entries.Add(new MenuEntry
                {
                    Label = "Свернуть",
                    Action = ContextAction.Fold,
                    IsDisabled = true,
                    DisabledReason = "Рюкзак не пуст — опустошите через ПКМ"
                });
        }

        entries.Add(new MenuEntry { IsSeparator = true });
    }
    else
    {
        if (!isEquipped && !item.IsFolded)
        {
            // ═══ ФИКС: "Закрыть" если открыт, "Открыть" если закрыт ═══
            if (isWindowOpen)
                entries.Add(new MenuEntry { Label = "Закрыть", Action = ContextAction.CloseBackpack });
            else
                entries.Add(new MenuEntry { Label = "Открыть", Action = ContextAction.OpenBackpack });

            entries.Add(new MenuEntry { IsSeparator = true });
        }
    }

    if (isEquipped) entries.Add(new MenuEntry { Label = "Снять", Action = ContextAction.Unequip });
    else entries.Add(new MenuEntry { Label = "Надеть", Action = ContextAction.Equip });
}
    

    private void BuildToolEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { Label = "Ремонт", Action = ContextAction.Repair });
    }

    private void BuildDefaultEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { IsSeparator = true });
    }

    private void AddSeparatorIfNotEmpty(List<MenuEntry> entries) { }

    #endregion

    #region UI Creation

    private void CreateButton(MenuEntry entry, bool isLast)
    {
        if (_contentRect == null) return;

        GameObject go;
        var prefab = S.MenuItemPrefab;
        if (prefab != null)
        {
            go = Instantiate(prefab, _contentRect);
        }
        else
        {
            go = CreateButtonProgrammatically(entry);
            go.transform.SetParent(_contentRect, false);
        }

        _spawnedItems.Add(go);

        var rt = go.GetComponent<RectTransform>();
        if (rt != null)
        {
            rt.anchorMin = new Vector2(0, 1);
            rt.anchorMax = new Vector2(1, 1);
            rt.pivot = new Vector2(0.5f, 1);
            rt.sizeDelta = new Vector2(0, S.ButtonHeight);
        }

        var le = go.GetComponent<LayoutElement>();
        if (le != null)
        {
            le.minHeight = S.ButtonHeight;
            le.preferredHeight = S.ButtonHeight;
        }

        var text = go.GetComponentInChildren<TextMeshProUGUI>();
        if (text != null)
        {
            text.text = entry.Label;
            text.fontSize = S.FontSize;
            text.color = entry.IsDisabled ? S.DisabledTextColor :
                         entry.IsDanger ? S.TextDangerColor : S.TextColor;
            if (S.Font != null) text.font = S.Font;
        }

        var button = go.GetComponent<Button>();
        if (button != null)
        {
            if (entry.IsDisabled)
            {
                button.interactable = false;
            }
            else
            {
                ColorBlock colors = button.colors;
                colors.normalColor = entry.IsDanger ? S.DangerColor : S.NormalColor;
                colors.highlightedColor = entry.IsDanger ? S.DangerHoverColor : S.HoverColor;
                colors.pressedColor = entry.IsDanger ? S.DangerColor : S.PressedColor;
                colors.fadeDuration = 0.1f;
                button.colors = colors;

                var entryAction = entry.Action;
                var entryPart = entry.TargetPart;   // 6.6
                button.onClick.AddListener(() => {
                    OnActionClicked(entryAction, entryPart);
                });
            }
        }

        var img = go.GetComponent<Image>();
        if (img != null)
            img.color = entry.IsDanger ? S.DangerColor : S.NormalColor;
        // Stage 4: disabled removal explains why without attempting a mutation.
        if ((entry.Action == ContextAction.RemoveApplied || entry.Action == ContextAction.Repair) && entry.IsDisabled)
        {
            var trigger = go.GetComponent<EventTrigger>() ?? go.AddComponent<EventTrigger>();
            var enter = new EventTrigger.Entry { eventID = EventTriggerType.PointerEnter };
            enter.callback.AddListener(_ => ShowRemovalTooltip(go, entry.DisabledReason));
            var exit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
            exit.callback.AddListener(_ => { if (_stage4Tooltip != null) _stage4Tooltip.SetActive(false); });
            trigger.triggers.Add(enter); trigger.triggers.Add(exit);
        }
    }

    private void ShowRemovalTooltip(GameObject button, string reason)
    {
        if (_stage4Tooltip == null)
        {
            _stage4Tooltip = new GameObject("Stage4RemovalTooltip", typeof(RectTransform), typeof(Image), typeof(LayoutElement));
            _stage4Tooltip.transform.SetParent(transform, false);
            _stage4Tooltip.GetComponent<LayoutElement>().ignoreLayout = true;
            var background = _stage4Tooltip.GetComponent<Image>();
            background.color = new Color(0.08f, 0.08f, 0.08f, 0.98f); background.raycastTarget = false;
            var textObject = new GameObject("Text", typeof(RectTransform), typeof(TextMeshProUGUI));
            textObject.transform.SetParent(_stage4Tooltip.transform, false);
            var textRect = textObject.GetComponent<RectTransform>();
            textRect.anchorMin = Vector2.zero; textRect.anchorMax = Vector2.one;
            textRect.offsetMin = new Vector2(6f, 4f); textRect.offsetMax = new Vector2(-6f, -4f);
            textRect.localScale = Vector3.one;
            var label = textObject.GetComponent<TextMeshProUGUI>();
            label.fontSize = S.FontSize; label.color = Color.white; label.raycastTarget = false;
            if (S.Font != null) label.font = S.Font;
        }
        var rt = _stage4Tooltip.GetComponent<RectTransform>();
        rt.pivot = new Vector2(0f, 1f); rt.localScale = Vector3.one;
        rt.sizeDelta = new Vector2(240f, 46f);
        rt.position = button.transform.position;
        _stage4Tooltip.GetComponentInChildren<TextMeshProUGUI>().text = reason;
        _stage4Tooltip.transform.SetAsLastSibling(); _stage4Tooltip.SetActive(true);
    }

    private GameObject CreateButtonProgrammatically(MenuEntry entry)
    {
        var go = new GameObject("MenuBtn_" + entry.Label, typeof(RectTransform), typeof(Image), typeof(Button));

        var bg = go.GetComponent<Image>();
        bg.color = entry.IsDanger ? S.DangerColor : S.NormalColor;
        bg.raycastTarget = true;

        var btn = go.GetComponent<Button>();
        btn.targetGraphic = bg;

        var le = go.AddComponent<LayoutElement>();
        le.minHeight = S.ButtonHeight;
        le.preferredHeight = S.ButtonHeight;
        le.minWidth = S.MinWidth;

        var nav = btn.navigation;
        nav.mode = Navigation.Mode.None;
        btn.navigation = nav;

        var textObj = new GameObject("Label", typeof(RectTransform));
        textObj.transform.SetParent(go.transform, false);
        var tmp = textObj.AddComponent<TextMeshProUGUI>();
        tmp.text = entry.Label;
        tmp.fontSize = S.FontSize;
        tmp.alignment = TextAlignmentOptions.MidlineLeft;
        tmp.color = entry.IsDisabled ? S.DisabledTextColor :
                    entry.IsDanger ? S.TextDangerColor : S.TextColor;
        if (S.Font != null) tmp.font = S.Font;

        var textRT = textObj.GetComponent<RectTransform>();
        textRT.anchorMin = new Vector2(0, 0);
        textRT.anchorMax = new Vector2(1, 1);
        textRT.offsetMin = new Vector2(S.TextLeftPadding, 0f);
        textRT.offsetMax = new Vector2(-S.TextRightPadding, 0f);

        return go;
    }

    private void CreateSeparator()
    {
        if (_contentRect == null) return;

        GameObject go;
        var sepPrefab = S.SeparatorPrefab;
        if (sepPrefab != null)
        {
            go = Instantiate(sepPrefab, _contentRect);
        }
        else
        {
            go = new GameObject("Separator", typeof(RectTransform), typeof(Image), typeof(LayoutElement));
            go.transform.SetParent(_contentRect, false);
            var sepImg = go.GetComponent<Image>();
            sepImg.color = S.SeparatorColor;
            sepImg.raycastTarget = false;
            var sepLe = go.GetComponent<LayoutElement>();
            sepLe.minHeight = S.SeparatorHeight;
            sepLe.preferredHeight = S.SeparatorHeight;
        }

        _spawnedItems.Add(go);

        var img = go.GetComponent<Image>();
        if (img != null) img.color = S.SeparatorColor;

        var rt = go.GetComponent<RectTransform>();
        if (rt != null)
        {
            rt.anchorMin = new Vector2(0, 1);
            rt.anchorMax = new Vector2(1, 1);
            rt.pivot = new Vector2(0.5f, 1);
            rt.sizeDelta = new Vector2(-S.Padding * 2, S.SeparatorHeight);
        }
    }

    private void ClearMenuItems()
    {
        foreach (var item in _spawnedItems)
            if (item != null) Destroy(item);
        _spawnedItems.Clear();
    }

    #endregion

    #region Positioning

    private void PositionMenu(Vector2 screenPosition)
    {
        if (_rectTransform == null || _canvas == null) return;

        LayoutRebuilder.ForceRebuildLayoutImmediate(_rectTransform);

        float width = Mathf.Clamp(_rectTransform.rect.width, S.MinWidth, S.MaxWidth);
        float height = _rectTransform.rect.height;

        float x = screenPosition.x + S.OffsetFromCursor.x;
        float y = screenPosition.y + S.OffsetFromCursor.y;

        if (x + width > Screen.width) x = screenPosition.x - width - S.OffsetFromCursor.x;
        if (y - height < 0) y = screenPosition.y + height + Mathf.Abs(S.OffsetFromCursor.y);

        Vector2 clampedScreenPos = new Vector2(x, y);

        Canvas rootCanvas = _canvas.rootCanvas;
        Camera cam = rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : rootCanvas.worldCamera;

        // ФИКС: Корректное преобразование экранных координат в мировые с учетом Canvas Scaler и Render Mode
        if (RectTransformUtility.ScreenPointToWorldPointInRectangle(rootCanvas.transform as RectTransform, clampedScreenPos, cam, out Vector3 worldPos))
        {
            _rectTransform.position = worldPos;
        }
        else
        {
            _rectTransform.position = new Vector3(x, y, 0f);
        }

        _rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, width);
    }

    #endregion

    #region Animation

    private IEnumerator FadeInRoutine()
    {
        while (_canvasGroup != null && _canvasGroup.alpha < 1f)
        {
            _canvasGroup.alpha += S.AppearSpeed * Time.deltaTime;
            yield return null;
        }
        if (_canvasGroup != null) _canvasGroup.alpha = 1f;
    }

    private IEnumerator HideRoutine()
    {
        if (_canvasGroup != null)
        {
            while (_canvasGroup.alpha > 0f)
            {
                _canvasGroup.alpha -= S.AppearSpeed * Time.deltaTime;
                yield return null;
            }
        }
        gameObject.SetActive(false);
        ClearMenuItems();
        _hideCoroutine = null;
    }

    #endregion

    #region Description Panel

    private void ShowDescriptionPanel(InventoryItem item)
    {
        var descPrefab = S.DescriptionPanelPrefab;
        if (descPrefab == null) return;

        var panel = Instantiate(descPrefab, transform.root);
        Debug.Log($"[ContextMenu] Показать описание: {item?.Data?.DisplayName}");
    }

    #endregion

    #region Action Handling

    private void OnActionClicked(ContextAction action, BodyPart? targetPart = null)
    {
        if (!IsImplementedAction(action) || K_SplitStackDialog.IsItemLocked(_currentItem)) return;
        if (_currentItem == null)
        {
            Debug.LogWarning($"[K_ContextMenu] OnActionClicked: _currentItem is null (action={action}).");
            return;
        }

        switch (action)
        {
            case ContextAction.ReloadMagazine: HandleReloadMagazine(); break;
            case ContextAction.LoadLooseMagazine:
                _currentInventoryUI?.CombatController?.TryBeginMagazineLoad(_currentItem);
                break;
            case ContextAction.UnloadMagazine: HandleUnloadMagazine(); break;
            case ContextAction.LoadMagazine: HandleLoadMagazine(); break;
            case ContextAction.CheckMagazine: HandleCheckMagazine(); break;
            case ContextAction.ChamberRound: HandleChamberRound(); break;
            case ContextAction.ClearChamber: HandleClearChamber(); break;
            case ContextAction.CockWeapon: HandleCockWeapon(); break;
            case ContextAction.ToggleFireMode: HandleToggleFireMode(); break;
            case ContextAction.Eat:
            case ContextAction.Drink:
            case ContextAction.Use: HandleUse(); break;
            case ContextAction.ApplyToPart: HandleApplyToPart(targetPart); break;
            case ContextAction.RemoveApplied:
                if (_currentAppliedRecord != null && _currentAppliedHealth?.AppliedMedical != null &&
                    !_currentAppliedHealth.AppliedMedical.TryRemove(_currentAppliedRecord, out string removeReason))
                    Debug.LogWarning($"[K_ContextMenu] {removeReason}");
                break;
            case ContextAction.Equip:
            case ContextAction.Unequip: HandleEquipUnequip(action == ContextAction.Equip); break;
            case ContextAction.Fold: HandleFold(); break;
            case ContextAction.Unfold: HandleUnfold(); break;
            case ContextAction.OpenBackpack: HandleOpenBackpack(); break;
            case ContextAction.CloseBackpack: HandleCloseBackpack(); break;
            case ContextAction.EmptyBackpack: HandleEmptyBackpack(); break;
            case ContextAction.Drop: HandleDrop(); break;
            case ContextAction.Description: ShowDescription(_currentItem); return;
            case ContextAction.Split: HandleSplit(); break;
            case ContextAction.Repair: HandleRepair(); break;
        }

        Hide();
    }

    #endregion

    #region Action Implementations 
    public static bool IsImplementedAction(ContextAction action) =>
        action != ContextAction.Inspect && action != ContextAction.InspectWeapon &&
        action != ContextAction.Discard && action != ContextAction.TransferAmmo;

    private void HandleReloadMagazine()
    {
        _currentInventoryUI?.CombatController?.TryBeginWeaponReload(_currentItem);
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Перезарядка: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleUnloadMagazine()
    {
        if (_currentInventoryUI != null && !_currentInventoryUI.TryDetachWeaponMagazine(_currentItem, out string reason))
            Debug.LogWarning($"[ContextMenu] {reason}");
    }

    private void HandleLoadMagazine()
    {
        _currentInventoryUI?.CombatController?.TryBeginWeaponReload(_currentItem);
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Вставка магазина: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleCheckMagazine()
    {
        if (_currentInventoryUI != null && !_currentInventoryUI.TryCheckWeaponMagazine(_currentItem, out _, out string reason))
            Debug.LogWarning($"[ContextMenu] {reason}");
    }

    private void HandleChamberRound()
    {
        if (_currentInventoryUI != null && !_currentInventoryUI.TryCycleWeaponChamber(_currentItem, out string reason))
            Debug.LogWarning($"[ContextMenu] {reason}");
    }

    private void HandleClearChamber()
    {
        if (_currentInventoryUI != null && !_currentInventoryUI.TryClearWeaponChamber(_currentItem, out string reason))
            Debug.LogWarning($"[ContextMenu] {reason}");
    }

    private void HandleCockWeapon()
    {
        _currentInventoryUI?.CombatController?.ClearMisfire(_currentItem);
    }

    private void HandleToggleFireMode()
    {
        _currentInventoryUI?.CombatController?.CycleFireMode(_currentItem);
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Режим огня: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleUse()
    {
        if (_currentItem?.Data == null || _currentInventoryUI == null) return;
        if (_currentItem.Data.ConsumableType != ConsumableType.None)
        {
            _currentInventoryUI.TryOpenConsumableQuantity(_currentItem, _lastScreenPosition);
            return;
        }
        if (_currentItem.Data.IsRepairKit) { HandleRepair(); return; }
        var service = _currentInventoryUI.MedicalApplyService;
        if (service != null && _currentMedicalRecord.HasValue)
        {
            var parts = service.GetValidPartsForItem(_currentItem.Data.ItemID);
            if (parts != null && parts.Count > 0)
            {
                service.TryStartApply(_currentMedicalRecord.Value, parts[0], null);
                return;
            }
        }
        Debug.LogWarning("[ContextMenu] Нет доступного применения. Медикамент должен находиться в своём инвентаре и иметь подходящую цель.");
    }

    private void HandleApplyToPart(BodyPart? part)
    {
        if (part == null) return; // disabled-строка

        // Stage 4: loot is not in MedicalInventoryService, so resolve its controller directly.
        if (_currentItem?.Data != null &&
            K_AppliedMedicalManager.TryGetKind(_currentItem.Data.ItemID, out var kind))
        {
            var source = _currentInventoryUI?.FindControllerForItem(_currentItem);
            if (!K_AppliedMedicalInventoryBridge.TryApply(_currentInventoryUI, _currentAppliedHealth,
                _currentItem, source, part.Value, kind, out string reason))
                Debug.LogWarning($"[K_ContextMenu] {reason}");
            return;
        }

        var svc = _currentInventoryUI?.MedicalApplyService;
        if (svc == null)
        {
            Debug.LogWarning("[K_ContextMenu] HandleApplyToPart: MedicalApplyService is null.");
            return;
        }

        if (_currentMedicalRecord == null)
        {
            Debug.LogWarning("[K_ContextMenu] HandleApplyToPart: _currentMedicalRecord is null.");
            return;
        }

        svc.TryStartApply(_currentMedicalRecord.Value, part.Value, null);
    }

    private void HandleEquipUnequip(bool equip)
    {
        if (_currentItem == null || _currentInventoryUI == null) return;

        if (equip)
        {
            // ═══════════════════════════════════════════════════════════════
            //  БЛОК 3: Контекстное меню (ПКМ → Надеть).
            //
            //  Делегируем в InventoryTransactionService.TryEquipFromContextMenu:
            //    1. Определяется целевой слот экипировки (по типу предмета).
            //    2. Если слот пуст — простой перенос.
            //    3. Если слот занят — свап: A уходит в слот, B — на старое
            //       место A (с FindFreeSpace при нехватке места).
            //    4. При ошибке — транзакция откатывается, предмет остаётся
            //       на месте, errorMessage выводится в лог.
            //
            //  Сервис сам вызывает ForceRefresh после успеха — UI обновится.
            // ═══════════════════════════════════════════════════════════════
            var tx = InventoryTransactionService.Instance;
            if (tx == null)
            {
                Debug.LogError("[K_ContextMenu] InventoryTransactionService.Instance is null — cannot equip.");
                return;
            }

            if (tx.IsTransactionActive)
            {
                Debug.LogWarning("[K_ContextMenu] Cannot equip: another transaction is active.");
                return;
            }

            bool ok = tx.TryEquipFromContextMenuAtomic(_currentItem, out string errorMessage);
            if (!ok)
            {
                Debug.LogWarning(
                    $"[K_ContextMenu] Equip failed for '{_currentItem.Data?.DisplayName}': {errorMessage}");
            }
#if UNITY_EDITOR
            else
            {
                Debug.Log($"[K_ContextMenu] Equip OK: {_currentItem.Data?.DisplayName}");
            }
#endif
        }
        else
        {
            // Снять (unequip) — оставляем прежнюю логику через слот.
            if (_currentEquipmentSlot != null)
            {
                _currentEquipmentSlot.Unequip();
            }
        }
    }

    private void HandleFold()
    {
        if (_currentItem == null || _currentInventoryUI == null)
        {
            Debug.LogWarning($"[V9-CTX] HandleFold: _currentItem={(_currentItem == null ? "null" : "ok")}, _currentInventoryUI={(_currentInventoryUI == null ? "null" : "ok")}");
            return;
        }

        // ═══ БАГ ФИКС (fold/unfold через ПКМ перестаёт работать): ═══
        // Двойная проверка пустоты рюкзака. BuildBackpackEntries уже проверяет
        // isContentsEmpty, но между показом меню и кликом игрока состояние могло
        // измениться (например, другой скрипт положил предмет в рюкзак).
        // Без этой проверки ToggleBackpackFold → HandleInventoryBackpackFold
        // попытается свернуть непустой рюкзак, что приведёт к:
        //   1) SyncBackpackContentsBeforeFold сохранит содержимое в _backpackContentsSerialized
        //   2) IsBackpackContentsEmpty вернёт false → abort
        //   3) НО! Если между этими шагами что-то пошло не так, рюкзак может остаться
        //      в рассинхронизированном состоянии (IsFolded=false, но _backpackContentsSerialized
        //      уже обновлён, а контроллер не очищен).
        // Повторная проверка здесь — дешёвая страховка.
        bool isContentsEmpty = _currentInventoryUI.IsBackpackContentsEmpty(_currentItem);
        if (!isContentsEmpty)
        {
            Debug.LogWarning($"[V9-CTX] HandleFold: ABORT — backpack '{_currentItem.Data?.DisplayName}' is not empty. " +
                "Player must empty it first (right-click → Empty).");
            return;
        }

        Debug.Log($"[V9-CTX] HandleFold: item={_currentItem.Data?.DisplayName}, isContentsEmpty={isContentsEmpty}");
        _currentInventoryUI.ToggleBackpackFold(_currentItem, fold: true);
    }

   private void HandleUnfold()
{
    if (_currentItem == null || _currentInventoryUI == null)
    {
        Debug.LogWarning($"[V9-CTX] HandleUnfold: _currentItem={(_currentItem == null ? "null" : "ok")}, _currentInventoryUI={(_currentInventoryUI == null ? "null" : "ok")}");
        return;
    }
    
    // ⬇️ НОВАЯ ПРОВЕРКА (страховка от прямого вызова)
    if (_currentInventoryUI.IsAtMaxNestingDepth(_currentItem))
    {
        Debug.LogWarning($"[V9-CTX] HandleUnfold: ABORT — backpack '{_currentItem.Data?.DisplayName}' is at max nesting depth.");
        return;
    }
    
    Debug.Log($"[V9-CTX] HandleUnfold: item={_currentItem.Data?.DisplayName}, IsFolded={_currentItem.IsFolded}, CanFold={_currentItem.CanFold}");
    _currentInventoryUI.ToggleBackpackFold(_currentItem, fold: false);
}
    private void HandleOpenBackpack()
    {
        Debug.Log($"[CTX-OPEN] HandleOpenBackpack START: item={_currentItem?.Data?.DisplayName}, " +
            $"_currentInventoryUI={(_currentInventoryUI != null)}");

        if (_currentItem == null || _currentInventoryUI == null)
        {
            Debug.LogWarning($"[CTX-OPEN] ABORT: _currentItem={(_currentItem != null)}, " +
                $"_currentInventoryUI={(_currentInventoryUI != null)}");
            return;
        }

        if (!_currentItem.Data.IsBackpack)
        {
            Debug.LogWarning($"[CTX-OPEN] '{_currentItem.Data.DisplayName}' is not a backpack");
            return;
        }

        if (_currentItem.IsFolded && !_currentItem.Data.AlwaysShowGrid)
        {
            Debug.Log($"[CTX-OPEN] Cannot open folded backpack '{_currentItem.Data.DisplayName}' — " +
                "unfold first (or set AlwaysShowGrid=true in ItemStaticData).");
            return;
        }

        Debug.Log($"[CTX-OPEN] Calling OpenBackpackAsContainer for '{_currentItem.Data.DisplayName}'...");
        _currentInventoryUI.OpenBackpackAsContainer(_currentItem);
        Debug.Log($"[CTX-OPEN] OpenBackpackAsContainer returned.");
    }
    private void HandleCloseBackpack()
    {
        if (_currentItem == null || _currentInventoryUI == null) return;
        if (!_currentItem.Data.IsBackpack) return;

        Debug.Log($"[CTX-CLOSE] Closing backpack window for '{_currentItem.Data.DisplayName}'");
        _currentInventoryUI.CloseBackpackWindowByItem(_currentItem);
    }
    private void HandleEmptyBackpack()
    {
        if (_currentItem == null || _currentInventoryUI == null) return;

        if (!_currentItem.Data.IsBackpack)
        {
            Debug.LogWarning($"[ContextMenu] EmptyBackpack: '{_currentItem.Data.DisplayName}' is not a backpack");
            return;
        }

        if (_currentItem.IsFolded && !_currentItem.Data.AlwaysShowGrid)
        {
            Debug.Log($"[ContextMenu] Cannot empty folded backpack '{_currentItem.Data.DisplayName}' — " +
                "unfold first (or set AlwaysShowGrid=true in ItemStaticData).");
            return;
        }

        _currentInventoryUI.EmptyBackpackContents(_currentItem);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Stage 4.5.1: HandleDrop — мир-дроп.
    //  Stage 4.5.1b: позиция через CharacterController; rollback-порядок.
    //  Stage 4.5.1c: убран lazy-find _cachedPlayerTransform; при null — error+return.
    // ═════════════════════════════════════════════════════════════════════
    private void HandleDrop()
    {
        if (_currentItem == null || _currentInventoryUI == null) return;
        if (_currentInventoryUI.IsGroundLootItem(_currentItem)) return;

        // Stage 4.5.1c: кэш заполняется только в Start (EnsureCaches).
        // Если пусто — это баг инициализации, не лечим его рантайм-поиском.
        if (_cachedPlayerTransform == null)
        {
            Debug.LogError(
                "[K_ContextMenu] HandleDrop: _cachedPlayerTransform is null. " +
                "EnsureCaches must run in Start. Aborting.");
            return;
        }
        Transform playerT = _cachedPlayerTransform;

        // Stage 4.5.1b: позиция через CharacterController + forward×0.5.
        Vector3 dropPosition;
        var cc = playerT.GetComponent<CharacterController>();
        if (cc != null)
        {
            dropPosition = new Vector3(
                playerT.position.x,
                cc.bounds.min.y + 0.1f,
                playerT.position.z);
        }
        else
        {
            dropPosition = playerT.position + Vector3.down * 0.9f;
        }
        dropPosition += playerT.forward * 0.5f;

        if (_currentAppliedRecord != null && _currentAppliedHealth?.AppliedMedical != null)
        {
            HandleDropApplied(_currentAppliedRecord, dropPosition);
            return;
        }

        HandleDropRegular(dropPosition);
    }

    // ═════════════════════════════════════════════════════════════════════
    //  Stage 4.5.1c: захват origin ДО RemoveItem; при null-возврате SpawnItem
    //  пытаемся вернуть предмет в origin-ячейку, затем в первый свободный.
    //  Если не удалось — громкий error (item потерян).
    // ═════════════════════════════════════════════════════════════════════
    private void HandleDropRegular(Vector3 dropPosition)
    {
        var item = _currentItem;
        if (item.Data == null)
        {
            Debug.LogWarning("[K_ContextMenu] HandleDrop: item.Data is null.");
            return;
        }

        if (_currentEquipmentSlot != null && ReferenceEquals(_currentEquipmentSlot.EquippedItem, item))
        {
            if (K_WorldItemSpawner.TryDropEquippedItem(_currentEquipmentSlot, _currentInventoryUI, dropPosition))
            {
                NotifyPickupDropped();
                _currentInventoryUI.ForceRefresh();
            }
            return;
        }

        // 1. Найти контроллер, где лежит предмет.
        var controller = _currentInventoryUI.FindControllerForItem(item);
        if (controller == null)
        {
            Debug.LogWarning($"[K_ContextMenu] HandleDrop: cannot find controller for '{item.Data.DisplayName}'.");
            return;
        }

        // 2. Stage 4.5.1c: захват origin-позиции ДО RemoveItem (для rollback).
        var (originX, originY) = controller.FindItemRootPosition(item.InstanceID);

        // 3. Для рюкзака — синхронизировать дерево содержимого ДО RemoveItem.
        //    Плюс закрыть окна, если рюкзак открыт как контейнер.
        List<SavedItem> contents = null;
        if (item.Data.IsBackpack)
        {
            _currentInventoryUI.CloseAllWindowsForBackpack(item);

            var raw = item.GetBackpackSavedItems();
            if (raw != null && raw.Count > 0)
            {
                contents = new List<SavedItem>(raw.Count);
                for (int i = 0; i < raw.Count; i++)
                {
                    var c = raw[i];
                    contents.Add(SavedItem.DeepClone(c));
                }
            }
        }

        // 4. Удаление из контроллера ДО спавна — устранение дубликата при ошибке спавна.
        if (!controller.RemoveItem(item))
        {
            Debug.LogWarning(
                $"[K_ContextMenu] HandleDrop: RemoveItem failed for '{item.Data.DisplayName}'. Aborting drop.");
            return;
        }

        // 5. Спавн мир-объекта.
        var worldItem = K_WorldItemSpawner.SpawnItem(
            item.Data,
            item.Quantity,
            item.Durability,
            item.ChargePercent,
            item.IsRotated,
            dropPosition,
            contents,
            item.IsFolded,
            item.RemainingChargeSeconds);

        // 6. Stage 4.5.1c: null-guard + rollback в source controller.
        if (worldItem == null)
        {
            Debug.LogError(
                $"[K_ContextMenu] HandleDrop: SpawnItem returned null for '{item.Data.DisplayName}'. " +
                "Attempting rollback into source controller.");

            bool restored = originX >= 0 && originY >= 0 &&
                            controller.PlaceExistingItem(item, originX, originY);
            if (!restored)
                restored = controller.PlaceExistingItemInFirstFreeSlot(item);

            if (!restored)
                Debug.LogError(
                    $"[K_ContextMenu] HandleDrop rollback: cannot re-place '{item.Data.DisplayName}'. " +
                    "Item is LOST.");

            _currentInventoryUI.ForceRefresh();
            return;
        }

        worldItem.InstanceID = item.InstanceID;

        // 7. Кулдаун pickup'а.
        NotifyPickupDropped();

        // 8. ForceRefresh.
        _currentInventoryUI.ForceRefresh();
    }

    private void HandleDropApplied(AppliedMedicalRecord record, Vector3 dropPosition)
    {
        var manager = _currentAppliedHealth.AppliedMedical;

        // Захватываем параметры ДО снятия записи.
        string itemID = record.VirtualItemID;
        int quantity = record.VirtualQuantity;
        int durability = record.VirtualDurability;
        int chargePercent = record.ChargePercent;
        bool isRotated = _currentItem != null && _currentItem.IsRotated;
        uint instanceID = record.InstanceID;

        // Stage 4.5.1b / БЛОКЕР 2: сначала валидируем data. Если шаблон не найден —
        // ничего не снимаем, ничего не удаляем, item остаётся в инвентаре.
        var data = K_InventorySetup.DatabaseInstance?.GetItemData(itemID);
        if (data == null)
        {
            Debug.LogWarning($"[K_ContextMenu] HandleDrop (applied): data '{itemID}' not found. Aborting.");
            return;
        }

        if (!ReferenceEquals(manager.GetRecordForInstance(instanceID), record)) return;

        // Spawn before releasing ownership/effects so a bad prefab cannot consume the item.
        var worldItem = K_WorldItemSpawner.SpawnItem(
            data, quantity, durability, chargePercent, isRotated, dropPosition,
            null, false, record.RemainingSeconds);
        if (worldItem == null) return;
        worldItem.InstanceID = instanceID;

        System.Func<bool> rollback = null;
        if (!record.IsVirtual && !K_AppliedMedicalInventoryBridge.TryDetachForWorldDrop(
            _currentInventoryUI, instanceID, out rollback))
        {
            worldItem.gameObject.SetActive(false);
            Destroy(worldItem.gameObject);
            Debug.LogWarning("[K_ContextMenu] HandleDrop (applied): source item unavailable; drop cancelled.");
            return;
        }

        if (!manager.TryRemoveForWorldDrop(record, out string reason))
        {
            if (rollback != null && !rollback())
                Debug.LogError("[K_ContextMenu] HandleDrop (applied): failed to restore source item.");
            worldItem.gameObject.SetActive(false);
            Destroy(worldItem.gameObject);
            Debug.LogWarning($"[K_ContextMenu] HandleDrop (applied): {reason}");
            _currentInventoryUI.ForceRefresh();
            return;
        }

        NotifyPickupDropped();
        _currentInventoryUI.ForceRefresh();
    }

    /// <summary>
    /// Stage 4.5.1b: сообщает pickup-системе о дропе для включения cooldown.
    /// Stage 4.5.1c: без lazy-Find — если система не закэширована в Start, cooldown
    /// просто не сработает (не ошибка).
    /// </summary>
    private void NotifyPickupDropped()
    {
        _cachedPickup?.NotifyItemDropped();
    }

    private void HandleSplit()
    {
        var item = _currentItem;
        var inventoryUI = _currentInventoryUI;
        if (!K_SplitStackDialog.CanSplitItem(item, inventoryUI) ||
            _currentAppliedRecord != null ||
            (_currentEquipmentSlot != null && ReferenceEquals(_currentEquipmentSlot.EquippedItem, item)))
            return;

        var position = _lastScreenPosition;
        bool fromGround = inventoryUI.IsGroundLootItem(item);
        // Hide immediately: the menu must not retain raycasts or a fade coroutine behind the modal.
        Hide();
        StopAllCoroutines();
        _hideCoroutine = null;
        _rebuildCoroutine = null;
        gameObject.SetActive(false);
        ClearMenuItems();

        K_SplitStackDialog.Show(item, inventoryUI, position, quantity =>
        {
            var controller = inventoryUI != null ? inventoryUI.FindControllerForItem(item) : null;
            if (controller == null || controller.IsDisposed ||
                !ReferenceEquals(controller.GetItemByInstanceID(item.InstanceID), item) ||
                fromGround != inventoryUI.IsGroundLootItem(item) ||
                InventoryTransactionService.Instance == null)
            {
                Debug.LogWarning("[SplitStack] Исходная стопка больше недоступна.");
                return;
            }
            string error;
            bool success = fromGround
                ? InventoryTransactionService.Instance.TrySplitFromGroundAtomic(
                    inventoryUI.FindUIItemForItem(item), quantity, out error)
                : InventoryTransactionService.Instance.TrySplitStackAtomic(item, controller, quantity, out error);
            if (success)
            {
#if UNITY_EDITOR
                Debug.Log($"[SplitStack] Разделено '{item.Data.DisplayName}': отделено {quantity}, осталось {item.Quantity}.");
#endif
            }
            else
                Debug.LogWarning($"[SplitStack] {error}");
            inventoryUI.ForceRefresh();
        });
    }

    private void HandleRepair()
    {
        if (_currentInventoryUI == null || !_currentInventoryUI.HasRepairKit())
        {
            Debug.LogWarning("[ContextMenu] Требуется ремонтный комплект");
            return;
        }
        // TODO: repair amount, duration and kit consumption belong to the repair-system iteration.
        Debug.Log("[ContextMenu] Ремонтный комплект найден. Ремонт пока не реализован; предметы не изменены.");
    }

    #endregion

    #region Initialization

    public void Initialize(Transform rootCanvasTransform)
    {
        _canvas = rootCanvasTransform != null ? rootCanvasTransform.GetComponent<Canvas>() : null;
        SetupInternals();
    }

    private void SetupInternals()
    {
        if (_isInitialized) return;
        _rectTransform = GetComponent<RectTransform>();
        if (_rectTransform == null)
        {
            Debug.LogError("[K_ContextMenu] RectTransform is required. Add the menu to a UI object.");
            enabled = false;
            return;
        }
        _isInitialized = true;
        _canvasGroup = GetComponent<CanvasGroup>();
        if (_canvasGroup == null) _canvasGroup = gameObject.AddComponent<CanvasGroup>();
        if (_canvas == null) _canvas = GetComponentInParent<Canvas>();

        _rectTransform.anchorMin = new Vector2(0, 1);
        _rectTransform.anchorMax = new Vector2(0, 1);
        _rectTransform.pivot = new Vector2(0, 1);
        _rectTransform.sizeDelta = new Vector2(S.MinWidth, 0f);

        var bg = GetComponent<Image>();
        if (bg == null) bg = gameObject.AddComponent<Image>();
        bg.color = S.BackgroundColor;
        bg.raycastTarget = true;

        _canvasGroup.blocksRaycasts = true;
        _canvasGroup.interactable = true;

        var menuCsf = GetComponent<ContentSizeFitter>();
        if (menuCsf == null) menuCsf = gameObject.AddComponent<ContentSizeFitter>();
        menuCsf.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        CreateMenuBorder();

        if (_contentRect == null)
        {
            var contentObj = new GameObject("Content", typeof(RectTransform), typeof(VerticalLayoutGroup));
            contentObj.transform.SetParent(_rectTransform, false);
            _contentRect = contentObj.GetComponent<RectTransform>();
            _contentRect.anchorMin = Vector2.zero;
            _contentRect.anchorMax = Vector2.one;
            _contentRect.offsetMin = new Vector2(S.Padding, S.Padding);
            _contentRect.offsetMax = new Vector2(-S.Padding, -S.Padding);

            var vlg = contentObj.GetComponent<VerticalLayoutGroup>();
            vlg.childAlignment = TextAnchor.UpperLeft;
            vlg.childControlWidth = true;
            vlg.childControlHeight = false;
            vlg.childForceExpandWidth = true;
            vlg.childForceExpandHeight = false;
            vlg.spacing = 0f;

            var csf = contentObj.AddComponent<ContentSizeFitter>();
            csf.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
        }
    }

    private void CreateMenuBorder()
    {
        float t = S.BorderThickness;
        if (t <= 0f || S.BorderColor.a <= 0f) return;

        CreateBorderSide("BorderLeft",
            anchorMin: new Vector2(0, 0), anchorMax: new Vector2(0, 1),
            pivot: new Vector2(0, 0.5f),
            offsetMin: Vector2.zero, offsetMax: new Vector2(t, 0));

        CreateBorderSide("BorderRight",
            anchorMin: new Vector2(1, 0), anchorMax: new Vector2(1, 1),
            pivot: new Vector2(1, 0.5f),
            offsetMin: new Vector2(-t, 0), offsetMax: Vector2.zero);

        CreateBorderSide("BorderTop",
            anchorMin: new Vector2(0, 1), anchorMax: new Vector2(1, 1),
            pivot: new Vector2(0.5f, 1),
            offsetMin: new Vector2(0, -t), offsetMax: Vector2.zero);

        CreateBorderSide("BorderBottom",
            anchorMin: new Vector2(0, 0), anchorMax: new Vector2(1, 0),
            pivot: new Vector2(0.5f, 0),
            offsetMin: Vector2.zero, offsetMax: new Vector2(0, t));
    }

    private void CreateBorderSide(string name, Vector2 anchorMin, Vector2 anchorMax,
        Vector2 pivot, Vector2 offsetMin, Vector2 offsetMax)
    {
        var side = new GameObject(name, typeof(RectTransform), typeof(Image));
        side.transform.SetParent(_rectTransform, false);

        var img = side.GetComponent<Image>();
        img.color = S.BorderColor;
        img.raycastTarget = false;

        var rt = side.GetComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.pivot = pivot;
        rt.offsetMin = offsetMin;
        rt.offsetMax = offsetMax;
    }

    #endregion

    #region Unity Lifecycle

    private void Start()
    {
        if (!enabled) return;
        SetupInternals();
        if (!_isInitialized) return;
        EnsureCaches();
    }

    /// <summary>
    /// Stage 4.5.1c: единственная точка резолва сцен-зависимостей.
    /// Вызывается ТОЛЬКО из Start. Инвариант 6 соблюдён строго.
    /// Player transform — обязателен (error при отсутствии).
    /// Pickup-система — опциональна (тишина при отсутствии: cooldown не сработает).
    /// </summary>
    private void EnsureCaches()
    {
        if (_cachedPlayerTransform == null)
        {
            var motor = FindFirstObjectByType<K_PlayerMotor>();
            if (motor != null)
            {
                _cachedPlayerTransform = motor.transform;
            }
            else
            {
                var health = FindFirstObjectByType<K_HealthSystem>();
                if (health != null)
                {
                    _cachedPlayerTransform = health.transform;
                }
                else
                {
                    Debug.LogError(
                        "[K_ContextMenu] EnsureCaches: neither K_PlayerMotor nor K_HealthSystem found. " +
                        "World drop will fail.");
                }
            }
        }

        if (_cachedPickup == null)
        {
            _cachedPickup = FindFirstObjectByType<K_WorldItemPickupSystem>();
            // Не ошибка, если системы нет: drop работает, только без cooldown.
        }
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            // ФИКС БАГ #16: Проверяем, был ли клик по самому меню или его дочерним элементам
            bool clickedInside = false;
            if (EventSystem.current != null)
            {
                var eventData = new PointerEventData(EventSystem.current);
                eventData.position = Input.mousePosition;
                var results = new System.Collections.Generic.List<RaycastResult>();
                EventSystem.current.RaycastAll(eventData, results);

                foreach (var result in results)
                {
                    // Если клик попал в меню или в любой объект, являющийся ребенком меню
                    if (result.gameObject.transform.IsChildOf(transform))
                    {
                        clickedInside = true;
                        break;
                    }
                }
            }

            if (!clickedInside)
            {
                Hide();
            }
        }
    }

    #endregion
}
