using System;
using System.Collections.Generic;
using System.Globalization;
using K_Incident.Core.Inventory;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>Shared split/eat/drink/transfusion window; inventory input remains available.</summary>
public sealed class K_SplitStackDialog : MonoBehaviour
{
    private static readonly Dictionary<K_QuantityDialogMode, K_SplitStackDialog> Active =
        new Dictionary<K_QuantityDialogMode, K_SplitStackDialog>();
    private static readonly List<K_SplitStackDialog> OpenOrder = new List<K_SplitStackDialog>();
    private static readonly Dictionary<K_InventoryUI, Dictionary<K_QuantityDialogMode, Vector2>> RememberedPositions =
        new Dictionary<K_InventoryUI, Dictionary<K_QuantityDialogMode, Vector2>>();
    private static int _escapeConsumedFrame = -1;

    private K_InventoryUI _owner;
    private InventoryItem _item;
    private K_QuantityDialogOptions _options;
    private Slider _slider;
    private TMP_InputField _input;
    private TextMeshProUGUI _warning;
    private TextMeshProUGUI _preview;
    private GameObject _previousSelection;
    private Canvas _rootCanvas;
    private RectTransform _panel;
    private Material _textMaterial;
    private bool _hidden;
    private bool _draggingHeader;
    private Vector2 _dragStartPointer;
    private Vector2 _dragStartPosition;
    private bool _closed;
    private bool _refreshingRange;

    public static bool IsOpen => Active.Count > 0;
    public static bool IsOpenFor(K_InventoryUI inventoryUI)
    {
        foreach (var dialog in OpenOrder)
            if (!dialog._closed && dialog._owner == inventoryUI) return true;
        return false;
    }

    public static bool IsItemLocked(InventoryItem item)
    {
        if (item == null) return false;
        foreach (var dialog in OpenOrder)
            if (!dialog._closed && dialog._item != null && dialog._item.InstanceID == item.InstanceID) return true;
        return false;
    }

    public static void CancelForInventory(K_InventoryUI inventoryUI)
    {
        foreach (var dialog in OpenOrder.ToArray())
            if (dialog._owner == inventoryUI) dialog.Close();
    }

    public static void CancelAll()
    {
        foreach (var dialog in OpenOrder.ToArray()) dialog.Close();
    }

    /// <summary>One Escape press retires only the top visible quantity window, in either Update order.</summary>
    public static bool ConsumeEscapeForInventory(K_InventoryUI inventoryUI)
    {
        if (!Input.GetKeyDown(KeyCode.Escape)) return false;
        if (_escapeConsumedFrame == Time.frameCount) return true;
        for (int index = OpenOrder.Count - 1; index >= 0; index--)
        {
            var dialog = OpenOrder[index];
            if (dialog._closed || dialog._owner == null || !dialog._owner.IsOpen ||
                !dialog._owner.gameObject.activeInHierarchy) continue;
            _escapeConsumedFrame = Time.frameCount;
            dialog.Close();
            return true;
        }
        return false;
    }

    /// <summary>Remove all callbacks and per-mode positions when their owner is destroyed.</summary>
    public static void ForgetOwner(K_InventoryUI inventoryUI)
    {
        if (ReferenceEquals(inventoryUI, null)) return;
        CancelForInventory(inventoryUI);
        RememberedPositions.Remove(inventoryUI);
    }

    internal static bool CanSplitItem(InventoryItem item, K_InventoryUI inventoryUI)
    {
        if (!IsAvailableItem(item, inventoryUI) || !InventoryTransactionService.CanSplitStackItem(item)) return false;
        // Ground roots keep their partial-pickup callback, and cannot be rebound by identity alone.
        var root = inventoryUI.RootCanvasTransform;
        if (root != null)
            foreach (var slot in root.GetComponentsInChildren<K_EquipmentSlotUI>(true))
                if (ReferenceEquals(slot.EquippedItem, item)) return false;
        return true;
    }

    private static bool IsAvailableItem(InventoryItem item, K_InventoryUI inventoryUI, K_QuantityDialogOptions options = null)
    {
        if (inventoryUI == null || !inventoryUI.IsOpen || item == null || item.Data == null) return false;
        if (inventoryUI.AppliedHealth?.AppliedMedical?.GetRecordForInstance(item.InstanceID) != null) return false;
        if (options?.SourceAvailable != null) return options.SourceAvailable();
        var controller = inventoryUI.FindControllerForItem(item);
        return controller != null && !controller.IsDisposed &&
            ReferenceEquals(controller.GetItemByInstanceID(item.InstanceID), item);
    }

    public static K_SplitStackDialog Show(InventoryItem item, K_InventoryUI inventoryUI,
        Vector2 screenPosition, Action<int> onConfirm)
    {
        if (!CanSplitItem(item, inventoryUI) || onConfirm == null) return null;
        return ShowQuantity(item, inventoryUI, screenPosition, new K_QuantityDialogOptions
        {
            Mode = K_QuantityDialogMode.Split,
            Title = $"Разделить: {item.Data.DisplayName}",
            QuantityLabel = "Количество",
            ConfirmLabel = "Разделить",
            Minimum = 1f,
            InitialValue = Mathf.RoundToInt(item.Quantity / 2f),
            Maximum = () => item.Quantity - 1,
            CanApply = () => CanSplitItem(item, inventoryUI),
            OnConfirm = value => onConfirm(Mathf.RoundToInt(value)),
            WholeNumbers = true,
            ClampInputToRange = false
        });
    }

    public static K_SplitStackDialog ShowQuantity(InventoryItem item, K_InventoryUI inventoryUI,
        Vector2 screenPosition, K_QuantityDialogOptions options)
    {
        if (!IsAvailableItem(item, inventoryUI, options) || inventoryUI.IsDragging || options == null ||
            options.OnConfirm == null || options.Maximum == null || options.CanApply == null ||
            !inventoryUI.gameObject.activeInHierarchy || !inventoryUI.enabled ||
            !Enum.IsDefined(typeof(K_QuantityDialogMode), options.Mode) || Active.ContainsKey(options.Mode) ||
            IsItemLocked(item) || !options.CanApply()) return null;
        float maximum = options.Maximum();
        if (!IsFinite(options.Minimum) || options.Minimum <= 0f || !IsFinite(maximum) || maximum <= 0f) return null;
        var canvas = inventoryUI.RootCanvasTransform != null
            ? inventoryUI.RootCanvasTransform.GetComponent<Canvas>() : null;
        if (canvas == null) return null;
        canvas = canvas.rootCanvas;

        var root = new GameObject(options.Mode + "QuantityWindow", typeof(RectTransform), typeof(Canvas),
            typeof(GraphicRaycaster), typeof(CanvasGroup), typeof(Image), typeof(K_SplitStackDialog));
        root.transform.SetParent(canvas.transform, false);
        var rootRect = root.GetComponent<RectTransform>();
        rootRect.anchorMin = Vector2.zero;
        rootRect.anchorMax = Vector2.one;
        rootRect.offsetMin = rootRect.offsetMax = Vector2.zero;
        rootRect.localScale = Vector3.one;
        var windowCanvas = root.GetComponent<Canvas>();
        windowCanvas.overrideSorting = true;
        var group = root.GetComponent<CanvasGroup>();
        group.ignoreParentGroups = true;
        group.blocksRaycasts = true;
        group.interactable = true;
        // Only the actual panel receives clicks; the rest of the inventory remains usable.
        var outside = root.GetComponent<Image>();
        outside.color = Color.clear;
        outside.raycastTarget = false;

        var dialog = root.GetComponent<K_SplitStackDialog>();
        dialog._owner = inventoryUI;
        dialog._item = item;
        // The window owns its callback configuration, so callers cannot retarget a live session.
        dialog._options = options.Copy();
        dialog._previousSelection = EventSystem.current != null ? EventSystem.current.currentSelectedGameObject : null;
        Active.Add(options.Mode, dialog);
        OpenOrder.Add(dialog);
        try
        {
            dialog.Build(canvas, screenPosition);
            dialog.BringToFront();
        }
        catch
        {
            dialog.Close();
            throw;
        }
        return dialog;
    }

    private void Build(Canvas rootCanvas, Vector2 screenPosition)
    {
        _rootCanvas = rootCanvas;
        var style = K_ContextMenu.Instance != null ? K_ContextMenu.Instance.GetSplitStyle() : null;
        if (style == null) style = K_SplitStackDialogStyle.Default();
        float width = Mathf.Max(220f, style.WindowSize.x);
        float height = Mathf.Max(160f, style.WindowSize.y);
        float padding = Mathf.Max(0f, style.Padding);
        float spacing = Mathf.Max(0f, style.Spacing);
        float headerHeight = Mathf.Max(1f, style.HeaderHeight);
        float controlHeight = Mathf.Max(1f, style.ControlHeight);
        float closeWidth = Mathf.Max(1f, style.CloseButtonSize.x);
        float closeHeight = Mathf.Max(1f, style.CloseButtonSize.y);
        float inputWidth = Mathf.Max(1f, style.InputWidth);
        var panel = _panel = CreateRect("SplitStackPanel", transform, 0f, 0f, width, height);
        panel.gameObject.AddComponent<Image>().color = style.BackgroundColor;
        AddEvent(panel.gameObject, EventTriggerType.PointerDown, _ => BringToFront());
        var header = CreateRect("Header", panel, 0f, 0f, width, headerHeight + padding);
        header.gameObject.AddComponent<Image>().color = style.HeaderColor;
        AddEvent(header.gameObject, EventTriggerType.PointerDown, _ => BringToFront());
        AddEvent(header.gameObject, EventTriggerType.BeginDrag, data => BeginHeaderDrag((PointerEventData)data));
        AddEvent(header.gameObject, EventTriggerType.Drag, data => DragHeader((PointerEventData)data));
        AddEvent(header.gameObject, EventTriggerType.EndDrag, _ => _draggingHeader = false);
        var divider = CreateRect("HeaderDivider", panel, 0f, -(headerHeight + padding),
            width, Mathf.Max(0f, style.HeaderDividerThickness));
        var dividerImage = divider.gameObject.AddComponent<Image>();
        dividerImage.color = style.HeaderDividerColor;
        dividerImage.raycastTarget = false;
        var title = CreateText("Title", header, style, padding, -padding * 0.5f,
            width - padding * 3f - closeWidth, headerHeight, _options.Title ?? string.Empty);
        title.fontStyle = FontStyles.Bold;
        title.fontSize = style.TitleFontSize;
        title.color = style.TitleColor;
        title.overflowMode = TextOverflowModes.Ellipsis;
        var close = CreateButton(panel, style, "Close", "×",
            width - padding - closeWidth + style.CloseButtonOffset.x,
            -padding * 0.5f + style.CloseButtonOffset.y, closeWidth, closeHeight,
            style.CloseFontSize, style.CloseTextColor,
            style.CloseNormalColor, style.CloseHoverColor, style.ClosePressedColor, Close);
        AddBorders((RectTransform)close.transform, "Close", style.CloseBorderThickness, style.CloseBorderColor);

        float labelY = -(headerHeight + padding + spacing);
        var label = CreateText("SliderLabel", panel, style, padding, labelY,
            width - padding * 2f, style.LabelHeight, _options.QuantityLabel ?? "Количество");
        label.color = style.SliderLabelColor;
        float controlsY = labelY - style.LabelHeight - spacing * 0.5f;
        _slider = CreateSlider(panel, style, padding, controlsY,
            width - padding * 2f - inputWidth - spacing, controlHeight);
        _slider.minValue = Mathf.Min(_options.Minimum, _options.Maximum());
        _slider.maxValue = _options.Maximum();
        // The handle stays continuous even for split, whose displayed and applied value is integral.
        _slider.wholeNumbers = false;
        float initial = IsFinite(_options.InitialValue) ? _options.InitialValue : _options.Minimum;
        _slider.SetValueWithoutNotify(Normalize(Mathf.Clamp(initial, _slider.minValue, _slider.maxValue)));
        _input = CreateInput(panel, style, width - padding - inputWidth, controlsY, inputWidth, controlHeight);
        _input.characterLimit = _options.WholeNumbers
            ? Mathf.Max(_item.Quantity, Mathf.RoundToInt(_slider.maxValue)).ToString(CultureInfo.InvariantCulture).Length : 12;
        _input.SetTextWithoutNotify(Format(_slider.value));
        float messageY = controlsY - controlHeight - spacing;
        float messageHeight = Mathf.Max(style.WarningHeight, _options.Preview != null ? style.WarningFontSize * 2.5f : style.WarningHeight);
        _preview = CreateText("Preview", panel, style, padding, messageY,
            width - padding * 2f, messageHeight, string.Empty);
        _preview.fontSize = style.WarningFontSize;
        _warning = CreateText("Warning", panel, style, padding, messageY,
            width - padding * 2f, messageHeight, string.Empty);
        _warning.fontSize = style.WarningFontSize;
        _warning.color = style.WarningColor;
        float buttonWidth = Mathf.Max(1f, style.ButtonSize.x);
        float buttonHeight = Mathf.Max(1f, style.ButtonSize.y);
        CreateButton(panel, style, _options.ConfirmLabel ?? "Подтвердить", _options.ConfirmLabel ?? "Подтвердить",
            width - padding - buttonWidth, -height + padding + buttonHeight,
            buttonWidth, buttonHeight, style.ButtonFontSize, style.ButtonTextColor,
            style.ButtonNormalColor, style.ButtonHoverColor, style.ButtonPressedColor, Confirm);
        _slider.onValueChanged.AddListener(value =>
        {
            if (_refreshingRange) return;
            _input.SetTextWithoutNotify(Format(value));
            _warning.text = string.Empty;
            UpdatePreview();
        });
        _input.onValueChanged.AddListener(_ =>
        {
            if (TryReadQuantity(out float value))
            {
                value = Mathf.Clamp(value, _slider.minValue, _slider.maxValue);
                _slider.SetValueWithoutNotify(value);
                if (_options.ClampInputToRange) _input.SetTextWithoutNotify(Format(value));
            }
            // Split keeps invalid typed input visible and rejects it at confirmation.
            _warning.text = string.Empty;
            UpdatePreview();
        });
        _input.onSubmit.AddListener(_ => Confirm());
        AddBorders(panel, string.Empty, style.BorderThickness, style.BorderColor);
        if (RememberedPositions.TryGetValue(_owner, out var modes) && modes.TryGetValue(_options.Mode, out var remembered))
            panel.anchoredPosition = ClampPosition(remembered);
        else PositionPanel(panel, rootCanvas, screenPosition, style.OffsetFromCursor);
        UpdatePreview();
        _input.Select();
        _input.ActivateInputField();
    }

    private static bool IsFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    private float Normalize(float value) => _options.WholeNumbers ? Mathf.RoundToInt(value) : value;
    private string Format(float value)
    {
        value = Normalize(value);
        // Round-trip text must not turn 99.9996 into an invalid 100, or a tiny
        // positive remainder into zero when the current maximum is fractional.
        return value.ToString(_options.WholeNumbers ? "0" : "R", CultureInfo.InvariantCulture);
    }

    private bool TryReadQuantity(out float quantity)
    {
        if (_options.WholeNumbers)
        {
            bool valid = int.TryParse(_input.text, NumberStyles.Integer, CultureInfo.InvariantCulture, out int integer);
            quantity = integer;
            return valid;
        }
        return float.TryParse(_input.text, NumberStyles.Float, CultureInfo.InvariantCulture, out quantity) && IsFinite(quantity);
    }

    private void UpdatePreview()
    {
        if (_preview == null || _options == null) return;
        _preview.text = string.IsNullOrEmpty(_warning.text) && TryReadQuantity(out float value)
            ? _options.Preview?.Invoke(Mathf.Clamp(value, _slider.minValue, _slider.maxValue)) ?? string.Empty : string.Empty;
    }

    private bool RefreshRange()
    {
        float maximum = _options.Maximum();
        if (!IsFinite(maximum) || maximum <= 0f) return false;
        // Slider range setters can publish onValueChanged in Unity. Keep a strict
        // split input unchanged so a stale amount fails rather than silently shrinking.
        _refreshingRange = true;
        try
        {
            _slider.minValue = Mathf.Min(_options.Minimum, maximum);
            _slider.maxValue = maximum;
        }
        finally { _refreshingRange = false; }
        if (_options.ClampInputToRange && TryReadQuantity(out float quantity))
        {
            quantity = Normalize(Mathf.Clamp(quantity, _slider.minValue, maximum));
            _input.SetTextWithoutNotify(Format(quantity));
            _slider.SetValueWithoutNotify(quantity);
        }
        UpdatePreview();
        return true;
    }

    private void Confirm()
    {
        if (_closed || _hidden || _owner == null || !_owner.IsOpen) return;
        if (!IsAvailableItem(_item, _owner, _options) || !_options.CanApply() || !RefreshRange())
        {
            Debug.LogWarning("[QuantityDialog] Исходный предмет больше недоступен.");
            Close();
            return;
        }
        if (!TryReadQuantity(out float quantity) || quantity < _slider.minValue || quantity > _slider.maxValue)
        {
            _warning.text = $"От {Format(_slider.minValue)} до {Format(_slider.maxValue)}";
            UpdatePreview();
            _input.Select();
            _input.ActivateInputField();
            return;
        }
        var callback = _options.OnConfirm;
        // Release item/window ownership before arbitrary inventory refresh; duplicate submits become inert.
        Close();
        callback?.Invoke(Normalize(quantity));
    }

    private void Update()
    {
        if (_closed) return;
        if (Input.GetKeyDown(KeyCode.F5) || Input.GetKeyDown(KeyCode.F9))
        {
            CancelAll();
            return;
        }
        if (_owner == null || !_owner.gameObject.activeInHierarchy)
        {
            Close();
            return;
        }
        SyncVisibility();
        if (_closed || _hidden) return;
        if (ConsumeEscapeForInventory(_owner)) return;
        if (!IsAvailableItem(_item, _owner, _options) || !_options.CanApply() || !RefreshRange())
        {
            Close();
            return;
        }
        if (_input != null && _input.isFocused &&
            (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter))) Confirm();
    }

    private void LateUpdate()
    {
        // Owner handles Tab once. Synchronize after either possible Update order, before rendering.
        if (!_closed && _owner != null) SyncVisibility();
    }

    private void SyncVisibility()
    {
        bool hidden = !_owner.IsOpen;
        if (_hidden == hidden) return;
        _hidden = hidden;
        _draggingHeader = false;
        if (hidden)
        {
            RememberPosition();
            ClearDialogSelection();
        }
        else
        {
            if (!IsAvailableItem(_item, _owner, _options) || !_options.CanApply() || !RefreshRange())
            {
                Close();
                return;
            }
            _panel.anchoredPosition = ClampPosition(_panel.anchoredPosition);
        }
        var group = GetComponent<CanvasGroup>();
        group.alpha = hidden ? 0f : 1f;
        group.blocksRaycasts = !hidden;
        group.interactable = !hidden;
    }

    private void BringToFront()
    {
        if (_closed || _rootCanvas == null) return;
        OpenOrder.Remove(this);
        OpenOrder.Add(this);
        transform.SetAsLastSibling();
        int highestOrder = _rootCanvas.sortingOrder;
        var ownCanvas = GetComponent<Canvas>();
        foreach (var childCanvas in _rootCanvas.GetComponentsInChildren<Canvas>(true))
            if (childCanvas != ownCanvas) highestOrder = Mathf.Max(highestOrder, childCanvas.sortingOrder);
        // Renumber quantity windows at the Canvas limit instead of overflowing short sortingOrder.
        if (highestOrder >= short.MaxValue)
        {
            int order = short.MaxValue - OpenOrder.Count;
            foreach (var dialog in OpenOrder) dialog.GetComponent<Canvas>().sortingOrder = ++order;
        }
        else ownCanvas.sortingOrder = highestOrder + 1;
    }

    private void ClearDialogSelection()
    {
        if (EventSystem.current == null) return;
        var selected = EventSystem.current.currentSelectedGameObject;
        if (selected != null && selected.transform.IsChildOf(transform)) EventSystem.current.SetSelectedGameObject(null);
    }

    private void RememberPosition()
    {
        if (_owner == null || _panel == null) return;
        if (!RememberedPositions.TryGetValue(_owner, out var modes))
        {
            modes = new Dictionary<K_QuantityDialogMode, Vector2>();
            RememberedPositions.Add(_owner, modes);
        }
        modes[_options.Mode] = _panel.anchoredPosition;
    }

    private void Close()
    {
        if (_closed) return;
        _closed = true;
        RememberPosition();
        if (_options != null)
        {
            Active.Remove(_options.Mode);
            _options.OnConfirm = null;
        }
        OpenOrder.Remove(this);
        ClearDialogSelection();
        var group = GetComponent<CanvasGroup>();
        if (group != null) group.blocksRaycasts = false;
        gameObject.SetActive(false);
        Destroy(gameObject);
    }

    private void OnDisable()
    {
        if (!_closed) Close();
    }

    private void OnDestroy()
    {
        if (!_closed)
        {
            _closed = true;
            if (_options != null) Active.Remove(_options.Mode);
            OpenOrder.Remove(this);
        }
        if (_options != null)
        {
            _options.OnConfirm = null;
            _options.CanApply = null;
            _options.SourceAvailable = null;
            _options.Maximum = null;
            _options.Preview = null;
        }
        if (_textMaterial != null)
        {
            Destroy(_textMaterial);
            _textMaterial = null;
        }
        if (EventSystem.current != null && EventSystem.current.currentSelectedGameObject == null &&
            _previousSelection != null && _previousSelection.activeInHierarchy)
            EventSystem.current.SetSelectedGameObject(_previousSelection);
    }
    private static RectTransform CreateRect(string name, Transform parent, float x, float y, float width, float height)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        var rect = go.GetComponent<RectTransform>();
        rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0, 1);
        rect.anchoredPosition = new Vector2(x, y);
        rect.sizeDelta = new Vector2(width, height);
        rect.localScale = Vector3.one;
        return rect;
    }

    private TextMeshProUGUI CreateText(string name, Transform parent, K_SplitStackDialogStyle style,
        float x, float y, float width, float height, string value)
    {
        var rect = CreateRect(name, parent, x, y, width, height);
        var text = rect.gameObject.AddComponent<TextMeshProUGUI>();
        if (style.Font != null) text.font = style.Font;
        ApplyTextMaterial(text);
        text.fontSize = style.LabelFontSize;
        text.color = style.SliderLabelColor;
        text.text = value;
        text.alignment = TextAlignmentOptions.MidlineLeft;
        text.raycastTarget = false;
        return text;
    }

    private void ApplyTextMaterial(TextMeshProUGUI text)
    {
        if (_textMaterial == null && text.fontSharedMaterial != null)
        {
            // The project's default font has a grey face, FaceDilate=-1 and a
            // soft, wide outline. Use a clean local copy so style colors reach
            // the glyphs without altering any shared font or other inventory UI.
            _textMaterial = new Material(text.fontSharedMaterial)
            {
                name = "Split Stack Text",
                hideFlags = HideFlags.HideAndDontSave
            };
            if (_textMaterial.HasProperty("_FaceColor"))
                _textMaterial.SetColor("_FaceColor", Color.white);
            foreach (var property in new[] { "_FaceDilate", "_OutlineWidth", "_OutlineSoftness" })
                if (_textMaterial.HasProperty(property)) _textMaterial.SetFloat(property, 0f);
            foreach (var keyword in new[] { "UNDERLAY_ON", "UNDERLAY_INNER", "GLOW_ON", "OUTLINE_ON" })
                _textMaterial.DisableKeyword(keyword);
        }
        if (_textMaterial != null) text.fontSharedMaterial = _textMaterial;
    }

    private static void AddBorders(RectTransform panel, string prefix, float thickness, Color color)
    {
        thickness = Mathf.Max(0f, thickness);
        AddBorder(panel, prefix + "Top", new Vector2(0, 1), Vector2.one,
            new Vector2(0, -thickness), Vector2.zero, color);
        AddBorder(panel, prefix + "Bottom", Vector2.zero, new Vector2(1, 0),
            Vector2.zero, new Vector2(0, thickness), color);
        AddBorder(panel, prefix + "Left", Vector2.zero, new Vector2(0, 1),
            Vector2.zero, new Vector2(thickness, 0), color);
        AddBorder(panel, prefix + "Right", new Vector2(1, 0), Vector2.one,
            new Vector2(-thickness, 0), Vector2.zero, color);
    }

    private static void AddBorder(RectTransform panel, string name, Vector2 min, Vector2 max,
        Vector2 offsetMin, Vector2 offsetMax, Color color)
    {
        var border = CreateRect(name, panel, 0, 0, 0, 0);
        border.anchorMin = min;
        border.anchorMax = max;
        border.offsetMin = offsetMin;
        border.offsetMax = offsetMax;
        var image = border.gameObject.AddComponent<Image>();
        image.color = color;
        image.raycastTarget = false;
    }

    private Button CreateButton(Transform panel, K_SplitStackDialogStyle style, string name, string label,
        float x, float y, float width, float height, float fontSize, Color textColor,
        Color normal, Color hover, Color pressed, UnityEngine.Events.UnityAction action)
    {
        var rect = CreateRect(name, panel, x, y, width, height);
        var image = rect.gameObject.AddComponent<Image>();
        image.color = Color.white;
        var button = rect.gameObject.AddComponent<Button>();
        button.targetGraphic = image;
        ApplyColors(button, normal, hover, hover, pressed);
        var text = CreateText(name + "Label", rect, style, 0f, 0f, width, height, label);
        text.alignment = TextAlignmentOptions.Center;
        text.fontSize = fontSize;
        text.color = textColor;
        button.onClick.AddListener(action);
        return button;
    }

    private static Slider CreateSlider(Transform parent, K_SplitStackDialogStyle style,
        float x, float y, float width, float height)
    {
        var rect = CreateRect("QuantitySlider", parent, x, y, width, height);
        var slider = rect.gameObject.AddComponent<Slider>();
        float thickness = Mathf.Max(0f, style.TrackThickness);
        float handleWidth = Mathf.Max(1f, style.HandleSize.x);
        float handleHeight = Mathf.Max(1f, style.HandleSize.y);
        float trackY = -(height - thickness) * 0.5f;
        var track = CreateRect("Track", rect, 0f, trackY, width, thickness);
        track.gameObject.AddComponent<Image>().color = style.TrackColor;
        var fillArea = CreateRect("FillArea", rect, handleWidth * 0.5f, trackY,
            width - handleWidth, thickness);
        var fill = CreateRect("Fill", fillArea, 0, 0, width - handleWidth, thickness);
        fill.anchorMin = Vector2.zero;
        fill.anchorMax = Vector2.one;
        fill.offsetMin = fill.offsetMax = Vector2.zero;
        fill.gameObject.AddComponent<Image>().color = style.FillColor;
        var handleArea = CreateRect("HandleArea", rect, handleWidth * 0.5f, 0, width - handleWidth, height);
        var handle = CreateRect("Handle", handleArea, 0, 0, handleWidth, handleHeight);
        handle.anchorMin = Vector2.zero;
        handle.anchorMax = new Vector2(0, 1);
        handle.pivot = new Vector2(0.5f, 0.5f);
        handle.sizeDelta = new Vector2(handleWidth, handleHeight - height);
        handle.anchoredPosition = Vector2.zero;
        handle.gameObject.AddComponent<Image>().color = Color.white;
        slider.fillRect = fill;
        slider.handleRect = handle;
        slider.targetGraphic = handle.GetComponent<Image>();
        slider.direction = Slider.Direction.LeftToRight;
        ApplyColors(slider, style.HandleColor, style.HandleHoverColor, style.HandleColor, style.HandlePressedColor);
        return slider;
    }

    private TMP_InputField CreateInput(Transform parent, K_SplitStackDialogStyle style,
        float x, float y, float width, float height)
    {
        var rect = CreateRect("QuantityInput", parent, x, y, width, height);
        var image = rect.gameObject.AddComponent<Image>();
        image.color = Color.white;
        var viewport = CreateRect("TextArea", rect, style.InputTextPadding.x, -style.InputTextPadding.y,
            width - style.InputTextPadding.x * 2f, height - style.InputTextPadding.y * 2f);
        viewport.gameObject.AddComponent<RectMask2D>();
        var text = CreateText("Text", viewport, style, 0, 0, viewport.sizeDelta.x, viewport.sizeDelta.y, string.Empty);
        text.fontSize = style.InputFontSize;
        text.color = style.InputTextColor;
        // Native TMP creates its caret renderer in OnEnable only when the text
        // is already assigned. Initialize the text first, then enable the fully
        // configured input once instead of leaving an enabled input without a caret.
        rect.gameObject.SetActive(false);
        var input = rect.gameObject.AddComponent<K_SplitStackInputField>();
        input.targetGraphic = image;
        input.textViewport = viewport;
        input.textComponent = text;
        input.contentType = _options.WholeNumbers
            ? TMP_InputField.ContentType.IntegerNumber : TMP_InputField.ContentType.DecimalNumber;
        input.lineType = TMP_InputField.LineType.SingleLine;
        input.customCaretColor = true;
        input.caretColor = style.InputCaretColor;
        input.caretBlinkRate = Mathf.Max(0.1f, style.InputCaretBlinkRate);
        input.caretWidth = Mathf.Clamp(style.InputCaretWidth, 1, 5);
        input.CaretHeight = Mathf.Max(0f, style.InputCaretHeight);
        input.onFocusSelectAll = false;
        input.selectionColor = style.InputSelectionColor;
        input.onSelect.AddListener(_ => text.color = style.InputFocusedTextColor);
        input.onDeselect.AddListener(_ => text.color = style.InputTextColor);
        AddEvent(rect.gameObject, EventTriggerType.PointerClick, data =>
        {
            if (((PointerEventData)data).button != PointerEventData.InputButton.Left) return;
            input.Select();
            input.ActivateInputField();
        });
        ApplyColors(input, style.InputNormalColor, style.InputHoverColor, style.InputFocusedColor, style.InputPressedColor);
        rect.gameObject.SetActive(true);
        return input;
    }

    private static void ApplyColors(Selectable selectable, Color normal, Color hover, Color selected, Color pressed)
    {
        var navigation = selectable.navigation;
        navigation.mode = Navigation.Mode.None;
        selectable.navigation = navigation;
        var colors = selectable.colors;
        colors.normalColor = normal;
        colors.highlightedColor = hover;
        colors.selectedColor = selected;
        colors.pressedColor = pressed;
        colors.colorMultiplier = 1f;
        colors.fadeDuration = 0f;
        selectable.colors = colors;
    }

    private static void AddEvent(GameObject target, EventTriggerType type, UnityEngine.Events.UnityAction<BaseEventData> callback)
    {
        var trigger = target.GetComponent<EventTrigger>();
        if (trigger == null) trigger = target.AddComponent<EventTrigger>();
        var entry = new EventTrigger.Entry { eventID = type };
        entry.callback.AddListener(callback);
        trigger.triggers.Add(entry);
    }

    private void BeginHeaderDrag(PointerEventData data)
    {
        if (_hidden || _closed || data.button != PointerEventData.InputButton.Left) return;
        BringToFront();
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
            (RectTransform)_rootCanvas.transform, data.position, data.pressEventCamera, out _dragStartPointer)) return;
        _dragStartPosition = _panel.anchoredPosition;
        _draggingHeader = true;
    }

    private void DragHeader(PointerEventData data)
    {
        if (!_draggingHeader || _hidden || _closed) return;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
            (RectTransform)_rootCanvas.transform, data.position, data.pressEventCamera, out var pointer)) return;
        _panel.anchoredPosition = ClampPosition(_dragStartPosition + pointer - _dragStartPointer);
        RememberPosition();
    }

    private Vector2 ClampPosition(Vector2 position)
    {
        var bounds = ((RectTransform)_rootCanvas.transform).rect;
        return new Vector2(Mathf.Clamp(position.x, 0f, Mathf.Max(0f, bounds.width - _panel.rect.width)),
            Mathf.Clamp(position.y, Mathf.Min(0f, _panel.rect.height - bounds.height), 0f));
    }

    private static void PositionPanel(RectTransform panel, Canvas rootCanvas, Vector2 screenPosition, Vector2 offset)
    {
        var canvasRect = rootCanvas.transform as RectTransform;
        var camera = rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : rootCanvas.worldCamera;
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRect, screenPosition, camera, out var local))
            local = canvasRect.rect.center;
        float scale = Mathf.Max(0.0001f, rootCanvas.scaleFactor);
        float x = local.x + offset.x / scale;
        float y = local.y + offset.y / scale;
        var bounds = canvasRect.rect;
        x = Mathf.Clamp(x, bounds.xMin, Mathf.Max(bounds.xMin, bounds.xMax - panel.rect.width));
        y = Mathf.Clamp(y, Mathf.Min(bounds.yMax, bounds.yMin + panel.rect.height), bounds.yMax);
        panel.anchoredPosition = new Vector2(x - bounds.xMin, y - bounds.yMax);
    }
}
