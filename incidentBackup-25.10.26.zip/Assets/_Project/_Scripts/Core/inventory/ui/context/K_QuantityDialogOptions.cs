using System;

public enum K_QuantityDialogMode
{
    Split = 0,
    Eat = 1,
    Drink = 2,
    Transfusion = 3
}

/// <summary>Plain configuration for the existing generated quantity-window component.</summary>
public sealed class K_QuantityDialogOptions
{
    public K_QuantityDialogMode Mode;
    public string Title;
    public string QuantityLabel = "Количество";
    public string ConfirmLabel = "Подтвердить";
    public float Minimum = 1f;
    public float InitialValue = 1f;
    public Func<float> Maximum;
    public Func<bool> CanApply;
    public Func<bool> SourceAvailable;
    public Func<float, string> Preview;
    public Action<float> OnConfirm;
    public bool WholeNumbers = true;
    public bool ClampInputToRange;

    internal K_QuantityDialogOptions Copy() => (K_QuantityDialogOptions)MemberwiseClone();
}
