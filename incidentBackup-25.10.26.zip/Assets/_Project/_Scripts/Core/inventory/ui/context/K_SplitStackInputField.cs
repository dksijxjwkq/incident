using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>Changes only the native caret's height after TMP has rebuilt it.</summary>
public sealed class K_SplitStackInputField : TMP_InputField
{
    /// <summary>Height in UI pixels; zero uses TMP's natural glyph height.</summary>
    public float CaretHeight { get; set; }

    private readonly List<Vector3> _caretVertices = new List<Vector3>(4);
    private TMP_SelectionCaret _caretGraphic;

    public override void Rebuild(CanvasUpdate update)
    {
        base.Rebuild(update);
        if (update != CanvasUpdate.LatePreRender || CaretHeight <= 0f ||
            !isFocused || readOnly || !m_CaretVisible ||
            selectionStringAnchorPosition != selectionStringFocusPosition ||
            m_Mesh == null || m_Mesh.vertexCount != 4) return;

        if (_caretGraphic == null)
            _caretGraphic = GetComponentInChildren<TMP_SelectionCaret>(true);
        if (_caretGraphic == null) return;

        m_Mesh.GetVertices(_caretVertices);
        float bottom = _caretVertices[0].y;
        float top = bottom;
        for (int i = 1; i < _caretVertices.Count; i++)
        {
            bottom = Mathf.Min(bottom, _caretVertices[i].y);
            top = Mathf.Max(top, _caretVertices[i].y);
        }
        if (top <= bottom) return;

        // Preserve the native caret center, horizontal insertion point and width.
        // Native TMP still controls blink visibility, selection, color and clipping.
        float center = (bottom + top) * 0.5f;
        float halfHeight = CaretHeight * 0.5f;
        for (int i = 0; i < _caretVertices.Count; i++)
        {
            var vertex = _caretVertices[i];
            _caretVertices[i] = new Vector3(vertex.x,
                center + (vertex.y > center ? halfHeight : -halfHeight), vertex.z);
        }
        m_Mesh.SetVertices(_caretVertices);
        m_Mesh.RecalculateBounds();
        _caretGraphic.canvasRenderer.SetMesh(m_Mesh);
    }
}
