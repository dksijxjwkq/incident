﻿using UnityEngine;
using TMPro;
public class K_ContextMenuStyle : ScriptableObject
{
    [Header("Split Dialog")]
    [Tooltip("Стиль окна разделения. Назначается здесь и для автоматически создаваемого контекстного меню.")]
    public K_SplitStackDialogStyle SplitDialogStyle;

    [Header("Menu Layout")]
    [Tooltip("Минимальная ширина меню")]
    public float MinWidth = 180f;
    [Tooltip("Максимальная ширина")]
    public float MaxWidth = 280f;
    [Tooltip("Отступ от курсора (пиксели)")]
    public Vector2 OffsetFromCursor = new Vector2(8f, -8f);
    [Tooltip("Отступ внутри меню (padding)")]
    public float Padding = 6f;
    [Tooltip("Отступ между элементами в меню")]
    public float Spacing = 2f;

    [Header("Menu Background")]
    [Tooltip("Цвет фона меню")]
    public Color BackgroundColor = new Color(0.08f, 0.09f, 0.11f, 0.97f);
    [Tooltip("Цвет рамки меню (0 альфа = без рамки)")]
    public Color BorderColor = new Color(0.2f, 0.22f, 0.25f, 0.8f);
    [Tooltip("Толщина рамки (0 = без рамки)")]
    public float BorderThickness = 1f;

    [Header("Button Style")]
    [Tooltip("Высота кнопки")]
    public float ButtonHeight = 28f;
    [Tooltip("Цвет кнопки (нормальное состояние)")]
    public Color NormalColor = new Color(0.14f, 0.16f, 0.18f, 0.95f);
    [Tooltip("Цвет кнопки при наведении")]
    public Color HoverColor = new Color(0.25f, 0.30f, 0.35f, 0.95f);
    [Tooltip("Цвет кнопки (нажата)")]
    public Color PressedColor = new Color(0.1f, 0.12f, 0.14f, 0.95f);
    [Tooltip("Цвет опасной кнопки (Выбросить и т.д.)")]
    public Color DangerColor = new Color(0.7f, 0.15f, 0.15f, 0.95f);
    [Tooltip("Цвет опасной кнопки при наведении")]
    public Color DangerHoverColor = new Color(0.9f, 0.25f, 0.25f, 0.95f);
    [Tooltip("Цвет текста кнопки")]
    public Color TextColor = new Color(0.9f, 0.9f, 0.9f, 1f);
    [Tooltip("Цвет текста опасной кнопки")]
    public Color TextDangerColor = new Color(1f, 0.5f, 0.5f, 1f);
    [Tooltip("Цвет текста заблокированной кнопки")]
    public Color DisabledTextColor = new Color(0.5f, 0.5f, 0.5f, 1f);
    [Tooltip("Отступ текста от левого края кнопки")]
    public float TextLeftPadding = 10f;
    [Tooltip("Отступ текста от правого края кнопки")]
    public float TextRightPadding = 4f;

    [Header("Item Border (between buttons)")]
    [Tooltip("Показывать тонкую линию-разделитель между каждой кнопкой")]
    public bool ShowItemBorders = true;
    [Tooltip("Цвет линии между кнопками")]
    public Color ItemBorderColor = new Color(0.2f, 0.22f, 0.25f, 0.6f);
    [Tooltip("Толщина линии между кнопками (пиксели)")]
    public float ItemBorderThickness = 1f;
    [Tooltip("Отступ линии-разделителя от краёв кнопки по горизонтали")]
    public float ItemBorderHorizontalMargin = 0f;

    [Header("Section Separator Style")]
    [Tooltip("Цвет разделителя секций (жирная линия между группами)")]
    public Color SeparatorColor = new Color(0.3f, 0.3f, 0.3f, 0.8f);
    [Tooltip("Высота разделителя секций")]
    public float SeparatorHeight = 2f;

    [Header("Font")]
    [Tooltip("Размер шрифта кнопок")]
    public float FontSize = 13f;
    [Tooltip("Шрифт TextMeshPro (null = дефолтный)")]
    public TMP_FontAsset Font;

    [Header("Animation")]
    [Tooltip("Скорость появления (0 = мгновенно)")]
    public float AppearSpeed = 12f;

    [Header("Prefabs (optional)")]
    [Tooltip("Префаб кнопки меню. Если null — создаётся программно.")]
    public GameObject MenuItemPrefab;
    [Tooltip("Префаб разделителя. Если null — создаётся программно.")]
    public GameObject SeparatorPrefab;
    [Tooltip("Префаб панели описания")]
    public GameObject DescriptionPanelPrefab;

    /// <summary>
    /// Возвращает дефолтный стиль, если ассет не назначен.
    /// Используется чтобы меню работало даже без создания ассета.
    /// </summary>
    public static K_ContextMenuStyle Default()
    {
        var style = CreateInstance<K_ContextMenuStyle>();
        style.name = "(Default ContextMenu Style)";
        return style;
    }
}
