using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Geometry shared by grid layout, equipment drag and panel alignment.</summary>
    public static class InventoryUiGeometry
    {
        public static int GridRows(int slots, int columns) => columns > 0 && slots > 0 ? 1 + (slots - 1) / columns : 0;

        public static float GridExtent(int cells, float cellSize, float spacing) =>
            cells > 0 ? cells * cellSize + (cells - 1) * spacing : 0f;

        // A rectangular footprint repeats every 180 degrees; the model only has 0 and -90.
        public static bool SameFootprintOrientation(float visualAngle, float targetAngle) =>
            Mathf.Abs(Mathf.DeltaAngle(visualAngle * 2f, targetAngle * 2f)) < 0.01f;

        public static void AlignPanelToGrid(RectTransform panel, RectTransform grid)
        {
            if (panel == null || grid == null || panel == grid || panel.IsChildOf(grid)) return;
            var corners = new Vector3[4];
            grid.GetWorldCorners(corners);
            panel.localScale = Vector3.one;
            Vector2 min = panel.InverseTransformPoint(corners[0]);
            Vector2 max = min;
            for (int i = 1; i < corners.Length; i++)
            {
                Vector2 local = panel.InverseTransformPoint(corners[i]);
                min = Vector2.Min(min, local);
                max = Vector2.Max(max, local);
            }
            Vector3 topLeft = panel.TransformPoint(new Vector3(min.x, max.y, 0f));
            Vector2 size = max - min;
            panel.anchorMin = panel.anchorMax = panel.pivot = new Vector2(0f, 1f);
            panel.sizeDelta = size;
            panel.position = topLeft;
            if (grid.parent != panel) grid.SetParent(panel, false);
            grid.anchorMin = grid.anchorMax = grid.pivot = new Vector2(0f, 1f);
            grid.localScale = Vector3.one;
            grid.localRotation = Quaternion.identity;
            grid.sizeDelta = size;
            grid.anchoredPosition = Vector2.zero;
        }
    }
}
