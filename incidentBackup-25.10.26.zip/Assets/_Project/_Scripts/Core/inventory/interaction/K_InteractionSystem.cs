﻿
using K_Incident.Core.Inventory;
using TMPro;
using UnityEngine;

namespace K_Incident.Core
{
    public class K_InteractionSystem : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Interaction Settings")]
        [SerializeField, Tooltip("Радиус поиска интерактивных объектов от игрока (м)")]
        private float _interactionRange = 2.0f;

        [SerializeField, Tooltip("Клавиша взаимодействия")]
        private KeyCode _interactKey = KeyCode.E;

        [SerializeField, Tooltip("Слой, на котором находятся интерактивные объекты")]
        private LayerMask _interactableLayer;

        [Header("UI References")]
        [SerializeField] private TextMeshProUGUI _interactionPrompt;
        [SerializeField] private TextMeshProUGUI _holdProgressText;
        [SerializeField] private UnityEngine.Camera _playerCamera;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false; // ✅ По умолчанию выключено, чтобы не спамить
        [SerializeField] private bool _debugGizmos = true;

        #endregion

        #region Constants (ТЗ: "Никаких магических чисел")

        private const float SCAN_INTERVAL = 0.2f;
        private const float HOLD_PROGRESS_UPDATE_RATE = 0.05f;

        #endregion

        #region Fields

        private IInteractable _currentInteractable;
        private Transform _currentInteractableTransform;
        private Transform _playerTransform;
        private K_InventoryUI _cachedInventoryUI;
        private K_VitalitySystem _vitality;

        private bool _isHolding;
        private float _holdTimer;
        private IInteractable _holdTarget;
        private Transform _holdTransform;
        private float _holdDuration;
        private bool _isDestroyed;
        private bool _ignoreInteractionUntilRelease = false;

        // Троттлинг сканирования (ТЗ: "Минимум логики в Update")
        private float _nextScanTime;
        private float _lastProgressUpdateTime;

        // ФИКС БАГ #32: Кэшированный буфер для OverlapSphereNonAlloc
        private Collider[] _overlapBuffer = new Collider[32];

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _playerTransform = transform;
            _vitality = GetComponent<K_VitalitySystem>();
            _isDestroyed = false;
            _nextScanTime = 0f;
            _lastProgressUpdateTime = 0f;

            if (_playerCamera == null)
                _playerCamera = UnityEngine.Camera.main;

            if (_interactionPrompt != null)
                _interactionPrompt.gameObject.SetActive(false);

            if (_holdProgressText != null)
                _holdProgressText.gameObject.SetActive(false);

            // ═══ АУДИТ-ФИКС (Layer index out of bounds):
            // LayerMask.value — это битовая маска, а не индекс слоя.
            // LayerToName(int) ожидает ИНДЕКС слоя (0..31), а не маску.
            // Передача маски напрямую приводила к "Layer index out of bounds".
            // Корректный логгинг: берём первый установленный бит маски.
            // ═══
            string layerName = "none";
            int maskValue = _interactableLayer.value;
            for (int i = 0; i < 32; i++)
            {
                if ((maskValue & (1 << i)) != 0)
                {
                    layerName = LayerMask.LayerToName(i);
                    break;
                }
            }
            LogDebug($"[InteractionSystem] Initialized. Range: {_interactionRange}m, Layer: {layerName}");
        }

        private void Start()
        {
            _cachedInventoryUI = FindFirstObjectByType<K_InventoryUI>();
        }

        public void CancelForGroundLoot()
        {
            CancelHoldInteraction();
            ResetTarget();
            HidePrompt();
            _ignoreInteractionUntilRelease = Input.GetKey(_interactKey);
        }

        private void Update()
        {
            if (K_SplitStackDialog.IsOpen)
            {
                CancelForGroundLoot();
                return;
            }
            // A release can happen while either UI branch returns early, including
            // a frame whose GetKeyUp was consumed before this component resumed.
            if (!Input.GetKey(_interactKey)) _ignoreInteractionUntilRelease = false;
            if (_cachedInventoryUI != null && _cachedInventoryUI.IsGroundLootOpen)
            {
                CancelHoldInteraction();
                HidePrompt();
                if (Input.GetKey(_interactKey)) _ignoreInteractionUntilRelease = true;
                return;
            }
            if (IsInventoryOpen())
            {
                CancelHoldInteraction();
                HidePrompt();

                if (Input.GetKeyDown(_interactKey))
                {
                    _cachedInventoryUI?.CloseAll();
                    ResetTarget();
                    _ignoreInteractionUntilRelease = true;
                }
                return;
            }

            if (_ignoreInteractionUntilRelease)
            {
                if (Input.GetKeyUp(_interactKey))
                {
                    _ignoreInteractionUntilRelease = false;
                }
                return;
            }

            // ✅ ТРОТТЛИНГ: Проверка радиуса не каждый кадр, а раз в 0.2с
            if (Time.time >= _nextScanTime)
            {
                _nextScanTime = Time.time + SCAN_INTERVAL;
                CheckForNearbyInteractables();
            }

            HandleHoldInput();
            TickHoldInteraction(Time.deltaTime);
        }

        private void OnDestroy()
        {
            _isDestroyed = true;
            CancelHoldInteraction();
        }

        private void OnDisable()
        {
            CancelHoldInteraction();
            HidePrompt();
        }

        #endregion

        #region Core Logic

        private bool IsInventoryOpen()
        {
            return _cachedInventoryUI != null && _cachedInventoryUI.IsOpen;
        }

        private void CheckForNearbyInteractables()
        {
            // ФИКС БАГ #32: Используем NonAlloc для предотвращения GC аллокаций
            int hitCount = Physics.OverlapSphereNonAlloc(
                _playerTransform.position,
                _interactionRange,
                _overlapBuffer,
                _interactableLayer
            );

            if (hitCount == 0)
            {
                if (_currentInteractable != null)
                    ResetTarget();
                return;
            }

            IInteractable bestTarget = null;
            Transform bestTransform = null;
            float closestSqrDist = float.MaxValue;

            for (int i = 0; i < hitCount; i++)
            {
                var hit = _overlapBuffer[i];
                if (hit.TryGetComponent(out IInteractable interactable))
                {
                    float dist = Vector3.Distance(_playerTransform.position, hit.transform.position);
                    if (dist > _interactionRange) continue;

                    float sqrDist = dist * dist;
                    if (sqrDist < closestSqrDist)
                    {
                        closestSqrDist = sqrDist;
                        bestTarget = interactable;
                        bestTransform = hit.transform;
                    }
                }
            }

            if (bestTarget != null)
            {
                if (_currentInteractable != bestTarget)
                {
                    LogDebug($"[InteractionSystem] Target CHANGED: {bestTransform?.gameObject.name}");
                    _currentInteractable = bestTarget;
                    _currentInteractableTransform = bestTransform;
                    ShowPrompt(_currentInteractable.GetHoldPrompt());
                }
            }
            else
            {
                if (_currentInteractable != null)
                    ResetTarget();
            }
        }

        private void HandleHoldInput()
        {
            if (!IsInteractableAlive(_currentInteractable)) return;

            float requiredHold = _currentInteractable.GetHoldDuration();

            // ФИКС БАГ (audit) #24: защита от NaN/Infinity в hold duration.
            if (float.IsNaN(requiredHold) || float.IsInfinity(requiredHold))
            {
                Debug.LogWarning(
                    $"[InteractionSystem] Invalid hold duration {requiredHold} on {_currentInteractable}. Skipping.");
                return;
            }

            if (Input.GetKey(_interactKey) && !_isHolding)
            {
                if (requiredHold <= 0f)
                {
                    CompleteHoldInteraction();
                }
                else
                {
                    BeginHoldInteraction(_currentInteractable, _currentInteractableTransform, requiredHold);
                }
            }
            else if (!Input.GetKey(_interactKey) && _isHolding)
            {
                CancelHoldInteraction();
            }
        }

        // Preserve the captured target while advancing the action in the owning Update.
        private void BeginHoldInteraction(
            IInteractable capturedTarget,
            Transform capturedTransform,
            float duration)
        {
            _isHolding = true;
            _holdTimer = 0f;
            _holdTarget = capturedTarget;
            _holdTransform = capturedTransform;
            _holdDuration = duration;
            _lastProgressUpdateTime = Time.time;
            HidePrompt();
            ShowHoldProgress(0f);
        }

        private void TickHoldInteraction(float deltaTime)
        {
            if (!_isHolding) return;
            if (_isDestroyed || !IsInteractableAlive(_holdTarget) || _holdTransform == null ||
                !Input.GetKey(_interactKey) || (_currentInteractable != null &&
                !ReferenceEquals(_currentInteractable, _holdTarget)))
            {
                CancelHoldInteraction();
                return;
            }

            float currentSqrDist = Vector3.SqrMagnitude(_playerTransform.position - _holdTransform.position);
            if (currentSqrDist > _interactionRange * _interactionRange)
            {
                CancelHoldInteraction();
                return;
            }

            _holdTimer += deltaTime * (_vitality != null ? _vitality.ActionSpeedMult : 1f);
            if (Time.time - _lastProgressUpdateTime >= HOLD_PROGRESS_UPDATE_RATE)
            {
                ShowHoldProgress(Mathf.Clamp01(_holdTimer / _holdDuration));
                _lastProgressUpdateTime = Time.time;
            }
            if (_holdTimer >= _holdDuration)
                CompleteCapturedInteraction(_holdTarget, _holdTransform);
        }

        // ФИКС БАГ (audit) #24: проверка живости IInteractable.
        // Unity "fake null" — interface reference на уничтоженный MonoBehaviour
        // не настоящий null, поэтому нужна явная проверка.
        private static bool IsInteractableAlive(IInteractable value)
        {
            if (value == null) return false;
            return value is not UnityEngine.Object unityObject || unityObject != null;
        }

        private void CompleteCapturedInteraction(IInteractable capturedTarget, Transform capturedTransform)
        {
            _isHolding = false;
            _holdTimer = 0f;
            _holdTarget = null;
            _holdTransform = null;
            _holdDuration = 0f;
            HideHoldProgress();
            HidePrompt();

            if (IsInteractableAlive(capturedTarget))
            {
                LogDebug($"[InteractionSystem] Interaction COMPLETED: {capturedTransform?.gameObject.name}");
                capturedTarget.OnInteract();
            }

            ResetTarget();
        }

        private void CompleteHoldInteraction()
        {
            _isHolding = false;
            _holdTimer = 0f;
            _holdTarget = null;
            _holdTransform = null;
            _holdDuration = 0f;
            HideHoldProgress();
            HidePrompt();

            if (_currentInteractable != null)
            {
                LogDebug($"[InteractionSystem] Interaction COMPLETED: {_currentInteractableTransform?.gameObject.name}");
                _currentInteractable.OnInteract();
            }

            ResetTarget();
        }

        private void CancelHoldInteraction()
        {
            _isHolding = false;
            _holdTimer = 0f;
            _holdTarget = null;
            _holdTransform = null;
            _holdDuration = 0f;
            HideHoldProgress();
            if (IsInteractableAlive(_currentInteractable))
                ShowPrompt(_currentInteractable.GetHoldPrompt());
        }

        private void ResetTarget()
        {
            if (_currentInteractable != null)
            {
                CancelHoldInteraction();
                _currentInteractable = null;
                _currentInteractableTransform = null;
                HidePrompt();
            }
        }

        #endregion

        #region UI Helpers

        private void ShowPrompt(string text)
        {
            if (_interactionPrompt != null && !string.IsNullOrEmpty(text))
            {
                _interactionPrompt.text = text;
                _interactionPrompt.gameObject.SetActive(true);
            }
        }

        private void HidePrompt()
        {
            if (_interactionPrompt != null && _interactionPrompt.gameObject.activeSelf)
                _interactionPrompt.gameObject.SetActive(false);
        }

        private void ShowHoldProgress(float normalizedValue)
        {
            if (_holdProgressText != null)
            {
                _holdProgressText.text = $"{Mathf.RoundToInt(normalizedValue * 100)}%";
                if (!_holdProgressText.gameObject.activeSelf)
                    _holdProgressText.gameObject.SetActive(true);
            }
        }

        private void HideHoldProgress()
        {
            if (_holdProgressText != null && _holdProgressText.gameObject.activeSelf)
                _holdProgressText.gameObject.SetActive(false);
        }

        #endregion

        #region Debug & Gizmos

        private void OnDrawGizmosSelected()
        {
            if (_debugGizmos)
            {
                Gizmos.color = new Color(1f, 0.84f, 0f, 0.4f);
                Gizmos.DrawWireSphere(transform.position, _interactionRange);

                if (_currentInteractableTransform != null)
                {
                    Gizmos.color = Color.green;
                    Gizmos.DrawLine(transform.position, _currentInteractableTransform.position);
                }
            }
        }

        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs)
                UnityEngine.Debug.Log(message);
        }

        #endregion
    }
}
