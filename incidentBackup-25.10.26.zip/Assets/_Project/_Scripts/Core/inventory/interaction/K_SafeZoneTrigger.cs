﻿using UnityEngine;

using System.Collections.Generic;

namespace K_Incident.Core
{
    /// <summary>
    /// Компонентный триггер безопасной зоны (Аспект №6, №9)
    /// Поддержка множества зон в будущем без изменения кода
    /// </summary>
    public class K_SafeZoneTrigger : MonoBehaviour
    {
        [Header("Zone Settings")]
        [SerializeField] private string _zoneName = "TheHole";
        [SerializeField, Min(0.001f)] private float _coldRecoveryTime = 60f; // Секунд на полную очистку холода
        [SerializeField, Min(0f)] private float _metabolismMultiplier = 0.2f; // Замедление метаболизма
        private readonly Dictionary<Collider, K_VitalitySystem> _occupants = new Dictionary<Collider, K_VitalitySystem>();
        private readonly Dictionary<K_VitalitySystem, int> _playerColliderCounts = new Dictionary<K_VitalitySystem, int>();
        private readonly List<Collider> _staleColliders = new List<Collider>();

        private void Update()
        {
            if (_occupants.Count == 0) return;
            _staleColliders.Clear();
            foreach (var occupant in _occupants)
                if (occupant.Key == null || !occupant.Key.enabled || !occupant.Key.gameObject.activeInHierarchy || occupant.Value == null)
                    _staleColliders.Add(occupant.Key);
            for (int i = 0; i < _staleColliders.Count; i++) OnTriggerExit(_staleColliders[i]);
            _staleColliders.Clear();
        }

        private void OnTriggerEnter(Collider other)
        {
            if (!isActiveAndEnabled || other == null || _occupants.ContainsKey(other)) return;
            var vitality = other.GetComponentInParent<K_VitalitySystem>();
            if (vitality == null || (!other.CompareTag("Player") && !vitality.CompareTag("Player"))) return;
            _playerColliderCounts.TryGetValue(vitality, out int count);
            if (count == 0)
            {
                vitality.SetSafeZoneState(this, true, _coldRecoveryTime, _metabolismMultiplier);
                Debug.Log($"[SafeZone] ENTERED {_zoneName} — Metabolism ×{_metabolismMultiplier}, Cold recovery {_coldRecoveryTime}s");
            }
            _occupants.Add(other, vitality);
            _playerColliderCounts[vitality] = count + 1;
        }

        private void OnTriggerStay(Collider other) => OnTriggerEnter(other);

        private void OnTriggerExit(Collider other)
        {
            if (ReferenceEquals(other, null) || !_occupants.TryGetValue(other, out var vitality)) return;
            _occupants.Remove(other);
            int count = _playerColliderCounts[vitality] - 1;
            if (count > 0) _playerColliderCounts[vitality] = count;
            else
            {
                _playerColliderCounts.Remove(vitality);
                if (vitality != null) vitality.SetSafeZoneState(this, false);
                Debug.Log($"[SafeZone] LEFT {_zoneName}");
            }
        }

        private void OnDisable() => ReleaseOccupants();
        private void OnDestroy() => ReleaseOccupants();

        private void ReleaseOccupants()
        {
            var players = new List<K_VitalitySystem>(_playerColliderCounts.Keys);
            _playerColliderCounts.Clear();
            _occupants.Clear();
            _staleColliders.Clear();
            foreach (var player in players)
                if (player != null) player.SetSafeZoneState(this, false);
        }

        // ВИЗУАЛИЗАЦИЯ В SCENE VIEW (ТОЛЬКО КУБ, БЕЗ ТЕКСТА)
        private void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(0f, 1f, 0f, 0.3f); // Полупрозрачный зелёный
            Gizmos.DrawCube(transform.position, transform.lossyScale);

            Gizmos.color = Color.green;
            Gizmos.DrawWireCube(transform.position, transform.lossyScale);
        }
    }
}
