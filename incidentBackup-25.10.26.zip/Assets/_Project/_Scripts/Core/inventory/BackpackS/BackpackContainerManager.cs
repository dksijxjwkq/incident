using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    public sealed class BackpackContainerManager
    {
        // ═══════════════════════════════════════════════════════════
        //  ДЕЛЕГАТЫ (зависимости от K_InventoryUI)
        // ═══════════════════════════════════════════════════════════
        public delegate void RefreshDelegate();
        public delegate void CanvasActiveDelegate(bool active);
        public delegate void ContainerEventsDelegate();
        public delegate void GridSlotsRaycastDelegate(bool enabled);
        public delegate void StyleHeaderDelegate(K_ContainerWindow window);
        public delegate void RestoreLootDelegate();
        public delegate InventoryController GetLootControllerDelegate();
        public delegate InventoryItem FindItemDelegate(uint id);
        public delegate bool IsLootingDelegate();

        private RefreshDelegate _forceRefresh;
        private CanvasActiveDelegate _setCanvasActive;
        private ContainerEventsDelegate _subscribeToContainerEvents;
        private ContainerEventsDelegate _unsubscribeFromContainerEvents;
        private GridSlotsRaycastDelegate _setAllGridSlotsRaycast;
        private StyleHeaderDelegate _styleWindowHeader;
        private RestoreLootDelegate _restoreLootControllerIfLooting;
        private GetLootControllerDelegate _getLootControllerFromSlots;
        private FindItemDelegate _findItemByInstanceId;
        private IsLootingDelegate _isLootingContainer;

        // ═══════════════════════════════════════════════════════════
        //  КОНФИГУРАЦИЯ (из K_InventoryUI)
        // ═══════════════════════════════════════════════════════════
        private readonly GameObject _slotPrefab;
        private readonly float _slotSize;
        private readonly float _slotSpacing;
        private readonly Color _containerHeaderColor;
        private readonly float _containerHeaderHeight;
        private readonly GameObject _containerHeaderPrefab;

        private readonly Color      _containerWindowFillColor;
        private readonly Color      _containerWindowBorderColor;
        private readonly float      _containerWindowBorderThickness;

        // ═══════════════════════════════════════════════════════════
        //  ССЫЛКИ НА UI
        // ═══════════════════════════════════════════════════════════
        private K_InventoryUI _inventoryUI;
        private Transform _floatingWindowsRoot;
        private Transform _originalSurroundingsPanel;
        private Transform _originalSurroundingsGrid;
        private Transform _originalSurroundingsItemsContainer;

        private Transform _surroundingsPanel;
        private Transform _surroundingsGrid;
        private Transform _surroundingsItemsContainer;

        private GameObject _backpackPanel;
        private GameObject _inventoryBackground;
        private TMPro.TextMeshProUGUI _containerNameText;

        private InventoryController _pocketsController;
        private InventoryController _pocket2Controller;
        private InventoryController _backpackController;
        private K_EquipmentSlotUI _backpackSlot;

        // ═══════════════════════════════════════════════════════════
        //  ВНУТРЕННЕЕ СОСТОЯНИЕ
        // ═══════════════════════════════════════════════════════════
        private readonly List<K_ContainerWindow> _openContainerWindows = new List<K_ContainerWindow>();
        private readonly Dictionary<string, InventoryController> _openedBackpacks = new Dictionary<string, InventoryController>();
        private K_ContainerWindow _activeContainerWindow;
        private InventoryItem _activeBackpackContainer;
        private InventoryController _activeContainerController;
        private int _currentContainerCols;
        private int _currentContainerRows;

        // ═══════════════════════════════════════════════════════════
        //  READ-ONLY СВОЙСТВА
        // ═══════════════════════════════════════════════════════════
        public const int MaxOpenFloatingWindows = 3;
        private readonly List<K_ContainerWindow> _closeBuffer = new List<K_ContainerWindow>(8);
private readonly List<K_ContainerWindow> _reentryBuffer = new List<K_ContainerWindow>(8);
        public IReadOnlyList<K_ContainerWindow> OpenWindows => _openContainerWindows;
        public IReadOnlyDictionary<string, InventoryController> OpenedBackpacks => _openedBackpacks;
        public K_ContainerWindow ActiveWindow => _activeContainerWindow;
        public InventoryItem ActiveBackpackContainer => _activeBackpackContainer;
        public InventoryController ActiveContainerController => _activeContainerController;
        public void SetActiveContainerController(InventoryController ctrl) => _activeContainerController = ctrl;

        private InventoryController GetLiveLootController()
        {
            if (!(_isLootingContainer?.Invoke() ?? false)) return null;
            // Ground loot replaces its controller when it repacks. The slots/UI
            // delegate resolves that live root; a previously cached root may be disposed.
            var current = _getLootControllerFromSlots?.Invoke();
            if (current != null && !current.IsDisposed) return current;
            return _activeContainerController != null && !_activeContainerController.IsDisposed
                ? _activeContainerController : null;
        }
        public int CurrentContainerCols => _currentContainerCols;
        public int CurrentContainerRows => _currentContainerRows;
        public Transform SurroundingsPanel => _surroundingsPanel;
        public Transform SurroundingsGrid => _surroundingsGrid;
        public Transform SurroundingsItemsContainer => _surroundingsItemsContainer;
        public Transform OriginalSurroundingsPanel => _originalSurroundingsPanel;
        public Transform OriginalSurroundingsGrid => _originalSurroundingsGrid;
        public Transform OriginalSurroundingsItemsContainer => _originalSurroundingsItemsContainer;

       public BackpackContainerManager(
    GameObject slotPrefab,
    float slotSize,
    float slotSpacing,
    Color containerHeaderColor,
    float containerHeaderHeight,
    GameObject containerHeaderPrefab,
    Color containerWindowFillColor,
    Color containerWindowBorderColor,
    float containerWindowBorderThickness)
{
    _slotPrefab = slotPrefab;
    _slotSize = slotSize;
    _slotSpacing = slotSpacing;
    _containerHeaderColor = containerHeaderColor;
    _containerHeaderHeight = containerHeaderHeight;
    _containerHeaderPrefab = containerHeaderPrefab;
    _containerWindowFillColor = containerWindowFillColor;
    _containerWindowBorderColor = containerWindowBorderColor;
    _containerWindowBorderThickness = containerWindowBorderThickness;
}

        public void Initialize(
            K_InventoryUI inventoryUI,
            Transform floatingWindowsRoot,
            Transform originalSurroundingsPanel,
            Transform originalSurroundingsGrid,
            Transform originalSurroundingsItemsContainer,
            GameObject backpackPanel,
            GameObject inventoryBackground,
            TMPro.TextMeshProUGUI containerNameText,
            InventoryController pocketsController,
            InventoryController pocket2Controller,
            InventoryController backpackController,
            K_EquipmentSlotUI backpackSlot,
            RefreshDelegate forceRefresh,
            CanvasActiveDelegate setCanvasActive,
            ContainerEventsDelegate subscribeToContainerEvents,
            ContainerEventsDelegate unsubscribeFromContainerEvents,
            GridSlotsRaycastDelegate setAllGridSlotsRaycast,
            StyleHeaderDelegate styleWindowHeader,
            RestoreLootDelegate restoreLootControllerIfLooting,
            GetLootControllerDelegate getLootControllerFromSlots,
            FindItemDelegate findItemByInstanceId,
            IsLootingDelegate isLootingContainer)
        {
            _inventoryUI = inventoryUI;
            _floatingWindowsRoot = floatingWindowsRoot;
            _originalSurroundingsPanel = originalSurroundingsPanel;
            _originalSurroundingsGrid = originalSurroundingsGrid;
            _originalSurroundingsItemsContainer = originalSurroundingsItemsContainer;
            _surroundingsPanel = originalSurroundingsPanel;
            _surroundingsGrid = originalSurroundingsGrid;
            _surroundingsItemsContainer = originalSurroundingsItemsContainer;
            _backpackPanel = backpackPanel;
            _inventoryBackground = inventoryBackground;
            _containerNameText = containerNameText;
            _pocketsController = pocketsController;
            _pocket2Controller = pocket2Controller;
            _backpackController = backpackController;
            _backpackSlot = backpackSlot;
            _forceRefresh = forceRefresh;
            _setCanvasActive = setCanvasActive;
            _subscribeToContainerEvents = subscribeToContainerEvents;
            _unsubscribeFromContainerEvents = unsubscribeFromContainerEvents;
            _setAllGridSlotsRaycast = setAllGridSlotsRaycast;
            _styleWindowHeader = styleWindowHeader;
            _restoreLootControllerIfLooting = restoreLootControllerIfLooting;
            _getLootControllerFromSlots = getLootControllerFromSlots;
            _findItemByInstanceId = findItemByInstanceId;
            _isLootingContainer = isLootingContainer;
        }

        // ═══════════════════════════════════════════════════════════
        //  PUBLIC API
        // ═══════════════════════════════════════════════════════════
 public int GetBackpackDepth(InventoryItem item)
{
    if (item == null) return 0;

    if (_backpackSlot != null && _backpackSlot.EquippedItem == item)
        return 1;
    if (_pocketsController != null && _pocketsController.FindItemRootPosition(item.InstanceID).x != -1)
        return 1;
    if (_pocket2Controller != null && _pocket2Controller.FindItemRootPosition(item.InstanceID).x != -1)
        return 1;
    if (_backpackController != null && _backpackController.FindItemRootPosition(item.InstanceID).x != -1)
        return 1;

    int depth = FindItemOwnerDepth(item.InstanceID, 0);
    return depth > 0 ? depth : 1;
}

// ═══════════════════════════════════════════════════════════
//  ЕДИНАЯ ТОЧКА ВАЛИДАЦИИ: можно ли поместить РАЗВЁРНУТЫЙ рюкзак
//  внутрь целевого рюкзака. Используется ВСЕМИ путями:
//    - DragHighlightController (визуальная подсветка)
//    - InventoryTransactionService (транзакции)
//    - BackpackStateManager (fold/unfold)
// ═══════════════════════════════════════════════════════════
// BackpackContainerManager.cs
// Assets/_Project/_Scripts/Core/inventory/BackpackContainerManager.cs
public bool CanPlaceUnfoldedBackpack(
    InventoryItem targetBackpack,
    InventoryItem unfoldedBackpack,
    out string reason)
{
    reason = string.Empty;

    if (unfoldedBackpack == null
        || unfoldedBackpack.Data == null
        || !unfoldedBackpack.Data.IsBackpack
        || unfoldedBackpack.IsFolded)
        return true;

    if (targetBackpack == null)
        return true;

    int targetDepth = GetNestingDepth(targetBackpack);

    // КОРЕНЬ: если окно цели закрыто, его придётся открыть для доступа к сетке,
    // поэтому добавляем 1 к глубине.
    if (!IsBackpackWindowOpen(targetBackpack))
        targetDepth += 1;

    int placedDepth = targetDepth + 1;

    if (placedDepth > MaxOpenFloatingWindows)
    {
        reason = $"Превышен лимит вложенности рюкзаков ({MaxOpenFloatingWindows}). " +
                 $"Глубина цели с учётом открытия: {targetDepth}, размещаемый станет на {placedDepth}.";
        return false;
    }

    return true;
}
private int FindItemOwnerDepth(uint targetId, int guard)
{
    if (guard > 16) return 0;

    var roots = new[] { _pocketsController, _pocket2Controller, _backpackController };
    foreach (var ctrl in roots)
    {
        if (ctrl == null) continue;

        for (int y = 0; y < ctrl.Height; y++)
        {
            for (int x = 0; x < ctrl.Width; x++)
            {
                var it = ctrl.GetItemAt(x, y);
                if (it == null || !ctrl.IsRootCell(it.InstanceID, x, y)) continue;

                if (it.InstanceID == targetId)
                    return 1;

                if (it.Data != null && it.Data.IsBackpack && BackpackContainsTarget(it, targetId))
                    return GetBackpackDepth(it) + 1;
            }
        }
    }

    for (int i = 0; i < _openContainerWindows.Count; i++)
    {
        var w = _openContainerWindows[i];
        if (w == null || w.Controller == null) continue;

        var c = w.Controller;
        for (int y = 0; y < c.Height; y++)
        {
            for (int x = 0; x < c.Width; x++)
            {
                var it = c.GetItemAt(x, y);
                if (it == null || !c.IsRootCell(it.InstanceID, x, y)) continue;

                if (it.InstanceID == targetId)
                {
                    var owner = FindBackpackItemByID(w.BackpackInstanceID);
                    return owner != null ? GetBackpackDepth(owner) + 1 : 2;
                }

                if (it.Data != null && it.Data.IsBackpack && BackpackContainsTarget(it, targetId))
                    return GetBackpackDepth(it) + 1;
            }
        }
    }

    return 0;
}
/// <summary>
/// ЕДИНСТВЕННАЯ точка проверки: можно ли положить/развернуть РАЗВЁРНУТЫЙ рюкзак
/// внутри контроллера целевого окна. Для корневых сеток (карманы, экипированный
/// рюкзак) всегда разрешено. Для окна с глубиной >= 3 — запрещено, иначе новый
/// рюкзак станет 4-м окном, которое невозможно открыть.
/// </summary>
public bool CanPlaceUnfoldedBackpackIntoController(
    InventoryController targetController,
    InventoryItem backpack,
    out string reason)
{
    reason = string.Empty;
    if (backpack == null || backpack.Data == null || !backpack.Data.IsBackpack || backpack.IsFolded)
        return true;
    if (targetController == null)
        return true;
    var window = FindWindowByController(targetController);
    if (window == null)
        return true;
    if (!uint.TryParse(window.BackpackInstanceID, out _))
    { reason = "Cannot resolve backpack window owner identity"; return false; }
    if (!uint.TryParse(window.BackpackInstanceID, out uint ownerId))
        return true;
    var owner = _findItemByInstanceId?.Invoke(ownerId);
    if (owner == null) owner = InventoryOwnershipRegistry.FindLiveItem(ownerId);
    if (owner == null)
    { reason = "Cannot resolve backpack window owner; placement refused"; return false; }
    if (owner == null)
        return true;
    return CanPlaceUnfoldedBackpack(owner, backpack, out reason);
}

private bool BackpackContainsTarget(InventoryItem backpack, uint targetId)
{
    if (backpack == null || targetId == 0) return false;

    string idStr = backpack.InstanceID.ToString();
    if (_openedBackpacks.TryGetValue(idStr, out var liveCtrl)
        && liveCtrl != null
        && !liveCtrl.IsDisposed)
    {
        if (ContainsItemRecursive(liveCtrl, targetId, 0))
            return true;
    }

    return backpack.ContainsDescendantStrict(targetId);
}




       public int GetInternalDepth(InventoryItem backpack, int currentDepth = 1)
{
    if (backpack == null || !backpack.Data.IsBackpack) return currentDepth;
    if (currentDepth > 16) return currentDepth;
    var savedItems = backpack.GetBackpackSavedItems();
    if (savedItems == null || savedItems.Count == 0) return currentDepth;

    int maxChildDepth = currentDepth;
    foreach (var saved in savedItems)
    {
        var template = K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID);
        if (template != null && template.IsBackpack)
        {
            var inner = InventoryItem.FromSaveData(saved, template);
            if (inner != null)
            {
                int d = GetInternalDepth(inner, currentDepth + 1);
                if (d > maxChildDepth) maxChildDepth = d;
            }
        }
    }
    return maxChildDepth;
}


        public bool IsBackpackWindowOpen(InventoryItem item)
        {
            if (item == null) return false;
            string idStr = item.InstanceID.ToString();
            return _openContainerWindows.Exists(w => w != null && w.BackpackInstanceID == idStr);
        }

        public bool CanOpenBackpack(InventoryItem item)
        {
            if (item?.Data != null && !InventoryGridBounds.IsValidBackpack(item.Data)) return false;
            if (item == null || item.Data == null || !item.Data.IsBackpack) return false;
            if (item.IsFolded && !item.Data.AlwaysShowGrid) return false;
            return true;
        }

public void CloseActiveBackpack()
{
    if (InventoryAtomicJournal.DeferLifecycle(() => CloseActiveBackpack())) return;
    if (_activeContainerWindow != null)
    {
        CloseSpecificBackpackWindow(_activeContainerWindow.BackpackInstanceID);
        return;
    }
    if (_activeBackpackContainer == null) return;
    var backpackItem = _activeBackpackContainer;
    var instanceIdStr = backpackItem.InstanceID.ToString();
    if (_openedBackpacks.TryGetValue(instanceIdStr, out var controller))
    {
        var savedItems = controller.GetSaveData()?.GetItems();
        backpackItem.ReplaceBackpackContents(savedItems);
        controller.Dispose();
        _openedBackpacks.Remove(instanceIdStr);
    }
    _activeBackpackContainer = null;
    _activeContainerController = null;
    _currentContainerCols = 0;
    _currentContainerRows = 0;
    _unsubscribeFromContainerEvents?.Invoke();
    if (_surroundingsPanel != null) _surroundingsPanel.gameObject.SetActive(false);
    _forceRefresh?.Invoke();
}

public void CloseBackpackByItem(InventoryItem item)
{
    if (InventoryAtomicJournal.DeferLifecycle(() => CloseBackpackByItem(item))) return;
    if (item == null) return;
    string idStr = item.InstanceID.ToString();
    CloseSpecificBackpackWindow(idStr);
    _restoreLootControllerIfLooting?.Invoke();
}
  public void OpenBackpack(InventoryItem backpackItem)
{
    if (backpackItem?.Data != null && !InventoryGridBounds.IsValidBackpack(backpackItem.Data))
    { Debug.LogError("[Backpacks] Backpack dimensions must be between 1 and 20."); return; }
    if (backpackItem == null || !backpackItem.Data.IsBackpack) return;
    if (backpackItem.IsFolded && !backpackItem.Data.AlwaysShowGrid) return;

    int w = backpackItem.Data.BackpackWidth, h = backpackItem.Data.BackpackHeight;
    if (w <= 0 || h <= 0 || _slotPrefab == null) return;

    string idStr = backpackItem.InstanceID.ToString();
   var existing = _openContainerWindows.Find(x => x != null && x.BackpackInstanceID == idStr);
if (existing != null)
{
    if (_activeContainerWindow == existing) 
    { 
        CloseSpecificBackpackWindow(existing.BackpackInstanceID); 
        return; 
    }
    _floatingWindowsRoot?.SetAsLastSibling();
    existing.transform.SetAsLastSibling();
    ActivateContainerWindow(existing);
    _activeBackpackContainer = backpackItem;
    return;
}

    if (_openContainerWindows.Count >= MaxOpenFloatingWindows)
    {
        Debug.LogWarning($"[Backpacks] Достигнут лимит открытых окон ({MaxOpenFloatingWindows}). Закройте одно из них.");
        return;
    }

    InventoryController controller;
    if (_openedBackpacks.TryGetValue(idStr, out var existingCtrl)) controller = existingCtrl;
    else
    {
        var db = K_InventorySetup.DatabaseInstance;
        if (db == null) return;
        var data = new InventoryData(w, h);
        var savedItems = backpackItem.GetBackpackSavedItems();
        if (savedItems != null) foreach (var s in savedItems) data.AddItem(s);
        controller = new InventoryController(data, db, $"Backpack_{backpackItem.InstanceID}");
        _openedBackpacks[idStr] = controller;
    }

    backpackItem.SetBackpackController(controller);

    _activeBackpackContainer = backpackItem;
    
    // ═══ ДОБАВЬ ЭТОТ ЛОГ ЗДЕСЬ ═══
    Debug.Log($"[OpenBackpack] Creating NEW window for '{backpackItem.Data.DisplayName}' (ID={backpackItem.InstanceID}), " +
              $"openCount={_openContainerWindows.Count}");
    
    var window = CreateContainerWindow(controller, idStr, backpackItem.Data.DisplayName, w, h);
    if (window == null) return;
    ActivateContainerWindow(window);
    _setCanvasActive?.Invoke(true);
    if (_backpackPanel != null) _backpackPanel.SetActive(true);
    if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
    _forceRefresh?.Invoke();
}
        /// <summary>Releases floating windows without invoking callbacks into a dying inventory UI.</summary>
        public void DisposeForOwnerDestroy()
        {
            var lootController = GetLiveLootController();
            bool canPersist = (_pocketsController != null && !_pocketsController.IsDisposed)
                || (_pocket2Controller != null && !_pocket2Controller.IsDisposed)
                || (_backpackController != null && !_backpackController.IsDisposed)
                || (lootController != null && !lootController.IsDisposed)
                || (_backpackSlot != null && _backpackSlot.EquippedItem != null);
            _forceRefresh = null;
            _subscribeToContainerEvents = null;
            _unsubscribeFromContainerEvents = null;
            _setCanvasActive = null;
            _setAllGridSlotsRaycast = null;
            _styleWindowHeader = null;
            _restoreLootControllerIfLooting = null;
            _inventoryUI = null;
            try
            {
                if (canPersist)
                {
                    CloseAllBackpacks();
                    DestroyAllWindows();
                }
            }
            finally
            {
                // Canvas teardown can already have destroyed window components.
                // Their plain controllers still require explicit disposal.
                foreach (var controller in _openedBackpacks.Values)
                    controller?.Dispose();
                _openedBackpacks.Clear();
                foreach (var window in _openContainerWindows)
                {
                    if (window == null) continue;
                    window.OnWindowFocused -= OnContainerWindowFocused;
                    window.Controller?.Dispose();
                    UnityEngine.Object.Destroy(window.gameObject);
                }
                _openContainerWindows.Clear();
                _closeBuffer.Clear();
                _reentryBuffer.Clear();
                _activeContainerWindow = null;
                _activeBackpackContainer = null;
                _activeContainerController = null;
                _currentContainerCols = 0;
                _currentContainerRows = 0;
                _findItemByInstanceId = null;
                _isLootingContainer = null;
                _getLootControllerFromSlots = null;
                _floatingWindowsRoot = null;
                _surroundingsPanel = _originalSurroundingsPanel;
                _surroundingsGrid = _originalSurroundingsGrid;
                _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
            }
        }

public void CloseAllBackpacks()
{
    if (InventoryAtomicJournal.DeferLifecycle(() => CloseAllBackpacks())) return;
    var snapshot = new List<K_ContainerWindow>(_openContainerWindows);
    foreach (var window in snapshot)
    {
        if (window != null)
            DestroyContainerWindow(window);
    }

    if (_openedBackpacks.Count > 0)
    {
        var toRemove = new List<string>(_openedBackpacks.Keys);
        foreach (var id in toRemove)
        {
            if (!_openedBackpacks.TryGetValue(id, out var ctrl) || ctrl == null)
            {
                _openedBackpacks.Remove(id);
                continue;
            }

            if (!ctrl.IsDisposed && uint.TryParse(id, out uint bpId))
            {
                ctrl.RefreshAllItemsInData();
                var items = ctrl.GetSaveData()?.GetItems();
                var owner = FindBackpackItemByID(bpId.ToString());
                if (owner != null)
                {
                    if (items != null)
                        owner.ReplaceBackpackContents(items);
                    owner.ClearBackpackController();
                }
                else if (items != null)
                {
                    if (CommitBackpackContentsIntoChain(bpId, items))
                    {
                        Debug.LogWarning(
                            $"[Backpacks] Окно {id}: живой владелец недоступен — " +
                            "содержимое закоммичено в serialized-цепочку.");
                    }
                    else
                    {
                        Debug.LogError(
                            $"[Backpacks] Окно {id}: владелец не найден ни в живых, " +
                            "ни в serialized-данных — содержимое утрачено.");
                    }
                }
            }

            ctrl.Dispose();
            _openedBackpacks.Remove(id);
        }
    }

    _activeContainerWindow = null;
    _activeBackpackContainer = null;
    _activeContainerController = null;
    _currentContainerCols = 0;
    _currentContainerRows = 0;
    _unsubscribeFromContainerEvents?.Invoke();
    _surroundingsPanel = _originalSurroundingsPanel;
    _surroundingsGrid = _originalSurroundingsGrid;
    _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
    _forceRefresh?.Invoke();
}       
 public void CloseAllWindowsForBackpackItem(InventoryItem backpackItem)
{
    if (InventoryAtomicJournal.DeferLifecycle(() => CloseAllWindowsForBackpackItem(backpackItem))) return;
    if (backpackItem == null) return;
    
    // ═══ ДОБАВЬ ЭТОТ ЛОГ ЗДЕСЬ ═══
    Debug.Log($"[CloseAllWindowsForBackpackItem] Closing windows for '{backpackItem.Data?.DisplayName}' (ID={backpackItem.InstanceID})");
    
    string idStr = backpackItem.InstanceID.ToString();
    var windowsToClose = _openContainerWindows.FindAll(
        w => w != null && w.BackpackInstanceID == idStr);
    foreach (var window in windowsToClose)
    {
        if (window == null || !_openContainerWindows.Contains(window)) continue;
        DestroyContainerWindow(window);
    }
    if (_openedBackpacks.TryGetValue(idStr, out var ctrl))
    {
        ctrl.Dispose();
        _openedBackpacks.Remove(idStr);
    }
    if (_activeBackpackContainer != null &&
        _activeBackpackContainer.InstanceID.ToString() == idStr)
    {
        _activeBackpackContainer = null;
        bool isLooting = _isLootingContainer?.Invoke() ?? false;
        if (!isLooting)
        {
            _activeContainerController = null;
            _currentContainerCols = 0;
            _currentContainerRows = 0;
            _unsubscribeFromContainerEvents?.Invoke();
        }
    }
    if (_activeContainerWindow != null && !_openContainerWindows.Contains(_activeContainerWindow))
    {
        _activeContainerWindow = null;
        _surroundingsPanel = _originalSurroundingsPanel;
        _surroundingsGrid = _originalSurroundingsGrid;
        _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
    }
    if (_activeContainerWindow == null && _openContainerWindows.Count > 0)
    {
        var last = _openContainerWindows[_openContainerWindows.Count - 1];
        ActivateContainerWindow(last);
        if (_activeBackpackContainer == null)
            _activeBackpackContainer = FindBackpackItemByID(last.BackpackInstanceID);
    }
}

 public void CloseNestedBackpacks(InventoryItem backpackItem)
{
    if (InventoryAtomicJournal.DeferLifecycle(() => CloseNestedBackpacks(backpackItem))) return;
    if (backpackItem == null) return;

    string rootId = backpackItem.InstanceID.ToString();
    var rootWindow = _openContainerWindows.Find(w => w != null && w.BackpackInstanceID == rootId);
    if (rootWindow != null)
    {
        DestroyContainerWindow(rootWindow);
        return;
    }

    // Корневое окно закрыто — источник правды по потомкам: сериализованное
    // содержимое самого предмета. ContainsDescendant покрывает любую глубину.
    for (int i = _openContainerWindows.Count - 1; i >= 0; i--)
    {
        var w = _openContainerWindows[i];
        if (w == null || !_openContainerWindows.Contains(w)) continue;
        if (!uint.TryParse(w.BackpackInstanceID, out uint wid)) continue;
        if (backpackItem.ContainsDescendant(wid))
            DestroyContainerWindow(w);
    }
}

        public void SuspendForLoot()
        {
            foreach (var window in _openContainerWindows)
            {
                if (window != null && window.PanelRect != null)
                    window.PanelRect.gameObject.SetActive(false);
            }
            _surroundingsPanel = _originalSurroundingsPanel;
            _surroundingsGrid = _originalSurroundingsGrid;
            _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
        }

        public void ResumeAfterLoot()
        {
            if (_openContainerWindows.Count > 0)
            {
                foreach (var window in _openContainerWindows)
                {
                    if (window != null && window.PanelRect != null)
                        window.PanelRect.gameObject.SetActive(true);
                }
                var lastWindow = _openContainerWindows[_openContainerWindows.Count - 1];
                _surroundingsPanel = lastWindow.PanelRect;
                _surroundingsGrid = lastWindow.GridRect;
                _surroundingsItemsContainer = lastWindow.ItemsContainer;
                _activeContainerWindow = lastWindow;
                _activeContainerController = lastWindow.Controller;
                _currentContainerCols = lastWindow.GridWidth;
                _currentContainerRows = lastWindow.GridHeight;
            }
            else
            {
                _surroundingsPanel = _originalSurroundingsPanel;
                _surroundingsGrid = _originalSurroundingsGrid;
                _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
            }
        }

        public K_ContainerWindow FindWindowByController(InventoryController controller)
        {
            if (controller == null) return null;
            foreach (var w in _openContainerWindows)
                if (w != null && w.Controller == controller) return w;
            return null;
        }

       // ═══════════════════════════════════════════════════════════
//  ЕДИНЫЙ МЕТОД ПОДСЧЁТА ГЛУБИНЫ (заменяет GetBackpackDepth и старый GetNestingDepth)
//  Возвращает количество ПЕРЕНОСНЫХ СЕТОК (открытых окон) в цепочке
//  от экипированного рюкзака до данного предмета (включительно).
//
//  Пример: А(экипирован) → Б(открыт) → В(открыт) → Г(открыт)
//    GetNestingDepth(Б) = 1
//    GetNestingDepth(В) = 2
//    GetNestingDepth(Г) = 3
//    GetNestingDepth(предмет внутри Г) = 3
// ═══════════════════════════════════════════════════════════
public int GetNestingDepth(InventoryItem item)
{
    if (item == null) return 0;
    int depth = 0;
    var cur = item;

    // Если предмет сам является открытым рюкзаком (имеет собственное окно),
    // считаем его как переносную сетку.
    if (cur.Data != null && cur.Data.IsBackpack && IsBackpackWindowOpen(cur))
        depth = 1;

    for (int guard = 0; guard < 16; guard++)
    {
        var w = FindOpenWindowContainingItem(cur);
        if (w == null) return depth;
        depth++;
        var owner = FindBackpackItemByID(w.BackpackInstanceID);
        if (owner == null) return MaxOpenFloatingWindows + 1;
        if (owner == null) return depth;
        cur = owner;
    }
    return depth;
}

        public bool IsAncestorOf(InventoryController potentialAncestorCtrl, string descendantBackpackId, int depth = 0)
        {
            if (potentialAncestorCtrl == null || string.IsNullOrEmpty(descendantBackpackId) || depth > 16) return false;
            for (int y = 0; y < potentialAncestorCtrl.Height; y++)
            {
                for (int x = 0; x < potentialAncestorCtrl.Width; x++)
                {
                    var item = potentialAncestorCtrl.GetItemAt(x, y);
                    if (item == null) continue;
                    if (item.InstanceID.ToString() == descendantBackpackId) return true;
                    if (item.Data != null && item.Data.IsBackpack)
                    {
                        string itemIdStr = item.InstanceID.ToString();
                        var innerWindow = _openContainerWindows.Find(
                            w => w != null && w.BackpackInstanceID == itemIdStr);
                        if (innerWindow != null && innerWindow.Controller != null)
                        {
                            if (IsAncestorOf(innerWindow.Controller, descendantBackpackId, depth + 1))
                                return true;
                        }
                        else if (item.ContainsDescendant(uint.Parse(descendantBackpackId)))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public bool ContainsItemRecursive(InventoryController ctrl, uint targetId, int depth = 0)
        {
            if (ctrl == null || depth > 16) return false;
            for (int y = 0; y < ctrl.Height; y++)
            {
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var it = ctrl.GetItemAt(x, y);
                    if (it == null) continue;
                    if (it.InstanceID == targetId) return true;
                    if (it.Data != null && it.Data.IsBackpack)
                    {
                        var innerWindow = _openContainerWindows.Find(w => w.BackpackInstanceID == it.InstanceID.ToString());
                        if (innerWindow != null && innerWindow.Controller != null)
                        {
                            if (ContainsItemRecursive(innerWindow.Controller, targetId, depth + 1))
                                return true;
                        }
                        else if (it.ContainsDescendant(targetId)) return true;
                    }
                }
            }
            return false;
        }

        public bool IsControllerContainingBackpack(InventoryController ctrl, string backpackInstanceId)
        {
            if (ctrl == null || string.IsNullOrEmpty(backpackInstanceId)) return false;
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var item = ctrl.GetItemAt(x, y);
                    if (item != null && item.InstanceID.ToString() == backpackInstanceId)
                        return true;
                }
            return false;
        }

        public void DestroyAllWindows()
        {
    if (InventoryAtomicJournal.DeferLifecycle(() => DestroyAllWindows())) return;
            for (int i = _openContainerWindows.Count - 1; i >= 0; i--)
            {
                if (_openContainerWindows[i] != null)
                    DestroyContainerWindow(_openContainerWindows[i]);
            }
            _activeContainerWindow = null;
            _surroundingsPanel = _originalSurroundingsPanel;
            _surroundingsGrid = _originalSurroundingsGrid;
            _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
        }

        public bool IsBackpackOpenInCache(string instanceId) =>
            _openedBackpacks.ContainsKey(instanceId);

        public InventoryController GetLiveController(string instanceId)
        {
            _openedBackpacks.TryGetValue(instanceId, out var ctrl);
            return ctrl;
        }

        public void DisposeController(string instanceId)
        {
    if (InventoryAtomicJournal.DeferLifecycle(() => DisposeController(instanceId))) return;
            if (_openedBackpacks.TryGetValue(instanceId, out var ctrl))
            {
                ctrl.Dispose();
                _openedBackpacks.Remove(instanceId);
            }
        }

        // ═══════════════════════════════════════════════════════════
        //  SERIALIZED CHAIN COMMIT
        // ═══════════════════════════════════════════════════════════

        /// <summary>
        /// Записывает contents как содержимое SavedItem с InstanceID ==
        /// backpackInstanceId в serialized-цепочке всех достижимых рюкзаков
        /// (сетки игрока + открытые окна + их живые вложенные уровни).
        /// Единственная точка записи в serialized-уровни, чьи окна закрыты.
        /// </summary>
       /// <summary>
/// Записывает contents как содержимое SavedItem с InstanceID ==
/// backpackInstanceId в serialized-цепочке всех достижимых рюкзаков
/// (сетки игрока + открытые окна + их живые вложенные уровни).
/// Единственная точка записи в serialized-уровни, чьи окна закрыты.
/// </summary>
public bool CommitBackpackContentsIntoChain(uint backpackInstanceId, IReadOnlyList<SavedItem> contents)
{
    if (backpackInstanceId == 0 || contents == null) return false;

    var clone = new List<SavedItem>(contents.Count);
    for (int i = 0; i < contents.Count; i++)
    {
        // Результат индексатора не адресуем — для DeepClone(in ...) нужна
        // локальная переменная. Модификатор in на вызове опускаем: семантика
        // идентична (передаётся копия).
        SavedItem source = contents[i];
        clone.Add(SavedItem.DeepClone(source));
    }

    if (CommitContentsRecursive(_pocketsController, backpackInstanceId, clone)) return true;
    if (CommitContentsRecursive(_pocket2Controller, backpackInstanceId, clone)) return true;
    if (CommitContentsRecursive(_backpackController, backpackInstanceId, clone)) return true;
    if (CommitContentsRecursive(GetLiveLootController(), backpackInstanceId, clone)) return true;

    for (int i = 0; i < _openContainerWindows.Count; i++)
    {
        var w = _openContainerWindows[i];
        if (w == null || w.Controller == null) continue;
        if (CommitContentsRecursive(w.Controller, backpackInstanceId, clone)) return true;
    }

    // Equipment owns the backpack object directly, outside the grids. A closed
    // descendant can still exist only in that object's serialized contents.
    var equippedBackpack = _backpackSlot != null ? _backpackSlot.EquippedItem : null;
    if (equippedBackpack != null && equippedBackpack.Data != null && equippedBackpack.Data.IsBackpack
        && ReplaceContentsInList(equippedBackpack.GetBackpackSavedItems(), backpackInstanceId, clone))
        return true;
    return false;
}
        private bool CommitContentsRecursive(InventoryController ctrl, uint targetId, List<SavedItem> contentsClone)
        {
            if (ctrl == null || ctrl.IsDisposed) return false;
            for (int y = 0; y < ctrl.Height; y++)
            {
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var item = ctrl.GetItemAt(x, y);
                    if (item == null || !ctrl.IsRootCell(item.InstanceID, x, y)) continue;
                    if (item.Data == null || !item.Data.IsBackpack) continue;
                    if (item.InstanceID == targetId) continue; // живой объект сам владеет своими данными

                    var raw = item.GetBackpackSavedItems();
                    if (raw != null && ReplaceContentsInList(raw, targetId, contentsClone))
                    {
                        ctrl.RefreshItemInData(item);
                        return true;
                    }

                    K_ContainerWindow inner = null;
                    string innerId = item.InstanceID.ToString();
                    for (int i = 0; i < _openContainerWindows.Count; i++)
                    {
                        var w = _openContainerWindows[i];
                        if (w != null && w.Controller != null && w.BackpackInstanceID == innerId)
                        {
                            inner = w;
                            break;
                        }
                    }
                    if (inner != null && CommitContentsRecursive(inner.Controller, targetId, contentsClone))
                        return true;
                }
            }
            return false;
        }

        private static bool ReplaceContentsInList(List<SavedItem> list, uint targetId, List<SavedItem> contentsClone)
        {
            if (list == null) return false;
            for (int i = 0; i < list.Count; i++)
            {
                var node = list[i];
                if (node.InstanceID == targetId)
                {
                    node.BackpackContents = contentsClone;
                    list[i] = node;
                    return true;
                }
                if (node.BackpackContents != null &&
                    ReplaceContentsInList(node.BackpackContents, targetId, contentsClone))
                    return true;
            }
            return false;
        }
        
        // ═══════════════════════════════════════════════════════════
        //  PRIVATE METHODS
        // ═══════════════════════════════════════════════════════════

        public void SetupSurroundingsPanelHierarchy(int cols, int rows)
        {
            if (_surroundingsPanel == null || _surroundingsGrid == null) return;
            var panelRT = _surroundingsPanel.GetComponent<RectTransform>();
            var gridRT = _surroundingsGrid.GetComponent<RectTransform>();
            var oldVlg = panelRT.GetComponent<VerticalLayoutGroup>();
            if (oldVlg != null) UnityEngine.Object.DestroyImmediate(oldVlg);
            var oldCsf = panelRT.GetComponent<ContentSizeFitter>();
            if (oldCsf != null) UnityEngine.Object.DestroyImmediate(oldCsf);
            var oldHlg = panelRT.GetComponent<HorizontalLayoutGroup>();
            if (oldHlg != null) UnityEngine.Object.DestroyImmediate(oldHlg);
            var oldLep = panelRT.GetComponent<LayoutElement>();
            if (oldLep != null) UnityEngine.Object.DestroyImmediate(oldLep);
            var panelImg = panelRT.GetComponent<Image>();
            if (panelImg == null) panelImg = panelRT.gameObject.AddComponent<Image>();
            panelImg.raycastTarget = false;
            panelImg.color = new Color(0.15f, 0.16f, 0.18f, 0.95f);
            panelImg.maskable = true;
            Vector3[] gridCorners = new Vector3[4];
            gridRT.GetWorldCorners(gridCorners);
            Vector3 savedWorldTopLeft = gridCorners[1];
            if (gridRT.parent != panelRT)
                gridRT.SetParent(panelRT, false);
            Vector2 gridSize = ComputeGridSize(gridRT, cols, rows);
            float gridWidth = gridSize.x;
            float gridHeight = gridSize.y;
            float headerHeight = 0f;
            var dzTransform = panelRT.transform.Find("DragZone");
            if (dzTransform != null)
            {
                var dzRT = dzTransform as RectTransform;
                if (dzRT != null) headerHeight = dzRT.rect.height;
            }
            gridRT.anchorMin = new Vector2(0f, 1f);
            gridRT.anchorMax = new Vector2(0f, 1f);
            gridRT.pivot = new Vector2(0f, 1f);
            gridRT.sizeDelta = new Vector2(gridWidth, gridHeight);
            gridRT.anchoredPosition = new Vector2(0f, -headerHeight);
            var gridLe = gridRT.GetComponent<LayoutElement>();
            if (gridLe == null) gridLe = gridRT.gameObject.AddComponent<LayoutElement>();
            gridLe.ignoreLayout = true;
            LayoutRebuilder.ForceRebuildLayoutImmediate(gridRT);
            var gridImg = gridRT.GetComponent<Image>();
            if (gridImg == null) gridImg = gridRT.gameObject.AddComponent<Image>();
            gridImg.raycastTarget = true;
            gridImg.maskable = false;
            panelRT.anchorMin = new Vector2(0f, 1f);
            panelRT.anchorMax = new Vector2(0f, 1f);
            panelRT.pivot = new Vector2(0f, 1f);
            panelRT.sizeDelta = new Vector2(gridWidth, gridHeight + headerHeight);
            if (panelRT.parent != null)
            {
                Vector2 localTL = panelRT.parent.InverseTransformPoint(savedWorldTopLeft);
                RectTransform parentRT = panelRT.parent as RectTransform;
                if (parentRT != null)
                    localTL -= new Vector2(parentRT.rect.xMin, parentRT.rect.yMax);
                localTL += new Vector2(0f, headerHeight);
                panelRT.anchoredPosition = localTL;
            }
            if (_surroundingsItemsContainer != null)
            {
                if (_surroundingsItemsContainer.parent != gridRT)
                    _surroundingsItemsContainer.SetParent(gridRT, false);
                _surroundingsItemsContainer.SetAsLastSibling();
                var icLe = _surroundingsItemsContainer.GetComponent<LayoutElement>();
                if (icLe == null) icLe = _surroundingsItemsContainer.gameObject.AddComponent<LayoutElement>();
                icLe.ignoreLayout = true;
                var icGraphic = _surroundingsItemsContainer.GetComponent<Graphic>();
                if (icGraphic != null) icGraphic.raycastTarget = false;
            }
            gridRT.SetAsLastSibling();
            var drag = panelRT.GetComponent<K_DraggablePanel>();
            if (drag == null) drag = panelRT.gameObject.AddComponent<K_DraggablePanel>();
            drag.FindDragZone();
        }

        public void EnableDraggableSurroundingsPanel()
{
    if (_surroundingsPanel == null || _surroundingsGrid == null)
        return;

    try
    {
        var draggable = _surroundingsPanel.GetComponent<K_DraggablePanel>();

        if (draggable == null)
            draggable = _surroundingsPanel.gameObject.AddComponent<K_DraggablePanel>();

        draggable.ConfigureDragBehavior(false, true);

        draggable.SetDragZone(null);
        draggable.FindDragZone();
    }
    catch (System.Exception ex)
    {
        Debug.LogError($"[V13-DRAG] EnableDraggableSurroundingsPanel FAILED: {ex}");
    }
}

        public void DisableSurroundingsPanelDrag()
        {
            if (_surroundingsPanel == null && _surroundingsGrid == null) return;
            try { LinkSurroundingsHierarchy(); }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[LOOT] LinkSurroundingsHierarchy failed: {ex.Message}");
            }
            if (_surroundingsPanel != null)
            {
                var drag = _surroundingsPanel.GetComponent<K_DraggablePanel>();
                if (drag != null) UnityEngine.Object.DestroyImmediate(drag);
                string[] headerNames = { "DragZone", "Header", "Title", "TitleBar", "TopBar", "ContainerName" };
                foreach (var hName in headerNames)
                {
                    var hdr = _surroundingsPanel.transform.Find(hName);
                    if (hdr != null) UnityEngine.Object.DestroyImmediate(hdr.gameObject);
                }
                var panelImg = _surroundingsPanel.GetComponent<Image>();
                if (panelImg != null) panelImg.raycastTarget = false;
            }
            if (_surroundingsGrid != null)
            {
                var gridImg = _surroundingsGrid.GetComponent<Image>();
                if (gridImg != null) gridImg.raycastTarget = false;
                var gridDrag = _surroundingsGrid.GetComponent<K_DraggablePanel>();
                if (gridDrag != null) UnityEngine.Object.DestroyImmediate(gridDrag);
            }
        }

        public void LinkSurroundingsHierarchy()
        {
            if (_surroundingsPanel == null || _surroundingsGrid == null) return;
            var panelRT = _surroundingsPanel.GetComponent<RectTransform>();
            var gridRT = _surroundingsGrid.GetComponent<RectTransform>();
            if (panelRT == null || gridRT == null) return;
            Vector3[] gridCorners = new Vector3[4];
            gridRT.GetWorldCorners(gridCorners);
            Vector3 savedWorldTopLeft = gridCorners[1];
            Vector2 gridSize = ComputeGridSize(gridRT, _currentContainerCols, _currentContainerRows);
            if (gridSize.x <= 0f || gridSize.y <= 0f)
                gridSize = new Vector2(gridRT.rect.width, gridRT.rect.height);
            if (gridRT.parent != panelRT)
                gridRT.SetParent(panelRT, false);
            gridRT.anchorMin = new Vector2(0f, 1f);
            gridRT.anchorMax = new Vector2(0f, 1f);
            gridRT.pivot = new Vector2(0f, 1f);
            gridRT.anchoredPosition = Vector2.zero;
            gridRT.sizeDelta = gridSize;
            gridRT.localScale = Vector3.one;
            var gridLe = gridRT.GetComponent<LayoutElement>();
            if (gridLe == null) gridLe = gridRT.gameObject.AddComponent<LayoutElement>();
            gridLe.ignoreLayout = true;
            gridRT.SetAsLastSibling();
            if (_surroundingsItemsContainer != null)
            {
                var itemsRT = _surroundingsItemsContainer.GetComponent<RectTransform>();
                if (itemsRT != null)
                {
                    if (_surroundingsItemsContainer.parent != gridRT)
                        _surroundingsItemsContainer.SetParent(gridRT, false);
                    _surroundingsItemsContainer.SetAsLastSibling();
                    itemsRT.anchorMin = new Vector2(0f, 1f);
                    itemsRT.anchorMax = new Vector2(0f, 1f);
                    itemsRT.pivot = new Vector2(0f, 1f);
                    itemsRT.anchoredPosition = Vector2.zero;
                    itemsRT.sizeDelta = gridSize;
                    itemsRT.localScale = Vector3.one;
                    var icLe = itemsRT.GetComponent<LayoutElement>();
                    if (icLe == null) icLe = itemsRT.gameObject.AddComponent<LayoutElement>();
                    icLe.ignoreLayout = true;
                    var icGraphic = _surroundingsItemsContainer.GetComponent<Graphic>();
                    if (icGraphic != null) icGraphic.raycastTarget = false;
                }
            }
            panelRT.anchorMin = new Vector2(0f, 1f);
            panelRT.anchorMax = new Vector2(0f, 1f);
            panelRT.pivot = new Vector2(0f, 1f);
            panelRT.sizeDelta = gridSize;
            panelRT.localScale = Vector3.one;
            if (panelRT.parent != null)
            {
                Vector2 localTL = panelRT.parent.InverseTransformPoint(savedWorldTopLeft);
                RectTransform parentRT = panelRT.parent as RectTransform;
                if (parentRT != null)
                    localTL -= new Vector2(parentRT.rect.xMin, parentRT.rect.yMax);
                panelRT.anchoredPosition = localTL;
            }
        }

        public void AlignPanelToGridExact()
        {
            if (_surroundingsPanel == null || _surroundingsGrid == null) return;
            var panelRT = _surroundingsPanel.GetComponent<RectTransform>();
            var gridRT = _surroundingsGrid.GetComponent<RectTransform>();
            if (panelRT == null || gridRT == null) return;
            InventoryUiGeometry.AlignPanelToGrid(panelRT, gridRT);
            var gridLe = gridRT.GetComponent<LayoutElement>();
            if (gridLe == null) gridLe = gridRT.gameObject.AddComponent<LayoutElement>();
            gridLe.ignoreLayout = true;
            gridRT.SetAsLastSibling();
            if (_surroundingsItemsContainer != null)
            {
                if (_surroundingsItemsContainer.parent != gridRT)
                    _surroundingsItemsContainer.SetParent(gridRT, false);
                _surroundingsItemsContainer.SetAsLastSibling();
                var icLe = _surroundingsItemsContainer.GetComponent<LayoutElement>();
                if (icLe == null) icLe = _surroundingsItemsContainer.gameObject.AddComponent<LayoutElement>();
                icLe.ignoreLayout = true;
                var icGraphic = _surroundingsItemsContainer.GetComponent<Graphic>();
                if (icGraphic != null) icGraphic.raycastTarget = false;
            }
        }

        public void DetachGridFromPanel() { }

        public void DetachPanelAsFloatingWindow()
        {
            if (_surroundingsPanel == null) return;
            var panelRect = _surroundingsPanel.GetComponent<RectTransform>();
            if (panelRect == null) return;
            Canvas rootCanvas = null;
            var c = _surroundingsPanel.GetComponentInParent<Canvas>();
            while (c != null)
            {
                if (c.transform.parent == null || c.transform.parent.GetComponent<Canvas>() == null)
                {
                    rootCanvas = c;
                    break;
                }
                c = c.transform.parent.GetComponent<Canvas>();
            }
            if (rootCanvas == null) return;
            if (panelRect.parent != rootCanvas.transform)
                panelRect.SetParent(rootCanvas.transform, false);
            panelRect.anchorMin = new Vector2(0.5f, 0.5f);
            panelRect.anchorMax = new Vector2(0.5f, 0.5f);
            panelRect.pivot = new Vector2(0.5f, 0.5f);
            panelRect.anchoredPosition = Vector2.zero;
        }

        public void SyncDraggablePanelHeaderSettings(K_DraggablePanel draggable)
        {
            if (draggable == null) return;
            draggable.ConfigureHeader(_containerHeaderPrefab, _containerHeaderHeight, _containerHeaderColor);
        }

        public void SetContainerHeaderText(K_DraggablePanel draggable, string text)
        {
            if (draggable == null) return;
            var dragZone = draggable.transform.Find("DragZone");
            if (dragZone == null) return;
            var tmp = dragZone.GetComponentInChildren<TMPro.TextMeshProUGUI>();
            if (tmp != null) tmp.text = text;
        }

        public void NotifyPanelDragStarted() { }
        public void NotifyPanelDragEnded() { }

        public void EnsureDragZoneExists()
        {
            if (_surroundingsPanel == null) return;
            if (_surroundingsPanel.transform.Find("DragZone") != null) return;
            float h = _containerHeaderHeight > 0f ? _containerHeaderHeight : 30f;
            var dzObj = new GameObject("DragZone", typeof(RectTransform), typeof(Image));
            dzObj.transform.SetParent(_surroundingsPanel.transform, false);
            dzObj.transform.SetAsFirstSibling();
            var dzRT = dzObj.GetComponent<RectTransform>();
            dzRT.anchorMin = new Vector2(0f, 1f);
            dzRT.anchorMax = new Vector2(1f, 1f);
            dzRT.pivot = new Vector2(0.5f, 1f);
            dzRT.anchoredPosition = Vector2.zero;
            dzRT.sizeDelta = new Vector2(0f, h);
            dzRT.localScale = Vector3.one;
            dzObj.AddComponent<LayoutElement>().ignoreLayout = true;
            var dzImg = dzObj.GetComponent<Image>();
            dzImg.color = new Color(0.24f, 0.26f, 0.30f, 0.98f);
            dzImg.raycastTarget = true;
            var lineObj = new GameObject("HeaderBottomLine", typeof(RectTransform), typeof(Image));
            lineObj.transform.SetParent(dzObj.transform, false);
            var lineRT = lineObj.GetComponent<RectTransform>();
            lineRT.anchorMin = new Vector2(0f, 0f);
            lineRT.anchorMax = new Vector2(1f, 0f);
            lineRT.pivot = new Vector2(0.5f, 0f);
            lineRT.anchoredPosition = Vector2.zero;
            lineRT.sizeDelta = new Vector2(0f, 1f);
            lineRT.localScale = Vector3.one;
            var lineImg = lineObj.GetComponent<Image>();
            lineImg.color = new Color(0.45f, 0.47f, 0.52f, 1f);
            lineImg.raycastTarget = false;
            if (_containerNameText != null)
            {
                var nameObj = new GameObject("WindowTitle", typeof(RectTransform));
                nameObj.transform.SetParent(dzObj.transform, false);
                var nameRT = nameObj.GetComponent<RectTransform>();
                nameRT.anchorMin = Vector2.zero;
                nameRT.anchorMax = Vector2.one;
                nameRT.pivot = new Vector2(0.5f, 0.5f);
                nameRT.offsetMin = new Vector2(8f, 0f);
                nameRT.offsetMax = new Vector2(-8f, 0f);
                nameRT.localScale = Vector3.one;
                var nameText = nameObj.AddComponent<TMPro.TextMeshProUGUI>();
                nameText.text = _containerNameText.text;
                nameText.alignment = TMPro.TextAlignmentOptions.Center;
                nameText.verticalAlignment = TMPro.VerticalAlignmentOptions.Middle;
                nameText.fontSize = 14f;
                nameText.fontStyle = TMPro.FontStyles.Bold;
                nameText.color = new Color(0.92f, 0.92f, 0.95f, 1f);
                nameText.raycastTarget = false;
                nameText.overflowMode = TMPro.TextOverflowModes.Truncate;
                nameText.textWrappingMode = TMPro.TextWrappingModes.NoWrap;
            }
        }

        private Vector2 ComputeGridSize(RectTransform gridRT, int cols, int rows)
        {
            if (gridRT == null || cols <= 0 || rows <= 0)
                return new Vector2(_slotSize * cols, _slotSize * rows);
            var gridLayout = gridRT.GetComponent<GridLayoutGroup>();
            if (gridLayout != null)
            {
                float cellW = gridLayout.cellSize.x;
                float cellH = gridLayout.cellSize.y;
                float spaceX = gridLayout.spacing.x;
                float spaceY = gridLayout.spacing.y;
                float w = gridLayout.padding.left + cols * cellW + Mathf.Max(0, cols - 1) * spaceX + gridLayout.padding.right;
                float h = gridLayout.padding.top + rows * cellH + Mathf.Max(0, rows - 1) * spaceY + gridLayout.padding.bottom;
                return new Vector2(w, h);
            }
            float width = cols * _slotSize + Mathf.Max(0, cols - 1) * _slotSpacing;
            float height = rows * _slotSize + Mathf.Max(0, rows - 1) * _slotSpacing;
            return new Vector2(width, height);
        }


    private K_ContainerWindow CreateContainerWindow(
    InventoryController controller, string instanceID, string displayName, int w, int h)
{
    if (_floatingWindowsRoot == null || _slotPrefab == null)
    {
        Debug.LogError("[MULTI-WIN] Cannot create window: missing root or slotPrefab");
        return null;
    }
    // Поднимаем весь слой окон: панель подбора могла оказаться выше него.
    _floatingWindowsRoot.SetAsLastSibling();
    var windowObj = new GameObject($"Window_{instanceID}", typeof(RectTransform));
    windowObj.transform.SetParent(_floatingWindowsRoot, false);
    windowObj.transform.SetAsLastSibling();
    var window = windowObj.AddComponent<K_ContainerWindow>();
    float headerH = _containerHeaderPrefab != null ? _containerHeaderHeight : 32f;
    Vector2 position = GetNextWindowPosition();
    window.Initialize(
        controller, instanceID, w, h,
        _slotPrefab, _slotSize, _slotSpacing,
        _containerHeaderColor, headerH,
        _inventoryUI,
        null,
        displayName,
        _containerWindowFillColor,
        _containerWindowBorderColor,
        _containerWindowBorderThickness
    );
    window.SetPosition(position);
    _styleWindowHeader?.Invoke(window);   // теперь no-op, сохраняем вызов
    window.OnWindowFocused += OnContainerWindowFocused;
    _openContainerWindows.Add(window);
    return window;
}
        private void ActivateContainerWindow(K_ContainerWindow window)
        {
            if (window == null) return;
            if (_activeContainerWindow != null && _activeContainerWindow != window)
                DeactivateContainerWindow(_activeContainerWindow);
            _activeContainerWindow = window;
            _activeContainerWindow.IsActive = true;
            _activeContainerWindow.SetInteractable(true);
            bool isLooting = _isLootingContainer?.Invoke() ?? false;
            if (!isLooting)
            {
                _surroundingsPanel = window.PanelRect;
                _surroundingsGrid = window.GridRect;
                _surroundingsItemsContainer = window.ItemsContainer;
                _unsubscribeFromContainerEvents?.Invoke();
                _activeContainerController = window.Controller;
                _subscribeToContainerEvents?.Invoke();
                _currentContainerCols = window.GridWidth;
                _currentContainerRows = window.GridHeight;
            }
            if (_containerNameText != null && window.Controller != null)
                _containerNameText.text = "";
            _forceRefresh?.Invoke();
            _setAllGridSlotsRaycast?.Invoke(false);
        }

        private void DeactivateContainerWindow(K_ContainerWindow window)
        {
            if (window == null) return;
            window.IsActive = true;
        }

 // ═══════════════════════════════════════════════════════════
//  ИСПРАВЛЕННЫЙ DestroyContainerWindow: pre-pass flush + leaf-first destruction
//  ГАРАНТИРУЕТ: все контроллеры замыкания синхронизированы ДО начала уничтожения.
// ═══════════════════════════════════════════════════════════
private void DestroyContainerWindow(K_ContainerWindow window)
{
    if (InventoryAtomicJournal.DeferLifecycle(() => DestroyContainerWindow(window))) return;
    if (window == null) return;
    var closure = CollectClosure(window);
    if (closure.Count == 0) return;

    // ═══ PRE-PASS: синхронизируем ВСЕ контроллеры замыкания ДО уничтожения.
    // Это гарантирует, что данные каждого окна актуальны в его InventoryItem
    // до того, как мы начнём удалять окна. Без этого промежуточные коммиты
    // могут потерять данные, если родительский контроллер ещё не синхронизирован.
    // ═══
    for (int i = 0; i < closure.Count; i++)
    {
        var w = closure[i];
        if (w == null || w.Controller == null || w.Controller.IsDisposed) continue;
        w.Controller.RefreshAllItemsInData();
    }

    // ═══ LEAF-FIRST DESTRUCTION ═══
    while (closure.Count > 0)
    {
        K_ContainerWindow leaf = null;
        foreach (var w in closure)
        {
            bool isAncestor = false;
            if (w.Controller != null && !w.Controller.IsDisposed)
            {
                foreach (var o in closure)
                {
                    if (o == w) continue;
                    if (uint.TryParse(o.BackpackInstanceID, out uint oid) &&
                        ContainsItemRecursive(w.Controller, oid))
                    {
                        isAncestor = true;
                        break;
                    }
                }
            }
            if (!isAncestor) { leaf = w; break; }
        }
        if (leaf == null) leaf = closure[closure.Count - 1];
        closure.Remove(leaf);
        DestroyWindowCore(leaf);
    }
}
private void DestroyWindowCore(K_ContainerWindow window)
{
    if (window == null || !_openContainerWindows.Contains(window)) return;

    _inventoryUI?.CleanupWindowItems(window.BackpackInstanceID);

    if (window.Controller != null
        && _openedBackpacks.TryGetValue(window.BackpackInstanceID, out var liveCtrl))
    {
        var owner = FindBackpackItemByID(window.BackpackInstanceID);

  if (owner != null)
{
    var parentController = FindControllerForClosingOwner(owner);

    window.Controller.RefreshAllItemsInData();
    var savedItemsReadOnly = window.Controller.GetSaveData()?.GetItems();

    // GetItems() returns IReadOnlyList<SavedItem>; ContainsInstanceId
    // (и логика copy-below) работают с List<SavedItem>. Делаем одну
    // копию здесь — она же уходит в ReplaceBackpackContents.
    List<SavedItem> items = savedItemsReadOnly != null
        ? new List<SavedItem>(savedItemsReadOnly)
        : null;

    // ═══════════════════════════════════════════════════════════
    //  FAIL-SAFE: self-cycle guard.
    // ═══════════════════════════════════════════════════════════
    if (items != null && SavedItem.ContainsInstanceId(items, owner.InstanceID))
    {
        Debug.LogError(
            $"[Backpacks] SELF-CYCLE FAIL-SAFE: owner {owner.InstanceID} " +
            $"('{owner.Data?.DisplayName}') appears in its own contents while " +
            $"destroying window {window.BackpackInstanceID}. " +
            "This should have been blocked by transaction pre-check. " +
            "Un-cycling: offending items are NOT committed to owner; " +
            "attempting fallback placement into player grids.");

        var cleanItems = new List<SavedItem>(items.Count);
        var db = K_InventorySetup.DatabaseInstance;

        for (int i = 0; i < items.Count; i++)
        {
            var s = items[i];
            bool cyclic = s.InstanceID == owner.InstanceID
                || SavedItem.ContainsInstanceId(s.BackpackContents, owner.InstanceID);
            if (!cyclic) { cleanItems.Add(s); continue; }

            // Best-effort: восстановить в player grids.
            var template = db != null ? db.GetItemData(s.ItemID) : null;
            var live = template != null ? InventoryItem.FromSaveData(s, template) : null;
            bool placed = false;
            if (live != null)
            {
                var grids = new[] { _pocketsController, _pocket2Controller, _backpackController };
                foreach (var ctrl in grids)
                {
                    if (ctrl == null) continue;
                    if (ctrl.PlaceExistingItemInFirstFreeSlot(live)) { placed = true; break; }
                }
            }

            if (placed)
            {
                Debug.LogWarning(
                    $"[Backpacks] FAIL-SAFE: self-cycle item {s.InstanceID} " +
                    $"('{s.ItemID}') restored into player grid.");
            }
            else
            {
                Debug.LogError(
                    $"[Backpacks] FAIL-SAFE: could not restore self-cycle item " +
                    $"{s.InstanceID} ('{s.ItemID}') into any player grid. Item is LOST.");
            }
        }
        items = cleanItems;
    }

    if (items != null)
        owner.ReplaceBackpackContents(items);
    owner.ClearBackpackController();

    // The equipment slot already owns the exact object updated above, so
    // OnBackpackEquipped can import it before this live controller is disposed.
    // A reconstructed serialized owner must instead be written back into its
    // reachable parent; changing only that temporary object would lose edits.
    if (parentController != null && parentController != window.Controller)
    {
        if (!parentController.RefreshItemInData(owner))
            Debug.LogError(
                $"[Backpacks] Не удалось закоммитить '{owner.Data?.DisplayName}' " +
                $"в родительский контроллер при закрытии окна {window.BackpackInstanceID}.");
    }
    else if (parentController == null
        && !(_backpackSlot != null && ReferenceEquals(_backpackSlot.EquippedItem, owner))
        && !CommitBackpackContentsIntoChain(owner.InstanceID, owner.GetBackpackSavedItems()))
    {
        Debug.LogError(
            $"[Backpacks] Владелец '{owner.Data?.DisplayName}' не лежит ни в одном " +
            $"живом контроллере — содержимое сохранено только в предмете.");
    }
}
        else
        {
            var orphanItems = window.Controller.GetSaveData()?.GetItems();
            if (orphanItems != null && uint.TryParse(window.BackpackInstanceID, out uint orphanId))
            {
                if (CommitBackpackContentsIntoChain(orphanId, orphanItems))
                {
                    Debug.LogWarning(
                        $"[Backpacks] Окно {window.BackpackInstanceID}: живой владелец " +
                        $"недостижим — содержимое закоммичено в serialized-цепочку.");
                }
                else
                {
                    var restoredOwner = FindBackpackItemByID(window.BackpackInstanceID);
                    if (restoredOwner != null)
                    {
                        restoredOwner.ReplaceBackpackContents(orphanItems);

                        var parentCtrl = FindControllerForClosingOwner(restoredOwner);

                        if (parentCtrl != null)
                            parentCtrl.RefreshItemInData(restoredOwner);
                        else
                            CommitBackpackContentsIntoChain(
                                restoredOwner.InstanceID,
                                restoredOwner.GetBackpackSavedItems());

                        Debug.LogWarning(
                            $"[Backpacks] Окно {window.BackpackInstanceID}: " +
                            $"владелец восстановлен из serialized-данных.");
                    }
                    else
                    {
                        Debug.LogError(
                            $"[Backpacks] Живой предмет-владелец для окна " +
                            $"{window.BackpackInstanceID} не найден — состояние контроллера утрачено.");
                    }
                }
            }
        }

        _openedBackpacks.Remove(window.BackpackInstanceID);
        liveCtrl.Dispose();
    }

    window.OnWindowFocused -= OnContainerWindowFocused;
    _openContainerWindows.Remove(window);

    if (_activeContainerWindow == window)
    {
        _activeContainerWindow = null;
        _activeContainerController = null;
        _currentContainerCols = 0;
        _currentContainerRows = 0;
        _surroundingsPanel = _originalSurroundingsPanel;
        _surroundingsGrid = _originalSurroundingsGrid;
        _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
    }

    UnityEngine.Object.Destroy(window.gameObject);
}
private InventoryController FindControllerForClosingOwner(InventoryItem owner)
{
    if (_inventoryUI != null) return _inventoryUI.FindControllerForItem(owner);
    if (owner == null) return null;
    var roots = new[] { _pocketsController, _pocket2Controller, _backpackController, GetLiveLootController() };
    foreach (var controller in roots)
        if (controller != null && !controller.IsDisposed
            && ReferenceEquals(controller.GetItemByInstanceID(owner.InstanceID), owner)) return controller;
    foreach (var controller in _openedBackpacks.Values)
        if (controller != null && !controller.IsDisposed
            && ReferenceEquals(controller.GetItemByInstanceID(owner.InstanceID), owner)) return controller;
    return null;
}

private List<K_ContainerWindow> CollectClosure(K_ContainerWindow root)
{
    _closeBuffer.Clear();
    if (root == null || !_openContainerWindows.Contains(root)) return _closeBuffer;
    _closeBuffer.Add(root);

    bool added = true;
    int guard = 0;
    while (added && guard++ < 16)
    {
        added = false;
        foreach (var w in _openContainerWindows)
        {
            if (w == null || _closeBuffer.Contains(w)) continue;
            if (!uint.TryParse(w.BackpackInstanceID, out uint wid)) continue;
            foreach (var known in _closeBuffer)
            {
                bool inside = false;
                if (known.Controller != null)
                    inside = ContainsItemRecursive(known.Controller, wid);
                if (!inside)
                    inside = OwnerItemContainsTransitive(known.BackpackInstanceID, wid);
                if (inside)
                {
                    _closeBuffer.Add(w);
                    added = true;
                    break;
                }
            }
        }
    }
    return _closeBuffer;
}

private bool OwnerItemContainsTransitive(string ownerInstanceId, uint candidateId)
{
    var owner = FindBackpackItemByID(ownerInstanceId);
    return owner != null && owner.ContainsDescendant(candidateId);
}

private bool DeferAtomicSubtreeClose(InventoryController controller)
{
    if (!InventoryAtomicJournal.IsActive) return false;
    if (controller == null) return true;
    foreach (var window in _openContainerWindows)
    {
        if (window == null || !uint.TryParse(window.BackpackInstanceID, out uint id)
            || !ContainsItemRecursive(controller, id)) continue;
        string instanceId = window.BackpackInstanceID;
        InventoryAtomicJournal.DeferLifecycle(() => CloseSpecificBackpackWindow(instanceId));
    }
    return true;
}

public void CloseWindowsInsideSubtree(InventoryController controller)
{
    if (DeferAtomicSubtreeClose(controller)) return;
    if (controller == null) return;

    _reentryBuffer.Clear();
    for (int i = 0; i < _openContainerWindows.Count; i++)
        if (_openContainerWindows[i] != null)
            _reentryBuffer.Add(_openContainerWindows[i]);

    for (int i = _reentryBuffer.Count - 1; i >= 0; i--)
    {
        var w = _reentryBuffer[i];
        if (w == null || !_openContainerWindows.Contains(w)) continue;
        if (!uint.TryParse(w.BackpackInstanceID, out uint wid)) continue;
        if (ContainsItemRecursive(controller, wid))
            DestroyContainerWindow(w);
    }
    _reentryBuffer.Clear();
}

/// <summary>
/// ЕДИНСТВЕННАЯ точка защиты от сирот: перед очисткой/перезаписью контроллера
/// контейнера все открытые окна его поддерева (транзитивно) закрываются.
/// Вызывается из OnBackpackEquipped/OnBackpackUnequipped и fold экипированного.
/// </summary>

private List<K_ContainerWindow> CollectClosureBottomUp(K_ContainerWindow root)
{
    _closeBuffer.Clear();
    if (root == null || !_openContainerWindows.Contains(root)) return _closeBuffer;
    _closeBuffer.Add(root);

    bool added = true;
    int guard = 0;
    while (added && guard++ < 32)
    {
        added = false;
        foreach (var w in _openContainerWindows)
        {
            if (w == null || _closeBuffer.Contains(w)) continue;
            foreach (var known in _closeBuffer)
            {
                if (known.Controller != null &&
                    IsControllerContainingBackpack(known.Controller, w.BackpackInstanceID))
                {
                    _closeBuffer.Add(w);
                    added = true;
                    break;
                }
            }
        }
    }

    _closeBuffer.Sort((a, b) => ComputeWindowDepth(b).CompareTo(ComputeWindowDepth(a)));
    return _closeBuffer;
}

private K_ContainerWindow FindParentWindow(K_ContainerWindow window)
{
    foreach (var w in _openContainerWindows)
    {
        if (w == null || w == window) continue;
        if (w.Controller != null &&
            IsControllerContainingBackpack(w.Controller, window.BackpackInstanceID))
            return w;
    }
    return null;
}

private int ComputeWindowDepth(K_ContainerWindow window)
{
    int depth = 0;
    var cur = window;
    for (int guard = 0; guard < 16; guard++)
    {
        var parent = FindParentWindow(cur);
        if (parent == null) return depth;
        depth++;
        cur = parent;
    }
    return depth;
}

/// <summary>Уничтожает ОДНО окно. Порядок обеспечивает CollectClosureBottomUp.</summary>

        public void CloseSpecificBackpackWindow(string instanceID)
        {
    if (InventoryAtomicJournal.DeferLifecycle(() => CloseSpecificBackpackWindow(instanceID))) return;
            var window = _openContainerWindows.Find(w => w != null && w.BackpackInstanceID == instanceID);
            if (window != null)
            {
                if (_activeContainerWindow == window)
                {
                    _activeContainerWindow = null;
                    bool isLooting = _isLootingContainer?.Invoke() ?? false;
                    if (!isLooting)
                    {
                        _activeContainerController = null;
                        _currentContainerCols = 0;
                        _currentContainerRows = 0;
                    }
                    _surroundingsPanel = _originalSurroundingsPanel;
                    _surroundingsGrid = _originalSurroundingsGrid;
                    _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
                    if (_openContainerWindows.Count > 1)
                    {
                        var nextWindow = _openContainerWindows.Find(
                            w => w != null && w != window
                            && !IsControllerContainingBackpack(window.Controller, w.BackpackInstanceID));
                        if (nextWindow != null)
                        {
                            ActivateContainerWindow(nextWindow);
                            var found = FindBackpackItemByID(nextWindow.BackpackInstanceID);
                            if (found == null && _backpackSlot != null
                                && _backpackSlot.EquippedItem != null
                                && _backpackSlot.EquippedItem.InstanceID.ToString() == nextWindow.BackpackInstanceID)
                            {
                                found = _backpackSlot.EquippedItem;
                            }
                            _activeBackpackContainer = found;
                        }
                    }
                }
                DestroyContainerWindow(window);
            }
            bool wasLooting = _isLootingContainer?.Invoke() ?? false;
            _unsubscribeFromContainerEvents?.Invoke();
            if (_activeBackpackContainer != null &&
                _activeBackpackContainer.InstanceID.ToString() == instanceID)
            {
                _activeBackpackContainer = null;
            }
            if (_activeContainerWindow != null)
            {
                bool isLooting = _isLootingContainer?.Invoke() ?? false;
                if (!isLooting)
                    _activeContainerController = _activeContainerWindow.Controller;
                _subscribeToContainerEvents?.Invoke();
            }
            else if (wasLooting)
            {
                _restoreLootControllerIfLooting?.Invoke();
                _subscribeToContainerEvents?.Invoke();
            }
            bool isLootingFinal = _isLootingContainer?.Invoke() ?? false;
            if (isLootingFinal)
            {
                _activeContainerController = GetLiveLootController();
                if (_activeContainerController != null)
                {
                    _currentContainerCols = _activeContainerController.Width;
                    _currentContainerRows = _activeContainerController.Height;
                }
            }
            _forceRefresh?.Invoke();
        }

    public InventoryItem FindBackpackItemByID(string instanceID)
{
    if (string.IsNullOrEmpty(instanceID)) return null;
    if (!uint.TryParse(instanceID, out uint id)) return null;
    var registeredItem = InventoryOwnershipRegistry.FindLiveItem(id);
    if (registeredItem != null) return registeredItem;

    // 1. Корневые контроллеры
    var roots = new[] { _pocketsController, _pocket2Controller, _backpackController };
    foreach (var ctrl in roots)
    {
        var found = FindLiveItemRecursive(ctrl, id);
        if (found != null) return found;
    }

    // 2. Экипированный рюкзак
    if (_backpackSlot != null && _backpackSlot.EquippedItem != null &&
        _backpackSlot.EquippedItem.InstanceID == id)
        return _backpackSlot.EquippedItem;

    // 3. Лут-контроллер
    bool isLooting = _isLootingContainer?.Invoke() ?? false;
    if (isLooting)
    {
        var lootCtrl = GetLiveLootController();
        var found = FindLiveItemRecursive(lootCtrl, id);
        if (found != null) return found;
    }

    // 4. Открытые окна
    foreach (var window in _openContainerWindows)
    {
        if (window == null || window.Controller == null) continue;
        var found = FindLiveItemRecursive(window.Controller, id);
        if (found != null) return found;
    }

    // 5. Сериализованные данные рюкзаков в корневых контроллерах и открытых окнах.
    //    Ищем живой InventoryItem, который содержит искомый InstanceID в своих
    //    _backpackContentsSerialized. Это покрывает случай, когда владелец лежит
    //    в закрытом окне (его живой объект недоступен, но он может быть
    //    восстановлен из сериализованных данных родителя).
    var allControllers = new List<InventoryController>();
    foreach (var ctrl in roots)
        if (ctrl != null) allControllers.Add(ctrl);
    if (isLooting)
    {
        var lootCtrl = GetLiveLootController();
        if (lootCtrl != null) allControllers.Add(lootCtrl);
    }
    foreach (var window in _openContainerWindows)
        if (window != null && window.Controller != null)
            allControllers.Add(window.Controller);

    foreach (var ctrl in allControllers)
    {
        var result = FindItemInSerializedTree(ctrl, id);
        if (result != null) return result;
    }

    var equippedBackpack = _backpackSlot != null ? _backpackSlot.EquippedItem : null;
    if (equippedBackpack != null)
    {
        var result = FindItemInSavedList(equippedBackpack.GetBackpackSavedItems(), id);
        if (result != null) return result;
    }

    return null;
}

/// <summary>
/// Рекурсивно ищет живой InventoryItem с данным InstanceID в сериализованных
/// данных рюкзаков внутри контроллера. Восстанавливает предмет из SavedItem
/// если живой объект не найден.
/// </summary>
private InventoryItem FindItemInSerializedTree(InventoryController ctrl, uint targetId)
{
    if (ctrl == null) return null;
    for (int y = 0; y < ctrl.Height; y++)
    {
        for (int x = 0; x < ctrl.Width; x++)
        {
            var item = ctrl.GetItemAt(x, y);
            if (item == null || item.Data == null || !item.Data.IsBackpack) continue;
            if (!ctrl.IsRootCell(item.InstanceID, x, y)) continue;

            var contents = item.GetBackpackSavedItems();
            if (contents == null) continue;

            var result = FindItemInSavedList(contents, targetId);
            if (result != null) return result;
        }
    }
    return null;
}

private InventoryItem FindItemInSavedList(List<SavedItem> contents, uint targetId)
{
    if (contents == null) return null;
    foreach (var saved in contents)
    {
        if (saved.InstanceID == targetId)
        {
            // Восстанавливаем живой объект из SavedItem
            var template = K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID);
            if (template == null) return null;
            return InventoryItem.FromSaveData(saved, template);
        }
        if (saved.BackpackContents != null && saved.BackpackContents.Count > 0)
        {
            var found = FindItemInSavedList(saved.BackpackContents, targetId);
            if (found != null) return found;
        }
    }
    return null;
}
  private InventoryItem FindLiveItemRecursive(InventoryController ctrl, uint targetId)
        {
            if (ctrl == null) return null;
            for (int y = 0; y < ctrl.Height; y++)
            {
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var item = ctrl.GetItemAt(x, y);
                    if (item == null) continue;
                    if (item.InstanceID == targetId) return item;
                    if (item.Data != null && item.Data.IsBackpack)
                    {
                        string itemIdStr = item.InstanceID.ToString();
                        var innerWindow = _openContainerWindows.Find(w => w != null && w.BackpackInstanceID == itemIdStr);
                        if (innerWindow != null && innerWindow.Controller != null)
                        {
                            var found = FindLiveItemRecursive(innerWindow.Controller, targetId);
                            if (found != null) return found;
                        }
                    }
                }
            }
            return null;
        }
        
       
        private K_ContainerWindow FindOpenWindowContainingItem(InventoryItem item)
        {
            if (item == null) return null;
            uint id = item.InstanceID;
            for (int i = 0; i < _openContainerWindows.Count; i++)
            {
                var w = _openContainerWindows[i];
                if (w == null || w.Controller == null) continue;
                var c = w.Controller;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var it = c.GetItemAt(x, y);
                        if (it != null && it.InstanceID == id) return w;
                    }
            }
            return null;
        }
        /// <summary>
/// Вызывается из K_InventoryUI.Start() после инициализации контроллеров.
/// В Awake() контроллеры ещё не существуют — передаются как null.
/// </summary>
public void SetPlayerControllers(
    InventoryController pockets,
    InventoryController pocket2,
    InventoryController backpack)
{
    _pocketsController = pockets;
    _pocket2Controller = pocket2;
    _backpackController = backpack;
}

        private void OnContainerWindowFocused(K_ContainerWindow window) { }

        private Vector2 GetNextWindowPosition()
        {
            if (_originalSurroundingsGrid != null)
            {
                var gridRT = _originalSurroundingsGrid.GetComponent<RectTransform>();
                if (gridRT != null)
                {
                    Vector3[] corners = new Vector3[4];
                    gridRT.GetWorldCorners(corners);
                    Vector2 worldTL = _floatingWindowsRoot.InverseTransformPoint(corners[1]);
                    RectTransform parentRT = _floatingWindowsRoot as RectTransform;
                    if (parentRT != null)
                        worldTL -= new Vector2(parentRT.rect.xMin, parentRT.rect.yMax);
                    int offset = _openContainerWindows.Count;
                    return worldTL + new Vector2(offset * 30f, -offset * 30f);
                }
            }
            int idx = _openContainerWindows.Count;
            return new Vector2(300f + idx * 30f, -100f - idx * 30f);
        }
    }
}
