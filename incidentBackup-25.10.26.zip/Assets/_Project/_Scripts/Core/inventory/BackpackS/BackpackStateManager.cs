using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public sealed class BackpackStateManager
    {
        public delegate void RefreshDelegate();
        public delegate void ClearGridDelegate(Transform grid, Transform preserveChild);
        public delegate void RebuildBackpackGridDelegate(int width, int height);
        public delegate void StopCoroutineDelegate(UnityEngine.Coroutine coroutine);
        public delegate bool TryPlaceInAnyPlayerGridDelegate(InventoryItem item);
        public delegate (GridType? grid, int x, int y) FindItemLocationDelegate(InventoryItem item);
        public delegate InventoryController FindControllerForItemDelegate(InventoryItem item);
        public delegate InventoryController GetControllerForGridDelegate(GridType gridType);
        public delegate (int width, int height) GetEffectiveGridSizeDelegate(GridType gridType, InventoryController controller);

        private RefreshDelegate _forceRefresh;
        private ClearGridDelegate _clearGrid;
        private RebuildBackpackGridDelegate _rebuildBackpackGrid;
        private StopCoroutineDelegate _stopCoroutine;
        private TryPlaceInAnyPlayerGridDelegate _tryPlaceInAnyPlayerGrid;
        private FindItemLocationDelegate _findItemLocation;
        private FindControllerForItemDelegate _findControllerForItem;
        private GetControllerForGridDelegate _getControllerForGrid;
        private GetEffectiveGridSizeDelegate _getEffectiveGridSize;

        private K_EquipmentSlotUI _backpackSlot;
        private BackpackContainerManager _backpackManager;

        private bool _isDragging;
        private bool _dragItemRemoved;
        private UI_Item _draggedItem;
        private int _dragOriginX, _dragOriginY;
        private GridType _dragOriginGridType;

        public delegate void CancelDragDelegate();
        private CancelDragDelegate _cancelDrag;

        public BackpackStateManager() { }

        public void Initialize(
            InventoryController backpackController, // Оставлены для совместимости, но не используются
            InventoryController pocketsController,
            InventoryController pocket2Controller,
            K_EquipmentSlotUI backpackSlot,
            BackpackContainerManager backpackManager,
            RefreshDelegate forceRefresh,
            ClearGridDelegate clearGrid,
            RebuildBackpackGridDelegate rebuildBackpackGrid,
            StopCoroutineDelegate stopCoroutine,
            TryPlaceInAnyPlayerGridDelegate tryPlaceInAnyPlayerGrid,
            FindItemLocationDelegate findItemLocation,
            FindControllerForItemDelegate findControllerForItem,
            GetControllerForGridDelegate getControllerForGrid,
            GetEffectiveGridSizeDelegate getEffectiveGridSize,
            CancelDragDelegate cancelDrag)
        {
            _backpackSlot = backpackSlot;
            _backpackManager = backpackManager;
            _forceRefresh = forceRefresh;
            _clearGrid = clearGrid;
            _rebuildBackpackGrid = rebuildBackpackGrid;
            _stopCoroutine = stopCoroutine;
            _tryPlaceInAnyPlayerGrid = tryPlaceInAnyPlayerGrid;
            _findItemLocation = findItemLocation;
            _findControllerForItem = findControllerForItem;
            _getControllerForGrid = getControllerForGrid;
            _getEffectiveGridSize = getEffectiveGridSize;
            _cancelDrag = cancelDrag;
        }

 public void ToggleBackpackFold(InventoryItem item, bool fold)
{
    if (item == null || !item.CanFold || !item.Data.IsBackpack) return;

    if (!fold && _backpackManager != null)
    {
        int depth = _backpackManager.GetBackpackDepth(item);
        if (depth > BackpackContainerManager.MaxOpenFloatingWindows)
        {
            Debug.Log(
                $"[FOLD] Cannot unfold '{item.Data.DisplayName}': уровень вложенности {depth} " +
                $"превышает лимит открытых окон ({BackpackContainerManager.MaxOpenFloatingWindows}).");
            return;
        }

        var currentController = _findControllerForItem?.Invoke(item);
        if (currentController != null
            && !_backpackManager.CanPlaceUnfoldedBackpackIntoController(currentController, item, out var reason))
        {
            Debug.Log($"[FOLD] Cannot unfold '{item.Data.DisplayName}': {reason}");
            return;
        }
    }

    if (fold)
        SyncBackpackContentsBeforeFold(item);

    if (fold && !IsBackpackContentsEmpty(item))
    {
        Debug.Log($"[FOLD] Cannot fold backpack '{item.Data.DisplayName}' — not empty");
        return;
    }

    if (fold && item.IsFolded) return;
    if (!fold && !item.IsFolded) return;

    if (_backpackSlot != null && _backpackSlot.EquippedItem == item)
    {
        HandleEquippedBackpackFold(item, fold);
        return;
    }

    HandleInventoryBackpackFold(item, fold);
}

        public bool IsBackpackContentsEmpty(InventoryItem item)
        {
            if (item == null || !item.Data.IsBackpack) return true;

            SyncBackpackContentsBeforeFold(item);

            var ctrl = _backpackManager?.GetLiveController(item.InstanceID.ToString());
            if (ctrl != null && ctrl.GetItemCount() > 0) return false;

            if (_backpackSlot != null && _backpackSlot.EquippedItem == item)
            {
                var bpCtrl = _getControllerForGrid?.Invoke(GridType.Backpack);
                if (bpCtrl != null && bpCtrl.GetItemCount() > 0) return false;
            }

            return !item.HasBackpackContents;
        }
public bool CanUnfoldInCurrentGrid(InventoryItem item)
{
    if (item == null || !item.CanFold || !item.IsFolded) return true;
    if (_backpackManager != null &&
        _backpackManager.GetBackpackDepth(item) > BackpackContainerManager.MaxOpenFloatingWindows)
        return false;
    if (_backpackSlot != null && _backpackSlot.EquippedItem == item) return true;

    var location = _findItemLocation?.Invoke(item);
    if (location == null || location.Value.grid == null) return false;

    var originGrid = location.Value.grid.Value;
    InventoryController controller = originGrid == GridType.Container
        ? _findControllerForItem?.Invoke(item)
        : _getControllerForGrid?.Invoke(originGrid);
    if (controller == null) return false;

    var effectiveSize = _getEffectiveGridSize?.Invoke(originGrid, controller) ?? (0, 0);
    Vector2Int baseSize = ComputeUnfoldedSize(item);
    bool axisSwap = Mathf.Abs(item.RotationAngle % 180) > 0;
    Vector2Int unfoldedSize = axisSwap ? new Vector2Int(baseSize.y, baseSize.x) : baseSize;

    if (location.Value.x + unfoldedSize.x <= effectiveSize.width && 
        location.Value.y + unfoldedSize.y <= effectiveSize.height &&
        CanPlaceRotatedInController(controller, unfoldedSize, location.Value.x, location.Value.y, item))
        return true;

    for (int y = 0; y <= effectiveSize.height - unfoldedSize.y; y++)
        for (int x = 0; x <= effectiveSize.width - unfoldedSize.x; x++)
            if (CanPlaceRotatedInController(controller, unfoldedSize, x, y, item)) return true;

    return false;
}

        public void SyncBackpackForValidationPublic(InventoryItem backpackItem) => SyncBackpackForValidation(backpackItem);

   public int EmptyBackpackContents(InventoryItem backpackItem, bool isLootingContainer, InventoryController activeContainerController)
{
    if (backpackItem == null || !backpackItem.Data.IsBackpack) return 0;
    if (backpackItem.IsFolded && !backpackItem.Data.AlwaysShowGrid) return 0;

    _backpackManager?.CloseAllWindowsForBackpackItem(backpackItem);
    _backpackManager?.CloseNestedBackpacks(backpackItem);

    var savedItems = backpackItem.GetBackpackSavedItems();
    if (savedItems == null || savedItems.Count == 0) return 0;

    var pocketsCtrl = _getControllerForGrid?.Invoke(GridType.Pockets);
    var pocket2Ctrl = _getControllerForGrid?.Invoke(GridType.Pocket2);
    var backpackCtrl = _getControllerForGrid?.Invoke(GridType.Backpack);

    InventoryController parentCtrl = null;
    var allCtrls = new List<InventoryController> { pocketsCtrl, pocket2Ctrl, backpackCtrl };
    if (isLootingContainer && activeContainerController != null) allCtrls.Add(activeContainerController);
    if (_backpackManager?.OpenWindows != null)
    {
        foreach (var w in _backpackManager.OpenWindows)
            if (w != null && w.Controller != null) allCtrls.Add(w.Controller);
    }

    foreach (var ctrl in allCtrls)
    {
        if (ctrl == null) continue;
        for (int y = 0; y < ctrl.Height; y++)
            for (int x = 0; x < ctrl.Width; x++)
                if (ctrl.GetItemAt(x, y) == backpackItem) { parentCtrl = ctrl; break; }
        if (parentCtrl != null) break;
    }

    if (parentCtrl == null && _backpackSlot != null && _backpackSlot.EquippedItem == backpackItem)
        parentCtrl = pocketsCtrl;

    if (parentCtrl == null) parentCtrl = pocketsCtrl;

    var fallbackCtrls = new List<InventoryController>();
    void AddCtrl(InventoryController c)
    {
        if (c != null && !fallbackCtrls.Contains(c))
            fallbackCtrls.Add(c);
    }

    // БАГ 2А ФИКС: Если владелец найден, пытаемся положить предметы ТОЛЬКО в него
    if (parentCtrl != null)
    {
        AddCtrl(parentCtrl);
    }
    else
    {
        AddCtrl(pocketsCtrl);
        AddCtrl(pocket2Ctrl);
        AddCtrl(backpackCtrl);
    }

    var db = K_InventorySetup.DatabaseInstance;
    if (db == null) return 0;

    int extracted = 0;
    var remaining = new List<SavedItem>();
    var candidates = new List<InventoryItem>();
    var savedByInstance = new Dictionary<uint, SavedItem>();

    foreach (var saved in savedItems)
    {
        var template = db.GetItemData(saved.ItemID);
        if (template == null) { remaining.Add(saved); continue; }
        var inner = InventoryItem.FromSaveData(saved, template);
        if (inner == null) { remaining.Add(saved); continue; }
        candidates.Add(inner);
        savedByInstance[inner.InstanceID] = saved;
    }

    candidates.Sort((a, b) => (b.CurrentSize.x * b.CurrentSize.y).CompareTo(a.CurrentSize.x * a.CurrentSize.y));

    foreach (var inner in candidates)
    {
        bool placed = false;

        foreach (var ctrl in fallbackCtrls)
        {
            if (ctrl == null) continue;

            if (_backpackManager != null
                && !_backpackManager.CanPlaceUnfoldedBackpackIntoController(ctrl, inner, out _))
                continue;

            if (PlaceSmartInController(inner, ctrl))
            {
                placed = true;
                break;
            }
        }

        if (placed) extracted++;
        else remaining.Add(savedByInstance[inner.InstanceID]);
    }

    backpackItem.ReplaceBackpackContents(remaining);
    _forceRefresh?.Invoke();
    return extracted;
}
        public void UpdateDragState(bool isDragging, bool dragItemRemoved, UI_Item draggedItem, int dragOriginX, int dragOriginY, GridType dragOriginGridType)
        {
            _isDragging = isDragging;
            _dragItemRemoved = dragItemRemoved;
            _draggedItem = draggedItem;
            _dragOriginX = dragOriginX;
            _dragOriginY = dragOriginY;
            _dragOriginGridType = dragOriginGridType;
        }

       private void HandleEquippedBackpackFold(InventoryItem item, bool fold)
{
    var bpCtrl = _getControllerForGrid?.Invoke(GridType.Backpack);

    // Дети надетого рюкзака с открытыми окнами обязаны быть закрыты до
    // Clear()/восстановления — иначе их живые объекты станут сиротами.
    _backpackManager?.CloseWindowsInsideSubtree(bpCtrl);

    if (fold)
    {
        SyncEquippedBackpackControllerToItem(item);
        if (!IsBackpackContentsEmpty(item)) return;

        if (bpCtrl != null) bpCtrl.Clear();
        if (!item.ToggleFold(contentsEmpty: true)) return;

        if (_clearGrid != null && bpCtrl != null) _clearGrid.Invoke(null, null);
        _forceRefresh?.Invoke();
    }
    else
    {
        item.ToggleFold(contentsEmpty: true);
        if (item.Data.BackpackWidth > 0 && item.Data.BackpackHeight > 0)
            _rebuildBackpackGrid?.Invoke(item.Data.BackpackWidth, item.Data.BackpackHeight);
        RestoreEquippedBackpackControllerFromItem(item);
    }
    _backpackSlot?.Refresh();
    _forceRefresh?.Invoke();
}

        private void HandleInventoryBackpackFold(InventoryItem item, bool fold)
        {
            if (_isDragging && _dragItemRemoved && _draggedItem != null && _draggedItem.Item == item)
            {
                var orphanOriginController = _getControllerForGrid?.Invoke(_dragOriginGridType);
                if (orphanOriginController != null)
                {
                    bool orphanPlaced = orphanOriginController.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
                    if (!orphanPlaced) orphanPlaced = orphanOriginController.PlaceExistingItemInFirstFreeSlot(item);
                    if (!orphanPlaced) _tryPlaceInAnyPlayerGrid?.Invoke(item);
                }
            }

            _cancelDrag?.Invoke();

            var location = _findItemLocation?.Invoke(item);
            if (location == null || location.Value.grid == null) return;

            var originGrid = location.Value.grid.Value;
            int origX = location.Value.x;
            int origY = location.Value.y;
            int origRotationAngle = item.RotationAngle;

            InventoryController controller = originGrid == GridType.Container ? _findControllerForItem?.Invoke(item) : _getControllerForGrid?.Invoke(originGrid);
            if (controller == null) return;

            if (_backpackManager?.ActiveBackpackContainer == item || System.Linq.Enumerable.Any(_backpackManager?.OpenWindows ?? new List<K_ContainerWindow>(), w => w != null && w.BackpackInstanceID == item.InstanceID.ToString()))
            {
                _backpackManager?.CloseAllWindowsForBackpackItem(item);
            }

            controller.RemoveItem(item);
            bool ok = item.ToggleFold(contentsEmpty: true);
            if (!ok)
            {
                controller.PlaceExistingItem(item, origX, origY);
                _forceRefresh?.Invoke();
                return;
            }

            var effectiveSize = _getEffectiveGridSize?.Invoke(originGrid, controller) ?? (0, 0);
            bool placed = PlaceBackpackWithSmartFit(controller, item, origX, origY, false, effectiveSize.width, effectiveSize.height);

            if (!placed)
            {
                item.ToggleFold(contentsEmpty: !fold);
                item.RestoreRotationState(origRotationAngle);
                if (!controller.PlaceExistingItem(item, origX, origY))
                    controller.PlaceExistingItemInFirstFreeSlot(item);
            }
            _forceRefresh?.Invoke();
        }

        private bool PlaceBackpackWithSmartFit(InventoryController controller, InventoryItem item, int origX, int origY, bool allowRotation, int effectiveW, int effectiveH)
        {
            if (controller == null || item == null) return false;
            Vector2Int size = item.CurrentSize;
            if (size.x > effectiveW || size.y > effectiveH) return false;

            if (controller.PlaceExistingItem(item, origX, origY)) return true;
            
            for (int y = 0; y <= effectiveH - size.y; y++)
                for (int x = 0; x <= effectiveW - size.x; x++)
                    if (controller.PlaceExistingItem(item, x, y)) return true;

            if (allowRotation && item.Data != null && item.Data.CanRotate && size.x != size.y)
            {
                item.Rotate();
                Vector2Int rotSize = item.CurrentSize;
                if (rotSize.x <= effectiveW && rotSize.y <= effectiveH)
                {
                    for (int y = 0; y <= effectiveH - rotSize.y; y++)
                        for (int x = 0; x <= effectiveW - rotSize.x; x++)
                            if (controller.PlaceExistingItem(item, x, y)) return true;
                }
                item.Rotate();
            }
            return false;
        }

                   public void SyncBackpackContentsBeforeFold(InventoryItem item)
        {
            if (item == null || !item.Data.IsBackpack) return;

            // ФИКС: Если рюкзак сейчас открыт как контейнер, его содержимое уже актуально в контроллере.
            if (item.GetBackpackController() != null)
            {
                item.MarkBackpackContentsDirty();
                return;
            }

            if (_backpackSlot != null && _backpackSlot.EquippedItem == item)
            {
                var bpCtrl = _getControllerForGrid?.Invoke(GridType.Backpack);
                if (bpCtrl != null)
                {
                    bpCtrl.RefreshAllItemsInData();
                    var savedItems = bpCtrl.GetSaveData()?.GetItems();
                    item.ReplaceBackpackContents(savedItems);
                }
            }

            string idStr = item.InstanceID.ToString();
            var ctrl = _backpackManager?.GetLiveController(idStr);
            if (ctrl != null)
            {
                ctrl.RefreshAllItemsInData();
                var savedItems = ctrl.GetSaveData()?.GetItems();
                item.ReplaceBackpackContents(savedItems);
            }
        }        private void SyncBackpackForValidation(InventoryItem backpackItem)
        {
            if (backpackItem == null || backpackItem.Data == null || !backpackItem.Data.IsBackpack) return;
            SyncBackpackTreeRecursive(backpackItem, 0);
        }

        private void SyncBackpackTreeRecursive(InventoryItem backpack, int depth)
        {
            if (backpack == null || !backpack.Data.IsBackpack || depth > 16) return;

            if (_backpackSlot != null && _backpackSlot.EquippedItem == backpack)
            {
                var bpCtrl = _getControllerForGrid?.Invoke(GridType.Backpack);
                if (bpCtrl != null)
                {
                    for (int y = 0; y < bpCtrl.Height; y++)
                        for (int x = 0; x < bpCtrl.Width; x++)
                        {
                            var item = bpCtrl.GetItemAt(x, y);
                            if (item != null && item.Data.IsBackpack && bpCtrl.IsRootCell(item.InstanceID, x, y))
                                SyncBackpackTreeRecursive(item, depth + 1);
                        }
                    var savedItems = bpCtrl.GetSaveData()?.GetItems();
                    if (savedItems != null) backpack.ReplaceBackpackContents(savedItems);
                    return;
                }
            }

            string idStr = backpack.InstanceID.ToString();
            var ctrl = _backpackManager?.GetLiveController(idStr);
            if (ctrl != null)
            {
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var item = ctrl.GetItemAt(x, y);
                        if (item != null && item.Data.IsBackpack && ctrl.IsRootCell(item.InstanceID, x, y))
                            SyncBackpackTreeRecursive(item, depth + 1);
                    }
                var savedItems = ctrl.GetSaveData()?.GetItems();
                if (savedItems != null) backpack.ReplaceBackpackContents(savedItems);
            }
        }

        private void SyncEquippedBackpackControllerToItem(InventoryItem item)
        {
            var bpCtrl = _getControllerForGrid?.Invoke(GridType.Backpack);
            if (bpCtrl == null || item == null) return;
            var savedItems = bpCtrl.GetSaveData()?.GetItems();
            if (savedItems == null) return;
            item.ReplaceBackpackContents(savedItems);
        }

        private void RestoreEquippedBackpackControllerFromItem(InventoryItem item)
        {
            var bpCtrl = _getControllerForGrid?.Invoke(GridType.Backpack);
            if (bpCtrl == null || item == null) return;
            bpCtrl.Clear();
            var savedItems = item.GetBackpackSavedItems();
            if (savedItems == null || savedItems.Count == 0) return;
            foreach (var saved in savedItems)
            {
                var template = K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID);
                if (template == null) continue;
                var inner = InventoryItem.FromSaveData(saved, template);
                if (inner == null) continue;
                bpCtrl.PlaceExistingItem(inner, saved.X, saved.Y);
            }
        }

        private static Vector2Int ComputeUnfoldedSize(InventoryItem item)
        {
            if (item?.Data == null) return new Vector2Int(1, 1);
            var data = item.Data;
            if (data.IsBackpack && data.UnfoldedIconSize.x > 0 && data.UnfoldedIconSize.y > 0) return data.UnfoldedIconSize;
            if (data.IsBackpack && data.BackpackWidth > 0 && data.BackpackHeight > 0) return new Vector2Int(data.BackpackWidth, data.BackpackHeight);
            return data.Size;
        }

        private bool CanPlaceRotatedInController(InventoryController controller, Vector2Int size, int x, int y, InventoryItem ignoreItem)
        {
            if (controller == null || x < 0 || y < 0 || x + size.x > controller.Width || y + size.y > controller.Height) return false;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    var at = controller.GetItemAt(x + dx, y + dy);
                    if (at != null && at.InstanceID != ignoreItem.InstanceID) return false;
                }
            return true;
        }

        private bool PlaceSmartInController(InventoryItem item, InventoryController ctrl)
        {
            if (ctrl == null) return false;
            if (TryPlaceBottomLeft(item, ctrl)) return true;
            if (item.Data != null && item.Data.CanRotate)
            {
                Vector2Int sz = item.CurrentSize;
                if (sz.x != sz.y)
                {
                    item.Rotate();
                    bool ok = TryPlaceBottomLeft(item, ctrl);
                    if (!ok) item.Rotate();
                    return ok;
                }
            }
            return false;
        }

        private bool TryPlaceBottomLeft(InventoryItem item, InventoryController ctrl)
        {
            if (ctrl == null) return false;
            for (int y = 0; y <= ctrl.Height - item.CurrentSize.y; y++)
                for (int x = 0; x <= ctrl.Width - item.CurrentSize.x; x++)
                    if (ctrl.PlaceExistingItem(item, x, y)) return true;
            return false;
        }
    }
}
