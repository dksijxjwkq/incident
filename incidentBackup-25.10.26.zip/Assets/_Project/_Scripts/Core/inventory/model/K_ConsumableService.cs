using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Quantity rules shared by windows and timed medical application.
    /// The owner commits charge and effect together, before publishing inventory events.</summary>
    public static class K_ConsumableService
    {
        private static readonly HashSet<uint> Applying = new HashSet<uint>();

        public static float GetTransfusionMaximum(InventoryItem item, K_BloodSystem blood, float perUseMaximumMl)
        {
            if (!IsAmountItem(item) || blood == null || !Positive(perUseMaximumMl)) return 0f;
            return Mathf.Max(0f, Mathf.Min(perUseMaximumMl,
                Mathf.Min(item.RemainingChargeAmount, blood.MaxVolumeMl - blood.CurrentVolumeMl)));
        }

        public static bool TryTransfuse(InventoryItem item, float selectedMl, K_BloodSystem blood,
            float perUseMaximumMl, Func<float, Action, bool> spendCharge, out float transferredMl, out string reason)
        {
            transferredMl = 0f;
            reason = "переливание недоступно";
            if (!Positive(selectedMl) || spendCharge == null || !IsAmountItem(item) || blood == null) return false;
            float amount = Mathf.Min(selectedMl, GetTransfusionMaximum(item, blood, perUseMaximumMl));
            if (amount <= 0f) { reason = "кровь уже заполнена или пакет пуст"; return false; }
            if (!Applying.Add(item.InstanceID)) { reason = "предмет уже используется"; return false; }
            try
            {
                if (!spendCharge(amount, () => blood.AddBlood(amount)))
                { reason = "предмет больше не принадлежит инвентарю"; return false; }
                transferredMl = amount;
                reason = null;
                return true;
            }
            finally { Applying.Remove(item.InstanceID); }
        }

        public static bool TryConsumeFood(InventoryItem item, float selectedPercent, K_VitalitySystem vitality,
            Func<float, Action, bool> spendCharge, out float consumedPercent, out string reason)
        {
            consumedPercent = 0f;
            reason = "еда или напиток недоступны";
            if (item?.Data == null || item.Data.IsBackpack || item.Quantity != 1 || vitality == null || spendCharge == null ||
                (item.Data.ConsumableType != ConsumableType.Food && item.Data.ConsumableType != ConsumableType.Drink) ||
                !Positive(item.Data.ConsumableTotalValue) || !Positive(selectedPercent)) return false;
            float remaining = item.RemainingConsumablePercent;
            if (remaining <= 0f || selectedPercent < Mathf.Min(1f, remaining)) return false;
            float amount = Mathf.Min(selectedPercent, remaining);
            float value = item.Data.ConsumableTotalValue * (amount / 100f);
            if (!Applying.Add(item.InstanceID)) { reason = "предмет уже используется"; return false; }
            try
            {
                if (!spendCharge(amount, () => vitality.ConsumeFoodWater(
                    item.Data.ConsumableType == ConsumableType.Food ? value : 0f,
                    item.Data.ConsumableType == ConsumableType.Drink ? value : 0f)))
                { reason = "предмет больше не принадлежит инвентарю"; return false; }
                consumedPercent = amount;
                reason = null;
                return true;
            }
            finally { Applying.Remove(item.InstanceID); }
        }

        private static bool IsAmountItem(InventoryItem item) => item?.Data != null && !item.Data.IsBackpack && item.Quantity == 1 &&
            item.Data.ChargeCategory == ChargeCategory.AmountAbsolute && item.Data.ConsumableType == ConsumableType.None;
        private static bool Positive(float value) => !float.IsNaN(value) && !float.IsInfinity(value) && value > 0f;
    }
}
