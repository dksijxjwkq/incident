using System;
using System.Collections.Generic;

namespace K_Incident.Core.Inventory
{
    /// <summary>Explicit weak registry of every live controller, including loot and ground roots.</summary>
    public static class InventoryOwnershipRegistry
    {
        private static readonly List<WeakReference<InventoryController>> Controllers =
            new List<WeakReference<InventoryController>>();

        internal static void Register(InventoryController controller)
        {
            Prune();
            if (controller == null || controller.IsDisposed) return;
            foreach (var entry in Controllers)
                if (entry.TryGetTarget(out var known) && ReferenceEquals(known, controller)) return;
            Controllers.Add(new WeakReference<InventoryController>(controller));
        }

        internal static void Unregister(InventoryController controller)
        {
            for (int i = Controllers.Count - 1; i >= 0; i--)
                if (!Controllers[i].TryGetTarget(out var known) || known.IsDisposed || ReferenceEquals(known, controller))
                    Controllers.RemoveAt(i);
        }

        public static InventoryItem FindLiveItem(uint instanceId)
        {
            Prune();
            if (instanceId == 0 || instanceId == uint.MaxValue) return null;
            for (int i = Controllers.Count - 1; i >= 0; i--)
                if (Controllers[i].TryGetTarget(out var controller))
                {
                    var item = controller.GetItemByInstanceID(instanceId);
                    if (item != null) return item;
                }
            return null;
        }

        public static int RegisteredControllerCount { get { Prune(); return Controllers.Count; } }

        private static void Prune()
        {
            for (int i = Controllers.Count - 1; i >= 0; i--)
                if (!Controllers[i].TryGetTarget(out var controller) || controller.IsDisposed)
                    Controllers.RemoveAt(i);
        }
    }
}
