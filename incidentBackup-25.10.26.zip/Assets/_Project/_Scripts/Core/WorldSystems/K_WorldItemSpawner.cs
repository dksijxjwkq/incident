using System.Collections.Generic;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core.World
{
    /// <summary>
    /// Stage 4.5.1: спавнер мир-объектов.
    ///
    /// Stage 4.5.1b: добавлен параметр isFolded для сохранения свёрнутого
    /// состояния рюкзака при дропе.
    /// </summary>
    public class K_WorldItemSpawner : MonoBehaviour
    {
        public static K_WorldItemSpawner Instance { get; private set; }

        [Header("Prefab (optional)")]
        [SerializeField, Tooltip("Опциональный префаб. Должен содержать K_WorldItem + " +
            "SpriteRenderer + BoxCollider. Если null — собираем программно.")]
        private GameObject _worldItemPrefab;

#if UNITY_EDITOR
        [Header("Debug")]
        [SerializeField, Tooltip("ItemStaticData для Context Menu → Debug: Spawn Test Item.")]
        private ItemStaticData _debugTestItem;
#endif

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        /// <summary>
        /// Создаёт мир-объект. Позиция — ровно переданная (без Raycast, без гравитации).
        /// InstanceID НЕ устанавливается — вызывающий код проставляет его сам.
        ///
        /// Stage 4.5.1b: isFolded сохраняется в K_WorldItem.IsFolded.
        /// </summary>
        public static K_WorldItem SpawnItem(
            ItemStaticData data,
            int quantity,
            int durability,
            int chargePercent,
            bool isRotated,
            Vector3 position,
            List<SavedItem> backpackContents = null,
            bool isFolded = false,
            float remainingChargeSeconds = -1f)
        {
            if (data != null && (quantity < 1 || quantity > data.HardStackLimit))
            {
                Debug.LogWarning("[K_WorldItemSpawner] Quantity exceeds the live item contract; source remains unchanged.");
                return null;
            }
            if (data == null)
            {
                Debug.LogWarning("[K_WorldItemSpawner] SpawnItem: data is null.");
                return null;
            }

            GameObject go;
            var prefab = Instance != null ? Instance._worldItemPrefab : null;

            if (prefab != null)
            {
                go = Instantiate(prefab, position, Quaternion.identity);
            }
            else
            {
                go = new GameObject(
                    "K_WorldItem_" + data.ItemID,
                    typeof(SpriteRenderer),
                    typeof(BoxCollider),
                    typeof(K_WorldItem));
                go.transform.position = position;
            }

            var item = go.GetComponent<K_WorldItem>();
            if (item == null)
            {
                Debug.LogError("[K_WorldItemSpawner] Prefab has no K_WorldItem component.");
                Destroy(go);
                return null;
            }

            item.ItemID = data.ItemID;
            item.InstanceID = 0; // заполнит вызывающий
            item.Quantity = Mathf.Max(1, quantity);
            item.Durability = Mathf.Max(0, durability);
            item.ChargePercent = Mathf.Clamp(chargePercent, 0, 100);
            item.RemainingChargeSeconds = remainingChargeSeconds;
            item.IsRotated = isRotated;
            item.IsFolded = isFolded;
            item.BackpackContents = backpackContents;

            item.ApplyVisual(data);

            // Stage 4.5.1: визуальный поворот иконки при isRotated (Z-плоскость).
            go.transform.rotation = Quaternion.Euler(0f, 0f, isRotated ? -90f : 0f);

            return item;
        }

        /// <summary>Builds and validates a replacement under an inactive staging parent.</summary>
        public static K_WorldItem SpawnInactiveForLoad(ItemStaticData data, SavedItem saved,
            Vector3 position, float rotationY, Transform stagingParent)
        {
            if (data == null || stagingParent == null)
                throw new System.IO.InvalidDataException("World replacement requires a template and staging parent.");
            var prefab = Instance != null ? Instance._worldItemPrefab : null;
            if (prefab != null && (prefab.GetComponent<K_WorldItem>() == null ||
                prefab.GetComponent<SpriteRenderer>() == null || prefab.GetComponent<BoxCollider>() == null))
                throw new System.IO.InvalidDataException("World-item prefab requires K_WorldItem, SpriteRenderer and BoxCollider on its root.");
            GameObject go = null;
            try
            {
                if (prefab != null) go = Instantiate(prefab, stagingParent, false);
                else
                {
                    go = new GameObject("K_WorldItem_" + data.ItemID);
                    go.SetActive(false);
                    go.transform.SetParent(stagingParent, false);
                    go.AddComponent<SpriteRenderer>();
                    go.AddComponent<BoxCollider>();
                    go.AddComponent<K_WorldItem>();
                }
                go.SetActive(false);
                var item = go.GetComponent<K_WorldItem>();
                item.ItemID = saved.ItemID;
                item.InstanceID = saved.InstanceID;
                item.Quantity = saved.Quantity;
                item.Durability = saved.Durability;
                item.ChargePercent = saved.ChargePercent;
                item.RemainingChargeSeconds = saved.RemainingChargeSeconds;
                item.IsRotated = saved.IsRotated;
                item.IsFolded = saved.IsFolded;
                item.BackpackContents = saved.BackpackContents;
                item.ApplyVisual(data);
                go.transform.position = position;
                go.transform.rotation = Quaternion.Euler(0f, rotationY, saved.IsRotated ? -90f : 0f);
                return item;
            }
            catch
            {
                if (go != null) { go.SetActive(false); Destroy(go); }
                throw;
            }
        }

        public static bool TryDropEquippedItem(K_EquipmentSlotUI slot, K_InventoryUI inventoryUI, Vector3 position)
        {
            var source = slot != null ? slot.EquippedItem : null;
            if (source?.Data == null || inventoryUI == null) return false;
            bool isBackpack = slot.SlotType == EquipmentSlotType.Backpack && source.Data.IsBackpack;
            if (isBackpack) inventoryUI.SyncBackpackForValidation(source);

            List<SavedItem> contents = null;
            if (source.Data.IsBackpack)
            {
                contents = new List<SavedItem>();
                foreach (var saved in source.GetBackpackSavedItems())
                    contents.Add(SavedItem.DeepClone(saved));
            }
            var world = SpawnItem(source.Data, source.Quantity, source.Durability,
                source.ChargePercent, source.IsRotated, position, contents, source.IsFolded,
                source.RemainingChargeSeconds);
            if (world == null) return false;
            world.InstanceID = source.InstanceID;

            try
            {
                if (isBackpack) inventoryUI.OnBackpackUnequipped();
                slot.SetEquippedItem(null);
                return true;
            }
            catch (System.Exception exception)
            {
                world.gameObject.SetActive(false);
                Destroy(world.gameObject);
                Debug.LogException(exception);
                // SetEquippedItem assigns the owner before notifying listeners.
                // A second listener failure must not skip backpack restoration.
                try { slot.SetEquippedItem(source); }
                catch (System.Exception rollbackException) { Debug.LogException(rollbackException); }
                if (isBackpack)
                {
                    try { inventoryUI.OnBackpackEquipped(source); }
                    catch (System.Exception rollbackException) { Debug.LogException(rollbackException); }
                }
                return false;
            }
        }

#if UNITY_EDITOR
        [ContextMenu("Debug: Spawn Test Item")]
        private void DebugSpawnTest()
        {
            if (_debugTestItem == null)
            {
                Debug.LogWarning("[K_WorldItemSpawner] _debugTestItem not assigned.");
                return;
            }
            Vector3 pos = transform.position + new Vector3(1f, 0f, 0f);
            var item = SpawnItem(_debugTestItem, 1, 0, 100, false, pos);
            if (item != null) item.InstanceID = K_Incident.Core.Inventory.GlobalIDManager.GenerateID();
            Debug.Log($"[K_WorldItemSpawner] Test item spawned at {pos}.");
        }
#endif
    }
}
