using System.Collections.Generic;
using K_Incident.Core.Inventory;
using UnityEngine;
using UnityEngine.InputSystem;

namespace K_Incident.Core.World
{
    /// <summary>
    /// Stage 4.5.1: система подбора мир-объектов.
    ///
    /// Stage 4.5.1b:
    ///   - F-tap заменён на F-hold (0.4с) — подбор срабатывает ровно один раз
    ///     за удержание, до отпускания не повторяется.
    ///   - Добавлен cooldown 0.5с после дропа (через NotifyItemDropped) — защита
    ///     от мгновенного re-pickup выброшенного предмета.
    ///   - Pass-through IsFolded в SavedItem ctor для восстановления свёрнутого
    ///     состояния рюкзаков при подборе.
    ///
    /// Stage 4.5.1c:
    ///   - Гейт «инвентарь закрыт»: F не подбирает при открытом K_InventoryUI,
    ///     чтобы не конфликтовать с _foldKey (fold тащимого рюкзака во время drag).
    /// </summary>
    public class K_WorldItemPickupSystem : MonoBehaviour
    {
        [Header("Pickup")]
        [SerializeField, Min(0.5f)] private float _pickupRadius = 2f;

        [SerializeField, Tooltip("Маска слоёв для OverlapSphere. " +
            "Если не задана (0) — берётся слой 'WorldItem'.")]
        private LayerMask _worldItemMask;

        private const float HOLD_DURATION = 0.4f;
        private const float DROP_COOLDOWN = 0.5f;

        private Collider[] _buffer = new Collider[512];
        private K_PlayerMotor _playerMotor;
        private K_InventoryUI _inventoryUI;
        private Transform _playerTransform;

        private float _holdTimer;
        private bool _pickupConsumed;
        private float _lastDropTime = -999f;
        private bool _groundLootRefreshPending;

        private void Start()
        {
            // Инвариант: FindFirstObjectByType только в Start.
            _playerMotor = FindFirstObjectByType<K_PlayerMotor>();
            _inventoryUI = FindFirstObjectByType<K_InventoryUI>();
            _playerTransform = _playerMotor != null ? _playerMotor.transform : null;

            if (_worldItemMask.value == 0)
                _worldItemMask = 1 << K_WorldItem.GetLayer();
        }

        private void Update()
        {
            var kb = Keyboard.current;
            if (kb == null) return;

            // Stage 4.5.1c: pickup работает только когда инвентарь закрыт.
            // Иначе F конфликтует с K_InventoryUI._foldKey (fold тащимого рюкзака).
            if (K_SplitStackDialog.IsOpen || (_inventoryUI != null && _inventoryUI.IsOpen))
            {
                _holdTimer = 0f;
                _pickupConsumed = kb.fKey.isPressed;
                return;
            }

            // Cooldown после дропа (см. NotifyItemDropped).
            if (Time.time - _lastDropTime < DROP_COOLDOWN)
            {
                // Сбрасываем прогресс удержания, если игрок держит F в момент дропа.
                _holdTimer = 0f;
                _pickupConsumed = false;
                return;
            }

            if (kb.fKey.wasPressedThisFrame)
            {
                _holdTimer = 0f;
                _pickupConsumed = false;
            }
            else if (kb.fKey.isPressed && !_pickupConsumed)
            {
                _holdTimer += Time.deltaTime;
                if (_holdTimer >= HOLD_DURATION)
                {
                    OpenLootPanel();
                    _pickupConsumed = true; // до отпускания — не повторять
                }
            }
            else if (kb.fKey.wasReleasedThisFrame)
            {
                _holdTimer = 0f;
                _pickupConsumed = false;
            }
        }

        /// <summary>
        /// Вызывается из K_ContextMenu после успешного SpawnItem, чтобы
        /// заблокировать мгновенный re-pickup того же предмета.
        /// </summary>
        public void NotifyItemDropped()
        {
            _lastDropTime = Time.time;
            _groundLootRefreshPending = true;
        }

        private void LateUpdate()
        {
            if (!_groundLootRefreshPending) return;
            if (_inventoryUI == null || !_inventoryUI.IsGroundLootOpen || _playerTransform == null)
            {
                _groundLootRefreshPending = false;
                return;
            }
            if (_inventoryUI.IsDragging) return;

            // Drop has committed by now, including its final InstanceID. Sync
            // the new collider before querying even when autoSyncTransforms is off.
            Physics.SyncTransforms();
            _inventoryUI.RefreshGroundLootItems(CollectNearbyWorldItems());
            _groundLootRefreshPending = false;
        }

        private List<K_WorldItem> CollectNearbyWorldItems()
        {
            int count;
            while (true)
            {
                count = Physics.OverlapSphereNonAlloc(_playerTransform.position, _pickupRadius,
                    _buffer, _worldItemMask, QueryTriggerInteraction.Collide);
                if (count < _buffer.Length) break;
                System.Array.Resize(ref _buffer, checked(_buffer.Length * 2));
            }
            var worlds = new List<K_WorldItem>();
            var seen = new HashSet<K_WorldItem>();
            for (int i = 0; i < count; i++)
            {
                var collider = _buffer[i];
                if (collider == null) continue;
                var world = collider.GetComponentInParent<K_WorldItem>();
                if (world == null || !seen.Add(world)) continue;
                worlds.Add(world);
            }
            return worlds;
        }

        private void OpenLootPanel()
        {
            if (_inventoryUI == null || _playerTransform == null || _inventoryUI.IsOpen ||
                _inventoryUI.IsLooting || _inventoryUI.IsGroundLootOpen) return;
            _inventoryUI.OpenGroundLoot(CollectNearbyWorldItems());
        }

    }
}
