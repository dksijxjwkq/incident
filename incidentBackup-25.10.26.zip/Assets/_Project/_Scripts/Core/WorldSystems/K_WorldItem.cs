using System.Collections.Generic;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core.World
{
    /// <summary>
    /// Stage 4.5.1: предмет, лежащий в мире (дропнутый из инвентаря).
    ///
    /// НЕ реализует IInteractable — подбор идёт через отдельную систему
    /// K_WorldItemPickupSystem (F-hold → OverlapSphere → ближайший).
    ///
    /// НЕ имеет Rigidbody: лежит неподвижно на позиции, заданной при спавне.
    /// BoxCollider нужен только для Physics.OverlapSphere.
    ///
    /// Stage 4.5.1b: добавлено поле IsFolded. Свёрнутое состояние сохраняется
    /// вместе с объектом в мире и восстанавливается при подборе.
    /// </summary>
    public class K_WorldItem : MonoBehaviour
    {
        public string ItemID;
        public uint InstanceID;
        public int Quantity = 1;
        public int Durability;
        public int ChargePercent = 100;
        public float RemainingChargeSeconds = -1f;
        public bool IsRotated;

        // Stage 4.5.1b: свёрнутое состояние рюкзака (для не-рюкзаков всегда false).
        public bool IsFolded;

        // Stage 4.5.1: полное дерево содержимого (для рюкзаков).
        // null для не-рюкзаков или пустых рюкзаков.
        public List<SavedItem> BackpackContents;

        public SpriteRenderer SpriteRenderer;
        public BoxCollider Collider;

        // Stage 4.5.1: имя слоя в Project Settings. Резолвится лениво.
        public const string LayerName = "WorldItem";
        private static int _cachedLayer = -2; // -2 = not resolved

        /// <summary>
        /// Возвращает id слоя "WorldItem" (резолвится один раз).
        /// Если слоя нет в проекте — warning + fallback на Default (0).
        /// </summary>
        public static int GetLayer()
        {
            if (_cachedLayer == -2)
            {
                _cachedLayer = LayerMask.NameToLayer(LayerName);
                if (_cachedLayer < 0)
                {
                    Debug.LogWarning($"[K_WorldItem] Layer '{LayerName}' not found. " +
                        "Falling back to Default. Create it in Project Settings → Tags and Layers.");
                    _cachedLayer = 0;
                }
            }
            return _cachedLayer;
        }

        /// <summary>
        /// Настраивает визуал по иконке ItemStaticData:
        ///   - SpriteRenderer.preserveAspect = true;
        ///   - масштаб transform.localScale такой, чтобы длинная сторона = 0.4м;
        ///   - BoxCollider по bounding box спрайта;
        ///   - gameObject.layer = WorldItem.
        /// Безопасно вызывается повторно.
        /// </summary>
        public void ApplyVisual(ItemStaticData data)
        {
            if (SpriteRenderer == null) SpriteRenderer = GetComponent<SpriteRenderer>();
            if (Collider == null) Collider = GetComponent<BoxCollider>();

            Sprite icon = data != null ? data.Icon : null;

            if (SpriteRenderer != null)
            {
                SpriteRenderer.sprite = icon;
              

            if (icon != null)
            {
                Vector3 bs = icon.bounds.size;
                float maxSide = Mathf.Max(bs.x, bs.y);
                if (maxSide > 0.0001f)
                {
                    float s = 0.4f / maxSide;
                    transform.localScale = new Vector3(s, s, 1f);
                }
                else
                {
                    transform.localScale = Vector3.one;
                }

                if (Collider != null)
                {
                    Collider.size = new Vector3(bs.x, bs.y, 0.1f);
                    Collider.center = new Vector3(icon.bounds.center.x, icon.bounds.center.y, 0f);
                    Collider.isTrigger = true;
                }
            }
            else
            {
                transform.localScale = Vector3.one;
                if (Collider != null)
                {
                    Collider.size = new Vector3(0.4f, 0.4f, 0.1f);
                    Collider.center = Vector3.zero;
                    Collider.isTrigger = true;
                }
            }

            gameObject.layer = GetLayer();
        }
    }
}}
