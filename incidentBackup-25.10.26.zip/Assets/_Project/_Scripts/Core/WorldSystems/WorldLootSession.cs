using System;
using System.Collections.Generic;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core.World
{
    /// <summary>A temporary projection of world ownership, never a saveable inventory.</summary>
    public sealed class WorldLootSession : IDisposable
    {
        public const int Columns = 8;
        public const int MinimumRows = 8;

        private sealed class Entry
        {
            public K_WorldItem World;
            public InventoryItem Item;
            public Vector2Int PackedSize;
            public int PackedRotation;
            public bool PackedFolded;
            public int Quantity;
        }

        private readonly List<Entry> _entries = new List<Entry>();
        private readonly List<InventoryItem> _items = new List<InventoryItem>();
        private readonly HashSet<uint> _allowedIDs = new HashSet<uint>();
        private readonly ItemDatabase _database;
        public InventoryController Controller { get; private set; }
        public IReadOnlyList<InventoryItem> Items => _items;
        public int Rows => Controller.Height;
        public bool IsDisposed { get; private set; }

        public WorldLootSession(IReadOnlyList<K_WorldItem> worlds, ItemDatabase database)
        {
            if (database == null) throw new ArgumentNullException(nameof(database));
            _database = database;
            AppendWorldItems(worlds);
            RebuildLayout();
        }

        /// <summary>Add initialized world objects after completed operations have been synchronized.</summary>
        public bool AddWorldItems(IReadOnlyList<K_WorldItem> worlds)
        {
            if (IsDisposed) return false;
            int previousCount = _entries.Count;
            try
            {
                AppendWorldItems(worlds);
                if (_entries.Count == previousCount) return false;
                RebuildLayout();
                return true;
            }
            catch
            {
                // The old controller remains valid if constructing its replacement fails.
                // Drop only the appended projection records; world ownership stays intact.
                while (_entries.Count > previousCount) RemoveEntry(_entries.Count - 1);
                throw;
            }
        }

        private void AppendWorldItems(IReadOnlyList<K_WorldItem> worlds)
        {
            var seenWorlds = new HashSet<K_WorldItem>();
            foreach (var entry in _entries) seenWorlds.Add(entry.World);
            for (int i = 0; worlds != null && i < worlds.Count; i++)
            {
                var world = worlds[i];
                if (world == null || !world.gameObject.activeInHierarchy || world.InstanceID == 0 ||
                    string.IsNullOrEmpty(world.ItemID) || !seenWorlds.Add(world)) continue;
                var data = _database.GetItemData(world.ItemID);
                if (data == null || _allowedIDs.Contains(world.InstanceID)) continue;
                var saved = new SavedItem(world.ItemID, world.InstanceID, 0, 0, world.Quantity,
                    world.Durability, world.IsRotated, world.IsFolded, world.ChargePercent,
                    world.RemainingChargeSeconds) { BackpackContents = Clone(world.BackpackContents) };
                var item = InventoryItem.FromSaveData(saved, data);
                if (item == null) continue;

                if (!FitsWidth(item.CurrentSize))
                {
                    Debug.LogWarning($"[LootPanel] Предмет '{world.ItemID}' ({item.CurrentSize.x}x{item.CurrentSize.y}) " +
                        $"не помещается в 8 колонок и оставлен в мире. InstanceID={world.InstanceID}");
                    continue;
                }
                _allowedIDs.Add(item.InstanceID);
                _entries.Add(new Entry { World = world, Item = item });
                _items.Add(item);
            }
        }

        private static bool FitsWidth(Vector2Int size) => size.x > 0 && size.x <= Columns && size.y > 0;

        private static (int x, int y) FindFirstFit(List<byte> occupied, Vector2Int size)
        {
            for (int y = 0; y <= occupied.Count; y++)
                for (int x = 0; x <= Columns - size.x; x++)
                {
                    int mask = ((1 << size.x) - 1) << x;
                    bool fits = true;
                    for (int dy = 0; dy < size.y && y + dy < occupied.Count; dy++)
                        if ((occupied[y + dy] & mask) != 0) { fits = false; break; }
                    if (!fits) continue;
                    while (occupied.Count < checked(y + size.y)) occupied.Add(0);
                    for (int dy = 0; dy < size.y; dy++) occupied[y + dy] |= (byte)mask;
                    return (x, y);
                }
            throw new InvalidOperationException("Cannot find a ground-loot position.");
        }

        private void RebuildLayout()
        {
            var occupied = new List<byte>();
            var positions = new List<(int x, int y)>(_entries.Count);
            foreach (var entry in _entries)
            {
                if (!FitsWidth(entry.Item.CurrentSize))
                    throw new InvalidOperationException("Ground-loot footprint exceeds its fixed width.");
                positions.Add(FindFirstFit(occupied, entry.Item.CurrentSize));
            }
            // Resize clamps ordinary inventories to 20 rows. Construct a new
            // transient controller instead, retaining the same live item objects.
            var replacement = new InventoryController(InventoryData.CreateTransientGroundGrid(Columns,
                Mathf.Max(MinimumRows, occupied.Count)), _database, "WorldLoot_Transient",
                item => item != null && _allowedIDs.Contains(item.InstanceID));
            try
            {
                for (int i = 0; i < _entries.Count; i++)
                    if (!replacement.PlaceExistingItem(_entries[i].Item, positions[i].x, positions[i].y))
                        throw new InvalidOperationException("Cannot construct world-loot projection.");
            }
            catch { replacement.Dispose(); throw; }
            var previous = Controller;
            Controller = replacement;
            foreach (var entry in _entries)
            {
                entry.PackedSize = entry.Item.CurrentSize;
                entry.PackedRotation = entry.Item.RotationAngle;
                entry.PackedFolded = entry.Item.IsFolded;
                entry.Quantity = entry.Item.Quantity;
            }
            previous?.Dispose();
        }

        private bool Owns(InventoryItem item) => !IsDisposed && item != null &&
            ReferenceEquals(Controller.GetItemByInstanceID(item.InstanceID), item);

        public bool TryRotateItem(InventoryItem item)
        {
            if (!Owns(item) || !item.Data.CanRotate) return false;
            int previous = item.RotationAngle;
            item.Rotate();
            if (!FitsWidth(item.CurrentSize)) { item.RestoreRotationState(previous); return false; }
            try { RebuildLayout(); }
            catch { item.RestoreRotationState(previous); throw; }
            return true;
        }

        public bool CanSetFolded(InventoryItem item, bool folded)
        {
            if (!Owns(item) || !item.CanFold || (folded && item.HasBackpackContents)) return false;
            bool previous = item.IsFolded;
            try { item.SetFolded(folded); return FitsWidth(item.CurrentSize); }
            finally { item.SetFolded(previous); }
        }

        public bool TrySetFolded(InventoryItem item, bool folded)
        {
            if (!CanSetFolded(item, folded)) return false;
            if (item.IsFolded == folded) return true;
            bool previous = item.IsFolded;
            if (!item.ToggleFold(contentsEmpty: !item.HasBackpackContents)) return false;
            try { RebuildLayout(); }
            catch { item.SetFolded(previous); throw; }
            return true;
        }

        /// <summary>Run after completed operations, never on OnItemRemoved (rollback may follow).</summary>
        public bool Synchronize(bool flushContents = false)
        {
            if (IsDisposed) return false;
            bool changed = false;
            bool layoutChanged = Controller.GetItemCount() != _entries.Count;
            bool copyContents = flushContents || Controller.IsDirty;
            for (int i = _entries.Count - 1; i >= 0; i--)
            {
                var entry = _entries[i];
                var item = Controller.GetItemByInstanceID(entry.Item.InstanceID);
                if (entry.World == null || !entry.World.gameObject.activeInHierarchy)
                {
                    if (item != null) Controller.RemoveItem(item);
                    RemoveEntry(i);
                    changed = true;
                    layoutChanged = true;
                    continue;
                }
                if (item == null)
                {
                    // Destroy is deferred in Unity. Deactivation excludes the old
                    // owner from a save or another physics query in this frame.
                    entry.World.gameObject.SetActive(false);
                    UnityEngine.Object.Destroy(entry.World.gameObject);
                    RemoveEntry(i);
                    changed = true;
                    layoutChanged = true;
                    continue;
                }
                var world = entry.World;
                if (!FitsWidth(item.CurrentSize))
                {
                    item.SetFolded(entry.PackedFolded);
                    item.RestoreRotationState(entry.PackedRotation);
                }
                if (entry.PackedSize != item.CurrentSize)
                {
                    // An atomic drag merge can already have rebound its rotated
                    // remainder at the original root. Keep that valid placement
                    // instead of running first-fit packing over the whole session.
                    var bound = Controller.GetActualFootprint(item);
                    bool placed = bound.width == item.CurrentSize.x && bound.height == item.CurrentSize.y;
                    for (int y = 0; placed && y < bound.height; y++)
                    for (int x = 0; x < bound.width; x++)
                        if (!ReferenceEquals(Controller.GetItemAt(bound.x + x, bound.y + y), item))
                        { placed = false; break; }
                    if (placed) entry.PackedSize = item.CurrentSize;
                    else layoutChanged = true;
                }
                if (entry.Quantity != item.Quantity)
                {
                    Controller.RefreshItemInData(item);
                    entry.Quantity = item.Quantity;
                    changed = true;
                }
                if (entry.PackedRotation != item.RotationAngle || entry.PackedFolded != item.IsFolded)
                {
                    Controller.RefreshItemInData(item);
                    entry.PackedRotation = item.RotationAngle;
                    entry.PackedFolded = item.IsFolded;
                    changed = true;
                }
                bool visualChanged = world.IsRotated != item.IsRotated || world.IsFolded != item.IsFolded;
                changed |= world.Quantity != item.Quantity || world.Durability != item.Durability ||
                    world.IsRotated != item.IsRotated || world.IsFolded != item.IsFolded ||
                    world.RemainingChargeSeconds != item.RemainingChargeSeconds || world.ChargePercent != item.ChargePercent;
                world.Quantity = item.Quantity;
                world.Durability = item.Durability;
                world.ChargePercent = item.ChargePercent;
                world.RemainingChargeSeconds = item.RemainingChargeSeconds;
                world.IsRotated = item.IsRotated;
                world.IsFolded = item.IsFolded;
                if (visualChanged)
                {
                    world.ApplyVisual(item.Data);
                    world.transform.rotation = Quaternion.Euler(0, 0, item.IsRotated ? -90f : 0f);
                }
                if (copyContents && item.Data.IsBackpack)
                    world.BackpackContents = Clone(item.GetBackpackSavedItems());
            }
            if (layoutChanged) RebuildLayout();
            Controller.IsDirty = false;
            return changed || layoutChanged;
        }

        private void RemoveEntry(int index)
        {
            _allowedIDs.Remove(_entries[index].Item.InstanceID);
            _items.Remove(_entries[index].Item);
            _entries.RemoveAt(index);
        }

        private static List<SavedItem> Clone(IReadOnlyList<SavedItem> items)
        {
            if (items == null) return null;
            var result = new List<SavedItem>(items.Count);
            for (int i = 0; i < items.Count; i++) result.Add(SavedItem.DeepClone(items[i]));
            return result;
        }

        public void Dispose()
        {
            if (IsDisposed) return;
            Synchronize(true);
            Controller.Dispose();
            _entries.Clear(); _items.Clear(); _allowedIDs.Clear();
            IsDisposed = true;
        }
    }
}
