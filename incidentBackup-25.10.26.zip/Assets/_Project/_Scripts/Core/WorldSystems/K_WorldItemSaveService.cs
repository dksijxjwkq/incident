using System.Collections.Generic;
using System.IO;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core.World
{
    /// <summary>
    /// Stage 4.5.1: сериализация всех K_WorldItem в сцене.
    ///
    /// Stage 4.5.1b:
    ///   - Save фильтрует null-элементы из FindObjectsByType (устранение
    ///     count mismatch, когда объект удалён в том же кадре).
    ///   - Добавлено поле IsFolded в Save/Load (SchemaRevision → 4).
    /// </summary>
    public class K_WorldItemSaveService : MonoBehaviour, ISaveable
        , ISavePayloadValidator
    {
        public string SaveID => "WorldItems";
        public bool IsDirty { get; set; } = true;

        private const int MAX_WORLD_ITEMS = 100000;
        private const int MAX_NESTED_ITEMS = 100000;
        private const int MAX_BACKPACK_DEPTH = 32;
        private PreparedWorld _prepared;

        private sealed class PreparedWorld : System.IDisposable
        {
            public GameObject Root;
            public string Fingerprint;
            public readonly List<K_WorldItem> Items = new List<K_WorldItem>();
            public void Dispose()
            {
                foreach (var item in Items)
                    if (item != null) { item.gameObject.SetActive(false); Destroy(item.gameObject); }
                Items.Clear();
                if (Root != null) { Destroy(Root); Root = null; }
            }
        }

        private struct PendingWorldItem
        {
            public SavedItem Item;
            public Vector3 Position;
            public float RotationY;
        }

        private void Start()
        {
            K_SaveManager.Instance?.Register(this);
        }

        private void OnDestroy()
        {
            _prepared?.Dispose();
            _prepared = null;
            K_SaveManager.Instance?.Unregister(this);
        }

        // =====================================================================
        // SAVE
        // =====================================================================
        public void Save(BinaryWriter writer)
        {
            // Stage 4.5.1b: фильтруем null, чтобы writer.Write(count) и тело
            // цикла были согласованы (иначе Load падает с count mismatch).
            var found = FindObjectsByType<K_WorldItem>(FindObjectsSortMode.None);
            var items = new List<K_WorldItem>(found != null ? found.Length : 0);
            if (found != null)
            {
                for (int i = 0; i < found.Length; i++)
                    if (found[i] != null) items.Add(found[i]);
            }

            writer.Write(items.Count);
            if (items.Count == 0) { IsDirty = false; return; }

            for (int i = 0; i < items.Count; i++)
            {
                var it = items[i]; // гарантированно не null

                writer.Write(it.ItemID ?? string.Empty);
                writer.Write(it.InstanceID);
                writer.Write(it.Quantity);
                writer.Write(it.Durability);
                writer.Write(it.ChargePercent);
                writer.Write(it.RemainingChargeSeconds);
                writer.Write(it.IsRotated);
                // Stage 4.5.1b: свёрнутое состояние.
                writer.Write(it.IsFolded);

                Vector3 p = it.transform.position;
                writer.Write(p.x);
                writer.Write(p.y);
                writer.Write(p.z);
                writer.Write(it.transform.eulerAngles.y);

                bool hasContents = it.BackpackContents != null && it.BackpackContents.Count > 0;
                writer.Write(hasContents);
                if (hasContents)
                {
                    writer.Write(it.BackpackContents.Count);
                    for (int j = 0; j < it.BackpackContents.Count; j++)
                        WriteSavedItemRecursive(writer, it.BackpackContents[j]);
                }
            }

            IsDirty = false;
        }

        private void WriteSavedItemRecursive(BinaryWriter writer, SavedItem item)
        {
            writer.Write(item.ItemID);
            writer.Write(item.InstanceID);
            writer.Write(item.X);
            writer.Write(item.Y);
            writer.Write(item.Quantity);
            writer.Write(item.Durability);
            writer.Write(item.IsRotated);
            writer.Write(item.IsFolded);
            writer.Write(Mathf.Clamp(item.ChargePercent, 0, 100));
            writer.Write(item.RemainingChargeSeconds);

            int contentsCount = item.BackpackContents?.Count ?? 0;
            writer.Write(contentsCount);
            if (contentsCount > 0)
            {
                for (int i = 0; i < item.BackpackContents.Count; i++)
                    WriteSavedItemRecursive(writer, item.BackpackContents[i]);
            }
        }

        // =====================================================================
        // LOAD
        // =====================================================================
        public void Load(BinaryReader reader)
        {
            uint maxInstanceID;
            var pending = ReadWorldItems(reader, out maxInstanceID);
            string fingerprint = WorldFingerprint(pending);
            var replacement = _prepared;
            if (replacement == null || replacement.Fingerprint != fingerprint)
            {
                replacement?.Dispose();
                replacement = PrepareReplacement(pending, fingerprint);
            }
            _prepared = null;
            try
            {
                var existing = FindObjectsByType<K_WorldItem>(FindObjectsSortMode.None);
                // Every replacement and all templates are valid before the first old owner is removed.
                if (maxInstanceID > 0) GlobalIDManager.ObserveID(maxInstanceID);
                if (existing != null)
                    foreach (var item in existing)
                        if (item != null) { item.gameObject.SetActive(false); Destroy(item.gameObject); }
                foreach (var item in replacement.Items)
                {
                    item.transform.SetParent(null, true);
                    item.gameObject.SetActive(true);
                }
                replacement.Items.Clear();
                IsDirty = false;
            }
            finally { replacement.Dispose(); }
        }

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            uint ignored;
            var pending = ReadWorldItems(reader, out ignored);
            var database = K_InventorySetup.DatabaseInstance;
            foreach (var record in pending)
                InventoryLoadReader.ValidateItemTree(record.Item, database, context, SaveID);
            _prepared?.Dispose();
            var prepared = PrepareReplacement(pending, WorldFingerprint(pending));
            _prepared = prepared;
            context.OnFinished(() =>
            {
                if (ReferenceEquals(_prepared, prepared)) _prepared = null;
                prepared.Dispose();
            });
        }

        private PreparedWorld PrepareReplacement(List<PendingWorldItem> pending, string fingerprint)
        {
            var prepared = new PreparedWorld { Fingerprint = fingerprint };
            try
            {
                var database = K_InventorySetup.DatabaseInstance;
                if (pending.Count > 0 && database == null)
                    throw new InvalidDataException("World replacement requires the item database.");
                prepared.Root = new GameObject("WorldLoad_Staging");
                prepared.Root.SetActive(false);
                using (var context = new SaveLoadValidationContext())
                {
                    foreach (var record in pending)
                    {
                        InventoryLoadReader.ValidateItemTree(record.Item, database, context, SaveID);
                        var data = database.GetItemData(record.Item.ItemID);
                        prepared.Items.Add(K_WorldItemSpawner.SpawnInactiveForLoad(data, record.Item,
                            record.Position, record.RotationY, prepared.Root.transform));
                    }
                }
                return prepared;
            }
            catch { prepared.Dispose(); throw; }
        }

        private static string WorldFingerprint(List<PendingWorldItem> pending)
        {
            var items = new List<SavedItem>(pending.Count);
            var positions = new System.Text.StringBuilder();
            foreach (var record in pending)
            {
                items.Add(record.Item);
                positions.Append(record.Item.InstanceID).Append(':')
                    .Append(record.Position.x.ToString("R", System.Globalization.CultureInfo.InvariantCulture)).Append(',')
                    .Append(record.Position.y.ToString("R", System.Globalization.CultureInfo.InvariantCulture)).Append(',')
                    .Append(record.Position.z.ToString("R", System.Globalization.CultureInfo.InvariantCulture)).Append(',')
                    .Append(record.RotationY.ToString("R", System.Globalization.CultureInfo.InvariantCulture)).Append(';');
            }
            return InventoryLoadReader.Fingerprint(items) + "|" + positions;
        }

        private List<PendingWorldItem> ReadWorldItems(BinaryReader reader, out uint maxInstanceID)
        {
            int count = reader.ReadInt32();
            if (count < 0 || count > MAX_WORLD_ITEMS)
                throw new InvalidDataException("[K_WorldItemSaveService] Invalid world-item count.");

            var pending = new List<PendingWorldItem>(count);
            int remainingNestedItems = MAX_NESTED_ITEMS;
            maxInstanceID = 0;
            for (int i = 0; i < count; i++)
            {
                var item = new SavedItem
                {
                    ItemID = reader.ReadString(),
                    InstanceID = reader.ReadUInt32(),
                    Quantity = reader.ReadInt32(),
                    Durability = reader.ReadInt32(),
                    ChargePercent = reader.ReadInt32(),
                    RemainingChargeSeconds = K_SaveManager.LoadedSchemaRevision >= 5
                        ? reader.ReadSingle() : -1f
                };
                ValidatePendingID(item.InstanceID, ref maxInstanceID);
                ValidateChargeDuration(item.RemainingChargeSeconds);
                item.IsRotated = reader.ReadBoolean();
                item.IsFolded = reader.ReadBoolean();

                var position = new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
                float rotationY = reader.ReadSingle();
                if (!IsFinite(position.x) || !IsFinite(position.y) || !IsFinite(position.z) || !IsFinite(rotationY))
                    throw new InvalidDataException("[K_WorldItemSaveService] Invalid world-item position or rotation.");

                if (reader.ReadBoolean())
                {
                    int contentsCount = reader.ReadInt32();
                    ValidateContentsCount(contentsCount, remainingNestedItems);
                    item.BackpackContents = new List<SavedItem>(contentsCount);
                    for (int j = 0; j < contentsCount; j++)
                        item.BackpackContents.Add(ReadSavedItemRecursive(reader, 0,
                            ref remainingNestedItems, ref maxInstanceID));
                }
                pending.Add(new PendingWorldItem { Item = item, Position = position, RotationY = rotationY });
            }

            // Revision 4 shares its stream with later sections; revisions 5/6 have isolated payloads.
            if (K_SaveManager.LoadedSchemaRevision >= 5 && reader.BaseStream.Position != reader.BaseStream.Length)
                throw new InvalidDataException("[K_WorldItemSaveService] Unexpected trailing world-item data.");
            using (var identities = new SaveLoadValidationContext())
                foreach (var record in pending) ValidateUniqueTree(record.Item, identities);
            return pending;
        }

        private static void ValidateUniqueTree(SavedItem item, SaveLoadValidationContext identities)
        {
            identities.Own(item.InstanceID, "WorldItems");
            if (item.BackpackContents != null)
                foreach (var child in item.BackpackContents) ValidateUniqueTree(child, identities);
        }

        private SavedItem ReadSavedItemRecursive(BinaryReader reader, int depth,
            ref int remainingNestedItems, ref uint maxInstanceID)
        {
            if (depth > MAX_BACKPACK_DEPTH || remainingNestedItems <= 0)
                throw new InvalidDataException("[K_WorldItemSaveService] Backpack contents exceed load limits.");
            remainingNestedItems--;
            var item = new SavedItem
            {
                ItemID = reader.ReadString(),
                InstanceID = reader.ReadUInt32(),
                X = reader.ReadInt32(),
                Y = reader.ReadInt32(),
                Quantity = Mathf.Max(1, reader.ReadInt32()),
                Durability = Mathf.Max(0, reader.ReadInt32()),
                IsRotated = reader.ReadBoolean(),
                IsFolded = reader.ReadBoolean(),
                ChargePercent = Mathf.Clamp(reader.ReadInt32(), 0, 100)
            };
            // The nested layout already contained exact seconds in revision 4.
            item.RemainingChargeSeconds = reader.ReadSingle();
            ValidatePendingID(item.InstanceID, ref maxInstanceID);
            ValidateChargeDuration(item.RemainingChargeSeconds);
            if (item.X < 0 || item.Y < 0)
                throw new InvalidDataException("[K_WorldItemSaveService] Invalid backpack item position.");

            int contentsCount = reader.ReadInt32();
            ValidateContentsCount(contentsCount, remainingNestedItems);
            if (contentsCount > 0)
            {
                item.BackpackContents = new List<SavedItem>(contentsCount);
                for (int j = 0; j < contentsCount; j++)
                    item.BackpackContents.Add(ReadSavedItemRecursive(reader, depth + 1,
                        ref remainingNestedItems, ref maxInstanceID));
            }
            return item;
        }

        private static void ValidateContentsCount(int count, int remainingNestedItems)
        {
            if (count < 0 || count > remainingNestedItems)
                throw new InvalidDataException("[K_WorldItemSaveService] Invalid backpack contents count.");
        }

        private static void ValidatePendingID(uint instanceID, ref uint maxInstanceID)
        {
            // Match GlobalIDManager.ObserveID without mutating its state during parsing.
            if (instanceID == 0 || instanceID == uint.MaxValue)
                throw new InvalidDataException("[K_WorldItemSaveService] Invalid world-item instance ID.");
            if (instanceID > maxInstanceID) maxInstanceID = instanceID;
        }

        private static void ValidateChargeDuration(float duration)
        {
            if (!IsFinite(duration) || (duration < 0f && duration != -1f))
                throw new InvalidDataException("[K_WorldItemSaveService] Invalid world-item charge duration.");
        }

        private static bool IsFinite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
