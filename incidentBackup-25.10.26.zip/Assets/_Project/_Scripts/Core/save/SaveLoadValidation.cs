using System;
using System.Collections.Generic;
using System.IO;

namespace K_Incident.Core
{
    /// <summary>Reads a payload without changing its live owner, callbacks or ID allocator.</summary>
    public interface ISavePayloadValidator
    {
        void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context);
    }

    public sealed class SaveLoadValidationContext : IDisposable
    {
        private readonly Dictionary<uint, string> _owners = new Dictionary<uint, string>();
        private readonly List<Action> _cleanup = new List<Action>();
        private string _backpackProjection;
        private string _equippedBackpack;

        public void Own(uint id, string source)
        {
            if (id == 0 || id == uint.MaxValue)
                throw new InvalidDataException("Invalid item identity in " + source + ".");
            if (_owners.TryGetValue(id, out var previous))
                throw new InvalidDataException($"Duplicate item identity {id}: {previous} / {source}.");
            _owners.Add(id, source);
        }

        public void RecordBackpackProjection(string fingerprint) => _backpackProjection = fingerprint;
        public void RecordEquippedBackpack(string fingerprint) => _equippedBackpack = fingerprint;
        public void OnFinished(Action cleanup) => _cleanup.Add(cleanup ?? throw new ArgumentNullException(nameof(cleanup)));

        public void Validate()
        {
            // Player_Backpack is a projection, never a second owner of the equipment subtree.
            if (_backpackProjection != null &&
                !string.Equals(_backpackProjection, _equippedBackpack ?? string.Empty, StringComparison.Ordinal))
                throw new InvalidDataException("Player_Backpack does not match the equipped backpack contents.");
        }

        public void Dispose()
        {
            var errors = new List<Exception>();
            for (int i = _cleanup.Count - 1; i >= 0; i--)
                try { _cleanup[i](); } catch (Exception error) { errors.Add(error); }
            _cleanup.Clear();
            if (errors.Count > 0) throw new AggregateException("Save staging cleanup failed.", errors);
        }

        public static float ReadFinite(BinaryReader reader, bool nonnegative = false)
        {
            float value = reader.ReadSingle();
            if (float.IsNaN(value) || float.IsInfinity(value) || (nonnegative && value < 0f))
                throw new InvalidDataException("Save contains an invalid floating-point value.");
            return value;
        }
    }
}
