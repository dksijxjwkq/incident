using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace K_Incident.Core
{
    public interface ISaveable
    {
        string SaveID { get; }
        bool IsDirty { get; set; }
        void Save(BinaryWriter writer);
        void Load(BinaryReader reader);
    }

    public interface IPreSave
    {
        void OnBeforeSave();
    }

    public interface IPostLoad
    {
        void OnAfterLoad();
    }

    public interface IPreLoad
    {
        void OnBeforeLoad();
    }

    public static class BinaryExtensions
    {
        public static void WriteVector3(this BinaryWriter writer, Vector3 vector)
        {
            writer.Write(vector.x);
            writer.Write(vector.y);
            writer.Write(vector.z);
        }
        public static Vector3 ReadVector3(this BinaryReader reader)
        {
            return new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
        }
    }

    public class K_SaveManager : MonoBehaviour
    {
        public static K_SaveManager Instance { get; private set; }

        // Stage 5.2: always write V10; retain V9 revision 4/5 readers for migration.
        public static int SaveVersion { get; private set; } = 10;

        // Revision 6 adds the framed CombatItemState graph; existing section layouts are unchanged.
        public const uint SchemaMarker = 0x34474D53;
        public const int SchemaRevision = 6;
        public static int LoadedSchemaRevision { get; private set; } = SchemaRevision;

        private static readonly string[] RequiredRevision6Sections =
        {
            "PlayerHealth", "PlayerBlood", "PlayerDebuffs", "PlayerVitality", "CombatItemState",
            "Player_Pocket1", "Player_Pocket2", "Player_Backpack", "Player_Equipment"
        };

        private string _savePath;
        private readonly List<ISaveable> _saveables = new List<ISaveable>();
        private bool _operationInProgress;
        private bool _loadOwnerBindingsLocked;

        private void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
            _savePath = Path.Combine(Application.persistentDataPath, "save_01.dat");
            Debug.Log($"[K_SaveManager] Save path: {Application.persistentDataPath}");
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null) return;
            if (keyboard.f5Key.wasPressedThisFrame) SaveGame();
            if (keyboard.f9Key.wasPressedThisFrame) LoadGame();
        }

        public void Register(ISaveable saveable)
        {
            if (saveable != null && !_saveables.Contains(saveable))
            {
                if (_loadOwnerBindingsLocked)
                    throw new InvalidOperationException("Save owner registration cannot change during load.");
                _saveables.Add(saveable);
            }
        }

        public void Unregister(ISaveable saveable)
        {
            if (saveable != null && _saveables.Contains(saveable))
            {
                if (_loadOwnerBindingsLocked)
                    throw new InvalidOperationException("Save owner registration cannot change during load.");
                _saveables.Remove(saveable);
            }
        }

        private void CleanupDeadReferences()
        {
            _saveables.RemoveAll(s => s == null || (s is MonoBehaviour mb && mb == null));
        }

        public void SaveGame()
        {
            if (_operationInProgress)
            {
                Debug.LogWarning("[K_SaveManager] Save ignored: another save/load operation is in progress.");
                return;
            }
            K_SplitStackDialog.CancelAll();
            _operationInProgress = true;
            try
            {
                CleanupDeadReferences();
                SaveVersion = 10;

                // Synchronize every live backpack before writing any root inventory.
                var saveables = _saveables.ToArray();
                foreach (var obj in saveables)
                    if (obj is IPreSave preparation) preparation.OnBeforeSave();

                string temporaryPath = _savePath + ".tmp";
                using (var stream = new FileStream(temporaryPath, FileMode.Create, FileAccess.Write, FileShare.None))
                using (var writer = new BinaryWriter(stream))
                {
                    writer.Write("INCIDENT_V10");
                    writer.Write(SchemaMarker);
                    writer.Write(SchemaRevision);
                    var ids = new HashSet<string>();
                    foreach (var obj in saveables)
                    {
                        if (obj != null)
                        {
                            if (string.IsNullOrEmpty(obj.SaveID) || !ids.Add(obj.SaveID))
                                throw new InvalidDataException($"Invalid or duplicate SaveID '{obj.SaveID}'.");

                            byte[] payload;
                            using (var payloadStream = new MemoryStream())
                            using (var payloadWriter = new BinaryWriter(payloadStream))
                            {
                                // Some serializers clear their own flag. Until the
                                // file is committed, retain the state needed to retry.
                                bool wasDirty = obj.IsDirty;
                                try { obj.Save(payloadWriter); }
                                finally { obj.IsDirty = wasDirty; }
                                payloadWriter.Flush();
                                payload = payloadStream.ToArray();
                            }
                            writer.Write(obj.SaveID);
                            writer.Write(payload.Length);
                            writer.Write(payload);
                        }
                    }
                    writer.Flush();
                    stream.Flush(true);
                }

                // A failed write leaves the previous successful save intact.
                if (File.Exists(_savePath))
                    File.Replace(temporaryPath, _savePath, _savePath + ".bak");
                else
                    File.Move(temporaryPath, _savePath);

                foreach (var obj in saveables) obj.IsDirty = false;
                Debug.Log($"[K_SaveManager] ✅ Save successful (V10, schema {SchemaRevision}). Objects saved: {saveables.Length}");
            }
            catch (Exception e)
            {
                Debug.LogError($"[K_SaveManager] ❌ Save Failed: {e.Message}");
            }
            finally { _operationInProgress = false; }
        }

        public void LoadGame()
        {
            if (_operationInProgress)
            {
                Debug.LogWarning("[K_SaveManager] Load ignored: another save/load operation is in progress.");
                return;
            }
            K_SplitStackDialog.CancelAll();
            if (!File.Exists(_savePath))
            {
                Debug.LogWarning("[K_SaveManager] No save file found.");
                return;
            }

            int previousVersion = SaveVersion;
            int previousRevision = LoadedSchemaRevision;
            bool loadCommitted = false;
            bool applyStarted = false;
            List<OwnerSnapshot> snapshots = null;
            K_Incident.Core.Inventory.GlobalIDManager.LoadAllocationScope allocationScope = null;
            _operationInProgress = true;
            try
            {
                CleanupDeadReferences();
                _loadOwnerBindingsLocked = true;

                using (BinaryReader reader = new BinaryReader(File.Open(_savePath, FileMode.Open)))
                {
                    string header = reader.ReadString();
                    bool legacyV9 = header == "INCIDENT_V9";
                    if (!legacyV9 && header != "INCIDENT_V10")
                    {
                        Debug.LogWarning($"[K_SaveManager] Unsupported save version '{header}'. V9 or V10 required. Starting new game.");
                        return;
                    }

                    if (reader.BaseStream.Length - reader.BaseStream.Position < sizeof(uint) + sizeof(int)
                        || reader.ReadUInt32() != SchemaMarker)
                    {
                        Debug.LogWarning("[K_SaveManager] Unsupported schema marker; save was not loaded.");
                        return;
                    }
                    int revision = reader.ReadInt32();
                    if ((legacyV9 && revision != 4 && revision != 5) || (!legacyV9 && revision != SchemaRevision))
                    {
                        Debug.LogWarning($"[K_SaveManager] Unsupported {header} schema {revision}; save was not loaded.");
                        return;
                    }

                    if (reader.BaseStream.Position >= reader.BaseStream.Length)
                        throw new InvalidDataException("Save contains no sections after its header and schema; current session was not loaded.");

                    SaveVersion = legacyV9 ? 9 : 10;
                    LoadedSchemaRevision = revision;

                    var loaded = new List<ISaveable>();
                    using (var validation = new SaveLoadValidationContext())
                    {
                    if (revision >= 5)
                    {
                        // Parse section boundaries before applying anything to the scene.
                        var sections = new List<(string id, byte[] payload, ISaveable owner)>();
                        var ids = new HashSet<string>();
                        while (reader.BaseStream.Position < reader.BaseStream.Length)
                        {
                            string id = reader.ReadString();
                            int length = reader.ReadInt32();
                            if (length < 0 || length > reader.BaseStream.Length - reader.BaseStream.Position
                                || !ids.Add(id))
                                throw new InvalidDataException($"Invalid save section '{id}'.");
                            sections.Add((id, reader.ReadBytes(length), null));
                        }

                        snapshots = CaptureSnapshots();
                        if (revision == SchemaRevision) ValidateRequiredSections(ids);
                        var sectionOwners = new HashSet<ISaveable>();
                        for (int i = 0; i < sections.Count; i++)
                        {
                            var section = sections[i];
                            var owner = ResolveSaveOwner(section.id);
                            if (owner != null && !sectionOwners.Add(owner))
                                throw new InvalidDataException($"Multiple sections resolve to save owner '{owner.SaveID}'.");
                            sections[i] = (section.id, section.payload, owner);
                            ValidateSection(section.id, section.payload, owner, validation);
                        }
                        validation.Validate();
                        allocationScope = K_Incident.Core.Inventory.GlobalIDManager.BeginLoadAllocationScope();
                        applyStarted = true;
                        PrepareForLoad();
                        // Equipment reconstructs the worn backpack after the root grids.
                        foreach (var section in sections)
                            if (section.id != "Player_Equipment") LoadSection(section.id, section.payload, section.owner, loaded);
                        foreach (var section in sections)
                            if (section.id == "Player_Equipment") LoadSection(section.id, section.payload, section.owner, loaded);
                    }
                    else
                    {
                        snapshots = CaptureSnapshots();
                        ValidateLegacyAndRewind(reader, validation);
                        validation.Validate();
                        allocationScope = K_Incident.Core.Inventory.GlobalIDManager.BeginLoadAllocationScope();
                        applyStarted = true;
                        PrepareForLoad();
                        // Legacy revision 4 has no section lengths; preserve its layout.
                        while (reader.BaseStream.Position < reader.BaseStream.Length)
                        {
                            string id = reader.ReadString();
                            ISaveable target = ResolveSaveOwner(id, true);
                            if (target == null)
                                throw new InvalidDataException($"Unknown legacy SaveID '{id}'; its payload cannot be skipped safely.");
                            target.Load(reader);
                            loaded.Add(target);
                        }
                    }

                    foreach (var obj in loaded)
                        if (obj is IPostLoad completion) completion.OnAfterLoad();
                    }
                    allocationScope.Commit();
                    loadCommitted = true;
                    Debug.Log($"[K_SaveManager] ✅ Load completed (V{SaveVersion}, schema {revision}). Loaded {loaded.Count} objects.");
                }
            }
            catch (Exception e)
            {
                if (applyStarted && snapshots != null)
                {
                    try
                    {
                        RestoreSnapshots(snapshots);
                        Debug.LogError($"[K_SaveManager] ❌ Load Failed, rolled back to previous state (persistable only): {e.Message}");
                    }
                    catch (Exception rollbackError)
                    {
                        Debug.LogError($"[K_SaveManager] CRITICAL: Load Failed and rollback failed; live state is unknown. Load: {e.Message}; rollback: {rollbackError}");
                    }
                }
                else Debug.LogError($"[K_SaveManager] ❌ Load Failed: {e.Message}");
            }
            finally
            {
                DisposeSnapshots(snapshots);
                allocationScope?.Dispose();
                if (!loadCommitted)
                {
                    SaveVersion = previousVersion;
                    LoadedSchemaRevision = previousRevision;
                }
                _operationInProgress = false;
                _loadOwnerBindingsLocked = false;
            }
        }

        private sealed class OwnerSnapshot
        {
            public ISaveable Owner;
            public string SaveID;
            public bool WasDirty;
            public K_Incident.Core.Inventory.InventoryData InventoryData;
            public bool DataWasDirty;
            public byte[] Payload;
        }

        // Iteration 8a, agreed contract: rollback covers persistable state only.
        // Heal boosts, stimulant phases, painkiller timers, in-progress medical
        // applies and backpack-window positions are deliberately not restored.
        // Capture happens BEFORE PrepareForLoad; after apply begins, cancelled
        // sessions and closed windows stay cancelled/closed after rollback.
        private List<OwnerSnapshot> CaptureSnapshots()
        {
            var snapshots = new List<OwnerSnapshot>(_saveables.Count);
            var ids = new HashSet<string>(StringComparer.Ordinal);
            foreach (var owner in _saveables.ToArray())
            {
                if (string.IsNullOrEmpty(owner.SaveID) || !ids.Add(owner.SaveID))
                    throw new InvalidDataException($"Invalid or duplicate live SaveID '{owner.SaveID}'.");
                var controller = owner as K_Incident.Core.Inventory.InventoryController;
                if (owner is K_LootBox box) controller = box.InventoryController;
                var data = controller?.GetSaveData();
                snapshots.Add(new OwnerSnapshot
                {
                    Owner = owner, SaveID = owner.SaveID, WasDirty = owner.IsDirty,
                    InventoryData = data, DataWasDirty = data != null && data.IsDirty
                });
            }
            int sourceVersion = SaveVersion;
            int sourceRevision = LoadedSchemaRevision;
            bool captured = false;
            try
            {
                // Save writers emit the current payload even when the last load was V9.
                SaveVersion = 10;
                LoadedSchemaRevision = SchemaRevision;
                // Equipment.Save synchronizes open-backpack DTOs. Run it before any
                // grid serializer, without IPreSave (which would cancel an active drag).
                foreach (var snapshot in snapshots)
                    if (snapshot.SaveID == "Player_Equipment") CaptureSnapshot(snapshot);
                foreach (var snapshot in snapshots)
                    if (snapshot.SaveID != "Player_Equipment") CaptureSnapshot(snapshot);
                captured = true;
                return snapshots;
            }
            finally
            {
                // Writers may clear their own flag or dirty a synchronized root DTO.
                try
                {
                    foreach (var snapshot in snapshots)
                    {
                        snapshot.Owner.IsDirty = snapshot.WasDirty;
                        if (snapshot.InventoryData != null) snapshot.InventoryData.IsDirty = snapshot.DataWasDirty;
                    }
                }
                finally
                {
                    SaveVersion = sourceVersion;
                    LoadedSchemaRevision = sourceRevision;
                    if (!captured) DisposeSnapshots(snapshots);
                }
            }
        }

        private static void CaptureSnapshot(OwnerSnapshot snapshot)
        {
            using (var stream = new MemoryStream())
            using (var writer = new BinaryWriter(stream))
            {
                if (snapshot.Owner is PlayerEquipmentSaveService equipment)
                    equipment.SaveForRollbackSnapshot(writer);
                else if (snapshot.Owner is K_LootBox box)
                    box.SaveForRollbackSnapshot(writer);
                else snapshot.Owner.Save(writer);
                writer.Flush();
                snapshot.Payload = stream.ToArray();
            }
        }

        private static void RestoreSnapshots(List<OwnerSnapshot> snapshots)
        {
            SaveVersion = 10;
            LoadedSchemaRevision = SchemaRevision;
            var restored = new List<ISaveable>();
            var errors = new List<Exception>();
            // Preload and callbacks may change owners whose section was optional or
            // had not yet loaded. Restore EVERY captured owner, equipment last.
            foreach (var snapshot in snapshots)
                if (snapshot.SaveID != "Player_Equipment") RestoreSnapshot(snapshot, restored, errors);
            foreach (var snapshot in snapshots)
                if (snapshot.SaveID == "Player_Equipment") RestoreSnapshot(snapshot, restored, errors);
            foreach (var owner in restored)
            {
                try { if (owner is IPostLoad completion) completion.OnAfterLoad(); }
                catch (Exception error) { errors.Add(new InvalidOperationException($"Rollback post-load '{owner.SaveID}' failed.", error)); }
            }
            foreach (var snapshot in snapshots)
            {
                try
                {
                    snapshot.Owner.IsDirty = snapshot.WasDirty;
                    if (snapshot.InventoryData != null) snapshot.InventoryData.IsDirty = snapshot.DataWasDirty;
                }
                catch (Exception error) { errors.Add(error); }
            }
            if (errors.Count > 0) throw new AggregateException("Persistable rollback did not complete.", errors);
        }

        private static void RestoreSnapshot(OwnerSnapshot snapshot, List<ISaveable> restored, List<Exception> errors)
        {
            try
            {
                using (var reader = new BinaryReader(new MemoryStream(snapshot.Payload, false)))
                {
                    snapshot.Owner.Load(reader);
                    if (reader.BaseStream.Position != reader.BaseStream.Length)
                        throw new InvalidDataException("Snapshot payload was not fully consumed.");
                }
                restored.Add(snapshot.Owner);
            }
            catch (Exception error)
            {
                errors.Add(new InvalidOperationException($"Rollback load '{snapshot.SaveID}' failed.", error));
            }
        }

        private static void DisposeSnapshots(List<OwnerSnapshot> snapshots)
        {
            if (snapshots == null) return;
            foreach (var snapshot in snapshots) snapshot.Payload = null;
            snapshots.Clear();
        }

        private void ValidateSection(string id, byte[] payload, ISaveable target, SaveLoadValidationContext context)
        {
            if (target == null) return; // Unknown framed optional sections retain the existing skip policy.
            if (!(target is ISavePayloadValidator validator))
                throw new InvalidDataException($"Save owner '{id}' does not provide non-mutating load validation.");
            using (var reader = new BinaryReader(new MemoryStream(payload, false)))
            {
                validator.ValidateLoad(reader, context);
                if (reader.BaseStream.Position != reader.BaseStream.Length)
                    throw new InvalidDataException($"Save section '{id}' was not fully consumed during validation.");
            }
        }

        private void ValidateLegacyAndRewind(BinaryReader reader, SaveLoadValidationContext context)
        {
            long start = reader.BaseStream.Position;
            var ids = new HashSet<string>();
            try
            {
                while (reader.BaseStream.Position < reader.BaseStream.Length)
                {
                    string id = reader.ReadString();
                    ISaveable target = ResolveSaveOwner(id);
                    if (!ids.Add(id) || !(target is ISavePayloadValidator validator))
                        throw new InvalidDataException($"Unknown, duplicate or unvalidated legacy SaveID '{id}'.");
                    validator.ValidateLoad(reader, context);
                }
            }
            finally { reader.BaseStream.Position = start; }
        }

        private void LoadSection(string id, byte[] payload, ISaveable target, List<ISaveable> loaded)
        {
            if (target == null)
            {
                Debug.LogWarning($"[K_SaveManager] ⚠ Unknown SaveID '{id}' — section skipped.");
                return;
            }
            if (target is K_LootBox box && string.Equals(box.LegacySaveID, id, StringComparison.Ordinal))
                Debug.LogWarning("[LootBox] Loaded via legacy sibling-index; set authoredId for stability");
            using (var payloadReader = new BinaryReader(new MemoryStream(payload, false)))
            {
                target.Load(payloadReader);
                if (payloadReader.BaseStream.Position != payloadReader.BaseStream.Length)
                    throw new InvalidDataException($"Save section '{id}' was not fully consumed.");
            }
            loaded.Add(target);
        }

        private void PrepareForLoad()
        {
            foreach (var obj in _saveables.ToArray())
                if (obj is IPreLoad preparation) preparation.OnBeforeLoad();
        }

        private void ValidateRequiredSections(HashSet<string> sectionIds)
        {
            foreach (string id in RequiredRevision6Sections)
            {
                if (!sectionIds.Contains(id))
                    throw new InvalidDataException($"Missing required section: {id}");
                if (ResolveSaveOwner(id) == null)
                    throw new InvalidDataException($"Required save owner is not registered: {id}");
            }
        }

        private ISaveable ResolveSaveOwner(string id, bool warnLegacy = false)
        {
            ISaveable target = null;
            bool legacy = false;
            foreach (var candidate in _saveables)
            {
                if (candidate == null) continue;
                bool exact = string.Equals(candidate.SaveID, id, StringComparison.Ordinal);
                bool alias = candidate is K_LootBox box
                    && string.Equals(box.LegacySaveID, id, StringComparison.Ordinal);
                if (!exact && !alias) continue;
                if (target != null && !ReferenceEquals(target, candidate))
                    throw new InvalidDataException($"Ambiguous save owner or legacy alias: {id}");
                target = candidate;
                legacy = alias;
            }
            if (warnLegacy && legacy)
                Debug.LogWarning("[LootBox] Loaded via legacy sibling-index; set authoredId for stability");
            return target;
        }
    }
}
