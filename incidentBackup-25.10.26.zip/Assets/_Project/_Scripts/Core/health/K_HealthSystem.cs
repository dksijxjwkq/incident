﻿﻿using System;
using System.IO;
using System.Collections.Generic;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core
{
    public enum BodyPart
    {
        Head = 0,
        Chest = 1,
        Stomach = 2,
        Pelvis = 3,
        LeftShoulder = 4,
        RightShoulder = 5,
        LeftBiceps = 6,
        RightBiceps = 7,
        LeftForearm = 8,
        RightForearm = 9,
        LeftHand = 10,
        RightHand = 11,
        LeftQuadriceps = 12,
        RightQuadriceps = 13,
        LeftKnee = 14,
        RightKnee = 15,
        LeftShin = 16,
        RightShin = 17,
        LeftFoot = 18,
        RightFoot = 19
    }

    public enum DamageType
    {
        Generic, Firearm, Metabolism, Fall, Bleeding, Cold,
        // Stage 5.1: status commands. Existing source values 0..5 keep their IDs.
        Fracture = 6, Gunshot = 7, Laceration = 8, ExternalBleeding = 9,
        InternalBleeding = 10, Concussion = 11, TraumaticBrainInjury = 12
    }

    public class K_HealthSystem : MonoBehaviour, ISaveable, IPostLoad
        , ISavePayloadValidator
    {
        public event Action OnHealthChanged;
        public event Action<BodyPart, float, DamageType> OnDamageTaken;
        public event Action OnDeath;
        // Stage 5.1: HP-only contract; legacy OnDamageTaken retains its old semantics.
        public event Action<BodyPart, float, DamageType> OnSegmentDamageApplied;

        public string SaveID => "PlayerHealth";
        public bool IsDirty { get; set; } = true;
        public bool IsDead { get; private set; }

        // =====================================================================
        // КОНСТАНТЫ БАЛАНСА
        // 6.4.2: PASSIVE_HEAL_RATE удалён — заменён на SerializeField _passiveHealRate.
        // =====================================================================
        private const float FIREARM_SHOCK_DURATION = 10f;
        private const float UI_UPDATE_INTERVAL = 0.5f;
        private const int SEGMENT_COUNT = 20;
        private const float COAGULANT_DURATION = 420f;
        private const int COAGULANT_SEGMENT_TAIL_MARKER = 0x38414743; // "CGA8"
        private const int COAGULANT_TAIL_BYTES = 4 * sizeof(int) + 2 * SEGMENT_COUNT * sizeof(float);
        private const float JETT_DURATION = 420f;
        // Stage 1: удалены FIREARM_FRACTURE_CHANCE, LACERATION_HEAL_PENALTY, LIMB_HP_FLOOR.
        // Причины: авто-фрактура от оружия переносится в Stage 5 (матрица оружия);
        //           LACERATION_HEAL_PENALTY противоречит спеке ч.10.3 (равномерная регенерация);
        //           LIMB_HP_FLOOR больше не используется (старый cold-алгоритм удалён).

        // =====================================================================
        // БАЗОВЫЕ HP (index = (int)BodyPart)
        // =====================================================================
        [Header("Base HP (per segment, index = (int)BodyPart)")]
        [SerializeField]
        private float[] _baseHP = new float[SEGMENT_COUNT]
        {
            30f, // Head
            60f, // Chest
            45f, // Stomach
            45f, // Pelvis
            25f, // L Shoulder
            25f, // R Shoulder
            30f, // L Biceps
            30f, // R Biceps
            25f, // L Forearm
            25f, // R Forearm
            15f, // L Hand
            15f, // R Hand
            35f, // L Quadriceps
            35f, // R Quadriceps
            25f, // L Knee
            25f, // R Knee
            30f, // L Shin
            30f, // R Shin
            20f, // L Foot
            20f  // R Foot
        };

        [Header("Can Fracture (per segment)")]
        [SerializeField]
        private bool[] _canFracture = new bool[SEGMENT_COUNT]
        {
            true,  // Head      (было false)
            true,  // Chest
            false, // Stomach   (единственное исключение)
            true,  // Pelvis
            true, true,   // Shoulders
            true, true,   // Biceps
            true, true,   // Forearms
            true, true,   // Hands     (было false)
            true, true,   // Quadriceps
            true, true,   // Knees
            true, true,   // Shins
            true, true    // Feet      (было false)
        };

        // =====================================================================
        // СЕГМЕНТЫ (runtime)
        // =====================================================================
        [Header("Segments (runtime)")]
        [SerializeField] private BodySegment[] _segments = new BodySegment[SEGMENT_COUNT];
        [SerializeField] private LimbStatus[] _limbStatuses = new LimbStatus[SEGMENT_COUNT];
        [SerializeField] private bool[] _fractured = new bool[SEGMENT_COUNT];
        [SerializeField] private bool[] _splinted = new bool[SEGMENT_COUNT];
        [SerializeField] private bool[] _gunshot = new bool[SEGMENT_COUNT];   // NEW

        // Stage 1 §4.2: счётчик применений бинта на сегмент.
        // Сбрасывается при любом изменении bleedingLevel НЕ через бинт.
        [SerializeField] private int[] _bandageCounter = new int[SEGMENT_COUNT];

        // Stage 2 §4.5: внутреннее кровотечение.
        [SerializeField] private bool[] _internalBleeding = new bool[SEGMENT_COUNT];
        [SerializeField] private bool[] _internalBleedingRevealed = new bool[SEGMENT_COUNT];
        [SerializeField] private float[] _internalBleedingRevealTimer = new float[SEGMENT_COUNT];

        // Stage 3: временные эффекты лечения IB; в Save V7 не входят.
        private float[] _ibDrainMultiplier = new float[SEGMENT_COUNT];
        private float[] _ibDrainMultiplierTimer = new float[SEGMENT_COUNT];
        private float[] _ibBlockTimer = new float[SEGMENT_COUNT];

        [SerializeField] private float _shockTimer = 0f;

        // =====================================================================
        // Этап 9: Laceration
        // =====================================================================
        [Header("Laceration (Этап 9)")]
        [SerializeField, Range(1, 3),
         Tooltip("Уровень кровотечения, который возвращается на сегмент при разрыве клея прыжком.")]
        private int _glueTearBleedingLevel = 1;

        // =====================================================================
        // PASSIVE HEALING (6.4.2: const → SerializeField)
        // =====================================================================
        [Header("Passive Healing")]
        [SerializeField, Min(0f), Tooltip("Пассивный хил, HP/сек на сегмент (до boost-множителя).")]
        private float _passiveHealRate = 0.0167f;

        [SerializeField, Min(0f), Tooltip("Минимальный Hunger для работы пассивного хила.")]
        private float _passiveHealMinHunger = 25f;

        [SerializeField, Min(0f), Tooltip("Минимальный Thirst для работы пассивного хила.")]
        private float _passiveHealMinThirst = 25f;

        // =====================================================================
        // HEAL BOOST — гель / аптечка HP (6.4.2)
        // =====================================================================
        [Header("Heal Boost (гель)")]
        [SerializeField, Min(1f), Tooltip("Множитель пассивного хила при активном HealBoost.")]
        private float _healBoostMultiplier = 5f;

        [SerializeField, Min(0f), Tooltip("Длительность HealBoost по умолчанию (fallback, если из БД пришло 0).")]
        private float _healBoostDuration = 120f;

        // =====================================================================
        // КЭШИРОВАННЫЕ ССЫЛКИ
        // =====================================================================
        private K_VitalitySystem _cachedVitality;
        private K_DebuffSystem _cachedDebuffs;                          // 6.4.2
        private float[] _healBoostTimers = new float[SEGMENT_COUNT];    // 6.4.2
        private float _timeSinceLastUIUpdate = 0f;
        // Audit H08: a separate elapsed-time budget keeps distributed damage HUD
        // updates independent of passive healing and allows the first update at once.
        private float _distributedDamageNotifyTimer = UI_UPDATE_INTERVAL;
        private float _distributedDamageNotifySampleTime = float.NaN;
        private float[] _pendingLoadedHP;

        // Stage 4: one owner for applied devices and exact remaining-charge timers.
        private K_AppliedMedicalManager _appliedMedical;
        public K_AppliedMedicalManager AppliedMedical => _appliedMedical;


       private bool _runtimeInitialized;
        private static readonly BodyPart[] LeftArmChain =
        {
            BodyPart.LeftShoulder, BodyPart.LeftBiceps,
            BodyPart.LeftForearm, BodyPart.LeftHand
        };

        private static readonly BodyPart[] RightArmChain =
        {
            BodyPart.RightShoulder, BodyPart.RightBiceps,
            BodyPart.RightForearm, BodyPart.RightHand
        };

        private static readonly BodyPart[] LeftLegChain =
        {
            BodyPart.LeftQuadriceps, BodyPart.LeftKnee,
            BodyPart.LeftShin, BodyPart.LeftFoot
        };

        private static readonly BodyPart[] RightLegChain =
        {
            BodyPart.RightQuadriceps, BodyPart.RightKnee,
            BodyPart.RightShin, BodyPart.RightFoot
        };

        // =====================================================================
        // ЛОКАЛИЗОВАННЫЕ СТАТУСЫ КОНЕЧНОСТЕЙ
        // =====================================================================
        [System.Serializable]
        public struct LimbStatus
        {
            public int bleedingLevel;
            public LacerationType laceration;
        }

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
       private void OnValidate()
{
    NormalizeFractureEligibility();
    WarnSegmentBaseHPMismatches();
    if (!Application.isPlaying) return;
    if (!_runtimeInitialized) return;

    // Stage 1: вызовы FixZeroHPWithoutFracture и EnforceFractureHP удалены —
    // перелом больше не трогает HP, авто-фрактура от HP=0 отменена.
    ClampAllSegments();
    CheckDeathConditions();
    NotifyChange();
}

      private void Awake()
{
    NormalizeFractureEligibility();
    InitializeSegments();
    WarnSegmentBaseHPMismatches();
    // Stage 4: segments must exist before mechanical bleeding snapshots are captured.
    _appliedMedical = new K_AppliedMedicalManager();
    _appliedMedical.Initialize(this);
    _runtimeInitialized = true;   // после InitializeSegments — сегменты уже валидны
    _cachedVitality = GetComponent<K_VitalitySystem>();
    _cachedDebuffs  = GetComponent<K_DebuffSystem>();   // 6.4.2

    if (_cachedVitality == null)
        Debug.LogWarning("[K_HealthSystem] K_VitalitySystem not found!");
    else
        Debug.Log("[K_HealthSystem] K_VitalitySystem cached successfully");
}

        // The fracture rule is invariant, including scenes authored with the old mask.
        private void NormalizeFractureEligibility()
        {
            if (_canFracture == null || _canFracture.Length != SEGMENT_COUNT)
                _canFracture = new bool[SEGMENT_COUNT];
            for (int i = 0; i < SEGMENT_COUNT; i++)
                _canFracture[i] = i != (int)BodyPart.Stomach;
        }

        private void WarnSegmentBaseHPMismatches()
        {
            if (_baseHP == null || _segments == null) return;
            int count = Math.Min(SEGMENT_COUNT, Math.Min(_baseHP.Length, _segments.Length));
            for (int i = 0; i < count; i++)
            {
                var segment = _segments[i];
                if (segment == null || Mathf.Approximately(_baseHP[i], segment.OriginalMaxHP)) continue;
                Debug.LogWarning($"[K_HealthSystem] Segment {i} ({(BodyPart)i}) HP configuration mismatch: " +
                    $"_baseHP={_baseHP[i]}, OriginalMaxHP={segment.OriginalMaxHP}. " +
                    "Serialized segment was retained; review the authored HP configuration.");
            }
        }

        private void Start()
        {
            K_SaveManager.Instance?.Register(this);
        }

        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
        }

      private void Update()
{
    if (IsDead)
    {
        // Stage 4: late inventory Load reconciles frozen charge without advancing timers.
        _appliedMedical?.SynchronizeInventory();
        return;
    }
    // Stage 4: active devices drain only while the player is alive.
    // Tick also synchronizes precise inventory charge, so alive frames need one pass.
    _appliedMedical?.Tick(Time.deltaTime);

    if (_shockTimer > 0f)
    {
        _shockTimer -= Time.deltaTime;
        if (_shockTimer <= 0f) NotifyChange();
    }

    // ВЕТКА if (GetMaxBleedingLevel() > 0 && !IsShocked) { ApplyBleedingDamage(); } — УДАЛЕНА.
    // HP-урон от кровотечения теперь идёт через K_BloodSystem (только в состоянии Shock).

    // 6.4.2: тик heal-boost таймеров.
    if (_healBoostTimers != null)
    {
        float dt = Time.deltaTime;
        for (int i = 0; i < SEGMENT_COUNT; i++)
        {
            if (_healBoostTimers[i] > 0f)
                _healBoostTimers[i] = Mathf.Max(0f, _healBoostTimers[i] - dt);
        }
    }

    // Stage 2 §4.5: активность влияет на дренаж, но не на reveal-таймеры.
    bool ibChanged = false;
    float dtIB = Time.deltaTime;
    for (int i = 0; i < SEGMENT_COUNT; i++)
    {
        if (_ibDrainMultiplierTimer[i] > 0f)
        {
            _ibDrainMultiplierTimer[i] = Mathf.Max(0f, _ibDrainMultiplierTimer[i] - dtIB);
            if (_ibDrainMultiplierTimer[i] <= 0f)
            {
                ClearInternalBleedingState(i);
                Debug.Log($"[Health] Coagulant finished on {(BodyPart)i} — IB cleared.");
            }
            else
            {
                _ibDrainMultiplier[i] = Mathf.Clamp01(
                    _ibDrainMultiplierTimer[i] / COAGULANT_DURATION);
            }
            ibChanged = true;
        }

        if (_ibBlockTimer[i] > 0f)
        {
            _ibBlockTimer[i] = Mathf.Max(0f, _ibBlockTimer[i] - dtIB);
            if (_ibBlockTimer[i] <= 0f)
            {
                Debug.Log($"[Health] JETT expired on {(BodyPart)i}.");
                ibChanged = true;
            }
        }

        if (!_internalBleeding[i] || _internalBleedingRevealed[i]) continue;

        _internalBleedingRevealTimer[i] -= dtIB;
        if (_internalBleedingRevealTimer[i] <= 0f)
        {
            _internalBleedingRevealTimer[i] = 0f;
            _internalBleedingRevealed[i] = true;
            Debug.Log($"[Health] IB revealed on {(BodyPart)i}.");
            ibChanged = true;
        }
    }

    if (ibChanged) NotifyChange();

    if (HandlePassiveHealing())
    {
        _timeSinceLastUIUpdate += Time.deltaTime;
        if (_timeSinceLastUIUpdate >= UI_UPDATE_INTERVAL)
        {
            NotifyChange();
            _timeSinceLastUIUpdate = 0f;
        }
    }
}

        // =====================================================================
        // ИНИЦИАЛИЗАЦИЯ
        // =====================================================================
       private void InitializeSegments()
{
    if (_segments == null || _segments.Length != SEGMENT_COUNT)
    {
        Debug.LogWarning($"[K_HealthSystem] _segments length mismatch: " +
                         $"{_segments?.Length ?? 0}, recreating.");
        _segments = new BodySegment[SEGMENT_COUNT];
    }

    if (_limbStatuses == null || _limbStatuses.Length != SEGMENT_COUNT)
        _limbStatuses = new LimbStatus[SEGMENT_COUNT];

    if (_fractured == null || _fractured.Length != SEGMENT_COUNT)
        _fractured = new bool[SEGMENT_COUNT];

    if (_splinted == null || _splinted.Length != SEGMENT_COUNT)
        _splinted = new bool[SEGMENT_COUNT];

    if (_gunshot == null || _gunshot.Length != SEGMENT_COUNT)
        _gunshot = new bool[SEGMENT_COUNT];

    // 6.4.2: защита массива heal-boost таймеров.
    if (_healBoostTimers == null || _healBoostTimers.Length != SEGMENT_COUNT)
        _healBoostTimers = new float[SEGMENT_COUNT];

    // Stage 1: защита массива счётчиков бинта.
    if (_bandageCounter == null || _bandageCounter.Length != SEGMENT_COUNT)
        _bandageCounter = new int[SEGMENT_COUNT];

    // Stage 2 §4.5: защита IB-массивов.
    if (_internalBleeding == null || _internalBleeding.Length != SEGMENT_COUNT)
        _internalBleeding = new bool[SEGMENT_COUNT];

    if (_internalBleedingRevealed == null || _internalBleedingRevealed.Length != SEGMENT_COUNT)
        _internalBleedingRevealed = new bool[SEGMENT_COUNT];

    if (_internalBleedingRevealTimer == null || _internalBleedingRevealTimer.Length != SEGMENT_COUNT)
        _internalBleedingRevealTimer = new float[SEGMENT_COUNT];

    // Stage 3: временные эффекты всегда стартуют с дефолтов.
    if (_ibDrainMultiplier == null || _ibDrainMultiplier.Length != SEGMENT_COUNT)
        _ibDrainMultiplier = new float[SEGMENT_COUNT];

    if (_ibDrainMultiplierTimer == null || _ibDrainMultiplierTimer.Length != SEGMENT_COUNT)
        _ibDrainMultiplierTimer = new float[SEGMENT_COUNT];

    if (_ibBlockTimer == null || _ibBlockTimer.Length != SEGMENT_COUNT)
        _ibBlockTimer = new float[SEGMENT_COUNT];

    for (int i = 0; i < SEGMENT_COUNT; i++)
    {
        if (_segments[i] == null || _segments[i].OriginalMaxHP <= 0f)
            _segments[i] = new BodySegment(_baseHP[i]);
        _ibDrainMultiplier[i] = 1f;
        _ibDrainMultiplierTimer[i] = 0f;
        _ibBlockTimer[i] = 0f;
    }
}
        // =====================================================================
        // ЕДИНЫЙ API ГЕТТЕРОВ
        // =====================================================================
        public float GetHP(BodyPart part) => _segments[(int)part].CurrentHP;
        public float GetMaxHP(BodyPart part) => _segments[(int)part].OriginalMaxHP;

        public float GetHPPercent(BodyPart part)
        {
            var seg = _segments[(int)part];
            return seg.OriginalMaxHP > 0f ? seg.CurrentHP / seg.OriginalMaxHP : 0f;
        }

        // =====================================================================
        // FUNCTIONAL-СВОЙСТВА
        // Stage 1 §7.6: удалены IsLeftArmFunctional / IsRightArmFunctional /
        //   IsLeftLegFunctional / IsRightLegFunctional / HasLegFracture /
        //   HasArmFracture. Единственный источник правды — GetArmZoneLevel() /
        //   GetLegZoneLevel() + IsSegmentFunctional(part).
        // =====================================================================

        public bool HasFracture
        {
            get
            {
                for (int i = 0; i < SEGMENT_COUNT; i++)
                    if (_fractured[i] && !_splinted[i]) return true;
                return false;
            }
        }

        public int FractureCount
        {
            get
            {
                int c = 0;
                for (int i = 0; i < SEGMENT_COUNT; i++)
                    if (_fractured[i] && !_splinted[i]) c++;
                return c;
            }
        }

        public bool IsGunshot(BodyPart part) => _gunshot[(int)part];

        public bool HasGunshot
        {
            get
            {
                for (int i = 0; i < SEGMENT_COUNT; i++)
                    if (_gunshot[i]) return true;
                return false;
            }
        }

        public int GunshotCount
        {
            get
            {
                int c = 0;
                for (int i = 0; i < SEGMENT_COUNT; i++)
                    if (_gunshot[i]) c++;
                return c;
            }
        }

        public bool IsShocked => _shockTimer > 0f;

        /// <summary>Stage 5.2: refresh firearm shock without legacy damage or automatic head trauma.</summary>
        public void ApplyShock(float duration = FIREARM_SHOCK_DURATION)
        {
            if (float.IsNaN(duration) || float.IsInfinity(duration) || duration < 0f)
                throw new ArgumentOutOfRangeException(nameof(duration));
            if (duration <= _shockTimer) return;
            _shockTimer = Mathf.Max(_shockTimer, duration);
            NotifyChange();
        }

        // =====================================================================
        // ВНУТРЕННЕЕ КРОВОТЕЧЕНИЕ (Stage 2 §4.5)
        // =====================================================================
        public bool HasInternalBleeding(BodyPart part) => _internalBleeding[(int)part];

        public float GetIBDrainMultiplier(BodyPart part)
            => _ibDrainMultiplier[(int)part];

        public bool CanApplyCoagulant()
        {
            if (IsDead) return false;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (_internalBleeding[i] && _ibDrainMultiplierTimer[i] <= 0f) return true;
            return false;
        }

        public bool IsIBBlockedByJETT(BodyPart part)
            => _ibBlockTimer[(int)part] > 0f
            || _appliedMedical?.GetRecordFor(part, AppliedGhostKind.JETT) != null;

        public bool IsInternalBleedingRevealed(BodyPart part)
            => _internalBleedingRevealed[(int)part];

        public bool HasAnyInternalBleedingRevealed()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (_internalBleedingRevealed[i]) return true;
            return false;
        }

        public int GetInternalBleedingCount()
        {
            int count = 0;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (_internalBleeding[i]) count++;
            return count;
        }

        public int GetInternalBleedingRevealedCount()
        {
            int count = 0;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (_internalBleedingRevealed[i]) count++;
            return count;
        }

        public void ClearInternalBleeding(BodyPart part)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return;

            ClearInternalBleedingState(i);
            NotifyChange();
        }

        // Stage 3: любой мгновенный clear отменяет оставшийся коагулянт.
        // Профилактический блок JETT живёт своим таймером.
        private void ClearInternalBleedingState(int i)
        {
            _internalBleeding[i] = false;
            _internalBleedingRevealed[i] = false;
            _internalBleedingRevealTimer[i] = 0f;
            _ibDrainMultiplierTimer[i] = 0f;
            _ibDrainMultiplier[i] = 1f;
        }

        public void ClearAllInternalBleeding()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
                ClearInternalBleedingState(i);
            NotifyChange();
            Debug.Log("[Health] All IB cleared.");
        }

        /// <summary>
        /// Stage 3: коагулянт лечит все активные IB-сегменты одновременно.
        /// part сохранён для совместимости с MedicalEffectApplier.
        /// </summary>
        public void ApplyCoagulant(BodyPart part)
        {
            int affected = 0;
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                if (!_internalBleeding[i] || _ibDrainMultiplierTimer[i] > 0f) continue;

                _ibDrainMultiplierTimer[i] = COAGULANT_DURATION;
                _ibDrainMultiplier[i] = 1f;
                affected++;
            }

            if (affected == 0)
            {
                Debug.Log("[Health] Coagulant: no active IB to treat.");
                return;
            }

            Debug.Log($"[Health] Coagulant applied: {affected} IB segments " +
                      $"treated for {COAGULANT_DURATION:F0}s.");
            NotifyChange();
        }

        public void ApplyTransamacha()
        {
            int cleared = 0;
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                if (_internalBleeding[i]) cleared++;
                ClearInternalBleedingState(i);
            }

            Debug.Log($"[Health] Transamacha: cleared {cleared} IB segment(s).");
            NotifyChange();
        }

        public void ApplyJETT(BodyPart part)
        {
            // Stage 4: legacy callers cannot extend/bypass an active reusable device.
            if (_appliedMedical?.GetRecordForPart(part) != null)
            {
                Debug.LogWarning($"[Health] JETT: a device is already active on {part}.");
                return;
            }
            BodyPart[] chain = part switch
            {
                BodyPart.LeftShoulder    => LeftArmChain,
                BodyPart.RightShoulder   => RightArmChain,
                BodyPart.LeftQuadriceps  => LeftLegChain,
                BodyPart.RightQuadriceps => RightLegChain,
                _ => null
            };

            if (chain == null)
            {
                Debug.LogWarning($"[Health] JETT: invalid part {part} " +
                                 "(only shoulders/quadriceps).");
                return;
            }

            for (int k = 0; k < chain.Length; k++)
            {
                int i = (int)chain[k];
                ClearInternalBleedingState(i);
                _ibBlockTimer[i] = JETT_DURATION;
            }

            Debug.Log($"[Health] JETT applied on {part}: " +
                      $"{chain.Length} segments cleared + blocked for " +
                      $"{JETT_DURATION:F0}s.");
            NotifyChange();
        }

        /// <summary>
        /// Debug-only: принудительно поставить IB.
        /// reveal=true — сразу revealed; reveal=false — таймер 120с.
        /// </summary>
        public void DebugSetInternalBleeding(BodyPart part, bool reveal)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return;

            // Stage 4: forced test IB follows the same active-JETT prevention as fractures.
            if (IsIBBlockedByJETT(part))
            {
                Debug.Log($"[Health] IB prevented by JETT on {part}.");
                return;
            }

            _internalBleeding[i] = true;
            _internalBleedingRevealed[i] = reveal;
            _internalBleedingRevealTimer[i] = reveal ? 0f : 120f;
            NotifyChange();
        }

        // =====================================================================
        // ЛОКАЛИЗОВАННЫЕ ГЕТТЕРЫ СТАТУСОВ
        // =====================================================================
        public int GetBleedingLevel(BodyPart part) => GetLimbStatus(part).bleedingLevel;

        // ── Laceration (Этап 9) ─────────────────────────────────────────────
        // Две разные семантики:
        //   HasLaceration / HasAnyLaceration — «есть ли рана в любом состоянии»
        //     (для UI: игрок должен видеть заклеенную/зашитую рану).
        //   HasOpenLaceration / HasAnyOpenLaceration — «есть ли НЕзакрытая рана»
        //     (для гейтов регенерации/HealSegment; закрытая рана не мешает).

        public bool HasLaceration(BodyPart part)
            => _limbStatuses[(int)part].laceration != LacerationType.None;

        public bool HasAnyLaceration()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (_limbStatuses[i].laceration != LacerationType.None) return true;
            return false;
        }

        public bool HasOpenLaceration(BodyPart part)
            => _limbStatuses[(int)part].laceration == LacerationType.Open;

        public bool HasAnyOpenLaceration()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (_limbStatuses[i].laceration == LacerationType.Open) return true;
            return false;
        }

        public LacerationType GetLacerationType(BodyPart part)
            => _limbStatuses[(int)part].laceration;

        public int GetMaxBleedingLevel()
        {
            int maxLevel = 0;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                maxLevel = Mathf.Max(maxLevel, _limbStatuses[i].bleedingLevel);
            return maxLevel;
        }

        public int GetBleedingLimbsCount()
        {
            int count = 0;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (_limbStatuses[i].bleedingLevel > 0) count++;
            return count;
        }

        public BodyPart? GetPartWithMaxBleeding()
        {
            int maxLevel = 0;
            BodyPart? maxPart = null;
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                int level = _limbStatuses[i].bleedingLevel;
                if (level > maxLevel)
                {
                    maxLevel = level;
                    maxPart = (BodyPart)i;
                }
            }
            return maxPart;
        }

        private LimbStatus GetLimbStatus(BodyPart part) => _limbStatuses[(int)part];

        // =====================================================================
        // ЗОНАЛЬНАЯ СИСТЕМА (Stage 1 §7)
        // =====================================================================
        private static readonly BodyPart[] ArmZoneSegments =
        {
            BodyPart.LeftShoulder, BodyPart.RightShoulder,
            BodyPart.LeftBiceps,   BodyPart.RightBiceps,
            BodyPart.LeftForearm,  BodyPart.RightForearm,
            BodyPart.LeftHand,     BodyPart.RightHand,
        };

        private static readonly BodyPart[] LegZoneSegments =
        {
            BodyPart.LeftQuadriceps, BodyPart.RightQuadriceps,
            BodyPart.LeftKnee,       BodyPart.RightKnee,
            BodyPart.LeftShin,       BodyPart.RightShin,
            BodyPart.LeftFoot,       BodyPart.RightFoot,
        };

        /// <summary>
        /// Stage 1 §7.1: рабочая конечность — HP ≥ 1 И нет перелома без шины.
        /// </summary>
        public bool IsSegmentFunctional(BodyPart part)
        {
            int i = (int)part;
            if (_segments[i].CurrentHP < 1f) return false;
            if (_fractured[i] && !_splinted[i]) return false;
            return true;
        }

        private int CountNonFunctional(BodyPart[] parts)
        {
            int c = 0;
            for (int i = 0; i < parts.Length; i++)
                if (!IsSegmentFunctional(parts[i])) c++;
            return c;
        }

        /// <summary>Stage 1 §7.2: уровень зоны рук 0–3.</summary>
        public int GetArmZoneLevel()
        {
            int nf = CountNonFunctional(ArmZoneSegments);
            int bonus = 0;
            if (_cachedDebuffs != null)
            {
                if (_cachedDebuffs.HasConcussion) bonus++;
                if (_cachedDebuffs.HasTBI)        bonus++;
            }
            if (_cachedVitality != null &&
                (_cachedVitality.IsDrunk || _cachedVitality.IsHangover)) bonus++;
            return Mathf.Min(3, nf + bonus);
        }

        /// <summary>Stage 1 §7.3: уровень зоны ног 0–3. Авто-3 от таза/живота.</summary>
        public int GetLegZoneLevel()
        {
            // Авто-3, если таз или живот «выбиты» (спека §7.3).
            if (!IsSegmentFunctional(BodyPart.Pelvis)) return 3;
            if (_segments[(int)BodyPart.Stomach].CurrentHP < 1f) return 3;

            int nf = CountNonFunctional(LegZoneSegments);
            int bonus = 0;
            if (_cachedVitality != null &&
                (_cachedVitality.IsDrunk || _cachedVitality.IsHangover)) bonus++;
            return Mathf.Min(3, nf + bonus);
        }

        // Множители берутся из K_HealthConfig (Stage 1 §7.4 — placeholder'ы).
        public float GetArmAimMultiplier()
        {
            if (_cachedDebuffs != null && _cachedDebuffs.IsUnderPainkiller) return 1f;
            var c = K_HealthConfig.Instance;
            return c != null ? c.GetArmAimMultiplier(GetArmZoneLevel()) : 1f;
        }
        public float GetArmSpeedMultiplier()
        {
            if (_cachedDebuffs != null && _cachedDebuffs.IsUnderPainkiller) return 1f;
            var c = K_HealthConfig.Instance;
            return c != null ? c.GetArmSpeedMultiplier(GetArmZoneLevel()) : 1f;
        }
        public float GetArmNoiseMultiplier()
        {
            if (_cachedDebuffs != null && _cachedDebuffs.IsUnderPainkiller) return 1f;
            var c = K_HealthConfig.Instance;
            return c != null ? c.GetArmNoiseMultiplier(GetArmZoneLevel()) : 1f;
        }
        public float GetLegSpeedMultiplier()
        {
            if (_cachedDebuffs != null && _cachedDebuffs.IsUnderPainkiller) return 1f;
            var c = K_HealthConfig.Instance;
            return c != null ? c.GetLegSpeedMultiplier(GetLegZoneLevel()) : 1f;
        }
        public bool IsSprintBlockedByLegZone() => GetLegZoneLevel() >= 3;

        // =====================================================================
        // ХОЛОД — batch API для K_VitalitySystem (Stage 1 §8.3)
        // Старый ApplyColdDamage(float) удалён, алгоритм переехал в K_VitalitySystem.
        // =====================================================================
        public void BeginColdDamageBatch() { /* no-op, зарезервирован под будущее */ }

        public void ApplyColdDamageToSegment(BodyPart part, float damage)
        {
            if (float.IsNaN(damage) || float.IsInfinity(damage)) return;
            if (IsDead || damage <= 0f) return;
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return;
            _segments[i].ApplyDamage(damage);
        }

        public void FinishColdDamageBatch()
        {
            CheckDeathConditions();
            NotifyChange();
        }

        // =====================================================================
        // ПРИНЯТИЕ УРОНА
        // =====================================================================
        /// <summary>
        /// Stage 5.1 HP-only entry point. Head and chest are final overflow targets.
        /// Status effects are applied separately; legacy TakeDamage is unchanged.
        /// </summary>
        public void ApplySegmentDamage(float damage, BodyPart part, DamageType source = DamageType.Generic)
        {
            ValidateCombatPart(part);
            if (float.IsNaN(damage) || float.IsInfinity(damage) || damage < 0f)
                throw new ArgumentOutOfRangeException(nameof(damage));
            if (source < DamageType.Generic || source > DamageType.Cold)
                throw new ArgumentOutOfRangeException(nameof(source), "HP damage requires a source, not a status.");
            if (IsDead || damage == 0f) return;

            float overflow = _segments[(int)part].ApplyDamageWithOverflow(damage);
            if (overflow > 0f && part != BodyPart.Head && part != BodyPart.Chest)
                _segments[(int)BodyPart.Chest].ApplyDamage(overflow);

            CheckDeathConditions();
            OnSegmentDamageApplied?.Invoke(part, damage, source);
            NotifyChange();
        }

        /// <summary>Stage 5.1 deterministic fracture call; one IB roll per new fracture.</summary>
        public bool ApplyCombatFracture(BodyPart part, float internalBleedingSample)
        {
            ValidateCombatPart(part);
            if (float.IsNaN(internalBleedingSample) || internalBleedingSample < 0f || internalBleedingSample > 1f)
                throw new ArgumentOutOfRangeException(nameof(internalBleedingSample));
            int i = (int)part;
            if (!_canFracture[i] || (_fractured[i] && !_splinted[i])) return false;

            _fractured[i] = true;
            _splinted[i] = false;
            if (internalBleedingSample < 0.15f) ApplyCombatInternalBleeding(part);
            NotifyChange();
            return true;
        }

        /// <summary>Stage 5.1 status-only IB call, honoring active JETT and coagulant.</summary>
        public bool ApplyCombatInternalBleeding(BodyPart part)
        {
            ValidateCombatPart(part);
            int i = (int)part;
            if (_internalBleeding[i] || IsIBBlockedByJETT(part) || _ibDrainMultiplierTimer[i] > 0f)
                return false;
            _internalBleeding[i] = true;
            _internalBleedingRevealed[i] = false;
            _internalBleedingRevealTimer[i] = 120f;
            NotifyChange();
            return true;
        }

        /// <summary>Stage 5.1 laceration state without implicit HP or bleeding changes.</summary>
        public void SetCombatLaceration(BodyPart part, LacerationType laceration)
        {
            ValidateCombatPart(part);
            if (laceration < LacerationType.None || laceration > LacerationType.Sealed)
                throw new ArgumentOutOfRangeException(nameof(laceration));
            int i = (int)part;
            if (_limbStatuses[i].laceration == laceration) return;
            _limbStatuses[i].laceration = laceration;
            NotifyChange();
        }

        /// <summary>Unscaled project defaults used by NPC data before a player template exists.</summary>
        public static float GetDefaultBaseHP(BodyPart part)
        {
            ValidateCombatPart(part);
            switch (part)
            {
                case BodyPart.Head: return 30f;
                case BodyPart.Chest: return 60f;
                case BodyPart.Stomach:
                case BodyPart.Pelvis: return 45f;
                case BodyPart.LeftHand:
                case BodyPart.RightHand: return 15f;
                case BodyPart.LeftQuadriceps:
                case BodyPart.RightQuadriceps: return 35f;
                case BodyPart.LeftFoot:
                case BodyPart.RightFoot: return 20f;
                case BodyPart.LeftBiceps:
                case BodyPart.RightBiceps:
                case BodyPart.LeftShin:
                case BodyPart.RightShin: return 30f;
                default: return 25f;
            }
        }

        private static void ValidateCombatPart(BodyPart part)
        {
            if ((int)part < 0 || (int)part >= SEGMENT_COUNT)
                throw new ArgumentOutOfRangeException(nameof(part));
        }

        public void TakeDamage(float damage, BodyPart part, DamageType type = DamageType.Generic, int weaponBleed = 0)
        {
            if (float.IsNaN(damage) || float.IsInfinity(damage)) return;
            if ((int)part < 0 || (int)part >= SEGMENT_COUNT) return;
            if (IsDead || damage <= 0f) return;

            var segment = _segments[(int)part];
            float overflow = segment.ApplyDamageWithOverflow(damage);

            if (overflow > 0f)
            {
                if (part == BodyPart.Head)
                {
                    // overflow от головы никуда не идёт — она источник
                }
                else if (part == BodyPart.Chest)
                {
                    _segments[(int)BodyPart.Head].ApplyDamage(overflow);
                }
                else
                {
                    float chestOverflow = _segments[(int)BodyPart.Chest].ApplyDamageWithOverflow(overflow);
                    if (chestOverflow > 0f)
                        _segments[(int)BodyPart.Head].ApplyDamage(chestOverflow);
                }
            }

            if (type == DamageType.Firearm)
            {
                _shockTimer = FIREARM_SHOCK_DURATION;

                if (weaponBleed > 0)
                {
                    // Stage 4: a wound raises the per-segment snapshot while visible bleed stays 0.
                    SetExternalBleeding(part, weaponBleed, raiseOnly: true);
                    // Новая рана = Open (перекрывает Glued/Sealed в этом сегменте).
                    _limbStatuses[(int)part].laceration = LacerationType.Open;
                    // Stage 1 §4.2: bleedingLevel изменился НЕ через бинт → сброс счётчика.
                    _bandageCounter[(int)part] = 0;
                }

                // Stage 1 §2.3: авто-фрактура УДАЛЕНА.
                // Раньше здесь был блок с FIREARM_FRACTURE_CHANCE — перелом
                // ставит оружие (Stage 5), не ядро.

                // Гарантированное ранение. HP уже применён выше через ApplyDamageWithOverflow.
                ApplyGunshot(part);

                NotifyChange();
            }

            CheckDeathConditions();
            OnDamageTaken?.Invoke(part, damage, type);
            NotifyChange();
        }

        // =====================================================================
        // УРОН ОТ МЕТАБОЛИЗМА
        // =====================================================================
        /// <summary>
        /// Stage 1 §8.1: урон от голода/жажды идёт через тот же каскад, что TakeDamage:
        /// живот → грудь → голова. Раньше при мёртвом животе размазывался по 20 сегментам —
        /// это противоречит спеке.
        /// </summary>
        public void TakeMetabolismDamage(float damage, BodyPart part)
        {
            if (float.IsNaN(damage) || float.IsInfinity(damage) || (int)part < 0 || (int)part >= SEGMENT_COUNT) return;
            if (IsDead || damage <= 0f) return;

            var stomach = _segments[(int)BodyPart.Stomach];
            float overflow = stomach.ApplyDamageWithOverflow(damage);

            if (overflow > 0f)
            {
                float chestOverflow = _segments[(int)BodyPart.Chest].ApplyDamageWithOverflow(overflow);
                if (chestOverflow > 0f)
                    _segments[(int)BodyPart.Head].ApplyDamage(chestOverflow);
            }

            CheckDeathConditions();
            NotifyChange();
        }

        // =====================================================================
        // ПЕРЕЛОМЫ И ШИНЫ
        // =====================================================================
        /// <summary>
        /// Stage 1 §2.2: перелом — чистый статус. HP НЕ трогает.
        /// Конечность становится нерабочей через IsSegmentFunctional().
        /// </summary>
        public void ApplyFracture(BodyPart part)
        {
            if (!_canFracture[(int)part]) return;
            int i = (int)part;

            if (_fractured[i] && !_splinted[i]) return;

            if (_fractured[i] && _splinted[i])
                _fractured[i] = false;

            _splinted[i] = false;
            _fractured[i] = true;

            // Stage 2 §4.5: 15% шанс IB от нового перелома.
            // Если IB уже есть, повторный бросок не выполняется.
            if (!_internalBleeding[i] && !IsIBBlockedByJETT(part) &&
                _ibDrainMultiplierTimer[i] <= 0f && UnityEngine.Random.value < 0.15f)
            {
                _internalBleeding[i] = true;
                _internalBleedingRevealed[i] = false;
                _internalBleedingRevealTimer[i] = 120f;
                Debug.Log($"[Health] IB activated on {part}.");
            }

            NotifyChange();
        }

        /// <summary>
        /// Снять перелом с сегмента. Снимает и шину, если стояла.
        /// HP НЕ восстанавливает — только убирает статус.
        /// </summary>
        public void ClearFracture(BodyPart part)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return;

            if (!_fractured[i] && !_splinted[i]) return;

            _fractured[i] = false;
            _splinted[i] = false;
            NotifyChange();
        }

        /// <summary>
        /// Гарантированное огнестрельное ранение сегмента.
        /// HP НЕ трогает — оно определяется уроном оружия.
        /// </summary>
        public void ApplyGunshot(BodyPart part)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return;

            if (_gunshot[i]) return;

            _gunshot[i] = true;
            NotifyChange();
        }

        /// <summary>
        /// Снять статус огнестрельного ранения. HP не восстанавливает.
        /// </summary>
        public void ClearGunshot(BodyPart part)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return;
            if (!_gunshot[i]) return;

            _gunshot[i] = false;
            NotifyChange();
        }

        /// <summary>
        /// Stage 1 §2.2: шина снимает флаг перелома. HP НЕ восстанавливает.
        /// </summary>
        public void ApplySplint(BodyPart part)
        {
            int i = (int)part;
            if (!_fractured[i])
            {
                Debug.LogWarning($"[Health] Cannot apply splint to {part} — not fractured!");
                return;
            }

            _fractured[i] = false;
            _splinted[i] = true;
            // Stage 1: HP не восстанавливаем. Строка if (CurrentHP <= 0) SetHP(1) удалена.

            NotifyChange();
        }

        public void RemoveSplint(BodyPart part)
        {
            _splinted[(int)part] = false;
            NotifyChange();
        }

        public bool IsFractured(BodyPart part) => _fractured[(int)part];
        public bool IsSplinted(BodyPart part) => _splinted[(int)part];

        // =====================================================================
        // ЛЕЧЕНИЕ
        // =====================================================================
        /// <summary>
        /// Stage 1 §10.2: per-segment гейты.
        /// Раньше был глобальный гейт HasAnyOpenLaceration() — из-за него
        /// одна открытая рана блокировала лечение всего тела. Теперь каждый
        /// сегмент блокируется только своими статусами.
        /// </summary>
        public bool CanRestoreHP(BodyPart part)
        {
            int i = (int)part;
            if (IsDead || i < 0 || i >= SEGMENT_COUNT) return false;
            return _segments[i].CurrentHP > 0f && _segments[i].CurrentHP < _segments[i].MaxHP
                && !(_fractured[i] && !_splinted[i]) && !_gunshot[i]
                && _limbStatuses[i].laceration != LacerationType.Open
                && _limbStatuses[i].bleedingLevel <= 0 && !_internalBleeding[i];
        }

        public void HealSegment(BodyPart part, float amount)
        {
            if (float.IsNaN(amount) || float.IsInfinity(amount) || (int)part < 0 || (int)part >= SEGMENT_COUNT) return;
            if (IsDead || amount <= 0f) return;

            int i = (int)part;
            // Per-segment гейты:
            if (_fractured[i] && !_splinted[i]) return;
            if (_gunshot[i]) return;
            if (_limbStatuses[i].laceration == LacerationType.Open) return;
            if (_limbStatuses[i].bleedingLevel > 0) return;

            if (_internalBleeding[i]) return;   // Stage 2 §4.5: IB блокирует регенерацию.

            // Stage 1: LACERATION_HEAL_PENALTY (×0.7) удалён — спека ч.10.3
            // требует равномерную регенерацию.
            if (_segments[i].Heal(amount)) NotifyChange();
        }

        public void HealAll(float amount)
        {
            if (float.IsNaN(amount) || float.IsInfinity(amount)) return;
            if (IsDead || amount <= 0f) return;

            bool changed = false;
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                if (_fractured[i] && !_splinted[i]) continue;
                if (_gunshot[i]) continue;
                if (_limbStatuses[i].laceration == LacerationType.Open) continue;
                if (_limbStatuses[i].bleedingLevel > 0) continue;
                if (_internalBleeding[i]) continue;   // Stage 2 §4.5.
                if (_segments[i].Heal(amount)) changed = true;
            }
            if (changed) NotifyChange();
        }

        // =====================================================================
        // HEAL BOOST (Этап 6.4.2)
        // =====================================================================
        /// <summary>
        /// Stage 1 §10.4: гель накладывается на конкретный сегмент.
        /// Активирует boost только на нём. Refresh через Max.
        /// duration &lt;= 0 → _healBoostDuration. Не сохраняется.
        /// </summary>
        public void ActivateHealBoost(BodyPart part, float duration)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return;

            if (duration <= 0f) duration = _healBoostDuration;
            if (duration <= 0f) return;

            if (_healBoostTimers == null || _healBoostTimers.Length != SEGMENT_COUNT)
                _healBoostTimers = new float[SEGMENT_COUNT];

            _healBoostTimers[i] = Mathf.Max(_healBoostTimers[i], duration);

            Debug.Log($"[Health] HealBoost ×{_healBoostMultiplier} on {part} for {duration:F1}s.");
            NotifyChange();
        }

        /// <summary>Resolve one accepted remaining duration for legacy gel effect and icon without mutating health.</summary>
        public bool TryResolveHealBoostDuration(BodyPart part, float requestedDuration, out float acceptedDuration)
        {
            acceptedDuration = 0f;
            int index = (int)part;
            if (IsDead || index < 0 || index >= SEGMENT_COUNT || float.IsNaN(requestedDuration) || float.IsInfinity(requestedDuration))
                return false;
            float duration = requestedDuration <= 0f ? _healBoostDuration : requestedDuration;
            if (float.IsNaN(duration) || float.IsInfinity(duration) || duration <= 0f) return false;
            float current = _healBoostTimers != null && _healBoostTimers.Length == SEGMENT_COUNT ? _healBoostTimers[index] : 0f;
            if (float.IsNaN(current) || float.IsInfinity(current)) return false;
            acceptedDuration = Mathf.Max(current, duration);
            return true;
        }

        public bool CanExtendHealBoost(BodyPart part, float requestedDuration)
        {
            if (!TryResolveHealBoostDuration(part, requestedDuration, out float accepted)) return false;
            return accepted > (_healBoostTimers != null && _healBoostTimers.Length == SEGMENT_COUNT
                ? _healBoostTimers[(int)part] : 0f);
        }

        /// <summary>
        /// Stage 1 §10.3: HP = 0 БОЛЬШЕ НЕ ГЕЙТ. Регенерация вытянет сегмент
        /// с нуля, если нет блокеров.
        /// Глобальные гейты: голод &lt; 25, жажда &lt; 25.
        /// Пер-сегментные: перелом без шины, огнестрел, открытая лацерация,
        /// кровотечение &gt; 0, внутреннее кровотечение (включая скрытое).
        /// </summary>
        private bool HandlePassiveHealing()
        {
            // ── Глобальные стоп-условия ──
            if (_cachedVitality != null)
            {
                if (_cachedVitality.Hunger < _passiveHealMinHunger) return false;
                if (_cachedVitality.Thirst < _passiveHealMinThirst) return false;
            }

            float dt = Time.deltaTime;
            bool changed = false;

            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                // Stage 1: HP = 0 НЕ гейт.
                if (_fractured[i] && !_splinted[i]) continue;
                if (_gunshot[i]) continue;
                if (_limbStatuses[i].laceration == LacerationType.Open) continue;
                if (_limbStatuses[i].bleedingLevel > 0) continue;

                if (_internalBleeding[i]) continue;   // Stage 2 §4.5.

                float rate = _passiveHealRate;
                if (_healBoostTimers[i] > 0f) rate *= _healBoostMultiplier;

                if (_segments[i].Heal(rate * dt)) changed = true;
            }

            return changed;
        }

        // =====================================================================
        // КРОВОТЕЧЕНИЕ
        // =====================================================================

        // Stage 4: all positive external-bleeding writes go through the applied snapshot.
        private void SetExternalBleeding(BodyPart part, int level, bool raiseOnly = false)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return;
            int proposed = Mathf.Clamp(level, 0, 3);
            if (raiseOnly) proposed = Mathf.Max(_limbStatuses[i].bleedingLevel, proposed);
            _limbStatuses[i].bleedingLevel =
                _appliedMedical != null && _appliedMedical.CaptureSuppressedBleeding(part, proposed)
                ? 0 : proposed;
            _bandageCounter[i] = 0;
        }

        // Stage 4: chains are owned by health and exposed read-only to its manager.
        internal IReadOnlyList<BodyPart> GetMechanicalLimbChain(BodyPart parent)
        {
            switch (parent)
            {
                case BodyPart.LeftShoulder: return LeftArmChain;
                case BodyPart.RightShoulder: return RightArmChain;
                case BodyPart.LeftQuadriceps: return LeftLegChain;
                case BodyPart.RightQuadriceps: return RightLegChain;
                default: return Array.Empty<BodyPart>();
            }
        }

        internal void SuppressMechanicalBleeding(AppliedMedicalRecord record, bool captureSnapshot)
        {
            var chain = GetMechanicalLimbChain(record.AppliedTo);
            for (int k = 0; k < chain.Count; k++)
            {
                int i = (int)chain[k];
                if (captureSnapshot) record.SavedBleeding[i] = _limbStatuses[i].bleedingLevel;
                _limbStatuses[i].bleedingLevel = 0;
                _bandageCounter[i] = 0;
                if (record.Kind == AppliedGhostKind.JETT)
                {
                    ClearInternalBleedingState(i);
                    // Stage 4: this record, rather than a legacy 420s timer, now owns IB blocking.
                    _ibBlockTimer[i] = 0f;
                }
            }
        }

        internal void RestoreMechanicalBleeding(AppliedMedicalRecord record)
        {
            var chain = GetMechanicalLimbChain(record.AppliedTo);
            for (int k = 0; k < chain.Count; k++)
            {
                int i = (int)chain[k];
                record.SavedBleeding.TryGetValue(i, out int savedLevel);
                _limbStatuses[i].bleedingLevel = Mathf.Clamp(
                    Mathf.Max(_limbStatuses[i].bleedingLevel, savedLevel), 0, 3);
                _bandageCounter[i] = 0;
                // Stage 4: IB never returns when JETT is removed or expires.
            }
        }

        internal void NotifyAppliedMedicalChanged() => NotifyChange();
        internal void MarkAppliedMedicalDirty() => IsDirty = true;

        public bool ApplyTourniquet(InventoryItem item, BodyPart parent)
        {
            bool applied = _appliedMedical.TryApply(item, parent,
                AppliedGhostKind.Tourniquet, out string reason);
            if (!applied) Debug.LogWarning($"[Health] Tourniquet: {reason}");
            return applied;
        }

        public bool ApplyJETT(InventoryItem item, BodyPart parent)
        {
            bool applied = _appliedMedical.TryApply(item, parent,
                AppliedGhostKind.JETT, out string reason);
            if (!applied) Debug.LogWarning($"[Health] JETT: {reason}");
            return applied;
        }

        public bool RemoveApplied(BodyPart parent, AppliedGhostKind kind, out string reason)
            => _appliedMedical.TryRemove(_appliedMedical.GetRecordFor(parent, kind), out reason);

        public void SetBleedingLevel(int level)
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                SetExternalBleeding((BodyPart)i, level);
            }
            NotifyChange();
        }
        /// <summary>
        /// Прямая установка уровня кровотечения на конкретном сегменте.
        /// Stage 1 §4.2: сбрасывает счётчик бинта на этом сегменте.
        /// </summary>
        public void SetBleedingLevelOnPart(BodyPart part, int level)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return;
            SetExternalBleeding(part, level);
            NotifyChange();
        }
        public void StopBleeding()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                _limbStatuses[i].bleedingLevel = 0;
                _bandageCounter[i] = 0;   // Stage 1 §4.2
            }
            NotifyChange();
        }

        // =====================================================================
        // БИНТЫ
        // =====================================================================
        /// <summary>
        /// Stage 1 §4.2: N применений бинта снимают уровень N.
        /// L3 → 3 бинта → L2 → ещё 2 → L1 → ещё 1 → L0. Всего 6 с L3.
        /// Счётчик обнуляется при любом изменении bleedingLevel не через бинт.
        /// </summary>
        public bool UseBandage(BodyPart? targetPart = null)
        {
            if (targetPart == null)
            {
                targetPart = GetPartWithMaxBleeding();
                if (targetPart == null)
                {
                    Debug.Log("[Health] No bleeding to stop!");
                    return false;
                }
            }

            int i = (int)targetPart.Value;
            int level = _limbStatuses[i].bleedingLevel;
            if (level <= 0)
            {
                Debug.Log($"[Health] No bleeding on {targetPart}!");
                return false;
            }

            _bandageCounter[i]++;
            Debug.Log($"[Health] Bandage on {targetPart}: {_bandageCounter[i]}/{level}");

            if (_bandageCounter[i] >= level)
            {
                _bandageCounter[i] = 0;
                _limbStatuses[i].bleedingLevel = level - 1;
                Debug.Log($"[Health] Bleeding on {targetPart}: L{level} → L{level - 1}");
            }

            NotifyChange();
            return true;
        }

        // =====================================================================
        // ЖГУТ / ТУРНИКЕТ (Этап 6.4)
        // =====================================================================
        /// <summary>
        /// Stage 1 §4.3: жгут обнуляет ЛЮБОЙ уровень (L1–L3), не только L3.
        /// Счётчик бинта сбрасывается. Валидные части — плечи/бёдра
        /// (проверка на уровне MedicalDatabase, здесь — все сегменты).
        /// </summary>
        public bool UseTourniquet(BodyPart part)
        {
            // Stage 4: item-aware ApplyTourniquet owns all new reusable applications.
            // Keep this old one-shot signature for existing callers and block active overlap.
            if (_appliedMedical?.GetRecordForPart(part) != null)
            {
                Debug.LogWarning($"[Health] Tourniquet: a device is already active on {part}.");
                return false;
            }
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return false;

            int level = _limbStatuses[i].bleedingLevel;
            if (level <= 0)
            {
                Debug.Log($"[Health] Tourniquet on {part}: no bleeding, no-op.");
                return false;
            }

            _limbStatuses[i].bleedingLevel = 0;
            _bandageCounter[i] = 0;
            NotifyChange();
            Debug.Log($"[Health] Tourniquet applied on {part}: L{level} → L0.");
            return true;
        }

        // =====================================================================
        // ГЕМОСТАТИК (Этап 6.4.1)
        // =====================================================================
        /// <summary>
        /// Stage 1 §4.4: гемостатик — обнуляет L1–L3 на любом сегменте.
        /// Счётчик бинта сбрасывается. Laceration НЕ трогает.
        /// </summary>
        public bool UseHemostatic(BodyPart part)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return false;

            int previous = _limbStatuses[i].bleedingLevel;
            if (previous == 0)
            {
                Debug.Log($"[Health] Hemostatic on {part}: no bleeding, no-op.");
                return false;
            }

            _limbStatuses[i].bleedingLevel = 0;
            _bandageCounter[i] = 0;
            NotifyChange();
            Debug.Log($"[Health] Hemostatic applied on {part}: L{previous} → L0.");
            return true;
        }

        // =====================================================================
        // ЛЕЧЕНИЕ РВАНОЙ РАНЫ (Этап 9)
        // =====================================================================
        /// <summary>
        /// Применить средство от рваной раны (клей / стрипы / степлер).
        ///
        /// Матрица:
        ///   входящий type = None/Open  → false (невалидный аргумент, no-op).
        ///   сегмент None               → false (нечего лечить).
        ///   сегмент Open + Glued       → Glued, true.
        ///   сегмент Open + Sealed      → Sealed, true.
        ///   сегмент Glued + Glued      → false (no-op, таймера у клея нет).
        ///   сегмент Glued + Sealed     → upgrade до Sealed, true.
        ///   сегмент Sealed + любой     → false (не понижаем надёжность).
        ///
        /// Возвращает true, если состояние раны изменилось.
        /// Кровотечение НЕ трогает — для этого есть BleedingLight/Full/Arterial.
        /// </summary>
        public bool UseLacerationTreatment(BodyPart part, LacerationType type)
        {
            int i = (int)part;
            if (i < 0 || i >= SEGMENT_COUNT) return false;

            if (type == LacerationType.None || type == LacerationType.Open) return false;

            var current = _limbStatuses[i].laceration;

            if (current == LacerationType.None) return false;

            if (current == LacerationType.Open)
            {
                _limbStatuses[i].laceration = type;
                NotifyChange();
                return true;
            }

            if (current == LacerationType.Glued && type == LacerationType.Sealed)
            {
                _limbStatuses[i].laceration = LacerationType.Sealed;
                NotifyChange();
                return true;
            }

            // Glued→Glued: no-op.
            // Sealed→любой: отказ (не понижаем).
            return false;
        }

        // =====================================================================
        // ПРЫЖОК (Этап 9): рвёт клей без обезбола.
        // =====================================================================
        /// <summary>
        /// Stage 1 §3.3: прыжок рвёт ВСЕ Glued-сегменты в Open,
        /// возвращает кровотечение уровня _glueTearBleedingLevel.
        /// Обезбол НЕ защищает (раньше был гейт IsUnderPainkiller — удалён).
        /// Stage 1 §4.2: счётчик бинта на сегменте сбрасывается.
        /// </summary>
        public void NotifyJump()
        {
            if (IsDead) return;
            // Stage 1: гейт IsUnderPainkiller удалён (спека ч.3.3).

            bool anyBroken = false;
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                if (_limbStatuses[i].laceration != LacerationType.Glued) continue;

                _limbStatuses[i].laceration = LacerationType.Open;
                // Stage 4: glue tearing is also a new external-bleeding producer.
                SetExternalBleeding((BodyPart)i, _glueTearBleedingLevel, raiseOnly: true);
                _bandageCounter[i] = 0;   // Stage 1 §4.2
                anyBroken = true;

                Debug.Log($"[Health] Glue torn on {(BodyPart)i} by jump. " +
                          $"Bleeding → L{_limbStatuses[i].bleedingLevel}.");
            }

            if (anyBroken) NotifyChange();
        }

        // =====================================================================
        // РАДИАЦИЯ
        // =====================================================================
        public void ApplyRadiationClamp(float radiationPercent)
        {
            if (radiationPercent >= 100f)
            {
                for (int i = 0; i < SEGMENT_COUNT; i++) _segments[i].SetHP(0f);
                Die();
                return;
            }

            float radiationFactor = Mathf.Clamp01(1.0f - radiationPercent / 100f);
            for (int i = 0; i < SEGMENT_COUNT; i++)
                _segments[i].SetMaxHP(_baseHP[i] * radiationFactor);

            ClampAllSegments();
            NotifyChange();
        }

        /// <summary>Buffered radiation limit: no reduction through 10%, then up to 50% at 100%.</summary>
        public void ApplyRadiationMaxHPReduction(float radiationPercent)
        {
            if (float.IsNaN(radiationPercent) || float.IsInfinity(radiationPercent))
            {
                Debug.LogError("[Health] Radiation must be finite; using 0% for max HP.");
                radiationPercent = 0f;
            }
            radiationPercent = Mathf.Clamp(radiationPercent, 0f, 100f);
            float reduction = Mathf.Clamp01((radiationPercent - 10f) / 90f) * 0.5f;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                _segments[i].SetMaxHP(_baseHP[i] * (1f - reduction));
            ClampAllSegments();
            NotifyChange();
        }

        // =====================================================================
        // ВСПОМОГАТЕЛЬНЫЕ
        // =====================================================================
        private void ClampAllSegments()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++) _segments[i].ClampHP();
        }

        // Stage 1: FixZeroHPWithoutFracture() удалён (см. OnValidate).
        // Stage 1: EnforceFractureHP() удалён (см. OnValidate).

      private void CheckDeathConditions()
{
    if (IsDead) return;
    if (_segments == null || _segments.Length < SEGMENT_COUNT) return;
    if (_segments[(int)BodyPart.Head] == null) return;
    if (_segments[(int)BodyPart.Chest] == null) return;

    if (_segments[(int)BodyPart.Head].CurrentHP <= 0f ||
        _segments[(int)BodyPart.Chest].CurrentHP <= 0f)
        Die();
}
        private void Die()
        {
            if (!IsDead)
            {
                IsDead = true;
                // Stage 4: the persisted death latch must be dirty even after ForceDeath.
                NotifyChange();
                OnDeath?.Invoke();
                Debug.Log("[K_HealthSystem] PLAYER DEAD");
            }
        }
/// <summary>
/// Принудительная смерть из внешней системы (например, обезвоживание кровью).
/// </summary>
public void ForceDeath()
{
    if (IsDead) return;
    Die();
}

/// <summary>
/// Распределённый урон по всем 20 сегментам (используется K_BloodSystem в состоянии Shock).
/// </summary>
public void ApplyDistributedDamage(float damage)
{
    if (float.IsNaN(damage) || float.IsInfinity(damage)) return;
    if (IsDead || damage <= 0f) return;
    float perSegment = damage / (float)SEGMENT_COUNT;
    for (int i = 0; i < SEGMENT_COUNT; i++)
        _segments[i].ApplyDamage(perSegment);
    CheckDeathConditions();
    // Audit H08: damage is save-relevant even while its HUD update is throttled.
    IsDirty = true;
    // Death already emits NotifyChange through the existing Die path.
    if (IsDead) return;

    float distributedDamageNotifyTime = Time.time;
    if (!float.IsNaN(_distributedDamageNotifySampleTime))
        _distributedDamageNotifyTimer += Mathf.Max(0f,
            distributedDamageNotifyTime - _distributedDamageNotifySampleTime);
    _distributedDamageNotifySampleTime = distributedDamageNotifyTime;
    if (_distributedDamageNotifyTimer >= UI_UPDATE_INTERVAL)
    {
        // Reset before callbacks so reentrant damage cannot notify a second time.
        _distributedDamageNotifyTimer = 0f;
        NotifyChange();
    }
}
        private void NotifyChange()
        {
            IsDirty = true;
            OnHealthChanged?.Invoke();
        }

        // =====================================================================
        // СОХРАНЕНИЕ / ЗАГРУЗКА
        // 6.4.2: _healBoostTimers НЕ сохраняется (временный эффект).
        //        _cachedDebuffs — кэш, не сохраняется.
        // V7 (Stage 2 §4.5): IB-флаги сохраняются, reveal-таймеры НЕ сохраняются.
        // =====================================================================
        public void Save(BinaryWriter writer)
        {
            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_segments[i].CurrentHP);
            writer.Write(_shockTimer);
            // Stage 4 / V8 schema 2: preserve death freeze and permit living-save revival.
            writer.Write(IsDead);

            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                writer.Write(_limbStatuses[i].bleedingLevel);
                writer.Write((byte)_limbStatuses[i].laceration);
            }

            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_fractured[i]);
            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_splinted[i]);
            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_gunshot[i]);

            // V6 (Stage 1 §13): счётчик применений бинта.
            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_bandageCounter[i]);

            // V7 (Stage 2 §4.5): IB-флаги. Reveal-таймеры НЕ сохраняются.
            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_internalBleeding[i]);
            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_internalBleedingRevealed[i]);
            // Stage 4 / V8: exact charge duration, source metadata and external snapshots.
            _appliedMedical.Save(writer);
            WriteCoagulantTail(writer);
        }

        public void Load(BinaryReader reader)
        {
            ResetNonPersistentEffectsForLoad();
            // Preserve exact saved values until every system has loaded. Current-session
            // radiation limits must not truncate HP before saved vitality is restored.
            _pendingLoadedHP = new float[SEGMENT_COUNT];
            for (int i = 0; i < SEGMENT_COUNT; i++) _pendingLoadedHP[i] = reader.ReadSingle();
            _shockTimer = reader.ReadSingle();
            // Stage 4 / V8 schema 2: replace the current-session death latch from the save.
            IsDead = reader.ReadBoolean();

            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                _limbStatuses[i].bleedingLevel = reader.ReadInt32();
                _limbStatuses[i].laceration = (LacerationType)reader.ReadByte();
            }

            for (int i = 0; i < SEGMENT_COUNT; i++) _fractured[i] = reader.ReadBoolean();
            for (int i = 0; i < SEGMENT_COUNT; i++) _splinted[i]  = reader.ReadBoolean();
            for (int i = 0; i < SEGMENT_COUNT; i++) _gunshot[i]   = reader.ReadBoolean();

            // V6 (Stage 1 §13)
            for (int i = 0; i < SEGMENT_COUNT; i++) _bandageCounter[i] = reader.ReadInt32();

            // V7 (Stage 2 §4.5).
            for (int i = 0; i < SEGMENT_COUNT; i++) _internalBleeding[i] = reader.ReadBoolean();
            for (int i = 0; i < SEGMENT_COUNT; i++) _internalBleedingRevealed[i] = reader.ReadBoolean();

            // Для скрытого IB reveal-таймер после загрузки начинается заново.
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                _internalBleedingRevealTimer[i] =
                    (_internalBleeding[i] && !_internalBleedingRevealed[i]) ? 120f : 0f;
                _ibDrainMultiplier[i] = 1f;
                _ibDrainMultiplierTimer[i] = 0f;
                _ibBlockTimer[i] = 0f;
            }

            // Stage 4 / V8: the record restores suppression, never an IB snapshot.
            // Inventory references resolve lazily so saveable load order does not matter.
            _appliedMedical.Load(reader);
            ReadCoagulantTail(reader, _internalBleeding, out var coagulantTimers, out var coagulantMultipliers);
            Array.Copy(coagulantTimers, _ibDrainMultiplierTimer, SEGMENT_COUNT);
            Array.Copy(coagulantMultipliers, _ibDrainMultiplier, SEGMENT_COUNT);
            // Stage 1: EnforceFractureHP() удалён — перелом не трогает HP.
        }

        /// <summary>Load starts a new timeline; unsaved per-segment medical boosts never cross it.</summary>
        public void ResetNonPersistentEffectsForLoad()
        {
            if (_healBoostTimers != null) Array.Clear(_healBoostTimers, 0, _healBoostTimers.Length);
        }

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            for (int i = 0; i < SEGMENT_COUNT; i++) SaveLoadValidationContext.ReadFinite(reader, true);
            SaveLoadValidationContext.ReadFinite(reader, true);
            reader.ReadBoolean();
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                int bleeding = reader.ReadInt32();
                byte laceration = reader.ReadByte();
                if (bleeding < 0 || bleeding > 3 || !Enum.IsDefined(typeof(LacerationType), laceration))
                    throw new InvalidDataException("Invalid saved wound status.");
            }
            for (int i = 0; i < 3 * SEGMENT_COUNT; i++) reader.ReadBoolean();
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (reader.ReadInt32() < 0) throw new InvalidDataException("Invalid saved bandage counter.");
            var internalBleeding = new bool[SEGMENT_COUNT];
            for (int i = 0; i < SEGMENT_COUNT; i++) internalBleeding[i] = reader.ReadBoolean();
            for (int i = 0; i < SEGMENT_COUNT; i++) reader.ReadBoolean();
            _appliedMedical.ValidateLoad(reader, context);
            ReadCoagulantTail(reader, internalBleeding, out _, out _);
        }

        // Iteration 8a: preserve the existing payload prefix. The first pair is the
        // requested whole-body summary; the tagged extension retains independently
        // started segment treatments and fractional seconds without changing rev6.
        private void WriteCoagulantTail(BinaryWriter writer)
        {
            float maximumTimer = 0f;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                maximumTimer = Mathf.Max(maximumTimer, _ibDrainMultiplierTimer[i]);
            writer.Write((int)Math.Ceiling(maximumTimer));
            writer.Write(maximumTimer > 0f ? maximumTimer / COAGULANT_DURATION : 1f);
            writer.Write(COAGULANT_SEGMENT_TAIL_MARKER);
            writer.Write(SEGMENT_COUNT);
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                writer.Write(_ibDrainMultiplierTimer[i]);
                writer.Write(_ibDrainMultiplier[i]);
            }
        }

        private static void ReadCoagulantTail(BinaryReader reader, bool[] internalBleeding,
            out float[] timers, out float[] multipliers)
        {
            timers = new float[SEGMENT_COUNT];
            multipliers = new float[SEGMENT_COUNT];
            for (int i = 0; i < SEGMENT_COUNT; i++) multipliers[i] = 1f;

            // Rev4 stores consecutive unframed owners: remaining bytes belong to
            // the next owner, so they cannot be interpreted as an optional tail.
            if (K_SaveManager.LoadedSchemaRevision < 5) return;

            long remaining = reader.BaseStream.Length - reader.BaseStream.Position;
            if (remaining == 0) return; // Complete historical payload: inactive defaults.
            if (remaining != 2 * sizeof(int) && remaining != COAGULANT_TAIL_BYTES)
                throw new InvalidDataException("Truncated or invalid saved coagulant tail.");

            int summarySeconds = reader.ReadInt32();
            float summaryMultiplier = SaveLoadValidationContext.ReadFinite(reader, true);
            float summaryTimer = summarySeconds > 0 ? summaryMultiplier * COAGULANT_DURATION : 0f;
            if (summarySeconds < 0 || summarySeconds > COAGULANT_DURATION || summaryMultiplier > 1f ||
                (summarySeconds == 0 && summaryMultiplier != 1f) ||
                (summarySeconds > 0 && (summaryMultiplier <= 0f ||
                    summaryTimer > summarySeconds + 0.0001f || summaryTimer < summarySeconds - 1.0001f)))
                throw new InvalidDataException("Invalid saved coagulant summary.");

            if (remaining == 2 * sizeof(int))
            {
                // The summary-only format can represent one common active treatment.
                for (int i = 0; i < SEGMENT_COUNT; i++)
                {
                    if (!internalBleeding[i] || summarySeconds == 0) continue;
                    timers[i] = summaryTimer;
                    multipliers[i] = summaryMultiplier;
                }
                return;
            }

            if (reader.ReadInt32() != COAGULANT_SEGMENT_TAIL_MARKER || reader.ReadInt32() != SEGMENT_COUNT)
                throw new InvalidDataException("Invalid saved coagulant segment extension.");
            float maximumTimer = 0f;
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                float timer = SaveLoadValidationContext.ReadFinite(reader, true);
                float multiplier = SaveLoadValidationContext.ReadFinite(reader, true);
                if (timer > COAGULANT_DURATION || multiplier > 1f ||
                    (timer == 0f && multiplier != 1f) ||
                    (timer > 0f && (!internalBleeding[i] ||
                        Math.Abs(multiplier - timer / COAGULANT_DURATION) > 0.000001f)))
                    throw new InvalidDataException("Invalid saved per-segment coagulant state.");
                timers[i] = timer;
                multipliers[i] = multiplier;
                maximumTimer = Mathf.Max(maximumTimer, timer);
            }
            float expectedMultiplier = maximumTimer > 0f ? maximumTimer / COAGULANT_DURATION : 1f;
            if (summarySeconds != (int)Math.Ceiling(maximumTimer) || summaryMultiplier != expectedMultiplier)
                throw new InvalidDataException("Saved coagulant summary does not match segment state.");
        }

        public void OnAfterLoad()
        {
            if (_pendingLoadedHP == null) return;
            var savedHP = _pendingLoadedHP;
            _pendingLoadedHP = null;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                _ibDrainMultiplier[i] = _ibDrainMultiplierTimer[i] > 0f
                    ? Mathf.Clamp01(_ibDrainMultiplierTimer[i] / COAGULANT_DURATION) : 1f;

            float radiation = _cachedVitality != null ? _cachedVitality.Radiation : 0f;
            if (radiation >= 100f) ApplyRadiationClamp(radiation);
            else ApplyRadiationMaxHPReduction(radiation);
            if (radiation < 100f)
            {
                for (int i = 0; i < SEGMENT_COUNT; i++) _segments[i].SetHP(savedHP[i]);
                CheckDeathConditions();
            }
            NotifyChange();
        }

        // =====================================================================
        // BODY SEGMENT (внутренний класс — без изменений)
        // =====================================================================
        [Serializable]
        private class BodySegment
        {
            [SerializeField] private float _originalMaxHP;
            [SerializeField] private float _maxHP;
            [SerializeField] private float _currentHP;

            public float CurrentHP => _currentHP;
            public float MaxHP => _maxHP;
            public float OriginalMaxHP => _originalMaxHP;

            public BodySegment(float maxHP)
            {
                _originalMaxHP = maxHP;
                _maxHP = maxHP;
                _currentHP = maxHP;
            }

            public float ApplyDamageWithOverflow(float damage)
            {
                float actualDamage = Mathf.Min(_currentHP, damage);
                _currentHP = Mathf.Max(0f, _currentHP - actualDamage);
                return damage - actualDamage;
            }

            public void ApplyDamage(float damage)
            {
                _currentHP = Mathf.Max(0f, _currentHP - damage);
            }

            public bool Heal(float amount)
            {
                if (_currentHP >= _maxHP) return false;
                float oldHP = _currentHP;
                _currentHP = Mathf.Min(_currentHP + amount, _maxHP);
                return _currentHP > oldHP;
            }

            public void SetHP(float value)
            {
                _currentHP = Mathf.Clamp(value, 0f, _maxHP);
            }

            public void SetMaxHP(float value)
            {
                _maxHP = Mathf.Max(1f, value);
                ClampHP();
            }

            public void ClampHP()
            {
                _currentHP = Mathf.Clamp(_currentHP, 0f, _maxHP);
            }
        }

        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Debug: Set Bleeding Level 3 (Left Biceps)")]
        public void DebugSetBleeding()
        {
            SetExternalBleeding(BodyPart.LeftBiceps, 3);
            _limbStatuses[(int)BodyPart.LeftBiceps].laceration = LacerationType.Open;
            NotifyChange();
        }

        [ContextMenu("Debug: Stop All Bleeding")]
        public void DebugStopBleeding()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
                _limbStatuses[i].bleedingLevel = 0;
        }

        [ContextMenu("Debug: Remove All Lacerations")]
        public void DebugRemoveLaceration()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
                _limbStatuses[i].laceration = LacerationType.None;
        }

        [ContextMenu("Debug: Fracture Left Quadriceps")]
        public void DebugFractureLeftLeg() => ApplyFracture(BodyPart.LeftQuadriceps);

        [ContextMenu("Debug: Splint Left Quadriceps")]
        public void DebugSplintLeftLeg() => ApplySplint(BodyPart.LeftQuadriceps);

        [ContextMenu("Debug: Apply 50 Radiation")]
        public void DebugRadiation50() => ApplyRadiationClamp(50f);

        [ContextMenu("Debug: Apply 100 Radiation (Death)")]
        public void DebugRadiation100() => ApplyRadiationClamp(100f);
    }
}
