using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Stage 1 UI-миграция: drop-цель — Image сегмента куклы в инвентаре.
    ///
    /// Заменяет K_DropZoneSlot (удалён вместе с K_DropZoneRegistry).
    /// Владелец — K_InventoryHealthWidget: навешивает компонент на каждый
    /// _segmentImages[i] в Awake/Start и биндит через Bind().
    ///
    /// Ответственности:
    ///   1. Drag-out во время активного apply на этом сегменте → CancelApply.
    ///   2. Визуал apply: GhostIcon (иконка медикамента) + ProgressFill (прогресс).
    ///   3. Тинт самого Image сегмента через widget.SetSegmentColor().
    ///
    /// Конфиг визуала (цвет, спрайт, alpha, padding) приходит из K_MedicalMirrorPanel
    /// через K_InventoryHealthWidget.ConfigureDragOuts().
    ///
    /// СИНХРОННЫЙ. Без Coroutine/async/Task/yield.
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    public class K_BodyPartDragOut : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        private K_MedicalMirrorPanel _panel;
        private K_InventoryHealthWidget _widget;
        private BodyPart _part;
        private bool _bound;

        // ═══ Визуал apply ═══
        private Image _progressFill;
        private Image _ghostIcon;
        private bool _visualsEnsured;
        private bool _applyVisualActive;

        // Конфиг (дефолты — на случай, если панель ещё не передала config).
        private Color _progressColor = new Color(0.25f, 0.85f, 0.25f, 1f);
        private Sprite _progressSprite;
        private Image.FillMethod _progressFillMethod = Image.FillMethod.Radial360;
        private int _progressFillOrigin = 2; // Origin360.Top
        private bool _progressClockwise = true;
        private float _ghostAlpha = 0.5f;
        private float _ghostPadding = 4f;

        /// <summary>
        /// Забиндить drop-target. Вызывается K_InventoryHealthWidget
        /// при навешивании компонента. Идемпотентно.
        /// </summary>
        internal void Bind(K_MedicalMirrorPanel panel, K_InventoryHealthWidget widget, BodyPart part)
        {
            _panel = panel;
            _widget = widget;
            _part = part;
            _bound = true;
        }

        /// <summary>
        /// Толчок конфига визуала от панели. Идемпотентно:
        /// если визуалы уже созданы — переприменяем.
        /// </summary>
        internal void SetVisualConfig(
            Color progressColor,
            Sprite progressSprite,
            Image.FillMethod fillMethod,
            int fillOrigin,
            bool clockwise,
            float ghostAlpha,
            float ghostPadding)
        {
            _progressColor = progressColor;
            _progressSprite = progressSprite;
            _progressFillMethod = fillMethod;
            _progressFillOrigin = fillOrigin;
            _progressClockwise = clockwise;
            _ghostAlpha = ghostAlpha;
            _ghostPadding = ghostPadding;

            if (_visualsEnsured)
                ApplyConfigToVisuals();
        }

        /// <summary>
        /// Показать/обновить визуал apply. Идемпотентно: многократный вызов
        /// обновляет прогресс и иконку без пересоздания.
        /// Тинтует Image сегмента через widget.SetSegmentColor().
        /// </summary>
        public void SetApplyVisual(Sprite icon, float progress, Color lockedColor)
        {
            EnsureVisuals();
            _applyVisualActive = true;

            if (_widget != null && _bound)
                _widget.SetSegmentColor(_part, lockedColor);

            if (_ghostIcon != null)
            {
                if (_ghostIcon.sprite != icon) _ghostIcon.sprite = icon;
                if (!_ghostIcon.gameObject.activeSelf) _ghostIcon.gameObject.SetActive(true);
            }

            if (_progressFill != null)
            {
                _progressFill.fillAmount = Mathf.Clamp01(progress);
                if (!_progressFill.gameObject.activeSelf) _progressFill.gameObject.SetActive(true);
            }
        }

        /// <summary>
        /// Скрыть визуал и вернуть оригинальный цвет Image сегмента.
        /// При отсутствии активного apply — страховочная очистка (idempotent).
        /// </summary>
        public void ClearApplyVisual()
        {
            if (!_applyVisualActive)
            {
                // Страховка от рассинхрона (например, сегмент был выключен посреди apply).
                if ((_ghostIcon != null && _ghostIcon.gameObject.activeSelf) ||
                    (_progressFill != null && _progressFill.gameObject.activeSelf))
                {
                    HideVisuals();
                }
                return;
            }

            _applyVisualActive = false;
            HideVisuals();

            if (_widget != null && _bound)
                _widget.RestoreSegmentColor(_part);
        }

        /// <summary>
        /// Только тинт Image сегмента (без прогресса/иконки).
        /// </summary>
        public void SetLockedVisual(Color lockedColor)
        {
            if (_widget != null && _bound)
                _widget.SetSegmentColor(_part, lockedColor);
        }

        // ═════════════════════════════════════════════════════════════════
        // Внутренние
        // ═════════════════════════════════════════════════════════════════

        private void HideVisuals()
        {
            if (_ghostIcon != null)
            {
                _ghostIcon.sprite = null;
                if (_ghostIcon.gameObject.activeSelf)
                    _ghostIcon.gameObject.SetActive(false);
            }
            if (_progressFill != null)
            {
                _progressFill.fillAmount = 0f;
                if (_progressFill.gameObject.activeSelf)
                    _progressFill.gameObject.SetActive(false);
            }
        }

        private void EnsureVisuals()
        {
            if (_visualsEnsured) return;
            var rt = transform as RectTransform;
            if (rt == null) return;

            // ─── GhostIcon (нижний слой) ───
            var ghostGo = new GameObject("GhostIcon", typeof(RectTransform), typeof(Image));
            ghostGo.transform.SetParent(rt, false);
            var ghostRT = ghostGo.GetComponent<RectTransform>();
            ghostRT.anchorMin = Vector2.zero;
            ghostRT.anchorMax = Vector2.one;
            ghostRT.offsetMin = new Vector2(_ghostPadding, _ghostPadding);
            ghostRT.offsetMax = new Vector2(-_ghostPadding, -_ghostPadding);
            ghostRT.localScale = Vector3.one;
            ghostRT.localRotation = Quaternion.identity;

            _ghostIcon = ghostGo.GetComponent<Image>();
            _ghostIcon.raycastTarget = false;
            _ghostIcon.preserveAspect = true;
            _ghostIcon.color = new Color(1f, 1f, 1f, _ghostAlpha);
            _ghostIcon.enabled = true;
            ghostGo.SetActive(false);

            // ─── ProgressFill (верхний слой) ───
            var progGo = new GameObject("ProgressFill", typeof(RectTransform), typeof(Image));
            progGo.transform.SetParent(rt, false);
            var progRT = progGo.GetComponent<RectTransform>();
            progRT.anchorMin = Vector2.zero;
            progRT.anchorMax = Vector2.one;
            progRT.offsetMin = Vector2.zero;
            progRT.offsetMax = Vector2.zero;
            progRT.localScale = Vector3.one;
            progRT.localRotation = Quaternion.identity;

            _progressFill = progGo.GetComponent<Image>();
            _progressFill.raycastTarget = false;
            _progressFill.sprite = _progressSprite;
            _progressFill.color = _progressColor;
            _progressFill.type = Image.Type.Filled;
            _progressFill.fillMethod = _progressFillMethod;
            _progressFill.fillOrigin = _progressFillOrigin;
            _progressFill.fillClockwise = _progressClockwise;
            _progressFill.fillAmount = 0f;
            progGo.SetActive(false);

            _visualsEnsured = true;
        }

        private void ApplyConfigToVisuals()
        {
            if (_progressFill != null)
            {
                _progressFill.sprite = _progressSprite;
                _progressFill.color = _progressColor;
                _progressFill.fillMethod = _progressFillMethod;
                _progressFill.fillOrigin = _progressFillOrigin;
                _progressFill.fillClockwise = _progressClockwise;
            }
            if (_ghostIcon != null)
            {
                _ghostIcon.color = new Color(1f, 1f, 1f, _ghostAlpha);
                var rt = _ghostIcon.rectTransform;
                rt.offsetMin = new Vector2(_ghostPadding, _ghostPadding);
                rt.offsetMax = new Vector2(-_ghostPadding, -_ghostPadding);
            }
        }

        private void OnDisable()
        {
            // Прячем детей при выключении сегмента. _applyVisualActive не сбрасываем —
            // панель при следующем Update снова покажет визуал, если apply ещё идёт.
            if (_ghostIcon != null && _ghostIcon.gameObject.activeSelf)
                _ghostIcon.gameObject.SetActive(false);
            if (_progressFill != null && _progressFill.gameObject.activeSelf)
                _progressFill.gameObject.SetActive(false);
        }

        // ═════════════════════════════════════════════════════════════════
        // Drag-out (отмена apply при перетаскивании с сегмента)
        // ═════════════════════════════════════════════════════════════════

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (!_bound) return;
            if (eventData == null) return;
            if (eventData.button != PointerEventData.InputButton.Left) return;
            if (_panel == null) return;
            if (!_panel.IsApplying) return;
            if (_panel.AppliedPart != _part) return;
            _panel.CancelApply("drag-out");
        }

        public void OnDrag(PointerEventData eventData) { }
        public void OnEndDrag(PointerEventData eventData) { }
    }
}