using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Этап 6.4: применение эффектов медикамента к игроку.
    /// Чистый C#-класс (не MonoBehaviour). Fail-safe: null-зависимости → warn + skip.
    /// Stage 3: InternalBleeding — Коагулянт; Stage 4: JETT owns an applied item record.
    /// </summary>
    public class MedicalEffectApplier
    {
        private readonly K_HealthSystem _health;
        private readonly K_BloodSystem _blood;
        private readonly K_VitalitySystem _vitality;
        private readonly K_DebuffSystem _debuff;
        private readonly MedicalDatabase _db;

        private bool _warnedHealth;
        private bool _warnedBlood;
        private bool _warnedVitality;
        private bool _warnedDebuff;
        private bool _warnedDb;
        private bool _warnedLegacyLaceration;    // Этап 9

        public MedicalEffectApplier(
            K_HealthSystem health,
            K_BloodSystem blood,
            K_VitalitySystem vitality,
            K_DebuffSystem debuff,
            MedicalDatabase db)
        {
            _health = health;
            _blood = blood;
            _vitality = vitality;
            _debuff = debuff;
            _db = db;
        }

        public void ApplyEffects(MedicalEffect effects, BodyPart part, string itemID)
            => ApplyEffects(effects, part, itemID, null);

        /// <summary>Read-only admission check shared by ordinary medical start and commit.</summary>
        public bool CanApplyEffects(MedicalEffect effects, BodyPart part, string itemID, out string reason)
        {
            reason = null;
            effects = MedicalDatabase.ResolveEffects(itemID, effects);
            if ((int)part < 0 || (int)part >= 20 || effects == MedicalEffect.None)
            { reason = "эффект или зона недоступны"; return false; }
            if (_health != null && _health.IsDead)
            { reason = "игрок мёртв"; return false; }

            const MedicalEffect healthEffects = MedicalEffect.Fracture | MedicalEffect.Gunshot |
                MedicalEffect.BleedingLight | MedicalEffect.BleedingArterial | MedicalEffect.BleedingFull |
                MedicalEffect.InternalBleeding | MedicalEffect.Transamacha | MedicalEffect.JETT |
                MedicalEffect.Laceration | MedicalEffect.Laceration_Glue | MedicalEffect.Laceration_Strips |
                MedicalEffect.Laceration_Staples | MedicalEffect.Collar | MedicalEffect.HPRestore | MedicalEffect.HealBoost;
            if ((effects & healthEffects) != 0 && _health == null)
            { reason = "система здоровья недоступна"; return false; }
            if ((effects & MedicalEffect.BloodRestore) != 0 && _blood == null)
            { reason = "система крови недоступна"; return false; }
            if ((effects & MedicalEffect.Stimulator) != 0 && _vitality == null)
            { reason = "система метаболизма недоступна"; return false; }
            if ((effects & (MedicalEffect.Painkiller | MedicalEffect.Collar)) != 0 && _debuff == null)
            { reason = "система дебаффов недоступна"; return false; }
            if ((effects & (MedicalEffect.HPRestore | MedicalEffect.BloodRestore |
                MedicalEffect.Painkiller | MedicalEffect.HealBoost)) != 0 && _db == null)
            { reason = "медицинская база недоступна"; return false; }
            if ((effects & MedicalEffect.Collar) != 0 && part != BodyPart.Head)
            { reason = "воротник применяется только к голове"; return false; }
            if ((effects & MedicalEffect.JETT) != 0)
            { reason = "JETT требует механического применения с сохранением предмета"; return false; }
            if ((effects & MedicalEffect.Stimulator) != 0 && !_vitality.IsStimReady)
            { reason = "стимулятор ещё недоступен"; return false; }
            if ((effects & MedicalEffect.HPRestore) != 0 && !IsFinitePositive(_db.GetHPRestoreAmount(itemID)))
            { reason = "объём лечения HP недопустим"; return false; }
            if ((effects & MedicalEffect.BloodRestore) != 0 && !IsFinitePositive(_db.GetBloodRestoreMl(itemID)))
            { reason = "объём переливания недопустим"; return false; }
            if ((effects & MedicalEffect.Painkiller) != 0 && !IsFinitePositive(_db.GetEffectDuration(itemID)))
            { reason = "длительность обезболивания недопустима"; return false; }
            if ((effects & MedicalEffect.HealBoost) != 0 &&
                !_health.TryResolveHealBoostDuration(part, _db.GetEffectDuration(itemID), out _))
            { reason = "длительность усиления лечения недопустима"; return false; }
            return true;
        }

        private static bool IsFinitePositive(float value)
            => !float.IsNaN(value) && !float.IsInfinity(value) && value > 0f;

        public void ApplyEffects(MedicalEffect effects, BodyPart part, string itemID, InventoryItem item)
        {
            effects = MedicalDatabase.ResolveEffects(itemID, effects);
            if (effects == MedicalEffect.None) return;

            // A reusable JETT must retain item identity, charge and its bleeding
            // snapshot. Never route a legacy coagulant entry to the old IB timer.
            if ((effects & MedicalEffect.JETT) != 0)
            {
                if (!HasHealth()) return;
                if (item?.Data == null || item.Data.ItemID != itemID)
                {
                    Debug.LogWarning("[EffectApplier] JETT requires its inventory item; use the mechanical apply service.");
                    return;
                }
                _health.ApplyJETT(item, part);
                return;
            }

            if ((effects & MedicalEffect.Collar) != 0 && part != BodyPart.Head) return;

            // ── Статус-снятие ──
            if ((effects & MedicalEffect.Fracture) != 0)
            {
                if (HasHealth()) _health.ClearFracture(part);
            }

            if ((effects & MedicalEffect.Gunshot) != 0)
            {
                if (HasHealth()) _health.ClearGunshot(part);
            }

            // ── Этап 1: воротник — ClearFracture(Head) + CureTBI ──
            if ((effects & MedicalEffect.Collar) != 0)
            {
                if (HasHealth()) _health.ClearFracture(BodyPart.Head);
                if (HasDebuff()) _debuff.CureTBI();
            }

            // ── Кровотечения ──
            if ((effects & MedicalEffect.BleedingLight) != 0)
            {
                if (HasHealth()) _health.UseBandage(part);
            }

            if ((effects & MedicalEffect.BleedingArterial) != 0)
            {
                if (HasHealth()) _health.UseTourniquet(part);
            }

            // 6.4.1: полная остановка (гемостатик). Laceration НЕ трогает.
            if ((effects & MedicalEffect.BleedingFull) != 0)
            {
                if (HasHealth()) _health.UseHemostatic(part);
            }

            // ── Рваные раны (Этап 9) ──
            // Порядок: Staples+Strips → Sealed; Glue → Glued; legacy Laceration → Sealed.
            // Если случайно выставлено несколько новых флагов — выигрывает самый надёжный.
            if ((effects & (MedicalEffect.Laceration_Staples | MedicalEffect.Laceration_Strips)) != 0)
            {
                if (HasHealth()) _health.UseLacerationTreatment(part, LacerationType.Sealed);
            }
            else if ((effects & MedicalEffect.Laceration_Glue) != 0)
            {
                if (HasHealth()) _health.UseLacerationTreatment(part, LacerationType.Glued);
            }
            else if ((effects & MedicalEffect.Laceration) != 0)   // legacy, бит 1<<5
            {
                if (!_warnedLegacyLaceration)
                {
                    _warnedLegacyLaceration = true;
                    Debug.LogWarning(
                        "[EffectApplier] Legacy MedicalEffect.Laceration is still in use. " +
                        "Treated as Sealed. Re-run 'Populate Default Matrix' on MedicalDatabase to migrate.");
                }
                if (HasHealth()) _health.UseLacerationTreatment(part, LacerationType.Sealed);
            }

            // ── HP / кровь ──
            if ((effects & MedicalEffect.HPRestore) != 0)   // deprecated 6.4.2
            {
                if (HasHealth() && HasDb())
                    _health.HealSegment(part, _db.GetHPRestoreAmount(itemID));
            }

            if ((effects & MedicalEffect.BloodRestore) != 0)
            {
                if (HasBlood() && HasDb())
                    _blood.AddBlood(_db.GetBloodRestoreMl(itemID));
            }

            // ── Баффы ──
            if ((effects & MedicalEffect.Stimulator) != 0)
            {
                if (HasVitality()) _vitality.UseStimulatorEnhanced();
            }

            if ((effects & MedicalEffect.Painkiller) != 0)
            {
                if (HasDebuff() && HasDb())
                    _debuff.ActivatePainkiller(_db.GetEffectDuration(itemID));
            }
            // Stage 1 §10.4: HealBoost — per-segment.
            if ((effects & MedicalEffect.HealBoost) != 0)
            {
                if (HasHealth() && HasDb())
                    _health.ActivateHealBoost(part, _db.GetEffectDuration(itemID));
            }

            // ── Этап 3: спец-средства IB ──
            if ((effects & MedicalEffect.InternalBleeding) != 0)
            {
                if (HasHealth()) _health.ApplyCoagulant(part);
            }

            if ((effects & MedicalEffect.Transamacha) != 0)
            {
                if (HasHealth()) _health.ApplyTransamacha();
            }

#if UNITY_EDITOR
            Debug.Log($"[EffectApplier] Applied: {effects} on {part} (itemID='{itemID}')");
#endif
        }

        // ═══ Null-guard helpers (warn once) ═══
        private bool HasHealth()
        {
            if (_health != null) return true;
            if (!_warnedHealth) { _warnedHealth = true; Debug.LogWarning("[EffectApplier] K_HealthSystem is null — health effects skipped."); }
            return false;
        }
        private bool HasBlood()
        {
            if (_blood != null) return true;
            if (!_warnedBlood) { _warnedBlood = true; Debug.LogWarning("[EffectApplier] K_BloodSystem is null — blood effects skipped."); }
            return false;
        }
        private bool HasVitality()
        {
            if (_vitality != null) return true;
            if (!_warnedVitality) { _warnedVitality = true; Debug.LogWarning("[EffectApplier] K_VitalitySystem is null — stimulator effect skipped."); }
            return false;
        }
        private bool HasDebuff()
        {
            if (_debuff != null) return true;
            if (!_warnedDebuff) { _warnedDebuff = true; Debug.LogWarning("[EffectApplier] K_DebuffSystem is null — painkiller effect skipped."); }
            return false;
        }
        private bool HasDb()
        {
            if (_db != null) return true;
            if (!_warnedDb) { _warnedDb = true; Debug.LogWarning("[EffectApplier] MedicalDatabase is null — parameterized effects skipped."); }
            return false;
        }
    }
}
