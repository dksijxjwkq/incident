namespace K_Incident.Core
{
    /// <summary>
    /// Этап 6.6: русские названия сегментов тела в винительном падеже
    /// (для строки "Применить на <часть>").
    /// </summary>
    public static class BodyPartLocalization
    {
        public static string GetRussian(BodyPart part) => part switch
        {
            BodyPart.Head            => "голову",
            BodyPart.Chest           => "грудь",
            BodyPart.Stomach         => "живот",
            BodyPart.Pelvis          => "таз",
            BodyPart.LeftShoulder    => "левое плечо",
            BodyPart.RightShoulder   => "правое плечо",
            BodyPart.LeftBiceps      => "левый бицепс",
            BodyPart.RightBiceps     => "правый бицепс",
            BodyPart.LeftForearm     => "левое предплечье",
            BodyPart.RightForearm    => "правое предплечье",
            BodyPart.LeftHand        => "левую кисть",
            BodyPart.RightHand       => "правую кисть",
            BodyPart.LeftQuadriceps  => "левое бедро",
            BodyPart.RightQuadriceps => "правое бедро",
            BodyPart.LeftKnee         => "левое колено",
            BodyPart.RightKnee       => "правое колено",
            BodyPart.LeftShin        => "левую голень",
            BodyPart.RightShin       => "правую голень",
            BodyPart.LeftFoot        => "левую стопу",
            BodyPart.RightFoot       => "правую стопу",
            _ => part.ToString()
        };
    }
}