using UnityEngine;

namespace K_Incident.Core
{
    public enum DebuffKind
    {
        Concussion = 0,
        TBI = 1,
        BreathingDifficulty = 2,
        Immobilized = 3,
        InternalBleeding = 4
    }

    [System.Serializable]
    public struct DebuffConfig
    {
        [Tooltip("Имя дебафа для отладки (в логах).")]
        public string displayName;

        [Tooltip("Включён ли дебаф. Если false — не сработает, даже если триггер активен.")]
        public bool enabled;

        [Tooltip("Тип дебафа. НЕ МЕНЯТЬ — триггер зашит в логику K_DebuffSystem.")]
        public DebuffKind kind;

        [Tooltip("Длительность в секундах после срабатывания. " +
                 "0 = пока причина держится (перелом, HP сегмента). " +
                 ">0 = фиксированный таймер (Concussion).")]
        public float duration;

        [Tooltip("Множитель скорости движения. 1.0 = без штрафа.")]
        [Range(0f, 2f)] public float speedMultiplier;

        [Tooltip("Множитель восстановления стамины. 1.0 = без штрафа.")]
        [Range(0f, 2f)] public float staminaRegenMultiplier;

        [Tooltip("Множитель МАКСИМАЛЬНОЙ стамины. 1.0 = без изменений.")]
        [Range(0f, 2f)] public float staminaMaxMultiplier;

        [Tooltip("Множитель стабильности прицела. 1.0 = без штрафа. " +
                 "Меньше 1 = тряска прицела.")]
        [Range(0f, 2f)] public float aimStabilityMultiplier;

        [Tooltip("Запрещает спринт (бег). Ходьба работает.")]
        public bool blockSprint;

        [Tooltip("Множитель скорости потери крови. 1.0 = без изменений. " +
                 "2.0 = вдвое быстрее теряешь кровь.")]
        [Range(0f, 5f)] public float bloodDrainMultiplier;
    }

    [System.Serializable]
    public struct CoagulantConfig
    {
        [HideInInspector]
        [Tooltip("Включён ли коагулянт как предмет.")]
        public bool enabled;

        [HideInInspector]
        [Tooltip("Максимальный уровень кровотечения, который коагулянт останавливает ПОЛНОСТЬЮ. " +
                 "По умолчанию 2: level 1 и 2 → 0. Level 3 (артериальное) → снижается до 1, " +
                 "требуется жгут или хирург.")]
        [Range(1, 3)] public int fullStopMaxLevel;
    }

    [DefaultExecutionOrder(-1000)]
    public class K_HealthConfig : MonoBehaviour
    {
        public static K_HealthConfig Instance { get; private set; }

        [Header("══════ ПОРОГИ ТРИГГЕРОВ ДЕБАФОВ ══════")]

        [SerializeField, Tooltip("Минимальный урон выстрела в Голову для появления Сотрясения (Concussion). " +
            "Меньше порога — только HP-урон, дебаф не сработает.")]
        private float _concussionDamageThreshold = 15f;

        [SerializeField, Tooltip("Минимальный урон выстрела в Голову для появления ЧМТ (TBI). " +
            "Одновременно с TBI срабатывает и Сотрясение (если урон ≥ порога Сотрясения).")]
        private float _tbiDamageThreshold = 20f;

        [Header("══════ ДЕБАФЫ (5 штук) ══════")]
        [SerializeField]
        private DebuffConfig[] _debuffs = new DebuffConfig[5]
        {
            new DebuffConfig {
                displayName = "Сотрясение",
                enabled = true,
                kind = DebuffKind.Concussion,
                duration = 60f,
                speedMultiplier = 0.85f,
                staminaRegenMultiplier = 1f,
                staminaMaxMultiplier = 1f,
                aimStabilityMultiplier = 0.7f,
                blockSprint = false,
                bloodDrainMultiplier = 1f
            },
            new DebuffConfig {
                displayName = "Тяжёлая ЧМТ",
                enabled = true,
                kind = DebuffKind.TBI,
                duration = 0f,
                speedMultiplier = 1f,
                staminaRegenMultiplier = 0.7f,
                staminaMaxMultiplier = 1f,
                aimStabilityMultiplier = 1f,
                blockSprint = false,
                bloodDrainMultiplier = 1f
            },
            new DebuffConfig {
                displayName = "Тяжело дышать",
                enabled = true,
                kind = DebuffKind.BreathingDifficulty,
                duration = 0f,
                speedMultiplier = 1f,
                staminaRegenMultiplier = 0.5f,
                staminaMaxMultiplier = 0.6f,
                aimStabilityMultiplier = 1f,
                blockSprint = false,
                bloodDrainMultiplier = 1f
            },
            new DebuffConfig {
                displayName = "Обездвижен",
                enabled = true,
                kind = DebuffKind.Immobilized,
                duration = 0f,
                speedMultiplier = 1f,
                staminaRegenMultiplier = 1f,
                staminaMaxMultiplier = 1f,
                aimStabilityMultiplier = 1f,
                blockSprint = true,
                bloodDrainMultiplier = 1f
            },
            new DebuffConfig {
                displayName = "Внутреннее кровотечение",
                enabled = true,
                kind = DebuffKind.InternalBleeding,
                duration = 0f,
                speedMultiplier = 1f,
                staminaRegenMultiplier = 1f,
                staminaMaxMultiplier = 1f,
                aimStabilityMultiplier = 1f,
                blockSprint = false,
                bloodDrainMultiplier = 1f
            }
        };

        [Header("══════ КОАГУЛЯНТ ══════")]
        [HideInInspector]
        [SerializeField] private CoagulantConfig _coagulant = new CoagulantConfig {
            enabled = true,
            fullStopMaxLevel = 2
        };

        // ══════ Stage 1 §7.4: ЗОНАЛЬНЫЕ МНОЖИТЕЛИ (placeholder'ы) ══════
        [Header("══════ ZONE MULTIPLIERS (Stage 1 §7.4, placeholder) ══════")]
        [Tooltip("Индекс = уровень зоны 0..3. [0] = без травм, [3] = макс. штраф.")]
        [SerializeField] private float[] _armAimMultipliers   = { 1.00f, 0.85f, 0.65f, 0.40f };
        [SerializeField] private float[] _armSpeedMultipliers = { 1.00f, 0.90f, 0.75f, 0.50f };
        [SerializeField] private float[] _armNoiseMultipliers = { 1.00f, 1.10f, 1.25f, 1.50f };
        [SerializeField] private float[] _legSpeedMultipliers = { 1.00f, 0.85f, 0.65f, 0.40f };

        public float ConcussionDamageThreshold => _concussionDamageThreshold;
        public float TbiDamageThreshold => _tbiDamageThreshold;
        [System.Obsolete("Legacy external-bleeding configuration, retained for serialized compatibility. Production coagulant treats internal bleeding through medical effects and their configured duration.")]
        public CoagulantConfig Coagulant => _coagulant;

        public DebuffConfig GetDebuff(DebuffKind kind)
        {
            for (int i = 0; i < _debuffs.Length; i++)
                if (_debuffs[i].kind == kind) return _debuffs[i];
            Debug.LogError($"[HealthConfig] DebuffKind.{kind} not found in config!");
            return default;
        }

        // ══════ Stage 1 §7.4: геттеры зональных множителей ══════
        public float GetArmAimMultiplier(int level)   => _armAimMultipliers  [Mathf.Clamp(level, 0, 3)];
        public float GetArmSpeedMultiplier(int level) => _armSpeedMultipliers[Mathf.Clamp(level, 0, 3)];
        public float GetArmNoiseMultiplier(int level) => _armNoiseMultipliers[Mathf.Clamp(level, 0, 3)];
        public float GetLegSpeedMultiplier(int level) => _legSpeedMultipliers[Mathf.Clamp(level, 0, 3)];

        private void Awake()
        {
            NormalizeTbiThreshold();
            NormalizeInternalBleedingConfig();
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[HealthConfig] Duplicate instance — destroying.");
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void NormalizeTbiThreshold()
        {
            // Migrate the old scene value without removing the inspector's tuning control.
            if (_tbiDamageThreshold == 30f || _tbiDamageThreshold <= 0f ||
                float.IsNaN(_tbiDamageThreshold) || float.IsInfinity(_tbiDamageThreshold))
                _tbiDamageThreshold = 20f;
        }

        private void NormalizeInternalBleedingConfig()
        {
            if (_debuffs == null) return;

            for (int i = 0; i < _debuffs.Length; i++)
            {
                if (_debuffs[i].kind != DebuffKind.InternalBleeding) continue;

                DebuffConfig ib = _debuffs[i];
                ib.speedMultiplier = 1f;
                ib.staminaRegenMultiplier = 1f;
                ib.staminaMaxMultiplier = 1f;
                ib.aimStabilityMultiplier = 1f;
                ib.blockSprint = false;
                ib.bloodDrainMultiplier = 1f;
                _debuffs[i] = ib;
            }
        }

        private void OnValidate()
        {
            NormalizeTbiThreshold();
            if (_debuffs == null || _debuffs.Length != 5)
            {
                Debug.LogWarning("[HealthConfig] _debuffs должен быть массивом из 5 элементов. Автокоррекция.");
                var fixedArr = new DebuffConfig[5];
                if (_debuffs != null)
                    for (int i = 0; i < Mathf.Min(5, _debuffs.Length); i++)
                        fixedArr[i] = _debuffs[i];
                _debuffs = fixedArr;
            }
            NormalizeInternalBleedingConfig();
            for (int i = 0; i < _debuffs.Length; i++)
                for (int j = i + 1; j < _debuffs.Length; j++)
                    if (_debuffs[i].kind == _debuffs[j].kind)
                        Debug.LogError($"[HealthConfig] Duplicate DebuffKind.{_debuffs[i].kind} at indices {i} and {j}!");

            // Stage 1 §7.4: автокоррекция размеров массивов зональных множителей.
            if (_armAimMultipliers   == null || _armAimMultipliers.Length   != 4) _armAimMultipliers   = new[] { 1f, 0.85f, 0.65f, 0.40f };
            if (_armSpeedMultipliers == null || _armSpeedMultipliers.Length != 4) _armSpeedMultipliers = new[] { 1f, 0.90f, 0.75f, 0.50f };
            if (_armNoiseMultipliers == null || _armNoiseMultipliers.Length != 4) _armNoiseMultipliers = new[] { 1f, 1.10f, 1.25f, 1.50f };
            if (_legSpeedMultipliers == null || _legSpeedMultipliers.Length != 4) _legSpeedMultipliers = new[] { 1f, 0.85f, 0.65f, 0.40f };
        }
    }
}
