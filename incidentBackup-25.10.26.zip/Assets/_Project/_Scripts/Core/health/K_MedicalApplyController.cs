using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Этап 6.3.1: сессия применения медикамента на сегмент тела.
    ///
    /// Считает прогресс по duration, не имеет собственного MonoBehaviour,
    /// не рисует UI, не списывает медикамент, не применяет эффект.
    /// Аналог K_MedicalMirrorDragController по архитектуре.
    ///
    /// СИНХРОННЫЙ. Без Coroutine / async / Task / yield.
    /// </summary>
    public sealed class K_MedicalApplyController
    {
        private MedicalItemRecord _record;
        private BodyPart _part;
        private K_MedicalMirrorItem _sourceWidget;
        private float _elapsed;
        private float _duration;
        private bool _isRunning;

        public bool IsRunning => _isRunning;
        public ulong Generation { get; private set; }
        public MedicalItemRecord Record => _record;
        public BodyPart Part => _part;
        public K_MedicalMirrorItem SourceWidget => _sourceWidget;
        public float Elapsed => _elapsed;
        public float Duration => _duration;
        public float Progress => _duration > 0f ? Mathf.Clamp01(_elapsed / _duration) : 0f;

        /// <summary>
        /// Начать сессию. Возвращает false при невалидных данных
        /// (нет Item, duration &lt;= 0) или если уже идёт другая сессия.
        /// </summary>
        public bool Begin(
            MedicalItemRecord record, BodyPart part, float duration, K_MedicalMirrorItem sourceWidget)
        {
            if (float.IsNaN(duration) || float.IsInfinity(duration)) return false;
            if (record.Item == null) return false;
            if (duration <= 0f) return false;
            if (_isRunning) return false;

            unchecked { Generation++; }

            _record = record;
            _part = part;
            _duration = duration;
            _elapsed = 0f;
            _sourceWidget = sourceWidget;
            _isRunning = true;
            return true;
        }

        /// <summary>
        /// Продвинуть прогресс. Возвращает true, если сессия завершена
        /// (elapsed >= duration). НЕ сбрасывает состояние — вызывающий
        /// обязан вызвать Cancel() после обработки завершения.
        /// </summary>
        public bool Tick(float deltaTime)
        {
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime)) return false;
            if (!_isRunning) return false;
            if (deltaTime <= 0f) return false;

            _elapsed += deltaTime;
            if (_elapsed >= _duration)
            {
                _elapsed = _duration;
                return true;
            }
            return false;
        }

        /// <summary>Сброс сессии. Идемпотентно.</summary>
        public void Cancel()
        {
            if (_isRunning) unchecked { Generation++; }
            _isRunning = false;
            _record = default;
            _sourceWidget = null;
            _elapsed = 0f;
            _duration = 0f;
        }
    }
}
