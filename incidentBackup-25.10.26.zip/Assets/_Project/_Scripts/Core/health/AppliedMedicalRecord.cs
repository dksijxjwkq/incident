using System;
using System.Collections.Generic;
using K_Incident.Core.Inventory;

namespace K_Incident.Core
{
    // Stage 4: MedicalEffect asset bits stay unchanged; this is the runtime kind.
    public enum AppliedGhostKind { Tourniquet = 0, JETT = 1 }

    [Serializable]
    public sealed class AppliedMedicalRecord
    {
        public uint InstanceID;
        public BodyPart AppliedTo;
        public AppliedGhostKind Kind;
        // Stage 4: visual ceil percentage only; exact seconds remain authoritative.
        public int ChargePercent;
        public float RemainingSeconds;
        public float FullChargeSeconds = 420f;
        public bool IsVirtual;

        // Stage 4: populated for both sources, so UI/drop need no live inventory item.
        public string VirtualItemID;
        public int VirtualQuantity;
        public int VirtualDurability;

        // Stage 4: maximum observed external bleeding for each of the four segments.
        // IB is cleared by JETT and is deliberately never restored.
        public readonly Dictionary<int, int> SavedBleeding = new Dictionary<int, int>();

        // Stage 4: runtime convenience only; V8 resolves held items again by InstanceID.
        [NonSerialized] internal InventoryItem RuntimeItem;
    }
}
