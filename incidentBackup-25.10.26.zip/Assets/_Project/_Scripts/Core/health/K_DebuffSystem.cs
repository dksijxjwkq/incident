using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core
{
    public class K_DebuffSystem : MonoBehaviour, ISaveable
        , ISavePayloadValidator
    {
        [Header("References (auto-find)")]
        [SerializeField] private K_HealthSystem _healthSystem;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false;

        private const float DERIVED_CHECK_INTERVAL = 0.2f;
        private float _derivedCheckTimer;

        private float _concussionTimer;

        // ═══ Этап 6.4: Painkiller (не сохраняется в Save) ═══
        private float _painkillerTimer;

        private bool _tbiActive;
        private bool _breathingActive;
        private bool _immobilizedActive;
        private bool _internalBleedingActive;
        // Stage 1 §5.1: сотрясение от перелома головы (без шины).
        private bool _fractureConcussionActive;

        private bool _lastConcussion, _lastTbi, _lastBreathing, _lastImmobilized, _lastInternalBleeding;

        public event Action OnDebuffsChanged;

        /// <summary>
        /// Stage 1 §5.1: два независимых источника — таймер и перелом головы.
        /// Не складываются. True, если активен хотя бы один.
        /// </summary>
        public bool HasConcussion => IsDebuffEnabled(DebuffKind.Concussion) && (_concussionTimer > 0f || _fractureConcussionActive);
        public bool HasTBI => IsDebuffEnabled(DebuffKind.TBI) && _tbiActive;
        public bool HasBreathingDifficulty => IsDebuffEnabled(DebuffKind.BreathingDifficulty) && _breathingActive;
        public bool HasImmobilized => IsDebuffEnabled(DebuffKind.Immobilized) && _immobilizedActive;
        public bool HasInternalBleeding =>
            IsDebuffEnabled(DebuffKind.InternalBleeding) && _healthSystem != null && _healthSystem.HasAnyInternalBleedingRevealed();

        private static bool IsDebuffEnabled(DebuffKind kind)
        {
            var config = K_HealthConfig.Instance;
            return config == null || config.GetDebuff(kind).enabled;
        }

        public bool IsUnderPainkiller => _painkillerTimer > 0f;   // Этап 6.4

        public string SaveID => "PlayerDebuffs";
        public bool IsDirty { get; set; } = true;

        private void Awake()
        {
            if (_healthSystem == null) _healthSystem = GetComponent<K_HealthSystem>();
            if (_healthSystem == null)
                Debug.LogError("[DebuffSystem] K_HealthSystem not found!");
        }

        private void OnEnable()
        {
            if (_healthSystem != null)
                _healthSystem.OnDamageTaken += HandleDamageTaken;
        }

        private void OnDisable()
        {
            if (_healthSystem != null)
                _healthSystem.OnDamageTaken -= HandleDamageTaken;
        }

        private void Start()
        {
            K_SaveManager.Instance?.Register(this);
            RefreshDerivedDebuffs();
        }

        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
            OnDebuffsChanged = null;
        }

        private void Update()
        {
            if (_concussionTimer > 0f)
            {
                _concussionTimer -= Time.deltaTime;
                if (_concussionTimer <= 0f)
                {
                    _concussionTimer = 0f;
                    if (_debugLogs) Debug.Log("[DebuffSystem] Concussion expired.");
                    FireChangedIfNeeded();
                }
            }

            // ═══ Этап 6.4: Painkiller tick ═══
            if (_painkillerTimer > 0f)
            {
                _painkillerTimer -= Time.deltaTime;
                if (_painkillerTimer <= 0f)
                {
                    _painkillerTimer = 0f;
                    if (_debugLogs) Debug.Log("[DebuffSystem] Painkiller expired.");
                }
            }

            _derivedCheckTimer += Time.deltaTime;
            if (_derivedCheckTimer >= DERIVED_CHECK_INTERVAL)
            {
                _derivedCheckTimer = 0f;
                RefreshDerivedDebuffs();
            }
        }

        private void HandleDamageTaken(BodyPart part, float damage, DamageType type)
        {
            if (part != BodyPart.Head) return;
            if (type != DamageType.Firearm) return;

            var config = K_HealthConfig.Instance;
            if (config == null)
            {
                Debug.LogWarning("[DebuffSystem] K_HealthConfig.Instance is null — cannot resolve debuff thresholds.");
                return;
            }

            if (!_tbiActive && damage >= config.TbiDamageThreshold)
            {
                var cfg = config.GetDebuff(DebuffKind.TBI);
                if (cfg.enabled)
                {
                    _tbiActive = true;
                    Debug.Log($"[DebuffSystem] TBI activated (damage {damage:F0} ≥ {config.TbiDamageThreshold:F0})");
                }
            }

            if (damage >= config.ConcussionDamageThreshold)
            {
                var cfg = config.GetDebuff(DebuffKind.Concussion);
                if (cfg.enabled)
                {
                    _concussionTimer = Mathf.Max(_concussionTimer, cfg.duration);
                    Debug.Log($"[DebuffSystem] Concussion activated/refreshed (damage {damage:F0}, timer {_concussionTimer:F0}s)");
                }
            }

            FireChangedIfNeeded();
        }

        /// <summary>
        /// Stage 1 §5: пересчёт производных дебаффов.
        /// - BreathingDifficulty: перелом груди без шины ИЛИ огнестрел в грудь.
        /// - Immobilized: перелом таза без шины.
        /// - _fractureConcussionActive: перелом головы без шины (даёт HasConcussion).
        /// - InternalBleeding: реальный revealed IB из K_HealthSystem.
        /// </summary>
        private void RefreshDerivedDebuffs()
        {
            if (_healthSystem == null) return;

            bool chestFracture = _healthSystem.IsFractured(BodyPart.Chest)
                              && !_healthSystem.IsSplinted(BodyPart.Chest);
            bool chestGunshot = _healthSystem.IsGunshot(BodyPart.Chest);
            bool breathing = chestFracture || chestGunshot;

            bool immobilized = _healthSystem.IsFractured(BodyPart.Pelvis)
                            && !_healthSystem.IsSplinted(BodyPart.Pelvis);

            bool headFracture = _healthSystem.IsFractured(BodyPart.Head)
                             && !_healthSystem.IsSplinted(BodyPart.Head);

            // Stage 2 §4.5: реальный IB от K_HealthSystem (только revealed).
            bool internalBleed = _healthSystem.HasAnyInternalBleedingRevealed();

            bool changed = false;
            if (_breathingActive != breathing) { _breathingActive = breathing; changed = true; }
            if (_immobilizedActive != immobilized) { _immobilizedActive = immobilized; changed = true; }
            if (_internalBleedingActive != internalBleed) { _internalBleedingActive = internalBleed; changed = true; }
            if (_fractureConcussionActive != headFracture) { _fractureConcussionActive = headFracture; changed = true; }

            if (changed) FireChangedIfNeeded();
        }

        public float GetSpeedMultiplier()
        {
            if (IsUnderPainkiller) return 1f;
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).speedMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).speedMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).speedMultiplier;
            // Immobilized only blocks sprint. The separate leg-zone rules still apply.
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).speedMultiplier;
            return m;
        }

        public float GetStaminaRegenMultiplier()
        {
            if (IsUnderPainkiller) return 1f;
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).staminaRegenMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).staminaRegenMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).staminaRegenMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).staminaRegenMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).staminaRegenMultiplier;
            return m;
        }

        public float GetStaminaMaxMultiplier()
        {
            if (IsUnderPainkiller) return 1f;
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).staminaMaxMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).staminaMaxMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).staminaMaxMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).staminaMaxMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).staminaMaxMultiplier;
            return m;
        }

        /// <summary>Breathing difficulty raises stamina expenditure, independently of recovery.</summary>
        public float GetStaminaDrainMultiplier()
            => IsUnderPainkiller || !HasBreathingDifficulty ? 1f : 1.3f;

        public float GetAimStabilityMultiplier()
        {
            // 6.4: обезбол полностью убирает тряску.
            if (IsUnderPainkiller) return 1f;

            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).aimStabilityMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).aimStabilityMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).aimStabilityMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).aimStabilityMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).aimStabilityMultiplier;
            return m;
        }

        public bool IsSprintBlocked()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return false;

            if (HasConcussion && c.GetDebuff(DebuffKind.Concussion).blockSprint) return true;
            if (HasTBI && c.GetDebuff(DebuffKind.TBI).blockSprint) return true;
            // Breathing difficulty never blocks sprint, including stale serialized configs.
            if (HasImmobilized && c.GetDebuff(DebuffKind.Immobilized).blockSprint) return true;
            if (HasInternalBleeding && c.GetDebuff(DebuffKind.InternalBleeding).blockSprint) return true;
            return false;
        }

        public float GetBloodDrainMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).bloodDrainMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).bloodDrainMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).bloodDrainMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).bloodDrainMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).bloodDrainMultiplier;
            return m;
        }

        private void FireChangedIfNeeded()
        {
            bool changed = false;
            if (_lastConcussion != HasConcussion) { _lastConcussion = HasConcussion; changed = true; }
            if (_lastTbi != HasTBI) { _lastTbi = HasTBI; changed = true; }
            if (_lastBreathing != HasBreathingDifficulty) { _lastBreathing = HasBreathingDifficulty; changed = true; }
            if (_lastImmobilized != HasImmobilized) { _lastImmobilized = HasImmobilized; changed = true; }
            if (_lastInternalBleeding != HasInternalBleeding) { _lastInternalBleeding = HasInternalBleeding; changed = true; }

            if (changed)
            {
                if (_debugLogs)
                {
                    Debug.Log($"[DebuffSystem] State: Concussion={HasConcussion} TBI={HasTBI} " +
                              $"Breathing={HasBreathingDifficulty} Immobilized={HasImmobilized} " +
                              $"InternalBleeding={HasInternalBleeding}");
                }
                IsDirty = true;
                OnDebuffsChanged?.Invoke();
            }
        }

        // 6.4: _painkillerTimer НЕ сохраняется (временный боевой эффект).
        // Save-формат НЕ изменён.
        public void Save(BinaryWriter writer)
        {
            writer.Write(_concussionTimer);
            writer.Write(_tbiActive);
            // V6 (Stage 1 §13): сотрясение от перелома головы.
            writer.Write(_fractureConcussionActive);
        }

        public void Load(BinaryReader reader)
        {
            ResetNonPersistentEffectsForLoad();
            _concussionTimer = reader.ReadSingle();
            _tbiActive = reader.ReadBoolean();
            // V6 (Stage 1 §13)
            _fractureConcussionActive = reader.ReadBoolean();
            RefreshDerivedDebuffs();
            FireChangedIfNeeded();
            IsDirty = false;
        }

        /// <summary>Uses the same Load-boundary policy as health boosts and vitality stimulants.</summary>
        public void ResetNonPersistentEffectsForLoad() => _painkillerTimer = 0f;

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            SaveLoadValidationContext.ReadFinite(reader, true);
            reader.ReadBoolean();
            reader.ReadBoolean();
        }

        public void CureConcussion()
        {
            if (_concussionTimer <= 0f) return;
            _concussionTimer = 0f;
            Debug.Log("[DebuffSystem] Concussion cured.");
            FireChangedIfNeeded();
        }

        /// <summary>Stage 5.1 explicit status call, independent of HP damage events.</summary>
        public void ApplyCombatConcussion(K_HealthConfig healthConfig = null)
        {
            var config = healthConfig != null ? healthConfig : K_HealthConfig.Instance;
            if (config != null && !config.GetDebuff(DebuffKind.Concussion).enabled) return;
            float duration = config != null ? config.GetDebuff(DebuffKind.Concussion).duration : 60f;
            if (float.IsNaN(duration) || float.IsInfinity(duration) || duration <= 0f)
                throw new InvalidOperationException("Concussion duration must be finite and positive.");
            _concussionTimer = Mathf.Max(_concussionTimer, duration);
            IsDirty = true;
            FireChangedIfNeeded();
        }

        /// <summary>Stage 5.1 permanent TBI status; existing treatment remains available.</summary>
        public void ApplyCombatTBI(K_HealthConfig healthConfig = null)
        {
            var config = healthConfig != null ? healthConfig : K_HealthConfig.Instance;
            if (config != null && !config.GetDebuff(DebuffKind.TBI).enabled) return;
            _tbiActive = true;
            IsDirty = true;
            FireChangedIfNeeded();
        }

        /// <summary>Stage 5.1 immediate refresh after a separate fracture/gunshot call.</summary>
        public void RefreshCombatDerivedDebuffs() => RefreshDerivedDebuffs();

        /// <summary>
        /// Этап 6.4: активировать/обновить обезбол. Refresh через Max.
        /// duration &lt;= 0 → no-op. Не сохраняется в Save (временный эффект).
        /// </summary>
        public bool CanActivatePainkiller(float duration)
            => !float.IsNaN(duration) && !float.IsInfinity(duration) && duration > 0f && duration > _painkillerTimer;

        public void ActivatePainkiller(float duration)
        {
            if (duration <= 0f) return;
            _painkillerTimer = Mathf.Max(_painkillerTimer, duration);
            if (_debugLogs)
                Debug.Log($"[DebuffSystem] Painkiller active: {_painkillerTimer:F1}s");
        }

        public void CureTBI()
        {
            if (!_tbiActive) return;
            _tbiActive = false;
            Debug.Log("[DebuffSystem] TBI cured.");
            FireChangedIfNeeded();
        }

        [ContextMenu("Debug: Apply Concussion (60s)")]
        public void DebugApplyConcussion()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return;
            _concussionTimer = c.GetDebuff(DebuffKind.Concussion).duration;
            FireChangedIfNeeded();
        }

        [ContextMenu("Debug: Apply TBI")]
        public void DebugApplyTBI()
        {
            _tbiActive = true;
            FireChangedIfNeeded();
        }

        [ContextMenu("Debug: Print State")]
        public void DebugPrintState()
        {
            Debug.Log($"[DebuffSystem] Concussion={HasConcussion} ({_concussionTimer:F1}s) " +
                      $"TBI={HasTBI} Breathing={HasBreathingDifficulty} " +
                      $"Immobilized={HasImmobilized} InternalBleeding={HasInternalBleeding}");
        }

        [ContextMenu("Debug: Cure All")]
        public void DebugCureAll()
        {
            _concussionTimer = 0f;
            _tbiActive = false;
            FireChangedIfNeeded();
        }
    }
}
