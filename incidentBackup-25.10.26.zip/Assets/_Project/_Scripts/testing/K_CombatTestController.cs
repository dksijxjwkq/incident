﻿
using System;
using UnityEngine;
using System.Collections.Generic;
using K_Incident.Core.Inventory;
using K_Incident.Core.Combat;
using UnityEngine.InputSystem;

namespace K_Incident.Core
{
    public class K_CombatTestController : MonoBehaviour
    {
        // =====================================================================
        // КОНСТАНТЫ БАЛАНСА
        // =====================================================================
        private const float PISTOL_DAMAGE = 30f;
        private const float ASSAULT_DAMAGE = 35f;
        private const float SHOTGUN_DAMAGE = 50f;
        private const float RIFLE_DAMAGE = 50f;

        private const float PISTOL_FRACTURE_CHANCE = 0.4f;
        private const float ASSAULT_FRACTURE_CHANCE = 0.6f;
        private const float SHOTGUN_FRACTURE_CHANCE = 0.8f;
        private const float RIFLE_FRACTURE_CHANCE = 0.8f;

        private const int PISTOL_BLEEDING_LEVEL = 1;
        private const int ASSAULT_BLEEDING_LEVEL = 2;
        private const int SHOTGUN_BLEEDING_LEVEL = 3;
        private const int RIFLE_BLEEDING_LEVEL = 3;

        // =====================================================================
        // ССЫЛКИ
        // =====================================================================
        [Header("System References")]
        [SerializeField] private K_HealthSystem _healthSystem;
        [SerializeField] private K_VitalitySystem _vitalitySystem;
        [SerializeField] private K_PlayerMotor _playerMotor;
        // Stage 1: _coagulantItem → _gelItem (K_CoagulantItem удалён, гель per-segment).
        [SerializeField] private K_GelItem _gelItem;

        // Stage 4: player item first, then actual opened loot, then debug virtual fallback.
        [SerializeField] private K_InventoryUI _inventoryUI;
        [SerializeField] private ItemDatabase _itemDatabase;

        [Header("Diagnostics (explicit opt-in)")]
        [SerializeField, Tooltip("Включает тестовые Ctrl-сочетания и резервирует их для диагностики. По умолчанию выключено: Ctrl остаётся приседом с обычным боевым вводом.")]
        private bool _diagnosticsEnabled;
        public bool DiagnosticsEnabled => _diagnosticsEnabled;

        private void OnEnable() => CombatDiagnosticInput.RegisterOwner(this, () => DiagnosticsEnabled);
        private void OnDisable() => CombatDiagnosticInput.UnregisterOwner(this);
        private void OnDestroy() => CombatDiagnosticInput.UnregisterOwner(this);




        private void Awake()
        {
            if (_healthSystem == null) _healthSystem = GetComponent<K_HealthSystem>();
            if (_vitalitySystem == null) _vitalitySystem = GetComponent<K_VitalitySystem>();
            if (_playerMotor == null) _playerMotor = GetComponent<K_PlayerMotor>();
            if (_gelItem == null) _gelItem = GetComponent<K_GelItem>();

            if (_healthSystem == null) Debug.LogError("[CombatTest] K_HealthSystem NOT FOUND!");
            if (_vitalitySystem == null) Debug.LogError("[CombatTest] K_VitalitySystem NOT FOUND!");
            if (_gelItem == null) Debug.LogWarning("[CombatTest] K_GelItem NOT FOUND!");
        }

        private void Start()
        {
            // Stage 4: scene-wide resolution only in Start; no searches in hotkeys.
            if (_inventoryUI == null)
                _inventoryUI = FindFirstObjectByType<K_InventoryUI>(FindObjectsInactive.Include);
            if (_itemDatabase == null)
                _itemDatabase = K_InventorySetup.DatabaseInstance;
        }

               private void Update()
        {
            HandleTestInput();
        }

        // =====================================================================
        // ВВОД (КЛАВИШИ 1-0, =, Q/W/E)
        // =====================================================================
       private void HandleTestInput()
{
    if (Keyboard.current == null) return;
    if (!CombatDiagnosticInput.IsReservedControlChord(
        Keyboard.current[Key.LeftCtrl].isPressed || Keyboard.current[Key.RightCtrl].isPressed)) return;
    if (!(Keyboard.current[Key.LeftCtrl].isPressed || Keyboard.current[Key.RightCtrl].isPressed)) return;
    if (_inventoryUI != null && (_inventoryUI.IsOpen || _inventoryUI.IsDragging)) return;
    if (UnityEngine.EventSystems.EventSystem.current != null &&
        UnityEngine.EventSystems.EventSystem.current.IsPointerOverGameObject()) return;

    if (Keyboard.current.digit1Key.wasPressedThisFrame)
        TestFirearmHit("Pistol", PISTOL_DAMAGE, PISTOL_BLEEDING_LEVEL, PISTOL_FRACTURE_CHANCE,
                       ResolveTarget(BodyPart.LeftBiceps));

    if (Keyboard.current.digit2Key.wasPressedThisFrame)
        TestFirearmHit("Assault Rifle", ASSAULT_DAMAGE, ASSAULT_BLEEDING_LEVEL, ASSAULT_FRACTURE_CHANCE,
                       ResolveTarget(BodyPart.LeftQuadriceps));

    if (Keyboard.current.digit3Key.wasPressedThisFrame)
        TestFirearmHit("Shotgun", SHOTGUN_DAMAGE, SHOTGUN_BLEEDING_LEVEL, SHOTGUN_FRACTURE_CHANCE,
                       ResolveTarget(BodyPart.RightBiceps));

    if (Keyboard.current.digit4Key.wasPressedThisFrame)
        TestFirearmHit("Rifle", RIFLE_DAMAGE, RIFLE_BLEEDING_LEVEL, RIFLE_FRACTURE_CHANCE,
                       ResolveTarget(BodyPart.RightQuadriceps));

    if (Keyboard.current.digit5Key.wasPressedThisFrame) UseBandage();
    if (Keyboard.current.digit6Key.wasPressedThisFrame) UseSplint();
    if (Keyboard.current.digit7Key.wasPressedThisFrame) UseStrips();      // renamed (было UseSutureKit)
    if (Keyboard.current.digit8Key.wasPressedThisFrame) UseGel();
    if (Keyboard.current.digit9Key.wasPressedThisFrame) UseStimulatorEnhanced();
    if (Keyboard.current.digit0Key.wasPressedThisFrame) TestColdExposure();

    // Этап 9: медицина рваных ран.
    // Stage 4: U reserved for IB x3; glue moves to G.
    if (Keyboard.current.gKey.wasPressedThisFrame) UseGlue();
    if (Keyboard.current.iKey.wasPressedThisFrame) UseStaples();

    // Этап 9: симуляция прыжка.
    if (Keyboard.current.jKey.wasPressedThisFrame) SimulateJump();

    // Stage 2 §4.5: тест внутреннего кровотечения.
    if (Keyboard.current.lKey.wasPressedThisFrame) ClearAllIB();
    if (Keyboard.current.kKey.wasPressedThisFrame) TestAddIB();
    if (Keyboard.current.semicolonKey.wasPressedThisFrame) TestForceIB();

    // Stage 3: тестовые применения трёх спец-средств IB.
    if (Keyboard.current.qKey.wasPressedThisFrame) TestCoagulant();
    if (Keyboard.current.wKey.wasPressedThisFrame) TestTransamacha();
    if (Keyboard.current.eKey.wasPressedThisFrame) TestJETT();

    // Stage 4: R/T/Y/U — reusable mechanical means on the left arm.
    if (Keyboard.current.rKey.wasPressedThisFrame) TestApplied(AppliedGhostKind.Tourniquet);
    if (Keyboard.current.tKey.wasPressedThisFrame) TestApplied(AppliedGhostKind.JETT);
    if (Keyboard.current.yKey.wasPressedThisFrame) TestRemoveApplied();
    if (Keyboard.current.uKey.wasPressedThisFrame) TestForceIBThree();

    // Stage 4: T reserved for JETT; reset target moves to Backspace.
    if (Keyboard.current.backspaceKey.wasPressedThisFrame)
        ClearTargetPart();

    if (Keyboard.current.equalsKey.wasPressedThisFrame) UseVodka();
}
               private void TestFirearmHit(string weaponName, float damage, int bleedingLevel, float fractureChance, BodyPart targetPart)
        {
            if (_healthSystem == null || _healthSystem.IsDead)
            {
                Debug.LogWarning("[CombatTest] HealthSystem not found or player is dead!");
                return;
            }

            Debug.Log($"[CombatTest] ============================================");
            Debug.Log($"[CombatTest] FIREARM HIT: {weaponName}");
            Debug.Log($"[CombatTest] HP/wound-only: Damage {damage} HP | Bleeding {bleedingLevel}. Fracture resolver is not exercised by this legacy diagnostic.");
            Debug.Log($"[CombatTest] Target: {targetPart}");
            Debug.Log($"[CombatTest] ============================================");

            _healthSystem.TakeDamage(damage, targetPart, DamageType.Firearm, bleedingLevel);

            PrintHealthStatus();
        }

        // =====================================================================
        // МЕДИЦИНА
        // =====================================================================
        private void UseBandage()
        {
            if (_healthSystem == null) return;

            int maxBleedingLevel = _healthSystem.GetMaxBleedingLevel();
            if (maxBleedingLevel == 0)
            {
                Debug.Log("[CombatTest] No bleeding to stop!");
                return;
            }

            bool success = _healthSystem.UseBandage();
            if (success) Debug.Log($"[CombatTest] BANDAGE USED! Max bleeding level reduced by 1");

            PrintHealthStatus();
        }

        private void UseSplint()
        {
            if (_healthSystem == null) return;

            BodyPart[] limbs = {
                BodyPart.LeftShoulder, BodyPart.RightShoulder,
                BodyPart.LeftBiceps, BodyPart.RightBiceps,
                BodyPart.LeftForearm, BodyPart.RightForearm,
                BodyPart.LeftQuadriceps, BodyPart.RightQuadriceps,
                BodyPart.LeftKnee, BodyPart.RightKnee,
                BodyPart.LeftShin, BodyPart.RightShin,
                BodyPart.Pelvis, BodyPart.Chest
            };

            bool foundFracture = false;
            foreach (var limb in limbs)
            {
                if (_healthSystem.IsFractured(limb) && !_healthSystem.IsSplinted(limb))
                {
                    _healthSystem.ApplySplint(limb);
                    Debug.Log($"[CombatTest] SPLINT APPLIED to {limb}!");
                    foundFracture = true;
                    break;
                }
            }

            if (!foundFracture) Debug.Log("[CombatTest] No fractures to splint!");

            PrintHealthStatus();
        }

        // ── Этап 9: три средства от рваных ран ──
        private void UseStrips()
        {
            ApplyLacerationToAllOpen(LacerationType.Sealed, "STRIPS");
        }

        private void UseGlue()
        {
            ApplyLacerationToAllOpen(LacerationType.Glued, "GLUE");
        }

        private void UseStaples()
        {
            ApplyLacerationToAllOpen(LacerationType.Sealed, "STAPLES");
        }

        /// <summary>
        /// Stage 1: замена устаревшего UseCoagulant (K_CoagulantItem удалён).
        /// Применяет гель на текущий target (или Chest по умолчанию).
        /// </summary>
        private void UseGel()
        {
            if (_gelItem == null)
            {
                Debug.Log("[CombatTest] K_GelItem not found!");
                return;
            }

            BodyPart target = ResolveTarget(BodyPart.Chest);
            bool success = _gelItem.UseGel(target, 120f);

            if (success)
                Debug.Log($"[CombatTest] GEL APPLIED on {target}. HealBoost ×5 for 120s.");
            else
                Debug.Log("[CombatTest] GEL FAILED — HealthSystem missing.");

            PrintHealthStatus();
        }

        private void ApplyLacerationToAllOpen(LacerationType type, string label)
        {
            if (_healthSystem == null) return;

            if (!_healthSystem.HasAnyOpenLaceration())
            {
                Debug.Log($"[CombatTest] No open laceration to treat with {label}!");
                return;
            }

            int treated = 0;
            for (int i = 0; i < 20; i++)
            {
                var part = (BodyPart)i;
                if (!_healthSystem.HasOpenLaceration(part)) continue;
                if (_healthSystem.UseLacerationTreatment(part, type)) treated++;
            }

            Debug.Log($"[CombatTest] {label} applied to {treated} segment(s).");
            PrintHealthStatus();
        }

        // ── Этап 9: прыжок ──
        private void SimulateJump()
        {
            if (_healthSystem == null)
            {
                Debug.LogWarning("[CombatTest] HealthSystem not found!");
                return;
            }
            Debug.Log("[CombatTest] SIMULATE JUMP");

            if (_playerMotor != null)
            {
                _playerMotor.NotifyJumped();
            }
            else
            {
                _healthSystem.NotifyJump();
                Debug.LogWarning("[CombatTest] PlayerMotor not found — jump ×3 activity multiplier not set.");
            }

            PrintHealthStatus();
        }

        // ── Stage 2 §4.5: тесты внутреннего кровотечения ──
        private void ClearAllIB()
        {
            if (_healthSystem == null) return;
            _healthSystem.ClearAllInternalBleeding();
            Debug.Log("[CombatTest] All IB cleared.");
            PrintHealthStatus();
        }

        private void TestAddIB()
        {
            if (_healthSystem == null) return;
            BodyPart part = ResolveTarget(BodyPart.Chest);
            _healthSystem.ApplyFracture(part);
            Debug.Log($"[CombatTest] ApplyFracture({part}) — roll for IB (15%).");
            PrintHealthStatus();
        }

        private void TestForceIB()
        {
            if (_healthSystem == null) return;
            BodyPart part = ResolveTarget(BodyPart.Chest);
            _healthSystem.DebugSetInternalBleeding(part, reveal: false);
            Debug.Log($"[CombatTest] FORCE IB on {part} (reveal in 120s).");
            PrintHealthStatus();
        }

        // Stage 3: прямые тестовые вызовы HealthSystem без расходования предмета.
        private void TestCoagulant()
        {
            if (_healthSystem == null) return;
            BodyPart part = ResolveTarget(BodyPart.Chest);
            _healthSystem.ApplyCoagulant(part);
            Debug.Log($"[CombatTest] Coagulant requested on {part}.");
            PrintHealthStatus();
        }

        private void TestTransamacha()
        {
            if (_healthSystem == null) return;
            _healthSystem.ApplyTransamacha();
            Debug.Log("[CombatTest] Transamacha requested.");
            PrintHealthStatus();
        }

        private void TestJETT()
        {
            if (_healthSystem == null) return;
            BodyPart part = ResolveTarget(BodyPart.LeftShoulder);
            _healthSystem.ApplyJETT(part);
            Debug.Log($"[CombatTest] JETT requested on {part}.");
            PrintHealthStatus();
        }

        // Stage 4: test the same applied-record path as the UI, with real charge.
        private void TestApplied(AppliedGhostKind kind)
        {
            var manager = _healthSystem?.AppliedMedical;
            if (manager == null)
            {
                Debug.LogWarning("[CombatTest] AppliedMedical manager not initialized.");
                return;
            }

            var medicalItems = _inventoryUI?.MedicalInventoryService?.GetMedicalItems();
            if (medicalItems != null)
            {
                foreach (var medical in medicalItems)
                {
                    var item = medical.Item;
                    if (item?.Data == null || item.ChargePercent <= 0 || item.Quantity != 1)
                        continue;
                    if (!K_AppliedMedicalManager.TryGetKind(item.Data.ItemID, out var itemKind)
                        || itemKind != kind || IsAppliedInstance(item.InstanceID))
                        continue;

                    bool applied = K_AppliedMedicalInventoryBridge.TryApply(
                        _inventoryUI, _healthSystem, item,
                        K_AppliedMedicalInventoryBridge.FindController(_inventoryUI, item.InstanceID),
                        BodyPart.LeftShoulder, kind, out string reason);
                    if (applied)
                        Debug.Log($"[CombatTest] {kind} APPLIED on LeftShoulder from inventory, charge {item.ChargePercent}%.");
                    else
                        Debug.LogWarning($"[CombatTest] {kind} FAILED: {reason}");
                    PrintHealthStatus();
                    return;
                }
            }

            // Stage 4: real loot is tested through the production apply path.
            // It removes the source item before publishing a virtual record with its ID.
            if (K_AppliedMedicalInventoryBridge.TryFindMechanicalItemInLoot(
                _inventoryUI, kind, out var lootItem, out var lootController))
            {
                bool applied = K_AppliedMedicalInventoryBridge.TryApply(
                    _inventoryUI, _healthSystem, lootItem, lootController,
                    BodyPart.LeftShoulder, kind, out string reason);
                if (applied)
                    Debug.Log($"[CombatTest] {kind} APPLIED on LeftShoulder from loot, " +
                              $"id {lootItem.InstanceID}, charge {lootItem.ChargePercent}% " +
                              $"({lootItem.RemainingChargeSeconds:F3}s).");
                else
                    Debug.LogWarning($"[CombatTest] {kind} FAILED from loot: {reason}");
                PrintHealthStatus();
                return;
            }

            // Stage 4: no held item — create an explicit debug virtual record.
            // It still requires a configured item template and can be removed/expired/saved.
            var templates = _itemDatabase?.GetAllItems();
            if (templates != null)
            {
                foreach (var template in templates)
                {
                    if (template == null
                        || !K_AppliedMedicalManager.TryGetKind(template.ItemID, out var itemKind)
                        || itemKind != kind)
                        continue;

                    bool applied = manager.TryApplyFromContainer(
                        template.ItemID, 1, template.MaxDurability,
                        BodyPart.LeftShoulder, kind, out string reason);
                    if (applied)
                        Debug.Log($"[CombatTest] {kind} APPLIED on LeftShoulder (debug virtual item, charge 100%).");
                    else
                        Debug.LogWarning($"[CombatTest] {kind} FAILED: {reason}");
                    PrintHealthStatus();
                    return;
                }
            }

            Debug.LogWarning($"[CombatTest] No configured {kind} template or eligible player/opened-loot item found.");
        }

        private bool IsAppliedInstance(uint instanceID)
        {
            var records = _healthSystem?.AppliedMedical?.Records;
            if (records == null) return false;
            foreach (var record in records)
                if (record.InstanceID == instanceID) return true;
            return false;
        }

        private void TestRemoveApplied()
        {
            var manager = _healthSystem?.AppliedMedical;
            if (manager == null) return;
            var record = manager.GetRecordForPart(BodyPart.LeftShoulder);
            if (record == null)
            {
                Debug.Log("[CombatTest] No applied item on LeftShoulder.");
                return;
            }

            bool removed = _healthSystem.RemoveApplied(BodyPart.LeftShoulder, record.Kind, out string reason);
            if (removed)
                Debug.Log($"[CombatTest] {record.Kind} REMOVED from LeftShoulder, charge {record.ChargePercent}%.");
            else
                Debug.LogWarning($"[CombatTest] REMOVE FAILED: {reason}");
            PrintHealthStatus();
        }

        private void TestForceIBThree()
        {
            if (_healthSystem == null) return;
            _healthSystem.DebugSetInternalBleeding(BodyPart.LeftShoulder, reveal: false);
            _healthSystem.DebugSetInternalBleeding(BodyPart.LeftBiceps, reveal: false);
            _healthSystem.DebugSetInternalBleeding(BodyPart.LeftForearm, reveal: false);
            Debug.Log("[CombatTest] FORCE IB x3 on LeftShoulder / LeftBiceps / LeftForearm (JETT blocks new IB while worn).");
            PrintHealthStatus();
        }

        // Stage 1: UseCoagulant() удалён вместе с K_CoagulantItem.
        // Замена — UseGel() выше.

        private void UseStimulatorEnhanced()
        {
            if (_vitalitySystem == null)
            {
                Debug.Log("[CombatTest] VitalitySystem not found!");
                return;
            }

            _vitalitySystem.UseStimulatorEnhanced();
            Debug.Log("[CombatTest] STIMULATOR USED! 85s ON + 200s OFF (Side Effects + Cooldown)");
        }

        private void TestColdExposure()
        {
            if (_vitalitySystem == null)
            {
                Debug.Log("[CombatTest] VitalitySystem not found!");
                return;
            }

            float current = _vitalitySystem.ColdExposure;
            float next = current >= 1.0f ? 0f : (current >= 0.5f ? 1.0f : 0.5f);
            _vitalitySystem.SetColdExposure(next);
            Debug.Log($"[CombatTest] Cold Exposure: {current:F2} → {next:F2}");
        }

        private void UseVodka()
        {
            if (_vitalitySystem == null)
            {
                Debug.Log("[CombatTest] VitalitySystem not found!");
                return;
            }

            _vitalitySystem.ConsumeVodka(100f);
            Debug.Log("[CombatTest] VODKA CONSUMED! 100ml | -5 Radiation | Drunk 120s");
        }

        // =====================================================================
        // СТАТУС
        // =====================================================================
       private void PrintHealthStatus()
{
    Debug.Log($"[CombatTest] Current target: {(CurrentTargetPart?.ToString() ?? "default per key")}");

    if (_healthSystem == null) return;

    Debug.Log($"[CombatTest] ========== HEALTH STATUS ==========");
    for (int i = 0; i < 20; i++)
    {
        var part = (BodyPart)i;
        var lac = _healthSystem.GetLacerationType(part);
        string lacLabel = lac == LacerationType.None ? "" : $" | Lac:{lac}";
        Debug.Log($"[CombatTest] {part}: {_healthSystem.GetHP(part):F1}/{_healthSystem.GetMaxHP(part):F1}{lacLabel}");
    }
    Debug.Log($"[CombatTest] -----------------------------------");
    Debug.Log($"[CombatTest] Max Bleeding Level: {_healthSystem.GetMaxBleedingLevel()}");
    Debug.Log($"[CombatTest] Bleeding Limbs Count: {_healthSystem.GetBleedingLimbsCount()}");
    Debug.Log($"[CombatTest] Has Any Laceration: {_healthSystem.HasAnyLaceration()}");
    Debug.Log($"[CombatTest] Has Any Open Laceration: {_healthSystem.HasAnyOpenLaceration()}");
    Debug.Log($"[CombatTest] Fractures: {_healthSystem.FractureCount}");
    Debug.Log($"[CombatTest] Gunshots: {_healthSystem.GunshotCount}");
    Debug.Log($"[CombatTest] Shock: {_healthSystem.IsShocked}");
    Debug.Log($"[CombatTest] IB count: {_healthSystem.GetInternalBleedingCount()}");
    Debug.Log($"[CombatTest] IB revealed: {_healthSystem.GetInternalBleedingRevealedCount()}");
    Debug.Log($"[CombatTest] IB drain avg: {GetAvgIBDrainMultiplier():F2}");

    // Stage 4: record status includes real/virtual source and remaining duration.
    var appliedLabels = new List<string>();
    var appliedRecords = _healthSystem.AppliedMedical?.Records;
    if (appliedRecords != null)
    {
        foreach (var record in appliedRecords)
            appliedLabels.Add($"{record.Kind}@{record.AppliedTo} {record.ChargePercent}% " +
                              $"({record.RemainingSeconds:F1}s, {(record.IsVirtual ? "virtual" : "inventory")})");
    }
    Debug.Log($"[CombatTest] Applied: {(appliedLabels.Count == 0 ? "none" : string.Join(", ", appliedLabels))}");

    if (_vitalitySystem != null)
    {
        Debug.Log($"[CombatTest] -----------------------------------");
        Debug.Log($"[CombatTest] Stim ON: {_vitalitySystem.IsStimOn}");
        Debug.Log($"[CombatTest] Stim OFF: {_vitalitySystem.IsStimOff}");
        Debug.Log($"[CombatTest] Stim Ready: {_vitalitySystem.IsStimReady}");
        Debug.Log($"[CombatTest] Fatigue: {_vitalitySystem.IsFatigued}");
        Debug.Log($"[CombatTest] Hangover: {_vitalitySystem.IsHangover}");
        Debug.Log($"[CombatTest] Cold Exposure: {_vitalitySystem.ColdExposure:F2}");
        Debug.Log($"[CombatTest] Temperature: {_vitalitySystem.CurrentTemperature:F1}°C");
        Debug.Log($"[CombatTest] Overload: {_vitalitySystem.IsOverloaded}");
        Debug.Log($"[CombatTest] Hunger: {_vitalitySystem.Hunger:F1}");
        Debug.Log($"[CombatTest] Thirst: {_vitalitySystem.Thirst:F1}");
        Debug.Log($"[CombatTest] Radiation: {_vitalitySystem.Radiation:F1}%");
        Debug.Log($"[CombatTest] Alcohol: {_vitalitySystem.AlcoholConcentration:F2}");
        Debug.Log($"[CombatTest] Radiation Immunity: {_vitalitySystem.HasRadiationImmunity}");
    }
    Debug.Log($"[CombatTest] ===================================");
}

        private float GetAvgIBDrainMultiplier()
        {
            if (_healthSystem == null) return 1f;

            float total = 0f;
            int count = 0;
            for (int i = 0; i < 20; i++)
            {
                BodyPart part = (BodyPart)i;
                if (!_healthSystem.HasInternalBleeding(part)) continue;
                total += _healthSystem.GetIBDrainMultiplier(part);
                count++;
            }

            return count > 0 ? total / count : 1f;
        }
        // =====================================================================
        // DEBUG CONTEXT MENUS
        // =====================================================================
        [ContextMenu("Test: Pistol Shot (Left Biceps)")]
        public void DebugPistolShot()
            => TestFirearmHit("Pistol", PISTOL_DAMAGE, PISTOL_BLEEDING_LEVEL, PISTOL_FRACTURE_CHANCE, BodyPart.LeftBiceps);

        [ContextMenu("Test: Assault Shot (Left Quadriceps)")]
        public void DebugAssaultShot()
            => TestFirearmHit("Assault Rifle", ASSAULT_DAMAGE, ASSAULT_BLEEDING_LEVEL, ASSAULT_FRACTURE_CHANCE, BodyPart.LeftQuadriceps);

        [ContextMenu("Test: Shotgun Shot (Right Biceps)")]
        public void DebugShotgunShot()
            => TestFirearmHit("Shotgun", SHOTGUN_DAMAGE, SHOTGUN_BLEEDING_LEVEL, SHOTGUN_FRACTURE_CHANCE, BodyPart.RightBiceps);

        [ContextMenu("Test: Rifle Shot (Right Quadriceps)")]
        public void DebugRifleShot()
            => TestFirearmHit("Rifle", RIFLE_DAMAGE, RIFLE_BLEEDING_LEVEL, RIFLE_FRACTURE_CHANCE, BodyPart.RightQuadriceps);

        [ContextMenu("Test: Use Bandage")]
        public void DebugBandage() => UseBandage();

        [ContextMenu("Test: Use Splint")]
        public void DebugSplint() => UseSplint();

        [ContextMenu("Test: Apply Gunshot to Target")]
        public void DebugApplyGunshot()
        {
            if (_healthSystem == null)
            {
                Debug.Log("[CombatTest] HealthSystem not found!");
                return;
            }
            BodyPart part = ResolveTarget(BodyPart.LeftBiceps);
            _healthSystem.ApplyGunshot(part);
            Debug.Log($"[CombatTest] GUNSHOT applied to {part} (HP untouched).");
            PrintHealthStatus();
        }

        [ContextMenu("Test: Clear Gunshot On Target")]
        public void DebugClearTargetGunshot()
        {
            if (_healthSystem == null)
            {
                Debug.Log("[CombatTest] HealthSystem not found!");
                return;
            }
            BodyPart part = ResolveTarget(BodyPart.LeftBiceps);
            _healthSystem.ClearGunshot(part);
            Debug.Log($"[CombatTest] Gunshot cleared on {part}.");
            PrintHealthStatus();
        }

        [ContextMenu("Test: Clear All Gunshots")]
        public void DebugClearAllGunshots()
        {
            if (_healthSystem == null)
            {
                Debug.Log("[CombatTest] HealthSystem not found!");
                return;
            }
            for (int i = 0; i < 20; i++)
                _healthSystem.ClearGunshot((BodyPart)i);
            Debug.Log("[CombatTest] All gunshots cleared.");
            PrintHealthStatus();
        }

        [ContextMenu("Test: Use Strips (Sealed)")]
        public void DebugStrips() => UseStrips();

        [ContextMenu("Test: Use Glue (Glued)")]
        public void DebugGlue() => UseGlue();

        [ContextMenu("Test: Use Staples (Sealed)")]
        public void DebugStaples() => UseStaples();

        [ContextMenu("Test: Simulate Jump")]
        public void DebugJump() => SimulateJump();

        [ContextMenu("Test: Use Gel (target)")]
        public void DebugGel() => UseGel();

        [ContextMenu("Test: Use Stimulator")]
        public void DebugStim() => UseStimulatorEnhanced();

        [ContextMenu("Test: Toggle Cold Exposure")]
        public void DebugCold() => TestColdExposure();

        [ContextMenu("Test: Consume Vodka (100ml)")]
        public void DebugVodka() => UseVodka();

        [ContextMenu("Test: Toggle Overload")]
        public void DebugOverload()
        {
            if (_vitalitySystem != null)
                _vitalitySystem.SetOverload(!_vitalitySystem.IsOverloaded);
        }

        [ContextMenu("Test: Print Status")]
        public void DebugPrintStatus() => PrintHealthStatus();

               [ContextMenu("Test: Clear external wounds, gunshots and splints")]
        public void DebugResetAll()
        {
            if (_healthSystem != null)
            {
                _healthSystem.DebugStopBleeding();
                _healthSystem.DebugRemoveLaceration();

                for (int i = 0; i < 20; i++)
                {
                    _healthSystem.RemoveSplint((BodyPart)i);
                    _healthSystem.ClearGunshot((BodyPart)i);
                }
            }
            Debug.Log("[CombatTest] Cleared external bleeding/lacerations, gunshot markers and splints. Fractures, internal bleeding, applied treatments, shock, debuffs and death are preserved.");
        }

public static BodyPart? CurrentTargetPart { get; private set; }

/// <summary>Установить целевую часть тела для следующего выстрела.</summary>
public static void SetTargetPart(BodyPart part)
{
    CurrentTargetPart = part;
    Debug.Log($"[CombatTest] Target set: {part}");
}

/// <summary>Сбросить цель на дефолт.</summary>
public static void ClearTargetPart()
{
    CurrentTargetPart = null;
    Debug.Log("[CombatTest] Target cleared (default per key).");
}

private static BodyPart ResolveTarget(BodyPart fallback)
    => CurrentTargetPart ?? fallback;
    }
}
