#if UNITY_EDITOR
using System;
using System.Linq;
using K_Incident.Core;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_AddAcousticSystem
    {
        public const string PortalScriptPath = "Assets/_Project/_Scripts/Core/acoustic/K_AcousticPortal.cs";

        // Batch entry point: import/type evidence only, without scene access,
        // dialogs, dirty flags, Undo, creation, saving, or modifications.
        public static void ProbeImport()
        {
            string path = Incident_FixAcousticScriptName.ResolvePath();
            var script = AssetDatabase.LoadAssetAtPath<MonoScript>(path);
            Type imported = script != null ? script.GetClass() : null;
            string className = imported == null ? "null" : "\"" + imported.FullName + "\"";
            Debug.Log("[Incident/C12/ProbeImport] {\"path\":\"" + path + "\",\"scriptLoaded\":" +
                (script != null ? "true" : "false") + ",\"getClass\":" + className + ",\"expectedClass\":\"K_Incident.Core.K_AcousticSystem\",\"attachableClassMatches\":" +
                (imported == typeof(K_AcousticSystem) ? "true" : "false") + "}");
            var portalScript = AssetDatabase.LoadAssetAtPath<MonoScript>(PortalScriptPath);
            Type portalClass = portalScript != null ? portalScript.GetClass() : null;
            string portalGuid = AssetDatabase.AssetPathToGUID(PortalScriptPath);
            Debug.Log("[Incident/C12/ProbeImport] {\"path\":\"" + PortalScriptPath + "\",\"scriptLoaded\":" +
                (portalScript != null ? "true" : "false") + ",\"guid\":\"" + portalGuid + "\",\"getClass\":" +
                (portalClass == null ? "null" : "\"" + portalClass.FullName + "\"") + ",\"expectedClass\":\"K_Incident.Core.K_AcousticPortal\",\"attachableClassMatches\":" +
                (portalClass == typeof(K_AcousticPortal) ? "true" : "false") + "}");
            if (imported != typeof(K_AcousticSystem) ||
                AssetDatabase.AssetPathToGUID(path) != Incident_FixAcousticScriptName.ScriptGuid)
                throw new InvalidOperationException("C12 manager MonoScript type/GUID verification failed.");
            if (portalClass != typeof(K_AcousticPortal) || string.IsNullOrEmpty(portalGuid) ||
                portalGuid == Incident_FixAcousticScriptName.ScriptGuid)
                throw new InvalidOperationException("C12 portal MonoScript type/new GUID verification failed.");
        }

        [MenuItem("Incident/Scene/Add Acoustic System (C12 after filename fix)")]
        public static void Execute() => Incident_EditorSupport.Run("C12: проверка перед добавлением", () =>
        {
            var scene = Incident_EditorSupport.RequireScene();
            string path = Incident_FixAcousticScriptName.ResolvePath();
            var script = Incident_EditorSupport.Asset<MonoScript>(path);
            Type imported = script.GetClass();
            var managers = scene.GetRootGameObjects().SelectMany(go => go.GetComponentsInChildren<K_AcousticSystem>(true)).ToArray();
            if (imported != typeof(K_AcousticSystem))
                throw new InvalidOperationException("MonoScript импортирован как " + (imported == null ? "null" : imported.FullName) +
                    ". Сначала Incident/Assets/Fix Acoustic Script Filename, дождитесь компиляции. Компонент не добавлен.");
            var portalScript = Incident_EditorSupport.Asset<MonoScript>(PortalScriptPath);
            string portalGuid = AssetDatabase.AssetPathToGUID(PortalScriptPath);
            if (portalScript.GetClass() != typeof(K_AcousticPortal) || string.IsNullOrEmpty(portalGuid) ||
                portalGuid == Incident_FixAcousticScriptName.ScriptGuid)
                throw new InvalidOperationException("K_AcousticPortal MonoScript должен импортироваться отдельным классом с новым GUID. Компонент не добавлен.");
            if (managers.Length > 1) throw new InvalidOperationException("Найдено несколько acoustic managers; устраните дубликат вручную.");
            string preview = managers.Length == 1 ? "В сцене уже один manager. Его настройки сохраняются; новый не добавляется." :
                "Создать ровно один K_AcousticSystem на ACOUSTIC_SYSTEM.\nУтверждённый прототип: heavy mask=0, cover mask=0, AudioMixer не назначен.\n" +
                "События шума работают без окклюзии до настройки Inspector. Стены/пол, звуки и portals автоматически не выбираются.";
            Incident_EditorSupport.SceneChange("C12: acoustic manager", preview, counts =>
            {
                if (managers.Length == 1) { counts.Skipped++; return; }
                var go = new GameObject("ACOUSTIC_SYSTEM");
                Undo.RegisterCreatedObjectUndo(go, "Incident C12: acoustic manager");
                go.SetActive(false);
                var manager = Undo.AddComponent<K_AcousticSystem>(go);
                Undo.RecordObject(manager, "Incident C12: prototype settings");
                var serialized = new SerializedObject(manager);
                Incident_EditorSupport.Property(serialized, "_heavyOcclusionMask").intValue = 0;
                Incident_EditorSupport.Property(serialized, "_coverOcclusionMask").intValue = 0;
                Incident_EditorSupport.Property(serialized, "_audioMixer").objectReferenceValue = null;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                go.SetActive(true);
                counts.Created++;
                counts.Assigned += 3;
            });
        });
    }
}
#endif
