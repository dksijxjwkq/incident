#if UNITY_EDITOR
using System;
using K_Incident.Core;
using TMPro;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_CreateHoldProgress
    {
        [MenuItem("Incident/Scene/Create Hold Progress (C13)")]
        public static void Execute() => Incident_EditorSupport.Run("C13: прогресс удержания E", () =>
        {
            var scene = Incident_EditorSupport.RequireScene();
            var interaction = Incident_EditorSupport.Component<K_InteractionSystem>(Incident_EditorSupport.Path(scene, "Player"));
            Incident_EditorSupport.RequireField(interaction, "_interactionPrompt", "_holdProgressText");
            var prompt = Incident_EditorSupport.Reference<TextMeshProUGUI>(interaction, "_interactionPrompt");
            if (prompt == null || prompt.font == null || prompt.transform.parent == null || prompt.gameObject.scene != scene)
                throw new InvalidOperationException("Player._interactionPrompt должен ссылаться на существующий TMP рабочей сцены с font и родителем.");
            var existing = Incident_EditorSupport.Reference<TextMeshProUGUI>(interaction, "_holdProgressText");
            if (existing != null && (existing == prompt || existing.gameObject.scene != scene))
                throw new InvalidOperationException("_holdProgressText использует prompt или другой scene-объект; требуется отдельный TMP.");
            if (existing == null && prompt.transform.parent.Find("Incident_HoldProgress") != null)
                throw new InvalidOperationException("Incident_HoldProgress уже существует без привязки; проверьте Inspector.");
            var rect = prompt.rectTransform;
            Incident_EditorSupport.SceneChange("C13: прогресс удержания E", "Создать отдельный TMP Incident_HoldProgress рядом с текущим InteractionPrompt, с тем же шрифтом/цветом.\n" +
                "Назначить Player._holdProgressText; начальное состояние скрыто, scale=1. Назначенный отдельный TMP сохраняется.", counts =>
            {
                if (existing != null) { counts.Skipped++; return; }
                var text = Incident_EditorSupport.CreateText("Incident_HoldProgress", rect.parent, prompt, Vector2.zero, rect.sizeDelta);
                text.rectTransform.anchorMin = rect.anchorMin;
                text.rectTransform.anchorMax = rect.anchorMax;
                text.rectTransform.pivot = rect.pivot;
                text.rectTransform.anchoredPosition = rect.anchoredPosition + new Vector2(0, -Mathf.Max(30f, rect.rect.height));
                text.gameObject.SetActive(false);
                counts.Created++;
                Incident_EditorSupport.Assign(interaction, "_holdProgressText", text, counts);
            });
        });
    }
}
#endif
