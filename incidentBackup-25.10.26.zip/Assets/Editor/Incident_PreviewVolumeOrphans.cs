#if UNITY_EDITOR
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_PreviewVolumeOrphans
    {
        private static readonly long[] AuditIds =
        {
            -7750755424749557576, -7274224791359825572, -5139089513906902183, 4251301726029935498,
            -8104416584915340131, -5360449096862653589, -581120513425526550, 6940869943325143175, 9122958982931076880
        };

        [MenuItem("Incident/Assets/Preview Volume Orphans (C-REF1 read only)")]
        public static void Execute() => Incident_EditorSupport.Run("C-REF1: volume preview", () =>
        {
            const string path = "Assets/Settings/DefaultVolumeProfile.asset";
            var profile = Incident_EditorSupport.Asset<ScriptableObject>(path);
            var components = Incident_EditorSupport.Property(new SerializedObject(profile), "components");
            var used = new HashSet<Object>();
            var lines = new List<string> { $"{path}: profile.components={components.arraySize} (в аудите 19)." };
            for (int i = 0; i < components.arraySize; i++)
            {
                var component = components.GetArrayElementAtIndex(i).objectReferenceValue;
                if (component != null) used.Add(component);
                lines.Add($"components[{i}]: {(component == null ? "MISSING" : component.GetType().FullName + " / " + component.name)}");
            }
            var available = AssetDatabase.LoadAllAssetsAtPath(path).Where(a => a != null).ToArray();
            foreach (long id in AuditIds)
            {
                Object found = available.FirstOrDefault(a => AssetDatabase.TryGetGUIDAndLocalFileIdentifier(a, out string guid, out long local) && local == id);
                lines.Add($"audit localID={id}: {(found == null ? "native object недоступен" : found.name + ", type=" + found.GetType().FullName + ", in components=" + used.Contains(found))}");
            }
            lines.Add("Read-only. Удаление не реализовано: native доступность/входящие ссылки должны быть доказаны до очистки. Рабочие 19 компонентов не затрагиваются; косметика явно отложена.");
            string report = string.Join("\n", lines);
            Debug.Log("[Incident/C-REF1] " + report);
            Incident_EditorSupport.Report("C-REF1: только preview", new Incident_EditorSupport.Counts { Skipped = AuditIds.Length }, report);
        });
    }
}
#endif
