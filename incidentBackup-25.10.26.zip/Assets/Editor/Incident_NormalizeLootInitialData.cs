#if UNITY_EDITOR
using System;
using K_Incident.Core;
using UnityEditor;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_NormalizeLootInitialData
    {
        [MenuItem("Incident/Scene/Normalize Empty Loot Data (C15)")]
        public static void Execute() => Incident_EditorSupport.Run("C15: начальная сетка Cube", () =>
        {
            var scene = Incident_EditorSupport.RequireScene();
            var box = Incident_EditorSupport.Component<K_LootBox>(Incident_EditorSupport.Path(scene, "Cube"));
            var serialized = new SerializedObject(box);
            int width = Incident_EditorSupport.Property(serialized, "_gridWidth").intValue;
            int height = Incident_EditorSupport.Property(serialized, "_gridHeight").intValue;
            var data = Incident_EditorSupport.Property(serialized, "_initialInventoryData");
            var items = data.FindPropertyRelative("_items");
            var initialWidth = data.FindPropertyRelative("_width");
            var initialHeight = data.FindPropertyRelative("_height");
            if (items == null || initialWidth == null || initialHeight == null)
                throw new InvalidOperationException("Изменилась структура InventoryData; автоматическое исправление остановлено.");
            if (width != 7 || height != 7 || items.arraySize != 0)
                throw new InvalidOperationException($"C15 рассчитан на пустой Cube7×7; текущий grid={width}×{height}, items={items.arraySize}. Миграция содержимого не выполняется.");
            bool already = initialWidth.intValue == 7 && initialHeight.intValue == 7;
            if (!already && (initialWidth.intValue != 8 || initialHeight.intValue != 10))
                throw new InvalidOperationException($"Ожидался initial8×10 или уже7×7; сейчас {initialWidth.intValue}×{initialHeight.intValue}.");
            Incident_EditorSupport.SceneChange("C15: начальная сетка Cube", $"Cube: пустой initial DTO {initialWidth.intValue}×{initialHeight.intValue} → 7×7.\n_runtime gridWidth/gridHeight остаются 7×7. Начальные предметы отсутствуют.", counts =>
            {
                if (already) { counts.Skipped++; return; }
                Undo.RecordObject(box, "Incident C15: initial dimensions");
                initialWidth.intValue = 7;
                initialHeight.intValue = 7;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                counts.Assigned += 2;
            });
        });
    }
}
#endif
