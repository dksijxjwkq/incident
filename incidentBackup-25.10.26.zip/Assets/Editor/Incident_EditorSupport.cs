#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using Object = UnityEngine.Object;

namespace K_Incident.EditorTools.Iteration7
{
    // Shared authoring mechanics only. No operation runs automatically on import.
    public static class Incident_EditorSupport
    {
        public const string ScenePath = "Assets/Scenes/0 (1).unity";
        public const string ItemDatabasePath = "Assets/_Project/Items/database/ItemDatabase.asset";
        public const string MedicalDatabasePath = "Assets/_Project/Items/database/MedicalDatabase.asset";
        public const string MedicalFolder = "Assets/_Project/_Scripts/Items/Medical_Items/Data";
        public const string InventoryDollPath = "HUD_Canvas/InventoryPanel/HealthContentPane/DollCanvasRoot/Health_Doll_Inventory";
        public const string HealthPanePath = "HUD_Canvas/InventoryPanel/HealthContentPane";
        public const string HudDollPath = "HUD_Canvas/Metabolism_Group/PanelTarget  /Health_Doll";
        public const string HealthIconFolder = "Assets/_Project/UI/visual_icons/health_Icon/";

        public sealed class Counts
        {
            public int Created, Assigned, Skipped;
            public override string ToString() => $"Создано {Created}, назначено {Assigned}, пропущено {Skipped}.";
        }

        public static void Run(string title, Action operation)
        {
            try
            {
                if (EditorApplication.isPlayingOrWillChangePlaymode || EditorApplication.isCompiling)
                    throw new InvalidOperationException("Нужен Edit Mode после завершения компиляции.");
                operation();
            }
            catch (Exception ex)
            {
                Debug.LogError($"[Incident/Iteration7] {title}: {ex}");
                EditorUtility.DisplayDialog(title, "Изменения не выполнены или отменены. Подробности в Console.\n" + ex.Message, "OK");
            }
        }

        public static Scene RequireScene()
        {
            Scene scene = SceneManager.GetActiveScene();
            if (!scene.IsValid() || !scene.isLoaded || scene.path != ScenePath)
                throw new InvalidOperationException("Откройте и сделайте активной сцену " + ScenePath + ". Другие сцены инструмент не изменяет.");
            return scene;
        }

        public static Transform Path(Scene scene, string path)
        {
            string[] names = path.Split('/');
            Transform result = null;
            foreach (string name in names)
            {
                var candidates = result == null
                    ? scene.GetRootGameObjects().Select(go => go.transform).Where(t => t.name == name).ToArray()
                    : Enumerable.Range(0, result.childCount).Select(result.GetChild).Where(t => t.name == name).ToArray();
                if (candidates.Length != 1)
                    throw new InvalidOperationException($"Ожидался один объект '{path}', сегмент '{name}': найдено {candidates.Length}.");
                result = candidates[0];
            }
            return result;
        }

        public static T Component<T>(Transform transform) where T : UnityEngine.Component
        {
            var components = transform.GetComponents<T>();
            if (components.Length != 1)
                throw new InvalidOperationException($"На '{transform.name}' ожидается один {typeof(T).Name}; найдено {components.Length}.");
            return components[0];
        }

        public static T Unique<T>(Scene scene) where T : UnityEngine.Component
        {
            var matches = scene.GetRootGameObjects().SelectMany(go => go.GetComponentsInChildren<T>(true)).ToArray();
            if (matches.Length != 1)
                throw new InvalidOperationException($"В рабочей сцене ожидается один {typeof(T).Name}; найдено {matches.Length}.");
            return matches[0];
        }

        public static T Named<T>(Transform root, string name) where T : UnityEngine.Component
        {
            var matches = root.GetComponentsInChildren<T>(true).Where(c => c.name == name).ToArray();
            if (matches.Length != 1)
                throw new InvalidOperationException($"Под '{root.name}' ожидается один {typeof(T).Name} '{name}'; найдено {matches.Length}.");
            return matches[0];
        }

        public static T Asset<T>(string path) where T : Object
        {
            var asset = AssetDatabase.LoadAssetAtPath<T>(path);
            if (asset == null) throw new InvalidOperationException($"Не найден {typeof(T).Name}: {path}");
            return asset;
        }

        public static SerializedProperty Property(SerializedObject owner, string path)
        {
            var property = owner.FindProperty(path);
            if (property == null) throw new InvalidOperationException($"Нет serialized-поля {owner.targetObject.name}.{path}. Проверьте версию исходников.");
            return property;
        }

        public static T Reference<T>(Object owner, string field) where T : Object
        {
            return Property(new SerializedObject(owner), field).objectReferenceValue as T;
        }

        public static bool Assign(Object owner, string field, Object value, Counts counts)
        {
            var serialized = new SerializedObject(owner);
            var property = Property(serialized, field);
            if (property.objectReferenceValue == value) { counts.Skipped++; return false; }
            Undo.RecordObject(owner, "Incident: " + field);
            property.objectReferenceValue = value;
            serialized.ApplyModifiedPropertiesWithoutUndo();
            counts.Assigned++;
            return true;
        }

        public static void SceneChange(string title, string preview, Action<Counts> apply)
        {
            Scene scene = RequireScene();
            Debug.Log($"[Incident/Iteration7] PREVIEW {title}\n{preview}");
            if (!EditorUtility.DisplayDialog(title, preview + "\n\nПродолжить? Изменения сцены можно отменить Ctrl+Z.", "Применить", "Отмена")) return;
            string backup = Backup(new[] { ScenePath });
            Undo.IncrementCurrentGroup();
            int group = Undo.GetCurrentGroup();
            Undo.SetCurrentGroupName(title);
            var counts = new Counts();
            try
            {
                apply(counts);
                EditorSceneManager.MarkSceneDirty(scene);
                Undo.CollapseUndoOperations(group);
            }
            catch
            {
                Undo.RevertAllDownToGroup(group);
                throw;
            }
            Report(title, counts, "Сцена не сохранена автоматически. Ctrl+Z отменяет операцию.\nBackup сохранённой сцены: " + backup);
        }

        public static void AssetChange(string title, string preview, IEnumerable<string> modifiedPaths, Action<Counts, List<string>> apply)
        {
            string[] paths = modifiedPaths.Distinct().ToArray();
            foreach (string path in paths)
            {
                Object existing = AssetDatabase.LoadMainAssetAtPath(path);
                if (existing != null && EditorUtility.IsDirty(existing))
                    throw new InvalidOperationException("Сначала сохраните или отмените ручные изменения ассета: " + path);
            }
            Debug.Log($"[Incident/Iteration7] PREVIEW {title}\n{preview}");
            if (!EditorUtility.DisplayDialog(title, preview + "\n\nПродолжить? Для .asset создаётся файловая резервная копия, Undo не используется.", "Применить", "Отмена")) return;
            string backup = Backup(paths);
            var created = new List<string>();
            var counts = new Counts();
            try
            {
                apply(counts, created);
                foreach (string path in paths.Concat(created).Distinct())
                {
                    Object asset = AssetDatabase.LoadMainAssetAtPath(path);
                    if (asset != null) AssetDatabase.SaveAssetIfDirty(asset);
                }
            }
            catch
            {
                foreach (string path in created) AssetDatabase.DeleteAsset(path);
                foreach (string path in paths)
                {
                    string stored = System.IO.Path.Combine(backup, path.Replace('/', System.IO.Path.DirectorySeparatorChar));
                    if (!File.Exists(stored)) continue;
                    File.Copy(stored, path, true);
                    if (File.Exists(stored + ".meta")) File.Copy(stored + ".meta", path + ".meta", true);
                    AssetDatabase.ImportAsset(path, ImportAssetOptions.ForceUpdate);
                }
                Debug.LogError("[Incident/Iteration7] Asset-операция отменена; backup: " + backup);
                throw;
            }
            Report(title, counts, "Backup .asset и .meta: " + backup + "\nДля отката закройте Unity и восстановите парные файлы из копии; новые файлы указаны в Console.");
        }

        public static string Backup(IEnumerable<string> paths)
        {
            string root = System.IO.Path.GetFullPath(System.IO.Path.Combine("ReviewBackups", "Iteration7", DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fffffff")));
            foreach (string path in paths.Distinct())
            {
                if (!path.StartsWith("Assets/", StringComparison.Ordinal) || path.Contains(".."))
                    throw new InvalidOperationException("Недопустимый путь резервного копирования: " + path);
                if (!File.Exists(path)) continue;
                string target = System.IO.Path.Combine(root, path.Replace('/', System.IO.Path.DirectorySeparatorChar));
                Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target));
                File.Copy(path, target, false);
                if (File.Exists(path + ".meta")) File.Copy(path + ".meta", target + ".meta", false);
            }
            return root;
        }

        public static void Report(string title, Counts counts, string details)
        {
            string report = counts + "\n" + details;
            Debug.Log($"[Incident/Iteration7] {title}\n{report}");
            EditorUtility.DisplayDialog(title, report, "OK");
        }

        public static RectTransform CreateRect(string name, Transform parent, Vector2 position, Vector2 size)
        {
            var go = new GameObject(name, typeof(RectTransform));
            Undo.RegisterCreatedObjectUndo(go, "Incident: " + name);
            Undo.SetTransformParent(go.transform, parent, "Incident: parent " + name);
            var rect = go.GetComponent<RectTransform>();
            rect.localScale = Vector3.one;
            rect.localRotation = Quaternion.identity;
            rect.anchorMin = rect.anchorMax = new Vector2(0, 1);
            rect.pivot = new Vector2(0, 1);
            rect.anchoredPosition = position;
            rect.sizeDelta = size;
            return rect;
        }

        public static TextMeshProUGUI CreateText(string name, Transform parent, TextMeshProUGUI source, Vector2 position, Vector2 size)
        {
            if (source == null || source.font == null) throw new InvalidOperationException("Для TMP нужен существующий образец с назначенным шрифтом.");
            var rect = CreateRect(name, parent, position, size);
            var text = Undo.AddComponent<TextMeshProUGUI>(rect.gameObject);
            text.font = source.font;
            text.fontSharedMaterial = source.fontSharedMaterial;
            text.fontSize = source.fontSize;
            text.fontStyle = source.fontStyle;
            text.color = source.color;
            text.alignment = source.alignment;
            text.raycastTarget = false;
            text.text = "";
            return text;
        }

        public static Sprite Sprite(string path)
        {
            var importer = AssetImporter.GetAtPath(path) as TextureImporter;
            if (importer == null || importer.textureType != TextureImporterType.Sprite || importer.spriteImportMode != SpriteImportMode.Single)
                throw new InvalidOperationException("Импортируйте выбранный рисунок как Sprite (2D and UI), Single, Apply: " + path);
            var sprites = AssetDatabase.LoadAllAssetsAtPath(path).OfType<Sprite>().ToArray();
            if (sprites.Length != 1) throw new InvalidOperationException($"В '{path}' ожидается один Sprite, найдено {sprites.Length}.");
            return sprites[0];
        }

        public static void RequireField(Object owner, params string[] names)
        {
            var serialized = new SerializedObject(owner);
            foreach (string name in names) Property(serialized, name);
        }
    }
}
#endif
