#if UNITY_EDITOR
using System;
using System.Linq;
using K_Incident.Core.UI;
using TMPro;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_SeparateInventoryStatuses
    {
        public static readonly string[] Fields =
        {
            "_iconConcussion", "_iconTBI", "_iconBreathingDifficulty", "_iconImmobilized", "_iconInternalBleeding",
            "_iconHunger", "_iconThirst", "_iconRadiation", "_iconCold", "_iconOverload", "_iconBleeding",
            "_iconLaceration", "_iconHangover", "_iconDrunk", "_iconStimOn", "_iconStimOff", "_iconCoagulant", "_iconFracture", "_iconGunshot"
        };

        [MenuItem("Incident/Scene/Separate Inventory Statuses (C06 after C07)")]
        public static void Execute() => Incident_EditorSupport.Run("C06: отдельные статусы инвентаря", () =>
        {
            var scene = Incident_EditorSupport.RequireScene();
            var inventory = Incident_EditorSupport.Component<K_InventoryHealthWidget>(Incident_EditorSupport.Path(scene, Incident_EditorSupport.InventoryDollPath));
            var hud = Incident_EditorSupport.Component<K_HealthWidget>(Incident_EditorSupport.Path(scene, Incident_EditorSupport.HudDollPath));
            var sources = Fields.Select(field => Incident_EditorSupport.Reference<Image>(hud, field)).ToArray();
            if (sources.Any(image => image == null))
                throw new InvalidOperationException("HUD: пустые поля " + string.Join(", ", Fields.Where((field, i) => sources[i] == null)) + ". Сначала C07.");
            Transform hudRoot = Incident_EditorSupport.Path(scene, "HUD_Canvas/Metabolism_Group");
            if (sources.Distinct().Count() != sources.Length || sources.Any(image => !image.transform.IsChildOf(hudRoot)))
                throw new InvalidOperationException("HUD-иконки должны быть разными объектами своего Metabolism_Group.");
            var fracture = Incident_EditorSupport.Reference<TextMeshProUGUI>(hud, "_fractureCountText");
            if (fracture == null || fracture.font == null) throw new InvalidOperationException("HUD fracture-count TMP или font не назначен.");
            if (!fracture.transform.IsChildOf(hudRoot)) throw new InvalidOperationException("HUD fracture-count принадлежит чужому поддереву.");
            Incident_EditorSupport.RequireField(inventory, Fields.Concat(new[] { "_fractureCountText" }).ToArray());
            Transform group = inventory.transform.Find("Incident_InventoryStatuses");
            if (group != null && (group.GetComponent<RectTransform>() == null || group.GetComponent<GridLayoutGroup>() == null))
                throw new InvalidOperationException("Имя Incident_InventoryStatuses занято неизвестной группой. Проверьте вручную.");
            for (int i = 0; i < Fields.Length; i++)
            {
                var current = Incident_EditorSupport.Reference<Image>(inventory, Fields[i]);
                if (current != null && current != sources[i] && !current.transform.IsChildOf(inventory.transform))
                    throw new InvalidOperationException("Неожиданная внешняя inventory-ссылка: " + Fields[i] + " → " + current.name);
                if (group != null && (current == null || current == sources[i]) && group.Find(sources[i].name) != null)
                    throw new InvalidOperationException("Есть не связанная с полем копия " + sources[i].name + "; автоматическое дублирование остановлено.");
            }
            var owned = Fields.Select(field => Incident_EditorSupport.Reference<Image>(inventory, field))
                .Where(image => image != null && image.transform.IsChildOf(inventory.transform)).ToArray();
            if (owned.Distinct().Count() != owned.Length)
                throw new InvalidOperationException("Несколько inventory-статусов ссылаются на один Image; проверьте Inspector.");
            var oldFracture = Incident_EditorSupport.Reference<TextMeshProUGUI>(inventory, "_fractureCountText");
            if (oldFracture != null && oldFracture != fracture && !oldFracture.transform.IsChildOf(inventory.transform))
                throw new InvalidOperationException("Неожиданная внешняя inventory-ссылка fracture-count.");
            if ((oldFracture == null || oldFracture == fracture) && inventory.GetComponentsInChildren<TextMeshProUGUI>(true).Any(t => t.name == "IconFractureText"))
                throw new InvalidOperationException("В inventory уже есть не связанная с fracture-count копия IconFractureText; повторное создание остановлено.");
            Incident_EditorSupport.SceneChange("C06: отдельные статусы инвентаря", "После C07: скопировать 19 HUD Image и fracture-count TMP в собственное поддерево inventory-куклы.\n" +
                "HUD-ссылки сохраняются. Копируются только визуальные компоненты, без gameplay-скриптов.\nМинимальная сетка 5 колонок, scale=1; окончательный layout — A07.", counts =>
            {
                bool needsImages = Fields.Any(field =>
                {
                    var current = Incident_EditorSupport.Reference<Image>(inventory, field);
                    return current == null || !current.transform.IsChildOf(inventory.transform);
                });
                bool needsText = oldFracture == null || !oldFracture.transform.IsChildOf(inventory.transform);
                if (group == null && (needsImages || needsText))
                {
                    group = Incident_EditorSupport.CreateRect("Incident_InventoryStatuses", inventory.transform, new Vector2(0, -350), new Vector2(268, 212));
                    var layout = Undo.AddComponent<GridLayoutGroup>(group.gameObject);
                    layout.cellSize = new Vector2(48, 48);
                    layout.spacing = new Vector2(6, 6);
                    layout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
                    layout.constraintCount = 5;
                    counts.Created++;
                }
                Image inventoryFracture = null;
                for (int i = 0; i < Fields.Length; i++)
                {
                    Image current = Incident_EditorSupport.Reference<Image>(inventory, Fields[i]);
                    if (current != null && current.transform.IsChildOf(inventory.transform)) { counts.Skipped++; }
                    else
                    {
                        var rect = Incident_EditorSupport.CreateRect(sources[i].name, group, Vector2.zero, new Vector2(48, 48));
                        current = Undo.AddComponent<Image>(rect.gameObject);
                        EditorUtility.CopySerialized(sources[i], current);
                        rect.gameObject.SetActive(sources[i].gameObject.activeSelf);
                        counts.Created++;
                        Incident_EditorSupport.Assign(inventory, Fields[i], current, counts);
                    }
                    if (Fields[i] == "_iconFracture") inventoryFracture = current;
                    if (Incident_EditorSupport.Reference<Image>(hud, Fields[i]) != sources[i])
                        throw new InvalidOperationException("Изменилась ссылка HUD: " + Fields[i]);
                }
                if (needsText)
                {
                    var text = Incident_EditorSupport.CreateText("IconFractureText", inventoryFracture.transform, fracture, Vector2.zero, new Vector2(48, 48));
                    text.text = fracture.text;
                    counts.Created++;
                    Incident_EditorSupport.Assign(inventory, "_fractureCountText", text, counts);
                }
                else counts.Skipped++;
                foreach (string field in Fields)
                    if (!Incident_EditorSupport.Reference<Image>(inventory, field).transform.IsChildOf(inventory.transform))
                        throw new InvalidOperationException("Inventory-target остался вне поддерева: " + field);
                if (Incident_EditorSupport.Reference<TextMeshProUGUI>(hud, "_fractureCountText") != fracture)
                    throw new InvalidOperationException("Изменилась ссылка HUD fracture-count.");
            });
        });
    }
}
#endif
