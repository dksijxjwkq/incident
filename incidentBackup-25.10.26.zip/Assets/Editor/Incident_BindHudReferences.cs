#if UNITY_EDITOR
using K_Incident.Core.UI;
using TMPro;
using UnityEditor;
using UnityEngine.UI;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_BindHudReferences
    {
        [MenuItem("Incident/Scene/Bind HUD References (C07)")]
        public static void Execute() => Incident_EditorSupport.Run("C07: ссылки HUD", () =>
        {
            var scene = Incident_EditorSupport.RequireScene();
            var hud = Incident_EditorSupport.Component<K_HealthWidget>(Incident_EditorSupport.Path(scene, Incident_EditorSupport.HudDollPath));
            var root = Incident_EditorSupport.Path(scene, "HUD_Canvas/Metabolism_Group");
            var gunshot = Incident_EditorSupport.Named<Image>(root, "Icon_GunShot");
            var clock = Incident_EditorSupport.Named<TextMeshProUGUI>(root, "Clock_Text");
            Incident_EditorSupport.RequireField(hud, "_iconGunshot", "_clockText");
            Incident_EditorSupport.SceneChange("C07: ссылки HUD", $"HUD {Incident_EditorSupport.HudDollPath}:\n_iconGunshot → {gunshot.name}\n_clockText → {clock.name}\nТолько HUD. Sprite огнестрела назначается после A02 через C08.", counts =>
            {
                Incident_EditorSupport.Assign(hud, "_iconGunshot", gunshot, counts);
                Incident_EditorSupport.Assign(hud, "_clockText", clock, counts);
            });
        });
    }
}
#endif
