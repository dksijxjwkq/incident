#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using K_Incident.Core.UI;
using UnityEditor;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_AssignAppliedIcons
    {
        [MenuItem("Incident/Scene/Preview Applied Icons (C08 after A02)")]
        public static void Preview() => Incident_EditorSupport.Run("C08: dry-run", () => Prepare(false));

        [MenuItem("Incident/Scene/Assign Applied Icons (C08 after A02)")]
        public static void Execute() => Incident_EditorSupport.Run("C08: applied icons", () => Prepare(true));

        private static void Prepare(bool apply)
        {
            var scene = Incident_EditorSupport.RequireScene();
            var inventory = Incident_EditorSupport.Component<K_InventoryHealthWidget>(Incident_EditorSupport.Path(scene, Incident_EditorSupport.InventoryDollPath));
            var hud = Incident_EditorSupport.Component<K_HealthWidget>(Incident_EditorSupport.Path(scene, Incident_EditorSupport.HudDollPath));
            Incident_EditorSupport.RequireField(inventory, "_tourniquetAppliedIcon", "_jettAppliedIcon", "_iconGunshot");
            var hudImage = Incident_EditorSupport.Reference<Image>(hud, "_iconGunshot");
            var inventoryImage = Incident_EditorSupport.Reference<Image>(inventory, "_iconGunshot");
            if (hudImage == null || inventoryImage == null || hudImage == inventoryImage ||
                !hudImage.transform.IsChildOf(Incident_EditorSupport.Path(scene, "HUD_Canvas/Metabolism_Group")) ||
                !inventoryImage.transform.IsChildOf(inventory.transform))
                throw new InvalidOperationException("Сначала C07 → C06: нужны раздельные HUD/inventory Image огнестрела.");
            string[] paths = { "tourniquet_applied.png", "jett_applied.png", "gunshot_status.png" };
            var errors = new List<string>();
            var sprites = new Sprite[paths.Length];
            for (int i = 0; i < paths.Length; i++)
            {
                try { sprites[i] = Incident_EditorSupport.Sprite(Incident_EditorSupport.HealthIconFolder + paths[i]); }
                catch (Exception ex) { errors.Add(ex.Message); }
            }
            string preview = "Карта имён A02; изображения выбирает и импортирует пользователь:\n" +
                string.Join("\n", paths.Select(p => Incident_EditorSupport.HealthIconFolder + p)) +
                "\nТурникет/JETT → inventory applied override; gunshot → раздельные HUD/inventory Image.\n" +
                (errors.Count == 0 ? "Все три файла готовы (Sprite/Single)." : "НЕ ГОТОВО:\n" + string.Join("\n", errors));
            Debug.Log("[Incident/C08] DRY-RUN\n" + preview);
            if (!apply)
            {
                Incident_EditorSupport.Report("C08: dry-run", new Incident_EditorSupport.Counts { Skipped = 4 }, preview + "\nИзменений нет.");
                return;
            }
            if (errors.Count > 0) throw new InvalidOperationException("Сначала A02. Все отсутствующие/неверные импорты:\n" + string.Join("\n", errors));
            Incident_EditorSupport.SceneChange("C08: applied icons", preview, counts =>
            {
                Incident_EditorSupport.Assign(inventory, "_tourniquetAppliedIcon", sprites[0], counts);
                Incident_EditorSupport.Assign(inventory, "_jettAppliedIcon", sprites[1], counts);
                foreach (Image image in new[] { hudImage, inventoryImage })
                {
                    if (image.sprite == sprites[2]) { counts.Skipped++; continue; }
                    Undo.RecordObject(image, "Incident C08: gunshot sprite");
                    image.sprite = sprites[2];
                    counts.Assigned++;
                }
            });
        }
    }
}
#endif
