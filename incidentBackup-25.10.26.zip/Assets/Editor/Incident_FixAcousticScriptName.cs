#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_FixAcousticScriptName
    {
        public const string ScriptGuid = "81e19224933fc0049ad52ea6d918093d";
        public const string OldPath = "Assets/_Project/_Scripts/Core/acoustic/k_AcousticSystem(vremenno).cs";
        public const string NewPath = "Assets/_Project/_Scripts/Core/acoustic/K_AcousticSystem.cs";

        public static string ResolvePath()
        {
            string path = AssetDatabase.GUIDToAssetPath(ScriptGuid);
            if (path != OldPath && path != NewPath)
                throw new InvalidOperationException("Acoustic MonoScript GUID missing or moved outside approved paths: " + path);
            return path;
        }

        [MenuItem("Incident/Assets/Fix Acoustic Script Filename (C12 prerequisite)")]
        public static void Execute() => Incident_EditorSupport.Run("C12: имя MonoScript", () =>
        {
            string current = ResolvePath();
            if (!File.Exists(current) || !File.Exists(current + ".meta"))
                throw new InvalidOperationException("Нельзя создать парный backup: отсутствует C# или .meta: " + current);
            var script = Incident_EditorSupport.Asset<MonoScript>(current);
            if (EditorUtility.IsDirty(script)) throw new InvalidOperationException("Сохраните ручные изменения MonoScript перед переименованием.");
            if (current == OldPath && (File.Exists(NewPath) || File.Exists(NewPath + ".meta") || AssetDatabase.LoadMainAssetAtPath(NewPath) != null))
                throw new InvalidOperationException("Конфликт: целевой путь уже занят: " + NewPath);
            string preview = current == NewPath ? "Файл уже переименован; будет проверен GUID, без повторного переноса." :
                "AssetDatabase.MoveAsset:\n" + OldPath + "\n→ " + NewPath + "\nGUID " + ScriptGuid + " сохраняется; содержимое C# и YAML не меняется.";
            Debug.Log("[Incident/C12] PREVIEW " + preview);
            if (!EditorUtility.DisplayDialog("C12: имя MonoScript", preview + "\n\nСоздаётся backup C# и .meta. Undo для файлов не используется. Продолжить?", "Продолжить", "Отмена")) return;
            string backup = Incident_EditorSupport.Backup(new[] { current });
            var counts = new Incident_EditorSupport.Counts();
            if (current == NewPath) counts.Skipped++;
            else
            {
                string error = AssetDatabase.MoveAsset(OldPath, NewPath);
                if (!string.IsNullOrEmpty(error)) throw new InvalidOperationException(error + " Backup: " + backup);
                if (AssetDatabase.AssetPathToGUID(NewPath) != ScriptGuid)
                {
                    string rollback = AssetDatabase.MoveAsset(NewPath, OldPath);
                    throw new InvalidOperationException("GUID не сохранился. Откат: " + rollback + ". Backup: " + backup);
                }
                counts.Assigned++;
            }
            Incident_EditorSupport.Report("C12: имя MonoScript", counts,
                "Backup C# и .meta: " + backup + "\nДождитесь компиляции Unity, затем запустите Incident/Scene/Add Acoustic System.\n" +
                "Откат: через Project переименуйте K_AcousticSystem.cs обратно в k_AcousticSystem(vremenno).cs либо восстановите парные файлы из backup при закрытой Unity.");
        });
    }
}
#endif
