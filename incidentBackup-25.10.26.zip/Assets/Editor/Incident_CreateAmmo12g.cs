#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using K_Incident.Core.Combat;
using K_Incident.Core.Inventory;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_CreateAmmo12g
    {
        [MenuItem("Incident/Assets/Create Ammo12g Defaults (C04)")]
        public static void Execute() => Incident_EditorSupport.Run("C04: настраиваемый Ammo12g", () =>
        {
            const string path = "Assets/_Project/Items/I_weapons/Ammo12g_data.asset";
            var database = Incident_EditorSupport.Asset<ItemDatabase>(Incident_EditorSupport.ItemDatabasePath);
            var ammo = AssetDatabase.LoadAssetAtPath<ItemStaticData>(path);
            if (ammo == null && (File.Exists(path) || File.Exists(path + ".meta")))
                throw new InvalidOperationException("Целевой путь занят повреждённым/неимпортируемым asset/meta: " + path);
            foreach (string guid in AssetDatabase.FindAssets("t:ItemStaticData"))
            {
                var other = Incident_EditorSupport.Asset<ItemStaticData>(AssetDatabase.GUIDToAssetPath(guid));
                if (other != ammo && (other.ItemID == "ammo_12g" || other.PrefabID == 52001))
                    throw new InvalidOperationException("Identity ammo_12g/52001 занята другим ассетом: " + AssetDatabase.GetAssetPath(other));
            }
            if (ammo != null && (ammo.ItemID != "ammo_12g" || ammo.PrefabID != 52001 || ammo.Type != ItemType.Ammo || ammo.Caliber != "12g" ||
                ammo.MaxDurability != 0 || ammo.Ammunition.Type != AmmoType.Standard || ammo.WeightGrams < 0 || ammo.HardStackLimit < 1))
                throw new InvalidOperationException("Существующий Ammo12g конфликтует с identity/контрактом. Пользовательские данные не перезаписываются.");
            Incident_EditorSupport.RequireField(database, "_items");
            Incident_EditorSupport.AssetChange("C04: настраиваемый Ammo12g", "Решение пользователя: 'сделать настраиваемым'.\n" +
                (ammo == null ? "Создать " : "Сохранить существующие настройки и зарегистрировать ") + path +
                "\nНачальный preset: ItemID=ammo_12g,PrefabID=52001,Ammo/Standard,caliber12g,1×1,40г за единицу,stack8,durability0.\n" +
                "После создания параметры доступны в Inspector. Иконка остаётся ручной. Новые runtime-предметы/патроны в сцене не создаются.",
                new[] { Incident_EditorSupport.ItemDatabasePath }, (counts, created) =>
                {
                    if (ammo == null)
                    {
                        ammo = ScriptableObject.CreateInstance<ItemStaticData>();
                        try
                        {
                            var serialized = new SerializedObject(ammo);
                            Incident_EditorSupport.Property(serialized, "_itemID").stringValue = "ammo_12g";
                            Incident_EditorSupport.Property(serialized, "_prefabID").intValue = 52001;
                            Incident_EditorSupport.Property(serialized, "_displayName").stringValue = "Патрон 12 калибра";
                            Incident_EditorSupport.Property(serialized, "_type").intValue = (int)ItemType.Ammo;
                            Incident_EditorSupport.Property(serialized, "_caliber").stringValue = "12g";
                            Incident_EditorSupport.Property(serialized, "_size").vector2IntValue = Vector2Int.one;
                            Incident_EditorSupport.Property(serialized, "_weightGrams").intValue = 40;
                            Incident_EditorSupport.Property(serialized, "_hardStackLimit").intValue = 8;
                            Incident_EditorSupport.Property(serialized, "_maxDurability").intValue = 0;
                            Incident_EditorSupport.Property(serialized, "_ammunition.Type").intValue = (int)AmmoType.Standard;
                            serialized.ApplyModifiedPropertiesWithoutUndo();
                            created.Add(path);
                            AssetDatabase.CreateAsset(ammo, path);
                        }
                        catch { if (!AssetDatabase.Contains(ammo)) UnityEngine.Object.DestroyImmediate(ammo); throw; }
                        counts.Created++;
                        Debug.Log("[Incident/C04] Новый файл для отката: " + path);
                    }
                    var dbData = new SerializedObject(database);
                    var items = Incident_EditorSupport.Property(dbData, "_items");
                    if (Enumerable.Range(0, items.arraySize).Any(i => items.GetArrayElementAtIndex(i).objectReferenceValue == ammo)) counts.Skipped++;
                    else
                    {
                        int index = items.arraySize++;
                        items.GetArrayElementAtIndex(index).objectReferenceValue = ammo;
                        dbData.ApplyModifiedPropertiesWithoutUndo();
                        counts.Assigned++;
                    }
                });
        });
    }
}
#endif
