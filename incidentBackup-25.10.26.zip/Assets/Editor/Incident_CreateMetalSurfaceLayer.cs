#if UNITY_EDITOR
using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using Object = UnityEngine.Object;

namespace K_Incident.EditorTools.Iteration7
{
    // CH-07 authoring prerequisite only. No geometry, scene or runtime settings
    // are selected or modified by this operation.
    public static class Incident_CreateMetalSurfaceLayer
    {
        private const string SettingsPath = "ProjectSettings/TagManager.asset";
        private const string LayerName = "MetalSurface";

        [MenuItem("Incident/Assets/Ensure MetalSurface Layer (CH07)")]
        public static void Execute()
        {
            Incident_EditorSupport.Run("CH-07: MetalSurface layer", EnsureLayer);
        }

        private static void EnsureLayer()
        {
            Object[] assets = AssetDatabase.LoadAllAssetsAtPath(SettingsPath);
            if (assets == null || assets.Length != 1 || assets[0] == null)
                throw new InvalidOperationException("Ожидался ровно один объект " + SettingsPath + "; операция остановлена.");
            Object target = assets[0];
            var serialized = new SerializedObject(target);
            string[] original = ReadLayers(serialized);
            int[] matches = Enumerable.Range(0, original.Length)
                .Where(index => string.Equals(original[index], LayerName, StringComparison.Ordinal)).ToArray();
            if (matches.Length > 1)
                throw new InvalidOperationException("В TagManager найдено несколько слоёв с точным именем MetalSurface; устраните неоднозначность вручную.");

            int index = matches.Length == 1 ? matches[0] : -1;
            if (index < 0)
                for (int candidate = 8; candidate < 32; candidate++)
                    if (string.IsNullOrEmpty(original[candidate])) { index = candidate; break; }
            if (index < 0)
                throw new InvalidOperationException("Нет свободного пользовательского слоя 8…31. Ничего не изменено.");

            bool alreadyExists = matches.Length == 1;
            if (!alreadyExists && EditorUtility.IsDirty(target))
                throw new InvalidOperationException("Сначала сохраните или отмените несохранённые изменения Tags and Layers. Backup должен соответствовать live TagManager.");

            string projectRoot = Directory.GetParent(Application.dataPath).FullName;
            string absoluteSettings = Path.Combine(projectRoot, SettingsPath);
            if (!File.Exists(absoluteSettings))
                throw new InvalidOperationException("Не найден файл " + absoluteSettings);
            byte[] originalFile = File.ReadAllBytes(absoluteSettings);
            bool hadMeta = File.Exists(absoluteSettings + ".meta");
            byte[] originalMeta = hadMeta ? File.ReadAllBytes(absoluteSettings + ".meta") : null;
            string preview = alreadyExists
                ? "Слой MetalSurface уже существует: index " + index + ". Изменений не требуется; будет пропущено 1."
                : "Будет создано имя MetalSurface в первом свободном пользовательском слое: index " + index +
                  ".\nИзменяется только " + SettingsPath + ".\nПеред записью: backup .asset" +
                  (hadMeta ? " и существующего .meta." : "; .meta отсутствует, новый .meta не создаётся.");
            preview += "\nНазначение слоя объектам, collision matrix и настройки Player не выполняются.";
            Debug.Log("[Incident/Iteration7] PREVIEW CH-07 MetalSurface\n" + preview);
            if (!EditorUtility.DisplayDialog("CH-07: MetalSurface layer", preview + "\n\nПродолжить?", "Продолжить", "Отмена")) return;

            if (alreadyExists)
            {
                Incident_EditorSupport.Report("CH-07: MetalSurface layer",
                    new Incident_EditorSupport.Counts { Skipped = 1 }, "MetalSurface index " + index + ". Файлы не изменены.");
                return;
            }

            // Recheck after the modal preview, before backup or the first write.
            serialized.Update();
            if (EditorUtility.IsDirty(target) || !ReadLayers(serialized).SequenceEqual(original) ||
                !File.ReadAllBytes(absoluteSettings).SequenceEqual(originalFile) ||
                File.Exists(absoluteSettings + ".meta") != hadMeta ||
                (hadMeta && !File.ReadAllBytes(absoluteSettings + ".meta").SequenceEqual(originalMeta)))
                throw new InvalidOperationException("TagManager изменился после preview. Запустите операцию повторно; ничего не изменено.");

            string backupRoot = Path.Combine(projectRoot, "ReviewBackups", "Iteration7",
                DateTime.UtcNow.ToString("yyyyMMdd_HHmmss_fffffff") + "_MetalSurface_" + Guid.NewGuid().ToString("N"));
            string backup = Path.Combine(backupRoot, SettingsPath);
            Directory.CreateDirectory(Path.GetDirectoryName(backup));
            File.Copy(absoluteSettings, backup, false);
            if (hadMeta) File.Copy(absoluteSettings + ".meta", backup + ".meta", false);
            Debug.Log("[Incident/Iteration7] CH-07 TagManager backup: " + backup);

            try
            {
                serialized.FindProperty("layers").GetArrayElementAtIndex(index).stringValue = LayerName;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                // ProjectSettings is not an imported Assets/ asset. Persist the
                // complete existing object with Unity's serializer explicitly.
                InternalEditorUtility.SaveToSerializedFileAndForget(assets, absoluteSettings, true);

                string[] expected = (string[])original.Clone();
                expected[index] = LayerName;
                var verification = new SerializedObject(target);
                if (!ReadLayers(verification).SequenceEqual(expected) || LayerMask.NameToLayer(LayerName) != index ||
                    !File.Exists(absoluteSettings) || new FileInfo(absoluteSettings).Length == 0)
                    throw new InvalidOperationException("Проверка сохранённого MetalSurface не пройдена.");
            }
            catch (Exception error)
            {
                try
                {
                    var rollback = new SerializedObject(target);
                    var layers = rollback.FindProperty("layers");
                    for (int layer = 0; layer < original.Length; layer++)
                        layers.GetArrayElementAtIndex(layer).stringValue = original[layer];
                    rollback.ApplyModifiedPropertiesWithoutUndo();
                    InternalEditorUtility.SaveToSerializedFileAndForget(assets, absoluteSettings, true);
                    // Byte-for-byte backup restoration is file copying, not a
                    // textual edit of serialized settings.
                    File.Copy(backup, absoluteSettings, true);
                    if (hadMeta) File.Copy(backup + ".meta", absoluteSettings + ".meta", true);
                }
                catch (Exception rollbackError)
                {
                    throw new AggregateException("Ошибка отката TagManager. Закройте Unity и восстановите backup: " + backup, error, rollbackError);
                }
                throw new InvalidOperationException("Операция отменена, TagManager восстановлен. Backup: " + backup, error);
            }

            Incident_EditorSupport.Report("CH-07: MetalSurface layer",
                new Incident_EditorSupport.Counts { Created = 1 },
                "MetalSurface index " + index + ". Backup: " + backup +
                "\nДля отката закройте Unity и восстановите TagManager.asset" + (hadMeta ? " и .meta" : "") +
                " из копии.\nДальше вручную назначьте слой выбранным металлическим поверхностям и настройте маппинг Player.");
        }

        private static string[] ReadLayers(SerializedObject serialized)
        {
            var layers = serialized.FindProperty("layers");
            if (layers == null || !layers.isArray || layers.arraySize != 32)
                throw new InvalidOperationException("Ожидался TagManager.layers[32]; схема не распознана.");
            var values = new string[32];
            for (int index = 0; index < values.Length; index++)
            {
                var property = layers.GetArrayElementAtIndex(index);
                if (property.propertyType != SerializedPropertyType.String)
                    throw new InvalidOperationException("TagManager.layers содержит нестроковый элемент " + index);
                values[index] = property.stringValue;
            }
            return values;
        }
    }
}
#endif
