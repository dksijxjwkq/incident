#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using K_Incident.Core.Combat;
using K_Incident.Core.Inventory;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    // Writes only the existing serialized authoring fields; gameplay has no new hardcoded balance.
    public static class Incident_WeaponAuthoringSupport
    {
        public static void Configure(string path, string itemId, ushort prefabId, string caliber, bool doubleBarrel)
        {
            var asset = Incident_EditorSupport.Asset<ItemStaticData>(path);
            if (asset.ItemID != itemId || asset.PrefabID != prefabId || asset.Type != ItemType.Weapon || asset.Caliber != caliber ||
                asset.HardStackLimit != 1 || asset.IsMelee || asset.IsPistol)
                throw new InvalidOperationException("Сначала отдельные операции caliber/identity/stack1; данные не соответствуют контракту: " + path);
            WeaponType type = doubleBarrel ? WeaponType.DoubleBarrel : WeaponType.AssaultRifle;
            WeaponClass weaponClass = doubleBarrel ? WeaponClass.Shotgun : WeaponClass.AssaultRifle;
            var definition = asset.Weapon;
            if (definition == null) throw new InvalidOperationException("_weapon=null; требуется явная проверка исходных данных.");
            bool authored = definition.Type == type && definition.Class == weaponClass;
            if (!authored && JsonUtility.ToJson(definition) != JsonUtility.ToJson(new WeaponItemDefinition()))
                throw new InvalidOperationException("_weapon уже отличается от начального Pistol default. Пользовательские данные автоматически не перезаписываются; нужна отдельная миграция: " + path);
            if (authored) Validate(definition);
            var ints = new Dictionary<string, int>
            {
                { "Type", (int)type }, { "Class", (int)weaponClass }, { "EquipmentSlot", (int)EquipmentSlotType.Primary },
                { "DefaultFireMode", (int)(doubleBarrel ? FireMode.Single : FireMode.Auto) },
                { "MagazineCapacity", doubleBarrel ? 0 : 30 }, { "InternalMagazineCapacity", 0 }, { "ChamberCapacity", doubleBarrel ? 2 : 1 },
                { "BurstCount", 3 }, { "PelletCount", doubleBarrel ? 8 : 1 }, { "ExternalBleedingLevel", 1 }
            };
            var floats = new Dictionary<string, float>
            {
                { "BaseDamage", doubleBarrel ? 8f : 25f }, { "ShotInterval", doubleBarrel ? .5f : .1f }, { "BurstPause", .3f },
                { "WeaponLength", doubleBarrel ? 1.15f : .94f }, { "Range", doubleBarrel ? 50f : 100f },
                { "SpreadAngleDegrees", doubleBarrel ? 6f : 1.5f }, { "BaseWearPerShot", .3f }, { "MisfireChance", 0f },
                { "FractureChance", .15f }, { "HeadTraumaChanceMultiplier", 1f }, { "ShockDuration", 10f }
            };
            FireMode[] modes = doubleBarrel ? new[] { FireMode.Single, FireMode.Safe } : new[] { FireMode.Single, FireMode.Auto, FireMode.Safe };
            string preview = path + "\nРешение пользователя: 'сделать настраиваемым'. Это стартовые prototype defaults в Inspector, не утверждение финального баланса.\n" +
                (authored ? "Уже настроенная соответствующая definition ПРОВЕРЯЕТСЯ И СОХРАНЯЕТСЯ целиком; числа Inspector не перезаписываются.\n" : "Начальный Pistol default →\n") +
                string.Join("; ", ints.Select(pair => pair.Key + "=" + pair.Value)) + "\n" +
                string.Join("; ", floats.Select(pair => pair.Key + "=" + pair.Value.ToString(System.Globalization.CultureInfo.InvariantCulture))) +
                "\nAllowedFireModes=" + string.Join(",", modes) + "; Suppressed=false; FractureChanceByPart=пусто.\n" +
                "Все поля далее доступны в Combat Data/Weapon Inspector. ItemID/PrefabID, icons, geometry/weight и Save V10/rev6 не меняются. Существующие сейвы не мигрируют этим меню.";
            Incident_EditorSupport.AssetChange(doubleBarrel ? "C04: ТОЗ definition" : "C04: AK definition", preview, new[] { path }, (counts, created) =>
            {
                if (authored) { counts.Skipped++; return; }
                var serialized = new SerializedObject(asset);
                foreach (var pair in ints) Incident_EditorSupport.Property(serialized, "_weapon." + pair.Key).intValue = pair.Value;
                foreach (var pair in floats) Incident_EditorSupport.Property(serialized, "_weapon." + pair.Key).floatValue = pair.Value;
                Incident_EditorSupport.Property(serialized, "_weapon.Suppressed").boolValue = false;
                var allowed = Incident_EditorSupport.Property(serialized, "_weapon.AllowedFireModes");
                allowed.arraySize = modes.Length;
                for (int i = 0; i < modes.Length; i++) allowed.GetArrayElementAtIndex(i).intValue = (int)modes[i];
                Incident_EditorSupport.Property(serialized, "_weapon.FractureChanceByPart").arraySize = 0;
                serialized.ApplyModifiedPropertiesWithoutUndo();
                Validate(asset.Weapon);
                counts.Assigned += ints.Count + floats.Count + 3;
            });
        }

        private static void Validate(WeaponItemDefinition definition)
        {
            definition.ValidateFiring();
            if (definition.MagazineCapacity < 0 || definition.InternalMagazineCapacity < 0 || definition.ChamberCapacity < 1 ||
                (definition.MagazineCapacity > 0 && definition.InternalMagazineCapacity > 0) || !definition.Supports(definition.DefaultFireMode))
                throw new InvalidOperationException("Невалидная ёмкость или default mode существующей authoring definition.");
        }
    }
}
#endif
