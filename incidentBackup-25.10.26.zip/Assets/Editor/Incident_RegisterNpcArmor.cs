#if UNITY_EDITOR
using System;
using System.Linq;
using K_Incident.Core.Inventory;
using UnityEditor;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_RegisterNpcArmor
    {
        [MenuItem("Incident/Assets/Register NPC Armor Light")]
        public static void Execute() => Incident_EditorSupport.Run("C03: регистрация NPC Armor", () =>
        {
            const string path = "Assets/_Project/Items/I_Equipments/NPC_Armor_Light.asset";
            var armor = Incident_EditorSupport.Asset<ItemStaticData>(path);
            var database = Incident_EditorSupport.Asset<ItemDatabase>(Incident_EditorSupport.ItemDatabasePath);
            if (armor.ItemID != "NPC_Armor_Light" || armor.PrefabID != 51001 || armor.Type != ItemType.Armor)
                throw new InvalidOperationException("Изменилась identity/type NPC_Armor_Light. Исправление базы остановлено.");
            foreach (string guid in AssetDatabase.FindAssets("t:ItemStaticData"))
            {
                var other = Incident_EditorSupport.Asset<ItemStaticData>(AssetDatabase.GUIDToAssetPath(guid));
                if (other != armor && (other.ItemID == armor.ItemID || other.PrefabID == armor.PrefabID))
                    throw new InvalidOperationException("ID брони занят другим ассетом проекта: " + AssetDatabase.GetAssetPath(other));
            }
            var serialized = new SerializedObject(database);
            var items = Incident_EditorSupport.Property(serialized, "_items");
            foreach (int i in Enumerable.Range(0, items.arraySize))
            {
                var existing = items.GetArrayElementAtIndex(i).objectReferenceValue as ItemStaticData;
                if (existing != null && existing != armor && (existing.ItemID == armor.ItemID || existing.PrefabID == armor.PrefabID))
                    throw new InvalidOperationException("ID брони занят другой записью: " + AssetDatabase.GetAssetPath(existing));
            }
            bool registered = Enumerable.Range(0, items.arraySize).Any(i => items.GetArrayElementAtIndex(i).objectReferenceValue == armor);
            Incident_EditorSupport.AssetChange("C03: регистрация NPC Armor", (registered ? "Уже зарегистрирован: " : "Добавить в ItemDatabase: ") + path +
                "\nItemID=NPC_Armor_Light, PrefabID=51001. Параметры предмета не изменяются.", new[] { Incident_EditorSupport.ItemDatabasePath }, (counts, created) =>
                {
                    if (registered) { counts.Skipped++; return; }
                    serialized.Update();
                    items = Incident_EditorSupport.Property(serialized, "_items");
                    int index = items.arraySize++;
                    items.GetArrayElementAtIndex(index).objectReferenceValue = armor;
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                    counts.Assigned++;
                });
        });
    }
}
#endif
