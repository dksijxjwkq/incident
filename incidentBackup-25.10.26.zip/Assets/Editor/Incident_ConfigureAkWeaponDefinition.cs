#if UNITY_EDITOR
using UnityEditor;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_ConfigureAkWeaponDefinition
    {
        [MenuItem("Incident/Assets/Configure AK Weapon Defaults (C04 after caliber)")]
        public static void Execute() => Incident_EditorSupport.Run("C04: настраиваемые AK defaults", () =>
            Incident_WeaponAuthoringSupport.Configure("Assets/_Project/Items/I_weapons/AK74_data.asset", "1002", 10002, "5.45x39", false));
    }
}
#endif
