#if UNITY_EDITOR
using System;
using K_Incident.Core.Inventory;
using UnityEditor;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_ConfigureTozIdentity
    {
        [MenuItem("Incident/Assets/Configure TOZ Identity (C04 partial)")]
        public static void Execute() => Incident_EditorSupport.Run("C04: identity ТОЗ-34", () =>
        {
            const string path = "Assets/_Project/Items/I_weapons/Toz34_data.asset";
            var toz = Incident_EditorSupport.Asset<ItemStaticData>(path);
            if (toz.ItemID != "1001" || toz.PrefabID != 10001 || toz.Type != ItemType.Weapon)
                throw new InvalidOperationException("Identity/type ТОЗ изменились; IDs1001/10001 автоматически не мигрируют.");
            Incident_EditorSupport.RequireField(toz, "_displayName", "_description", "_hardStackLimit", "_caliber", "_isPistol", "_isMelee");
            Incident_EditorSupport.AssetChange("C04: identity ТОЗ-34", $"{path}\nРешение пользователя: это двуствольное ружьё.\n" +
                "Имя → ТОЗ-34; описание → Двуствольное ружьё 12 калибра; caliber →12g; stack →1; IsPistol/IsMelee →false.\n" +
                "ItemID1001, PrefabID10001 и Type=Weapon сохраняются. _weapon definition здесь не изменяется: настраиваемый prototype preset вынесен отдельным меню Configure TOZ Weapon Defaults.\n" +
                "Старые сейвы/stack>1 не мигрируют этим меню; сначала резервная копия сейвов и проверка совместимости.", new[] { path }, (counts, created) =>
                {
                    var serialized = new SerializedObject(toz);
                    SetString(serialized, "_displayName", "ТОЗ-34", counts);
                    SetString(serialized, "_description", "Двуствольное ружьё 12 калибра", counts);
                    SetString(serialized, "_caliber", "12g", counts);
                    var stack = Incident_EditorSupport.Property(serialized, "_hardStackLimit");
                    if (stack.intValue == 1) counts.Skipped++; else { stack.intValue = 1; counts.Assigned++; }
                    foreach (string field in new[] { "_isPistol", "_isMelee" })
                    {
                        var property = Incident_EditorSupport.Property(serialized, field);
                        if (!property.boolValue) counts.Skipped++; else { property.boolValue = false; counts.Assigned++; }
                    }
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                });
        });

        private static void SetString(SerializedObject owner, string path, string value, Incident_EditorSupport.Counts counts)
        {
            var property = Incident_EditorSupport.Property(owner, path);
            if (property.stringValue == value) { counts.Skipped++; return; }
            property.stringValue = value; counts.Assigned++;
        }
    }
}
#endif
