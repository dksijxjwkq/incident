#if UNITY_EDITOR
using UnityEditor;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_ConfigureTozWeaponDefinition
    {
        [MenuItem("Incident/Assets/Configure TOZ Weapon Defaults (C04 after identity)")]
        public static void Execute() => Incident_EditorSupport.Run("C04: настраиваемые ТОЗ defaults", () =>
            Incident_WeaponAuthoringSupport.Configure("Assets/_Project/Items/I_weapons/Toz34_data.asset", "1001", 10001, "12g", true));
    }
}
#endif
