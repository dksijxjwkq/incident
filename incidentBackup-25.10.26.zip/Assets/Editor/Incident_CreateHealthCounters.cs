#if UNITY_EDITOR
using System;
using K_Incident.Core.UI;
using TMPro;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_CreateHealthCounters
    {
        [MenuItem("Incident/Scene/Create Health Counters (C05)")]
        public static void Execute() => Incident_EditorSupport.Run("C05: кровь и IB", () =>
        {
            var scene = Incident_EditorSupport.RequireScene();
            var hud = Incident_EditorSupport.Component<K_HealthWidget>(Incident_EditorSupport.Path(scene, Incident_EditorSupport.HudDollPath));
            var inventory = Incident_EditorSupport.Component<K_InventoryHealthWidget>(Incident_EditorSupport.Path(scene, Incident_EditorSupport.InventoryDollPath));
            var template = Incident_EditorSupport.Named<TextMeshProUGUI>(Incident_EditorSupport.Path(scene, "HUD_Canvas/Metabolism_Group"), "Clock_Text");
            if (template.font == null) throw new InvalidOperationException("Clock_Text не имеет TMP font.");
            foreach (Component owner in new Component[] { hud, inventory })
            {
                Incident_EditorSupport.RequireField(owner, "_bloodText", "_ibCountText");
                foreach (string field in new[] { "_bloodText", "_ibCountText" })
                {
                    var existing = Incident_EditorSupport.Reference<TextMeshProUGUI>(owner, field);
                    if (existing != null && !existing.transform.IsChildOf(owner.transform))
                        throw new InvalidOperationException(owner.name + "." + field + " принадлежит чужому поддереву; операция остановлена.");
                    string name = field == "_bloodText" ? "Incident_BloodText" : "Incident_IBCountText";
                    if (existing == null && owner.transform.Find(name) != null)
                        throw new InvalidOperationException("Не связанный с полем объект уже существует: " + owner.name + "/" + name);
                }
                if (Incident_EditorSupport.Reference<TextMeshProUGUI>(owner, "_bloodText") != null &&
                    Incident_EditorSupport.Reference<TextMeshProUGUI>(owner, "_bloodText") == Incident_EditorSupport.Reference<TextMeshProUGUI>(owner, "_ibCountText"))
                    throw new InvalidOperationException("Кровь и IB ссылаются на один TMP: " + owner.name);
            }
            Incident_EditorSupport.SceneChange("C05: кровь и IB", "Создать до четырёх отдельных TMP: кровь и IB у HUD, кровь и IB у inventory.\n" +
                "Шрифт/цвет берутся с Clock_Text; raycast выключен, scale=1. Уже назначенные собственные TMP сохраняются.\nМинимальные позиции под куклами; окончательный layout — A07.", counts =>
            {
                foreach (Component owner in new Component[] { hud, inventory })
                {
                    foreach (string field in new[] { "_bloodText", "_ibCountText" })
                    {
                        if (Incident_EditorSupport.Reference<TextMeshProUGUI>(owner, field) != null) { counts.Skipped++; continue; }
                        bool blood = field == "_bloodText";
                        var text = Incident_EditorSupport.CreateText(blood ? "Incident_BloodText" : "Incident_IBCountText", owner.transform, template,
                            new Vector2(0, blood ? -280 : -312), new Vector2(220, 30));
                        counts.Created++;
                        Incident_EditorSupport.Assign(owner, field, text, counts);
                    }
                }
            });
        });
    }
}
#endif
