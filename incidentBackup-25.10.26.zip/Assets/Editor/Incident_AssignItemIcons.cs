#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.Linq;
using K_Incident.Core.Inventory;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_AssignItemIcons
    {
        // Exact import-name contract from audit A01. It never searches Gemini files or chooses artwork.
        private static readonly string[] MedicalIds =
        {
            "bandage", "collar_neck", "gel_heal", "glue_medical", "hemostatic", "painkiller", "splint_sam",
            "splint_wood", "stapler_medical", "stimulator", "strips_wound", "surgery_kit", "tourniquet", "transfusion"
        };
        private const string IconFolder = "Assets/_Project/UI/visual_icons/Medical_Items/";
        // Audit names the armor PNG, but not its subfolder: this explicit contract is shown before application.
        private const string ArmorPng = "Assets/_Project/UI/visual_icons/NPC_Armor_Light.png";

        [MenuItem("Incident/Assets/Preview Item Icons (C11 after A01)")]
        public static void Preview() => Incident_EditorSupport.Run("C11: dry-run", () => Prepare(false));

        [MenuItem("Incident/Assets/Assign Item Icons (C11 after A01)")]
        public static void Execute() => Incident_EditorSupport.Run("C11: item icons", () => Prepare(true));

        private static void Prepare(bool apply)
        {
            string[] ids = MedicalIds.Concat(new[] { "NPC_Armor_Light" }).ToArray();
            string[] assetPaths = MedicalIds.Select(id => Incident_EditorSupport.MedicalFolder + "/" + id + ".asset")
                .Concat(new[] { "Assets/_Project/Items/I_Equipments/NPC_Armor_Light.asset" }).ToArray();
            string[] spritePaths = MedicalIds.Select(id => IconFolder + id + ".png").Concat(new[] { ArmorPng }).ToArray();
            var assets = new ItemStaticData[ids.Length];
            var sprites = new Sprite[ids.Length];
            var errors = new List<string>();
            var lines = new List<string>();
            for (int i = 0; i < ids.Length; i++)
            {
                lines.Add(ids[i] + " → " + spritePaths[i]);
                try
                {
                    assets[i] = Incident_EditorSupport.Asset<ItemStaticData>(assetPaths[i]);
                    if (assets[i].ItemID != ids[i]) throw new InvalidOperationException("ItemID не совпадает с картой: " + assetPaths[i]);
                    Incident_EditorSupport.RequireField(assets[i], "_icon");
                }
                catch (Exception ex) { errors.Add(ex.Message); }
                try { sprites[i] = Incident_EditorSupport.Sprite(spritePaths[i]); }
                catch (Exception ex) { errors.Add(ex.Message); }
            }
            string preview = "Карта A01: 14 медицинских предметов + броня.\n" + string.Join("\n", lines) +
                "\nArmor PNG ожидается непосредственно в visual_icons (явный путь показан выше).\n" +
                "coagulant/transamacha/jett не входят в A01-карту: нужны отдельно утверждённые имена PNG.\n" +
                (errors.Count == 0 ? "Все указанные ассеты и импорты готовы." : "НЕ ГОТОВО:\n" + string.Join("\n", errors));
            Debug.Log("[Incident/C11] DRY-RUN\n" + preview);
            if (!apply)
            {
                Incident_EditorSupport.Report("C11: dry-run", new Incident_EditorSupport.Counts { Skipped = ids.Length }, preview + "\nИзменений нет.");
                return;
            }
            if (errors.Count > 0) throw new InvalidOperationException("Сначала A01. Все отсутствующие/неверные импорты:\n" + string.Join("\n", errors));
            Incident_EditorSupport.AssetChange("C11: item icons", preview, assetPaths, (counts, created) =>
            {
                for (int i = 0; i < ids.Length; i++)
                {
                    if (assets[i].Icon == sprites[i]) { counts.Skipped++; continue; }
                    var serialized = new SerializedObject(assets[i]);
                    Incident_EditorSupport.Property(serialized, "_icon").objectReferenceValue = sprites[i];
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                    counts.Assigned++;
                }
            });
        }
    }
}
#endif
