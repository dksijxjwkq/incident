#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using K_Incident.Core.Combat;
using K_Incident.Core.Inventory;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_CreateAkAmmoAndMagazine
    {
        private static readonly string[] Ids = { "ammo_545x39", "magazine_ak74" };
        private static readonly int[] Prefabs = { 52002, 52003 };
        private static readonly ItemType[] Types = { ItemType.Ammo, ItemType.Magazine };
        private static readonly string[] Paths =
        {
            "Assets/_Project/Items/I_weapons/Ammo545x39_data.asset",
            "Assets/_Project/Items/I_weapons/MagazineAK74_data.asset"
        };

        [MenuItem("Incident/Assets/Create AK Ammo and Magazine (C04)")]
        public static void Execute() => Incident_EditorSupport.Run("C04: Ammo/Magazine АК", () =>
        {
            var database = Incident_EditorSupport.Asset<ItemDatabase>(Incident_EditorSupport.ItemDatabasePath);
            var assets = new ItemStaticData[2];
            var all = AssetDatabase.FindAssets("t:ItemStaticData").Select(AssetDatabase.GUIDToAssetPath)
                .Select(Incident_EditorSupport.Asset<ItemStaticData>).ToArray();
            for (int i = 0; i < assets.Length; i++)
            {
                assets[i] = AssetDatabase.LoadAssetAtPath<ItemStaticData>(Paths[i]);
                if (assets[i] == null && (File.Exists(Paths[i]) || File.Exists(Paths[i] + ".meta")))
                    throw new InvalidOperationException("Путь занят неимпортируемым asset/meta, перезапись запрещена: " + Paths[i]);
                if (all.Any(item => item != assets[i] && (item.ItemID == Ids[i] || item.PrefabID == Prefabs[i])))
                    throw new InvalidOperationException($"Identity {Ids[i]}/{Prefabs[i]} занята другим ассетом. Ничего не создано.");
                var item = assets[i];
                if (item != null && (item.ItemID != Ids[i] || item.PrefabID != Prefabs[i] || item.Type != Types[i] || item.Caliber != "5.45x39"))
                    throw new InvalidOperationException("Конфликт identity/type/caliber: " + Paths[i]);
                if (item != null && ((i == 0 && (item.MaxDurability != 0 || item.Ammunition.Type != AmmoType.Standard)) ||
                    (i == 1 && (item.Magazine.Capacity != 30 || item.Magazine.WeaponClass != WeaponClass.AssaultRifle))))
                    throw new InvalidOperationException("Существующая combat definition расходится с утверждённой картой: " + Paths[i]);
            }
            Incident_EditorSupport.RequireField(database, "_items");
            string preview = "Утверждённые пользователем новые предметы; существующие совпадающие ассеты только регистрируются:\n" +
                Paths[0] + "\nItemID=ammo_545x39, PrefabID=52002, Ammo/Standard,5.45x39,1×1,10г,stack30,durability0.\n" +
                Paths[1] + "\nItemID=magazine_ak74, PrefabID=52003, Magazine/AssaultRifle,5.45x39,1×2,250г пустой,capacity30,stack1.\n" +
                "Оба регистрируются в ItemDatabase. Иконки требуют ручного выбора. AK74._weapon и caliber здесь не изменяются: для них отдельные меню.";
            Incident_EditorSupport.AssetChange("C04: Ammo/Magazine АК", preview, new[] { Incident_EditorSupport.ItemDatabasePath }, (counts, created) =>
            {
                for (int i = 0; i < assets.Length; i++)
                {
                    var item = assets[i];
                    if (item == null)
                    {
                        item = ScriptableObject.CreateInstance<ItemStaticData>();
                        try
                        {
                            var serialized = new SerializedObject(item);
                            Incident_EditorSupport.Property(serialized, "_itemID").stringValue = Ids[i];
                            Incident_EditorSupport.Property(serialized, "_prefabID").intValue = Prefabs[i];
                            Incident_EditorSupport.Property(serialized, "_displayName").stringValue = i == 0 ? "Патрон 5.45×39" : "Магазин АК74 (30)";
                            Incident_EditorSupport.Property(serialized, "_type").intValue = (int)Types[i];
                            Incident_EditorSupport.Property(serialized, "_caliber").stringValue = "5.45x39";
                            Incident_EditorSupport.Property(serialized, "_size").vector2IntValue = new Vector2Int(1, i == 0 ? 1 : 2);
                            Incident_EditorSupport.Property(serialized, "_weightGrams").intValue = i == 0 ? 10 : 250;
                            Incident_EditorSupport.Property(serialized, "_hardStackLimit").intValue = i == 0 ? 30 : 1;
                            if (i == 0)
                            {
                                Incident_EditorSupport.Property(serialized, "_maxDurability").intValue = 0;
                                Incident_EditorSupport.Property(serialized, "_ammunition.Type").intValue = (int)AmmoType.Standard;
                            }
                            else
                            {
                                Incident_EditorSupport.Property(serialized, "_magazine.Capacity").intValue = 30;
                                Incident_EditorSupport.Property(serialized, "_magazine.WeaponClass").intValue = (int)WeaponClass.AssaultRifle;
                            }
                            serialized.ApplyModifiedPropertiesWithoutUndo();
                            created.Add(Paths[i]);
                            AssetDatabase.CreateAsset(item, Paths[i]);
                        }
                        catch { if (!AssetDatabase.Contains(item)) UnityEngine.Object.DestroyImmediate(item); throw; }
                        counts.Created++;
                        Debug.Log("[Incident/C04] Новый файл для отката: " + Paths[i]);
                    }
                    var serializedDb = new SerializedObject(database);
                    var items = Incident_EditorSupport.Property(serializedDb, "_items");
                    if (Enumerable.Range(0, items.arraySize).Any(index => items.GetArrayElementAtIndex(index).objectReferenceValue == item)) counts.Skipped++;
                    else
                    {
                        int index = items.arraySize++;
                        items.GetArrayElementAtIndex(index).objectReferenceValue = item;
                        serializedDb.ApplyModifiedPropertiesWithoutUndo();
                        counts.Assigned++;
                    }
                }
            });
        });
    }
}
#endif
