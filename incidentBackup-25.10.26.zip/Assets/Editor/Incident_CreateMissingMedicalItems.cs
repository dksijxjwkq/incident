#if UNITY_EDITOR
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using K_Incident.Core.Inventory;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_CreateMissingMedicalItems
    {
        private readonly struct Definition
        {
            public readonly string Id, Name;
            public readonly int Prefab, Width, Height, Weight, Stack;
            public Definition(string id, string name, int prefab, int width, int height, int weight, int stack)
            { Id = id; Name = name; Prefab = prefab; Width = width; Height = height; Weight = weight; Stack = stack; }
        }

        private static readonly Definition[] Definitions =
        {
            new Definition("coagulant", "Коагулянт", 3015, 1, 1, 80, 3),
            new Definition("transamacha", "Трансамача", 3016, 1, 1, 100, 3),
            new Definition("jett", "JETT", 3017, 1, 2, 250, 1)
        };

        [MenuItem("Incident/Assets/Create Missing Medical Items")]
        public static void Execute() => Incident_EditorSupport.Run("C02: недостающие медикаменты", Prepare);

        private static void Prepare()
        {
            var database = Incident_EditorSupport.Asset<ItemDatabase>(Incident_EditorSupport.ItemDatabasePath);
            if (!AssetDatabase.IsValidFolder(Incident_EditorSupport.MedicalFolder))
                throw new InvalidOperationException("Изменилась медицинская папка: " + Incident_EditorSupport.MedicalFolder);
            var all = AssetDatabase.FindAssets("t:ItemStaticData").Select(AssetDatabase.GUIDToAssetPath)
                .Select(Incident_EditorSupport.Asset<ItemStaticData>).ToArray();
            var idCollision = all.GroupBy(a => a.ItemID).FirstOrDefault(g => string.IsNullOrWhiteSpace(g.Key) || g.Count() > 1);
            var prefabCollision = all.GroupBy(a => a.PrefabID).FirstOrDefault(g => g.Key == 0 || g.Count() > 1);
            if (idCollision != null || prefabCollision != null)
                throw new InvalidOperationException("До создания устраните пустые/дублирующиеся ItemID или PrefabID. Предметы: " +
                    string.Join(", ", (idCollision != null ? idCollision : prefabCollision.Select(x => x)).Select(a => AssetDatabase.GetAssetPath(a))));
            var assets = new Dictionary<string, ItemStaticData>();
            var preview = new List<string>();
            foreach (var def in Definitions)
            {
                string path = ItemPath(def.Id);
                var asset = AssetDatabase.LoadAssetAtPath<ItemStaticData>(path);
                if (asset == null && (File.Exists(path) || File.Exists(path + ".meta")))
                    throw new InvalidOperationException("На целевом пути есть неимпортированный/повреждённый asset или meta. Перезапись запрещена: " + path);
                if (AssetDatabase.LoadMainAssetAtPath(path) != null && asset == null)
                    throw new InvalidOperationException("Путь занят другим типом: " + path);
                if (asset != null && (asset.ItemID != def.Id || asset.PrefabID != def.Prefab || asset.Type != ItemType.Medical))
                    throw new InvalidOperationException("Identity/type конфликт: " + path);
                if (all.Any(a => (a.ItemID == def.Id || a.PrefabID == def.Prefab) && a != asset))
                    throw new InvalidOperationException($"ItemID {def.Id} / PrefabID {def.Prefab} занят другим ассетом.");
                if (asset != null && def.Id == "jett" &&
                    (asset.ChargeCategory != ChargeCategory.DurationPercent || asset.FullChargeSeconds != 420f || asset.HardStackLimit != 1))
                    throw new InvalidOperationException("Существующий JETT не соответствует DurationPercent/420/stack1; нужна явная миграция, не перезапись.");
                assets[def.Id] = asset;
                preview.Add($"{(asset == null ? "Создать" : "Проверить регистрацию")} {path}: ItemID={def.Id}, PrefabID={def.Prefab}." +
                    (def.Id == "jett" ? " DurationPercent, 420 секунд, stack1." : " Preset существующего генератора, charge=None."));
            }
            Incident_EditorSupport.RequireField(database, "_items");
            Incident_EditorSupport.AssetChange("C02: недостающие медикаменты", string.Join("\n", preview) +
                "\nСуществующие предметы не перенастраиваются. Иконки требуют A01; текущий статус будет напечатан.",
                new[] { Incident_EditorSupport.ItemDatabasePath }, (counts, created) =>
                {
                    foreach (var def in Definitions)
                    {
                        var asset = assets[def.Id];
                        if (asset == null)
                        {
                            asset = ScriptableObject.CreateInstance<ItemStaticData>();
                            try
                            {
                                var serialized = new SerializedObject(asset);
                                Incident_EditorSupport.Property(serialized, "_itemID").stringValue = def.Id;
                                Incident_EditorSupport.Property(serialized, "_displayName").stringValue = def.Name;
                                Incident_EditorSupport.Property(serialized, "_prefabID").intValue = def.Prefab;
                                Incident_EditorSupport.Property(serialized, "_size").vector2IntValue = new Vector2Int(def.Width, def.Height);
                                Incident_EditorSupport.Property(serialized, "_weightGrams").intValue = def.Weight;
                                Incident_EditorSupport.Property(serialized, "_hardStackLimit").intValue = def.Stack;
                                Incident_EditorSupport.Property(serialized, "_type").intValue = (int)ItemType.Medical;
                                Incident_EditorSupport.Property(serialized, "_chargeCategory").intValue = (int)(def.Id == "jett" ? ChargeCategory.DurationPercent : ChargeCategory.None);
                                Incident_EditorSupport.Property(serialized, "_fullChargeSeconds").floatValue = 420f;
                                serialized.ApplyModifiedPropertiesWithoutUndo();
                                created.Add(ItemPath(def.Id));
                                AssetDatabase.CreateAsset(asset, ItemPath(def.Id));
                            }
                            catch { if (!AssetDatabase.Contains(asset)) UnityEngine.Object.DestroyImmediate(asset); throw; }
                            counts.Created++;
                            Debug.Log("[Incident/C02] Создан новый файл для возможного отката: " + ItemPath(def.Id));
                        }
                        var db = new SerializedObject(database);
                        var items = Incident_EditorSupport.Property(db, "_items");
                        bool registered = Enumerable.Range(0, items.arraySize).Any(i => items.GetArrayElementAtIndex(i).objectReferenceValue == asset);
                        if (registered) counts.Skipped++;
                        else
                        {
                            int index = items.arraySize++;
                            items.GetArrayElementAtIndex(index).objectReferenceValue = asset;
                            db.ApplyModifiedPropertiesWithoutUndo();
                            counts.Assigned++;
                        }
                        Debug.Log($"[Incident/C02] {def.Id}: prefab={asset.PrefabID}, charge={asset.ChargeCategory}, full={asset.FullChargeSeconds}, stack={asset.HardStackLimit}, icon={(asset.Icon == null ? "A01 не назначена" : "есть")}.");
                    }
                });
        }

        private static string ItemPath(string id) => Incident_EditorSupport.MedicalFolder + "/" + id + ".asset";
    }
}
#endif
