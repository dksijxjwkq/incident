#if UNITY_EDITOR
using System;
using System.Linq;
using K_Incident.Core;
using K_Incident.Core.Inventory;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_CreateMedicalMirror
    {
        [MenuItem("Incident/Scene/Create Medical Mirror (C01 after C06)")]
        public static void Execute() => Incident_EditorSupport.Run("C01: панель медикаментов", () =>
        {
            var scene = Incident_EditorSupport.RequireScene();
            var pane = Incident_EditorSupport.Path(scene, Incident_EditorSupport.HealthPanePath);
            var ui = Incident_EditorSupport.Component<K_InventoryUI>(Incident_EditorSupport.Path(scene, "UI_Inventory"));
            if (Incident_EditorSupport.Unique<K_InventoryUI>(scene) != ui)
                throw new InvalidOperationException("Требуется единственный корневой UI_Inventory.");
            var inventory = Incident_EditorSupport.Component<K_InventoryHealthWidget>(Incident_EditorSupport.Path(scene, Incident_EditorSupport.InventoryDollPath));
            foreach (string field in Incident_SeparateInventoryStatuses.Fields)
            {
                var image = Incident_EditorSupport.Reference<UnityEngine.UI.Image>(inventory, field);
                if (image == null || !image.transform.IsChildOf(inventory.transform))
                    throw new InvalidOperationException("Сначала C07 → C06: inventory " + field + " ещё не принадлежит собственной кукле.");
            }
            var player = Incident_EditorSupport.Path(scene, "Player");
            var health = Incident_EditorSupport.Component<K_HealthSystem>(player);
            var blood = Incident_EditorSupport.Component<K_BloodSystem>(player);
            var vitality = Incident_EditorSupport.Component<K_VitalitySystem>(player);
            var debuff = Incident_EditorSupport.Component<K_DebuffSystem>(player);
            var database = Incident_EditorSupport.Asset<MedicalDatabase>(Incident_EditorSupport.MedicalDatabasePath);
            Incident_EditorSupport.RequireField(ui, "_medicalMirrorPanel");
            var panels = scene.GetRootGameObjects().SelectMany(go => go.GetComponentsInChildren<K_MedicalMirrorPanel>(true)).ToArray();
            if (panels.Length > 1 || (panels.Length == 1 && !panels[0].transform.IsChildOf(pane)))
                throw new InvalidOperationException("Есть несколько mirror-панелей или панель вне HealthContentPane; автоматическое добавление остановлено.");
            K_MedicalMirrorPanel panel = panels.Length == 1 ? panels[0] : null;
            var linked = Incident_EditorSupport.Reference<K_MedicalMirrorPanel>(ui, "_medicalMirrorPanel");
            if (linked != null && linked != panel) throw new InvalidOperationException("UI_Inventory уже связан с другой mirror-панелью.");
            if (panel == null && pane.Find("Incident_MedicalMirror") != null)
                throw new InvalidOperationException("Имя Incident_MedicalMirror занято объектом без ожидаемого компонента.");
            Transform content = panel == null ? null : Incident_EditorSupport.Reference<Transform>(panel, "_contentContainer");
            if (content != null && !content.IsChildOf(panel.transform)) throw new InvalidOperationException("Mirror content принадлежит чужому поддереву.");
            if (panel != null && content == null && panel.transform.Find("Content") != null)
                throw new InvalidOperationException("Mirror/Content существует без привязки; проверьте Inspector.");
            Incident_EditorSupport.SceneChange("C01: панель медикаментов", "Создать/проверить одну K_MedicalMirrorPanel под HealthContentPane.\n" +
                "Назначить корневой UI_Inventory, Content, MedicalDatabase и health/blood/vitality/debuff единственного Player; связать UI._medicalMirrorPanel.\n" +
                "Все обязательные поля заполняются до активации новой панели. Минимальная панель 320×240, scale=1; A07 поправит позицию.", counts =>
            {
                bool createdPanel = panel == null;
                if (createdPanel)
                {
                    var rect = Incident_EditorSupport.CreateRect("Incident_MedicalMirror", pane, new Vector2(340, -32), new Vector2(320, 240));
                    rect.gameObject.SetActive(false);
                    panel = Undo.AddComponent<K_MedicalMirrorPanel>(rect.gameObject);
                    counts.Created++;
                }
                if (content == null)
                {
                    content = Incident_EditorSupport.CreateRect("Content", panel.transform, Vector2.zero, new Vector2(320, 240));
                    counts.Created++;
                }
                Incident_EditorSupport.Assign(panel, "_inventoryUI", ui, counts);
                Incident_EditorSupport.Assign(panel, "_contentContainer", content, counts);
                Incident_EditorSupport.Assign(panel, "_medicalDatabase", database, counts);
                Incident_EditorSupport.Assign(panel, "_healthSystem", health, counts);
                Incident_EditorSupport.Assign(panel, "_bloodSystem", blood, counts);
                Incident_EditorSupport.Assign(panel, "_vitalitySystem", vitality, counts);
                Incident_EditorSupport.Assign(panel, "_debuffSystem", debuff, counts);
                Incident_EditorSupport.Assign(ui, "_medicalMirrorPanel", panel, counts);
                if (createdPanel) panel.gameObject.SetActive(true);
                if (!panel.enabled)
                    throw new InvalidOperationException("Существующая mirror-панель disabled; её включение требует проверки причины. Изменения отменены.");
            });
        });
    }
}
#endif
