#if UNITY_EDITOR
using System;
using K_Incident.Core.Inventory;
using UnityEditor;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_CanonicalizeAkCaliber
    {
        [MenuItem("Incident/Assets/Canonicalize AK Caliber (C04 partial)")]
        public static void Execute() => Incident_EditorSupport.Run("C04: только калибр AK", () =>
        {
            const string path = "Assets/_Project/Items/I_weapons/AK74_data.asset";
            var ak = Incident_EditorSupport.Asset<ItemStaticData>(path);
            if (ak.ItemID != "1002" || ak.PrefabID != 10002 || ak.Type != ItemType.Weapon || ak.IsMelee || ak.IsPistol)
                throw new InvalidOperationException("Изменилась identity/classification AK74. Операция остановлена.");
            var serialized = new SerializedObject(ak);
            string previous = Incident_EditorSupport.Property(serialized, "_caliber").stringValue;
            Incident_EditorSupport.AssetChange("C04: только калибр AK", $"{path}\n_caliber: '{previous}' → '5.45x39'.\n" +
                "Оружейная _weapon definition здесь не изменяется: для настраиваемого prototype preset есть отдельное меню Configure AK Weapon Defaults. После одного изменения caliber AK не объявляется готовым.",
                new[] { path }, (counts, created) =>
                {
                    if (previous == "5.45x39") { counts.Skipped++; return; }
                    Incident_EditorSupport.Property(serialized, "_caliber").stringValue = "5.45x39";
                    serialized.ApplyModifiedPropertiesWithoutUndo();
                    counts.Assigned++;
                });
        });
    }
}
#endif
