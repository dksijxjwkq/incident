#if UNITY_EDITOR
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace K_Incident.EditorTools.Iteration7
{
    public static class Incident_CheckRendererResources
    {
        private static readonly string[] Fields =
        {
            "probeVolumeDebugShader", "probeVolumeFragmentationDebugShader", "probeVolumeOffsetDebugShader", "probeVolumeSamplingDebugShader",
            "probeSamplingDebugMesh", "probeSamplingDebugTexture", "probeVolumeBlendStatesCS"
        };

        [MenuItem("Incident/Assets/Check Renderer Resources (C-REF2 read only)")]
        public static void Execute() => Incident_EditorSupport.Run("C-REF2: renderer resources", () =>
        {
            const string path = "Assets/Settings/PC_Renderer.asset";
            var renderer = Incident_EditorSupport.Asset<ScriptableObject>(path);
            var serialized = new SerializedObject(renderer);
            var lines = new List<string> { path, "Проверяются семь obsolete probeVolumeResources; отсутствие не доказывает отказ текущего URP renderer." };
            foreach (string field in Fields)
            {
                string propertyPath = "probeVolumeResources." + field;
                var property = serialized.FindProperty(propertyPath);
                lines.Add(propertyPath + ": " + (property == null ? "не экспонируется текущим URP" :
                    property.objectReferenceValue == null ? "NULL/MISSING (legacy)" : AssetDatabase.GetAssetPath(property.objectReferenceValue)));
            }
            var features = Incident_EditorSupport.Property(serialized, "m_RendererFeatures");
            for (int i = 0; i < features.arraySize; i++)
            {
                var feature = features.GetArrayElementAtIndex(i).objectReferenceValue;
                lines.Add($"RendererFeature[{i}]: {(feature == null ? "MISSING" : feature.name + " / " + feature.GetType().FullName)}");
            }
            var graphics = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/GraphicsSettings.asset");
            if (graphics.Length == 0) lines.Add("GraphicsSettings не доступен через AssetDatabase: проверьте Project Settings → Graphics → APV resources вручную.");
            foreach (var asset in graphics)
            {
                if (asset == null) continue;
                var iterator = new SerializedObject(asset).GetIterator();
                while (iterator.Next(true))
                    if (iterator.propertyType == SerializedPropertyType.ObjectReference && iterator.propertyPath.ToLowerInvariant().Contains("probe"))
                        lines.Add("GraphicsSettings." + iterator.propertyPath + ": " + (iterator.objectReferenceValue == null ? "NULL" : AssetDatabase.GetAssetPath(iterator.objectReferenceValue)));
            }
            lines.Add("Read-only: renderer, SSAO, masks и shaders не меняются. Миграция косметических deprecated-полей отложена до подтверждённого штатного API и визуальной проверки.");
            string report = string.Join("\n", lines);
            Debug.Log("[Incident/C-REF2] " + report);
            Incident_EditorSupport.Report("C-REF2: только проверка", new Incident_EditorSupport.Counts { Skipped = Fields.Length }, report);
        });
    }
}
#endif
