using System;
using System.IO;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

namespace K_Incident.Core
{
    public interface ISaveable
    {
        string SaveID { get; }
        bool IsDirty { get; set; }
        void Save(BinaryWriter writer);
        void Load(BinaryReader reader);
    }

    public static class BinaryExtensions
    {
        public static void WriteVector3(this BinaryWriter writer, Vector3 vector)
        {
            writer.Write(vector.x);
            writer.Write(vector.y);
            writer.Write(vector.z);
        }
        public static Vector3 ReadVector3(this BinaryReader reader)
        {
            return new Vector3(reader.ReadSingle(), reader.ReadSingle(), reader.ReadSingle());
        }
    }

    public class K_SaveManager : MonoBehaviour
    {
        public static K_SaveManager Instance { get; private set; }
        public static int SaveVersion { get; private set; } = 1; // ДОБАВЛЕНО: Версия формата
        
        private string _savePath;
        private readonly List<ISaveable> _saveables = new List<ISaveable>();

        private void Awake()
        {
            if (Instance != null) { Destroy(gameObject); return; }
            Instance = this;
            _savePath = Path.Combine(Application.persistentDataPath, "save_01.dat");
            Debug.Log($"[K_SaveManager] Save path: {Application.persistentDataPath}");
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (keyboard == null) return;
            if (keyboard.f5Key.wasPressedThisFrame) SaveGame();
            if (keyboard.f9Key.wasPressedThisFrame) LoadGame();
        }

        public void Register(ISaveable saveable)
        {
            if (saveable != null && !_saveables.Contains(saveable))
                _saveables.Add(saveable);
        }

        public void Unregister(ISaveable saveable)
        {
            if (saveable != null && _saveables.Contains(saveable))
                _saveables.Remove(saveable);
        }

        private void CleanupDeadReferences()
        {
            _saveables.RemoveAll(s => s == null || (s is MonoBehaviour mb && mb == null));
        }

        public void SaveGame()
        {
            try
            {
                CleanupDeadReferences();
                SaveVersion = 2; // ФИКС: Устанавливаем новую версию
                using (BinaryWriter writer = new BinaryWriter(File.Open(_savePath, FileMode.Create)))
                {
                    writer.Write("INCIDENT_V2"); // ФИКС: Bump версии
                    foreach (var obj in _saveables)
                    {
                        if (obj != null)
                        {
                            writer.Write(obj.SaveID);
                            obj.Save(writer);
                            obj.IsDirty = false;
                        }
                    }
                }
                Debug.Log($"[K_SaveManager] ✅ Save successful (V2). Objects saved: {_saveables.Count}");
            }
            catch (Exception e) { Debug.LogError($"[K_SaveManager] ❌ Save Failed: {e.Message}"); }
        }

        public void LoadGame()
        {
            if (!File.Exists(_savePath))
            {
                Debug.LogWarning("[K_SaveManager] No save file found.");
                return;
            }
            try
            {
                CleanupDeadReferences();
                _saveables.Sort((a, b) =>
                {
                    bool aIsEquip = a.SaveID == "Player_Equipment";
                    bool bIsEquip = b.SaveID == "Player_Equipment";
                    if (aIsEquip && !bIsEquip) return 1;  
                    if (!aIsEquip && bIsEquip) return -1; 
                    return 0;
                });
                
                using (BinaryReader reader = new BinaryReader(File.Open(_savePath, FileMode.Open)))
                {
                    string header = reader.ReadString();
                    if (header == "INCIDENT_V1") SaveVersion = 1;      // МИГРАЦИЯ: Старый формат
                    else if (header == "INCIDENT_V2") SaveVersion = 2; // МИГРАЦИЯ: Новый формат
                    else
                    {
                        Debug.LogWarning($"[K_SaveManager] Invalid save file header: {header}");
                        return;
                    }
                    
                    int loadedCount = 0;
                    int missingCount = 0;
                    while (reader.BaseStream.Position < reader.BaseStream.Length)
                    {
                        string id = reader.ReadString();
                        ISaveable target = _saveables.Find(x => x != null && x.SaveID == id);
                        if (target != null)
                        {
                            target.Load(reader);
                            loadedCount++;
                        }
                        else
                        {
                            Debug.LogWarning($"[K_SaveManager] ⚠ Unknown SaveID '{id}'");
                            missingCount++;
                        }
                    }
                    Debug.Log($"[K_SaveManager] ✅ Load completed (V{SaveVersion}). Loaded {loadedCount} objects.");
                }
            }
            catch (Exception e)
            {
                Debug.LogError($"[K_SaveManager] ❌ Load Failed: {e.Message}");
            }
        }
    }
}