using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Извлечено из K_InventoryUI (Задача 5F — Drag Ghost Presentation).
    ///
    /// Отвечает ТОЛЬКО за визуальный «призрак» перетаскиваемого предмета:
    ///   - Создание ghost-объекта из префаба (Instantiate, Canvas, CanvasGroup,
    ///     GhostName, GhostCaliber — всё программно, как раньше делал Awake()).
    ///   - SetupDragOutline (-> Begin): настройка иконки, размеров, поворота.
    ///   - UpdateDragGhostPosition (-> UpdatePosition): следование за курсором.
    ///   - RotateDraggedItem (-> Rotate): вращение тащимого предмета.
    ///   - UpdateGhostSize / UpdateGhostRotation / RefreshGhostAfterFold.
    ///   - End(): скрытие ghost.
    ///
    /// НЕ отвечает за:
    ///   - подсветку ячеек (DragHighlightController)
    ///   - логику drop/swap (TryPlaceItem, TrySwapItems)
    ///   - состояние drag-сессии (_isDragging, _draggedItem, _dragItemRemoved —
    ///     всё это живёт в K_InventoryUI как часть транзакционной модели)
    ///
    /// ВНИМАНИЕ: класс СИНХРОННЫЙ. Запрещено использовать async/await,
    /// Task, Coroutine, yield return.
    ///
    /// Создаётся в K_InventoryUI.Awake() ПОСЛЕ _highlightController.
    /// Ghost-объект инстанцируется через CreateGhost(prefab) — это
    /// перенос строк 418..510 старого Awake().
    /// </summary>
    public sealed class DragGhostPresenter
    {
        // ═══════════════════════════════════════════════════════════
        //  КОНСТАНТЫ
        // ═══════════════════════════════════════════════════════════
        private const int GHOST_SORTING_ORDER = 32000;

        // ═══════════════════════════════════════════════════════════
        //  ЗАВИСИМОСТИ
        // ═══════════════════════════════════════════════════════════
        private K_InventoryUI _ui;
        private DragHighlightController _highlights;

        // ═══════════════════════════════════════════════════════════
        //  СОСТОЯНИЕ GHOST
        // ═══════════════════════════════════════════════════════════
        private GameObject _dragGhost;
        private RectTransform _dragGhostRT;
        private Image _dragGhostImage;
        private RectTransform _dragGhostIconRect;
        private Image _dragGhostRootImage;
        private TextMeshProUGUI _dragGhostNameText;
        private TextMeshProUGUI _dragGhostCaliberText;
        private CanvasGroup _dragGhostCanvasGroup;
        private Canvas _dragGhostCanvas;

        // ═══════════════════════════════════════════════════════════
        //  ПУБЛИЧНЫЙ API
        // ═══════════════════════════════════════════════════════════

        /// <summary>RT призрака — нужен DragHighlightController для FindBestBackpackUnderGhost и т.д.</summary>
        public RectTransform GhostRect => _dragGhostRT;

        /// <summary>Активен ли ghost-объект (создан и не уничтожен).</summary>
        public bool IsGhostAvailable => _dragGhost != null && _dragGhostRT != null;

        /// <summary>
        /// Инициализация. Вызывается из K_InventoryUI.Awake().
        /// _highlights может быть передан позже через SetHighlightController,
        /// если порядок создания требует сначала создать presenter, потом
        /// highlights, и только потом связать их.
        /// </summary>
        ///         /// <summary>Screen-AABB фактически отрисованной иконки ghost'а.</summary>
        public bool TryGetVisualScreenBounds(out Vector2 min, out Vector2 max)
        {
            return VisualRectUtility.TryGetVisualBounds(
                _dragGhostIconRect, _dragGhostImage,
                _ui != null ? _ui.RootCanvasCamera : null,
                out min, out max);
        }
        /// 
        public void Initialize(K_InventoryUI ui, DragHighlightController highlights)
        {
            _ui = ui;
            _highlights = highlights;
        }

        /// <summary>Поздняя привязка контроллера подсветки (для разрыва цикла инициализации).</summary>
        public void SetHighlightController(DragHighlightController highlights)
        {
            _highlights = highlights;
        }

        /// <summary>
        /// Создаёт ghost-объект из префаба. Перенос строк 418..510 старого Awake().
        /// Вызывается из K_InventoryUI.Awake() ПОСЛЕ Initialize.
        /// </summary>
        public void CreateGhost(GameObject dragGhostPrefab)
        {
            if (dragGhostPrefab == null)
            {
                Debug.LogWarning("[DragGhostPresenter] _dragGhostPrefab is null — ghost disabled.");
                return;
            }

            _dragGhost = Object.Instantiate(dragGhostPrefab);
            _dragGhost.SetActive(false);

            RectTransform prefabRT = _dragGhost.GetComponent<RectTransform>();
            Image prefabImage = _dragGhost.GetComponent<Image>();
            _dragGhostRT = prefabRT;

            if (prefabImage != null)
            {
                _dragGhostRootImage = prefabImage;
                _dragGhostImage = CreateChildIcon(_dragGhostRT, prefabImage);
                _dragGhostIconRect = _dragGhostImage.rectTransform;
                prefabImage.enabled = false;
                prefabImage.raycastTarget = false;
            }
            else
            {
                Debug.LogError("[DragGhostPresenter] DragGhost Prefab MISSING Image on root!");
                _dragGhost = null;
                return;
            }

            _dragGhostImage.raycastTarget = false;
            _dragGhostImage.color = Color.white;
            _dragGhostImage.enabled = true;

            _dragGhostCanvasGroup = _dragGhost.GetComponent<CanvasGroup>();
            if (_dragGhostCanvasGroup == null)
                _dragGhostCanvasGroup = _dragGhost.AddComponent<CanvasGroup>();
            _dragGhostCanvasGroup.blocksRaycasts = false;
            _dragGhostCanvasGroup.interactable = false;
            _dragGhostCanvasGroup.alpha = 1f;

            _dragGhostCanvas = _dragGhost.GetComponent<Canvas>();
            if (_dragGhostCanvas == null)
                _dragGhostCanvas = _dragGhost.AddComponent<Canvas>();
            _dragGhostCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            _dragGhostCanvas.overrideSorting = true;
            _dragGhostCanvas.sortingOrder = GHOST_SORTING_ORDER;

            var rootCanvasTransform = _ui?.RootCanvasTransform;
            if (rootCanvasTransform != null)
                _dragGhost.transform.SetParent(rootCanvasTransform, false);
            else
                _dragGhost.transform.SetParent(_ui != null ? _ui.transform.root : null, false);

            var ghostLabelObj = new GameObject("GhostName", typeof(RectTransform), typeof(TextMeshProUGUI));
            ghostLabelObj.transform.SetParent(_dragGhostRT, false);
            var ghostLabelRT = ghostLabelObj.GetComponent<RectTransform>();
            ghostLabelRT.anchorMin = new Vector2(0f, 0.5f);
            ghostLabelRT.anchorMax = new Vector2(1f, 0.5f);
            ghostLabelRT.pivot = new Vector2(0f, 1f);
            ghostLabelRT.anchoredPosition = new Vector2(2f, 0f);
            ghostLabelRT.sizeDelta = new Vector2(-4f, 12f);
            ghostLabelRT.localScale = Vector3.one;

            _dragGhostNameText = ghostLabelObj.GetComponent<TextMeshProUGUI>();
            _dragGhostNameText.fontSize = 10f;
            _dragGhostNameText.color = new Color(1f, 1f, 1f, 0.85f);
            _dragGhostNameText.alignment = TextAlignmentOptions.Left;
            _dragGhostNameText.verticalAlignment = VerticalAlignmentOptions.Top;
            _dragGhostNameText.raycastTarget = false;
            _dragGhostNameText.overflowMode = TextOverflowModes.Truncate;
            _dragGhostNameText.textWrappingMode = TextWrappingModes.NoWrap;
            _dragGhostNameText.fontStyle = FontStyles.Bold;
            var ghostShadow = ghostLabelObj.AddComponent<Shadow>();
            ghostShadow.effectColor = new Color(0f, 0f, 0f, 0.7f);
            ghostShadow.effectDistance = new Vector2(1f, -1f);

            var ghostCalObj = new GameObject("GhostCaliber", typeof(RectTransform), typeof(TextMeshProUGUI));
            ghostCalObj.transform.SetParent(_dragGhostRT, false);
            var ghostCalRT = ghostCalObj.GetComponent<RectTransform>();
            ghostCalRT.anchorMin = new Vector2(0f, 0f);
            ghostCalRT.anchorMax = new Vector2(1f, 0f);
            ghostCalRT.pivot = new Vector2(0f, 0f);
            ghostCalRT.anchoredPosition = new Vector2(2f, 2f);
            ghostCalRT.sizeDelta = new Vector2(-4f, 11f);
            ghostCalRT.localScale = Vector3.one;

            _dragGhostCaliberText = ghostCalObj.GetComponent<TextMeshProUGUI>();
            _dragGhostCaliberText.fontSize = 9f;
            _dragGhostCaliberText.color = new Color(1f, 1f, 1f, 0.6f);
            _dragGhostCaliberText.alignment = TextAlignmentOptions.Left;
            _dragGhostCaliberText.verticalAlignment = VerticalAlignmentOptions.Bottom;
            _dragGhostCaliberText.raycastTarget = false;
            _dragGhostCaliberText.overflowMode = TextOverflowModes.Truncate;
            _dragGhostCaliberText.textWrappingMode = TextWrappingModes.NoWrap;
            var ghostCalShadow = ghostCalObj.AddComponent<Shadow>();
            ghostCalShadow.effectColor = new Color(0f, 0f, 0f, 0.7f);
            ghostCalShadow.effectDistance = new Vector2(1f, -1f);
        }

        /// <summary>
        /// Замещает бывший K_InventoryUI.SetupDragOutline(item).
        /// Настраивает ghost под указанный предмет: иконка, размер, поворот.
        /// НЕ показывает ghost — показ активируется отдельно через SetActive(true)
        /// из TryStartDrag / StartDragFromEquipmentSlot.
        /// </summary>
        public void Begin(InventoryItem item)
        {
            if (_dragGhost == null || _dragGhostRT == null) return;

            var rootCanvasTransform = _ui?.RootCanvasTransform;
            if (rootCanvasTransform != null)
                _dragGhost.transform.SetParent(rootCanvasTransform, false);

            _dragGhostRT.anchorMin = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchorMax = new Vector2(0.5f, 0.5f);
            _dragGhostRT.pivot = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchoredPosition = Vector2.zero;
            _dragGhostRT.localScale = Vector3.one;
            _dragGhostRT.localRotation = Quaternion.identity;
            _dragGhostRT.SetAsLastSibling();

            if (_dragGhostRootImage != null)
            {
                _dragGhostRootImage.sprite = null;
                _dragGhostRootImage.type = Image.Type.Simple;
                _dragGhostRootImage.color = Color.clear;
                _dragGhostRootImage.enabled = false;
                _dragGhostRootImage.raycastTarget = false;
            }

            if (_dragGhostImage != null)
            {
                _dragGhostImage.enabled = true;
                _dragGhostImage.sprite = item.CurrentIcon; // ФИКС v2: CurrentIcon учитывает fold
                _dragGhostImage.preserveAspect = true;     // ФИКС БАГ #4: НЕ растягиваем иконку
            }

            if (_dragGhostNameText != null)
            {
                _dragGhostNameText.text = "";
                _dragGhostNameText.gameObject.SetActive(false);
            }

            if (_dragGhostCaliberText != null)
            {
                _dragGhostCaliberText.text = string.Empty;
                _dragGhostCaliberText.gameObject.SetActive(false);
            }

            UpdateGhostSize();
            UpdateGhostRotation();
        }

        /// <summary>
        /// Замещает бывший K_InventoryUI.UpdateDragGhostPosition(eventData).
        /// Двигает ghost за курсором и в конце обновляет подсветку ячеек.
        /// </summary>
        public void UpdatePosition(PointerEventData eventData)
        {
            if (!IsDraggingActive() || _dragGhost == null || !_dragGhost.activeSelf || _dragGhostRT == null) return;

            RectTransform canvasRT = _ui?.RootCanvasTransform as RectTransform;
            if (canvasRT == null) return;

            var rootCamera = _ui?.RootCanvasCamera;
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRT, eventData.position, rootCamera, out Vector2 localPoint))
                _dragGhostRT.anchoredPosition = localPoint;

            // ═══ АУДИТ-ФИКС (призрак 0.35): всегда держим dragged source
            // в alpha=0.35 во время drag. Раньше было условие `if (cg.alpha > 0.4f)`,
            // которое никогда не срабатывало, т.к. UI_Item.OnBeginDrag ставил
            // alpha=0f. Теперь оба компонента согласованно ставят 0.35f.
            // ═══
            var draggedItem = _ui?.DraggedUIItem;
            if (draggedItem != null)
            {
                var cg = draggedItem.GetComponent<CanvasGroup>();
                if (cg != null)
                {
                    cg.alpha = 0.35f;
                    cg.blocksRaycasts = false;
                }
            }

            _highlights?.UpdateCellHighlights();
        }

/// <summary>Screen-AABB тела ghost'а (клеточный футпринт тащимого предмета, без иконки).</summary>
public bool TryGetBodyScreenBounds(out Vector2 min, out Vector2 max)
{
    min = new Vector2(float.MaxValue, float.MaxValue);
    max = new Vector2(float.MinValue, float.MinValue);
    if (_dragGhost == null || _dragGhostRT == null || !_dragGhost.activeSelf) return false;
    Vector3[] corners = new Vector3[4];
    _dragGhostRT.GetWorldCorners(corners);
    UnityEngine.Camera cam = _ui != null ? _ui.RootCanvasCamera : null;
    for (int i = 0; i < 4; i++)
    {
        Vector2 sp = RectTransformUtility.WorldToScreenPoint(cam, corners[i]);
        min = Vector2.Min(min, sp);
        max = Vector2.Max(max, sp);
    }
    return max.x - min.x > 0f && max.y - min.y > 0f;
}
        /// <summary>
        /// Замещает бывший K_InventoryUI.RotateDraggedItem().
        ///
        /// Поворот во время drag — ВИЗУАЛЬНАЯ операция, фиксируемая
        /// транзакцией при drop. Мутация item.Rotate() остаётся здесь:
        /// она синхронна и не ломает граф вызовов.
        ///
        /// Защитная проверка адаптирована под транзакционную модель:
        /// предмет ОСТАЁТСЯ в данных контроллера (Фаза 2), поэтому
        /// проверка опирается на _isDragging и наличие тащимого источника.
        /// </summary>
        public void Rotate()
        {
            if (!_ui.IsDragging)
            {
                Debug.LogWarning("[DragGhostPresenter.Rotate] Rejected: drag session not active.");
                return;
            }

            var item = _ui?.DraggedUIItem?.Item ?? _ui?.DraggedFromSlotItem;
            if (item == null) return;

            // Для предметов из слота экипировки — _draggedFromEquipmentSlot != null.
            // Для предметов из сетки — всегда валидно в транзакционной модели
            // (предмет остаётся в данных). Старая проверка _dragItemRemoved
            // больше не применяется.
            if (!_ui.IsDraggingFromEquipmentSlot && !_ui.DragItemRemoved)
            {
                // В транзакционной модели предмет может оставаться в контроллере
                // во время drag — поворот всё равно разрешён, т.к. он визуальный
                // и будет зафиксирован при drop. Оставляем warning для диагностики
                // несинхронизированных состояний.
                Debug.LogWarning($"[DragGhostPresenter.Rotate] item '{item.Data?.DisplayName}' " +
                    "is still in source controller (dragItemRemoved=false). Visual rotation only — " +
                    "final state will be reconciled by the drop transaction.");
            }

            if (item.Data != null && !item.Data.CanRotate && !_ui.IsDraggingFromEquipmentSlot) return;

            int prevAngle = item.RotationAngle;
            Vector2Int prevSize = item.CurrentSize;

            // Прямое вращение без привязки к сетке.
            item.Rotate();

            Debug.Log($"[DragGhostPresenter.Rotate] '{item.Data?.DisplayName}': " +
                $"angle {prevAngle}→{item.RotationAngle}, " +
                $"size {prevSize.x}x{prevSize.y}→{item.CurrentSize.x}x{item.CurrentSize.y}");

            UpdateGhostSize();
            UpdateGhostRotation();
            // ФИКС: обновляем подсветку ячеек после смены размера.
            _highlights?.UpdateCellHighlights();
        }

        /// <summary>Замещает бывший K_InventoryUI.UpdateGhostSize().</summary>
        public void UpdateGhostSize()
        {
            if (_dragGhostRT == null) return;

            // БАГ #1 ФИКС: body и иконка используют РАЗНЫЕ размеры.
            //   - body: CurrentSize — учитывает поворот (становится (h,w) при rotation=90).
            //   - иконка: НОРМАЛЬНЫЙ размер (без поворота) — GetNormalIconSize.
            //     Если IconBaseRotation меняет оси (90°/270°), swap'аем normalSize
            //     при расчёте размера иконки — это компенсирует поворот body.
            Vector2Int currentSize;
            Vector2Int normalSize;

            var iconItem = _ui?.DraggedUIItem?.Item ?? _ui?.DraggedFromSlotItem;
            if (iconItem != null)
            {
                currentSize = iconItem.CurrentSize;
                normalSize = GetNormalIconSize(iconItem);
            }
            else
            {
                currentSize = new Vector2Int(1, 1);
                normalSize = new Vector2Int(1, 1);
            }

            float slotSize = _ui?.SlotSize ?? 70f;
            float slotSpacing = _ui?.SlotSpacing ?? 0f;

            float bodyW = currentSize.x * slotSize + (currentSize.x - 1) * slotSpacing;
            float bodyH = currentSize.y * slotSize + (currentSize.y - 1) * slotSpacing;
            _dragGhostRT.sizeDelta = new Vector2(bodyW, bodyH);

            if (_dragGhostIconRect == null) return;

            // Иконка ghost — размер по normalSize с swap для IconBaseRotation.
            float baseRot = iconItem?.IconBaseRotation ?? 0f;
            bool iconSwapsAxes = Mathf.Abs(baseRot % 180) > 0.01f;
            int iconWcells = iconSwapsAxes ? normalSize.y : normalSize.x;
            int iconHcells = iconSwapsAxes ? normalSize.x : normalSize.y;
            float iconW = iconWcells * slotSize + (iconWcells - 1) * slotSpacing;
            float iconH = iconHcells * slotSize + (iconHcells - 1) * slotSpacing;
            _dragGhostIconRect.sizeDelta = new Vector2(iconW, iconH);
        }

        /// <summary>Замещает бывший K_InventoryUI.UpdateGhostRotation().</summary>
        public void UpdateGhostRotation()
        {
            var item = _ui?.DraggedUIItem?.Item ?? _ui?.DraggedFromSlotItem;
            if (item == null || _dragGhostIconRect == null) return;

            _dragGhostRT.localRotation = Quaternion.identity;

            // Единая формула для ВСЕХ случаев:
            //   visualAngle = IconBaseRotation - RotationAngle
            float visualAngle = item.IconBaseRotation - item.RotationAngle;

            _dragGhostIconRect.localRotation = Quaternion.Euler(0, 0, visualAngle);
        }

        /// <summary>
        /// Замещает инлайн-блок из K_InventoryUI.Update() F-key path:
        ///   - _dragGhostImage.sprite = foldItem.CurrentIcon
        ///   - UpdateGhostSize()
        ///   - UpdateGhostRotation()
        ///   - UpdateDragCellHighlights() — подсветку дёргает вызывающий код
        ///     через _highlights.UpdateCellHighlights() после этого метода.
        /// </summary>
        public void RefreshGhostAfterFold(InventoryItem item)
        {
            if (_dragGhostImage != null && item != null)
                _dragGhostImage.sprite = item.CurrentIcon;
            UpdateGhostSize();
            UpdateGhostRotation();
        }

        /// <summary>Показать ghost-объект.</summary>
        public void Show()
        {
            if (_dragGhost != null)
                _dragGhost.SetActive(true);
        }

        /// <summary>Скрыть ghost-объект. Замещает _dragGhost.SetActive(false).</summary>
        public void End()
        {
            if (_dragGhost != null)
                _dragGhost.SetActive(false);
        }

        /// <summary>Уничтожить ghost-объект (вызывается из K_InventoryUI.OnDestroy).</summary>
        public void DestroyGhost()
        {
            if (_dragGhost != null)
            {
                Object.Destroy(_dragGhost);
                _dragGhost = null;
            }
        }

        // ═══════════════════════════════════════════════════════════
        //  ВНУТРЕННИЕ ХЕЛПЕРЫ
        // ═══════════════════════════════════════════════════════════

        private bool IsDraggingActive()
        {
            return _ui != null && _ui.IsDragging;
        }

        /// <summary>
        /// БАГ #1 ФИКС: Возвращает нормальный (не повернутый) размер иконки.
        /// Тот же алгоритм, что в UI_Item.GetNormalIconSize — вынесен сюда
        /// чтобы переиспользовать для drag ghost.
        /// </summary>
        private static Vector2Int GetNormalIconSize(InventoryItem item)
        {
            if (item?.Data == null) return new Vector2Int(1, 1);
            var data = item.Data;
            if (item.IsFolded && data.CanFold) return data.SizeFolded;
            if (data.IsBackpack && data.UnfoldedIconSize.x > 0 && data.UnfoldedIconSize.y > 0)
                return data.UnfoldedIconSize;
            if (data.IsBackpack && data.BackpackWidth > 0 && data.BackpackHeight > 0)
                return new Vector2Int(data.BackpackWidth, data.BackpackHeight);
            return data.Size;
        }

        /// <summary>Создаёт дочерний Image для иконки ghost. Перенесено из K_InventoryUI.CreateChildIcon.</summary>
        private Image CreateChildIcon(RectTransform parent, Image source)
        {
            var childObj = new GameObject("GhostIcon", typeof(RectTransform), typeof(Image));
            childObj.transform.SetParent(parent, false);

            var childRT = childObj.GetComponent<RectTransform>();
            childRT.anchorMin = new Vector2(0.5f, 0.5f);
            childRT.anchorMax = new Vector2(0.5f, 0.5f);
            childRT.pivot = new Vector2(0.5f, 0.5f);
            childRT.anchoredPosition = Vector2.zero;
            childRT.localScale = Vector3.one;
            childRT.localRotation = Quaternion.identity;

            var childImage = childObj.GetComponent<Image>();
            childImage.sprite = source.sprite;
            childImage.color = Color.white;
            childImage.type = source.type;
            childImage.preserveAspect = false;
            childImage.raycastTarget = false;
            childImage.enabled = true;

            return childImage;
        }
    }
}
