﻿using UnityEngine;
using K_Incident.Core.Inventory;
using System;

namespace K_Incident.Core
{
    public enum LootBoxType
    {
        Soft,
        Medium,
        Hard
    }

    /// <summary>
    /// ФИКС БАГ #8: BroadcastLootNoise теперь вызывает K_AcousticSystem.
    /// ФИКС БАГ #10: AudioSource кэшируется в Awake(), не ищется каждый раз.
    /// </summary>
    public class K_LootBox : MonoBehaviour, IInteractable
    {
        #region Inspector Fields

        [Header("Identification")]
        [SerializeField, Tooltip("Название контейнера для отображения в UI")]
        private string _containerName = "Контейнер";

        [SerializeField, Tooltip("Тип контейнера для акустической классификации")]
        private LootBoxType _boxType = LootBoxType.Medium;

        [Header("Grid Settings")]
        [SerializeField, Tooltip("Ширина сетки инвентаря контейнера")]
        private int _gridWidth = 6;

        [SerializeField, Tooltip("Высота сетки инвентаря контейнера")]
        private int _gridHeight = 6;

        [Header("Interaction Timing")]
        [SerializeField, Tooltip("Время удержания для вскрытия (первый раз)")]
        private float _initialLootTime = 0.6f;

        [SerializeField, Tooltip("Если включено - повторное открытие мгновенное")]
        private bool _instantReopen = true;

        [Header("Audio")]
        [SerializeField, Tooltip("Звук вскрытия контейнера")]
        private AudioClip _lootSound;

        [SerializeField, Range(0f, 1f), Tooltip("Громкость звука вскрытия")]
        private float _soundVolume = 1f;

        [Header("Inventory")]
        [SerializeField, Tooltip("Начальные данные инвентаря (опционально)")]
        private InventoryData _initialInventoryData;

        #endregion

        #region Constants

        private const float ZERO_DURATION = 0f;

        #endregion

        #region Fields

        private InventoryController _inventoryController;
        private bool _hasBeenLooted;
        private ItemDatabase _database;
        private bool _isInitialized;

        // ФИКС БАГ #8/10: Кэшированные ссылки
        private K_AcousticSystem _acousticSystem;
        private AudioSource _audioSource;

        #endregion

        #region Properties

        public string ContainerName => _containerName;
        public LootBoxType BoxType => _boxType;
        public int GridWidth => _gridWidth;
        public int GridHeight => _gridHeight;
        public InventoryController InventoryController => _inventoryController;
        public bool HasBeenLooted => _hasBeenLooted;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            ValidateGridSettings();

            // ФИКС БАГ #8: Кэшируем акустическую систему
            _acousticSystem = FindFirstObjectByType<K_AcousticSystem>();

            // ФИКС БАГ #10: Кэшируем AudioSource, создаём если нет
            _audioSource = GetComponent<AudioSource>();
            if (_audioSource == null && _lootSound != null)
                _audioSource = gameObject.AddComponent<AudioSource>();
        }

        private void Start()
        {
            Initialize();
        }

        private void OnDestroy()
        {
            Cleanup();
        }

        #endregion

        #region Initialization

        private void ValidateGridSettings()
        {
            _gridWidth = Mathf.Clamp(_gridWidth, 1, 20);
            _gridHeight = Mathf.Clamp(_gridHeight, 1, 20);
            _initialLootTime = Mathf.Max(ZERO_DURATION, _initialLootTime);
        }

        private void Initialize()
        {
            _database = K_InventorySetup.GetDatabase();
            if (_database == null)
            {
                Debug.LogError($"[LootBox] {_containerName}: ItemDatabase not initialized! Check K_InventorySetup in scene.");
                enabled = false;
                return;
            }

            // ФИКС БАГ #34: Всегда создаем НОВЫЙ экземпляр InventoryData, чтобы не мутировать ScriptableObject
            InventoryData data = new InventoryData(_gridWidth, _gridHeight);

            if (_initialInventoryData != null)
            {
                var savedItems = _initialInventoryData.GetItems();
                if (savedItems != null)
                {
                    foreach (var saved in savedItems)
                    {
                        // Копируем только те предметы, которые влезают в новые размеры сетки
                        if (saved.X < _gridWidth && saved.Y < _gridHeight)
                        {
                            data.AddItem(saved);
                        }
                    }
                }
                if (_initialInventoryData.Width != _gridWidth || _initialInventoryData.Height != _gridHeight)
                {
                    Debug.LogWarning($"[LootBox] {_containerName}: _initialInventoryData size mismatch. Auto-resizing.");
                }
            }

            string saveID = $"LootBox_{GetInstanceID()}";
            _inventoryController = new InventoryController(data, _database, saveID);
            _inventoryController.OnInventoryChanged += MarkAsModified;

            _isInitialized = true;
        }

        private void Cleanup()
        {
            if (_isInitialized && _inventoryController != null)
            {
                _inventoryController.OnInventoryChanged -= MarkAsModified;
                _inventoryController.Dispose();
                _inventoryController = null;
            }
            _database = null;
            _isInitialized = false;
        }

        #endregion

        #region IInteractable Implementation

        public string GetInteractionPrompt() => _hasBeenLooted ? "ОБЫСКАТЬ (повторно)" : "ОБЫСКАТЬ";

        public string GetHoldPrompt()
        {
            float duration = GetHoldDuration();
            return duration > ZERO_DURATION ? $"ОБЫСКАТЬ [{duration:F1}с]" : "ОБЫСКАТЬ";
        }

        public float GetHoldDuration() => (_hasBeenLooted && _instantReopen) ? ZERO_DURATION : _initialLootTime;

        public void OnInteract()
        {
            if (!_isInitialized || _inventoryController == null)
            {
                Debug.LogWarning($"[LootBox] {_containerName}: Not initialized!");
                return;
            }

            var inventoryUI = FindFirstObjectByType<K_InventoryUI>();
            if (inventoryUI == null)
            {
                Debug.LogError("[LootBox] K_InventoryUI not found in scene! Cannot interact with container.");
                return;
            }

            _hasBeenLooted = true;

            if (inventoryUI.IsLooting && inventoryUI.GetControllerForGrid(GridType.Container) == _inventoryController)
            {
                inventoryUI.CloseAll();
                return;
            }

            inventoryUI.OpenContainer(_inventoryController, _containerName, _gridWidth, _gridHeight);

            PlayLootSound();
            BroadcastLootNoise();
        }

        #endregion

        #region Loot Interface

        /// <summary>
        /// Использует K_AcousticSystem.BroadcastLooting() — новый API по ТЗ.
        /// Радиусы: Soft=1м, Medium=12м, Hard=20м (Аспект #2, #8).
        /// </summary>
        private void BroadcastLootNoise()
        {
            if (_acousticSystem != null)
            {
                _acousticSystem.BroadcastLooting(transform.position, _boxType, isIndoor: true, source: gameObject);
            }
            else
            {
                Debug.Log($"[LootBox] {_containerName}: Loot noise (Type: {_boxType}). AcousticSystem not found - noise not broadcast to AI.");
            }
        }

        /// <summary>
        /// ФИКС БАГ #10: Использует кэшированный AudioSource, не ищет каждый раз.
        /// </summary>
        private void PlayLootSound()
        {
            if (_lootSound == null || _audioSource == null) return;
            _audioSource.PlayOneShot(_lootSound, _soundVolume);
        }

        #endregion

        #region Dirty Flags

        private void MarkAsModified()
        {
            if (_inventoryController != null)
            {
                _inventoryController.GetSaveData().MarkDirty();
            }
        }

        #endregion

        #region Editor Helpers

#if UNITY_EDITOR
        [ContextMenu("Debug: Print Info")]
        private void DebugPrintInfo()
        {
            Debug.Log($"=== [LootBox] {_containerName} ===");
            Debug.Log($"Type: {_boxType} | Grid: {_gridWidth}x{_gridHeight}");
            Debug.Log($"Hold Time: {GetHoldDuration():F2}s | Acoustic Radius: {GetAcousticRadius()}m");
            Debug.Log($"Initialized: {_isInitialized} | Looted: {_hasBeenLooted}");
            Debug.Log($"InventoryController: {_inventoryController != null}");

            if (_inventoryController != null)
            {
                Debug.Log($"  SaveID: {_inventoryController.SaveID}");
                Debug.Log($"  Weight: {_inventoryController.CurrentWeightKg:F2}kg");
                Debug.Log($"  Items: {_inventoryController.GetItemCount()}");
            }

            string dbName = _database != null ? _database.name : "NULL";
            Debug.Log($"Database: {dbName}");
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = _hasBeenLooted ? Color.yellow : Color.cyan;
            Gizmos.DrawWireCube(transform.position, Vector3.one);
            Gizmos.DrawLine(transform.position, transform.position + Vector3.up * 2f);
        }

        private float GetAcousticRadius()
        {
            return _boxType switch
            {
                LootBoxType.Soft => 1f,
                LootBoxType.Medium => 12f,
                LootBoxType.Hard => 20f,
                _ => 12f
            };
        }
#endif

        #endregion
    }
}
