﻿
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Сериализуемые данные предмета для сохранения/загрузки.
    ///
    /// ФИКС v2: Добавлены:
    /// - IsFolded (поле было, но не сериализовалось в InventoryData.Save/Load — нужно добавить)
    /// - BackpackContents: List<SavedItem> — рекурсивное содержимое рюкзака.
    ///   null если предмет не рюкзак или рюкзак пустой.
    ///
    /// ФИКС БАГ (audit) #25 SavedItem: добавлен [Serializable] и DeepClone.
    /// Без [Serializable] BinaryFormatter/Unity-serialization молча теряют
    /// структуру, а shallow-копия struct с mutable List<SavedItem> расшаривает
    /// один и тот же список между всеми копиями, что приводит к перекрёстному
    /// изменению содержимого рюкзаков.
    /// </summary>
    [Serializable]
    public struct SavedItem
    {
        public string ItemID;
        public uint InstanceID;
        public int X, Y;
        public int Quantity;
        public int Durability;
        public bool IsRotated;
        public bool IsFolded;

        /// <summary>
        /// Содержимое рюкзака (рекурсивно).
        /// null для не-рюкзаков или пустых рюкзаков.
        /// ВАЖНО: SavedItem — struct, поэтому присваивание копирует список по ссылке
        /// (List — reference type). Используйте new List(...) при присваивании,
        /// чтобы избежать случайного расшаривания.
        ///
        /// ФИКС БАГ (audit #25 → user feedback):
        /// Поле помечено [NonSerialized], потому что:
        ///   1) Unity-сериализатор видит `List<SavedItem>` внутри `SavedItem`
        ///      как потенциальную бесконечную рекурсию (Serialization depth 10).
        ///      Warning засорял консоль и не давал редактировать InventoryData в инспекторе.
        ///   2) BackpackContents в любом случае сериализуется через BinaryWriter/Reader
        ///      в InventoryData.Save/Load (см. WriteSavedItemRecursive).
        ///      Unity-сериализация здесь не нужна.
        /// </summary>
        [NonSerialized]
        public List<SavedItem> BackpackContents;

        public SavedItem(string itemID, uint instanceID, int x, int y, int quantity, int durability, bool isRotated, bool isFolded = false)
        {
            ItemID = itemID;
            InstanceID = instanceID;
            X = x; Y = y;
            Quantity = quantity;
            Durability = durability;
            IsRotated = isRotated;
            IsFolded = isFolded;
            BackpackContents = null;
        }

        /// <summary>
        /// Проверяет валидность данных предмета.
        /// </summary>
        public bool IsValid()
        {
            if (string.IsNullOrEmpty(ItemID)) return false;
            if (InstanceID == 0) return false;
            if (X < 0 || Y < 0) return false;
            if (Quantity <= 0) return false;
            return true;
        }

        public override string ToString()
        {
            string contents = BackpackContents != null ? $", Contents={BackpackContents.Count}" : "";
            return $"SavedItem[{InstanceID}] {ItemID} @ ({X},{Y}) Qty:{Quantity} Rot:{IsRotated} Fold:{IsFolded}{contents}";
        }

        // ═══════════════════════════════════════════════════════════════
        //  ФИКС БАГ (audit) #25: DeepClone — глубокое копирование SavedItem
        //  с рекурсивным клонированием BackpackContents.
        //
        //  SavedItem — struct с mutable List<SavedItem> BackpackContents.
        //  Shallow-копия (просто присваивание struct) копирует ссылку на List,
        //  и две «копии» оказываются с одним и тем же списком содержимого.
        //  Это приводило к смешиванию содержимого разных рюкзаков в:
        //    - InventoryItem.FromSaveData → _backpackContentsSerialized
        //    - K_InventoryUI.SwapBackpackContents
        //    - Resize/serialization paths
        //
        //  Глубина рекурсии ограничена 32 — этого достаточно для любого
        //  реального инвентаря. При превышении кидается InvalidDataException,
        //  чтобы повреждённое сохранение не дошло до live-state.
        // ═══════════════════════════════════════════════════════════════
        private const int MAX_DEEP_CLONE_DEPTH = 32;

        public static SavedItem DeepClone(in SavedItem source) => DeepClone(source, depth: 0);

        private static SavedItem DeepClone(in SavedItem source, int depth)
        {
            if (depth > MAX_DEEP_CLONE_DEPTH)
                throw new InvalidDataException(
                    "SavedItem.DeepClone: backpack nesting is too deep " +
                    $"(>{MAX_DEEP_CLONE_DEPTH}). Save data is corrupted.");

            SavedItem copy = source; // struct copy — копирует value-поля

            if (source.BackpackContents == null)
            {
                copy.BackpackContents = null;
                return copy;
            }

            copy.BackpackContents = new List<SavedItem>(source.BackpackContents.Count);
            foreach (var child in source.BackpackContents)
                copy.BackpackContents.Add(DeepClone(child, depth + 1));

            return copy;
        }

        /// <summary>
        /// Возвращает true, если в дереве SavedItem встречается InstanceID
        /// с таким же значением как rootInstanceId (защита от циклов в сохранении).
        /// </summary>
        public static bool ContainsInstanceId(List<SavedItem> contents, uint targetInstanceId, int depth = 0)
        {
            if (contents == null || contents.Count == 0) return false;
            if (depth > MAX_DEEP_CLONE_DEPTH) return true; // считаем цикл как «содержит» — fail-closed

            foreach (var child in contents)
            {
                if (child.InstanceID == targetInstanceId) return true;
                if (child.BackpackContents != null && child.BackpackContents.Count > 0)
                    if (ContainsInstanceId(child.BackpackContents, targetInstanceId, depth + 1))
                        return true;
            }
            return false;
        }
    }
}
