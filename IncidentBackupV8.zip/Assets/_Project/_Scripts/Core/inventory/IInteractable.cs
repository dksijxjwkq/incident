// === Source: original file lines 434-440 ===
using K_Incident.Core.Inventory;
using System.Collections;
using TMPro;
using UnityEngine;

namespace K_Incident.Core
{
    public interface IInteractable
    {
        void OnInteract();
        string GetInteractionPrompt();
        string GetHoldPrompt();
        float GetHoldDuration();
    }
}
