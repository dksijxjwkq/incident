using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// AABB фактически отрисованной области иконки (preserveAspect-aware).
    /// Rect ячейки шире картинки; «визуальное пересечение» считается
    /// только по отрисованной области, иначе обводка появляется,
    /// когда картинки ещё не касаются.
    /// </summary>
    public static class VisualRectUtility
    {
        public static bool TryGetVisualBounds(
            RectTransform iconRect,
            Image iconImage,
            UnityEngine.Camera camera,
            out Vector2 min,
            out Vector2 max)
        {
            min = new Vector2(float.MaxValue, float.MaxValue);
            max = new Vector2(float.MinValue, float.MinValue);
            if (iconRect == null) return false;

            Rect r = iconRect.rect;
            float w = r.width;
            float h = r.height;
            if (w <= 0f || h <= 0f) return false;

            float drawnW = w;
            float drawnH = h;
            if (iconImage != null && iconImage.preserveAspect && iconImage.sprite != null)
            {
                Vector2 native = iconImage.sprite.rect.size;
                if (native.x > 0f && native.y > 0f)
                {
                    float aspect = native.x / native.y;
                    if (w / h > aspect) { drawnH = h; drawnW = h * aspect; }
                    else { drawnW = w; drawnH = w / aspect; }
                }
            }

            Vector2 c = r.center;
            float hx = drawnW * 0.5f;
            float hy = drawnH * 0.5f;

            Expand(iconRect.TransformPoint(new Vector3(c.x - hx, c.y - hy, 0f)), camera, ref min, ref max);
            Expand(iconRect.TransformPoint(new Vector3(c.x + hx, c.y - hy, 0f)), camera, ref min, ref max);
            Expand(iconRect.TransformPoint(new Vector3(c.x + hx, c.y + hy, 0f)), camera, ref min, ref max);
            Expand(iconRect.TransformPoint(new Vector3(c.x - hx, c.y + hy, 0f)), camera, ref min, ref max);
            return true;
        }

        /// <summary>Пересечение двух screen-AABB с защитой от субпиксельного шума.</summary>
        public static bool Intersects(Vector2 aMin, Vector2 aMax, Vector2 bMin, Vector2 bMax, float epsilon = 1f)
        {
            float ix = Mathf.Min(aMax.x, bMax.x) - Mathf.Max(aMin.x, bMin.x);
            float iy = Mathf.Min(aMax.y, bMax.y) - Mathf.Max(aMin.y, bMin.y);
            return ix > epsilon && iy > epsilon;
        }

        private static void Expand(Vector3 world, UnityEngine.Camera camera, ref Vector2 min, ref Vector2 max)
        {
            Vector2 sp = RectTransformUtility.WorldToScreenPoint(camera, world);
            if (sp.x < min.x) min.x = sp.x;
            if (sp.y < min.y) min.y = sp.y;
            if (sp.x > max.x) max.x = sp.x;
            if (sp.y > max.y) max.y = sp.y;
        }
    }
}