﻿
﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Делает UI-панель перетаскиваемой по экрану.
    /// Прикрепляется к _surroundingsPanel (панель контейнера рюкзака) чтобы
    /// пользователь мог перемещать сетку рюкзака мышью.
    ///
    /// Z-ORDER ПЕРЕКЛЮЧЕНИЕ ОТКЛЮЧЕНО (баг-фикс):
    /// Окна больше не прыгают наверх при клике. Все окна всегда
    /// интерактивны одновременно. BringToFront() — no-op.
    ///
    /// БАГ #5 (предметы пропадают при перетаскивании окна):
    /// OnPointerDown НЕ начинает drag панели, если клик попал на
    /// UI_Item (перетаскиваемый предмет внутри сетки).
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    [ExecuteAlways]
    public class K_DraggablePanel : MonoBehaviour, IPointerDownHandler, IDragHandler, IEndDragHandler
    {
        #region Inspector Fields

        [Tooltip("Если true — клик в любом месте панели начинает перетаскивание " +
                 "(кроме слотов, предметов, кнопок). Если false — только на " +
                 "дочернем объекте DragZone/Header/Title.")]
        [SerializeField] private bool _dragFromAnywhere = true;

        [Header("Drag Zone (Header)")]
        [Tooltip("Префаб заголовка панели (DragZone). Если задан — инстанцируется " +
                 "при Awake и используется как зона перетаскивания. Если null — " +
                 "генерируется программно с параметрами ниже.")]
        [SerializeField] private GameObject _headerPrefab;

        [Tooltip("Высота заголовка в пикселях. Используется ТОЛЬКО при программной " +
                 "генерации (когда _headerPrefab не задан).")]
        [SerializeField] private float _headerHeight = 32f;

        [Tooltip("Цвет фона заголовка. Используется ТОЛЬКО при программной генерации.")]
        [SerializeField] private Color _headerColor = new Color(0.12f, 0.13f, 0.15f, 0.95f);

        [Tooltip("Если true — заголовок создаётся автоматически при Awake. " +
                 "Если false — заголовок должен быть создан вручную (или уже быть " +
                 "дочерним объектом панели).")]
        [SerializeField] private bool _autoCreateHeader = true;

        [Header("Window Focus (z-order)")]
        [Tooltip("ОТКЛЮЧЕНО. Z-order переключение убрано — окна не прыгают наверх при клике.")]
        [SerializeField] private bool _bringToFrontOnPointerDown = false;

        #endregion

        #region Fields

        private RectTransform _panelRect;
        private Canvas _canvas;
        private RectTransform _canvasRect;
        private Vector2 _dragOffset;
        private bool _isDragging;
        private RectTransform _dragZone;
        private Vector2 _lastPointerPosition;
        private bool _headerCreatedInternally;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _panelRect = GetComponent<RectTransform>();
            _canvas = GetComponentInParent<Canvas>();
            if (_canvas != null)
                _canvasRect = _canvas.transform as RectTransform;

            FindDragZoneInternal();

            if (_dragZone == null && _autoCreateHeader)
                CreateHeader();
        }

        // ФИКС БАГ #45: Удалён пустой метод OnEnable (мёртвый код)

        #endregion

        #region Public API

        public void FindDragZone()
        {
            FindDragZoneInternal();
        }

        public void SetDragZone(RectTransform zone)
        {
            _dragZone = zone;
        }

        public void CreateHeader()
        {
            if (_dragZone != null) return;
            if (_headerPrefab != null)
                CreateHeaderFromPrefab();
            else
                CreateHeaderProgrammatic();
        }

       

        public bool IsDragging => _isDragging;

        #endregion

        #region Header Creation

        private void FindDragZoneInternal()
        {
            _dragZone = null;
            string[] zoneNames = { "DragZone", "Header", "Title", "ContainerName", "TitleBar", "TopBar" };
            foreach (var name in zoneNames)
            {
                var t = transform.Find(name);
                if (t != null)
                {
                    _dragZone = t as RectTransform;
                    break;
                }
            }
        }

        private void CreateHeaderFromPrefab()
        {
            var headerObj = Instantiate(_headerPrefab, transform, false);
            headerObj.name = "DragZone";
            headerObj.transform.SetAsFirstSibling();

            var headerRT = headerObj.GetComponent<RectTransform>();
            if (headerRT != null)
            {
                _dragZone = headerRT;
                _headerCreatedInternally = true;
            }
            else
            {
                Debug.LogWarning($"[K_DraggablePanel] Header prefab '{_headerPrefab.name}' has no RectTransform — falling back to programmatic header.");
                Destroy(headerObj);
                CreateHeaderProgrammatic();
            }
        }

        private void CreateHeaderProgrammatic()
        {
            var dragZoneObj = new GameObject("DragZone", typeof(RectTransform), typeof(Image));
            dragZoneObj.transform.SetParent(transform, false);
            dragZoneObj.transform.SetAsFirstSibling();

            var dragZoneLayout = dragZoneObj.AddComponent<LayoutElement>();
            dragZoneLayout.ignoreLayout = true;
            dragZoneLayout.minHeight = 0;
            dragZoneLayout.preferredHeight = _headerHeight;

            var dragZoneRT = dragZoneObj.GetComponent<RectTransform>();
            dragZoneRT.anchorMin = new Vector2(0f, 1f);
            dragZoneRT.anchorMax = new Vector2(1f, 1f);
            dragZoneRT.pivot = new Vector2(0.5f, 1f);
            dragZoneRT.anchoredPosition = Vector2.zero;
            dragZoneRT.sizeDelta = new Vector2(0f, _headerHeight);
            dragZoneRT.localScale = Vector3.one;

            var dragZoneImage = dragZoneObj.GetComponent<Image>();
            dragZoneImage.color = _headerColor;
            dragZoneImage.raycastTarget = true;

            _dragZone = dragZoneRT;
            _headerCreatedInternally = true;
        }

        #endregion

        #region Drag Handlers

 public void OnPointerDown(PointerEventData eventData)
{
    if (IsClickOnInteractiveElement(eventData))
        return;

    if (_dragFromAnywhere)
    {
        StartDrag(eventData);
        return;
    }

    if (_dragZone != null)
    {
        var target = eventData.pointerCurrentRaycast.gameObject;

        if (target != null &&
            (target.transform == _dragZone || target.transform.IsChildOf(_dragZone)))
        {
            if (target.GetComponentInParent<Button>() == null)
                StartDrag(eventData);
        }

        return;
    }

    var raycastTarget = eventData.pointerCurrentRaycast.gameObject;
    if (raycastTarget == null)
        return;

    if (raycastTarget == gameObject ||
        raycastTarget.transform.IsChildOf(transform))
    {
        StartDrag(eventData);
    }
}
        private bool IsClickOnInteractiveElement(PointerEventData eventData)
        {
            var target = eventData.pointerCurrentRaycast.gameObject;
            if (target == null) return false;
            if (!target.transform.IsChildOf(transform)) return false;

            var interactive = target.GetComponentInParent<Selectable>();
            if (interactive != null) return true;

            var slotUI = target.GetComponentInParent<K_InventorySlotUI>();
            if (slotUI != null) return true;

            var uiItem = target.GetComponentInParent<UI_Item>();
            if (uiItem != null) return true;

            // ФИКС БАГ #12: Слоты экипировки не должны начинать drag панели
            var equipSlot = target.GetComponentInParent<K_EquipmentSlotUI>();
            if (equipSlot != null) return true;

            return false;
        }

        private void StartDrag(PointerEventData eventData)
        {
            if (_panelRect == null || _canvasRect == null) return;

            _isDragging = true;
            _lastPointerPosition = eventData.position;

            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _canvasRect, eventData.position, eventData.pressEventCamera, out var pointerLocal);

            _dragOffset = _panelRect.anchoredPosition - pointerLocal;
            // Z-order переключение отключено — SetAsLastSibling убран.
            NotifyInventoryUI(true);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!_isDragging || _panelRect == null || _canvasRect == null) return;

            Vector2 currentPointerLocal;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                _canvasRect, eventData.position, eventData.pressEventCamera, out currentPointerLocal))
                return;

            Vector2 newPos = currentPointerLocal + _dragOffset;
            ClampPositionToCanvas(ref newPos);
            _panelRect.anchoredPosition = newPos;
            _lastPointerPosition = eventData.position;
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (!_isDragging) return;
            _isDragging = false;
            NotifyInventoryUI(false);
        }

        private void NotifyInventoryUI(bool dragStarted)
        {
            var inventoryUI = GetComponentInParent<K_InventoryUI>();
            if (inventoryUI == null) return;

            if (dragStarted)
                inventoryUI.NotifyPanelDragStarted();
            else
                inventoryUI.NotifyPanelDragEnded();
        }

        #endregion

        #region Canvas Clamping

        private void ClampPositionToCanvas(ref Vector2 pos)
        {
            if (_canvasRect == null) return;

            Vector2 canvasSize = _canvasRect.rect.size;
            Vector2 panelSize = _panelRect.rect.size;
            Vector2 pivot = _panelRect.pivot;

            // ФИКС БАГ #13: Корректный расчет границ с учетом любого pivot (включая top-left 0,1)
            // Левая граница: -половина канваса + смещение пивота
            float minX = -canvasSize.x * 0.5f + (pivot.x * panelSize.x);
            // Правая граница: +половина канваса - то, что осталось от пивота
            float maxX = canvasSize.x * 0.5f - ((1f - pivot.x) * panelSize.x);

            float minY = -canvasSize.y * 0.5f + (pivot.y * panelSize.y);
            float maxY = canvasSize.y * 0.5f - ((1f - pivot.y) * panelSize.y);

            pos.x = Mathf.Clamp(pos.x, minX, maxX);
            pos.y = Mathf.Clamp(pos.y, minY, maxY);
        }

        #endregion
    }
}

