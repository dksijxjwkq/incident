using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Маркер-точка для коннекторов <see cref="K_UIConnector"/>.
    /// Не содержит игровой логики — нужен только для визуализации в Scene view
    /// и удобства выделения маркеров (Point_TL / Point_TR / Point_BL / Point_BR).
    ///
    /// Если вешать не хочется — можно не вешать: K_UIConnector работает
    /// с любыми RectTransform-маркерами.
    /// </summary>
    [AddComponentMenu("UI/K_UIConnectorPoint")]
    [DisallowMultipleComponent]
    public class K_UIConnectorPoint : MonoBehaviour
    {
#if UNITY_EDITOR
        [SerializeField] private Color _gizmoColor = new Color(1f, 0.6f, 0f, 1f);
        [SerializeField] private float _gizmoRadius = 4f;

        private void OnDrawGizmos()
        {
            Gizmos.color = _gizmoColor;
            Gizmos.DrawWireSphere(transform.position, _gizmoRadius);
            Gizmos.DrawSphere(transform.position, _gizmoRadius * 0.5f);
        }

        private void OnDrawGizmosSelected()
        {
            Gizmos.color = new Color(_gizmoColor.r, _gizmoColor.g, _gizmoColor.b, 1f);
            Gizmos.DrawWireSphere(transform.position, _gizmoRadius * 1.5f);
        }
#endif
    }
}