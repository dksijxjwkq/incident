﻿
using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public static class GlobalIDManager
    {
        private static uint _nextID = 1;
        private static readonly object _lock = new object();
        private static bool _isInitialized = false;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        private static void OnDomainReload()
        {
            lock (_lock)
            {
                _nextID = 1;
                _isInitialized = false;
            }
        }

        public static uint GenerateID()
        {
            lock (_lock)
            {
                if (!_isInitialized)
                {
                    _nextID = 1;
                    _isInitialized = true;
                }

                // ФИКС БАГ #23 (audit): uint.MaxValue тоже невалиден —
                // мы резервируем его как «no-id» sentinel. Кроме того,
                // переход через uint.MaxValue + 1 → 0 молча ломал бы
                // все новые предметы. Явно кидаем исключение.
                if (_nextID == 0 || _nextID == uint.MaxValue)
                    throw new OverflowException(
                        "GlobalIDManager: Instance ID space exhausted.");

                return _nextID++;
            }
        }

        /// <summary>
        /// ФИКС БАГ #23 (audit): Замена старого InitWithMaxId.
        /// Использует checked-арифметику, чтобы переполнение uint.MaxValue
        /// не превращалось молча в 0. Отбрасывает 0 и uint.MaxValue
        /// как невалидные известные ID.
        /// </summary>
        public static void ObserveID(uint knownId)
        {
            lock (_lock)
            {
                if (knownId == 0 || knownId == uint.MaxValue)
                    throw new InvalidDataException(
                        $"GlobalIDManager: invalid or exhausted ID: {knownId}");

                // checked: если knownId == uint.MaxValue — OverflowException
                uint candidate = checked(knownId + 1);

                if (!_isInitialized || candidate > _nextID)
                    _nextID = candidate;

                _isInitialized = true;
            }
        }

        /// <summary>
        /// Совместимость со старым API. Делегирует в ObserveID.
        /// </summary>
        public static void InitWithMaxId(uint maxKnownId) => ObserveID(maxKnownId);

        public static void Reset()
        {
            lock (_lock)
            {
                _nextID = 1;
                _isInitialized = false;
            }
        }
    }
}
