﻿using K_Incident.Core.Inventory;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
public class InventoryTransactionService : MonoBehaviour
{
    // ═══ Singleton ═══
    private static InventoryTransactionService _instance;
    public static InventoryTransactionService Instance
    {
        get
        {
            if (_instance != null) return _instance;
            _instance = FindFirstObjectByType<InventoryTransactionService>();
            if (_instance == null)
            {
                var go = new GameObject(nameof(InventoryTransactionService));
                _instance = go.AddComponent<InventoryTransactionService>();
            }
            return _instance;
        }
    }

    private void Awake()
    {
        if (_instance != null && _instance != this) { Destroy(gameObject); return; }
        _instance = this;
    }

    private void OnDestroy()
    {
        if (_instance == this) _instance = null;
    }

    [Header("References (auto-found if empty)")]
    [SerializeField] private K_InventoryUI _inventoryUI;
    private readonly List<K_EquipmentSlotUI> _cachedSlots = new(8);
    private bool _slotsCached;

    private bool _isTransactionActive;
    private readonly List<ItemSnapshot> _snapshots = new(4);
    private readonly List<PlacementRecord> _placements = new(4);
    private readonly Dictionary<uint, InventoryItem> _inHandItems = new(4);
    private readonly List<InventoryController> _relocBuffer = new List<InventoryController>(8);
    private struct PlacementRecord
    {
        public readonly InventoryItem Item;
        public readonly InventoryController Controller;
        public readonly int X;
        public readonly int Y;
        public readonly K_EquipmentSlotUI Slot;
        public readonly bool InSlot;

        public PlacementRecord(InventoryItem item, InventoryController controller, int x, int y)
        { Item = item; Controller = controller; X = x; Y = y; Slot = null; InSlot = false; }

        public PlacementRecord(InventoryItem item, K_EquipmentSlotUI slot)
        { Item = item; Controller = null; X = 0; Y = 0; Slot = slot; InSlot = true; }
    }

    public bool IsTransactionActive => _isTransactionActive;

    // ═══════════════════════════════════════════════════════════════
    //  SWAP
    // ═══════════════════════════════════════════════════════════════
// ============================================================
//  TrySwapItems – исправленный (удалён CloseDraggedBackpackWindowIfCrossController)
// ============================================================
// ============================================================
//  TrySwapItems – anchor единственная позиция swap'а (R5-guard).
// ============================================================
public bool TrySwapItems(UI_Item draggedUI, UI_Item targetUI, int anchorX, int anchorY, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || targetUI == null) { errorMessage = "Null UI references"; return false; }
    var itemA = draggedUI.Item;
    if (itemA == null) { errorMessage = "Invalid items"; return false; }
    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }
    var ctrlA = GetControllerForUI(draggedUI);
    var ctrlB = GetControllerForUI(targetUI);
    if (ctrlA == null || ctrlB == null) { errorMessage = "No controller for source or target"; return false; }
    var (ax, ay) = FindItemPositionInController(ctrlA, itemA);
    if (ax == -1) { errorMessage = "Item A not found in ctrlA (UI_Item desync)"; return false; }

    // ═══ Реальный футпринт itemA в ctrlA до любых мутаций. ═══
    RectInt realFootprintA = ctrlA.GetActualFootprint(itemA);
    if (realFootprintA.width <= 0 || realFootprintA.height <= 0)
    {
        errorMessage = "Item A has no footprint in ctrlA (data corruption)";
        return false;
    }

#if UNITY_EDITOR
    Debug.Log($"[SWAP-AUDIT] ENTER: dragged id={itemA.InstanceID} rot={itemA.RotationAngle} " +
              $"size={itemA.CurrentSize} gridFootprint=({realFootprintA.x},{realFootprintA.y}," +
              $"{realFootprintA.width},{realFootprintA.height}) " +
              $"target id={targetUI.Item.InstanceID} rot={targetUI.Item.RotationAngle} " +
              $"size={targetUI.Item.CurrentSize} sourceCtrl={ctrlA.SaveID} targetCtrl={ctrlB.SaveID} " +
              $"sourceRoot=({ax},{ay}) anchor=({anchorX},{anchorY})");

    // ═══ PRE-AUDIT: оккупанты freed-footprint ═══
    {
        var sb = new System.Text.StringBuilder(256);
        sb.Append("[SWAP-AUDIT] pre: dragged.rot=").Append(itemA.RotationAngle)
          .Append(" size=").Append(itemA.CurrentSize)
          .Append(" | target.rot=").Append(targetUI.Item.RotationAngle)
          .Append(" size=").Append(targetUI.Item.CurrentSize)
          .Append(" | freedFootprint=(").Append(realFootprintA.x).Append(',')
          .Append(realFootprintA.y).Append(',')
          .Append(realFootprintA.width).Append(',').Append(realFootprintA.height).Append(") ");
        sb.Append("occupants=[");
        for (int dy = 0; dy < realFootprintA.height; dy++)
        for (int dx = 0; dx < realFootprintA.width; dx++)
        {
            var occ = ctrlA.GetItemAt(realFootprintA.x + dx, realFootprintA.y + dy);
            sb.Append('(').Append(realFootprintA.x + dx).Append(',')
              .Append(realFootprintA.y + dy).Append(")=")
              .Append(occ != null ? occ.InstanceID.ToString() : "null").Append(' ');
        }
        sb.Append(']');
        Debug.Log(sb.ToString());
    }
#endif

    _inventoryUI.SyncBackpackForValidation(itemA);
    _inventoryUI.SyncBackpackForValidation(targetUI.Item);

    if (itemA.Data != null && itemA.Data.IsBackpack)
    {
        if (WouldCauseBackpackCycle(ctrlB, itemA, out string cycleReason))
        {
            errorMessage = cycleReason;
            return false;
        }
    }

    if (!InventoryOperationValidator.TryResolveSwapPositions(
        itemA, targetUI.Item, ctrlB, ctrlA, ax, ay,
        BuildRelocationControllers(ctrlB),
        anchorX, anchorY,
        out int bx, out int by, out int draggedRotation, out errorMessage,
        out int targetPlaceX, out int targetPlaceY, out int targetRotation,
        _inventoryUI.BackpackManager))
    {
        // Валидатор отказал ДО BeginTransaction — мутаций не было, но R-press
        // в процессе drag мог изменить itemA.RotationAngle, оставив физический
        // footprint в ctrl старым. Приводим угол в соответствие.
        ReconcileDraggedRotation(itemA, ctrlA);
        return false;
    }

   

#if UNITY_EDITOR
    Debug.Log($"[SWAP-AUDIT] validator: swap=({bx},{by}) draggedRotation={draggedRotation} " +
              $"targetPlace=({targetPlaceX},{targetPlaceY}) targetRotation={targetRotation}");
#endif

    var tRoot = ctrlB.FindItemRootPosition(targetUI.Item.InstanceID);
    if (tRoot.x == -1) { errorMessage = "Target not found in ctrlB"; return false; }

    var dSize = itemA.CurrentSize;
    var tSize = targetUI.Item.CurrentSize;
    bool isCaseB = (dSize.x * dSize.y) < (tSize.x * tSize.y);

    BeginTransaction();
    try
    {
        // ═══ CASE B ═══ (не использует freedFootprint)
        if (isCaseB)
        {
            _snapshots.Add(ItemSnapshot.FromGrid(itemA, draggedUI.GridType, ax, ay, GetContainerOwnerId(draggedUI)));
            _snapshots.Add(ItemSnapshot.FromGrid(targetUI.Item, targetUI.GridType, tRoot.x, tRoot.y, GetContainerOwnerId(targetUI)));

            if (!ctrlA.RemoveItem(itemA))
            { errorMessage = "Failed to remove item A from source controller"; Rollback(); return false; }
            _inHandItems[itemA.InstanceID] = itemA;

            if (!ctrlB.RemoveItem(targetUI.Item))
            { errorMessage = "Failed to remove primary target"; Rollback(); return false; }
            _inHandItems[targetUI.Item.InstanceID] = targetUI.Item;

            if (draggedRotation != itemA.RotationAngle)
                itemA.Rotate();

            if (!InventoryValidationService.GridSpaceCheck(ctrlB, itemA, bx, by)
                || !ctrlB.PlaceExistingItem(itemA, bx, by))
            {
                errorMessage = $"Item A: cannot place at validated swap position ({bx},{by})";
                Rollback(); return false;
            }
            _placements.Add(new PlacementRecord(itemA, ctrlB, bx, by));
            _inHandItems.Remove(itemA.InstanceID);

            targetUI.Item.RestoreRotationState(targetRotation);
            if (!InventoryValidationService.GridSpaceCheck(ctrlA, targetUI.Item, targetPlaceX, targetPlaceY)
                || !ctrlA.PlaceExistingItem(targetUI.Item, targetPlaceX, targetPlaceY))
            {
                errorMessage = $"Primary target: cannot place at validated position ({targetPlaceX},{targetPlaceY})";
                Rollback(); return false;
            }
            _placements.Add(new PlacementRecord(targetUI.Item, ctrlA, targetPlaceX, targetPlaceY));
            _inHandItems.Remove(targetUI.Item.InstanceID);

            if (!ValidateSwapFinalGeometry(ctrlA, ctrlB))
            { errorMessage = "Final geometry validation failed (bounds/overlap)"; Rollback(); return false; }

            Commit();
            AssertGridIntegrity(ctrlA, ctrlB);
            Debug.Log($"[Swap-B] committed: '{itemA.Data?.DisplayName}' -> ({bx},{by}) rot={itemA.RotationAngle}; " +
                      $"'{targetUI.Item.Data?.DisplayName}' -> ({targetPlaceX},{targetPlaceY}) rot={targetRotation}");
            return true;
        }

        // ═══ CASE A ═══
        Vector2Int effectiveASize = itemA.CurrentSize;
        if (draggedRotation != itemA.RotationAngle)
            effectiveASize = new Vector2Int(effectiveASize.y, effectiveASize.x);
        var t = targetUI.Item.CurrentSize;
        var targets = new HashSet<InventoryItem>(4);
        for (int dy = 0; dy < effectiveASize.y; dy++)
            for (int dx = 0; dx < effectiveASize.x; dx++)
            {
                var occ = ctrlB.GetItemAt(bx + dx, by + dy);
                if (occ != null && !ReferenceEquals(occ, itemA) && !ReferenceEquals(occ, targetUI.Item))
                    targets.Add(occ);
            }
        for (int dy = 0; dy < t.y; dy++)
            for (int dx = 0; dx < t.x; dx++)
            {
                var occ = ctrlB.GetItemAt(tRoot.x + dx, tRoot.y + dy);
                if (occ != null && !ReferenceEquals(occ, itemA) && !ReferenceEquals(occ, targetUI.Item))
                    targets.Add(occ);
            }

        _snapshots.Add(ItemSnapshot.FromGrid(itemA, draggedUI.GridType, ax, ay, GetContainerOwnerId(draggedUI)));
        _snapshots.Add(ItemSnapshot.FromGrid(targetUI.Item, targetUI.GridType, tRoot.x, tRoot.y, GetContainerOwnerId(targetUI)));
        foreach (var tItem in targets)
        {
            var (tx, ty) = FindItemPositionInController(ctrlB, tItem);
            if (tx == -1) { errorMessage = "Target item not found in ctrlB"; Rollback(); return false; }
            _snapshots.Add(ItemSnapshot.FromGrid(tItem, targetUI.GridType, tx, ty, GetContainerOwnerId(targetUI)));
        }

#if UNITY_EDITOR
        Debug.Log($"[SWAP-AUDIT] place: item id={itemA.InstanceID} size={effectiveASize} " +
                  $"into ({bx},{by}) [dragged; rot->{draggedRotation}]");
        Debug.Log($"[SWAP-AUDIT] freedFootprint=({realFootprintA.x},{realFootprintA.y}," +
                  $"{realFootprintA.width},{realFootprintA.height}) targets={targets.Count}");
#endif

        if (!ctrlA.RemoveItem(itemA))
        { errorMessage = "Failed to remove item A from source controller"; Rollback(); return false; }
        _inHandItems[itemA.InstanceID] = itemA;

        if (!ctrlB.RemoveItem(targetUI.Item))
        { errorMessage = "Failed to remove primary target"; Rollback(); return false; }
        _inHandItems[targetUI.Item.InstanceID] = targetUI.Item;

        foreach (var tItem in targets)
        {
            if (!ctrlB.RemoveItem(tItem))
            { errorMessage = "Failed to remove target item"; Rollback(); return false; }
            _inHandItems[tItem.InstanceID] = tItem;
        }

        if (draggedRotation != itemA.RotationAngle)
            itemA.Rotate();

        if (!InventoryValidationService.GridSpaceCheck(ctrlB, itemA, bx, by)
            || !ctrlB.PlaceExistingItem(itemA, bx, by))
        {
            errorMessage = $"Item A: cannot place at validated swap position ({bx},{by})";
            Rollback(); return false;
        }
        _placements.Add(new PlacementRecord(itemA, ctrlB, bx, by));
        _inHandItems.Remove(itemA.InstanceID);

        // ═══ freedFootprint = РЕАЛЬНЫЙ футпринт itemA до удаления. ═══
        RectInt freedFootprint = realFootprintA;

        if (!TryPlaceTargetStrict(ctrlA, targetUI.Item, ax, ay, freedFootprint))
        { errorMessage = "Primary target does not fit in freed footprint (strict swap)"; Rollback(); return false; }
        foreach (var tItem in targets)
        {
            if (!TryPlaceTargetStrict(ctrlA, tItem, ax, ay, freedFootprint))
            { errorMessage = "Target does not fit in freed footprint (strict swap)"; Rollback(); return false; }
        }

        if (!ValidateSwapFinalGeometry(ctrlA, ctrlB))
        { errorMessage = "Final geometry validation failed (bounds/overlap)"; Rollback(); return false; }

        Commit();
        AssertGridIntegrity(ctrlA, ctrlB);
        Debug.Log($"[Swap] committed: '{itemA.Data?.DisplayName}' -> ({bx},{by}) rot={itemA.RotationAngle}; " +
                  $"'{targetUI.Item.Data?.DisplayName}' -> origin ({ax},{ay}); thirdParty={targets.Count}");
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}
private static void ReconcileDraggedRotation(InventoryItem item, InventoryController ctrl)
{
    if (item == null || ctrl == null) return;
    if (ctrl.IsDisposed) return;

    RectInt fp = ctrl.GetActualFootprint(item);
    if (fp.width <= 0 || fp.height <= 0) return;

    var cs = item.CurrentSize;
    if (cs.x == fp.width && cs.y == fp.height) return;

    if (item.Data != null && item.Data.CanRotate && cs.x != cs.y)
    {
        item.Rotate();
        var after = item.CurrentSize;
        if (after.x != fp.width || after.y != fp.height)
        {
            Debug.LogWarning(
                $"[Swap-Reject] Could not reconcile rotation of item {item.InstanceID} " +
                $"('{item.Data?.DisplayName}'): footprint=({fp.width}x{fp.height}) " +
                $"afterRotate=({after.x}x{after.y})");
        }
    }
}
/// <summary>
/// Локальная утилита пересечения прямоугольников для defensive-guard'а.
/// Zero-alloc.
/// </summary>
private static bool RectOverlaps(RectInt a, RectInt b)
{
    if (a.width <= 0 || a.height <= 0 || b.width <= 0 || b.height <= 0) return false;
    return a.x < b.x + b.width  && a.x + a.width  > b.x
        && a.y < b.y + b.height && a.y + a.height > b.y;
}
private bool WouldCauseBackpackCycle(
    InventoryController targetController,
    InventoryItem itemToPlace,
    out string reason)
{
    reason = string.Empty;
    if (targetController == null || itemToPlace == null) return false;
    if (itemToPlace.Data == null || !itemToPlace.Data.IsBackpack) return false;

    var manager = _inventoryUI?.BackpackManager;
    if (manager == null) return false;

    var targetWindow = manager.FindWindowByController(targetController);
    if (targetWindow == null) return false; // обычная сетка игрока / лут-контейнер

    if (!uint.TryParse(targetWindow.BackpackInstanceID, out uint targetOwnerId))
        return false;

    // 1. Само-вложение: item сам владеет целевым окном.
    if (itemToPlace.InstanceID == targetOwnerId)
    {
        reason = $"Cannot place '{itemToPlace.Data.DisplayName}' into its own open window (self-drop).";
        return true;
    }

    // 2. Цикл: item содержит владельца целевого окна в своём содержимом.
    //    ContainsDescendant синкает снапшот из живого контроллера перед проверкой,
    //    поэтому защищено от stale-данных.
    if (itemToPlace.ContainsDescendant(targetOwnerId))
    {
        reason = $"Nesting cycle: '{itemToPlace.Data.DisplayName}' contains the owner of the target window " +
                 $"(ownerId={targetOwnerId}) in its contents.";
        return true;
    }
    return false;
}

private bool TryPlaceTargetStrict(
    InventoryController ctrl, InventoryItem item,
    int originX, int originY, RectInt freed)
{
    if (ctrl == null || item == null || item.Data == null) return false;

    int fw = freed.width;
    int fh = freed.height;
    if (fw <= 0 || fh <= 0) return false;

    // Создаём bitmap по текущему состоянию ctrl в пределах freed-footprint.
    // true = ячейка занята (живой целью, не являющейся этим item).
    var occupied = new bool[fw * fh];
    for (int dy = 0; dy < fh; dy++)
        for (int dx = 0; dx < fw; dx++)
        {
            var occ = ctrl.GetItemAt(freed.x + dx, freed.y + dy);
            if (occ != null) occupied[dy * fw + dx] = true;
        }

    // Пробуем текущую ориентацию, затем повёрнутую.
    if (TryPlaceOneOrientationStrict(ctrl, item, freed, occupied, out int px, out int py))
    {
        return ctrl.PlaceExistingItem(item, px, py);
    }
    if (item.Data.CanRotate)
    {
        var sz = item.CurrentSize;
        if (sz.x != sz.y)
        {
            item.Rotate();
            bool ok = TryPlaceOneOrientationStrict(ctrl, item, freed, occupied, out px, out py)
                      && ctrl.PlaceExistingItem(item, px, py);
            if (!ok) item.Rotate(); // откат поворота
            return ok;
        }
    }
    return false;
}

private bool TryPlaceOneOrientationStrict(
    InventoryController ctrl, InventoryItem item, RectInt freed, bool[] occupied,
    out int px, out int py)
{
    px = py = -1;
    var size = item.CurrentSize;
    int fw = freed.width;
    int fh = freed.height;
    if (size.x > fw || size.y > fh) return false;

    for (int y = 0; y <= fh - size.y; y++)
    {
        for (int x = 0; x <= fw - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    if (occupied[(y + dy) * fw + (x + dx)])
                    { free = false; break; }
            if (free)
            {
                px = freed.x + x;
                py = freed.y + y;
                // пометить занятым для следующих целей
                for (int dy = 0; dy < size.y; dy++)
                    for (int dx = 0; dx < size.x; dx++)
                        occupied[(y + dy) * fw + (x + dx)] = true;
                return true;
            }
        }
    }
    return false;
}

// ═══ БАГ 5 ФИКС: единый хелпер закрытия окна переносимого рюкзака
// ДО RemoveItem во всех транзакциях перемещения.
// Если targetCtrl == sourceCtrl (перемещение внутри той же сетки) — НЕ закрываем. ═══
private void CloseDraggedBackpackWindowIfCrossController(
    InventoryItem item, InventoryController sourceCtrl, InventoryController targetCtrl)
{
    if (item == null || item.Data == null || !item.Data.IsBackpack) return;
    if (sourceCtrl == targetCtrl) return;
    if (_inventoryUI == null || _inventoryUI.BackpackManager == null) return;
    if (!_inventoryUI.BackpackManager.IsBackpackWindowOpen(item)) return;
    _inventoryUI.CloseAllWindowsForBackpack(item);
}

 // ============================================================
//  ИСПРАВЛЕНИЕ БАГА 2: добавлены логи в TrySwapEquipmentSlots
// ============================================================
public bool TrySwapEquipmentSlots(K_EquipmentSlotUI sourceSlot, K_EquipmentSlotUI targetSlot, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (sourceSlot == null || targetSlot == null) { errorMessage = "Null slots"; return false; }

    var itemA = sourceSlot.EquippedItem;
    if (itemA == null) { errorMessage = "No item in source slot"; return false; }

    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

    Debug.Log($"[EQUIP-SWAP] attempt: {sourceSlot.SlotType}->{targetSlot.SlotType} " +
              $"'{itemA.Data?.DisplayName}' x '{targetSlot.EquippedItem?.Data?.DisplayName ?? "empty"}'");

    if (!InventoryValidationService.TypeMatchCheck(itemA, targetSlot.SlotType))
    {
        errorMessage = "Type mismatch A to B";
        Debug.Log($"[EQUIP-SWAP] failed: {errorMessage}");
        return false;
    }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromEquipmentSlot(itemA, sourceSlot.SlotType));
        var itemB = targetSlot.EquippedItem;
        if (itemB != null)
        {
            if (!InventoryValidationService.TypeMatchCheck(itemB, sourceSlot.SlotType))
            {
                errorMessage = "Type mismatch B to A";
                Debug.Log($"[EQUIP-SWAP] failed: {errorMessage}");
                Rollback();
                return false;
            }
            _snapshots.Add(ItemSnapshot.FromEquipmentSlot(itemB, targetSlot.SlotType));
        }

        sourceSlot.SetEquippedItem(null);
        _inHandItems[itemA.InstanceID] = itemA;

        if (itemB != null)
        {
            targetSlot.SetEquippedItem(null);
            _inHandItems[itemB.InstanceID] = itemB;
            sourceSlot.SetEquippedItem(itemB);
            _placements.Add(new PlacementRecord(itemB, sourceSlot));
            _inHandItems.Remove(itemB.InstanceID);
        }

        targetSlot.SetEquippedItem(itemA);
        _placements.Add(new PlacementRecord(itemA, targetSlot));
        _inHandItems.Remove(itemA.InstanceID);

        if (sourceSlot.SlotType == EquipmentSlotType.Backpack || targetSlot.SlotType == EquipmentSlotType.Backpack)
        {
            if (itemA.Data.IsBackpack && sourceSlot.SlotType == EquipmentSlotType.Backpack) _inventoryUI.OnBackpackUnequipped();
            if (itemB != null && itemB.Data.IsBackpack && targetSlot.SlotType == EquipmentSlotType.Backpack) _inventoryUI.OnBackpackUnequipped();
            if (itemA.Data.IsBackpack && targetSlot.SlotType == EquipmentSlotType.Backpack) _inventoryUI.OnBackpackEquipped(itemA);
            if (itemB != null && itemB.Data.IsBackpack && sourceSlot.SlotType == EquipmentSlotType.Backpack) _inventoryUI.OnBackpackEquipped(itemB);
        }

        Commit();
        _inventoryUI.ForceRefresh();

        Debug.Log($"[EQUIP-SWAP] committed: {sourceSlot.SlotType}->{targetSlot.SlotType} " +
                  $"'{itemA.Data?.DisplayName}' swapped with '{itemB?.Data?.DisplayName ?? "empty"}'");
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Debug.Log($"[EQUIP-SWAP] failed: {errorMessage}");
        Rollback();
        return false;
    }
}

public bool TryDropFromEquipmentIntoBackpack(InventoryItem item, InventoryItem targetBackpack, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (item == null || targetBackpack == null) { errorMessage = "Null references"; return false; }
    if (targetBackpack.Data == null || !targetBackpack.Data.IsBackpack) { errorMessage = "Target is not a backpack"; return false; }
    if (targetBackpack.IsFolded && !targetBackpack.Data.AlwaysShowGrid) { errorMessage = "Cannot drop into folded backpack"; return false; }
    if (!targetBackpack.HasInternalGrid || item == targetBackpack) { errorMessage = "Invalid target"; return false; }

    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

    _inventoryUI.SyncBackpackForValidation(item);
    _inventoryUI.SyncBackpackForValidation(targetBackpack);

    if (!InventoryOperationValidator.ValidateDropIntoBackpack(item, targetBackpack, _inventoryUI.BackpackManager, out errorMessage))
        return false;

    K_EquipmentSlotUI sourceSlot = FindSlotHoldingItem(item);
    if (sourceSlot == null) { errorMessage = "Item is not in any equipment slot"; return false; }
    if (sourceSlot.EquippedItem != item) { errorMessage = "Slot mismatch"; return false; }

    int w = targetBackpack.Data.BackpackWidth;
    int h = targetBackpack.Data.BackpackHeight;
    if (w <= 0 || h <= 0) { errorMessage = "Invalid backpack dimensions"; return false; }

    InventoryController liveCtrl = _inventoryUI.BackpackManager.GetLiveController(targetBackpack.InstanceID.ToString());
    InventoryController workCtrl;
    bool workIsTemp;
    if (liveCtrl != null)
    {
        workCtrl = liveCtrl;
        workIsTemp = false;
    }
    else
    {
        var data = new InventoryData(w, h);
        var savedItems = targetBackpack.GetBackpackSavedItems();
        if (savedItems != null)
            foreach (var s in savedItems) data.AddItem(s);
        workCtrl = new InventoryController(data, K_InventorySetup.DatabaseInstance, "TempDrop_" + targetBackpack.InstanceID);
        workIsTemp = true;
    }

    int origAngle = item.RotationAngle;
    if (!InventoryValidationService.FindFreeSpace(workCtrl, item, out int px, out int py))
    {
        item.RestoreRotationState(origAngle);
        if (workIsTemp) workCtrl.Dispose();
        errorMessage = "No free space in backpack";
        return false;
    }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromEquipmentSlot(item, sourceSlot.SlotType));

        sourceSlot.SetEquippedItem(null);
        _inHandItems[item.InstanceID] = item;

        if (!workCtrl.PlaceExistingItem(item, px, py))
        {
            item.Rotate();
            if (!workCtrl.PlaceExistingItem(item, px, py))
            {
                item.Rotate();
                errorMessage = "Failed to place item in backpack";
                Rollback();
                return false;
            }
        }
        _placements.Add(new PlacementRecord(item, workIsTemp ? null : workCtrl, px, py));
        _inHandItems.Remove(item.InstanceID);

        if (workIsTemp)
        {
            targetBackpack.ReplaceBackpackContents(workCtrl.GetSaveData().GetItems());
            workCtrl.Dispose();
        }

        Commit();
        _inventoryUI.ClearEquipmentDragState();
        _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        if (workIsTemp && workCtrl != null) workCtrl.Dispose();
        Rollback();
        return false;
    }
}

/// <summary>Устаревшая обёртка — оставлена для обратной совместимости.</summary>
/// <summary>
/// Legacy-обёртка без anchor. Используется внешними вызовами, где нет
/// UI-курсора (например, тесты). Валидатор берёт tRoot как anchor.
/// </summary>
[System.Obsolete("Use TrySwapEquipmentItemWithGridItem(UI_Item, int, int, out string) — с anchor из UI.")]
public bool TrySwapEquipmentItemWithGridItem(UI_Item targetUI, out string errorMessage)
    => TrySwapEquipmentItemWithGridItem(targetUI, -1, -1, out errorMessage);

/// <summary>
/// Основная перегрузка. anchorX/anchorY — top-left позиция dragged'а из
/// K_InventoryUI.GetAdjustedDropPosition. Если &lt; 0 — берётся tRoot (legacy).
/// Паритет с highlight: DragHighlightController.DrawVisualSwapOutline
/// передаёт тот же anchor, что и K_InventorySlotUI.OnDrop.
/// </summary>
public bool TrySwapEquipmentItemWithGridItem(
    UI_Item targetUI, int anchorX, int anchorY, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }
    if (!_inventoryUI.IsDraggingFromEquipmentSlot) { errorMessage = "Not dragging from equipment slot"; return false; }

    var itemA = _inventoryUI.DraggedFromSlotItem;
    if (itemA == null) { errorMessage = "No dragged slot item"; return false; }

    var itemB = targetUI != null ? targetUI.Item : null;
    if (itemB == null) { errorMessage = "No target item"; return false; }
    if (ReferenceEquals(itemA, itemB)) { errorMessage = "Same item"; return false; }

    if (itemB.Data != null && itemB.Data.IsBackpack && !itemB.IsFolded)
    { errorMessage = "Unfolded backpack cannot be swapped (target)"; return false; }

    K_EquipmentSlotUI sourceSlot = FindSlotHoldingItem(itemA);
    if (sourceSlot == null) { errorMessage = "Cannot find source equipment slot for dragged item"; return false; }

    if (!sourceSlot.ValidateItemForSlot(itemB))
    { errorMessage = $"Target item '{itemB.Data?.DisplayName}' does not fit source slot {sourceSlot.SlotType}"; return false; }

    var ctrlB = GetControllerForUI(targetUI);
    if (ctrlB == null) { errorMessage = "No controller for target"; return false; }

    var tRoot = ctrlB.FindItemRootPosition(itemB.InstanceID);
    if (tRoot.x == -1) { errorMessage = "Target not found in controller"; return false; }

    _inventoryUI.SyncBackpackForValidation(itemA);
    _inventoryUI.SyncBackpackForValidation(itemB);

    // ═══ Паритет с highlight: используем РЕАЛЬНЫЙ anchor, если передан. ═══
    int useAnchorX = anchorX >= 0 ? anchorX : tRoot.x;
    int useAnchorY = anchorY >= 0 ? anchorY : tRoot.y;

#if UNITY_EDITOR
    Debug.Log($"[EQ-TX-SWAP] enter: anchor=({useAnchorX},{useAnchorY}) " +
              $"anchorFromCaller={anchorX >= 0 && anchorY >= 0} " +
              $"target id={itemB.InstanceID} tRoot=({tRoot.x},{tRoot.y})");
#endif

    // ═══ ЕДИНЫЙ ВАЛИДАТОР (паритет с highlight) ═══
    if (!InventoryOperationValidator.TryResolveEquipmentGridSwap(
            itemA, itemB, ctrlB,
            useAnchorX, useAnchorY,
            BuildRelocationControllers(ctrlB),
            _inventoryUI.BackpackManager,
            out int placeX, out int placeY,
            out int draggedRotation,
            out errorMessage))
    {
#if UNITY_EDITOR
        Debug.Log($"[EQ-TX-SWAP] validator-result accepted=false reason='{errorMessage}'");
#endif
        return false;
    }

#if UNITY_EDITOR
    Debug.Log($"[EQ-TX-SWAP] validator-result swap=({placeX},{placeY}) rot={draggedRotation} accepted=true reason=''");
    Debug.Log($"[EQ-SWAP-AUDIT] validator accepted: place=({placeX},{placeY}) " +
              $"draggedRotation={draggedRotation} (current {itemA.RotationAngle}) " +
              $"draggedSize={itemA.CurrentSize}");
#endif

    // Сбор 3rd-party в НОВОМ футпринте dragged (с учётом auto-rotate).
    Vector2Int dSize = itemA.CurrentSize;
    if (draggedRotation != itemA.RotationAngle)
        dSize = new Vector2Int(dSize.y, dSize.x);

    var thirdParty = new HashSet<InventoryItem>(4);
    for (int dy = 0; dy < dSize.y; dy++)
    for (int dx = 0; dx < dSize.x; dx++)
    {
        var occ = ctrlB.GetItemAt(placeX + dx, placeY + dy);
        if (occ == null) continue;
        if (ReferenceEquals(occ, itemA) || ReferenceEquals(occ, itemB)) continue;
        thirdParty.Add(occ);
    }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromEquipmentSlot(itemA, sourceSlot.SlotType));
        _snapshots.Add(ItemSnapshot.FromGrid(itemB, targetUI.GridType, tRoot.x, tRoot.y, GetContainerOwnerId(targetUI)));
        foreach (var tp in thirdParty)
        {
            var (tx, ty) = ctrlB.FindItemRootPosition(tp.InstanceID);
            if (tx == -1) { errorMessage = "3rd-party not found in ctrlB"; Rollback(); return false; }
            _snapshots.Add(ItemSnapshot.FromGrid(tp, targetUI.GridType, tx, ty, GetContainerOwnerId(targetUI)));
        }

        // 1) Снять itemB с grid.
        if (!ctrlB.RemoveItem(itemB))
        { errorMessage = "Failed to remove target B from grid"; Rollback(); return false; }
        _inHandItems[itemB.InstanceID] = itemB;

        // 2) Снять 3rd-party.
        foreach (var tp in thirdParty)
        {
            if (!ctrlB.RemoveItem(tp))
            { errorMessage = "Failed to remove 3rd-party"; Rollback(); return false; }
            _inHandItems[tp.InstanceID] = tp;
        }

        // 3) Очистить source slot.
        if (ReferenceEquals(sourceSlot.EquippedItem, itemA))
            sourceSlot.SetEquippedItem(null);
        _inHandItems[itemA.InstanceID] = itemA;

        // 4) Применить auto-rotate (тот же, что вернул валидатор).
        if (draggedRotation != itemA.RotationAngle)
        {
            itemA.Rotate();
#if UNITY_EDITOR
            Debug.Log($"[EQ-SWAP-AUDIT] applied rotation: angle {itemA.RotationAngle} " +
                      $"size=({itemA.CurrentSize.x}x{itemA.CurrentSize.y})");
#endif
        }

        // 5) Положить A в grid на placeX/placeY.
        if (!InventoryValidationService.GridSpaceCheck(ctrlB, itemA, placeX, placeY)
            || !ctrlB.PlaceExistingItem(itemA, placeX, placeY))
        {
            errorMessage = $"Item A cannot be placed at ({placeX},{placeY}) after validator";
            Rollback(); return false;
        }
        _placements.Add(new PlacementRecord(itemA, ctrlB, placeX, placeY));
        _inHandItems.Remove(itemA.InstanceID);

        // 6) Разложить 3rd-party.
        foreach (var tp in thirdParty)
        {
            if (!TryPlaceItemInAnyPlayerGrid(tp, out string tpErr))
            {
                errorMessage = "3rd-party relocation failed: " + tpErr;
                Rollback(); return false;
            }
        }

        // 7) Положить B в source slot.
        sourceSlot.SetEquippedItem(itemB);
        _placements.Add(new PlacementRecord(itemB, sourceSlot));
        _inHandItems.Remove(itemB.InstanceID);

        // 8) Backpack hooks.
        if (sourceSlot.SlotType == EquipmentSlotType.Backpack)
        {
            if (itemA.Data != null && itemA.Data.IsBackpack) _inventoryUI.OnBackpackUnequipped();
            if (itemB.Data != null && itemB.Data.IsBackpack) _inventoryUI.OnBackpackEquipped(itemB);
        }

        // 9) Финальная геометрия.
        if (!ValidateSwapFinalGeometry(ctrlB))
        { errorMessage = "Final geometry validation failed"; Rollback(); return false; }

        Commit();
        AssertGridIntegrity(ctrlB);

#if UNITY_EDITOR
        Debug.Log($"[EQ-SWAP-AUDIT] committed: '{itemA.Data?.DisplayName}' → grid ({placeX},{placeY}) " +
                  $"rot={itemA.RotationAngle}; '{itemB.Data?.DisplayName}' → slot {sourceSlot.SlotType}; " +
                  $"3rd-party={thirdParty.Count}");
#endif
        _inventoryUI.ClearEquipmentDragState();
        _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}
public bool TryEquipFromDrag(UI_Item draggedUI, K_EquipmentSlotUI targetSlot, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || targetSlot == null) { errorMessage = "Null references (draggedUI or targetSlot)"; return false; }
    var itemA = draggedUI.Item;
    if (itemA == null || itemA.Data == null) { errorMessage = "Invalid dragged item"; return false; }
    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

    if (!InventoryValidationService.TypeMatchCheck(itemA, targetSlot.SlotType))
    { errorMessage = $"Type mismatch: '{itemA.Data.DisplayName}' cannot go to slot {targetSlot.SlotType}"; return false; }
    if (targetSlot.EquippedItem == itemA) { errorMessage = "Item is already in this slot"; return false; }

    var ctrlA = GetControllerForUI(draggedUI);
    GridType gridA = draggedUI.GridType;
    var (ax, ay) = FindItemPositionInController(ctrlA, itemA);
    if (ax == -1) { errorMessage = "Item A not found in source grid (UI_Item desync)"; return false; }

    InventoryItem oldItemB = targetSlot.IsOccupied ? targetSlot.EquippedItem : null;

#if UNITY_EDITOR
    Debug.Log($"[EQ-TX-AUDIT] enter: grid={gridA} dragged id={itemA.InstanceID} rot={itemA.RotationAngle} " +
              $"size={itemA.CurrentSize} sourceRoot=({ax},{ay}) targetSlot={targetSlot.SlotType} " +
              $"target id={(oldItemB != null ? oldItemB.InstanceID.ToString() : "empty")}");
#endif

    // ═══════════════════════════════════════════════════════════════
    //  ВЕТКА A: слот ЗАНЯТ (любой тип предмета — оружие, броня, рюкзак).
    //  Единый валидатор: displaced ДОЛЖЕН поместиться в freed cells
    //  sourceCtrl с auto-rotate. Никакого TryPlaceItemInPlayerGrids.
    // ═══════════════════════════════════════════════════════════════
    if (oldItemB != null)
    {
        _inventoryUI.SyncBackpackForValidation(itemA);
        _inventoryUI.SyncBackpackForValidation(oldItemB);

        if (!InventoryOperationValidator.TryResolveEquipSlotSwap(
                itemA, oldItemB, ctrlA, ax, ay,
                out int placeX, out int placeY, out int placeRotation,
                out errorMessage))
        {
#if UNITY_EDITOR
            Debug.Log($"[EQ-TX-AUDIT] validator REJECTED: {errorMessage}");
#endif
            return false;
        }

#if UNITY_EDITOR
        Debug.Log($"[EQ-TX-AUDIT] validator ACCEPTED: place=({placeX},{placeY}) " +
                  $"placeRotation={placeRotation} (equipped current rot={oldItemB.RotationAngle})");
#endif

        BeginTransaction();
        try
        {
            _snapshots.Add(ItemSnapshot.FromGrid(itemA, gridA, ax, ay, GetContainerOwnerId(draggedUI)));
            _snapshots.Add(ItemSnapshot.FromEquipmentSlot(oldItemB, targetSlot.SlotType));

            // 1) Снять dragged из source grid.
            if (ctrlA == null || !ctrlA.RemoveItem(itemA))
            { errorMessage = "Failed to remove A from source grid"; Rollback(); return false; }
            _inHandItems[itemA.InstanceID] = itemA;

            // 2) Backpack hook ДО очистки слота.
            if (targetSlot.SlotType == EquipmentSlotType.Backpack
                && oldItemB.Data != null && oldItemB.Data.IsBackpack)
            {
                _inventoryUI.OnBackpackUnequipped();
            }

            // 3) Снять equipped из слота.
            if (ReferenceEquals(targetSlot.EquippedItem, oldItemB))
                targetSlot.SetEquippedItem(null);
            _inHandItems[oldItemB.InstanceID] = oldItemB;

            // 4) Применить auto-rotate, если валидатор так решил.
            if (placeRotation != oldItemB.RotationAngle)
            {
                oldItemB.RestoreRotationState(placeRotation);
#if UNITY_EDITOR
                Debug.Log($"[EQ-TX-AUDIT] applied rotation to displaced: " +
                          $"angle={oldItemB.RotationAngle} size={oldItemB.CurrentSize}");
#endif
            }

            // 5) Разместить displaced СТРОГО в freed (уже проверено).
            if (!ctrlA.PlaceExistingItem(oldItemB, placeX, placeY))
            {
                errorMessage = $"Displaced item cannot be placed at validated position ({placeX},{placeY})";
                Rollback(); return false;
            }
            _placements.Add(new PlacementRecord(oldItemB, ctrlA, placeX, placeY));
            _inHandItems.Remove(oldItemB.InstanceID);

            // 6) Экипировать itemA.
            targetSlot.SetEquippedItem(itemA);
            _placements.Add(new PlacementRecord(itemA, targetSlot));
            _inHandItems.Remove(itemA.InstanceID);

            // 7) Backpack hook для нового экипированного.
            if (targetSlot.SlotType == EquipmentSlotType.Backpack
                && itemA.Data != null && itemA.Data.IsBackpack)
            {
                _inventoryUI.OnBackpackEquipped(itemA);
            }

            Commit();
            _inventoryUI.ForceRefresh();
            return true;
        }
        catch (System.Exception ex)
        {
            Debug.LogException(ex);
            errorMessage = "Transaction exception: " + ex.Message;
            Rollback();
            return false;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  ВЕТКА B: слот ПУСТ. Простой remove → equip. Без displaced.
    // ═══════════════════════════════════════════════════════════════
    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(itemA, gridA, ax, ay, GetContainerOwnerId(draggedUI)));

        if (ctrlA != null)
        {
            if (!ctrlA.RemoveItem(itemA))
            { errorMessage = "Failed to remove A from source grid"; Rollback(); return false; }
            _inHandItems[itemA.InstanceID] = itemA;
        }

        targetSlot.SetEquippedItem(itemA);
        _placements.Add(new PlacementRecord(itemA, targetSlot));
        _inHandItems.Remove(itemA.InstanceID);

        if (targetSlot.SlotType == EquipmentSlotType.Backpack
            && itemA.Data != null && itemA.Data.IsBackpack)
        {
            _inventoryUI.OnBackpackEquipped(itemA);
        }

        Commit();

        if (ctrlA != null && itemA.Data != null && itemA.Data.IsBackpack)
            _inventoryUI.CloseAllWindowsForBackpack(itemA);

        _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}
// ============================================================
//  TryEquipFromContextMenu – экипировка через ПКМ-меню.
//  Не требует UI_Item: сам находит предмет в сетках игрока
//  и определяет целевой слот по типу предмета.
// ============================================================
public bool TryEquipFromContextMenu(InventoryItem item, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (item == null || item.Data == null) { errorMessage = "Invalid item"; return false; }

    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

    // ═══ 1. Найти целевой слот экипировки ═══
    K_EquipmentSlotUI targetSlot = null;
    EnsureSlotsCached();
    foreach (var slot in _cachedSlots)
    {
        if (slot == null) continue;
        if (!InventoryValidationService.TypeMatchCheck(item, slot.SlotType)) continue;

        // Предпочтение: пустой слот.
        if (!slot.IsOccupied)
        {
            targetSlot = slot;
            break;
        }
        // Fallback: первый подходящий занятый слот (будет свап).
        if (targetSlot == null)
            targetSlot = slot;
    }

    if (targetSlot == null)
    {
        errorMessage = $"No equipment slot available for '{item.Data.DisplayName}' (type={item.Type})";
        return false;
    }

    // Если предмет уже в этом слоте — no-op.
    if (ReferenceEquals(targetSlot.EquippedItem, item))
        return true;

    // ═══ 2. Найти, где предмет сейчас лежит ═══
    InventoryController sourceCtrl = null;
    GridType sourceGrid = GridType.Pockets;
    int srcX = -1, srcY = -1;

    // 2a. Основные сетки игрока.
    var grids = new[]
    {
        (GridType.Pockets,   _inventoryUI.GetControllerForGrid(GridType.Pockets)),
        (GridType.Pocket2,   _inventoryUI.GetControllerForGrid(GridType.Pocket2)),
        (GridType.Backpack,  _inventoryUI.GetControllerForGrid(GridType.Backpack)),
    };

    foreach (var (gt, ctrl) in grids)
    {
        if (ctrl == null) continue;
        var (rx, ry) = ctrl.FindItemRootPosition(item.InstanceID);
        if (rx != -1)
        {
            sourceCtrl = ctrl;
            sourceGrid = gt;
            srcX = rx;
            srcY = ry;
            break;
        }
    }

    // 2b. Открытые окна рюкзаков (BackpackManager).
    if (sourceCtrl == null && _inventoryUI.BackpackManager != null)
    {
        foreach (var w in _inventoryUI.BackpackManager.OpenWindows)
        {
            if (w?.Controller == null) continue;
            var (rx, ry) = w.Controller.FindItemRootPosition(item.InstanceID);
            if (rx != -1)
            {
                sourceCtrl = w.Controller;
                sourceGrid = GridType.Container;
                srcX = rx;
                srcY = ry;
                break;
            }
        }
    }

    // 2c. Активный лут-контейнер.
    if (sourceCtrl == null && _inventoryUI.IsLooting && _inventoryUI.ActiveContainerController != null)
    {
        var lootCtrl = _inventoryUI.ActiveContainerController;
        var (rx, ry) = lootCtrl.FindItemRootPosition(item.InstanceID);
        if (rx != -1)
        {
            sourceCtrl = lootCtrl;
            sourceGrid = GridType.Container;
            srcX = rx;
            srcY = ry;
        }
    }

    if (sourceCtrl == null || srcX == -1)
    {
        errorMessage = $"Item '{item.Data.DisplayName}' not found in any player grid or container";
        return false;
    }

    // ═══ 3. Определить ownerId для снапшота ═══
    uint containerOwnerId = 0u;
    if (sourceGrid == GridType.Container && _inventoryUI.BackpackManager != null)
    {
        var win = _inventoryUI.BackpackManager.FindWindowByController(sourceCtrl);
        if (win != null && uint.TryParse(win.BackpackInstanceID, out uint oid))
            containerOwnerId = oid;
    }

    // ═══ 4. Выполнить экипировку (та же логика, что TryEquipFromDrag) ═══
    InventoryItem oldItemB = targetSlot.IsOccupied ? targetSlot.EquippedItem : null;

#if UNITY_EDITOR
    Debug.Log($"[CTX-EQUIP] enter: item='{item.Data?.DisplayName}' id={item.InstanceID} " +
              $"grid={sourceGrid} pos=({srcX},{srcY}) targetSlot={targetSlot.SlotType} " +
              $"occupied={(oldItemB != null ? oldItemB.Data?.DisplayName : "empty")}");
#endif

    // ─── ВЕТКА A: слот ЗАНЯТ → свап ───
    if (oldItemB != null)
    {
        _inventoryUI.SyncBackpackForValidation(item);
        _inventoryUI.SyncBackpackForValidation(oldItemB);

        if (!InventoryOperationValidator.TryResolveEquipSlotSwap(
                item, oldItemB, sourceCtrl, srcX, srcY,
                out int placeX, out int placeY, out int placeRotation,
                out errorMessage))
        {
#if UNITY_EDITOR
            Debug.Log($"[CTX-EQUIP] validator REJECTED: {errorMessage}");
#endif
            return false;
        }

        BeginTransaction();
        try
        {
            _snapshots.Add(ItemSnapshot.FromGrid(item, sourceGrid, srcX, srcY, containerOwnerId));
            _snapshots.Add(ItemSnapshot.FromEquipmentSlot(oldItemB, targetSlot.SlotType));

            if (!sourceCtrl.RemoveItem(item))
            { errorMessage = "Failed to remove item from source grid"; Rollback(); return false; }
            _inHandItems[item.InstanceID] = item;

            if (targetSlot.SlotType == EquipmentSlotType.Backpack
                && oldItemB.Data != null && oldItemB.Data.IsBackpack)
                _inventoryUI.OnBackpackUnequipped();

            if (ReferenceEquals(targetSlot.EquippedItem, oldItemB))
                targetSlot.SetEquippedItem(null);
            _inHandItems[oldItemB.InstanceID] = oldItemB;

            if (placeRotation != oldItemB.RotationAngle)
                oldItemB.RestoreRotationState(placeRotation);

            if (!sourceCtrl.PlaceExistingItem(oldItemB, placeX, placeY))
            {
                errorMessage = $"Displaced item cannot be placed at ({placeX},{placeY})";
                Rollback(); return false;
            }
            _placements.Add(new PlacementRecord(oldItemB, sourceCtrl, placeX, placeY));
            _inHandItems.Remove(oldItemB.InstanceID);

            targetSlot.SetEquippedItem(item);
            _placements.Add(new PlacementRecord(item, targetSlot));
            _inHandItems.Remove(item.InstanceID);

            if (targetSlot.SlotType == EquipmentSlotType.Backpack
                && item.Data != null && item.Data.IsBackpack)
                _inventoryUI.OnBackpackEquipped(item);

            Commit();
            _inventoryUI.ForceRefresh();

#if UNITY_EDITOR
            Debug.Log($"[CTX-EQUIP] swap committed: '{item.Data?.DisplayName}' → slot {targetSlot.SlotType}; " +
                      $"'{oldItemB.Data?.DisplayName}' → grid ({placeX},{placeY})");
#endif
            return true;
        }
        catch (System.Exception ex)
        {
            Debug.LogException(ex);
            errorMessage = "Transaction exception: " + ex.Message;
            Rollback();
            return false;
        }
    }

    // ─── ВЕТКА B: слот ПУСТ → простой перенос ───
    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(item, sourceGrid, srcX, srcY, containerOwnerId));

        if (!sourceCtrl.RemoveItem(item))
        { errorMessage = "Failed to remove item from source grid"; Rollback(); return false; }
        _inHandItems[item.InstanceID] = item;

        targetSlot.SetEquippedItem(item);
        _placements.Add(new PlacementRecord(item, targetSlot));
        _inHandItems.Remove(item.InstanceID);

        if (targetSlot.SlotType == EquipmentSlotType.Backpack
            && item.Data != null && item.Data.IsBackpack)
            _inventoryUI.OnBackpackEquipped(item);

        Commit();

        if (item.Data != null && item.Data.IsBackpack)
            _inventoryUI.CloseAllWindowsForBackpack(item);

        _inventoryUI.ForceRefresh();

#if UNITY_EDITOR
        Debug.Log($"[CTX-EQUIP] equip committed: '{item.Data?.DisplayName}' → slot {targetSlot.SlotType}");
#endif
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}
// ============================================================
//  TryDropIntoEquippedBackpack – исправленный
// ============================================================
public bool TryDropIntoEquippedBackpack(
    UI_Item draggedUI,
    K_EquipmentSlotUI backpackSlot,
    out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || backpackSlot == null) { errorMessage = "Null references"; return false; }
    var itemA = draggedUI.Item;
    if (itemA == null || itemA.Data == null) { errorMessage = "Invalid dragged item"; return false; }
    if (itemA.Data.IsBackpack) { errorMessage = "Backpack items use equip swap path"; return false; }
    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

    var equippedBackpack = backpackSlot.EquippedItem;
    if (equippedBackpack == null || equippedBackpack.Data == null || !equippedBackpack.Data.IsBackpack)
    { errorMessage = "No backpack equipped in slot"; return false; }

    var bpCtrl = _inventoryUI.GetControllerForGrid(GridType.Backpack);
    if (bpCtrl == null) { errorMessage = "No backpack controller"; return false; }

    if (!InventoryOperationValidator.ValidateDropIntoEquippedBackpack(
        itemA, bpCtrl, out int px, out int py, out errorMessage))
        return false;

    var ctrlA = GetControllerForUI(draggedUI);
    GridType gridA = draggedUI.GridType;
    var (ax, ay) = FindItemPositionInController(ctrlA, itemA);
    if (ax == -1) { errorMessage = "Item not found in source controller"; return false; }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(itemA, gridA, ax, ay, GetContainerOwnerId(draggedUI)));

        // ═══ УДАЛЯЕМ CloseDraggedBackpackWindowIfCrossController ОТСЮДА ═══

        if (!ctrlA.RemoveItem(itemA))
        {
            errorMessage = "Failed to remove item from source";
            Rollback();
            return false;
        }
        _inHandItems[itemA.InstanceID] = itemA;

        if (!bpCtrl.PlaceExistingItem(itemA, px, py))
        {
            itemA.Rotate();
            if (!bpCtrl.PlaceExistingItem(itemA, px, py))
            {
                itemA.Rotate();
                errorMessage = "Failed to place item in equipped backpack";
                Rollback();
                return false;
            }
        }
        _placements.Add(new PlacementRecord(itemA, bpCtrl, px, py));
        _inHandItems.Remove(itemA.InstanceID);

        Commit();

        // ═══ ПОСЛЕ Commit закрываем окно источника, если источник ≠ цель ═══
        if (ctrlA != null && ctrlA != bpCtrl && itemA.Data != null && itemA.Data.IsBackpack)
        {
            _inventoryUI.CloseAllWindowsForBackpack(itemA);
        }

        _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}

// ============================================================
//  TryMoveItem – исправленный
// ============================================================
public bool TryMoveItem(
    UI_Item draggedUI,
    InventoryController targetController,
    int targetX,
    int targetY,
    out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || targetController == null) { errorMessage = "Null references"; return false; }

    var itemA = draggedUI.Item;
    if (itemA == null || itemA.Data == null) { errorMessage = "Invalid dragged item"; return false; }

    EnsureInitialized();

    var sourceController = GetControllerForUI(draggedUI);
    GridType gridA = draggedUI.GridType;
    var (ax, ay) = FindItemPositionInController(sourceController, itemA);

    if (ax == -1)
    {
        errorMessage = $"Item '{itemA.Data?.DisplayName}' not found in source controller (UI_Item desync)";
        return false;
    }

    // no-op
    if (sourceController == targetController
        && ax == targetX && ay == targetY
        && itemA.RotationAngle == draggedUI.Item.RotationAngle)
    {
        return true;
    }

    // ═══ Проверка глубины для развёрнутого рюкзака ═══
    if (_inventoryUI != null && _inventoryUI.BackpackManager != null)
    {
        var backpackManager = _inventoryUI.BackpackManager;
        if (itemA.Data.IsBackpack && !itemA.IsFolded)
        {
            var targetWindow = backpackManager.FindWindowByController(targetController);
            if (targetWindow != null)
            {
                if (!backpackManager.CanPlaceUnfoldedBackpackIntoController(targetController, itemA, out string depthReason))
                {
                    errorMessage = depthReason;
                    return false;
                }
            }
        }
    }

    // ═══ CYCLE PRE-CHECK ═══
    // Отказ ДО любых мутаций: self-drop в собственное окно или вложение
    // в окно потомка (= цикл в serialized-цепочке).
    if (itemA.Data.IsBackpack)
    {
        _inventoryUI.SyncBackpackForValidation(itemA);
        if (WouldCauseBackpackCycle(targetController, itemA, out string cycleReason))
        {
            errorMessage = cycleReason;
            return false;
        }
    }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(itemA, gridA, ax, ay, GetContainerOwnerId(draggedUI)));

      if (sourceController == targetController)
{
    if (!targetController.MoveItem(itemA, targetX, targetY))
    {
        errorMessage = $"Cannot move to ({targetX},{targetY}) — no space or occupied";
        Rollback();
        return false;
    }
    _placements.Add(new PlacementRecord(itemA, targetController, targetX, targetY));

    // ═══ ФИКС БАГА A: жёсткая проверка пост-условия сразу после same-grid Move.
    // MoveItem использует ClearCellsOwnedBy, но если какой-то другой код
    // оставил фантом от ПРЕДЫДУЩЕЙ операции — он всплывёт здесь, а не через
    // несколько операций. ═══
    AssertGridIntegrity(targetController);
}
else
{
    if (sourceController != null)
    {
        if (!sourceController.RemoveItem(itemA))
        {
            errorMessage = "Failed to remove item from source controller";
            Rollback();
            return false;
        }
        _inHandItems[itemA.InstanceID] = itemA;
    }
    if (!targetController.PlaceExistingItem(itemA, targetX, targetY))
    {
        errorMessage = "Failed to place item into target controller";
        Rollback();
        return false;
    }
    _placements.Add(new PlacementRecord(itemA, targetController, targetX, targetY));
    _inHandItems.Remove(itemA.InstanceID);
}

        Commit();

        if (sourceController != null && sourceController != targetController
            && itemA.Data != null && itemA.Data.IsBackpack)
        {
            _inventoryUI.CloseAllWindowsForBackpack(itemA);
        }

        AssertGridIntegrity(sourceController, targetController);
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}
private void AssertGridIntegrity(params InventoryController[] ctrls)
{
    foreach (var ctrl in ctrls)
    {
        if (ctrl == null || ctrl.IsDisposed) continue;
        bool hasError = false;

        for (int y = 0; y < ctrl.Height && !hasError; y++)
        {
            for (int x = 0; x < ctrl.Width; x++)
            {
                var it = ctrl.GetItemAt(x, y);
                if (it == null) continue;
                var (rx, ry) = ctrl.FindItemRootPosition(it.InstanceID);
                if (rx == -1)
                {
                    Debug.LogError(
                        $"[Integrity] Cell ({x},{y}) references item {it.InstanceID} without root!");
                    hasError = true; break;
                }
                var sz = it.CurrentSize;
                if (rx + sz.x > ctrl.Width || ry + sz.y > ctrl.Height)
                {
                    Debug.LogError(
                        $"[Integrity] Item {it.InstanceID} root ({rx},{ry}) size {sz.x}x{sz.y} " +
                        $"exceeds grid {ctrl.Width}x{ctrl.Height}");
                    hasError = true; break;
                }
                if (x < rx || x >= rx + sz.x || y < ry || y >= ry + sz.y)
                {
                    Debug.LogError(
                        $"[Integrity] Cell ({x},{y}) outside footprint of its own item {it.InstanceID} " +
                        $"(root {rx},{ry}, size {sz.x}x{sz.y})");
                    hasError = true; break;
                }
            }
        }

        if (hasError)
        {
            DumpGrid(ctrl);
        }
    }
}

/// <summary>
/// Полный дамп сетки при нарушении целостности.
/// Формат: y=NN | [R/ ]XXXX, где R = root-cell, XXXX = последние 4 цифры InstanceID.
/// </summary>
private void DumpGrid(InventoryController ctrl)
{
    if (ctrl == null || ctrl.IsDisposed) return;
    var sb = new System.Text.StringBuilder(2048);
    sb.AppendLine($"[Integrity-DUMP] Grid '{ctrl.SaveID}' {ctrl.Width}x{ctrl.Height}:");
    for (int y = 0; y < ctrl.Height; y++)
    {
        sb.Append("  y=").Append(y.ToString("D2")).Append(" |");
        for (int x = 0; x < ctrl.Width; x++)
        {
            var at = ctrl.GetItemAt(x, y);
            if (at == null) { sb.Append("     ."); continue; }
            var (rx, ry) = ctrl.FindItemRootPosition(at.InstanceID);
            bool isRoot = (rx == x && ry == y);
            sb.Append(' ').Append(isRoot ? 'R' : ' ')
              .Append((at.InstanceID % 10000).ToString("D4"));
        }
        sb.AppendLine(" |");
    }
    Debug.LogError(sb.ToString());
}
public bool TryDropIntoBackpack(UI_Item draggedUI, InventoryItem targetBackpack, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || targetBackpack == null) { errorMessage = "Null references"; return false; }
    var itemA = draggedUI.Item;
    if (itemA == null || itemA.Data == null) { errorMessage = "Invalid dragged item"; return false; }
    if (targetBackpack.Data == null || !targetBackpack.Data.IsBackpack)
    { errorMessage = "Target is not a backpack"; return false; }
    if (targetBackpack.IsFolded && !targetBackpack.Data.AlwaysShowGrid)
    { errorMessage = "Cannot drop into folded backpack"; return false; }
    if (!targetBackpack.HasInternalGrid || itemA == targetBackpack)
    { errorMessage = "Invalid target"; return false; }

    EnsureInitialized();

    _inventoryUI.SyncBackpackForValidation(itemA);
    _inventoryUI.SyncBackpackForValidation(targetBackpack);
    if (!InventoryOperationValidator.ValidateDropIntoBackpack(
            itemA, targetBackpack, _inventoryUI.BackpackManager, out errorMessage))
        return false;

    int origAngle = itemA.RotationAngle;
    var db = K_InventorySetup.DatabaseInstance;
    if (db == null) { errorMessage = "Database not initialized"; return false; }

    int w = targetBackpack.Data.BackpackWidth;
    int h = targetBackpack.Data.BackpackHeight;
    if (w <= 0 || h <= 0) { errorMessage = "Invalid backpack dimensions"; return false; }

    string bpIdStr = targetBackpack.InstanceID.ToString();
    InventoryController liveCtrl = null;
    if (_inventoryUI != null && _inventoryUI.BackpackManager != null)
        liveCtrl = _inventoryUI.BackpackManager.GetLiveController(bpIdStr);

    InventoryController workCtrl;
    bool workIsTemp;
    if (liveCtrl != null)
    {
        workCtrl = liveCtrl;
        workIsTemp = false;
    }
    else
    {
        var data = new InventoryData(w, h);
        var savedItems = targetBackpack.GetBackpackSavedItems();
        if (savedItems != null)
            foreach (var s in savedItems) data.AddItem(s);
        workCtrl = new InventoryController(data, db, "TempDrop_" + targetBackpack.InstanceID);
        workIsTemp = true;
    }

    var sourceController = GetControllerForUI(draggedUI);
    int snapX, snapY;
    if (sourceController != null)
    {
        var (realX, realY) = FindItemPositionInController(sourceController, itemA);
        if (realX == -1)
        {
            errorMessage = "Item not found in source controller (UI_Item desync)";
            if (workIsTemp) workCtrl.Dispose();
            return false;
        }
        snapX = realX;
        snapY = realY;
    }
    else
    {
        snapX = draggedUI.X;
        snapY = draggedUI.Y;
    }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(itemA, draggedUI.GridType, snapX, snapY, GetContainerOwnerId(draggedUI)));

        if (!InventoryValidationService.FindFreeSpace(workCtrl, itemA, out int px, out int py))
        {
            itemA.RestoreRotationState(origAngle);
            if (workIsTemp) workCtrl.Dispose();
            errorMessage = "No free space in backpack";
            Rollback();
            return false;
        }

        if (sourceController != null)
        {
            if (!sourceController.RemoveItem(itemA))
            {
                if (workIsTemp) workCtrl.Dispose();
                errorMessage = "Failed to remove item from source controller";
                Rollback();
                return false;
            }
            _inHandItems[itemA.InstanceID] = itemA;
        }

        if (!workCtrl.PlaceExistingItem(itemA, px, py))
        {
            itemA.RestoreRotationState(origAngle);
            if (workIsTemp) workCtrl.Dispose();
            errorMessage = "Failed to place item in backpack";
            Rollback();
            return false;
        }
        _placements.Add(new PlacementRecord(itemA, workIsTemp ? null : workCtrl, px, py));
        _inHandItems.Remove(itemA.InstanceID);

        if (workIsTemp)
        {
            targetBackpack.ReplaceBackpackContents(workCtrl.GetSaveData().GetItems());
            workCtrl.Dispose();
            var parentCtrl = _inventoryUI != null
                ? _inventoryUI.FindControllerForItem(targetBackpack)
                : null;
            if (parentCtrl != null && parentCtrl.RefreshItemInData(targetBackpack))
            { }
            else if (_inventoryUI != null && _inventoryUI.BackpackManager != null)
            {
                _inventoryUI.BackpackManager.CommitBackpackContentsIntoChain(
                    targetBackpack.InstanceID,
                    targetBackpack.GetBackpackSavedItems());
            }
        }

        Commit();

        if (sourceController != null && sourceController != workCtrl
            && itemA.Data != null && itemA.Data.IsBackpack)
        {
            _inventoryUI.CloseAllWindowsForBackpack(itemA);
        }

        if (_inventoryUI != null) _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        if (workIsTemp && workCtrl != null) workCtrl.Dispose();
        Rollback();
        return false;
    }
}

private List<InventoryController> BuildRelocationControllers(InventoryController extra)
{
    _relocBuffer.Clear();
    if (_inventoryUI != null)
    {
        if (_inventoryUI.PocketsController != null) _relocBuffer.Add(_inventoryUI.PocketsController);
        if (_inventoryUI.Pocket2Controller != null) _relocBuffer.Add(_inventoryUI.Pocket2Controller);
        if (_inventoryUI.BackpackController != null) _relocBuffer.Add(_inventoryUI.BackpackController);
    }
    if (extra != null && !_relocBuffer.Contains(extra)) _relocBuffer.Add(extra);
    if (_inventoryUI != null && _inventoryUI.BackpackManager != null)
    {
        foreach (var w in _inventoryUI.BackpackManager.OpenWindows)
            if (w != null && w.Controller != null && !_relocBuffer.Contains(w.Controller))
                _relocBuffer.Add(w.Controller);
    }
    // ═══ БАГ 3c ФИКС (parity И2): loot/окружение в candidate-контроллерах
    // для relocation. Валидатор и транзакция должны видеть одинаковый список. ═══
    if (_inventoryUI != null && _inventoryUI.IsLooting && _inventoryUI.ActiveContainerController != null)
    {
        var lootCtrl = _inventoryUI.ActiveContainerController;
        if (!_relocBuffer.Contains(lootCtrl))
            _relocBuffer.Add(lootCtrl);
    }
    return _relocBuffer;
}
    private void BeginTransaction()
    {
        _isTransactionActive = true;
        _snapshots.Clear();
        _placements.Clear();
        _inHandItems.Clear();
    }

    private void Commit()
    {
        _snapshots.Clear();
        _placements.Clear();
        _inHandItems.Clear();
        _isTransactionActive = false;
    }

 private void Rollback()
{
    for (int i = _placements.Count - 1; i >= 0; i--)
    {
        var p = _placements[i];
        if (p.Item == null) continue;
        if (p.InSlot && p.Slot != null)
        {
            if (ReferenceEquals(p.Slot.EquippedItem, p.Item))
            {
                p.Slot.SetEquippedItem(null);
                _inHandItems[p.Item.InstanceID] = p.Item;
            }
        }
        else if (p.Controller != null)
        {
            try
            {
                if (p.Controller.IsRootCell(p.Item.InstanceID, p.X, p.Y) ||
                    IsItemAnywhereInController(p.Controller, p.Item))
                {
                    p.Controller.RemoveItem(p.Item);
                    _inHandItems[p.Item.InstanceID] = p.Item;
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[Transaction.Rollback] Failed to remove item from placement: {ex.Message}");
            }
        }
    }

    for (int i = _snapshots.Count - 1; i >= 0; i--)
    {
        var snap = _snapshots[i];
        if (!snap.IsValid) continue;

        InventoryItem liveItem;
        if (!_inHandItems.TryGetValue(snap.InstanceID, out liveItem))
            liveItem = FindItemByInstanceId(snap.InstanceID);

        if (liveItem == null)
        {
            Debug.LogError(
                $"[ROLLBACK-FAIL] InstanceID={snap.InstanceID} not found in hand or any controller. " +
                $"Snapshot was invalid. Item is LOST.");
            continue;
        }

        _inHandItems.Remove(snap.InstanceID);

        try { liveItem.RestoreRotationState(snap.RotationAngle); } catch { }

        if (liveItem.Data != null && liveItem.Data.CanFold && liveItem.IsFolded != snap.IsFolded)
            liveItem.SetFolded(snap.IsFolded);

        if (snap.IsFromEquipmentSlot)
        {
            K_EquipmentSlotUI slot = FindEquipmentSlot(snap.EquipmentSlotType);
            if (slot == null)
            {
                RemoveItemFromEverywhere(liveItem);
                // ФИКС БАГА B: НЕ вызываем TryPlaceItemInAnyPlayerGrid (silent relocation).
                // Последний шанс — Pockets (карман) с логированием.
                var pocketsCtrl = _inventoryUI != null
                    ? _inventoryUI.GetControllerForGrid(GridType.Pockets) : null;
                if (pocketsCtrl == null || !pocketsCtrl.PlaceExistingItemInFirstFreeSlot(liveItem))
                {
                    Debug.LogError(
                        $"[ROLLBACK-FAIL] Equipment slot {snap.EquipmentSlotType} not found and " +
                        $"Pockets has no space for '{liveItem.Data?.DisplayName}' " +
                        $"(InstanceID={snap.InstanceID}). Item is LOST.");
                }
                continue;
            }
            if (slot.EquippedItem != null && slot.EquippedItem != liveItem)
            {
                var orphan = slot.EquippedItem;
                slot.SetEquippedItem(null);
                Debug.LogError(
                    $"[ROLLBACK-FAIL] Slot {slot.SlotType} had conflicting item " +
                    $"'{orphan.Data?.DisplayName}' (InstanceID={orphan.InstanceID}) " +
                    $"while restoring '{liveItem.Data?.DisplayName}'. Moving orphan to Pockets.");
                var pocketsCtrl2 = _inventoryUI != null
                    ? _inventoryUI.GetControllerForGrid(GridType.Pockets) : null;
                if (pocketsCtrl2 == null || !pocketsCtrl2.PlaceExistingItemInFirstFreeSlot(orphan))
                {
                    Debug.LogError(
                        $"[ROLLBACK-FAIL] Could not relocate orphan " +
                        $"(InstanceID={orphan.InstanceID}). Item is LOST.");
                }
            }
            slot.SetEquippedItem(liveItem);
        }
        else
        {
            InventoryController originCtrl = null;
            if (snap.OriginGrid == GridType.Container)
            {
                if (snap.OriginContainerOwnerId != 0 && _inventoryUI != null && _inventoryUI.BackpackManager != null)
                    originCtrl = _inventoryUI.BackpackManager.GetLiveController(snap.OriginContainerOwnerId.ToString());
            }
            else
            {
                originCtrl = _inventoryUI != null ? _inventoryUI.GetControllerForGrid(snap.OriginGrid) : null;
            }

            if (originCtrl != null)
            {
                var existing = originCtrl.GetItemAt(snap.OriginX, snap.OriginY);
                bool alreadyAtOrigin = existing != null && existing.InstanceID == liveItem.InstanceID;
                if (!alreadyAtOrigin)
                {
                    RemoveItemFromEverywhere(liveItem);
                    if (!originCtrl.PlaceExistingItem(liveItem, snap.OriginX, snap.OriginY))
                    {
                        if (!originCtrl.PlaceExistingItemInFirstFreeSlot(liveItem))
                        {
                            if (!RestoreItemToBackpackContents(liveItem, snap.OriginContainerOwnerId,
                                                                snap.OriginX, snap.OriginY))
                            {
                                // ФИКС БАГА B: НЕ вызываем TryPlaceItemInAnyPlayerGrid.
                                Debug.LogError(
                                    $"[ROLLBACK-FAIL] Could not restore '{liveItem.Data?.DisplayName}' " +
                                    $"(InstanceID={snap.InstanceID}) to origin controller " +
                                    $"'{originCtrl.SaveID}' or serialized backpack. Item is LOST.");
                            }
                        }
                    }
                }
            }
            else
            {
                RemoveItemFromEverywhere(liveItem);

                if (!RestoreItemToBackpackContents(liveItem, snap.OriginContainerOwnerId,
                                                    snap.OriginX, snap.OriginY))
                {
                    // ФИКС БАГА B: НЕ вызываем TryPlaceItemInAnyPlayerGrid.
                    Debug.LogError(
                        $"[ROLLBACK-FAIL] No origin controller for '{liveItem.Data?.DisplayName}' " +
                        $"(InstanceID={snap.InstanceID}, origin={snap.OriginGrid}, " +
                        $"owner={snap.OriginContainerOwnerId}). Item is LOST.");
                }
            }
        }
    }

    _snapshots.Clear();
    _placements.Clear();
    _inHandItems.Clear();
    _isTransactionActive = false;

    if (_inventoryUI != null)
        _inventoryUI.ForceRefresh();
}
private bool RestoreItemToBackpackContents(InventoryItem item, uint ownerId, int x, int y)
{
    if (item == null || ownerId == 0 || _inventoryUI == null)
        return false;

    // Используем публичный метод BackpackManager для поиска владельца в сериализованных данных (закрытые окна любой глубины)
    var owner = _inventoryUI.BackpackManager.FindBackpackItemByID(ownerId.ToString());
    if (owner == null)
        return false;

    var contents = owner.GetBackpackContentsRaw();
    if (contents != null && InventoryItem.ContainsDescendantRecursive(contents, item.InstanceID))
        return true;

    var saved = item.ToSaveData(x, y);
    if (contents == null)
    {
        contents = new List<SavedItem>();
        owner.ReplaceBackpackContents(contents);
    }

    for (int i = 0; i < contents.Count; i++)
    {
        if (contents[i].InstanceID == item.InstanceID)
        {
            contents[i] = saved;
            return true;
        }
    }

    contents.Add(saved);
    return true;
}
private bool ValidateSwapFinalGeometry(params InventoryController[] ctrls)
{
    foreach (var ctrl in ctrls)
    {
        if (ctrl == null || ctrl.IsDisposed) continue;
        for (int y = 0; y < ctrl.Height; y++)
            for (int x = 0; x < ctrl.Width; x++)
            {
                var it = ctrl.GetItemAt(x, y);
                if (it == null) continue;
                var (rx, ry) = ctrl.FindItemRootPosition(it.InstanceID);
                if (rx == -1)
                {
                    Debug.LogError($"[SwapGeometry] Cell ({x},{y}) references item {it.InstanceID} without root in '{ctrl.SaveID}'");
                    return false;
                }
                var sz = it.CurrentSize;
                if (rx + sz.x > ctrl.Width || ry + sz.y > ctrl.Height)
                {
                    Debug.LogError($"[SwapGeometry] Item {it.InstanceID} root ({rx},{ry}) size {sz.x}x{sz.y} exceeds grid {ctrl.Width}x{ctrl.Height} in '{ctrl.SaveID}'");
                    return false;
                }
                if (x < rx || x >= rx + sz.x || y < ry || y >= ry + sz.y)
                {
                    Debug.LogError($"[SwapGeometry] Cell ({x},{y}) outside footprint of item {it.InstanceID} (root {rx},{ry}) in '{ctrl.SaveID}'");
                    return false;
                }
            }
    }
    return true;
}
    private bool TryPlaceItemInController(
        InventoryItem item, InventoryController controller, int x, int y, out string errorMessage)
    {
        errorMessage = string.Empty;

        // Точная позиция.
        if (InventoryValidationService.GridSpaceCheck(controller, item, x, y))
        {
            if (controller.PlaceExistingItem(item, x, y))
            {
                _placements.Add(new PlacementRecord(item, controller, x, y));
                _inHandItems.Remove(item.InstanceID);
                return true;
            }
        }

        // ═══ ФИКС «no free space при пустых ячейках»: строгий перебор ПУСТЫХ
        // ячеек (PlaceExistingItem не стекует), с попыкой поворота. ═══
        int origAngle = item.RotationAngle;
        for (int attempt = 0; attempt < 2; attempt++)
        {
            if (controller.PlaceExistingItemInFirstFreeSlot(item))
            {
                var (fx, fy) = controller.FindItemRootPosition(item.InstanceID);
                _placements.Add(new PlacementRecord(item, controller, fx, fy));
                _inHandItems.Remove(item.InstanceID);
                return true;
            }
            if (item.Data == null || !item.Data.CanRotate) break;
            var sz = item.CurrentSize;
            if (sz.x == sz.y) break;
            item.Rotate();
        }
        item.RestoreRotationState(origAngle);

        errorMessage = $"no free space in controller '{controller.SaveID}'";
        return false;
    }

    private bool TryPlaceItemInPlayerGrids(
        InventoryItem item, InventoryController preferenceController,
        int preferredX, int preferredY, out string errorMessage)
    {
        errorMessage = string.Empty;

        if (preferenceController != null &&
            InventoryValidationService.GridSpaceCheck(preferenceController, item, preferredX, preferredY))
        {
            if (preferenceController.PlaceExistingItem(item, preferredX, preferredY))
            {
                _placements.Add(new PlacementRecord(item, preferenceController, preferredX, preferredY));
                _inHandItems.Remove(item.InstanceID);
                return true;
            }
        }

        if (preferenceController != null)
        {
            int origAngle = item.RotationAngle;
            if (InventoryValidationService.FindFreeSpace(preferenceController, item, out int fx, out int fy))
            {
                if (preferenceController.PlaceExistingItem(item, fx, fy))
                {
                    _placements.Add(new PlacementRecord(item, preferenceController, fx, fy));
                    _inHandItems.Remove(item.InstanceID);
                    return true;
                }
                item.RestoreRotationState(origAngle);
            }
        }

        return TryPlaceItemInAnyPlayerGrid(item, out errorMessage);
    }

 private bool TryPlaceItemInAnyPlayerGrid(InventoryItem item, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_inventoryUI == null || item == null) return false;

    var grids = new List<(GridType, InventoryController)>
    {
        (GridType.Pockets, _inventoryUI.GetControllerForGrid(GridType.Pockets)),
        (GridType.Pocket2, _inventoryUI.GetControllerForGrid(GridType.Pocket2)),
        (GridType.Backpack, _inventoryUI.GetControllerForGrid(GridType.Backpack)),
    };

    if (_inventoryUI.BackpackManager != null)
    {
        foreach (var w in _inventoryUI.BackpackManager.OpenWindows)
        {
            if (w != null && w.Controller != null)
                grids.Add((GridType.Container, w.Controller));
        }
    }

    // ═══ БАГ 3c ФИКС: при активном луте включить контроллер окружения/лута
    // в candidates для relocation. Без этого свап в окружении отклоняется
    // с "no free space in any player grid" при наличии места в окружении. ═══
    if (_inventoryUI.IsLooting && _inventoryUI.ActiveContainerController != null)
    {
        var lootCtrl = _inventoryUI.ActiveContainerController;
        bool already = false;
        for (int i = 0; i < grids.Count; i++)
            if (grids[i].Item2 == lootCtrl) { already = true; break; }
        if (!already)
            grids.Add((GridType.Container, lootCtrl));
    }

    foreach (var (gridType, ctrl) in grids)
    {
        if (ctrl == null) continue;

        if (!_inventoryUI.BackpackManager.CanPlaceUnfoldedBackpackIntoController(ctrl, item, out _))
            continue;

        int origAngle = item.RotationAngle;
        if (InventoryValidationService.FindFreeSpace(ctrl, item, out int fx, out int fy))
        {
            if (ctrl.PlaceExistingItem(item, fx, fy))
            {
                _placements.Add(new PlacementRecord(item, ctrl, fx, fy));
                _inHandItems.Remove(item.InstanceID);
                return true;
            }
            item.RestoreRotationState(origAngle);
        }
    }

    errorMessage = "no free space in any player grid";
    return false;
}
    private uint GetContainerOwnerId(UI_Item uiItem)
    {
        if (uiItem == null || uiItem.GridType != GridType.Container) return 0u;
        var ctrl = uiItem.BoundController;
        if (ctrl == null || _inventoryUI == null || _inventoryUI.BackpackManager == null) return 0u;
        var win = _inventoryUI.BackpackManager.FindWindowByController(ctrl);
        if (win != null && uint.TryParse(win.BackpackInstanceID, out uint id)) return id;
        return 0u;
    }


    private InventoryController GetControllerForUI(UI_Item uiItem)
    {
        if (uiItem == null || _inventoryUI == null) return null;
        if (uiItem.GridType == GridType.Container && uiItem.BoundController != null)
            return uiItem.BoundController;
        return _inventoryUI.GetControllerForGrid(uiItem.GridType);
    }

    private (int x, int y) FindItemPositionInController(InventoryController ctrl, InventoryItem item)
    {
        if (ctrl == null || item == null) return (-1, -1);
        return ctrl.FindItemRootPosition(item.InstanceID);
    }

    private (GridType? grid, int x, int y) FindItemLocationInPlayerGrids(InventoryItem item)
    {
        if (item == null || _inventoryUI == null) return (null, 0, 0);
        uint id = item.InstanceID;
        var grids = new[]
        {
            (GridType.Pockets, _inventoryUI.GetControllerForGrid(GridType.Pockets)),
            (GridType.Pocket2, _inventoryUI.GetControllerForGrid(GridType.Pocket2)),
            (GridType.Backpack, _inventoryUI.GetControllerForGrid(GridType.Backpack)),
        };
        foreach (var (type, ctrl) in grids)
        {
            if (ctrl == null) continue;
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var at = ctrl.GetItemAt(x, y);
                    if (at != null && at.InstanceID == id)
                        return (type, x, y);
                }
        }
        return (null, 0, 0);
    }

    private bool IsItemAnywhereInController(InventoryController ctrl, InventoryItem item)
    {
        if (ctrl == null || item == null) return false;
        uint id = item.InstanceID;
        for (int y = 0; y < ctrl.Height; y++)
            for (int x = 0; x < ctrl.Width; x++)
            {
                var at = ctrl.GetItemAt(x, y);
                if (at != null && at.InstanceID == id) return true;
            }
        return false;
    }

    private void RemoveItemFromEverywhere(InventoryItem item)
    {
        if (item == null || _inventoryUI == null) return;
        uint id = item.InstanceID;

        var grids = new[]
        {
            _inventoryUI.GetControllerForGrid(GridType.Pockets),
            _inventoryUI.GetControllerForGrid(GridType.Pocket2),
            _inventoryUI.GetControllerForGrid(GridType.Backpack),
        };
        foreach (var ctrl in grids)
        {
            if (ctrl == null) continue;
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var at = ctrl.GetItemAt(x, y);
                    if (at != null && at.InstanceID == id)
                    {
                        ctrl.RemoveItem(item);
                        return;
                    }
                }
        }

        if (_inventoryUI.BackpackManager != null)
        {
            foreach (var w in _inventoryUI.BackpackManager.OpenWindows)
            {
                var ctrl = w != null ? w.Controller : null;
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var at = ctrl.GetItemAt(x, y);
                        if (at != null && at.InstanceID == id)
                        {
                            ctrl.RemoveItem(item);
                            return;
                        }
                    }
            }
        }

        foreach (var slot in _cachedSlots)
        {
            if (slot != null && slot.EquippedItem != null && slot.EquippedItem.InstanceID == id)
            {
                slot.SetEquippedItem(null);
                return;
            }
        }
    }

    private K_EquipmentSlotUI FindSlotHoldingItem(InventoryItem item)
    {
        if (item == null) return null;
        EnsureSlotsCached();
        foreach (var slot in _cachedSlots)
        {
            if (slot != null && slot.EquippedItem != null && slot.EquippedItem.InstanceID == item.InstanceID)
                return slot;
        }
        return null;
    }

    private InventoryItem FindItemByInstanceId(uint instanceId)
    {
        if (instanceId == 0 || _inventoryUI == null) return null;

        var grids = new[]
        {
            _inventoryUI.GetControllerForGrid(GridType.Pockets),
            _inventoryUI.GetControllerForGrid(GridType.Pocket2),
            _inventoryUI.GetControllerForGrid(GridType.Backpack),
        };
        foreach (var ctrl in grids)
        {
            if (ctrl == null) continue;
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var at = ctrl.GetItemAt(x, y);
                    if (at != null && at.InstanceID == instanceId) return at;
                }
        }

        if (_inventoryUI.BackpackManager != null)
        {
            foreach (var w in _inventoryUI.BackpackManager.OpenWindows)
            {
                var ctrl = w != null ? w.Controller : null;
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var at = ctrl.GetItemAt(x, y);
                        if (at != null && at.InstanceID == instanceId) return at;
                    }
            }
        }

        EnsureSlotsCached();
        foreach (var slot in _cachedSlots)
        {
            if (slot != null && slot.EquippedItem != null && slot.EquippedItem.InstanceID == instanceId)
                return slot.EquippedItem;
        }
        return null;
    }

    private K_EquipmentSlotUI FindEquipmentSlot(EquipmentSlotType slotType)
    {
        EnsureSlotsCached();
        foreach (var slot in _cachedSlots)
        {
            if (slot != null && slot.SlotType == slotType) return slot;
        }
        return null;
    }

    private K_EquipmentSlotUI GetEquipSlot(EquipmentSlotType slotType)
    {
        EnsureSlotsCached();
        K_EquipmentSlotUI fallback = null;
        foreach (var slot in _cachedSlots)
        {
            if (slot == null || slot.SlotType != slotType) continue;
            if (!slot.IsOccupied) return slot;
            if (fallback == null) fallback = slot;
        }
        return fallback;
    }

    private void EnsureInitialized()
    {
        if (_inventoryUI == null)
            _inventoryUI = FindFirstObjectByType<K_InventoryUI>();
        EnsureSlotsCached();
    }

    private void EnsureSlotsCached()
    {
        if (_slotsCached) return;
        _slotsCached = true;
        _cachedSlots.Clear();
        var slots = FindObjectsByType<K_EquipmentSlotUI>(FindObjectsSortMode.None);
        foreach (var slot in slots)
            if (slot != null) _cachedSlots.Add(slot);
    }
}
}