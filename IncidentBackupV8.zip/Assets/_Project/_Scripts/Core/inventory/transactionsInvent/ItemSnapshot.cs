﻿// ItemSnapshot.cs — fixed per audit (no class references, pure primitives)
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
/// <summary>
/// Легковесный неизменяемый снапшот состояния InventoryItem на момент
/// старта транзакции. readonly struct -> нулевые аллокации на heap,
/// копирование по значению (zero-GC).
///
/// АУДИТ-ФИКС: структура хранит ТОЛЬКО примитивы и enum'ы.
/// Никаких ссылок на InventoryItem (class), InventoryController (class),
/// K_EquipmentSlotUI (MonoBehaviour). Rollback находит контроллер/слот
/// по реестру через InstanceID, а не через захваченные ссылки — это
/// исключает MissingReferenceException при откатах после закрытия окон
/// или Dispose контроллера.
/// </summary>
public readonly struct ItemSnapshot
{
    // ── Идентификация предмета ──
    public readonly uint InstanceID;

    // ── Исходное размещение в сетке (если не из слота экипировки) ──
    public readonly GridType OriginGrid;
    public readonly int OriginX;
    public readonly int OriginY;

    // ── ФИКС БАГОВ 1/4: для OriginGrid == Container — InstanceID рюкзака-владельца
    //    окна (0 = не контейнер). Rollback по этому ID находит живой контроллер
    //    окна через BackpackManager.GetLiveController, вместо слепого высыпания
    //    предмета в карманы игрока. ──
    public readonly uint OriginContainerOwnerId;

    // ── Исходное размещение в слоте экипировки ──
    public readonly bool IsFromEquipmentSlot;
    public readonly EquipmentSlotType EquipmentSlotType;

    // ── Визуальное состояние для отката ──
    public readonly int RotationAngle;
    public readonly bool IsFolded;

    public ItemSnapshot(
        uint instanceID,
        GridType originGrid,
        int originX,
        int originY,
        uint originContainerOwnerId,
        int rotationAngle,
        bool isFolded,
        bool isFromEquipmentSlot,
        EquipmentSlotType equipmentSlotType)
    {
        InstanceID = instanceID;
        OriginGrid = originGrid;
        OriginX = originX;
        OriginY = originY;
        OriginContainerOwnerId = originContainerOwnerId;
        RotationAngle = rotationAngle;
        IsFolded = isFolded;
        IsFromEquipmentSlot = isFromEquipmentSlot;
        EquipmentSlotType = equipmentSlotType;
    }

    /// <summary>Снапшот валиден, если у нас есть InstanceID &gt; 0.</summary>
    public bool IsValid => InstanceID > 0;

    /// <summary>Удобный фабричный метод для предмета из обычной сетки.</summary>
    public static ItemSnapshot FromGrid(
        InventoryItem item,
        GridType grid,
        int x,
        int y,
        uint containerOwnerId = 0u)
    {
        return new ItemSnapshot(
            instanceID: item != null ? item.InstanceID : 0u,
            originGrid: grid,
            originX: x,
            originY: y,
            originContainerOwnerId: grid == GridType.Container ? containerOwnerId : 0u,
            rotationAngle: item != null ? item.RotationAngle : 0,
            isFolded: item != null ? item.IsFolded : false,
            isFromEquipmentSlot: false,
            equipmentSlotType: default);
    }

    /// <summary>Удобный фабричный метод для предмета из слота экипировки.</summary>
    public static ItemSnapshot FromEquipmentSlot(
        InventoryItem item,
        EquipmentSlotType slotType)
    {
        return new ItemSnapshot(
            instanceID: item != null ? item.InstanceID : 0u,
            originGrid: default,
            originX: 0,
            originY: 0,
            originContainerOwnerId: 0u,
            rotationAngle: item != null ? item.RotationAngle : 0,
            isFolded: item != null ? item.IsFolded : false,
            isFromEquipmentSlot: true,
            equipmentSlotType: slotType);
    }
}
}