﻿// === Source: original file lines 11255-11492 ===
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public static class InventoryValidationService
    {
        // ═══════════════════════════════════════════════════════════════
        //  1. TYPE MATCH CHECK
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Проверка соответствия типа предмета слоту экипировки.
        /// Возвращает true, если item может быть экипирован в слот заданного типа.
        ///
        /// Логика идентична K_EquipmentSlotUI.ValidateItemForSlot, но вынесена
        /// в чистую функцию, чтобы транзакционный слой мог её использовать
        /// без ссылки на конкретный UI-слот.
        /// </summary>
        public static bool TypeMatchCheck(InventoryItem item, EquipmentSlotType slotType)
        {
            if (item == null || item.Data == null) return false;
            return slotType switch
            {
                EquipmentSlotType.Primary => item.Type == ItemType.Weapon && !item.Data.IsPistol && !item.Data.IsMelee,
                EquipmentSlotType.Pistol => item.Type == ItemType.Weapon && item.Data.IsPistol,
                EquipmentSlotType.Melee => item.Data.IsMelee,
                EquipmentSlotType.Backpack => item.Data.IsBackpack,
                _ => false
            };
        }

        /// <summary>
        /// Определяет подходящий EquipmentSlotType для предмета.
        /// Возвращает false, если предмет не может быть экипирован ни в один слот
        /// (например, патроны, медикаменты, расходники).
        /// </summary>
        public static bool TryDetermineEquipSlotType(InventoryItem item, out EquipmentSlotType slotType)
        {
            slotType = default;
            if (item?.Data == null) return false;

            switch (item.Type)
            {
                case ItemType.Weapon:
                    slotType = item.Data.IsPistol ? EquipmentSlotType.Pistol : EquipmentSlotType.Primary;
                    return true;

                case ItemType.Backpack:
                    slotType = EquipmentSlotType.Backpack;
                    return true;

                default:
                    if (item.Data.IsMelee)
                    {
                        slotType = EquipmentSlotType.Melee;
                        return true;
                    }
                    return false;
            }
        }

        // ═══════════════════════════════════════════════════════════════
        //  2. GRID SPACE CHECK
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Проверка физической вместимости предмета на координатах сетки.
        /// Делегирует в controller.CanPlaceItem — это правильная проверка
        /// с учётом габаритов CurrentSize (X×Y) и границ сетки.
        ///
        /// ВАЖНО: CanPlaceItem разрешает stack-merge. Если вам нужна строгая
        /// проверка "только пустые ячейки" (для swap), используйте
        /// GridSpaceCheckIgnoring с указанием предмета-цели.
        /// </summary>
        public static bool GridSpaceCheck(
            InventoryController controller,
            InventoryItem item,
            int x,
            int y)
        {
            if (controller == null || item == null || item.Data == null) return false;
            if (x < 0 || y < 0) return false;

            var size = item.CurrentSize;
            if (size.x <= 0 || size.y <= 0) return false;
            if (x + size.x > controller.Width || y + size.y > controller.Height) return false;

            return controller.CanPlaceItem(item, x, y);
        }

        /// <summary>
        /// Grid Space Check с игнорированием указанного предмета.
        /// Используется в транзакциях свапа: мы проверяем, влезет ли item A
        /// на место item B, при этом B ещё не удалён — но мы игнорируем B
        /// в проверке, потому что B вот-вот будет убран.
        ///
        /// Реализация: ручной обход ячеек, поскольку публичный API
        /// InventoryController.CanPlaceItem не принимает ignoredItem.
        /// </summary>
        public static bool GridSpaceCheckIgnoring(
            InventoryController controller,
            InventoryItem item,
            int x,
            int y,
            InventoryItem ignoredItem)
        {
            if (controller == null || item == null || item.Data == null) return false;
            if (x < 0 || y < 0) return false;

            var size = item.CurrentSize;
            if (size.x <= 0 || size.y <= 0) return false;
            if (x + size.x > controller.Width || y + size.y > controller.Height) return false;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    var occupant = controller.GetItemAt(x + dx, y + dy);
                    if (occupant == null) continue;
                    if (ReferenceEquals(occupant, ignoredItem)) continue;
                    if (ReferenceEquals(occupant, item)) continue; // сам item — OK
                    return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Поиск свободного места для предмета в сетке контроллера.
        /// Сначала пробует текущую ориентацию, затем (если CanRotate и предмет
        /// неквадратный) — повёрнутую.
        ///
        /// ВАЖНО: если найдено место в повёрнутой ориентации — item ОСТАЁТСЯ
        /// повёрнутым (вызывается item.Rotate()). Вызывающий код должен либо
        /// зафиксировать этот поворот (commit), либо вызвать item.Rotate()
        /// снова для отката.
        /// </summary>
        public static bool FindFreeSpace(
            InventoryController controller,
            InventoryItem item,
            out int x,
            out int y)
        {
            x = 0;
            y = 0;
            if (controller == null || item == null || item.Data == null) return false;

            // 1. Пробуем текущую ориентацию
            if (FindFreeCellExact(controller, item, out x, out y))
                return true;

            // 2. Пробуем повёрнутую ориентацию (если CanRotate и предмет неквадратный)
            if (item.Data.CanRotate && item.CurrentSize.x != item.CurrentSize.y)
            {
                item.Rotate();
                if (FindFreeCellExact(controller, item, out x, out y))
                    return true;
                item.Rotate(); // возвращаем к исходной ориентации
            }

            return false;
        }

        private static bool FindFreeCellExact(
            InventoryController controller,
            InventoryItem item,
            out int x,
            out int y)
        {
            x = 0;
            y = 0;
            var size = item.CurrentSize;
            if (size.x <= 0 || size.y <= 0) return false;

            for (int py = 0; py <= controller.Height - size.y; py++)
            {
                for (int px = 0; px <= controller.Width - size.x; px++)
                {
                    if (GridSpaceCheck(controller, item, px, py))
                    {
                        x = px;
                        y = py;
                        return true;
                    }
                }
            }
            return false;
        }

        // ═══════════════════════════════════════════════════════════════
        //  3. NESTING / INCEPTION CHECK
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// АУДИТ-ФИКС: подготавливает снимки содержимого рюкзаков к валидации.
        ///
        /// Раньше InventoryItem.ContainsDescendant сам вызывал
        /// SyncSerializedFromController() внутри проверки. Это значило, что
        /// Validation мутировал состояние backpack-снапшота — нарушение
        /// чистоты validation-слоя.
        ///
        /// Теперь контракт такой:
        /// 1. Перед валидацией транзакции вызывающий код ОБЯЗАН вызвать
        ///    PrepareSnapshotsForValidation() для всех рюкзаков, участвующих
        ///    в транзакции.
        /// 2. NestingCheck использует только read-only ContainsDescendantStrict —
        ///    никаких побочных эффектов.
        /// </summary>
        public static void PrepareSnapshotsForValidation(params InventoryItem[] backpacks)
        {
            if (backpacks == null) return;
            foreach (var bp in backpacks)
            {
                if (bp == null || bp.Data == null || !bp.Data.IsBackpack) continue;
                bp.SyncBackpackContentsIfDirty();
            }
        }

        /// <summary>
        /// Запрет на помещение контейнера (рюкзака) внутрь самого себя
        /// или в собственные дочерние контейнеры.
        ///
        /// АУДИТ-ФИКС: теперь это чистая read-only функция. Никаких побочных
        /// эффектов, никакого SyncSerializedFromController внутри. Если
        /// контроллер рюкзака candidate ещё не синхронизирован — это проблема
        /// вызывающего кода, который должен был вызвать
        /// PrepareSnapshotsForValidation() ДО проверки.
        ///
        /// Сценарий: мы хотим поместить candidate "внутрь" container
        /// (например, перетащить candidate на иконку container или
        /// экипировать candidate в слот, занимаемый container).
        ///
        /// Возвращает true, если операция безопасна (нет цикла).
        /// Возвращает false, если candidate — это container, или если
        /// container содержится внутри candidate (что создало бы цикл).
        ///
        /// Если candidate — не рюкзак, цикл невозможен → true.
        /// </summary>
        public static bool NestingCheck(InventoryItem container, InventoryItem candidate)
        {
            if (container == null || candidate == null) return true;
            if (candidate.Data == null || !candidate.Data.IsBackpack) return true;

            // candidate не должен быть равен container
            if (candidate.InstanceID == container.InstanceID) return false;

            // АУДИТ-ФИКС: read-only проверка без побочных эффектов.
            // Синхронизация должна быть сделана вызывающим кодом заранее
            // через PrepareSnapshotsForValidation().
            if (candidate.ContainsDescendantStrict(container.InstanceID)) return false;

            return true;
        }

        /// <summary>
        /// Комбинированная проверка: NestingCheck в обоих направлениях.
        /// Используется для swap-операций, где оба предмета могут быть рюкзаками.
        ///
        /// Возвращает true, если swap безопасен (ни один не является потомком другого).
        /// </summary>
        public static bool NestingCheckBidirectional(InventoryItem a, InventoryItem b)
        {
            if (a == null || b == null) return true;
            if (a.InstanceID == b.InstanceID) return false;

            // Проверяем оба направления
            if (!NestingCheck(container: b, candidate: a)) return false;
            if (!NestingCheck(container: a, candidate: b)) return false;

            return true;
        }
    }
}
