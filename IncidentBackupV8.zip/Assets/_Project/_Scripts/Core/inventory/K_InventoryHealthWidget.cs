using K_Incident.Core;
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// ����� �������� ��� ������ ���������.
/// ���������� �� �� ������ ��� � K_HealthWidget (������� �����),
/// �� ��� HUD-������ (����, fade, �������).
/// ������ ������������� �� ������� K_HealthSystem / K_VitalitySystem / K_WeightManager.
///
/// ��������� � UNITY:
/// 1. ������ ������ � ��������� ��� ����� (GameObject � Image-�����)
/// 2. ������� ��������� ����� (7 Image ��� ������ ���� + ������ ��������)
/// 3. ������ ���� ������ �� ������ ������
/// 4. � ���������� ��������:
///    - K_HealthSystem
///    - K_VitalitySystem
///    - K_CoagulantItem (�����������)
///    - K_WeightManager (�����������)
///    - 7 Image ��� ������ ����
///    - ������ �������� (�����, �����, ������������ � �.�.)
///    - ������ ��������� (������)
///    - Gradients ��� ���������
/// </summary>
public class K_InventoryHealthWidget : MonoBehaviour
{
    #region System References

    [Header("System References")]
    [SerializeField] private K_HealthSystem _healthSystem;
    [SerializeField] private K_VitalitySystem _vitalitySystem;
    [SerializeField] private K_CoagulantItem _coagulantItem;
    [SerializeField] private K_WeightManager _weightManager;

    #endregion

    #region Health Doll

    [Header("Health Doll (Segments)")]
    [SerializeField] private Image _headImg;
    [SerializeField] private Image _torsoImg;
    [SerializeField] private Image _stomachImg;
    [SerializeField] private Image _leftArmImg;
    [SerializeField] private Image _rightArmImg;
    [SerializeField] private Image _leftLegImg;
    [SerializeField] private Image _rightLegImg;
    [SerializeField] private Gradient _healthGradient;

    #endregion

    #region Status Icons

    [Header("Metabolism & Status Icons")]
    [SerializeField] private Gradient _statusGradient;
    [SerializeField] private Gradient _bleedingGradient;
    [SerializeField] private Gradient _hungerGradient;
    [SerializeField] private Gradient _thirstGradient;
    [SerializeField] private Gradient _overloadGradient;

    [Space]
    [SerializeField] private Image _iconHunger;
    [SerializeField] private Image _iconThirst;
    [SerializeField] private Image _iconRadiation;
    [SerializeField] private Image _iconCold;
    [SerializeField] private Image _iconOverload;
    [SerializeField] private Image _iconBleeding;
    [SerializeField] private Image _iconLaceration;
    [SerializeField] private Image _iconHangover;
    [SerializeField] private Image _iconDrunk;
    [SerializeField] private Image _iconStimOn;
    [SerializeField] private Image _iconStimOff;
    [SerializeField] private Image _iconCoagulant;

    #endregion

    #region Fracture Icons

    [Header("Fracture Icons")]
    [SerializeField] private Image[] _fractureIcons;

    #endregion

    #region Cache

    private Image[] _healthDollImages;

    #endregion

    #region Unity Lifecycle

    private void Awake()
    {
        _healthDollImages = new Image[]
        {
            _headImg, _torsoImg, _stomachImg,
            _leftArmImg, _rightArmImg,
            _leftLegImg, _rightLegImg
        };
    }

    private void Start()
    {
        if (_healthSystem == null)
            _healthSystem = FindAnyObjectByType<K_HealthSystem>();
        if (_vitalitySystem == null)
            _vitalitySystem = FindAnyObjectByType<K_VitalitySystem>();
        if (_coagulantItem == null)
            _coagulantItem = FindAnyObjectByType<K_CoagulantItem>();
        if (_weightManager == null)
            _weightManager = FindAnyObjectByType<K_WeightManager>();

        // ���� ��� #50: ������ ����������� ���� ����
        // (������ ����� ����������� ��� identical FindAnyObjectByType<K_HealthSystem>/K_VitalitySystem>)

        if (_healthSystem == null || _vitalitySystem == null)
        {
            Debug.LogWarning("[K_InventoryHealthWidget] Core systems missing even after auto-find. " +
                $"HealthSystem={_healthSystem != null}, VitalitySystem={_vitalitySystem != null}. " +
                "Assign them in Inspector or ensure they exist in scene.");
        }

        InitializeFractureIcons();
        RefreshAll();
    }

    private void OnEnable()
    {
        if (_healthSystem != null) _healthSystem.OnHealthChanged += RefreshHealth;
        if (_vitalitySystem != null)
        {
            _vitalitySystem.OnMetabolismChanged += RefreshMetabolism;
            _vitalitySystem.OnStimulatorChanged += RefreshMetabolism;
            _vitalitySystem.OnHangoverChanged += RefreshMetabolism;
            _vitalitySystem.OnColdExposureChanged += RefreshMetabolism;
            _vitalitySystem.OnOverloadChanged += RefreshMetabolism;
        }
        if (_weightManager != null)
            _weightManager.OnWeightChanged += RefreshMetabolism;

        // ����� ��������� ��� ��������� (���������� ���������)
        RefreshAll();
    }

    private void OnDisable()
    {
        if (_healthSystem != null) _healthSystem.OnHealthChanged -= RefreshHealth;
        if (_vitalitySystem != null)
        {
            _vitalitySystem.OnMetabolismChanged -= RefreshMetabolism;
            _vitalitySystem.OnStimulatorChanged -= RefreshMetabolism;
            _vitalitySystem.OnHangoverChanged -= RefreshMetabolism;
            _vitalitySystem.OnColdExposureChanged -= RefreshMetabolism;
            _vitalitySystem.OnOverloadChanged -= RefreshMetabolism;
        }
        if (_weightManager != null)
            _weightManager.OnWeightChanged -= RefreshMetabolism;
    }

    #endregion

    #region Refresh

    public void RefreshAll()
    {
        RefreshHealth();
        RefreshMetabolism();
    }

    private void RefreshHealth()
    {
        UpdateHealthUI();
        UpdateFractureIcons();
        UpdateCoagulantIcon();
    }

    private void RefreshMetabolism()
    {
        UpdateMetabolismUI();
        UpdateFractureIcons();
        UpdateCoagulantIcon();
    }

    #endregion

    #region Health Doll UI

    private void UpdateHealthUI()
    {
        if (_healthSystem == null || _healthGradient == null) return;

        UpdateSegmentColor(_headImg, _healthSystem.HeadHP, _healthSystem.BaseHeadHP);
        UpdateSegmentColor(_torsoImg, _healthSystem.TorsoHP, _healthSystem.BaseTorsoHP);
        UpdateSegmentColor(_stomachImg, _healthSystem.StomachHP, _healthSystem.BaseStomachHP);
        UpdateSegmentColor(_leftArmImg, _healthSystem.LeftArmHP, _healthSystem.BaseLeftArmHP);
        UpdateSegmentColor(_rightArmImg, _healthSystem.RightArmHP, _healthSystem.BaseRightArmHP);
        UpdateSegmentColor(_leftLegImg, _healthSystem.LeftLegHP, _healthSystem.BaseLeftLegHP);
        UpdateSegmentColor(_rightLegImg, _healthSystem.RightLegHP, _healthSystem.BaseRightLegHP);
    }

    private void UpdateSegmentColor(Image img, float current, float baseMax)
    {
        if (img == null || baseMax <= 0f || _healthGradient == null) return;
        float ratio = Mathf.Clamp01(current / baseMax);
        Color c = _healthGradient.Evaluate(ratio);
        img.enabled = true;
        img.color = new Color(c.r, c.g, c.b, 1f);
    }

    #endregion

    #region Fractures

    private void InitializeFractureIcons()
    {
        if (_fractureIcons == null) return;
        foreach (var icon in _fractureIcons)
        {
            if (icon != null) icon.gameObject.SetActive(false);
        }
    }

    private void UpdateFractureIcons()
    {
        if (_healthSystem == null || _fractureIcons == null) return;
        int count = _healthSystem.FractureCount;
        for (int i = 0; i < _fractureIcons.Length; i++)
        {
            if (_fractureIcons[i] != null)
                _fractureIcons[i].gameObject.SetActive(i < count);
        }
    }

    #endregion

    #region Coagulant

    private void UpdateCoagulantIcon()
    {
        if (_coagulantItem == null || _iconCoagulant == null) return;
        bool show = _coagulantItem.ShouldShowIcon();
        _iconCoagulant.gameObject.SetActive(show);
        if (show)
        {
            bool hasDmg = _coagulantItem.HasDamagedSegments();
            _iconCoagulant.color = new Color(1f, 1f, 1f, hasDmg ? 1f : 0.5f);
        }
    }

    #endregion

    #region Metabolism UI

    private void UpdateMetabolismUI()
    {
        if (_vitalitySystem == null) return;

        SafeUpdateIcon(_iconHunger, _vitalitySystem.Icon_Hunger, _vitalitySystem.Hunger / 100f, _hungerGradient);
        SafeUpdateIcon(_iconThirst, _vitalitySystem.Icon_Thirst, _vitalitySystem.Thirst / 100f, _thirstGradient);
        SafeUpdateIcon(_iconRadiation, _vitalitySystem.Icon_Radiation, 1f - (_vitalitySystem.Radiation / 100f), _healthGradient);

        if (_vitalitySystem.Icon_Bleeding > 0)
            SafeUpdateIcon(_iconBleeding, true, _vitalitySystem.Icon_Bleeding / 3f, _bleedingGradient);
        else
            SafeUpdateIcon(_iconBleeding, false);

        SafeUpdateIcon(_iconLaceration, _vitalitySystem.Icon_Laceration);
        SafeUpdateIcon(_iconStimOn, _vitalitySystem.Icon_StimOn);
        SafeUpdateIcon(_iconStimOff, _vitalitySystem.Icon_StimOff);
        SafeUpdateIcon(_iconHangover, _vitalitySystem.Icon_Hangover);
        SafeUpdateIcon(_iconCold, _vitalitySystem.Icon_Cold);

        if (_weightManager != null)
        {
            float ratio = _weightManager.GetCurrentWeightRatio();
            bool overloaded = ratio >= 0.9f;
            if (overloaded)
            {
                float norm = Mathf.Clamp01(Mathf.InverseLerp(0.9f, 1.1f, ratio));
                SafeUpdateIcon(_iconOverload, true, norm, _overloadGradient);
            }
            else
                SafeUpdateIcon(_iconOverload, false);
        }
        else
            SafeUpdateIcon(_iconOverload, _vitalitySystem.Icon_Overload);

        SafeUpdateIcon(_iconDrunk, _vitalitySystem.Icon_Drunk);
    }

    private void SafeUpdateIcon(Image img, bool isActive, float? colorT = null, Gradient customGradient = null)
    {
        if (img == null) return;
        if (img.gameObject.activeSelf != isActive)
            img.gameObject.SetActive(isActive);
        if (isActive && colorT.HasValue)
        {
            Gradient g = customGradient != null ? customGradient : _statusGradient;
            if (g != null)
                img.color = g.Evaluate(Mathf.Clamp01(colorT.Value));
        }
    }

    #endregion
}
