﻿using K_Incident.Core.Inventory;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class K_ContextMenu : MonoBehaviour
{
    #region Singleton

    public static K_ContextMenu Instance { get; private set; }

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            gameObject.SetActive(false);
            return;
        }
        Instance = this;
        SetupInternals();
    }

    private void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }

    #endregion

    #region Style Configuration

    [Header("Style Configuration")]
    [SerializeField, Tooltip("Ассет стиля контекстного меню. Создайте через Create > K Context Menu Style " +
        "и перетащите сюда. Если null — используются дефолтные значения. " +
        "Этот ассет редактируется в Inspector в любое время, даже вне Play-режима!")]
    private K_ContextMenuStyle _style;

    private K_ContextMenuStyle S => _style != null ? _style : (_styleDefault ?? (_styleDefault = K_ContextMenuStyle.Default()));
    private static K_ContextMenuStyle _styleDefault;

    public void SetStyle(K_ContextMenuStyle style) => _style = style;
    public K_ContextMenuStyle GetStyle() => S;

    #endregion

    #region Internal

    private RectTransform _rectTransform;
    private CanvasGroup _canvasGroup;
    private Canvas _canvas;
    private RectTransform _contentRect;
    private List<GameObject> _spawnedItems = new List<GameObject>();
    private Coroutine _hideCoroutine;
    private Coroutine _rebuildCoroutine;
    private InventoryItem _currentItem;
    private K_InventoryUI _currentInventoryUI;
    private K_EquipmentSlotUI _currentEquipmentSlot;
    private bool _isShowingDescription;
    private bool _isInitialized;

    // ФИКС: Сохраняем последнюю позицию курсора для корректного репозиционирования
    private Vector2 _lastScreenPosition;

    /// <summary>Список записей текущего меню — нужен чтобы определить последнюю кнопку.</summary>
    private List<MenuEntry> _currentEntries = new List<MenuEntry>();

    #endregion

    #region Context Action Definition

    public enum ContextAction
    {
        InspectWeapon, ReloadMagazine, UnloadMagazine, LoadMagazine,
        CheckMagazine, ChamberRound, ClearChamber, ToggleFireMode, CockWeapon,
        Eat, Drink, Use,
        ApplyToSelf,
        Equip, Unequip,
        Fold, Unfold, OpenBackpack, CloseBackpack, EmptyBackpack,
        Inspect, Drop, Description, Discard, Split,
        Repair,
        TransferAmmo,
    }

    private struct MenuEntry
    {
        public string Label;
        public ContextAction Action;
        public bool IsDanger;
        public bool IsSeparator;
        public bool IsDisabled;
        public string DisabledReason;
    }

    #endregion

    #region Public API

    public void Show(InventoryItem item, Vector2 screenPosition, K_InventoryUI inventoryUI,
        K_EquipmentSlotUI equipmentSlot = null)
    {
        if (item == null || item.Data == null) return;

        _currentItem = item;
        _currentInventoryUI = inventoryUI;
        _currentEquipmentSlot = equipmentSlot;
        _isShowingDescription = false;

        if (!_isInitialized) SetupInternals();

        if (_hideCoroutine != null)
        {
            StopCoroutine(_hideCoroutine);
            _hideCoroutine = null;
        }

        // ФИКС: Останавливаем предыдущую корутину реконструкции, чтобы они не накладывались
        if (_rebuildCoroutine != null)
        {
            StopCoroutine(_rebuildCoroutine);
            _rebuildCoroutine = null;
        }

        BuildMenu();

        Debug.Log($"[ContextMenu] Show: item={item.Data.DisplayName}, " +
            $"entries={_currentEntries.Count}, contentRect={_contentRect != null}, " +
            $"parent={transform.parent?.name}, pos={screenPosition}");

        _lastScreenPosition = screenPosition; // Сохраняем позицию

        transform.SetAsLastSibling();
        gameObject.SetActive(true);
        EnsureRootVerticalLayoutGroup();

        if (_contentRect != null)
            LayoutRebuilder.ForceRebuildLayoutImmediate(_contentRect);

        if (_rectTransform != null)
            LayoutRebuilder.ForceRebuildLayoutImmediate(_rectTransform);

        ForceRecomputeRootSize();

        var cg = GetComponent<CanvasGroup>();
        float h = _rectTransform?.rect.height ?? -1f;
        float w = _rectTransform?.rect.width ?? -1f;
        float ch = _contentRect?.rect.height ?? -1f;
        float cw = _contentRect?.rect.width ?? -1f;

        Debug.Log($"[V12-DIAG] After rebuild+ForceRecompute: " +
            $"root=({w:F1}, {h:F1}), " +
            $"content=({cw:F1}, {ch:F1}), " +
            $"contentChildCount={_contentRect?.childCount}, " +
            $"activeSelf={gameObject.activeSelf}, " +
            $"activeInHierarchy={gameObject.activeInHierarchy}, " +
            $"CG.alpha={cg?.alpha}, CG.blocksRaycasts={cg?.blocksRaycasts}, " +
            $"CG.interactable={cg?.interactable}");

        var parentCg = transform.parent;
        int parentIdx = 0;
        while (parentCg != null)
        {
            var parentCanvasGroup = parentCg.GetComponent<CanvasGroup>();
            if (parentCanvasGroup != null)
            {
                Debug.Log($"[V12-DIAG] Parent[{parentIdx}] '{parentCg.name}': " +
                    $"CanvasGroup alpha={parentCanvasGroup.alpha}, " +
                    $"blocksRaycasts={parentCanvasGroup.blocksRaycasts}, " +
                    $"interactable={parentCanvasGroup.interactable}, " +
                    $"activeInHierarchy={parentCg.gameObject.activeInHierarchy}");
            }
            parentCg = parentCg.parent;
            parentIdx++;
            if (parentIdx > 10) break;
        }

        if (h <= 0.5f)
        {
            Debug.LogError($"[V12-DIAG] CRITICAL: root height={h} after ForceRecompute! " +
                $"content={_contentRect?.rect.size}, " +
                $"childCount={_contentRect?.childCount}, " +
                $"Padding={S.Padding}");
        }
        else
        {
            Debug.Log($"[V12-DIAG] OK: root height={h}, buttons should be visible & clickable");
        }

        // ФИКС БАГ #15: Убран синхронный вызов PositionMenu здесь, чтобы избежать мерцания.
        // Позиционирование будет выполнено в RebuildNextFrame, когда Layout полностью пересчитан.
        // PositionMenu(screenPosition); <-- УДАЛИТЬ ЭТУ СТРОКУ

        _rebuildCoroutine = StartCoroutine(RebuildNextFrame());

        if (_canvasGroup != null)
        {
            _canvasGroup.alpha = 0f;
            StartCoroutine(FadeInRoutine());
        }
    }

    private void EnsureRootVerticalLayoutGroup()
    {
        var vlg = GetComponent<VerticalLayoutGroup>();
        if (vlg == null)
        {
            vlg = gameObject.AddComponent<VerticalLayoutGroup>();
            Debug.Log("[V12-FIX] Added VerticalLayoutGroup to root menu");
        }

        vlg.childAlignment = TextAnchor.UpperLeft;
        vlg.childControlWidth = true;
        vlg.childControlHeight = true;
        vlg.childForceExpandWidth = true;
        vlg.childForceExpandHeight = true;
        vlg.spacing = 0f;

        int pad = Mathf.RoundToInt(S.Padding);
        vlg.padding = new RectOffset(pad, pad, pad, pad);
    }

    private void ForceRecomputeRootSize()
    {
        if (_rectTransform == null || _contentRect == null) return;

        float contentWidth = _contentRect.rect.width;
        float contentHeight = _contentRect.rect.height;

        if (contentHeight <= 0.5f && _contentRect.childCount > 0)
        {
            contentHeight = 0f;
            for (int i = 0; i < _contentRect.childCount; i++)
            {
                var child = _contentRect.GetChild(i) as RectTransform;
                if (child != null)
                    contentHeight += child.rect.height;
            }
            Debug.Log($"[V12-FIX] Content height was 0, computed from children: {contentHeight}");
        }

        float padding = S.Padding * 2f;
        float targetWidth = Mathf.Max(S.MinWidth, contentWidth + padding);
        float targetHeight = contentHeight + padding;

        Vector2 oldSize = _rectTransform.sizeDelta;
        _rectTransform.sizeDelta = new Vector2(targetWidth, targetHeight);

        if (S.MaxWidth > 0 && targetWidth > S.MaxWidth)
            _rectTransform.sizeDelta = new Vector2(S.MaxWidth, targetHeight);

        Debug.Log($"[V12-FIX] ForceRecomputeRootSize: " +
            $"content=({contentWidth:F1}, {contentHeight:F1}), " +
            $"padding={padding:F1}, " +
            $"oldRoot={oldSize}, " +
            $"newRoot={_rectTransform.sizeDelta}");

        LayoutRebuilder.ForceRebuildLayoutImmediate(_rectTransform);
    }

    private IEnumerator RebuildNextFrame()
    {
        yield return null;
        if (!gameObject.activeSelf) yield break;

        if (_contentRect != null)
            LayoutRebuilder.ForceRebuildLayoutImmediate(_contentRect);

        if (_rectTransform != null)
            LayoutRebuilder.ForceRebuildLayoutImmediate(_rectTransform);

        ForceRecomputeRootSize();

        float h = _rectTransform?.rect.height ?? -1f;
        float w = _rectTransform?.rect.width ?? -1f;
        float ch = _contentRect?.rect.height ?? -1f;

        Debug.Log($"[V12-DIAG] Next-frame rebuild: " +
            $"root=({w:F1}, {h:F1}), content_height={ch:F1}, " +
            $"activeSelf={gameObject.activeSelf}");

        if (h <= 0.5f)
        {
            Debug.LogError($"[V12-DIAG] CRITICAL: root height STILL 0 after next-frame rebuild! " +
                $"content={_contentRect?.rect.size}, childCount={_contentRect?.childCount}");
        }

        // ФИКС: Повторно позиционируем меню после того, как Layout полностью пересчитан
        PositionMenu(_lastScreenPosition);

        _rebuildCoroutine = null;
    }

    public void Hide()
    {
        if (_hideCoroutine != null)
        {
            StopCoroutine(_hideCoroutine);
            _hideCoroutine = null;
        }
        if (!gameObject.activeSelf) return;
        _hideCoroutine = StartCoroutine(HideRoutine());
    }

    public void ShowDescription(InventoryItem item)
    {
        if (item == null || item.Data == null) return;
        gameObject.SetActive(false);
        ShowDescriptionPanel(item);
    }

    #endregion

    #region Menu Building

    private void BuildMenu()
    {
        ClearMenuItems();
        _currentEntries = GetEntriesForItem(_currentItem);

        int lastButtonIndex = -1;
        for (int i = _currentEntries.Count - 1; i >= 0; i--)
        {
            if (!_currentEntries[i].IsSeparator)
            {
                lastButtonIndex = i;
                break;
            }
        }

        for (int i = 0; i < _currentEntries.Count; i++)
        {
            var entry = _currentEntries[i];
            if (entry.IsSeparator)
            {
                CreateSeparator();
                continue;
            }
            bool isLast = (i == lastButtonIndex);
            CreateButton(entry, isLast);
        }
    }

   private List<MenuEntry> GetEntriesForItem(InventoryItem item)
{
    var entries = new List<MenuEntry>();
    ItemType type = item.Type;
    bool isEquipped = _currentEquipmentSlot != null && _currentEquipmentSlot.EquippedItem == item;

    switch (type)
    {
        case ItemType.Weapon: BuildWeaponEntries(entries, item, isEquipped); break;
        case ItemType.Ammo: BuildAmmoEntries(entries, item, isEquipped); break;
        case ItemType.Medical: BuildMedicalEntries(entries, item, isEquipped); break;
        case ItemType.Consumable: BuildConsumableEntries(entries, item, isEquipped); break;
        case ItemType.Clothing: BuildClothingEntries(entries, item, isEquipped); break;
        case ItemType.Backpack: BuildBackpackEntries(entries, item, isEquipped); break;
        case ItemType.Tool: BuildToolEntries(entries, item, isEquipped); break;
        case ItemType.Armor: BuildArmorEntries(entries, item, isEquipped); break;
        default: BuildDefaultEntries(entries, item, isEquipped); break;
    }

    AddSeparatorIfNotEmpty(entries);
    entries.Add(new MenuEntry { Label = "Описание", Action = ContextAction.Description, IsDanger = false });
    entries.Add(new MenuEntry { Label = "Выбросить", Action = ContextAction.Drop, IsDanger = true });
    return entries;
}
private void BuildArmorEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
{
    entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
    entries.Add(new MenuEntry { IsSeparator = true });
    if (isEquipped)
        entries.Add(new MenuEntry { Label = "Снять", Action = ContextAction.Unequip });
    else
        entries.Add(new MenuEntry { Label = "Надеть", Action = ContextAction.Equip });
}

    #endregion

    #region Per-Type Entry Builders

    private void BuildWeaponEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.InspectWeapon });
        entries.Add(new MenuEntry { IsSeparator = true });
        entries.Add(new MenuEntry { Label = "Перезарядить", Action = ContextAction.ReloadMagazine });
        entries.Add(new MenuEntry { Label = "Проверить магазин", Action = ContextAction.CheckMagazine });
        entries.Add(new MenuEntry { Label = "Извлечь магазин", Action = ContextAction.UnloadMagazine });
        entries.Add(new MenuEntry { Label = "Вставить магазин", Action = ContextAction.LoadMagazine });
        entries.Add(new MenuEntry { IsSeparator = true });
        entries.Add(new MenuEntry { Label = "Дослать патрон", Action = ContextAction.ChamberRound });
        entries.Add(new MenuEntry { Label = "Убрать из патронника", Action = ContextAction.ClearChamber });
        entries.Add(new MenuEntry { Label = "Взвести затвор", Action = ContextAction.CockWeapon });
        entries.Add(new MenuEntry { Label = "Режим огня", Action = ContextAction.ToggleFireMode });
        entries.Add(new MenuEntry { IsSeparator = true });
    }

    private void BuildAmmoEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { IsSeparator = true });
        if (item.Quantity > 1)
            entries.Add(new MenuEntry { Label = "Разделить", Action = ContextAction.Split });
        entries.Add(new MenuEntry { Label = "Переложить патроны", Action = ContextAction.TransferAmmo });
    }

    private void BuildMedicalEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { Label = "Применить", Action = ContextAction.ApplyToSelf });
    }

    private void BuildConsumableEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { IsSeparator = true });

        bool isDrink = item.Data?.DisplayName?.ToLower().Contains("вод") == true ||
                       item.Data?.DisplayName?.ToLower().Contains("напит") == true;
        bool isFood = item.Data?.DisplayName?.ToLower().Contains("консерв") == true ||
                      item.Data?.DisplayName?.ToLower().Contains("хлеб") == true ||
                      item.Data?.DisplayName?.ToLower().Contains("мяс") == true;

        if (isDrink) entries.Add(new MenuEntry { Label = "Выпить", Action = ContextAction.Drink });
        else if (isFood) entries.Add(new MenuEntry { Label = "Съесть", Action = ContextAction.Eat });
        else entries.Add(new MenuEntry { Label = "Использовать", Action = ContextAction.Use });

        if (item.Quantity > 1)
            entries.Add(new MenuEntry { Label = "Разделить", Action = ContextAction.Split });
    }

    private void BuildClothingEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { IsSeparator = true });
        if (isEquipped) entries.Add(new MenuEntry { Label = "Снять", Action = ContextAction.Unequip });
        else entries.Add(new MenuEntry { Label = "Надеть", Action = ContextAction.Equip });
    }

   private void BuildBackpackEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
{
    entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
    entries.Add(new MenuEntry { IsSeparator = true });

    // ═══ ФИКС: Определяем, открыт ли рюкзак как окно ═══
    bool isWindowOpen = _currentInventoryUI != null
                        && _currentInventoryUI.IsBackpackWindowOpen(item);

    if (item.CanFold)
    {
        bool isContentsEmpty = _currentInventoryUI?.IsBackpackContentsEmpty(item) ?? true;
        bool alwaysShowGrid = item.Data != null && item.Data.AlwaysShowGrid;
        
        // ⬇️ НОВАЯ ПРОВЕРКА
        bool isAtMaxDepth = _currentInventoryUI?.IsAtMaxNestingDepth(item) ?? false;

        if (item.IsFolded)
        {
            if (!isEquipped && alwaysShowGrid)
            {
                // ═══ ФИКС: "Закрыть" если открыт, "Открыть" если закрыт ═══
                if (isWindowOpen)
                    entries.Add(new MenuEntry { Label = "Закрыть", Action = ContextAction.CloseBackpack });
                else
                    entries.Add(new MenuEntry { Label = "Открыть", Action = ContextAction.OpenBackpack });
            }

            bool canUnfold = _currentInventoryUI?.CanUnfoldInCurrentGrid(item) ?? true;
            
            // ⬇️ ИЗМЕНЕНО: учитываем лимит вложенности
            if (canUnfold && !isAtMaxDepth)
                entries.Add(new MenuEntry { Label = "Развернуть", Action = ContextAction.Unfold });
            else
                entries.Add(new MenuEntry
                {
                    Label = "Развернуть",
                    Action = ContextAction.Unfold,
                    IsDisabled = true,
                    DisabledReason = isAtMaxDepth ? "Достигнут лимит вложенности" : "Не хватает места в сетке"
                });

            if (!isContentsEmpty && !isEquipped && alwaysShowGrid)
                entries.Add(new MenuEntry { Label = "Опустошить", Action = ContextAction.EmptyBackpack });
        }
        else
        {
            if (!isEquipped)
            {
                // ═══ ФИКС: "Закрыть" если открыт, "Открыть" если закрыт ═══
                if (isWindowOpen)
                    entries.Add(new MenuEntry { Label = "Закрыть", Action = ContextAction.CloseBackpack });
                else
                    entries.Add(new MenuEntry { Label = "Открыть", Action = ContextAction.OpenBackpack });
            }

            if (!isContentsEmpty && !isEquipped)
                entries.Add(new MenuEntry { Label = "Опустошить", Action = ContextAction.EmptyBackpack });

            if (!isEquipped && isContentsEmpty)
                entries.Add(new MenuEntry { Label = "Свернуть", Action = ContextAction.Fold });
            else if (!isEquipped)
                entries.Add(new MenuEntry
                {
                    Label = "Свернуть",
                    Action = ContextAction.Fold,
                    IsDisabled = true,
                    DisabledReason = "Рюкзак не пуст — опустошите через ПКМ"
                });
        }

        entries.Add(new MenuEntry { IsSeparator = true });
    }
    else
    {
        if (!isEquipped && !item.IsFolded)
        {
            // ═══ ФИКС: "Закрыть" если открыт, "Открыть" если закрыт ═══
            if (isWindowOpen)
                entries.Add(new MenuEntry { Label = "Закрыть", Action = ContextAction.CloseBackpack });
            else
                entries.Add(new MenuEntry { Label = "Открыть", Action = ContextAction.OpenBackpack });

            entries.Add(new MenuEntry { IsSeparator = true });
        }
    }

    if (isEquipped) entries.Add(new MenuEntry { Label = "Снять", Action = ContextAction.Unequip });
    else entries.Add(new MenuEntry { Label = "Надеть", Action = ContextAction.Equip });
}
    

    private void BuildToolEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        entries.Add(new MenuEntry { Label = "Ремонт", Action = ContextAction.Repair });
    }

    private void BuildDefaultEntries(List<MenuEntry> entries, InventoryItem item, bool isEquipped)
    {
        entries.Add(new MenuEntry { Label = "Осмотреть", Action = ContextAction.Inspect });
        if (item.Quantity > 1)
            entries.Add(new MenuEntry { Label = "Разделить", Action = ContextAction.Split });
        entries.Add(new MenuEntry { IsSeparator = true });
    }

    private void AddSeparatorIfNotEmpty(List<MenuEntry> entries) { }

    #endregion

    #region UI Creation

    private void CreateButton(MenuEntry entry, bool isLast)
    {
        if (_contentRect == null) return;

        GameObject go;
        var prefab = S.MenuItemPrefab;
        if (prefab != null)
        {
            go = Instantiate(prefab, _contentRect);
        }
        else
        {
            go = CreateButtonProgrammatically(entry);
            go.transform.SetParent(_contentRect, false);
        }

        _spawnedItems.Add(go);

        var rt = go.GetComponent<RectTransform>();
        if (rt != null)
        {
            rt.anchorMin = new Vector2(0, 1);
            rt.anchorMax = new Vector2(1, 1);
            rt.pivot = new Vector2(0.5f, 1);
            rt.sizeDelta = new Vector2(0, S.ButtonHeight);
        }

        var le = go.GetComponent<LayoutElement>();
        if (le != null)
        {
            le.minHeight = S.ButtonHeight;
            le.preferredHeight = S.ButtonHeight;
        }

        var text = go.GetComponentInChildren<TextMeshProUGUI>();
        if (text != null)
        {
            text.text = entry.Label;
            text.fontSize = S.FontSize;
            text.color = entry.IsDisabled ? S.DisabledTextColor :
                         entry.IsDanger ? S.TextDangerColor : S.TextColor;
            if (S.Font != null) text.font = S.Font;
        }

        var button = go.GetComponent<Button>();
        if (button != null)
        {
            if (entry.IsDisabled)
            {
                button.interactable = false;
            }
            else
            {
                ColorBlock colors = button.colors;
                colors.normalColor = entry.IsDanger ? S.DangerColor : S.NormalColor;
                colors.highlightedColor = entry.IsDanger ? S.DangerHoverColor : S.HoverColor;
                colors.pressedColor = entry.IsDanger ? S.DangerColor : S.PressedColor;
                colors.fadeDuration = 0.1f;
                button.colors = colors;

                var entryLabel = entry.Label;
                var entryAction = entry.Action;
                button.onClick.AddListener(() => {
                    Debug.Log($"[V12-CLICK] Button.onClick FIRED: label='{entryLabel}', action={entryAction}");
                    OnActionClicked(entryAction);
                });
            }
        }

        var img = go.GetComponent<Image>();
        if (img != null)
            img.color = entry.IsDanger ? S.DangerColor : S.NormalColor;
    }

    private GameObject CreateButtonProgrammatically(MenuEntry entry)
    {
        var go = new GameObject("MenuBtn_" + entry.Label, typeof(RectTransform), typeof(Image), typeof(Button));

        var bg = go.GetComponent<Image>();
        bg.color = entry.IsDanger ? S.DangerColor : S.NormalColor;
        bg.raycastTarget = true;

        var btn = go.GetComponent<Button>();
        btn.targetGraphic = bg;

        var le = go.AddComponent<LayoutElement>();
        le.minHeight = S.ButtonHeight;
        le.preferredHeight = S.ButtonHeight;
        le.minWidth = S.MinWidth;

        var nav = btn.navigation;
        nav.mode = Navigation.Mode.None;
        btn.navigation = nav;

        var textObj = new GameObject("Label", typeof(RectTransform));
        textObj.transform.SetParent(go.transform, false);
        var tmp = textObj.AddComponent<TextMeshProUGUI>();
        tmp.text = entry.Label;
        tmp.fontSize = S.FontSize;
        tmp.alignment = TextAlignmentOptions.MidlineLeft;
        tmp.color = entry.IsDisabled ? S.DisabledTextColor :
                    entry.IsDanger ? S.TextDangerColor : S.TextColor;
        if (S.Font != null) tmp.font = S.Font;

        var textRT = textObj.GetComponent<RectTransform>();
        textRT.anchorMin = new Vector2(0, 0);
        textRT.anchorMax = new Vector2(1, 1);
        textRT.offsetMin = new Vector2(S.TextLeftPadding, 0f);
        textRT.offsetMax = new Vector2(-S.TextRightPadding, 0f);

        return go;
    }

    private void CreateSeparator()
    {
        if (_contentRect == null) return;

        GameObject go;
        var sepPrefab = S.SeparatorPrefab;
        if (sepPrefab != null)
        {
            go = Instantiate(sepPrefab, _contentRect);
        }
        else
        {
            go = new GameObject("Separator", typeof(RectTransform), typeof(Image), typeof(LayoutElement));
            go.transform.SetParent(_contentRect, false);
            var sepImg = go.GetComponent<Image>();
            sepImg.color = S.SeparatorColor;
            sepImg.raycastTarget = false;
            var sepLe = go.GetComponent<LayoutElement>();
            sepLe.minHeight = S.SeparatorHeight;
            sepLe.preferredHeight = S.SeparatorHeight;
        }

        _spawnedItems.Add(go);

        var img = go.GetComponent<Image>();
        if (img != null) img.color = S.SeparatorColor;

        var rt = go.GetComponent<RectTransform>();
        if (rt != null)
        {
            rt.anchorMin = new Vector2(0, 1);
            rt.anchorMax = new Vector2(1, 1);
            rt.pivot = new Vector2(0.5f, 1);
            rt.sizeDelta = new Vector2(-S.Padding * 2, S.SeparatorHeight);
        }
    }

    private void ClearMenuItems()
    {
        foreach (var item in _spawnedItems)
            if (item != null) Destroy(item);
        _spawnedItems.Clear();
    }

    #endregion

    #region Positioning

    private void PositionMenu(Vector2 screenPosition)
    {
        if (_rectTransform == null || _canvas == null) return;

        LayoutRebuilder.ForceRebuildLayoutImmediate(_rectTransform);

        float width = Mathf.Clamp(_rectTransform.rect.width, S.MinWidth, S.MaxWidth);
        float height = _rectTransform.rect.height;

        float x = screenPosition.x + S.OffsetFromCursor.x;
        float y = screenPosition.y + S.OffsetFromCursor.y;

        if (x + width > Screen.width) x = screenPosition.x - width - S.OffsetFromCursor.x;
        if (y - height < 0) y = screenPosition.y + height + Mathf.Abs(S.OffsetFromCursor.y);

        Vector2 clampedScreenPos = new Vector2(x, y);

        Canvas rootCanvas = _canvas.rootCanvas;
        Camera cam = rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : rootCanvas.worldCamera;

        // ФИКС: Корректное преобразование экранных координат в мировые с учетом Canvas Scaler и Render Mode
        if (RectTransformUtility.ScreenPointToWorldPointInRectangle(rootCanvas.transform as RectTransform, clampedScreenPos, cam, out Vector3 worldPos))
        {
            _rectTransform.position = worldPos;
        }
        else
        {
            _rectTransform.position = new Vector3(x, y, 0f);
        }

        _rectTransform.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, width);
    }

    #endregion

    #region Animation

    private IEnumerator FadeInRoutine()
    {
        while (_canvasGroup != null && _canvasGroup.alpha < 1f)
        {
            _canvasGroup.alpha += S.AppearSpeed * Time.deltaTime;
            yield return null;
        }
        if (_canvasGroup != null) _canvasGroup.alpha = 1f;
    }

    private IEnumerator HideRoutine()
    {
        if (_canvasGroup != null)
        {
            while (_canvasGroup.alpha > 0f)
            {
                _canvasGroup.alpha -= S.AppearSpeed * Time.deltaTime;
                yield return null;
            }
        }
        gameObject.SetActive(false);
        ClearMenuItems();
        _hideCoroutine = null;
    }

    #endregion

    #region Description Panel

    private void ShowDescriptionPanel(InventoryItem item)
    {
        var descPrefab = S.DescriptionPanelPrefab;
        if (descPrefab == null) return;

        var panel = Instantiate(descPrefab, transform.root);
        Debug.Log($"[ContextMenu] Показать описание: {item?.Data?.DisplayName}");
        _isShowingDescription = true;
    }

    #endregion

    #region Action Handling

    private void OnActionClicked(ContextAction action)
    {
        Debug.Log($"[V12-CLICK] OnActionClicked: action={action}, " +
            $"_currentItem={(_currentItem == null ? "NULL" : _currentItem.Data?.DisplayName)}, " +
            $"_currentInventoryUI={(_currentInventoryUI == null ? "NULL" : "ok")}");

        if (_currentItem == null)
        {
            Debug.LogWarning($"[V12-CLICK] ABORT: _currentItem is null! action={action} did not execute.");
            return;
        }

        switch (action)
        {
            case ContextAction.InspectWeapon:
            case ContextAction.Inspect:
                HandleInspect(); break;
            case ContextAction.ReloadMagazine: HandleReloadMagazine(); break;
            case ContextAction.UnloadMagazine: HandleUnloadMagazine(); break;
            case ContextAction.LoadMagazine: HandleLoadMagazine(); break;
            case ContextAction.CheckMagazine: HandleCheckMagazine(); break;
            case ContextAction.ChamberRound: HandleChamberRound(); break;
            case ContextAction.ClearChamber: HandleClearChamber(); break;
            case ContextAction.CockWeapon: HandleCockWeapon(); break;
            case ContextAction.ToggleFireMode: HandleToggleFireMode(); break;
            case ContextAction.Eat:
            case ContextAction.Drink:
            case ContextAction.Use: HandleUse(); break;
            case ContextAction.ApplyToSelf: HandleApplyMedical(); break;
            case ContextAction.Equip:
            case ContextAction.Unequip: HandleEquipUnequip(action == ContextAction.Equip); break;
            case ContextAction.Fold: HandleFold(); break;
            case ContextAction.Unfold: HandleUnfold(); break;
            case ContextAction.OpenBackpack: HandleOpenBackpack(); break;
            case ContextAction.CloseBackpack: HandleCloseBackpack(); break;
            case ContextAction.EmptyBackpack: HandleEmptyBackpack(); break;
            case ContextAction.Drop: HandleDrop(); break;
            case ContextAction.Description: ShowDescription(_currentItem); return;
            case ContextAction.Discard: HandleDiscard(); break;
            case ContextAction.Split: HandleSplit(); break;
            case ContextAction.Repair: HandleRepair(); break;
            case ContextAction.TransferAmmo: HandleTransferAmmo(); break;
        }

        Hide();
    }

    #endregion

    #region Action Implementations 
    private void HandleInspect()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Осмотр: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleReloadMagazine()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Перезарядка: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleUnloadMagazine()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Извлечение магазина: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleLoadMagazine()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Вставка магазина: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleCheckMagazine()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Проверка магазина: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleChamberRound()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Дослать патрон: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleClearChamber()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Убрать из патронника: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleCockWeapon()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Взвести затвор: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleToggleFireMode()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Режим огня: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleUse()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Использовать: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleApplyMedical()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Применить: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleEquipUnequip(bool equip)
    {
        if (_currentItem == null || _currentInventoryUI == null) return;

        if (equip)
        {
            // ═══════════════════════════════════════════════════════════════
            //  БЛОК 3: Контекстное меню (ПКМ → Надеть).
            //
            //  Делегируем в InventoryTransactionService.TryEquipFromContextMenu:
            //    1. Определяется целевой слот экипировки (по типу предмета).
            //    2. Если слот пуст — простой перенос.
            //    3. Если слот занят — свап: A уходит в слот, B — на старое
            //       место A (с FindFreeSpace при нехватке места).
            //    4. При ошибке — транзакция откатывается, предмет остаётся
            //       на месте, errorMessage выводится в лог.
            //
            //  Сервис сам вызывает ForceRefresh после успеха — UI обновится.
            // ═══════════════════════════════════════════════════════════════
            var tx = InventoryTransactionService.Instance;
            if (tx == null)
            {
                Debug.LogError("[K_ContextMenu] InventoryTransactionService.Instance is null — cannot equip.");
                return;
            }

            if (tx.IsTransactionActive)
            {
                Debug.LogWarning("[K_ContextMenu] Cannot equip: another transaction is active.");
                return;
            }

            bool ok = tx.TryEquipFromContextMenu(_currentItem, out string errorMessage);
            if (!ok)
            {
                Debug.LogWarning(
                    $"[K_ContextMenu] Equip failed for '{_currentItem.Data?.DisplayName}': {errorMessage}");
            }
#if UNITY_EDITOR
            else
            {
                Debug.Log($"[K_ContextMenu] Equip OK: {_currentItem.Data?.DisplayName}");
            }
#endif
        }
        else
        {
            // Снять (unequip) — оставляем прежнюю логику через слот.
            if (_currentEquipmentSlot != null)
            {
                _currentEquipmentSlot.Unequip();
            }
        }
    }

    private void HandleFold()
    {
        if (_currentItem == null || _currentInventoryUI == null)
        {
            Debug.LogWarning($"[V9-CTX] HandleFold: _currentItem={(_currentItem == null ? "null" : "ok")}, _currentInventoryUI={(_currentInventoryUI == null ? "null" : "ok")}");
            return;
        }

        // ═══ БАГ ФИКС (fold/unfold через ПКМ перестаёт работать): ═══
        // Двойная проверка пустоты рюкзака. BuildBackpackEntries уже проверяет
        // isContentsEmpty, но между показом меню и кликом игрока состояние могло
        // измениться (например, другой скрипт положил предмет в рюкзак).
        // Без этой проверки ToggleBackpackFold → HandleInventoryBackpackFold
        // попытается свернуть непустой рюкзак, что приведёт к:
        //   1) SyncBackpackContentsBeforeFold сохранит содержимое в _backpackContentsSerialized
        //   2) IsBackpackContentsEmpty вернёт false → abort
        //   3) НО! Если между этими шагами что-то пошло не так, рюкзак может остаться
        //      в рассинхронизированном состоянии (IsFolded=false, но _backpackContentsSerialized
        //      уже обновлён, а контроллер не очищен).
        // Повторная проверка здесь — дешёвая страховка.
        bool isContentsEmpty = _currentInventoryUI.IsBackpackContentsEmpty(_currentItem);
        if (!isContentsEmpty)
        {
            Debug.LogWarning($"[V9-CTX] HandleFold: ABORT — backpack '{_currentItem.Data?.DisplayName}' is not empty. " +
                "Player must empty it first (right-click → Empty).");
            return;
        }

        Debug.Log($"[V9-CTX] HandleFold: item={_currentItem.Data?.DisplayName}, isContentsEmpty={isContentsEmpty}");
        _currentInventoryUI.ToggleBackpackFold(_currentItem, fold: true);
    }

   private void HandleUnfold()
{
    if (_currentItem == null || _currentInventoryUI == null)
    {
        Debug.LogWarning($"[V9-CTX] HandleUnfold: _currentItem={(_currentItem == null ? "null" : "ok")}, _currentInventoryUI={(_currentInventoryUI == null ? "null" : "ok")}");
        return;
    }
    
    // ⬇️ НОВАЯ ПРОВЕРКА (страховка от прямого вызова)
    if (_currentInventoryUI.IsAtMaxNestingDepth(_currentItem))
    {
        Debug.LogWarning($"[V9-CTX] HandleUnfold: ABORT — backpack '{_currentItem.Data?.DisplayName}' is at max nesting depth.");
        return;
    }
    
    Debug.Log($"[V9-CTX] HandleUnfold: item={_currentItem.Data?.DisplayName}, IsFolded={_currentItem.IsFolded}, CanFold={_currentItem.CanFold}");
    _currentInventoryUI.ToggleBackpackFold(_currentItem, fold: false);
}
    private void HandleOpenBackpack()
    {
        Debug.Log($"[CTX-OPEN] HandleOpenBackpack START: item={_currentItem?.Data?.DisplayName}, " +
            $"_currentInventoryUI={(_currentInventoryUI != null)}");

        if (_currentItem == null || _currentInventoryUI == null)
        {
            Debug.LogWarning($"[CTX-OPEN] ABORT: _currentItem={(_currentItem != null)}, " +
                $"_currentInventoryUI={(_currentInventoryUI != null)}");
            return;
        }

        if (!_currentItem.Data.IsBackpack)
        {
            Debug.LogWarning($"[CTX-OPEN] '{_currentItem.Data.DisplayName}' is not a backpack");
            return;
        }

        if (_currentItem.IsFolded && !_currentItem.Data.AlwaysShowGrid)
        {
            Debug.Log($"[CTX-OPEN] Cannot open folded backpack '{_currentItem.Data.DisplayName}' — " +
                "unfold first (or set AlwaysShowGrid=true in ItemStaticData).");
            return;
        }

        Debug.Log($"[CTX-OPEN] Calling OpenBackpackAsContainer for '{_currentItem.Data.DisplayName}'...");
        _currentInventoryUI.OpenBackpackAsContainer(_currentItem);
        Debug.Log($"[CTX-OPEN] OpenBackpackAsContainer returned.");
    }
    private void HandleCloseBackpack()
    {
        if (_currentItem == null || _currentInventoryUI == null) return;
        if (!_currentItem.Data.IsBackpack) return;

        Debug.Log($"[CTX-CLOSE] Closing backpack window for '{_currentItem.Data.DisplayName}'");
        _currentInventoryUI.CloseBackpackWindowByItem(_currentItem);
    }
    private void HandleEmptyBackpack()
    {
        if (_currentItem == null || _currentInventoryUI == null) return;

        if (!_currentItem.Data.IsBackpack)
        {
            Debug.LogWarning($"[ContextMenu] EmptyBackpack: '{_currentItem.Data.DisplayName}' is not a backpack");
            return;
        }

        if (_currentItem.IsFolded && !_currentItem.Data.AlwaysShowGrid)
        {
            Debug.Log($"[ContextMenu] Cannot empty folded backpack '{_currentItem.Data.DisplayName}' — " +
                "unfold first (or set AlwaysShowGrid=true in ItemStaticData).");
            return;
        }

        _currentInventoryUI.EmptyBackpackContents(_currentItem);
    }

    private void HandleDrop()
    {
        if (_currentItem == null || _currentInventoryUI == null) return;

        // ФИКС БАГ #18: Логика выброса предмета в мир
        // Требует реализации спавна префаба и удаления из контроллера
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Выбросить: {_currentItem.Data?.DisplayName} (Требует реализации спавна префаба в мир)");
#endif

        // Пример того, как это должно быть связано:
        // var controller = _currentInventoryUI.GetControllerForGrid(GridType.Pockets); // или откуда взят предмет
        // if (controller != null) controller.RemoveItem(_currentItem);
        // SpawnWorldItem(_currentItem.Data.Prefab, PlayerPosition);
    }

    private void HandleDiscard()
    {
        if (_currentItem == null) return;
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Уничтожить: {_currentItem.Data?.DisplayName}");
#endif
    }

    private void HandleSplit()
    {
        if (_currentItem == null || _currentInventoryUI == null) return;
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Разделить: {_currentItem.Data?.DisplayName}");
#endif
    }

    private void HandleRepair()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Ремонт: {_currentItem?.Data?.DisplayName}");
#endif
    }

    private void HandleTransferAmmo()
    {
#if UNITY_EDITOR
        Debug.Log($"[ContextMenu] Переложить патроны: {_currentItem?.Data?.DisplayName}");
#endif
    }

    #endregion

    #region Initialization

    public void Initialize(Transform rootCanvasTransform)
    {
        _canvas = rootCanvasTransform != null ? rootCanvasTransform.GetComponent<Canvas>() : null;
        SetupInternals();
    }

    private void SetupInternals()
    {
        if (_isInitialized) return;
        _isInitialized = true;

        _rectTransform = GetComponent<RectTransform>();
        _canvasGroup = GetComponent<CanvasGroup>();
        if (_canvasGroup == null) _canvasGroup = gameObject.AddComponent<CanvasGroup>();
        if (_canvas == null) _canvas = GetComponentInParent<Canvas>();

        _rectTransform.anchorMin = new Vector2(0, 1);
        _rectTransform.anchorMax = new Vector2(0, 1);
        _rectTransform.pivot = new Vector2(0, 1);
        _rectTransform.sizeDelta = new Vector2(S.MinWidth, 0f);

        var bg = GetComponent<Image>();
        if (bg == null) bg = gameObject.AddComponent<Image>();
        bg.color = S.BackgroundColor;
        bg.raycastTarget = true;

        _canvasGroup.blocksRaycasts = true;
        _canvasGroup.interactable = true;

        var menuCsf = GetComponent<ContentSizeFitter>();
        if (menuCsf == null) menuCsf = gameObject.AddComponent<ContentSizeFitter>();
        menuCsf.verticalFit = ContentSizeFitter.FitMode.PreferredSize;

        CreateMenuBorder();

        if (_contentRect == null)
        {
            var contentObj = new GameObject("Content", typeof(RectTransform), typeof(VerticalLayoutGroup));
            contentObj.transform.SetParent(_rectTransform, false);
            _contentRect = contentObj.GetComponent<RectTransform>();
            _contentRect.anchorMin = Vector2.zero;
            _contentRect.anchorMax = Vector2.one;
            _contentRect.offsetMin = new Vector2(S.Padding, S.Padding);
            _contentRect.offsetMax = new Vector2(-S.Padding, -S.Padding);

            var vlg = contentObj.GetComponent<VerticalLayoutGroup>();
            vlg.childAlignment = TextAnchor.UpperLeft;
            vlg.childControlWidth = true;
            vlg.childControlHeight = false;
            vlg.childForceExpandWidth = true;
            vlg.childForceExpandHeight = false;
            vlg.spacing = 0f;

            var csf = contentObj.AddComponent<ContentSizeFitter>();
            csf.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
        }
    }

    private void CreateMenuBorder()
    {
        float t = S.BorderThickness;
        if (t <= 0f || S.BorderColor.a <= 0f) return;

        CreateBorderSide("BorderLeft",
            anchorMin: new Vector2(0, 0), anchorMax: new Vector2(0, 1),
            pivot: new Vector2(0, 0.5f),
            offsetMin: Vector2.zero, offsetMax: new Vector2(t, 0));

        CreateBorderSide("BorderRight",
            anchorMin: new Vector2(1, 0), anchorMax: new Vector2(1, 1),
            pivot: new Vector2(1, 0.5f),
            offsetMin: new Vector2(-t, 0), offsetMax: Vector2.zero);

        CreateBorderSide("BorderTop",
            anchorMin: new Vector2(0, 1), anchorMax: new Vector2(1, 1),
            pivot: new Vector2(0.5f, 1),
            offsetMin: new Vector2(0, -t), offsetMax: Vector2.zero);

        CreateBorderSide("BorderBottom",
            anchorMin: new Vector2(0, 0), anchorMax: new Vector2(1, 0),
            pivot: new Vector2(0.5f, 0),
            offsetMin: Vector2.zero, offsetMax: new Vector2(0, t));
    }

    private void CreateBorderSide(string name, Vector2 anchorMin, Vector2 anchorMax,
        Vector2 pivot, Vector2 offsetMin, Vector2 offsetMax)
    {
        var side = new GameObject(name, typeof(RectTransform), typeof(Image));
        side.transform.SetParent(_rectTransform, false);

        var img = side.GetComponent<Image>();
        img.color = S.BorderColor;
        img.raycastTarget = false;

        var rt = side.GetComponent<RectTransform>();
        rt.anchorMin = anchorMin;
        rt.anchorMax = anchorMax;
        rt.pivot = pivot;
        rt.offsetMin = offsetMin;
        rt.offsetMax = offsetMax;
    }

    #endregion

    #region Unity Lifecycle

    private void Start()
    {
        SetupInternals();
    }

    private void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            // ФИКС БАГ #16: Проверяем, был ли клик по самому меню или его дочерним элементам
            bool clickedInside = false;
            if (EventSystem.current != null)
            {
                var eventData = new PointerEventData(EventSystem.current);
                eventData.position = Input.mousePosition;
                var results = new System.Collections.Generic.List<RaycastResult>();
                EventSystem.current.RaycastAll(eventData, results);

                foreach (var result in results)
                {
                    // Если клик попал в меню или в любой объект, являющийся ребенком меню
                    if (result.gameObject.transform.IsChildOf(transform))
                    {
                        clickedInside = true;
                        break;
                    }
                }
            }

            if (!clickedInside)
            {
                Hide();
            }
        }
    }

    #endregion
}