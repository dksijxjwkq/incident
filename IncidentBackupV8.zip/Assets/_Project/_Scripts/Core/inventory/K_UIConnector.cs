using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Пара «откуда → куда» для одной декоративной линии-коннектора.
    /// from / to — это RectTransform-маркеры (пустые дети слотов, расставленные по углам).
    /// </summary>
    [Serializable]
    public struct ConnectorPair
    {
        public RectTransform from;
        public RectTransform to;

        [Tooltip("0 = использовать default thickness")]
        public float thickness;

        [Tooltip("alpha == 0 = использовать default color")]
        public Color color;
    }

    /// <summary>
    /// Рисует тонкие декоративные Image-линии между парами RectTransform-маркеров.
    ///
    /// <para><b>Инструкция пользователю:</b></para>
    /// <list type="number">
    /// <item>У каждого слота создай N пустых RectTransform-детей
    ///       ("Point_TL", "Point_TR", "Point_BL", "Point_BR").
    ///       Позиционируй их по углам слота через anchorMin/Max
    ///       (например, для левого-нижнего: anchorMin = anchorMax = (0,0), anchoredPosition = (0,0)).</item>
    /// <item>Помести K_UIConnector на общий родитель (EquipmentGroup или LeftPane).
    ///       Anchor/pivot/sizeDelta компонент выставит сам в Awake/OnValidate.</item>
    /// <item>В инспекторе K_UIConnector → Pairs → Add.
    ///       В поле <c>from</c> перетащи маркер, в <c>to</c> — парный маркер.</item>
    /// <item>Линия появится автоматически. Двигаешь слот или маркер — линия перестроится.</item>
    /// <item>Толщина 0 = default thickness. Цвет с alpha=0 = default color.</item>
    /// </list>
    ///
    /// <para><b>Почему не LineRenderer:</b> это 3D-компонент, не работает корректно
    /// в Screen Space Overlay Canvas без костылей. Используем плоский Image.</para>
    /// </summary>
    [AddComponentMenu("UI/K_UIConnector")]
    [RequireComponent(typeof(RectTransform))]
    public class K_UIConnector : MonoBehaviour
    {
        // ─────────────────────────────────────────────────────────────────────
        // Inspector
        // ─────────────────────────────────────────────────────────────────────

        [Header("Defaults")]
        [SerializeField] private float _defaultThickness = 2f;
        [SerializeField] private Color _defaultColor = new Color(0.45f, 0.47f, 0.52f, 1f);

        [Header("Pairs")]
        [SerializeField] private ConnectorPair[] _pairs = new ConnectorPair[0];

        [Header("Update")]
        [SerializeField, Tooltip("Пересчитывать линии каждый кадр в LateUpdate. " +
            "Если false — только при Start/OnValidate/через Rebuild().")]
        private bool _liveUpdate = true;

        [Header("Debug")]
        [SerializeField] private bool _drawGizmos = true;

        // ─────────────────────────────────────────────────────────────────────
        // Runtime state
        // ─────────────────────────────────────────────────────────────────────

        private RectTransform _rt;
        private readonly List<Image> _lines = new List<Image>();

        private const string LinePrefix = "Line_";
        private const float MinLength = 0.01f;

#if UNITY_EDITOR
        /// <summary>
        /// Защита от множественных delayCall-запросов, прилетающих пачкой
        /// из OnValidate при массовом изменении полей в инспекторе.
        /// </summary>
        private bool _delayedRebuildQueued;
#endif

        // ─────────────────────────────────────────────────────────────────────
        // Unity lifecycle
        // ─────────────────────────────────────────────────────────────────────

        private void Awake()
        {
            EnsureRect();
            if (_rt == null) return;
            NormalizeSelf(logWarning: true);
        }

        private void OnEnable()
        {
            EnsureRect();
            if (_rt == null) return;

            NormalizeSelf(logWarning: false);
            Rebuild();
        }

        private void Start()
        {
            // Если liveUpdate выключен — гарантируем корректный первый расчёт.
            if (!_liveUpdate) UpdateLines();
        }

        private void LateUpdate()
        {
            if (!_liveUpdate) return;
            UpdateLines();
        }

        private void OnValidate()
        {
            // OnValidate может вызываться до Awake / до OnEnable — не падаем.
            EnsureRect();
            if (_rt == null) return;

            NormalizeSelf(logWarning: false);

#if UNITY_EDITOR
            // Rebuild/UpdateLines нельзя вызывать синхронно из OnValidate —
            // Unity блокирует DestroyImmediate и создание/репарентинг GameObject
            // (SendMessage cannot be called during Awake/CheckConsistency/OnValidate).
            // Откладываем на delayCall и схлопываем повторные запросы.
            if (_delayedRebuildQueued) return;
            _delayedRebuildQueued = true;
            UnityEditor.EditorApplication.delayCall += DelayedRebuildFromValidate;
#else
            // В билде OnValidate не дёргается, ветка чисто для симметрии чтения.
            int target = _pairs != null ? _pairs.Length : 0;
            if (CountLineChildren() != target || _lines.Count != target)
                Rebuild();
            else
                UpdateLines();
#endif
        }

        // ─────────────────────────────────────────────────────────────────────
        // Public API
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Полностью пересоздать дочерние Image-линии (количество = _pairs.Length).
        /// Безопасно вызывать повторно — мусор не накапливается.
        /// </summary>
        [ContextMenu("Rebuild")]
        public void Rebuild()
        {
            EnsureRect();
            if (_rt == null) return;

            // 1) Уничтожаем все существующие дочерние линии.
            _lines.Clear();
            for (int i = _rt.childCount - 1; i >= 0; i--)
            {
                var child = _rt.GetChild(i);
                if (child == null) continue;
                if (!child.name.StartsWith(LinePrefix, StringComparison.Ordinal)) continue;

                DestroySafe(child.gameObject);
            }

            // 2) Создаём по одной на пару.
            int target = _pairs != null ? _pairs.Length : 0;
            for (int i = 0; i < target; i++)
            {
                var go = new GameObject(LinePrefix + i, typeof(RectTransform), typeof(Image));
                go.transform.SetParent(_rt, false);

                var img = go.GetComponent<Image>();
                img.sprite = null;
                img.type = Image.Type.Simple;
                img.raycastTarget = false;
                img.color = _defaultColor;

                var lrt = img.rectTransform;
                lrt.anchorMin = new Vector2(0f, 1f);
                lrt.anchorMax = new Vector2(0f, 1f);
                lrt.pivot = new Vector2(0f, 0.5f);

                _lines.Add(img);
            }

            // 3) Считаем позиции/углы.
            UpdateLines();
        }

        /// <summary>
        /// Пересчитать позиции / размеры / повороты всех линий.
        /// Безопасно вызывать каждый кадр.
        /// </summary>
        public void UpdateLines()
        {
            EnsureRect();
            if (_rt == null) return;
            if (_pairs == null) return;

            // Если по какой-то причине список линий разошёлся с количеством пар — восстановить.
            if (_lines.Count != _pairs.Length)
            {
                Rebuild();
                return;
            }

            for (int i = 0; i < _pairs.Length; i++)
            {
                var pair = _pairs[i];
                var img = _lines[i];
                if (img == null) continue;

                var lineGO = img.gameObject;

                // Пара невалидна — просто прячем линию.
                if (pair.from == null || pair.to == null)
                {
                    if (lineGO.activeSelf) lineGO.SetActive(false);
                    continue;
                }

                // Локальные координаты (world → local коннектора).
                Vector3 localFrom = _rt.InverseTransformPoint(pair.from.position);
                Vector3 localTo = _rt.InverseTransformPoint(pair.to.position);

                // В top-left-фрейме Unity UI (anchor (0,1), pivot (0,1))
                // локальная +y и anchoredPosition +y согласованы.
                Vector2 anchoredFrom = new Vector2(localFrom.x, localFrom.y);
                Vector2 anchoredTo = new Vector2(localTo.x, localTo.y);

                Vector2 delta = anchoredTo - anchoredFrom;
                float length = delta.magnitude;
                float angle = Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg;

                float thickness = (pair.thickness > 0f) ? pair.thickness : _defaultThickness;
                Color color = (pair.color.a > 0f) ? pair.color : _defaultColor;

                var lineRT = img.rectTransform;
                lineRT.anchorMin = new Vector2(0f, 1f);
                lineRT.anchorMax = new Vector2(0f, 1f);
                lineRT.pivot = new Vector2(0f, 0.5f);
                lineRT.anchoredPosition = anchoredFrom;
                lineRT.sizeDelta = new Vector2(length, thickness);
                lineRT.localEulerAngles = new Vector3(0f, 0f, angle);

                img.color = color;

                // Слишком короткая — прячем (иначе виден «квадрат» из-за округления).
                bool visible = length > MinLength;
                if (lineGO.activeSelf != visible) lineGO.SetActive(visible);
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // Helpers
        // ─────────────────────────────────────────────────────────────────────

#if UNITY_EDITOR
        private void DelayedRebuildFromValidate()
        {
            // delayCall может прилететь после удаления/выключения объекта — защищаемся.
            if (this == null) return;

            _delayedRebuildQueued = false;

            if (!isActiveAndEnabled) return;
            if (_rt == null) return;

            Rebuild();
        }
#endif

        private void EnsureRect()
        {
            if (_rt == null) _rt = GetComponent<RectTransform>();
        }

        /// <summary>
        /// Приводит RectTransform коннектора к top-left-фрейму родителя:
        /// anchorMin = anchorMax = (0,1), pivot = (0,1), anchoredPosition = (0,0), sizeDelta = (0,0).
        /// Не ломает объект — просто нормализует.
        /// </summary>
        private void NormalizeSelf(bool logWarning)
        {
            if (_rt == null) return;

            var anchorTL = new Vector2(0f, 1f);
            var pivotTL = new Vector2(0f, 1f);

            bool changed = false;

            if (_rt.anchorMin != anchorTL) { _rt.anchorMin = anchorTL; changed = true; }
            if (_rt.anchorMax != anchorTL) { _rt.anchorMax = anchorTL; changed = true; }
            if (_rt.pivot != pivotTL) { _rt.pivot = pivotTL; changed = true; }
            if (_rt.anchoredPosition != Vector2.zero) { _rt.anchoredPosition = Vector2.zero; changed = true; }
            if (_rt.sizeDelta != Vector2.zero) { _rt.sizeDelta = Vector2.zero; changed = true; }

            if (changed && logWarning)
            {
                Debug.LogWarning(
                    $"[{nameof(K_UIConnector)}] RectTransform '{name}' нормализован: " +
                    "anchorMin=anchorMax=(0,1), pivot=(0,1), anchoredPosition=(0,0), sizeDelta=(0,0). " +
                    "Линии рисуются в системе координат top-left родителя.",
                    this);
            }
        }

        private int CountLineChildren()
        {
            if (_rt == null) return 0;
            int count = 0;
            for (int i = 0; i < _rt.childCount; i++)
            {
                var c = _rt.GetChild(i);
                if (c == null) continue;
                if (c.name.StartsWith(LinePrefix, StringComparison.Ordinal)) count++;
            }
            return count;
        }

        private static void DestroySafe(GameObject go)
        {
            if (go == null) return;

#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                // DestroyImmediate запрещён внутри OnValidate / physics / rendering колбэков.
                // Откладываем фактическое удаление до конца текущего редакторного тика.
                UnityEditor.EditorApplication.delayCall += () =>
                {
                    if (go != null) UnityEngine.Object.DestroyImmediate(go);
                };
                return;
            }
#endif

            UnityEngine.Object.Destroy(go);
        }

        // ─────────────────────────────────────────────────────────────────────
        // Gizmos (Scene view)
        // ─────────────────────────────────────────────────────────────────────

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (!_drawGizmos) return;
            if (_pairs == null) return;

            for (int i = 0; i < _pairs.Length; i++)
            {
                var pair = _pairs[i];
                if (pair.from == null || pair.to == null) continue;

                Vector3 fromPos = pair.from.position;
                Vector3 toPos = pair.to.position;

                // from — жёлтая сфера
                Gizmos.color = new Color(1f, 0.85f, 0f, 1f);
                Gizmos.DrawWireSphere(fromPos, 0.05f);
                Gizmos.DrawSphere(fromPos, 0.015f);

                // to — голубая сфера
                Gizmos.color = new Color(0.4f, 0.8f, 1f, 1f);
                Gizmos.DrawWireSphere(toPos, 0.05f);
                Gizmos.DrawSphere(toPos, 0.015f);

                // соединительная линия — белая полупрозрачная
                Gizmos.color = new Color(1f, 1f, 1f, 0.5f);
                Gizmos.DrawLine(fromPos, toPos);
            }
        }
#endif
    }
}