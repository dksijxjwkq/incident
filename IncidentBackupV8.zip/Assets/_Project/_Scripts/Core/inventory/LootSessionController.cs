using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Извлечено из K_InventoryUI (Задача 5D — Loot Session).
    ///
    /// Отвечает ТОЛЬКО за лут-режим (открытие внешних контейнеров/ящиков):
    ///   - Ведение состояния IsLooting
    ///   - Хранение ActiveLootController, LootCols, LootRows
    ///   - Открытие/закрытие лута (мьют UI surroundings-панели)
    ///   - Restore/Get контроллера лута из слотов окружения
    ///
    /// НЕ отвечает за:
    ///   - multi-window систему рюкзаков (BackpackContainerManager)
    ///   - drag/drop cycle (TryStartDrag, EndDragComplete, CancelDrag)
    ///   - рендеринг (InventoryUISync)
    ///   - построение сеток (InventoryGridBuilder)
    ///   - save-синхронизацию (InventorySaveSync)
    ///
    /// ВНИМАНИЕ: класс СИНХРОННЫЙ. Запрещено использовать async/await,
    /// Task, Coroutine, yield return.
    ///
    /// Создаётся в K_InventoryUI.Awake() и инициализируется ссылками на
    /// K_InventoryUI (для визуальных хуков) и BackpackContainerManager
    /// (для Suspend/Resume окон рюкзаков при луте).
    /// </summary>
    public sealed class LootSessionController
    {
        // ═══════════════════════════════════════════════════════════
        //  ЗАВИСИМОСТИ
        // ═══════════════════════════════════════════════════════════
        private K_InventoryUI _ui;
        private BackpackContainerManager _backpackManager;

        // ═══════════════════════════════════════════════════════════
        //  ВНУТРЕННЕЕ СОСТОЯНИЕ ЛУТА
        // ═══════════════════════════════════════════════════════════
        private bool _isLooting;
        private InventoryController _activeLootController;
        private int _lootCols;
        private int _lootRows;

        // ═══════════════════════════════════════════════════════════
        //  ПУБЛИЧНЫЙ API
        // ═══════════════════════════════════════════════════════════
        public bool IsLooting => _isLooting;
        public InventoryController ActiveLootController => _activeLootController;
        public int LootCols => _lootCols;
        public int LootRows => _lootRows;

        /// <summary>
        /// Инициализация. Вызывается из K_InventoryUI.Awake() ПОСЛЕ создания
        /// _backpackManager, но ДО _backpackManager.Initialize(...) — потому что
        /// _backpackManager.Initialize получает делегаты, ссылающиеся на _lootSession.
        /// </summary>
        public void Initialize(K_InventoryUI ui, BackpackContainerManager backpackManager)
        {
            _ui = ui;
            _backpackManager = backpackManager;
        }

        /// <summary>
        /// Открыть лут (внешний контейнер/ящик).
        /// Замещает бывший K_InventoryUI.OpenContainer(...).
        ///
        /// Логика:
        ///   1. Если открыты окна рюкзаков — приостановить их (SuspendForLoot),
        ///      чтобы они не пересекались с панелью лута.
        ///   2. Если повторно кликаем по тому же активному контейнеру —
        ///      закрыть всё (CloseAll) и выйти.
        ///   3. Отписаться от событий предыдущего контейнера.
        ///   4. Установить новый ActiveLootController и размерности сетки.
        ///   5. Подписаться на события нового контейнера.
        ///   6. Через K_InventoryUI.BeginLootVisuals — активировать UI
        ///      (панель, текст названия, rebuild сетки, ForceRefresh).
        /// </summary>
        public void Open(InventoryController controller, string containerName, int cols, int rows)
        {
            // 1. Suspend плавающих окон рюкзаков, чтобы они не пересекались с лутом.
            if (_backpackManager != null && _backpackManager.OpenWindows.Count > 0)
                _backpackManager.SuspendForLoot();

            if (controller == null) return;

            // 2. Повторный клик по тому же контейнере — закрываем всё.
            if (_isLooting && _activeLootController == controller)
            {
                _ui.CloseAll();
                return;
            }

            // 3. Отписываемся от событий старого контейнера.
            //    (Если мы уже лутали что-то другое — ActiveContainerController
            //    вернёт старый ActiveLootController, и отписка пойдёт корректно.)
            _ui.UnsubscribeFromContainerEvents();

            // 4. СНАЧАЛА устанавливаем loot-состояние, ПОТОМ вызываем
            //    SetActiveContainerController — чтобы маршрутизация в K_InventoryUI
            //    (IsLooting=true → пишем в _lootSession.SetActiveLootController)
            //    сработала правильно и не было окна, когда _isLooting=true,
            //    а _activeLootController ещё null.
            _isLooting = true;
            _activeLootController = controller;
            _lootCols = cols;
            _lootRows = rows;
            _ui.SetActiveContainerController(controller);

            // Зеркалируем размерности в K_InventoryUI для backwards compat
            // (GetGridWidth/Height, RebuildSurroundingsGrid и т.д. читают _currentContainerCols/Rows).
            _ui.SetCurrentContainerDimensions(cols, rows);

            // 5. Подписываемся на события нового контейнера.
            _ui.SubscribeToContainerEvents();

            // 6. Активируем визуал.
            _ui.BeginLootVisuals(containerName, cols, rows);
        }

        /// <summary>
        /// Закрыть лут и вернуть UI в обычный режим.
        /// НЕ закрывает окна рюкзаков и НЕ закрывает основной инвентарь —
        /// только снимает лут-состояние и скрывает панель контейнера.
        /// Для полного закрытия используется K_InventoryUI.CloseAll().
        /// </summary>
        public void Close()
        {
            if (!_isLooting) return;

            _ui.UnsubscribeFromContainerEvents();
            _ui.EndLootVisuals();

            _isLooting = false;
            _activeLootController = null;
            _lootCols = 0;
            _lootRows = 0;
            _ui.SetCurrentContainerDimensions(0, 0);
            _ui.SetActiveContainerController(null);

            // Возвращаем плавающие окна рюкзаков, если они были suspended.
            if (_backpackManager != null && _backpackManager.OpenWindows.Count > 0)
                _backpackManager.ResumeAfterLoot();
        }

        /// <summary>
        /// Сбрасывает состояние лута БЕЗ визуальных побочных эффектов.
        /// Используется в K_InventoryUI.CloseAll(), который сам управляет
        /// визуальной очисткой (скрытие панелей, return-to-pool и т.д.).
        /// </summary>
        public void ResetLootState()
        {
            _isLooting = false;
            _activeLootController = null;
            _lootCols = 0;
            _lootRows = 0;
            _ui?.SetCurrentContainerDimensions(0, 0);
        }

        /// <summary>
        /// Устанавливает ActiveLootController без побочных эффектов на UI.
        /// Используется K_InventoryUI.SetActiveContainerController — когда
        /// IsLooting=true, он маршрутизирует вызов сюда вместо backpackManager.
        /// </summary>
        public void SetActiveLootController(InventoryController controller)
        {
            _activeLootController = controller;
        }

        

public void RestoreLootControllerIfLooting()
{
    if (!_isLooting) return;
    var root = _backpackManager?.OriginalSurroundingsGrid
               ?? _backpackManager?.OriginalSurroundingsItemsContainer;
    if (root == null) return;
    var slots = root.GetComponentsInChildren<K_InventorySlotUI>(true);
    if (slots == null) return;
    foreach (var s in slots)
    {
        if (s != null && s.BoundController != null && !s.BoundController.IsDisposed)
        {
            _activeLootController = s.BoundController;
            _ui.SetActiveContainerController(s.BoundController);
            if (_lootCols <= 0) _lootCols = s.BoundController.Width;
            if (_lootRows <= 0) _lootRows = s.BoundController.Height;
            _ui.SetCurrentContainerDimensions(_lootCols, _lootRows);
            break;
        }
    }
}

  public InventoryController GetLootControllerFromSlots()
{
    var root = _backpackManager?.OriginalSurroundingsGrid
               ?? _backpackManager?.OriginalSurroundingsItemsContainer;
    if (root == null) return null;
    var slots = root.GetComponentsInChildren<K_InventorySlotUI>(true);
    if (slots == null) return null;
    foreach (var s in slots)
    {
        if (s != null && s.BoundController != null && !s.BoundController.IsDisposed)
            return s.BoundController;
    }
    return null;
}
    }
}
