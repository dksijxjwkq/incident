﻿using UnityEngine;
using System;

namespace K_Incident.Core
{
    /// <summary>
    /// Система управления весом и перегрузом (Аспект №2)
    /// </summary>
    public class K_WeightManager : MonoBehaviour
    {
        // =====================================================================
        // СОБЫТИЯ
        // =====================================================================
        public event Action OnWeightChanged;
        public event Action OnOverloadStateChanged;

        // =====================================================================
        // НАСТРОЙКИ ВЕСА
        // =====================================================================
      [Header("Weight Settings")]
[SerializeField] private float _maxCapacity = 65f;
[SerializeField] private float _currentWeight = 0f;

[Header("Weight Thresholds (kg)")]
[SerializeField, Tooltip("Вес, с которого начинаются штрафы скорости. До него — ×1.0.")]
private float _debuffStartWeight = 50f;

[Header("Weight Ratio Thresholds")]
[SerializeField] private float _warningThreshold = 0.5f;
[SerializeField] private float _overloadThreshold = 0.9f;
[SerializeField] private float _criticalThreshold = 1.1f;

[Header("Speed Multipliers")]
[SerializeField] private float _normalSpeedMult = 1.0f;

[SerializeField] private float _minSpeedFloor = 0.05f;

[Header("Stamina Costs")]
[SerializeField] private float _normalStaminaCost = 0f;

// Оставлено для обратной совместимости с инспектором.
// В новой формуле UpdateWeightState() не используется.
[SerializeField] private float _overloadStaminaCost = 2.0f;

[SerializeField] private float _criticalStaminaCost = 4.0f;

        [Header("References")]
        [SerializeField] private K_VitalitySystem _vitalitySystem;
        [SerializeField] private K_HealthSystem _healthSystem;

        // =====================================================================
        // ВНУТРЕННИЕ ПЕРЕМЕННЫЕ
        // =====================================================================
        private bool _isOverloaded = false;
        private bool _isCriticalOverload = false;
        private float _weightRatio = 0f;
        private float _speedMultiplier = 1.0f;
        private float _staminaDrainRate = 0f;
        private float _accelerationTime = 0.25f;

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
        {
            if (_vitalitySystem == null)
                _vitalitySystem = GetComponent<K_VitalitySystem>();

            if (_healthSystem == null)
                _healthSystem = GetComponent<K_HealthSystem>();

            UpdateWeightState();
        }

        // =====================================================================
        // ONDESTROY — ОТПИСКА ОТ СОБЫТИЙ (ИСПРАВЛЕНИЕ УТЕЧКИ)
        // =====================================================================
        private void OnDestroy()
        {
            OnWeightChanged = null;
            OnOverloadStateChanged = null;
        }

        // =====================================================================
        // ONVALIDATE — ДЛЯ ИЗМЕНЕНИЙ В INSPECTOR ВО ВРЕМЯ PLAY MODE
        // =====================================================================
       private void OnValidate()
{
    _maxCapacity = Mathf.Max(0.001f, _maxCapacity);
    _currentWeight = Mathf.Max(0f, _currentWeight);

    _debuffStartWeight = Mathf.Clamp(_debuffStartWeight, 0f, _maxCapacity);

    _warningThreshold = Mathf.Max(0f, _warningThreshold);
    _overloadThreshold = Mathf.Max(_warningThreshold + 0.001f, _overloadThreshold);
    _criticalThreshold = Mathf.Max(_overloadThreshold + 0.001f, _criticalThreshold);
    _minSpeedFloor = Mathf.Clamp01(_minSpeedFloor);

    if (Application.isPlaying)
    {
        UpdateWeightState();
    }
}
        public float CurrentWeight => _currentWeight;
        public float MaxCapacity => _maxCapacity;
        public float WarningThreshold => _warningThreshold;
        public float OverloadThreshold => _overloadThreshold;
        public float CriticalThreshold => _criticalThreshold;
        public bool IsFullyStopped() => _currentWeight >= _maxCapacity;
        public float DebuffStartWeight => _debuffStartWeight;
        public float GetCurrentWeightRatio()
        {
            if (_maxCapacity <= 0f) return 0f;
            return _currentWeight / _maxCapacity;
        }

        public float GetSpeedMultiplier() => _speedMultiplier;
        public float GetStaminaDrainRate() => _staminaDrainRate;
        public float GetAccelerationTime() => _accelerationTime;
        public bool IsOverloaded() => _isOverloaded;
        public bool IsCriticalOverload() => _isCriticalOverload;
        public bool CanSprint() => !_isOverloaded;

        // =====================================================================
        // ИЗМЕНЕНИЕ ВЕСА
        // =====================================================================
        public void SetWeight(float kg)
        {
            if (float.IsNaN(kg) || float.IsInfinity(kg))
            {
                throw new ArgumentOutOfRangeException(nameof(kg),
                    $"Invalid weight value: {kg}");
            }
            kg = Mathf.Max(0f, kg);

            if (Mathf.Approximately(_currentWeight, kg))
                return;

            _currentWeight = kg;
            UpdateWeightState();
        }

        public void AddWeight(float weight)
        {
            if (float.IsNaN(weight) || float.IsInfinity(weight))
            {
                throw new ArgumentOutOfRangeException(nameof(weight),
                    $"Invalid weight delta: {weight}");
            }

            _currentWeight = Mathf.Max(0f, _currentWeight + weight);
            UpdateWeightState();
        }

        public void RemoveWeight(float weight)
        {
            if (float.IsNaN(weight) || float.IsInfinity(weight))
            {
                throw new ArgumentOutOfRangeException(nameof(weight),
                    $"Invalid weight delta: {weight}");
            }

            _currentWeight = Mathf.Max(0f, _currentWeight - weight);
            UpdateWeightState();
        }

        public void SetMaxCapacity(float newCapacity)
        {
            if (float.IsNaN(newCapacity) || float.IsInfinity(newCapacity))
            {
                throw new ArgumentOutOfRangeException(nameof(newCapacity),
                    $"Invalid max capacity: {newCapacity}");
            }

            _maxCapacity = Mathf.Max(0.001f, newCapacity);
            UpdateWeightState();
        }

        // =====================================================================
        // РАСЧЁТ МУЛЬТИПЛИКАТОРОВ
        // =====================================================================
       public void UpdateWeightState()
{
    _weightRatio = GetCurrentWeightRatio();

    // Гиподинамия (голод < 30) — эффективный вес +33%, как раньше через reduced capacity.
    float effectiveWeight = _currentWeight;
    if (_vitalitySystem != null && _vitalitySystem.Hunger <= 30f)
        effectiveWeight /= 0.75f;

    bool wasOverloaded = _isOverloaded;
    bool wasCritical = _isCriticalOverload;

    // ── Основная формула скорости ──
    if (effectiveWeight <= _debuffStartWeight)
        _speedMultiplier = 1.0f;
    else if (effectiveWeight >= _maxCapacity)
        _speedMultiplier = 0f;
    else
        _speedMultiplier = Mathf.Lerp(1.0f, 0.0f,
            (effectiveWeight - _debuffStartWeight) / (_maxCapacity - _debuffStartWeight));

    // ── Состояния ──
    _isOverloaded = effectiveWeight >= _debuffStartWeight;      // спринт заблокирован с 50 кг
    _isCriticalOverload = effectiveWeight >= _maxCapacity;      // полный стоп

    // ── Стамина и ускорение (остаются ступенчатыми — не влияют на «плавность» скорости) ──
    if (effectiveWeight < _debuffStartWeight)
    {
        _staminaDrainRate = _normalStaminaCost;
        _accelerationTime = 0.25f;
    }
    else if (effectiveWeight < _maxCapacity)
    {
        _staminaDrainRate = _overloadStaminaCost;
        _accelerationTime = 0.5f;
    }
    else
    {
        _staminaDrainRate = 0f;      // стоим — стамину не тратим
        _accelerationTime = 0.5f;
    }

    ApplyLegInjurySynergy();

    // Множитель может стать 0 — НЕ поднимать его обратно minSpeedFloor (иначе не будет стопа).

    OnWeightChanged?.Invoke();
    if (wasOverloaded != _isOverloaded || wasCritical != _isCriticalOverload)
    {
        OnOverloadStateChanged?.Invoke();
        if (_vitalitySystem != null)
            _vitalitySystem.SetOverload(_isCriticalOverload);
    }
}
        private void ApplyLegInjurySynergy()
        {
            if (_healthSystem == null) return;

            int brokenLegs = 0;

            if (_healthSystem.IsFractured(BodyPart.LeftLeg) && !_healthSystem.IsSplinted(BodyPart.LeftLeg))
                brokenLegs++;
            if (_healthSystem.IsFractured(BodyPart.RightLeg) && !_healthSystem.IsSplinted(BodyPart.RightLeg))
                brokenLegs++;

            float injuryMult = brokenLegs switch
            {
                1 => 0.6f,
                2 => 0.3f,
                _ => 1.0f
            };

            _speedMultiplier *= injuryMult;
            _speedMultiplier = Mathf.Max(_speedMultiplier, _minSpeedFloor);
        }

        // =====================================================================
        // ГИПОДИНАМИЯ
        // =====================================================================
       
        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Debug: Add 10kg")]
        public void DebugAddWeight() => AddWeight(10f);

        [ContextMenu("Debug: Add 20kg (Critical Overload)")]
        public void DebugAddCritical() => AddWeight(20f);

        [ContextMenu("Debug: Remove 10kg")]
        public void DebugRemoveWeight() => RemoveWeight(10f);

        [ContextMenu("Debug: Set Critical Overload (120%)")]
        public void DebugCriticalOverload() => SetWeight(_maxCapacity * 1.2f);

        [ContextMenu("Debug: Reset Weight")]
        public void DebugResetWeight() => SetWeight(0f);

        [ContextMenu("Debug: Print Status")]
        public void DebugPrintStatus()
        {
            Debug.Log($"[WeightManager] Current: {_currentWeight:F1}kg | Max: {_maxCapacity:F1}kg");
            Debug.Log($"[WeightManager] Ratio: {_weightRatio * 100:F0}% | SpeedMult: {_speedMultiplier:F2}");
            Debug.Log($"[WeightManager] StaminaDrain: {_staminaDrainRate:F1}/sec");
            Debug.Log($"[WeightManager] Overload: {_isOverloaded} | Critical: {_isCriticalOverload}");
        }
    }
}