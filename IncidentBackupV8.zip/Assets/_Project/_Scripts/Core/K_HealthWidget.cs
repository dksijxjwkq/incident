﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace K_Incident.Core.UI
{
    public class K_HealthWidget : MonoBehaviour
    {
        // =====================================================================
        // СИСТЕМНЫЕ ССЫЛКИ
        // =====================================================================
        [Header("System References")]
        [SerializeField] private K_HealthSystem _healthSystem;
        [SerializeField] private K_VitalitySystem _vitalitySystem;
        [SerializeField] private K_TimeSystem _timeSystem;
        [SerializeField] private K_CoagulantItem _coagulantItem;
        [SerializeField] private K_WeightManager _weightManager;

        // =====================================================================
        // КУКЛА ЗДОРОВЬЯ
        // =====================================================================
        [Header("Health Doll (Segments)")]
        [SerializeField] private Image _headImg;
        [SerializeField] private Image _torsoImg;
        [SerializeField] private Image _stomachImg;
        [SerializeField] private Image _leftArmImg;
        [SerializeField] private Image _rightArmImg;
        [SerializeField] private Image _leftLegImg;
        [SerializeField] private Image _rightLegImg;
        [SerializeField] private Gradient _healthGradient;

        // =====================================================================
        // ИНДИКАТОРЫ МЕТАБОЛИЗМА
        // =====================================================================
        [Header("Metabolism & Status Icons")]
        [SerializeField] private CanvasGroup _metabolismGroup;
        [SerializeField] private Gradient _statusGradient;
        [SerializeField] private Gradient _bleedingGradient;
        [SerializeField] private Gradient _hungerGradient;
        [SerializeField] private Gradient _thirstGradient;
        [SerializeField] private Gradient _overloadGradient;

        [Space]
        [SerializeField] private Image _iconHunger;
        [SerializeField] private Image _iconThirst;
        [SerializeField] private Image _iconRadiation;
        [SerializeField] private Image _iconCold;
        [SerializeField] private Image _iconOverload;
        [SerializeField] private Image _iconBleeding;
        [SerializeField] private Image _iconLaceration;
        [SerializeField] private Image _iconHangover;
        [SerializeField] private Image _iconDrunk;
        [SerializeField] private Image _iconStimOn;
        [SerializeField] private Image _iconStimOff;
        [SerializeField] private Image _iconCoagulant;

        // =====================================================================
        // ИНДИКАТОРЫ ПЕРЕЛОМОВ
        // =====================================================================
        [Header("Fracture Icons (Manual Setup)")]
        [SerializeField] private Image[] _fractureIcons;

        // =====================================================================
        // НАСТРОЙКИ UI
        // =====================================================================
        [Header("UI Settings")]
        [SerializeField] private TextMeshProUGUI _clockText;
        [SerializeField] private float _hudDisplayDuration = 4.0f;
        [SerializeField] private float _hudFadeSpeed = 2.0f;

        // =====================================================================
        // ВНУТРЕННИЕ ПЕРЕМЕННЫЕ
        // =====================================================================
        private Coroutine _fadeCoroutine;
        private Coroutine _clockCoroutine;
        private float _displayTimer = 0f;

        // ✅ НОВОЕ: Кэш всех изображений куклы для быстрой проверки
        private Image[] _healthDollImages;

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
        {
            // ✅ КЭШИРУЕМ все изображения куклы при старте
            _healthDollImages = new Image[]
            {
                _headImg, _torsoImg, _stomachImg,
                _leftArmImg, _rightArmImg,
                _leftLegImg, _rightLegImg
            };
        }

        private void Start()
        {
            // ФИКС: Авто-поиск систем, если не назначены в Inspector
            if (_healthSystem == null)
                _healthSystem = FindAnyObjectByType<K_HealthSystem>();
            if (_vitalitySystem == null)
                _vitalitySystem = FindAnyObjectByType<K_VitalitySystem>();
            if (_timeSystem == null)
                _timeSystem = FindAnyObjectByType<K_TimeSystem>();

            if (_healthSystem == null || _vitalitySystem == null || _timeSystem == null)
            {
                Debug.LogWarning("[K_HealthWidget] Core systems missing. " +
                    $"HealthSystem={_healthSystem != null}, VitalitySystem={_vitalitySystem != null}, TimeSystem={_timeSystem != null}. " +
                    "Assign them in Inspector or ensure they exist in scene.");
            }

            // ✅ КРИТИЧНО: Гарантируем видимость куклы при старте
            ForceHealthDollVisible();

            // ✅ Гарантируем что метаболизм виден
            if (_metabolismGroup != null && _metabolismGroup.alpha < 1f)
            {
                _metabolismGroup.alpha = 1f;
            }

            if (_coagulantItem == null)
                _coagulantItem = FindAnyObjectByType<K_CoagulantItem>();
            if (_weightManager == null)
                _weightManager = FindAnyObjectByType<K_WeightManager>();

            InitializeFractureIcons();
            RefreshHealth();
            RefreshMetabolism();

            _clockCoroutine = StartCoroutine(ClockUpdateRoutine());

            Debug.Log("[K_HealthWidget] Initialized successfully");
        }

        // ✅ НОВЫЙ МЕТОД: Принудительно делает куклу видимой
        private void ForceHealthDollVisible()
        {
            if (_healthDollImages == null) return;

            foreach (var img in _healthDollImages)
            {
                if (img != null)
                {
                    img.enabled = true;
                    img.color = new Color(img.color.r, img.color.g, img.color.b, 1f); // Полная непрозрачность
                }
            }
        }

        private void OnEnable()
        {
            // ✅ При включении объекта — снова гарантируем видимость
            ForceHealthDollVisible();

            if (_healthSystem != null) _healthSystem.OnHealthChanged += RefreshHealth;
            if (_vitalitySystem != null)
            {
                _vitalitySystem.OnMetabolismChanged += RefreshMetabolism;
                _vitalitySystem.OnStimulatorChanged += RefreshMetabolism;
                _vitalitySystem.OnHangoverChanged += RefreshMetabolism;
                _vitalitySystem.OnColdExposureChanged += RefreshMetabolism;
                _vitalitySystem.OnOverloadChanged += RefreshMetabolism;
            }
            if (_weightManager != null)
            {
                _weightManager.OnWeightChanged += RefreshMetabolism;
            }
        }

        private void OnDisable()
        {
            if (_healthSystem != null) _healthSystem.OnHealthChanged -= RefreshHealth;
            if (_vitalitySystem != null)
            {
                _vitalitySystem.OnMetabolismChanged -= RefreshMetabolism;
                _vitalitySystem.OnStimulatorChanged -= RefreshMetabolism;
                _vitalitySystem.OnHangoverChanged -= RefreshMetabolism;
                _vitalitySystem.OnColdExposureChanged -= RefreshMetabolism;
                _vitalitySystem.OnOverloadChanged -= RefreshMetabolism;
            }
            if (_weightManager != null)
            {
                _weightManager.OnWeightChanged -= RefreshMetabolism;
            }
        }

        private void OnDestroy()
        {
            if (_clockCoroutine != null) StopCoroutine(_clockCoroutine);
            if (_fadeCoroutine != null) StopCoroutine(_fadeCoroutine);
        }

        private void InitializeFractureIcons()
        {
            if (_fractureIcons == null || _fractureIcons.Length == 0)
            {
                Debug.LogWarning("[K_HealthWidget] No fracture icons assigned!");
                return;
            }
            foreach (var icon in _fractureIcons)
            {
                if (icon != null) icon.gameObject.SetActive(false);
            }
            Debug.Log($"[K_HealthWidget] Initialized {_fractureIcons.Length} fracture icons");
        }

        private void RefreshHealth()
        {
            UpdateHealthUI();
            UpdateFractureIcons();
            UpdateCoagulantIcon();
            ShowMetabolismHUD();
        }

        private void RefreshMetabolism()
        {
            UpdateMetabolismUI();
            UpdateFractureIcons();
            UpdateCoagulantIcon();
            ShowMetabolismHUD();
        }

        private void UpdateHealthUI()
        {
            if (_healthSystem == null)
            {
                Debug.LogWarning("[K_HealthWidget] HealthSystem is null!");
                return;
            }

            if (_healthGradient == null)
            {
                Debug.LogWarning("[K_HealthWidget] HealthGradient is null!");
                return;
            }

            UpdateSegmentColor(_headImg, _healthSystem.HeadHP, _healthSystem.BaseHeadHP);
            UpdateSegmentColor(_torsoImg, _healthSystem.TorsoHP, _healthSystem.BaseTorsoHP);
            UpdateSegmentColor(_stomachImg, _healthSystem.StomachHP, _healthSystem.BaseStomachHP);
            UpdateSegmentColor(_leftArmImg, _healthSystem.LeftArmHP, _healthSystem.BaseLeftArmHP);
            UpdateSegmentColor(_rightArmImg, _healthSystem.RightArmHP, _healthSystem.BaseRightArmHP);
            UpdateSegmentColor(_leftLegImg, _healthSystem.LeftLegHP, _healthSystem.BaseLeftLegHP);
            UpdateSegmentColor(_rightLegImg, _healthSystem.RightLegHP, _healthSystem.BaseRightLegHP);
        }

        private void UpdateSegmentColor(Image img, float current, float baseMax)
        {
            if (img == null) return;
            if (baseMax <= 0f) return;
            if (_healthGradient == null)
            {
                img.color = Color.white;
                return;
            }

            float ratio = Mathf.Clamp01(current / baseMax);
            Color newColor = _healthGradient.Evaluate(ratio);

            // ✅ Гарантируем что Image включен и непрозрачный
            img.enabled = true;
            img.color = new Color(newColor.r, newColor.g, newColor.b, 1f);
        }

        private void UpdateFractureIcons()
        {
            if (_healthSystem == null || _fractureIcons == null) return;
            int fractureCount = _healthSystem.FractureCount;
            for (int i = 0; i < _fractureIcons.Length; i++)
            {
                if (_fractureIcons[i] != null)
                    _fractureIcons[i].gameObject.SetActive(i < fractureCount);
            }
        }

        private void UpdateCoagulantIcon()
        {
            if (_coagulantItem == null || _iconCoagulant == null) return;
            bool shouldShow = _coagulantItem.ShouldShowIcon();
            _iconCoagulant.gameObject.SetActive(shouldShow);
            if (shouldShow)
            {
                bool hasDamage = _coagulantItem.HasDamagedSegments();
                _iconCoagulant.color = new Color(1f, 1f, 1f, hasDamage ? 1f : 0.5f);
            }
        }

        private void UpdateMetabolismUI()
        {
            if (_vitalitySystem == null) return;

            SafeUpdateIcon(_iconHunger, _vitalitySystem.Icon_Hunger, _vitalitySystem.Hunger / 100f, _hungerGradient);
            SafeUpdateIcon(_iconThirst, _vitalitySystem.Icon_Thirst, _vitalitySystem.Thirst / 100f, _thirstGradient);
            SafeUpdateIcon(_iconRadiation, _vitalitySystem.Icon_Radiation, 1f - (_vitalitySystem.Radiation / 100f), _healthGradient);

            if (_vitalitySystem.Icon_Bleeding > 0)
                SafeUpdateIcon(_iconBleeding, true, _vitalitySystem.Icon_Bleeding / 3f, _bleedingGradient);
            else
                SafeUpdateIcon(_iconBleeding, false);

            SafeUpdateIcon(_iconLaceration, _vitalitySystem.Icon_Laceration);
            SafeUpdateIcon(_iconStimOn, _vitalitySystem.Icon_StimOn);
            SafeUpdateIcon(_iconStimOff, _vitalitySystem.Icon_StimOff);
            SafeUpdateIcon(_iconHangover, _vitalitySystem.Icon_Hangover);
            SafeUpdateIcon(_iconCold, _vitalitySystem.Icon_Cold);

            if (_weightManager != null)
            {
                float weightRatio = _weightManager.GetCurrentWeightRatio();
                bool isOverloaded = weightRatio >= 0.9f;
                if (isOverloaded)
                {
                    float normalizedRatio = Mathf.InverseLerp(0.9f, 1.1f, weightRatio);
                    normalizedRatio = Mathf.Clamp01(normalizedRatio);
                    SafeUpdateIcon(_iconOverload, true, normalizedRatio, _overloadGradient);
                }
                else
                    SafeUpdateIcon(_iconOverload, false);
            }
            else
                SafeUpdateIcon(_iconOverload, _vitalitySystem.Icon_Overload);

            SafeUpdateIcon(_iconDrunk, _vitalitySystem.Icon_Drunk);
        }

        private void SafeUpdateIcon(Image img, bool isActive, float? colorT = null, Gradient customGradient = null)
        {
            if (img == null) return;
            if (img.gameObject.activeSelf != isActive)
                img.gameObject.SetActive(isActive);
            if (isActive && colorT.HasValue)
            {
                Gradient g = customGradient != null ? customGradient : _statusGradient;
                if (g != null)
                    img.color = g.Evaluate(Mathf.Clamp01(colorT.Value));
            }
        }

        private IEnumerator ClockUpdateRoutine()
        {
            WaitForSeconds wait = new WaitForSeconds(1.25f);
            while (true)
            {
                if (_timeSystem != null && _clockText != null)
                {
                    float hoursFloat = _timeSystem.CurrentGameHours;
                    int hours = Mathf.FloorToInt(hoursFloat);
                    int minutes = Mathf.FloorToInt((hoursFloat - hours) * 60f);
                    _clockText.text = $"{hours:00}:{minutes:00}";
                }
                yield return wait;
            }
        }

        private void ShowMetabolismHUD()
        {
            if (!gameObject.activeInHierarchy) return;
            _displayTimer = _hudDisplayDuration;
            if (_fadeCoroutine == null)
                _fadeCoroutine = StartCoroutine(FadeHUDRoutine());
        }

        private IEnumerator FadeHUDRoutine()
        {
            if (_metabolismGroup == null) yield break;

            // ✅ Начинаем с полной видимости
            _metabolismGroup.alpha = 1f;

            while (_metabolismGroup.alpha < 1f && _displayTimer > 0f)
            {
                _metabolismGroup.alpha += Time.deltaTime * _hudFadeSpeed;
                yield return null;
            }
            while (_displayTimer > 0f)
            {
                _displayTimer -= Time.deltaTime;
                yield return null;
            }
            while (_metabolismGroup.alpha > 0f)
            {
                _metabolismGroup.alpha -= Time.deltaTime * _hudFadeSpeed;
                yield return null;
            }
            _fadeCoroutine = null;
        }

        public void ForceRefresh()
        {
            RefreshHealth();
            RefreshMetabolism();
        }

        // ✅ НОВЫЙ КОНТЕКСТНЫЙ МЕТОД для ручной проверки
        [ContextMenu("Debug: Force All Visible")]
        public void DebugForceAllVisible()
        {
            Debug.Log("[HealthWidget] Forcing all elements visible...");
            ForceHealthDollVisible();

            if (_metabolismGroup != null)
            {
                _metabolismGroup.alpha = 1f;
                _metabolismGroup.interactable = true;
                _metabolismGroup.blocksRaycasts = true;
            }

            // Включаем все иконки метаболизма для теста
            var icons = new[] { _iconHunger, _iconThirst, _iconRadiation, _iconCold, _iconOverload, _iconBleeding };
            foreach (var icon in icons)
            {
                if (icon != null)
                {
                    icon.enabled = true;
                    icon.color = Color.white;
                }
            }
            Debug.Log("[HealthWidget] Done.");
        }
    }
}