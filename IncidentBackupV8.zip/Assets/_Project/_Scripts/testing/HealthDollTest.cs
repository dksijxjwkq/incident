using UnityEngine;
using UnityEngine.UI;

public class DebugHealthDolll : MonoBehaviour
{
    void Start()
    {
        var images = GetComponentsInChildren<Image>(true);
        Debug.Log($"[Debug] ������� Image: {images.Length}");

        foreach (var img in images)
        {
            Debug.Log($"[Debug] {img.gameObject.name}: " +
                     $"Enabled={img.enabled}, " +
                     $"Color={img.color}, " +
                     $"Sprite={(img.sprite != null ? img.sprite.name : "NULL")}");
        }

        var groups = GetComponentsInParent<CanvasGroup>();
        foreach (var g in groups)
        {
            Debug.Log($"[Debug] CanvasGroup '{g.gameObject.name}': Alpha={g.alpha}");
        }
    }
}