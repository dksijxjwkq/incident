﻿using UnityEngine;
using UnityEngine.UI;

public class FixRenderOrder : MonoBehaviour
{
    private void Start()
    {
        // Находим все сетки и контейнеры
        var backpackGrid = transform.Find("BackpackGrid");
        var pocketsGrid = transform.Find("PocketsGrid");
        var backpackItems = transform.Find("backpackitemscontainer");
        var pocketsItems = transform.Find("pocketsitemscontainer");

        // Устанавливаем порядок отрисовки через Canvas.sortingOrder
        SetCanvasOrder(backpackGrid, 0);
        SetCanvasOrder(pocketsGrid, 0);
        SetCanvasOrder(backpackItems, 10);
        SetCanvasOrder(pocketsItems, 10);

        Debug.Log("[FixRenderOrder] Render order fixed! Grids=0, Items=10");
    }

    private void SetCanvasOrder(Transform obj, int order)
    {
        if (obj == null) return;

        // Ищем Canvas на самом объекте
        var canvas = obj.GetComponent<Canvas>();
        if (canvas != null)
        {
            canvas.sortingOrder = order;
            canvas.overrideSorting = true;
            Debug.Log($"[FixRenderOrder] {obj.name} Canvas sortingOrder = {order}");
            return;
        }

        // Если Canvas не найден, ищем в детях
        var childCanvas = obj.GetComponentInChildren<Canvas>();
        if (childCanvas != null)
        {
            childCanvas.sortingOrder = order;
            childCanvas.overrideSorting = true;
            Debug.Log($"[FixRenderOrder] {childCanvas.name} (child) sortingOrder = {order}");
        }

        // Рекурсивно обрабатываем всех детей
        foreach (Transform child in obj)
        {
            SetCanvasOrder(child, order);
        }
    }
}
