using K_Incident.Core.Inventory;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    ///                                                                              .
    ///              K_InventoryUI                                                      (SRP).
    ///                  K_SaveManager               .
    /// </summary>
    public class PlayerEquipmentSaveService : MonoBehaviour, ISaveable
    {
        [Header("Dependencies (            Inspector)")]
        [SerializeField] private K_InventoryUI _inventoryUI;

        [Header("Equipment Slots (            Inspector)")]
        [SerializeField] private K_EquipmentSlotUI _primarySlot1;
        [SerializeField] private K_EquipmentSlotUI _primarySlot2;
        [SerializeField] private K_EquipmentSlotUI _pistolSlot;
        [SerializeField] private K_EquipmentSlotUI _meleeSlot;
        [SerializeField] private K_EquipmentSlotUI _backpackSlot;

        public string SaveID => "Player_Equipment";
        public bool IsDirty { get; set; } = true;

        private void Start()
        {
            if (_inventoryUI == null)
                _inventoryUI = GetComponentInParent<K_InventoryUI>();

            K_SaveManager.Instance?.Register(this);
        }

        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
        }

        public void Save(BinaryWriter writer)
        {
            // Синхронизация живых контроллеров открытых рюкзаков в их
            // InventoryItem._backpackContentsSerialized перед сериализацией.
            // Логика вынесена в InventorySaveSync (Задача 5E), вызов —
            // через тонкую обёртку K_InventoryUI.SyncAllBackpacksForSave().
            if (_inventoryUI != null)
                _inventoryUI.SyncAllBackpacksForSave();

            var slots = new K_EquipmentSlotUI[]
            {
        _primarySlot1, _primarySlot2, _pistolSlot, _meleeSlot, _backpackSlot
            };

            foreach (var slot in slots)
            {
                if (slot == null || slot.EquippedItem == null)
                {
                    writer.Write(0);
                    continue;
                }
                writer.Write(1);
                var saved = slot.EquippedItem.ToSaveData(0, 0);
                WriteSavedItemEquipment(writer, saved);
            }
        }

        public void Load(BinaryReader reader)
        {
            var slots = new K_EquipmentSlotUI[]
            {
                _primarySlot1, _primarySlot2, _pistolSlot, _meleeSlot, _backpackSlot
            };

            //           ,                   (         ).
            foreach (var slot in slots)
            {
                if (slot != null && slot.EquippedItem != null)
                    slot.SetEquippedItem(null);
            }

            //                                 _backpackController.
            if (_inventoryUI != null)
            {
                var bpController = _inventoryUI.GetControllerForGrid(GridType.Backpack);
                if (bpController != null)
                {
                    bpController.Clear();
                    _inventoryUI.OnBackpackUnequipped();
                }
            }

            var db = K_InventorySetup.DatabaseInstance;
            if (db == null)
            {
                Debug.LogWarning("[PlayerEquipmentSaveService.Load] No database   equipment load skipped.");
                return;
            }

            for (int i = 0; i < slots.Length; i++)
            {
                int hasItem = reader.ReadInt32();
                if (hasItem == 0) continue;
                if (slots[i] == null) continue;

                var saved = ReadSavedItemEquipment(reader);
                if (!saved.IsValid()) continue;

                var template = db.GetItemData(saved.ItemID);
                if (template == null)
                {
                    Debug.LogWarning($"[PlayerEquipmentSaveService.Load] Template '{saved.ItemID}' not found   skipping slot {i}.");
                    continue;
                }

                var item = InventoryItem.FromSaveData(saved, template);
                if (item == null) continue;

                slots[i].SetEquippedItem(item);
                if (slots[i].SlotType == EquipmentSlotType.Backpack && item.Data.IsBackpack && _inventoryUI != null)
                    _inventoryUI.OnBackpackEquipped(item);
            }

            if (_inventoryUI != null)
                _inventoryUI.ForceRefresh();
        }

        private void WriteSavedItemEquipment(BinaryWriter writer, SavedItem item)
        {
            writer.Write(item.ItemID);
            writer.Write(item.InstanceID);
            writer.Write(item.Quantity);
            writer.Write(item.Durability);
            writer.Write(item.IsRotated);
            writer.Write(item.IsFolded);

            int contentsCount = item.BackpackContents?.Count ?? 0;
            writer.Write(contentsCount);
            if (contentsCount > 0)
                foreach (var inner in item.BackpackContents)
                    WriteSavedItemEquipment(writer, inner);
        }

        private SavedItem ReadSavedItemEquipment(BinaryReader reader)
        {
            var item = new SavedItem
            {
                ItemID = reader.ReadString(),
                InstanceID = reader.ReadUInt32(),
                X = 0,
                Y = 0,
                Quantity = Mathf.Max(1, reader.ReadInt32()),
                Durability = Mathf.Max(0, reader.ReadInt32()),
                IsRotated = reader.ReadBoolean(),
                IsFolded = reader.ReadBoolean()
            };

            int contentsCount = reader.ReadInt32();
            if (contentsCount > 0)
            {
                item.BackpackContents = new List<SavedItem>(contentsCount);
                for (int j = 0; j < contentsCount; j++)
                    item.BackpackContents.Add(ReadSavedItemEquipment(reader));
            }
            return item;
        }
    }
}