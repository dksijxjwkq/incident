﻿// === Source: original file lines 11664-12424 ===
using K_Incident.Core.Inventory;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
public class UI_Item : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler,
    IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler,
    IDropHandler
{
#region Inspector Fields
    [Header("References")]
    [SerializeField] private Image _icon;
    [SerializeField] private TextMeshProUGUI _quantityText;
    [SerializeField] private GameObject _quantityGroup;

    [Header("Item Labels")]
    [SerializeField, Tooltip("Размер шрифта названия")]
    private float _nameFontSize = 10f;
    [SerializeField, Tooltip("Размер шрифта калибра")]
    private float _caliberFontSize = 9f;

    [Header("Selection (Click Highlight)")]
    [SerializeField, Tooltip("Цвет выделения при клике на предмет")]
    private Color _selectionColor = new Color(1f, 0.85f, 0f, 0.35f);

    [Header("Debug")]
    [SerializeField] private bool _debugLogs = false;
#endregion

#region Constants
    private static readonly Vector2 OFFSCREEN_POSITION = new Vector2(-9999f, -9999f);
    private static Sprite _transparentSprite;
    private static readonly HashSet<uint> _loggedMissingFoldIcon = new HashSet<uint>();
#endregion

#region Fields
    private InventoryItem _item;
    private K_InventoryUI _inventoryUI;
    private GridType _gridType;
    private int _gridX, _gridY;
    private bool _isDragging;
    private CanvasGroup _canvasGroup;
    private RectTransform _bodyRect;
    private RectTransform _iconRect;
    private bool _iconEnsuredAsChild;
    private Image _raycastTarget;
    private Image _selectionOverlay;
    private TextMeshProUGUI _nameText;
    private TextMeshProUGUI _caliberText;
    private InventoryController _boundController;
    private bool _isBeingDragged;
#endregion

#region Properties
    public bool TryGetVisualScreenBounds(UnityEngine.Camera camera, out Vector2 min, out Vector2 max)
    {
        return VisualRectUtility.TryGetVisualBounds(_iconRect, _icon, camera, out min, out max);
    }

    public InventoryItem Item => _item;
    public GridType GridType => _gridType;
    public int X => _gridX;
    public int Y => _gridY;
    public bool IsDragging => _isDragging;
    public Color SelectionColor => _selectionColor;
    public InventoryController BoundController => _boundController;

    public bool IsBeingDragged
    {
        get => _isBeingDragged;
        set => _isBeingDragged = value;
    }
#endregion

    private static Sprite GetTransparentSprite()
    {
        if (_transparentSprite != null) return _transparentSprite;
        var tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        tex.SetPixel(0, 0, Color.clear);
        tex.Apply();
        _transparentSprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), Vector2.zero, 1f);
        _transparentSprite.name = "TransparentRaycast";
        return _transparentSprite;
    }

#region Initialization
    private void Awake()
    {
        EnsureInitialized();
    }

    private void EnsureInitialized()
    {
        if (_bodyRect != null) return;
        _canvasGroup = GetComponent<CanvasGroup>();
        if (_canvasGroup == null)
            _canvasGroup = gameObject.AddComponent<CanvasGroup>();
        _bodyRect = GetComponent<RectTransform>();
        EnsureIconIsChild();
        EnsureRaycastTarget();
        EnsureSelectionOverlay();
    }

    private void EnsureIconIsChild()
    {
        if (_icon == null)
            _icon = GetComponentInChildren<Image>();
        if (_icon == null)
        {
            Debug.LogWarning($"[UI_Item] {gameObject.name}: Image (icon) не назначена!");
            return;
        }
        _iconRect = _icon.rectTransform;
        if (_iconRect == _bodyRect)
        {
            var childObj = new GameObject("Icon", typeof(RectTransform), typeof(Image));
            childObj.transform.SetParent(_bodyRect, false);
            var childRT = childObj.GetComponent<RectTransform>();
            childRT.anchorMin = new Vector2(0.5f, 0.5f);
            childRT.anchorMax = new Vector2(0.5f, 0.5f);
            childRT.pivot = new Vector2(0.5f, 0.5f);
            childRT.anchoredPosition = Vector2.zero;
            childRT.localRotation = Quaternion.identity;
            childRT.localScale = Vector3.one;
            var childImage = childObj.GetComponent<Image>();
            childImage.sprite = _icon.sprite;
            childImage.color = Color.white;
            childImage.type = _icon.type;
            childImage.preserveAspect = true;
            childImage.raycastTarget = true;
            childImage.enabled = true;
            _icon.enabled = false;
            _icon.raycastTarget = false;
            _icon = childImage;
            _iconRect = childRT;
        }
        else
        {
            _icon.raycastTarget = true;
        }
        _iconRect.anchorMin = new Vector2(0.5f, 0.5f);
        _iconRect.anchorMax = new Vector2(0.5f, 0.5f);
        _iconRect.pivot = new Vector2(0.5f, 0.5f);
        _iconRect.anchoredPosition = Vector2.zero;
        _iconRect.localScale = Vector3.one;
        _iconEnsuredAsChild = true;
    }

    private void EnsureRaycastTarget()
    {
        var allImages = GetComponents<Image>();
        foreach (var img in allImages)
        {
            if (img == null) continue;
            img.sprite = null;
            img.color = Color.clear;
            img.raycastTarget = false;
            img.enabled = false;
        }
        _raycastTarget = null;
    }

    private void EnsureSelectionOverlay()
    {
        Transform existing = _bodyRect.Find("SelectionOverlay");
        if (existing != null)
        {
            _selectionOverlay = existing.GetComponent<Image>();
            if (_selectionOverlay == null)
                _selectionOverlay = existing.gameObject.AddComponent<Image>();
            _selectionOverlay.color = Color.clear;
            _selectionOverlay.raycastTarget = false;
            _selectionOverlay.enabled = false;
            return;
        }
        var overlayObj = new GameObject("SelectionOverlay", typeof(RectTransform), typeof(Image));
        overlayObj.transform.SetParent(_bodyRect, false);
        var rt = overlayObj.GetComponent<RectTransform>();
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.pivot = new Vector2(0.5f, 0.5f);
        rt.anchoredPosition = Vector2.zero;
        rt.sizeDelta = Vector2.zero;
        rt.localScale = Vector3.one;
        _selectionOverlay = overlayObj.GetComponent<Image>();
        _selectionOverlay.sprite = null;
        _selectionOverlay.type = Image.Type.Simple;
        _selectionOverlay.color = Color.clear;
        _selectionOverlay.raycastTarget = false;
        _selectionOverlay.enabled = false;
    }

    public void Setup(InventoryItem item, K_InventoryUI inventoryUI, GridType gridType, int x, int y)
    {
        EnsureInitialized();
        _item = item;
        _inventoryUI = inventoryUI;
        _gridType = gridType;
        _gridX = x;
        _gridY = y;
        if (_canvasGroup != null)
        {
            _canvasGroup.interactable = true;
            _canvasGroup.blocksRaycasts = true;
            _canvasGroup.alpha = 1f;
        }
        ClearSelection();
        if (!gameObject.activeSelf)
            gameObject.SetActive(true);
        UpdateVisuals();
        if (gameObject.activeInHierarchy)
        {
            ForceTextRefresh();
        }
        if (_debugLogs && _nameText != null && _item.Data != null)
        {
            int chars = _nameText.textInfo.characterCount;
            float rw = _nameText.rectTransform.rect.width;
            if (chars == 0 && _item.Data.DisplayName.Length > 0)
            {
                Debug.LogWarning(
                    $"[TEXT-BUG] Setup FAILED for '{_item.Data.DisplayName}' at [{x},{y}] {gridType}: " +
                    $"charCount=0, rectW={rw:F1}, " +
                    $"bodyW={(_bodyRect != null ? _bodyRect.rect.width.ToString("F1") : "null")}, " +
                    $"activeInHierarchy={gameObject.activeInHierarchy}");
            }
        }
        LogDebug($"[UI_Item] Setup: {item.Data.DisplayName} at [{x},{y}] GridType={gridType}");
    }
#endregion

#region Visual Updates
    private void EnsureNameLabel()
    {
        if (_nameText != null && _caliberText != null)
            return;
        TMP_FontAsset fontAsset = TMP_Settings.defaultFontAsset;
        if (fontAsset == null)
        {
            fontAsset = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
            if (fontAsset == null)
                Debug.LogError("[UI_Item] TMP font asset not found!");
        }
        if (_nameText == null)
        {
            var labelObj = new GameObject("ItemName", typeof(RectTransform), typeof(TextMeshProUGUI));
            labelObj.transform.SetParent(_bodyRect, false);
            var rt = labelObj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(2f, -2f);
            rt.sizeDelta = new Vector2(-4f, _nameFontSize * 3f + 4f);
            rt.localScale = Vector3.one;
            _nameText = labelObj.GetComponent<TextMeshProUGUI>();
            _nameText.font = fontAsset;
            _nameText.fontSize = _nameFontSize;
            _nameText.color = new Color(1f, 1f, 1f, 0.85f);
            _nameText.alignment = TextAlignmentOptions.TopLeft;
            _nameText.raycastTarget = false;
            _nameText.overflowMode = TextOverflowModes.Truncate;
            _nameText.textWrappingMode = TextWrappingModes.Normal;
            _nameText.fontStyle = FontStyles.Bold;
            _nameText.outlineColor = new Color(0f, 0f, 0f, 0.7f);
            _nameText.outlineWidth = 0.15f;
        }
        if (_caliberText == null)
        {
            var calObj = new GameObject("ItemCaliber", typeof(RectTransform), typeof(TextMeshProUGUI));
            calObj.transform.SetParent(_bodyRect, false);
            var calRt = calObj.GetComponent<RectTransform>();
            calRt.anchorMin = new Vector2(0f, 0f);
            calRt.anchorMax = new Vector2(1f, 0f);
            calRt.pivot = new Vector2(0f, 0f);
            calRt.anchoredPosition = new Vector2(2f, 2f);
            calRt.sizeDelta = new Vector2(-4f, _caliberFontSize + 4f);
            calRt.localScale = Vector3.one;
            _caliberText = calObj.GetComponent<TextMeshProUGUI>();
            _caliberText.font = fontAsset;
            _caliberText.fontSize = _caliberFontSize;
            _caliberText.color = new Color(1f, 1f, 1f, 0.6f);
            _caliberText.alignment = TextAlignmentOptions.Left;
            _caliberText.verticalAlignment = VerticalAlignmentOptions.Bottom;
            _caliberText.raycastTarget = false;
            _caliberText.overflowMode = TextOverflowModes.Truncate;
            _caliberText.textWrappingMode = TextWrappingModes.NoWrap;
            _caliberText.outlineColor = new Color(0f, 0f, 0f, 0.7f);
            _caliberText.outlineWidth = 0.15f;
        }
    }

    public void UpdateVisuals()
    {
        if (_item == null || _item.Data == null) return;
        EnsureInitialized();
        if (!_iconEnsuredAsChild) EnsureIconIsChild();
        Sprite iconSprite = _item.CurrentIcon;
        if (_icon != null && iconSprite != null)
        {
            _icon.sprite = iconSprite;
            _icon.color = Color.white;
            _icon.enabled = true;
        }
        else if (_icon != null)
        {
            _icon.enabled = false;
        }
        if (_item.IsFolded && _item.Data.IconFolded == null)
        {
            if (_loggedMissingFoldIcon.Add(_item.InstanceID))
                Debug.LogWarning($"[UI_Item] Backpack '{_item.Data.DisplayName}' is folded but " +
                                 $"ItemStaticData.IconFolded is NOT set.");
        }
        float slotSize = _inventoryUI != null ? _inventoryUI.SlotSize : 70f;
        float slotSpacing = _inventoryUI != null ? _inventoryUI.SlotSpacing : 0f;
        Vector2Int currentSize = _item.CurrentSize;
        if (_bodyRect != null)
        {
            float widthPx = currentSize.x * slotSize + (currentSize.x - 1) * slotSpacing;
            float heightPx = currentSize.y * slotSize + (currentSize.y - 1) * slotSpacing;
            _bodyRect.sizeDelta = new Vector2(widthPx, heightPx);
            _bodyRect.localRotation = Quaternion.identity;
        }
        EnsureNameLabel();
        if (_nameText != null)
        {
            _nameText.text = _item.Data.DisplayName;
            if (gameObject.activeInHierarchy)
            {
                _nameText.SetAllDirty();
                _nameText.ForceMeshUpdate(false, true);
            }
        }
        if (_caliberText != null)
        {
            if (_item.Type == ItemType.Weapon && !string.IsNullOrEmpty(_item.Data.Caliber))
            {
                _caliberText.gameObject.SetActive(true);
                _caliberText.text = _item.Data.Caliber;
                if (gameObject.activeInHierarchy)
                {
                    _caliberText.SetAllDirty();
                    _caliberText.ForceMeshUpdate(false, true);
                }
            }
            else
            {
                _caliberText.text = string.Empty;
                _caliberText.gameObject.SetActive(false);
            }
        }
        if (_icon != null && _iconRect != null)
        {
            Vector2Int normalSize = GetNormalIconSize(_item);
            bool iconSwapsAxes = Mathf.Abs(_item.IconBaseRotation % 180) > 0.01f;
            int iconWcells = iconSwapsAxes ? normalSize.y : normalSize.x;
            int iconHcells = iconSwapsAxes ? normalSize.x : normalSize.y;
            float iconW = iconWcells * slotSize + (iconWcells - 1) * slotSpacing;
            float iconH = iconHcells * slotSize + (iconHcells - 1) * slotSpacing;
            _iconRect.sizeDelta = new Vector2(iconW, iconH);
            _icon.preserveAspect = true;
            float visualAngle = _item.IconBaseRotation - _item.RotationAngle;
            _iconRect.localRotation = Quaternion.Euler(0, 0, visualAngle);
        }
        if (_quantityText != null && _quantityGroup != null)
        {
            if (_item.Quantity > 1)
            {
                _quantityGroup.SetActive(true);
                _quantityText.text = _item.Quantity.ToString();
            }
            else
            {
                _quantityGroup.SetActive(false);
            }
        }
    }

    private static Vector2Int GetNormalIconSize(InventoryItem item)
    {
        if (item?.Data == null) return new Vector2Int(1, 1);
        var data = item.Data;
        if (item.IsFolded && data.CanFold)
            return data.SizeFolded;
        if (data.IsBackpack && data.UnfoldedIconSize.x > 0 && data.UnfoldedIconSize.y > 0)
            return data.UnfoldedIconSize;
        if (data.IsBackpack && data.BackpackWidth > 0 && data.BackpackHeight > 0)
            return new Vector2Int(data.BackpackWidth, data.BackpackHeight);
        return data.Size;
    }

    public void UpdateData(InventoryItem item)
    {
        _item = item;
        UpdateVisuals();
    }

    public void ForceTextRefresh()
    {
        if (_item == null || _item.Data == null) return;
        if (!gameObject.activeInHierarchy) return;
        if (_nameText == null) return;
        _nameText.text = _item.Data.DisplayName;
        _nameText.SetAllDirty();
        _nameText.ForceMeshUpdate(false, true);
        if (_caliberText != null)
        {
            bool showCaliber = _item.Type == ItemType.Weapon && !string.IsNullOrEmpty(_item.Data.Caliber);
            _caliberText.gameObject.SetActive(showCaliber);
            if (showCaliber)
            {
                _caliberText.text = _item.Data.Caliber;
                _caliberText.SetAllDirty();
                _caliberText.ForceMeshUpdate(false, true);
            }
            else
            {
                _caliberText.text = string.Empty;
            }
        }
    }
#endregion

#region Controller Binding
    public void BindController(InventoryController controller)
    {
        _boundController = controller;
    }

    public void UnbindController(InventoryController controller)
    {
        if (_boundController == controller)
            _boundController = null;
    }
#endregion

#region Selection (Click Highlight)
    public void SetSelected(bool selected)
    {
        if (_selectionOverlay == null) return;
        _selectionOverlay.enabled = selected;
        _selectionOverlay.color = selected ? _selectionColor : Color.clear;
    }

    public void SetSelected(bool selected, Color overlayColor)
    {
        if (_selectionOverlay == null) return;
        _selectionOverlay.enabled = selected;
        _selectionOverlay.color = selected ? overlayColor : Color.clear;
    }

    public void ClearSelection()
    {
        if (_selectionOverlay != null)
        {
            _selectionOverlay.color = Color.clear;
            _selectionOverlay.enabled = false;
        }
    }
#endregion

#region Pool Management
    public void ResetState()
    {
        _item = null;
        _inventoryUI = null;
        _gridType = GridType.Pockets;
        _gridX = 0;
        _gridY = 0;
        _isDragging = false;
        _isBeingDragged = false;
        _boundController = null;
        ClearSelection();
        if (_icon != null)
        {
            _icon.sprite = null;
            _icon.enabled = false;
            if (_iconRect != null)
                _iconRect.localRotation = Quaternion.identity;
        }
        if (_quantityGroup != null)
            _quantityGroup.SetActive(false);
        if (_nameText != null)
            _nameText.text = string.Empty;
        if (_caliberText != null)
        {
            _caliberText.text = string.Empty;
            _caliberText.gameObject.SetActive(false);
        }
        if (_canvasGroup != null)
        {
            _canvasGroup.interactable = false;
            _canvasGroup.blocksRaycasts = false;
            _canvasGroup.alpha = 1f;
        }
        if (_bodyRect != null)
            _bodyRect.localRotation = Quaternion.identity;
    }
#endregion

#region Drag & Drop (EventSystem Interfaces)
    public void OnBeginDrag(PointerEventData eventData)
    {
        if (_item == null || _inventoryUI == null) return;
        if (eventData.button != PointerEventData.InputButton.Left) return;
        if (_isDragging) return;
        if (_debugLogs && _nameText != null)
        {
            int charsBefore = _nameText.textInfo.characterCount;
            float rwBefore = _nameText.rectTransform.rect.width;
            if (charsBefore == 0 && _nameText.text.Length > 0)
            {
                Debug.LogWarning(
                    $"[TEXT-BUG] OnBeginDrag: text ALREADY empty before drag! " +
                    $"'{_item.Data?.DisplayName}', charCount=0, rectW={rwBefore:F1}");
            }
        }
        if (!_inventoryUI.TryStartDrag(this, eventData))
        {
            LogDebug($"[UI_Item] BeginDrag rejected: {_item.Data.DisplayName}");
            return;
        }
        _isDragging = true;
        ApplyDragGhostState();
        LogDebug($"[UI_Item] BeginDrag: {_item.Data.DisplayName}");
    }

    private void ApplyDragGhostState()
    {
        if (_canvasGroup == null) return;
        _canvasGroup.alpha = 0.35f;
        _canvasGroup.blocksRaycasts = false;
        _canvasGroup.interactable = false;
    }

    public void MarkDragFinished()
    {
        _isDragging = false;
    }

    public void OnDrag(PointerEventData eventData)
    {
        _inventoryUI?.UpdateDragGhostPosition(eventData);
    }

   public void OnEndDrag(PointerEventData eventData)
{
    _isDragging = false;
    if (_canvasGroup != null && gameObject.activeInHierarchy)
    {
        if (_inventoryUI == null || !_inventoryUI.IsDragging)
        {
            _canvasGroup.alpha = 1f;
            _canvasGroup.blocksRaycasts = true;
            _canvasGroup.interactable = true;
        }
    }
    _inventoryUI?.EndDragComplete(true);
    LogDebug($"[UI_Item] EndDrag: {_item?.Data.DisplayName ?? "NULL"}");
}

    protected virtual void OnDisable()
    {
        if (!_isDragging) return;
        if (_inventoryUI != null && _inventoryUI.IsReturningAllItemsToPool)
            return;
        _isDragging = false;
        if (_canvasGroup != null)
        {
            _canvasGroup.alpha = 1f;
            _canvasGroup.blocksRaycasts = true;
            _canvasGroup.interactable = true;
        }
        _inventoryUI?.EndDragComplete();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (_isDragging || _item == null) return;
        _inventoryUI?.OnItemHovered(this);
        LogDebug($"[UI_Item] Hover Enter: {_item?.Data.DisplayName}");
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (_isDragging) return;
        _inventoryUI?.OnItemUnhovered(this);
        LogDebug($"[UI_Item] Hover Exit: {_item?.Data.DisplayName}");
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (_isDragging || _item == null) return;
        if (eventData.button == PointerEventData.InputButton.Right)
        {
            if (K_ContextMenu.Instance != null)
            {
                K_ContextMenu.Instance.Show(_item, eventData.position, _inventoryUI);
            }
            return;
        }
    }
#endregion

#region Drop Handling
public void OnDrop(PointerEventData eventData)
{
    if (_inventoryUI == null || !_inventoryUI.IsDragging) return;
    if (eventData.pointerDrag == null) return;

    var draggedUI = _inventoryUI.DraggedUIItem;
    if (draggedUI == null) return;

    if (_item != null && _item.Data != null && _item.Data.IsBackpack
        && (!_item.IsFolded || _item.Data.AlwaysShowGrid))
    {
        // ⬇️ НОВЫЕ ПРОВЕРКИ ЛИМИТА ВЛОЖЕННОСТИ
        if (_inventoryUI != null && _inventoryUI.IsAtMaxNestingDepth(_item))
        {
            _inventoryUI.EndDragComplete(true);
            return;
        }
        if (draggedUI.Item != null && draggedUI.Item.Data.IsBackpack && _inventoryUI != null)
        {
            if (_inventoryUI.WouldExceedMaxNestingDepth(draggedUI.Item, _item))
            {
                _inventoryUI.EndDragComplete(true);
                return;
            }
        }

        bool selfDrop = draggedUI.Item == _item;
        bool cycle = !selfDrop && draggedUI.Item != null && draggedUI.Item.Data != null 
            && draggedUI.Item.Data.IsBackpack 
            && draggedUI.Item.ContainsDescendant(_item.InstanceID);

        if (selfDrop || cycle)
        {
            _inventoryUI.EndDragComplete(true);
            return;
        }

        bool dropSuccess = InventoryTransactionService.Instance.TryDropIntoBackpack(
            draggedUI, _item, out string dropErrorMessage);
            
        if (dropSuccess)
        {
            _inventoryUI.EndDragComplete();
            _inventoryUI.ForceRefresh();
        }
        else
        {
            Debug.LogWarning($"[UI_Item.OnDrop] Drop into backpack failed: {dropErrorMessage}");
            _inventoryUI.EndDragComplete(true);
        }
        return;
    }

    var eventSystem = EventSystem.current;
    if (eventSystem == null) return;

    var results = new List<RaycastResult>();
    eventSystem.RaycastAll(eventData, results);
    foreach (var result in results)
    {
        var slot = result.gameObject.GetComponent<K_InventorySlotUI>();
        if (slot != null)
        {
            slot.OnDrop(eventData);
            return;
        }
    }
}
#endregion

    #region Debug Helpers
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    private void LogDebug(string message)
    {
        if (_debugLogs)
            Debug.Log(message);
    }
  
public void DiagnoseTextState(string caller)
{
    if (_item == null || _item.Data == null) return;
    if (_nameText == null) return;

    int chars = _nameText.textInfo.characterCount;
    string text = _nameText.text;
    bool active = gameObject.activeInHierarchy;
    bool textActive = _nameText.gameObject.activeSelf;
    float rectW = _nameText.rectTransform.rect.width;
    float rectH = _nameText.rectTransform.rect.height;
    float bodyW = _bodyRect != null ? _bodyRect.rect.width : -1f;
    float bodyH = _bodyRect != null ? _bodyRect.rect.height : -1f;
    float alpha = _canvasGroup != null ? _canvasGroup.alpha : -1f;
    Vector2 anchorMin = _nameText.rectTransform.anchorMin;
    Vector2 anchorMax = _nameText.rectTransform.anchorMax;
    Vector2 sizeDelta = _nameText.rectTransform.sizeDelta;

    if (chars == 0 && text.Length > 0)
    {
        Debug.LogError(
            $"[TEXT-DIAG] {caller}: TEXT INVISIBLE!\n" +
            $"  Item: '{_item.Data.DisplayName}' (ID={_item.InstanceID})\n" +
            $"  text='{text}', charCount={chars}\n" +
            $"  nameRect: w={rectW:F2}, h={rectH:F2}\n" +
            $"  nameRect anchors: min=({anchorMin.x},{anchorMin.y}), max=({anchorMax.x},{anchorMax.y})\n" +
            $"  nameRect sizeDelta: ({sizeDelta.x:F2},{sizeDelta.y:F2})\n" +
            $"  bodyRect: w={bodyW:F2}, h={bodyH:F2}\n" +
            $"  gameObject.activeInHierarchy={active}\n" +
            $"  nameText.gameObject.activeSelf={textActive}\n" +
            $"  canvasGroup.alpha={alpha:F2}\n" +
            $"  parent={(_bodyRect != null && _bodyRect.parent != null ? _bodyRect.parent.name : "null")}\n" +
            $"  parentActive={(_bodyRect != null && _bodyRect.parent != null ? _bodyRect.parent.gameObject.activeInHierarchy.ToString() : "null")}");
    }
      #endregion
}
} 
}
