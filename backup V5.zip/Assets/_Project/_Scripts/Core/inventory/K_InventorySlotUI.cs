﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// UI-слот инвентаря. Отображает ячейку сетки, подсветку при drag и tint занятости.
    /// Реализует IDropHandler для приёма перетаскиваемых предметов.
    /// ПОРЯДОК DROP: 1) swap по визуальному пересечению Ghost∩предмет (курсор не важен);
    /// 2) прямая постановка, если пересечения нет и ячейки свободны; 3) отмена.
    /// </summary>
    public class K_InventorySlotUI : MonoBehaviour, IDropHandler
    {
        #region Fields
        private K_InventoryUI _inventoryUI;
        private Image _backgroundImage;
        private Color _originalColor;
        private Image _cellOverlay;
        private InventoryController _boundController;
        public void BindController(InventoryController c) { _boundController = c; }
        private int _lastDropFrame = -1;
        #endregion

        #region Properties
        public int X { get; private set; }
        public int Y { get; private set; }
        public GridType GridType { get; private set; }
        public Image BackgroundImage => _backgroundImage;
        public Color CellOverlayColor => _cellOverlay != null ? _cellOverlay.color : Color.clear;
        public InventoryController BoundController => _boundController;
        #endregion

        #region Initialization
        public void Setup(int x, int y, GridType gridType, K_InventoryUI inventoryUI)
        {
            X = x;
            Y = y;
            GridType = gridType;
            _inventoryUI = inventoryUI;
            if (_backgroundImage == null)
                _backgroundImage = GetComponent<Image>();
            if (_backgroundImage != null)
            {
                _originalColor = _backgroundImage.color;
                _backgroundImage.raycastTarget = false;
            }
            EnsureCellOverlay();
        }

        public void SetRaycastEnabled(bool enabled)
        {
            if (_backgroundImage != null)
                _backgroundImage.raycastTarget = enabled;
        }

        private void EnsureCellOverlay()
        {
            Transform existing = transform.Find("CellOverlay");
            if (existing != null)
            {
                _cellOverlay = existing.GetComponent<Image>();
                if (_cellOverlay == null)
                    _cellOverlay = existing.gameObject.AddComponent<Image>();
                _cellOverlay.color = Color.clear;
                _cellOverlay.raycastTarget = false;
                return;
            }
            var overlayObj = new GameObject("CellOverlay", typeof(RectTransform), typeof(Image));
            overlayObj.transform.SetParent(transform, false);
            var rt = overlayObj.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = Vector2.zero;
            rt.localScale = Vector3.one;
            _cellOverlay = overlayObj.GetComponent<Image>();
            _cellOverlay.sprite = null;
            _cellOverlay.type = Image.Type.Simple;
            _cellOverlay.color = Color.clear;
            _cellOverlay.raycastTarget = false;
        }
        #endregion

        #region Cell Color API
        public void SetCellColor(Color color)
        {
            if (_cellOverlay != null)
                _cellOverlay.color = color;
        }

        public void ResetCellColor()
        {
            if (_cellOverlay != null)
                _cellOverlay.color = Color.clear;
        }

        public void TintOccupied(Color tint)
        {
            if (_cellOverlay == null) return;
            if (tint.a <= 0f)
            {
                _cellOverlay.color = Color.clear;
                return;
            }
            _cellOverlay.color = tint;
        }
        #endregion

        #region Event Handlers (Unity UI)
 public void OnDrop(PointerEventData eventData)
{
    if (_inventoryUI == null || !_inventoryUI.IsDragging) return;
    if (Time.frameCount == _lastDropFrame) return;
    _lastDropFrame = Time.frameCount;

    var draggedUI = _inventoryUI.DraggedUIItem;
    bool isFromEquipment = _inventoryUI.IsDraggingFromEquipmentSlot;
    InventoryItem draggedItem;
    if (draggedUI != null) draggedItem = draggedUI.Item;
    else if (isFromEquipment) draggedItem = _inventoryUI.DraggedFromSlotItem;
    else return;

    if (draggedItem == null) return;

    // БАГ 3 ФИКС: Всегда получаем живой контроллер
    var targetController = _boundController ?? _inventoryUI.GetControllerForGrid(GridType);
    if (targetController == null || targetController.IsDisposed)
    {
        var restored = _inventoryUI.LootSession?.GetLootControllerFromSlots();
        if (restored != null && !restored.IsDisposed)
        {
            targetController = restored;
            _inventoryUI.SetActiveContainerController(restored);
        }
        else
        {
            Debug.LogWarning($"[OnDrop] Target controller is null or disposed for GridType={GridType}");
            _inventoryUI.EndDragComplete(true);
            return;
        }
    }

    var (tx, ty) = _inventoryUI.GetAdjustedDropPosition(
        X, Y, draggedItem.CurrentSize, GridType, targetController);

    if (isFromEquipment && draggedUI == null)
    {
        bool placed = _inventoryUI.TryPlaceItemFromEquipmentSlot(GridType, tx, ty);
        if (placed) _inventoryUI.FinalizeEquipSlotDrag();
        else _inventoryUI.EndDragComplete(true);
        return;
    }

    UI_Item swapTargetUI = null;
    UI_Item backpackTargetUI = null;
    if (DragHighlightController.Instance != null)
        DragHighlightController.Instance.ResolveSnapTargets(
            draggedItem, targetController, tx, ty, out swapTargetUI, out backpackTargetUI);

    if (backpackTargetUI != null && backpackTargetUI.Item != null)
    {
        if (_inventoryUI != null && _inventoryUI.IsAtMaxNestingDepth(backpackTargetUI.Item))
        {
            _inventoryUI.EndDragComplete(true);
            return;
        }
        if (draggedItem.Data != null && draggedItem.Data.IsBackpack && _inventoryUI != null && _inventoryUI.WouldExceedMaxNestingDepth(draggedItem, backpackTargetUI.Item))
        {
            _inventoryUI.EndDragComplete(true);
            return;
        }
        
        bool successDrop = InventoryTransactionService.Instance.TryDropIntoBackpack(
            draggedUI, backpackTargetUI.Item, out string dropError);
            
        if (successDrop) _inventoryUI.EndDragComplete();
        else
        {
            Debug.LogWarning($"[OnDrop] Drop into backpack failed: {dropError}");
            _inventoryUI.EndDragComplete(true);
        }
        return;
    }

    if (swapTargetUI != null && swapTargetUI.Item != null)
    {
        bool successSwap = InventoryTransactionService.Instance.TrySwapItems(
            draggedUI, swapTargetUI, tx, ty, out string errorMessage);
            
        if (successSwap) _inventoryUI.EndDragComplete();
        else
        {
            Debug.LogWarning($"[OnDrop] Swap failed: {errorMessage}");
            _inventoryUI.EndDragComplete(true);
        }
        return;
    }

    if (targetController.CanPlaceItem(draggedItem, tx, ty))
    {
        bool moveSuccess = InventoryTransactionService.Instance.TryMoveItem(
            draggedUI, targetController, tx, ty, out string moveError);
            
        if (moveSuccess) _inventoryUI.EndDragComplete();
        else
        {
            Debug.LogWarning($"[OnDrop] Move failed: {moveError}");
            _inventoryUI.EndDragComplete(true);
        }
    }
    else
    {
        _inventoryUI.EndDragComplete(true);
    }
}
        #endregion
    }
    }
