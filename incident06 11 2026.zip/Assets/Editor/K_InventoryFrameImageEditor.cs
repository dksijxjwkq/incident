#if UNITY_EDITOR
using K_Incident.Core.Inventory;
using UnityEditor;
using UnityEditor.UI;
using UnityEngine;

[CustomEditor(typeof(K_InventoryFrameImage)), CanEditMultipleObjects]
public sealed class K_InventoryFrameImageEditor : ImageEditor
{
    public override void OnInspectorGUI()
    {
        base.OnInspectorGUI();
        serializedObject.Update();
        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Рамка и заливка слота", EditorStyles.boldLabel);
        EditorGUILayout.PropertyField(serializedObject.FindProperty("_drawFrame"));
        EditorGUILayout.PropertyField(serializedObject.FindProperty("_useInventoryLineColor"));
        EditorGUILayout.PropertyField(serializedObject.FindProperty("_borderColor"));
        EditorGUILayout.PropertyField(serializedObject.FindProperty("_borderThickness"));
        EditorGUILayout.PropertyField(serializedObject.FindProperty("_minimumPixelThickness"));
        EditorGUILayout.PropertyField(serializedObject.FindProperty("_fillColor"));
        EditorGUILayout.HelpBox("При Use Inventory Line Color цвет рамки берётся из соединительных линий. Color компонента Image управляет заливкой.", MessageType.Info);
        serializedObject.ApplyModifiedProperties();
    }
}
#endif
