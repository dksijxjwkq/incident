using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Извлечено из K_InventoryUI (Задача 5E — Save Sync).
    ///
    /// Отвечает за синхронизацию ЖИВЫХ контроллеров открытых рюкзаков
    /// в их InventoryItem._backpackContentsSerialized ПЕРЕД бинарной
    /// сериализацией PlayerEquipmentSaveService.Save().
    ///
    /// КРИТИЧЕСКИ ВАЖНО: обход BOTTOM-UP (сначала дети, потом родители).
    /// Если синхронизировать родителя раньше ребёнка, ToSaveData() родителя
    /// прочитает УСТАРЕВШИЙ _backpackContentsSerialized ребёнка, и вложенные
    /// рюкзаки будут потеряны.
    ///
    /// Пример матрёшки: А (надет) → Б (открыт) → С (открыт) → Д (закрыт).
    /// Правильный порядок синхронизации: С, Б, А.
    ///
    /// НЕ отвечает за: сами рюкзаки (BackpackContainerManager), лут-режим
    /// (LootSessionController), drag/drop, рендеринг.
    ///
    /// ВНИМАНИЕ: класс СИНХРОННЫЙ. Запрещено использовать async/await,
    /// Task, Coroutine, yield return. BinaryWriter/BinaryReader тоже
    /// синхронные — это допустимо.
    ///
    /// Создаётся в K_InventoryUI.Awake() и инициализируется ссылками на
    /// K_InventoryUI (для доступа к контроллерам игрока и FindItemByInstanceId)
    /// и BackpackContainerManager (для GetLiveController / OpenedBackpacks).
    /// </summary>
    public sealed class InventorySaveSync
    {
        // ═══════════════════════════════════════════════════════════
        //  ЗАВИСИМОСТИ
        // ═══════════════════════════════════════════════════════════
        private K_InventoryUI _ui;
        private BackpackContainerManager _backpackManager;

        // Защита от зацикливания при обходе вложенных рюкзаков.
        private const int MAX_RECURSION_DEPTH = 32;

        public void Initialize(K_InventoryUI ui, BackpackContainerManager backpackManager)
        {
            _ui = ui;
            _backpackManager = backpackManager;
        }

        // ═══════════════════════════════════════════════════════════
        //  ПУБЛИЧНЫЙ API
        // ═══════════════════════════════════════════════════════════

        /// <summary>Refreshes only persisted backpack DTOs while retaining every controller/data dirty flag.</summary>
        public void SyncAllBackpacksForRollbackSnapshot()
        {
            if (_ui == null || _backpackManager == null) return;
            var controllers = new HashSet<InventoryController>();
            AddSnapshotController(controllers,
                _ui.GetEquippedBackpackProjection(_ui.BackpackEquipmentSlot?.EquippedItem));
            AddSnapshotController(controllers, _ui.PocketsController);
            AddSnapshotController(controllers, _ui.Pocket2Controller);
            if (_ui.IsLooting) AddSnapshotController(controllers, _ui.ActiveContainerController);
            foreach (var pair in _backpackManager.OpenedBackpacks)
                AddSnapshotController(controllers, pair.Value);

            var dirtyStates = new List<(InventoryController controller, bool controllerDirty,
                InventoryData data, bool dataDirty)>(controllers.Count);
            foreach (var controller in controllers)
            {
                var data = controller.GetSaveData();
                dirtyStates.Add((controller, controller.IsDirty, data, data != null && data.IsDirty));
            }
            try
            {
                SyncAllBackpacksForSave();
            }
            finally
            {
                foreach (var state in dirtyStates)
                {
                    state.controller.IsDirty = state.controllerDirty;
                    if (state.data != null) state.data.IsDirty = state.dataDirty;
                }
            }
        }

        private static void AddSnapshotController(HashSet<InventoryController> controllers,
            InventoryController controller)
        {
            if (controller != null && !controller.IsDisposed) controllers.Add(controller);
        }

        /// <summary>
        /// Главный вход перед Save. Замещает бывший
        /// K_InventoryUI.SyncAllBackpacksRecursiveForSave().
        ///
        /// Шаг 1: bottom-up обход всех деревьев от корневых контроллеров
        ///        игрока (Backpack, Pockets, Pocket2) + активного лут-контроллера.
        /// Шаг 2: сериализация надетого рюкзака в _backpackSlot.EquippedItem.
        ///
        /// Вызывается из PlayerEquipmentSaveService.Save() через тонкую
        /// обёртку K_InventoryUI.SyncAllBackpacksForSave().
        /// </summary>
     public void SyncAllBackpacksForSave()
{
    if (_ui == null || _backpackManager == null) return;
    var equippedProjection = _ui.GetEquippedBackpackProjection(_ui.BackpackEquipmentSlot?.EquippedItem);
    
    // Шаг 1: bottom-up обход всех деревьев от корневых контроллеров.
    SyncBackpacksBottomUp(equippedProjection, 0);
    SyncBackpacksBottomUp(_ui.PocketsController, 0);
    SyncBackpacksBottomUp(_ui.Pocket2Controller, 0);
    
    if (_ui.IsLooting && _ui.ActiveContainerController != null)
        SyncBackpacksBottomUp(_ui.ActiveContainerController, 0);
        
    // ФИКС КОРНЯ 2: Обновляем InventoryData всех корневых контроллеров.
    // Без этого struct SavedItem в _data контроллеров карманов останется старым,
    // и изменения внутри вложенных рюкзаков не попадут в сейв.
    equippedProjection?.RefreshAllItemsInData();
    _ui.PocketsController?.RefreshAllItemsInData();
    _ui.Pocket2Controller?.RefreshAllItemsInData();
    if (_ui.IsLooting && _ui.ActiveContainerController != null)
        _ui.ActiveContainerController.RefreshAllItemsInData();
        
    // Шаг 2: сериализуем надетый рюкзак.
    SyncEquippedBackpackIntoItem();
}        public void SyncAllOpenBackpacksForSave()
        {
            if (_ui == null || _backpackManager == null) return;

            foreach (var kvp in _backpackManager.OpenedBackpacks)
            {
                if (kvp.Value == null || kvp.Value.IsDisposed) continue;
                var bpItem = _ui.FindItemByInstanceId(uint.Parse(kvp.Key));
                if (bpItem != null)
                {
                    var live = kvp.Value.GetSaveData()?.GetItems();
                    if (live != null) bpItem.ReplaceBackpackContents(live);
                }
            }
        }

        // ═══════════════════════════════════════════════════════════
        //  ВНУТРЕННЯЯ ЛОГИКА
        // ═══════════════════════════════════════════════════════════

        /// <summary>
        /// Рекурсивный обход дерева открытых рюкзаков BOTTOM-UP.
        /// Для каждого открытого рюкзака: сначала синхронизируем всех потомков,
        /// потом сам рюкзак. Закрытые рюкзаки не трогаем — их данные уже актуальны
        /// (обновляются при закрытии окна).
        /// </summary>
     private void SyncBackpacksBottomUp(InventoryController controller, int depth)
        {
            if (controller == null || controller.IsDisposed || depth > MAX_RECURSION_DEPTH) return;

            for (int y = 0; y < controller.Height; y++)
            {
                for (int x = 0; x < controller.Width; x++)
                {
                    var item = controller.GetItemAt(x, y);
                    if (item == null || item.Data == null || !item.Data.IsBackpack) continue;
                    if (!controller.IsRootCell(item.InstanceID, x, y)) continue;

                    string idStr = item.InstanceID.ToString();
                    var liveCtrl = _backpackManager.GetLiveController(idStr);
                    if (liveCtrl != null && !liveCtrl.IsDisposed)
                    {
                        SyncBackpacksBottomUp(liveCtrl, depth + 1);
                        
                        // ФИКС: Сначала безопасно обновляем _data контроллера из предметов
                        liveCtrl.RefreshAllItemsInData();
                        
                        var savedItems = liveCtrl.GetSaveData()?.GetItems();
                        if (savedItems != null)
                            item.ReplaceBackpackContents(savedItems);
                    }
                }
            }
        }

         private void SyncEquippedBackpackIntoItem()
        {
            var backpackSlot = _ui.BackpackEquipmentSlot;
            var backpackCtrl = _ui.GetEquippedBackpackProjection(backpackSlot?.EquippedItem);
            if (backpackSlot != null && backpackSlot.EquippedItem != null && backpackCtrl != null)
            {
                // ФИКС: Безопасно обновляем перед сериализацией
                backpackCtrl.RefreshAllItemsInData();
                
                var savedItems = backpackCtrl.GetSaveData()?.GetItems();
                if (savedItems != null)
                    backpackSlot.EquippedItem.ReplaceBackpackContents(savedItems);
            }
        }
    }
}
