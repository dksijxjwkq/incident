
// === Source: original file lines 19307-20183 ===
using K_Incident.Core.Inventory;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public class InventoryController : IDisposable, ISaveable
        , ISavePayloadValidator
    {
        #region Events & Constants
        public event Action OnInventoryChanged;
        public event Action<float> OnWeightChanged;
        public event Action<InventoryItem, int, int> OnItemPlaced;
        public event Action<InventoryItem> OnItemRemoved;
        public event Action<InventoryItem> OnItemRotated;
        public event Action<InventoryItem> OnItemQuantityChanged;

        public event Action<List<InventoryItem>> OnResizeOverflow;

        private const int MAX_STACK_LIMIT = 90;
        private const int DEFAULT_MAX_CAPACITY_GRAMS = 30000;
        private const float GRAM_TO_KG = 0.001f;
        private const int MIN_GRID_INDEX = 0;
        #endregion

        #region Fields
        public string SaveID { get; private set; }
        public bool IsDirty { get; set; } = true;

        private InventoryData _data;
        private ItemDatabase _database;
        private InventoryItem[,] _grid;
        private readonly Dictionary<uint, InventoryItem> _itemCache = new();
        private readonly Dictionary<uint, (int x, int y)> _positionCache = new();
        private int _currentWeightGrams;
        private int _maxCapacityGrams = DEFAULT_MAX_CAPACITY_GRAMS;
        private bool _isDisposed;
        private readonly Func<InventoryItem, bool> _placementFilter;
        private Action<InventoryItem> _atomicBeforeMutation;
        #endregion

        #region Properties
        public bool IsDisposed => _isDisposed;
        public int Width => _data?.Width ?? 0;
        public int Height => _data?.Height ?? 0;
        public float CurrentWeightKg => _currentWeightGrams * GRAM_TO_KG;
        public float WeightRatio => _maxCapacityGrams > 0 ? _currentWeightGrams / (float)_maxCapacityGrams : 0f;
        public int MaxCapacityGrams => _maxCapacityGrams;
        #endregion

        #region Constructor
        public InventoryController(InventoryData data, ItemDatabase database, string saveID = null,
            Func<InventoryItem, bool> placementFilter = null)
        {
            _data = data ?? throw new ArgumentNullException(nameof(data));
            _database = database ?? throw new ArgumentNullException(nameof(database));
            SaveID = saveID ?? $"Inv_{Guid.NewGuid():N}";
            _placementFilter = placementFilter;

            InitializeGrid();
            LoadFromData();
            InventoryOwnershipRegistry.Register(this);
        }

        private void InitializeGrid()
        {
            if (_data.Width <= 0 || _data.Height <= 0)
                throw new ArgumentException($"Invalid grid dimensions: {_data.Width}x{_data.Height}", nameof(_data));

            _grid = new InventoryItem[_data.Width, _data.Height];
            _currentWeightGrams = 0;
        }

        private void LoadFromData()
        {
            ValidateInitialDataGeometry();
            int skippedCount = 0;

            foreach (var saved in _data.GetItems())
            {
                var template = _database.GetItemData(saved.ItemID);
                if (template == null)
                {
                    LogWarning($"Template not found for ItemID: {saved.ItemID} (InstanceID: {saved.InstanceID})");
                    skippedCount++; continue;
                }

                var item = InventoryItem.FromSaveData(saved, template);
                if (item == null)
                {
                    LogWarning($"Failed to create item from SavedData: {saved.ItemID}");
                    skippedCount++; continue;
                }

                if (!CanPlaceInternal(item, saved.X, saved.Y, item.CurrentSize))
                {
                    LogWarning($"Cannot place item {saved.InstanceID} at ({saved.X},{saved.Y}) - bounds/collision conflict");
                    skippedCount++; continue;
                }

                if (!BindToGrid(item, saved.X, saved.Y))
                {
                    LogWarning($"BindToGrid failed for item {saved.InstanceID} at ({saved.X},{saved.Y})");
                    skippedCount++; continue;
                }
            }

            if (skippedCount > 0) Debug.LogWarning($"[InventoryController] Load complete: {skippedCount} items skipped");

            RecalculateWeight();
            _data.MarkClean();
            IsDirty = false;
        }
        #endregion

        #region Placement Logic
        public bool AcceptsItemForPlacement(InventoryItem item) => !_isDisposed &&
            InventoryItem.IsValidLiveQuantity(item) && InventoryGridBounds.IsValidBackpack(item.Data) &&
            (_placementFilter == null || _placementFilter(item));

        public bool CanPlaceItem(InventoryItem item, int x, int y) =>
            item != null && item.Data != null && CanPlaceInternal(item, x, y, item.CurrentSize);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool IsValidCoordinate(int x, int y)
        {
            Debug.Assert(_data != null, "IsValidCoordinate called with null _data");
            return _data != null && x >= MIN_GRID_INDEX && y >= MIN_GRID_INDEX &&
                   x < _data.Width && y < _data.Height;
        }

        private bool CanPlaceInternal(InventoryItem item, int x, int y, Vector2Int size)
        {
            if (_placementFilter != null && !_placementFilter(item)) return false;
            if (!IsValidCoordinate(x, y) || !IsValidCoordinate(x + size.x - 1, y + size.y - 1))
                return false;

            InventoryItem stackTarget = null;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    var existing = _grid[x + dx, y + dy];
                    if (existing == null || existing == item) continue;

                    if (!CanStack(existing, item)) return false;

                    if (stackTarget == null) stackTarget = existing;
                    else if (stackTarget.InstanceID != existing.InstanceID) return false;
                }
            }

            return true;
        }

        private bool CanOccupy(int x, int y, Vector2Int size, InventoryItem ignoredItem = null)
        {
            if (_isDisposed || _grid == null || _data == null)
                return false;
            if (size.x <= 0 || size.y <= 0)
                return false;

            if (x < 0 || y < 0 ||
                x > _data.Width - size.x ||
                y > _data.Height - size.y)
                return false;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    InventoryItem occupied = _grid[x + dx, y + dy];
                    if (occupied != null && !ReferenceEquals(occupied, ignoredItem))
                        return false;
                }
            }
            return true;
        }

        private void ClearCellsOwnedBy(InventoryItem item)
        {
            if (_grid == null) return;
            for (int y = 0; y < _data.Height; y++)
                for (int x = 0; x < _data.Width; x++)
                    if (ReferenceEquals(_grid[x, y], item))
                        _grid[x, y] = null;
        }

        private void FillCells(InventoryItem item, int x, int y, Vector2Int size)
        {
            if (_grid == null) return;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    _grid[x + dx, y + dy] = item;
        }

        private bool CanPlaceInternalEmptyOnly(int x, int y, Vector2Int size)
        {
            if (!IsValidCoordinate(x, y) || !IsValidCoordinate(x + size.x - 1, y + size.y - 1))
                return false;

            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    if (_grid[x + dx, y + dy] != null) return false;

            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool CanStack(InventoryItem target, InventoryItem source)
        {
            if (target?.Data == null || source?.Data == null || ReferenceEquals(target, source)) return false;
            if (target.InstanceID == source.InstanceID || target.Data.IsBackpack || source.Data.IsBackpack) return false;
            // Stage 4: timed devices retain a unique identity and individual charge.
            if (target.Data.HasIndividualCharge || source.Data.HasIndividualCharge) return false;
            if (target.ChargePercent != source.ChargePercent) return false;
            if (target.RemainingChargeSeconds != source.RemainingChargeSeconds) return false;
            if (target.PrefabID != source.PrefabID) return false;
            if (target.Quantity >= target.Data.HardStackLimit) return false;
            if (target.Durability != source.Durability) return false;
            if (target.RotationAngle != source.RotationAngle) return false;
            if (target.IsFolded != source.IsFolded) return false;
            return true;
        }

        public bool CanMergeStack(InventoryItem source, InventoryItem target) =>
            !_isDisposed && source != null && source.Quantity > 0 && target != null &&
            (_placementFilter == null || _placementFilter(source)) &&
            _itemCache.TryGetValue(target.InstanceID, out var live) && ReferenceEquals(live, target) &&
            CanStack(target, source) && target.CurrentSize == source.CurrentSize;

        /// <summary>Moves quantity, retaining the source remainder and the target identity.
        /// A null sourceController means the source is detached (for example, a world item).</summary>
        public int MergeStackFrom(InventoryItem source, InventoryItem target, InventoryController sourceController = null)
        {
            if (!CanMergeStack(source, target)) return 0;
            if (sourceController != null)
            {
                if (sourceController.IsDisposed ||
                    !sourceController._itemCache.TryGetValue(source.InstanceID, out var live) ||
                    !ReferenceEquals(live, source)) return 0;
            }
            else if (_itemCache.ContainsKey(source.InstanceID)) return 0;

            int moved = Mathf.Min(source.Quantity, target.SpaceInStack);
            if (moved <= 0) return 0;
            source.RemoveQuantity(moved);
            target.AddQuantity(moved);

            bool removed = source.Quantity == 0;
            if (sourceController != null)
            {
                if (removed)
                {
                    sourceController.ClearCellsOwnedBy(source);
                    sourceController._itemCache.Remove(source.InstanceID);
                    sourceController._positionCache.Remove(source.InstanceID);
                    sourceController._data.RemoveItem(source.InstanceID);
                }
                else sourceController.RefreshItemInData(source);
                sourceController.MarkDirty();
            }
            RefreshItemInData(target);

            if (!ReferenceEquals(sourceController, this))
            {
                int grams = moved * source.Data.WeightGrams;
                sourceController?.AdjustWeight(-grams);
                AdjustWeight(grams);
            }
            if (sourceController != null)
            {
                if (removed) sourceController.SafeInvoke(sourceController.OnItemRemoved, source);
                else sourceController.SafeInvoke(sourceController.OnItemQuantityChanged, source);
                if (!ReferenceEquals(sourceController, this))
                    sourceController.SafeInvoke(sourceController.OnInventoryChanged);
            }
            SafeInvoke(OnItemQuantityChanged, target);
            SafeInvoke(OnInventoryChanged);
            return moved;
        }

        public int MergeIntoExistingStacks(InventoryItem source)
        {
            if (_isDisposed || source == null || _itemCache.ContainsKey(source.InstanceID)) return 0;
            int before = source.Quantity;
            for (int y = 0; y < Height && source.Quantity > 0; y++)
                for (int x = 0; x < Width && source.Quantity > 0; x++)
                {
                    var target = GetItemAt(x, y);
                    if (target != null && IsRootCell(target.InstanceID, x, y))
                        MergeStackFrom(source, target);
                }
            return before - source.Quantity;
        }

        /// <summary>Возвращает фактически размещённое количество; остаток остаётся ответственностью вызывающего кода.</summary>
        public int TryPlaceItem(InventoryItem source, int x, int y) =>
            TryPlaceItemQuantity(source, x, y, source?.Quantity ?? 0);

        private int TryPlaceItemQuantity(InventoryItem source, int x, int y, int quantity)
        {
            if (!InventoryGridBounds.IsValidBackpack(source?.Data)) return 0;
            if (_isDisposed || source == null || source.Data == null || quantity <= 0) return 0;
            if (!CanPlaceInternal(source, x, y, source.CurrentSize)) return 0;

            int remainder = quantity;
            int placedCount = 0;

            var targetStack = FindStackTarget(source, x, y);
            if (targetStack != null)
            {
                int space = targetStack.Data.HardStackLimit - targetStack.Quantity;
                if (space <= 0) return 0;

                int toAdd = Mathf.Min(space, remainder);
                int oldQty = targetStack.Quantity;
                targetStack.AddQuantity(toAdd);
                int actuallyAdded = targetStack.Quantity - oldQty;

                if (actuallyAdded <= 0) return 0;

                AdjustWeight(source.Data.WeightGrams * actuallyAdded);
                remainder -= actuallyAdded;
                placedCount += actuallyAdded;

                if (_positionCache.TryGetValue(targetStack.InstanceID, out var pos))
                    _data.UpdateItem(targetStack.InstanceID, pos.x, pos.y, targetStack.Quantity, targetStack.IsRotated);

                SafeInvoke(OnItemQuantityChanged, targetStack);

                // Остаток нельзя привязать поверх targetStack. Возвращаем
                // точное число объединённых единиц; first-free API продолжит
                // размещение остатка в следующих свободных ячейках.
                MarkDirty();
                SafeInvoke(OnInventoryChanged);
                return placedCount;
            }

            if (remainder > 0)
            {
                if (!CanPlaceInternalEmptyOnly(x, y, source.CurrentSize)) return placedCount;

                // Копия сохраняет fold/contents/точный заряд источника.
                var savedCopy = source.ToSaveData(x, y);
                SavedItem.ReserveSourceInstanceIDs(savedCopy);
                savedCopy.InstanceID = GlobalIDManager.GenerateID();
                savedCopy.BackpackContents = SavedItem.CloneContentsWithFreshInstanceIDs(savedCopy.BackpackContents);
                savedCopy.Quantity = Mathf.Min(remainder, source.Data.HardStackLimit);
                var newItem = InventoryItem.FromSaveData(savedCopy, source.Data);
                if (newItem == null) return placedCount;

                if (!BindToGrid(newItem, x, y))
                {
                    LogWarning($"Failed to bind new item {newItem.InstanceID} at ({x},{y})");
                    return placedCount;
                }

                _data.AddItem(newItem.ToSaveData(x, y));
                AdjustWeight(newItem.TotalWeightGrams);
                SafeInvoke(OnItemPlaced, newItem, x, y);
                placedCount += newItem.Quantity;
            }

            if (placedCount > 0)
            {
                MarkDirty();
                SafeInvoke(OnInventoryChanged);
            }

            return placedCount;
        }

        public bool PlaceExistingItem(InventoryItem item, int x, int y)
        {
            if (!InventoryGridBounds.IsValidBackpack(item?.Data)) return false;
            if (!InventoryItem.IsValidLiveQuantity(item)) return false;
            if (_placementFilter != null && !_placementFilter(item)) return false;
            if (_isDisposed || item == null || item.Data == null)
            {
                LogWarning($"PlaceExistingItem: invalid item");
                return false;
            }

            if (_itemCache.ContainsKey(item.InstanceID))
            {
                LogWarning($"PlaceExistingItem: item {item.InstanceID} already in cache — use MoveItem instead");
                return false;
            }

            if (!CanOccupy(x, y, item.CurrentSize, ignoredItem: item))
            {
                return false;
            }

            if (!BindToGrid(item, x, y))
            {
                LogWarning($"PlaceExistingItem: BindToGrid failed for item {item.InstanceID} at ({x},{y})");
                return false;
            }

            _data.AddItem(item.ToSaveData(x, y));
            AdjustWeight(item.TotalWeightGrams);
            SafeInvoke(OnItemPlaced, item, x, y);
            MarkDirty();
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        public bool PlaceExistingItemInFirstFreeSlot(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;

            for (int y = 0; y < _data.Height; y++)
                for (int x = 0; x < _data.Width; x++)
                    if (PlaceExistingItem(item, x, y))
                        return true;

            return false;
        }

       public bool MoveItem(InventoryItem item, int newX, int newY)
{
    if (item != null && (!_itemCache.TryGetValue(item.InstanceID, out var live) || !ReferenceEquals(live, item)))
        return false;
    if (_isDisposed || item == null || !_positionCache.ContainsKey(item.InstanceID))
    {
        LogWarning($"MoveItem: Item {item?.InstanceID} not found in position cache");
        return false;
    }
    var oldPos = _positionCache[item.InstanceID];
    // ═══ ФИКС [Integrity] "Cell outside footprint of its own item" ═══
    // Ранний return при совпадении позиции пропускал пересборку футпринта.
    // Предмет во время drag остаётся в сетке, а поворот (R) мутирует
    // CurrentSize — в сетке держится СТАРЫЙ футпринт. Drop в ту же корневую
    // позицию оставлял фантомные ячейки ((1,0) после 2x1→1x2) и не писал
    // IsRotated в _data. No-op разрешён только если футпринт и состояние
    // фактически не менялись.
    if (oldPos.x == newX && oldPos.y == newY && FootprintIntact(item, oldPos.x, oldPos.y))
    {
        var saved = _data.GetItem(item.InstanceID);
        if (saved.IsRotated == item.IsRotated && saved.IsFolded == item.IsFolded
            && saved.Quantity == item.Quantity)
            return true;
    }
    if (!CanOccupy(newX, newY, item.CurrentSize, item))
    {
        LogWarning($"MoveItem: Cannot move item {item.InstanceID} to ({newX},{newY})");
        return false;
    }
    // КОРНЕВОЙ ФИКС: Очистка ячеек по принадлежности предмету.
    // При вращении предмета во время drag, item.CurrentSize менялся, и старый ClearCellRange
    // оставлял "фантомные" ячейки в сетке, так как чистил по новому размеру.
    ClearCellsOwnedBy(item);
    _itemCache.Remove(item.InstanceID);
    _positionCache.Remove(item.InstanceID);
    if (!BindToGrid(item, newX, newY))
    {
        LogWarning($"MoveItem: BindToGrid failed for item {item.InstanceID} at ({newX},{newY})");
        return false;
    }
    RefreshItemInData(item);
    MarkDirty();
    SafeInvoke(OnInventoryChanged);
    return true;
}

private bool FootprintIntact(InventoryItem item, int x, int y)
{
    var size = item.CurrentSize;
    if (x < 0 || y < 0 || x + size.x > _data.Width || y + size.y > _data.Height) return false;
    var actual = GetActualFootprint(item);
    if (actual.x != x || actual.y != y || actual.width != size.x || actual.height != size.y)
        return false;
    for (int dy = 0; dy < size.y; dy++)
        for (int dx = 0; dx < size.x; dx++)
            if (!ReferenceEquals(_grid[x + dx, y + dy], item)) return false;
    return true;
}

        private InventoryItem FindStackTarget(InventoryItem item, int x, int y)
        {
            var target = GetItemAt(x, y);
            if (target == null) return null;

            if (!IsRootCell(target.InstanceID, x, y)) return null;

            if (target.CurrentSize.x != item.CurrentSize.x ||
                target.CurrentSize.y != item.CurrentSize.y ||
                target.RotationAngle != item.RotationAngle) return null;

            if (!CanStack(target, item)) return null;

            return target;
        }

        private bool BindToGrid(InventoryItem item, int x, int y)
        {
            if (_placementFilter != null && !_placementFilter(item)) return false;
            if (_itemCache.ContainsKey(item.InstanceID))
            {
                LogWarning($"Duplicate InstanceID {item.InstanceID} — skipping bind at ({x},{y})");
                return false;
            }

            var size = item.CurrentSize;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    _grid[x + dx, y + dy] = item;

            _itemCache[item.InstanceID] = item;
            _positionCache[item.InstanceID] = (x, y);
            return true;
        }
        #endregion

        #region Rotation & Removal
        public bool RotateItem(InventoryItem item)
        {
            if (item != null && (!_itemCache.TryGetValue(item.InstanceID, out var live) || !ReferenceEquals(live, item)))
                return false;
            if (_isDisposed || item == null || item.Data == null || !item.Data.CanRotate)
                return false;
            if (!_positionCache.TryGetValue(item.InstanceID, out var pos))
                return false;

            int oldAngle = item.RotationAngle;
            Vector2Int oldSize = item.CurrentSize;

            item.Rotate();
            if (item.RotationAngle == oldAngle)
                return false;

            Vector2Int candidateSize = item.CurrentSize;
            item.RestoreRotationState(oldAngle);

            if (!CanOccupy(pos.x, pos.y, candidateSize, ignoredItem: item))
                return false;

            ClearCellsOwnedBy(item);
            item.Rotate();

            if (item.CurrentSize != candidateSize)
            {
                item.RestoreRotationState(oldAngle);
                FillCells(item, pos.x, pos.y, oldSize);
                return false;
            }

            FillCells(item, pos.x, pos.y, candidateSize);

            _data.UpdateItem(item.InstanceID, pos.x, pos.y, item.Quantity, item.IsRotated);
            MarkDirty();
            SafeInvoke(OnItemRotated, item);
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        public bool RemoveItem(InventoryItem item)
        {
            if (item != null && (!_itemCache.TryGetValue(item.InstanceID, out var live) || !ReferenceEquals(live, item)))
                return false;
            if (_isDisposed || item == null || !_positionCache.ContainsKey(item.InstanceID)) return false;
            _atomicBeforeMutation?.Invoke(item);

            // КОРНЕВОЙ ФИКС: Безопасная очистка ячеек предмета. 
            // Устраняет баг с фантомными ячейками после вращения.
            ClearCellsOwnedBy(item);

            _itemCache.Remove(item.InstanceID);
            _positionCache.Remove(item.InstanceID);
            _data.RemoveItem(item.InstanceID);
            AdjustWeight(-item.TotalWeightGrams);

            SafeInvoke(OnItemRemoved, item);
            MarkDirty();
            SafeInvoke(OnInventoryChanged);
            return true;
        }
        #endregion

        #region Weight & Helpers
        public void AdjustWeight(int deltaGrams)
        {
            int oldWeight = _currentWeightGrams;
            _currentWeightGrams = Mathf.Max(0, _currentWeightGrams + deltaGrams);

            if (_currentWeightGrams != oldWeight) MarkDirty();
            SafeInvoke(OnWeightChanged, CurrentWeightKg);
        }

        private void RecalculateWeight()
        {
            int sum = 0;
            foreach (var item in _itemCache.Values) sum += item.TotalWeightGrams;
            _currentWeightGrams = sum;
            SafeInvoke(OnWeightChanged, CurrentWeightKg);
        }

        public InventoryItem GetItemAt(int x, int y)
        {
            if (_isDisposed || _data == null || _grid == null) return null;
            if (!IsValidCoordinate(x, y)) return null;
            return _grid[x, y];
        }

        public InventoryItem GetItemByInstanceID(uint id) =>
            !_isDisposed && _itemCache.TryGetValue(id, out var item) ? item : null;

        public bool TryGetItemPosition(uint id, out int x, out int y)
        {
            x = y = -1;
            if (_isDisposed || !_positionCache.TryGetValue(id, out var position)) return false;
            x = position.x; y = position.y;
            return true;
        }

        public (int x, int y) FindItemRootPosition(uint instanceId)
        {
            if (TryGetItemPosition(instanceId, out int x, out int y) &&
                GetItemAt(x, y)?.InstanceID == instanceId)
                return (x, y);
            return (-1, -1);
        }

/// <summary>
/// Возвращает ФАКТИЧЕСКИЙ AABB-футпринт предмета в _grid.
/// Если предмет не найден — (0,0,0,0).
///
/// ФИКС БАГА A: CurrentSize может НЕ совпадать с реальным AABB ячеек,
/// если предмет был повёрнут (item.Rotate()) во время drag — RotationAngle
/// мутировал, но BindToGrid/Refresh не вызывался. Для транзакционного swap,
/// где важно знать реально освобождаемые ячейки, используйте этот метод
/// вместо CurrentSize.
/// </summary>
public RectInt GetActualFootprint(InventoryItem item)
{
    if (_isDisposed || item == null || _grid == null) return new RectInt(0, 0, 0, 0);
    int minX = int.MaxValue, minY = int.MaxValue, maxX = int.MinValue, maxY = int.MinValue;
    for (int y = 0; y < _data.Height; y++)
        for (int x = 0; x < _data.Width; x++)
        {
            var at = _grid[x, y];
            if (at == null || at.InstanceID != item.InstanceID) continue;
            if (x < minX) minX = x;
            if (y < minY) minY = y;
            if (x > maxX) maxX = x;
            if (y > maxY) maxY = y;
        }
    if (minX == int.MaxValue) return new RectInt(0, 0, 0, 0);
    return new RectInt(minX, minY, maxX - minX + 1, maxY - minY + 1);
}
        public bool IsRootCell(uint id, int x, int y) =>
            _positionCache.TryGetValue(id, out var pos) && pos.x == x && pos.y == y;

        private void MarkDirty() => IsDirty = true;

        private void LogWarning(string message, [CallerMemberName] string method = "")
        {
            if (!_isDisposed) Debug.LogWarning($"[InventoryController.{method}] {message}");
        }

        private void SafeInvoke(Action handler)
        {
            if (!_isDisposed) handler?.Invoke();
        }

        private void SafeInvoke<T>(Action<T> handler, T arg)
        {
            if (!_isDisposed) handler?.Invoke(arg);
        }

        private void SafeInvoke<T1, T2>(Action<T1, T2> handler, T1 arg1, T2 arg2)
        {
            if (!_isDisposed) handler?.Invoke(arg1, arg2);
        }

        private void SafeInvoke<T1, T2, T3>(Action<T1, T2, T3> handler, T1 arg1, T2 arg2, T3 arg3)
        {
            if (!_isDisposed) handler?.Invoke(arg1, arg2, arg3);
        }
        #endregion

        #region UI Helper Methods
        public int GetItemCount() => _itemCache.Count;

        public bool CanFitItem(Vector2Int size)
        {
            if (size.x > _data.Width || size.y > _data.Height) return false;
            for (int x = 0; x <= _data.Width - size.x; x++)
                for (int y = 0; y <= _data.Height - size.y; y++)
                    if (CanPlaceInternalEmptyOnly(x, y, size)) return true;
            return false;
        }

        public int GetFreeCellCount()
        {
            int count = 0;
            for (int x = 0; x < _data.Width; x++)
                for (int y = 0; y < _data.Height; y++)
                    if (_grid[x, y] == null) count++;
            return count;
        }

        /// <summary>Размещает всю порцию, включая объединение нескольких стеков. При недостатке места не меняет инвентарь.</summary>
        public bool TryPlaceItemInFirstFreeSlot(InventoryItem item)
        {
            if (_isDisposed || item == null || item.Data == null || item.Quantity <= 0) return false;
            if (!CanPlaceWholeQuantity(item)) return false;
            int remaining = item.Quantity;

            for (int y = 0; y < _data.Height && remaining > 0; y++)
                for (int x = 0; x < _data.Width && remaining > 0; x++)
                    remaining -= TryPlaceItemQuantity(item, x, y, remaining);

            return remaining == 0;
        }

        private bool CanPlaceWholeQuantity(InventoryItem item)
        {
            if (!InventoryGridBounds.IsValidBackpack(item?.Data)) return false;
            if (_placementFilter != null && !_placementFilter(item)) return false;
            int remaining = item.Quantity;
            int limit = item.Data.HardStackLimit;
            if (remaining < 1 || limit < 1) return false;
            var size = item.CurrentSize;
            var reserved = new bool[_data.Width, _data.Height];
            var countedStackIDs = new HashSet<uint>();
            for (int y = 0; y < _data.Height; y++)
                for (int x = 0; x < _data.Width; x++)
                {
                    if (!CanPlaceInternal(item, x, y, size)) continue;
                    bool overlapsReservation = false;
                    for (int row = y; row < y + size.y && !overlapsReservation; row++)
                        for (int column = x; column < x + size.x; column++)
                            if (reserved[column, row]) { overlapsReservation = true; break; }
                    if (overlapsReservation) continue;
                    var stack = FindStackTarget(item, x, y);
                    if (stack != null)
                    {
                        if (countedStackIDs.Add(stack.InstanceID))
                            remaining -= Mathf.Min(remaining, Mathf.Max(0, stack.SpaceInStack));
                    }
                    else if (CanPlaceInternalEmptyOnly(x, y, size))
                    {
                        for (int row = y; row < y + size.y; row++)
                            for (int column = x; column < x + size.x; column++) reserved[column, row] = true;
                        remaining -= Mathf.Min(remaining, limit);
                    }
                    if (remaining == 0) return true;
                }
            return false;
        }
                public InventoryData GetSaveData() => _data;

        /// <summary>
        /// ФИКС: Безопасно обновляет SavedItem в _data перед сохранением или синхронизацией,
        /// используя уже актуальный _backpackContentsSerialized. НЕ вызывает GetSaveData(), избегая рекурсии.
        /// </summary>
        public void RefreshAllItemsInData()
{
    if (_isDisposed || _data == null)
        return;

    foreach (var kvp in _itemCache)
    {
        var item = kvp.Value;
        if (item == null)
            continue;

        RefreshItemInData(item);
    }
}
        public bool RefreshItemInData(InventoryItem item)
{
    if (_isDisposed || item == null || _data == null)
        return false;

    if (!_itemCache.TryGetValue(item.InstanceID, out var liveItem))
        return false;

    if (!ReferenceEquals(liveItem, item))
        return false;

    if (!_positionCache.TryGetValue(item.InstanceID, out var pos))
        return false;

    _data.UpdateItemWithContents(
        liveItem.InstanceID,
        pos.x,
        pos.y,
        liveItem.Quantity,
        liveItem.IsRotated,
        liveItem.IsFolded,
        liveItem.GetBackpackContentsRaw(),
        liveItem.ChargePercent,
        liveItem.RemainingChargeSeconds); // Stage 4: persist exact time, percentage is display-only.

    MarkDirty();
    return true;
}
        
        /// <summary>Publishes quantity notifications after the caller has updated the live item and DTO.</summary>
        public void NotifyItemQuantityChanged(InventoryItem item)
        {
            if (_isDisposed || item == null ||
                !_itemCache.TryGetValue(item.InstanceID, out var liveItem) ||
                !ReferenceEquals(liveItem, item))
                return;

            SafeInvoke(OnItemQuantityChanged, item);
            SafeInvoke(OnInventoryChanged);
        }

        public void Clear()
        {
            if (_isDisposed) return;

            if (_grid != null && _data != null)
            {
                Array.Clear(_grid, 0, _grid.Length);
                _grid = new InventoryItem[_data.Width, _data.Height];
            }

            _itemCache.Clear();
            _positionCache.Clear();
            _currentWeightGrams = 0;

            if (_data != null) _data.Clear();

            MarkDirty();
            SafeInvoke(OnInventoryChanged);
        }

        public bool Resize(int newWidth, int newHeight)
        {
            if (_isDisposed || _data == null) return false;
            newWidth = Mathf.Clamp(newWidth, 1, 20);
            newHeight = Mathf.Clamp(newHeight, 1, 20);
            if (newWidth == _data.Width && newHeight == _data.Height) return true;

            var snapshot = new List<(InventoryItem item, int x, int y)>(_itemCache.Count);
            foreach (var kvp in _positionCache)
                if (_itemCache.TryGetValue(kvp.Key, out var it) && it != null)
                    snapshot.Add((it, kvp.Value.x, kvp.Value.y));

            var tempGrid = new InventoryItem[newWidth, newHeight];
            var tempItemCache = new Dictionary<uint, InventoryItem>();
            var tempPositionCache = new Dictionary<uint, (int x, int y)>();
            var tempDataItems = new List<SavedItem>(snapshot.Count);

            var notPlaced = new List<InventoryItem>();

            foreach (var (item, x, y) in snapshot)
            {
                if (CanOccupyIn(tempGrid, newWidth, newHeight, x, y, item.CurrentSize, ignoredItem: item))
                {
                    PlaceInTemp(tempGrid, item, x, y, item.CurrentSize);
                    tempItemCache[item.InstanceID] = item;
                    tempPositionCache[item.InstanceID] = (x, y);
                    tempDataItems.Add(item.ToSaveData(x, y));
                }
                else
                {
                    bool placed = false;
                    for (int ny = 0; ny < newHeight && !placed; ny++)
                        for (int nx = 0; nx < newWidth && !placed; nx++)
                            if (CanOccupyIn(tempGrid, newWidth, newHeight, nx, ny, item.CurrentSize, null))
                            {
                                PlaceInTemp(tempGrid, item, nx, ny, item.CurrentSize);
                                tempItemCache[item.InstanceID] = item;
                                tempPositionCache[item.InstanceID] = (nx, ny);
                                tempDataItems.Add(item.ToSaveData(nx, ny));
                                placed = true;
                            }
                    if (!placed) notPlaced.Add(item);
                }
            }

            if (notPlaced.Count > 0 && OnResizeOverflow == null)
            {
                LogWarning(
                    $"Resize: {notPlaced.Count} items cannot fit in " +
                    $"{newWidth}x{newHeight} and no OnResizeOverflow subscriber. Aborting.");
                return false;
            }

            if (_grid != null) Array.Clear(_grid, 0, _grid.Length);
            _grid = tempGrid;
            _itemCache.Clear();
            foreach (var kvp in tempItemCache) _itemCache[kvp.Key] = kvp.Value;
            _positionCache.Clear();
            foreach (var kvp in tempPositionCache) _positionCache[kvp.Key] = kvp.Value;

            _data.Resize(newWidth, newHeight);
            foreach (var sd in tempDataItems) _data.AddItem(sd);

            if (notPlaced.Count > 0)
            {
                OnResizeOverflow.Invoke(notPlaced);
            }

            RecalculateWeight();
            MarkDirty();
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        private static bool CanOccupyIn(InventoryItem[,] grid, int w, int h, int x, int y, Vector2Int size, InventoryItem ignoredItem)
        {
            if (size.x <= 0 || size.y <= 0) return false;
            if (x < 0 || y < 0 || x > w - size.x || y > h - size.y) return false;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    var occ = grid[x + dx, y + dy];
                    if (occ != null && !ReferenceEquals(occ, ignoredItem))
                        return false;
                }
            return true;
        }

        private static void PlaceInTemp(InventoryItem[,] grid, InventoryItem item, int x, int y, Vector2Int size)
        {
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    grid[x + dx, y + dy] = item;
        }
        #endregion

        #region Serialization
        private void ValidateInitialDataGeometry()
        {
            using (var validation = new SaveLoadValidationContext())
            {
                if (SaveID == "WorldLoot_Transient")
                    InventoryLoadReader.ValidateTransientGroundGrid(_data.GetItems(), _data.Width, _data.Height,
                        _database, validation);
                else InventoryLoadReader.ValidateTree(_data.GetItems(), _data.Width, _data.Height,
                    _database, validation, SaveID);
            }
        }

        private void ValidateControllerDomainAndRewind(BinaryReader reader)
        {
            long start = reader.BaseStream.Position;
            try
            {
                var pending = InventoryLoadReader.ReadController(reader);
                using (var validation = new SaveLoadValidationContext())
                    InventoryLoadReader.ValidateTree(pending.Inventory.Items, pending.Inventory.Width,
                        pending.Inventory.Height, _database, validation, SaveID);
            }
            finally { reader.BaseStream.Position = start; }
        }

        internal Action ObserveAtomicMutation(Action<InventoryItem> observer)
        {
            var previous = _atomicBeforeMutation;
            _atomicBeforeMutation = observer;
            return () => _atomicBeforeMutation = previous;
        }

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            var pending = InventoryLoadReader.ReadController(reader);
            if (!string.Equals(pending.SaveID, SaveID, StringComparison.Ordinal))
                throw new InvalidDataException($"Inventory payload SaveID '{pending.SaveID}' does not match '{SaveID}'.");
            bool projection = SaveID == "Player_Backpack";
            InventoryLoadReader.ValidateTree(pending.Inventory.Items, pending.Inventory.Width,
                pending.Inventory.Height, _database, context, SaveID, !projection);
            if (projection) context.RecordBackpackProjection(InventoryLoadReader.Fingerprint(pending.Inventory.Items));
        }

        /// <summary>Captures ownership before any removal or callback, preserving exact live references.</summary>
        internal Action CaptureAtomicRestore()
        {
            if (_isDisposed) throw new ObjectDisposedException(nameof(InventoryController));
            var data = _data;
            var restoreData = data.CaptureAtomicRestore();
            var grid = (InventoryItem[,])_grid.Clone();
            var items = new Dictionary<uint, InventoryItem>(_itemCache);
            var positions = new Dictionary<uint, (int x, int y)>(_positionCache);
            int weight = _currentWeightGrams, capacity = _maxCapacityGrams;
            bool dirty = IsDirty;
            return () =>
            {
                _data = data;
                restoreData();
                _grid = (InventoryItem[,])grid.Clone();
                _itemCache.Clear();
                foreach (var pair in items) _itemCache.Add(pair.Key, pair.Value);
                _positionCache.Clear();
                foreach (var pair in positions) _positionCache.Add(pair.Key, pair.Value);
                _currentWeightGrams = weight;
                _maxCapacityGrams = capacity;
                IsDirty = dirty;
            };
        }

        public void Save(BinaryWriter writer)
        {
            writer.Write(SaveID);
            writer.Write(IsDirty);
            _data?.Save(writer);
        }

        public void Load(BinaryReader reader)
        {
            if (_isDisposed || _data == null)
                throw new ObjectDisposedException(nameof(InventoryController));

            InventoryLoadReader.ValidateControllerAndRewind(reader);
            ValidateControllerDomainAndRewind(reader);

            string loadedSaveId = reader.ReadString();
            _ = reader.ReadBoolean(); 

            if (!string.Equals(loadedSaveId, SaveID, StringComparison.Ordinal))
                Debug.LogWarning(
                    $"[InventoryController.Load] SaveID mismatch: " +
                    $"expected='{SaveID}', got='{loadedSaveId}'. " +
                    "Continuing load — payload structure must still match.");

            if (_grid != null)
                Array.Clear(_grid, 0, _grid.Length);

            _itemCache.Clear();
            _positionCache.Clear();

            _data.Load(reader);
            _grid = new InventoryItem[_data.Width, _data.Height];

            LoadFromData();
            IsDirty = false;

            SafeInvoke(OnInventoryChanged);
        }
        #endregion

        #region Disposable & Memory Safety
        public void Dispose()
        {
            if (_isDisposed) return;
            InventoryOwnershipRegistry.Unregister(this);
            _isDisposed = true;

            OnInventoryChanged = null;
            OnWeightChanged = null;
            OnItemPlaced = null;
            OnItemRemoved = null;
            OnItemRotated = null;
            OnItemQuantityChanged = null;

            _itemCache.Clear();
            _positionCache.Clear();

            if (_grid != null)
            {
                Array.Clear(_grid, 0, _grid.Length);
                _grid = null;
            }

            _data = null;
            _database = null;
        }
    
        #endregion

                #region Debug
        [ContextMenu("Debug: Print Grid")]
        public void DebugPrintGrid()
        {
            if (_isDisposed || _data == null || _grid == null) return;

            Debug.Log($"=== GRID {_data.Width}x{_data.Height} ===");
            for (int y = _data.Height - 1; y >= 0; y--)
            {
                var row = "";
                for (int x = 0; x < _data.Width; x++)
                    row += _grid[x, y] == null ? "[ ]" : $"[{_grid[x, y]?.PrefabID}]";
                Debug.Log(row);
            }
            Debug.Log($"Weight: {CurrentWeightKg:F1}kg | Items: {_itemCache.Count}");
        }
        #endregion
        #region Stage 5.2 atomic combat transfers (append-only)
        /// <summary>Returns a detached magazine or one round. Refusal never removes it from its combat owner.</summary>
        public static bool TryReturnDetachedCombatItem(InventoryItem item,
            IReadOnlyList<InventoryController> destinations, Func<bool> releaseCombatOwner, Action restoreCombatOwner)
        {
            if (!InventoryItem.IsValidLiveQuantity(item) || item.Quantity != 1 || destinations == null ||
                releaseCombatOwner == null || restoreCombatOwner == null) return false;
            InventoryController destination = null;
            InventoryItem stack = null;
            int targetX = -1, targetY = -1;
            // Match PrefabID, not merely caliber: two ammunition definitions must never be merged here.
            if (item.Type == ItemType.Ammo)
                for (int i = 0; i < destinations.Count && destination == null; i++)
                {
                    var candidate = destinations[i];
                    if (candidate == null || candidate.IsDisposed) continue;
                    foreach (var existing in candidate._itemCache.Values)
                        if (existing.Type == ItemType.Ammo && existing.PrefabID == item.PrefabID &&
                            existing.Quantity < existing.Data.HardStackLimit)
                        { destination = candidate; stack = existing; break; }
                }
            if (destination == null)
                for (int i = 0; i < destinations.Count && destination == null; i++)
                {
                    var candidate = destinations[i];
                    if (candidate == null || candidate.IsDisposed || candidate._itemCache.ContainsKey(item.InstanceID) ||
                        (candidate._placementFilter != null && !candidate._placementFilter(item))) continue;
                    for (int y = 0; y < candidate.Height && destination == null; y++)
                        for (int x = 0; x < candidate.Width; x++)
                            if (candidate.CanOccupy(x, y, item.CurrentSize, null))
                            { destination = candidate; targetX = x; targetY = y; break; }
                }
            if (destination == null) return false;
            var restoreGrid = destination.CaptureAtomicRestore();
            var restoreStack = stack?.CaptureAtomicRestore();
            bool releaseAttempted = false;
            try
            {
                if (stack != null)
                {
                    stack.AddQuantity(1);
                    destination.RefreshItemInData(stack);
                }
                else
                {
                    destination.FillCells(item, targetX, targetY, item.CurrentSize);
                    destination._itemCache.Add(item.InstanceID, item);
                    destination._positionCache.Add(item.InstanceID, (targetX, targetY));
                    destination._data.AddItem(item.ToSaveData(targetX, targetY));
                }
                releaseAttempted = true;
                if (!releaseCombatOwner()) { restoreStack?.Invoke(); restoreGrid(); return false; }
                destination.MarkDirty();
                destination.AdjustWeight(item.TotalWeightGrams);
                if (stack != null) destination.SafeInvoke(destination.OnItemQuantityChanged, stack);
                else destination.SafeInvoke(destination.OnItemPlaced, item, targetX, targetY);
                destination.SafeInvoke(destination.OnInventoryChanged);
                return true;
            }
            catch
            {
                restoreStack?.Invoke();
                restoreGrid();
                if (releaseAttempted) restoreCombatOwner();
                throw;
            }
        }

        /// <summary>Commits charge and the caller's state-first effect before external inventory notifications.</summary>
        public bool TryConsumeCharge(InventoryItem item, float amount, Action applyEffect)
        {
            if (_isDisposed || item?.Data == null || !item.Data.HasIndividualCharge || item.Quantity != 1 ||
                applyEffect == null || float.IsNaN(amount) || float.IsInfinity(amount) || amount <= 0f ||
                !ReferenceEquals(GetItemByInstanceID(item.InstanceID), item) || amount > item.RemainingChargeAmount ||
                !_positionCache.ContainsKey(item.InstanceID)) return false;
            _atomicBeforeMutation?.Invoke(item);
            float remaining = Mathf.Max(0f, item.RemainingChargeAmount - amount);
            item.RemainingChargeAmount = remaining;
            bool removed = remaining == 0f;
            if (removed)
            {
                ClearCellsOwnedBy(item);
                _itemCache.Remove(item.InstanceID);
                _positionCache.Remove(item.InstanceID);
                _data.RemoveItem(item.InstanceID);
                _currentWeightGrams = Mathf.Max(0, _currentWeightGrams - item.TotalWeightGrams);
            }
            else RefreshItemInData(item);
            MarkDirty();
            // These callbacks set blood/vitality first, then publish their events.
            // An observer exception is reported after the committed state; never signal
            // a failed operation that the caller could retry and spend twice.
            try { applyEffect(); } catch (Exception exception) { Debug.LogException(exception); }
            if (removed)
            {
                PublishChargeObserver(() => OnWeightChanged?.Invoke(CurrentWeightKg));
                PublishChargeObserver(() => OnItemRemoved?.Invoke(item));
            }
            else PublishChargeObserver(() => OnItemQuantityChanged?.Invoke(item));
            PublishChargeObserver(() => OnInventoryChanged?.Invoke());
            return true;
        }

        private static void PublishChargeObserver(Action notify)
        {
            try { notify(); } catch (Exception exception) { Debug.LogException(exception); }
        }

        /// <summary>Publishes inventory events only after the destination accepted one unit.</summary>
        public bool TryConsumeSingleForTransfer(InventoryItem source, Func<bool> acceptUnit)
        {
            if (_isDisposed || source == null || source.Quantity <= 0 || acceptUnit == null ||
                !_itemCache.TryGetValue(source.InstanceID, out var live) || !ReferenceEquals(live, source))
                return false;
            if (!acceptUnit()) return false;

            source.RemoveQuantity(1);
            bool removed = source.Quantity == 0;
            if (removed)
            {
                ClearCellsOwnedBy(source);
                _itemCache.Remove(source.InstanceID);
                _positionCache.Remove(source.InstanceID);
                _data.RemoveItem(source.InstanceID);
            }
            else RefreshItemInData(source);
            MarkDirty();
            AdjustWeight(-source.Data.WeightGrams);
            if (removed) SafeInvoke(OnItemRemoved, source);
            else SafeInvoke(OnItemQuantityChanged, source);
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        /// <summary>Preflight includes the cells freed by taking the incoming item.</summary>
        public static bool CanExchangeDetachedItem(InventoryController source, InventoryItem incoming,
            InventoryItem outgoing, IReadOnlyList<InventoryController> destinations)
            => FindCombatReturnPlacement(source, incoming, outgoing, destinations, out _, out _, out _);

        /// <summary>Atomically exchanges a grid item with a detached combat container.
        /// The graph callback must return false without mutations, or complete the graph exchange.</summary>
        public static bool TryExchangeDetachedItem(InventoryController source, InventoryItem incoming,
            InventoryItem outgoing, IReadOnlyList<InventoryController> destinations, Func<bool> exchangeGraph)
        {
            if (exchangeGraph == null || !FindCombatReturnPlacement(source, incoming, outgoing, destinations,
                    out var destination, out int x, out int y)) return false;
            if (!exchangeGraph()) return false;

            source.ClearCellsOwnedBy(incoming);
            source._itemCache.Remove(incoming.InstanceID);
            source._positionCache.Remove(incoming.InstanceID);
            source._data.RemoveItem(incoming.InstanceID);
            if (outgoing != null)
            {
                // All predicates and footprints were checked before either graph changed.
                destination.FillCells(outgoing, x, y, outgoing.CurrentSize);
                destination._itemCache.Add(outgoing.InstanceID, outgoing);
                destination._positionCache.Add(outgoing.InstanceID, (x, y));
                destination._data.AddItem(outgoing.ToSaveData(x, y));
                destination.MarkDirty();
            }
            source.MarkDirty();
            if (ReferenceEquals(source, destination))
                source._currentWeightGrams = Mathf.Max(0,
                    source._currentWeightGrams + (outgoing?.TotalWeightGrams ?? 0) - incoming.TotalWeightGrams);
            else
            {
                source._currentWeightGrams = Mathf.Max(0, source._currentWeightGrams - incoming.TotalWeightGrams);
                if (outgoing != null)
                    destination._currentWeightGrams = Mathf.Max(0, destination._currentWeightGrams + outgoing.TotalWeightGrams);
            }
            // Graph, both grids and both weights are committed before any observer runs.
            // A notification fault cannot turn this completed transfer into a retryable failure.
            PublishChargeObserver(() => source.SafeInvoke(source.OnWeightChanged, source.CurrentWeightKg));
            if (outgoing != null && !ReferenceEquals(source, destination))
                PublishChargeObserver(() => destination.SafeInvoke(destination.OnWeightChanged, destination.CurrentWeightKg));
            PublishChargeObserver(() => source.SafeInvoke(source.OnItemRemoved, incoming));
            if (outgoing != null)
                PublishChargeObserver(() => destination.SafeInvoke(destination.OnItemPlaced, outgoing, x, y));
            PublishChargeObserver(() => source.SafeInvoke(source.OnInventoryChanged));
            if (destination != null && !ReferenceEquals(source, destination))
                PublishChargeObserver(() => destination.SafeInvoke(destination.OnInventoryChanged));
            return true;
        }

        private static bool FindCombatReturnPlacement(InventoryController source, InventoryItem incoming,
            InventoryItem outgoing, IReadOnlyList<InventoryController> destinations,
            out InventoryController destination, out int resultX, out int resultY)
        {
            destination = null; resultX = resultY = -1;
            if (source == null || source.IsDisposed || incoming == null || incoming.Quantity != 1 ||
                !ReferenceEquals(source.GetItemByInstanceID(incoming.InstanceID), incoming)) return false;
            if (outgoing == null) return true;
            if (outgoing.Quantity != 1 || outgoing.InstanceID == incoming.InstanceID || destinations == null) return false;
            for (int i = 0; i < destinations.Count; i++)
            {
                var candidate = destinations[i];
                if (candidate == null || candidate.IsDisposed) continue;
                if (candidate.GetItemByInstanceID(outgoing.InstanceID) != null) return false;
            }
            for (int i = 0; i < destinations.Count; i++)
            {
                var candidate = destinations[i];
                if (candidate == null || candidate.IsDisposed ||
                    (candidate._placementFilter != null && !candidate._placementFilter(outgoing))) continue;
                for (int y = 0; y < candidate.Height; y++)
                    for (int x = 0; x < candidate.Width; x++)
                        if (candidate.CanOccupy(x, y, outgoing.CurrentSize,
                            ReferenceEquals(candidate, source) ? incoming : null))
                        { destination = candidate; resultX = x; resultY = y; return true; }
            }
            return false;
        }
        #endregion
    }
}
