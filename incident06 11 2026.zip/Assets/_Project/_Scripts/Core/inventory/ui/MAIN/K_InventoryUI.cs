
using K_Incident.Core;
using K_Incident.Core.Inventory;
using K_Incident.Core.World;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    public partial class K_InventoryUI : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Grid Config")]
        [SerializeField, Tooltip("Размер слота в пикселях")]
        private float _slotSize = 70f;

        [SerializeField, Tooltip("Отступ между слотами")]
        private float _slotSpacing = 0f;

        [Header("References")]
        [SerializeField] private K_InventorySetup _inventorySetup;

        [Header("Player Inventory Weight")]
        [SerializeField] private TextMeshProUGUI _weightText;

        [SerializeField, Tooltip("Градиент цвета текста веса. X = weightRatio (0..1.1+), Y = цвет. " +
            "Дефолт: 0.0 белый, 0.5 белый, 0.9 жёлтый, 1.1 красный.")]
        private Gradient _weightTextGradient;

        [SerializeField] private GameObject _slotPrefab;
        [SerializeField] private GameObject _uiItemPrefab;
        [SerializeField] private GameObject _dragGhostPrefab;

        [Header("Player Inventory (LEFT PANE)")]
        [SerializeField] private Transform _pocketsGrid;
        [SerializeField] private Transform _pocket2Grid;
        [SerializeField] private Transform _backpackGrid;
        [SerializeField] private GameObject _backpackPanel;
        [SerializeField] private Transform _pocketsItemsContainer;
        [SerializeField] private Transform _pocket2ItemsContainer;
        [SerializeField] private Transform _backpackItemsContainer;

        [Header("Equipment Slots")]
        [SerializeField] private K_EquipmentSlotUI _primarySlot1;
        [SerializeField] private K_EquipmentSlotUI _primarySlot2;
        [SerializeField] private K_EquipmentSlotUI _pistolSlot;
        [SerializeField] private K_EquipmentSlotUI _meleeSlot;
        [SerializeField] private K_EquipmentSlotUI _backpackSlot;
        [SerializeField] private K_EquipmentSlotUI _armorSlot;
[SerializeField] private K_EquipmentSlotUI _headgearSlot;

        [Header("Surroundings/Container (RIGHT PANE)")]
        [SerializeField] private GameObject _surroundingsPanel;
        [SerializeField] private Transform _surroundingsGrid;
        [SerializeField] private Transform _surroundingsItemsContainer;
        [SerializeField] private TextMeshProUGUI _containerNameText;

            [Header("Container Window (Floating)")]
        [SerializeField, Tooltip("Единая заливка панели плавающего окна рюкзака. #9F9F9F alpha 4/255.")]
        private Color _containerWindowFillColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 4f / 255f);

        [SerializeField, Tooltip("Цвет рамки по периметру панели окна и разделителя шапки. #9F9F9F alpha 45.")]
        private Color _containerWindowBorderColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 45f / 255f);

        [SerializeField, Tooltip("Толщина рамки окна и разделителя шапки (px).")]
        private float _containerWindowBorderThickness = 1f;

         [Header("Surroundings Header")]
        [SerializeField, Tooltip("Высота шапки панели лута (px).")]
        private float _surroundingsHeaderHeight = 32f;

        [SerializeField, Tooltip("Единая заливка панели и шапки — едва заметная «пелена». #9F9F9F alpha 4/255. Отдельной тёмной плашки под шапкой нет.")]
        private Color _surroundingsFillColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 4f / 255f);

        [SerializeField, Tooltip("Цвет нижней и верхней линии шапки, а также бордера панели. #9F9F9F alpha 45.")]
        private Color _surroundingsBorderColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 45f / 255f);

[SerializeField, Tooltip("Толщина линий бордера панели (bottom/left/right) и разделителя шапки (px).")]
private float _surroundingsBorderThickness = 1f;

[SerializeField, Tooltip("Толщина ВЕРХНЕЙ границы панели (px). " +
    "Увеличь до 2 если 1px не отрисовывается из-за субпиксельного рендеринга Unity Canvas.")]
private float _surroundingsTopBorderThickness = 2f;
        // ═══════════════════════════════════════════════════════════════
        // МУЛЬТИОКОННАЯ СИСТЕМА: несколько рюкзаков открыто одновременно
        // Каждое окно — отдельный K_ContainerWindow со своей панелью/сеткой.
        // _surroundingsPanel/Grid/ItemsContainer указывают на АКТИВНОЕ окно
        // (или на оригинальные объекты для лута).
        // ═══════════════════════════════════════════════════════════════
        [Header("Multi-Window Focus System")]
        [SerializeField, Tooltip("Родитель для всех плавающих окон контейнеров. " +
            "Все окна должны быть детьми одного родителя для корректного z-order.")]
        private Transform _floatingWindowsRoot;

        // Оригинальные ссылки (для возврата при луте)
        private GameObject _originalSurroundingsPanel;
        private Transform _originalSurroundingsGrid;
        private Transform _originalSurroundingsItemsContainer;
      
        private Coroutine _textRebuildCoroutine;
        // ═══════════════════════════════════════════════════════════════
        // ФИЧА #2: Префаб заголовка панели контейнера (DragZone).
        // Если задан — инстанцируется при открытии рюкзака-контейнера и
        // используется как зона перетаскивания. Если null — генерируется
        // программно с параметрами ниже (обратная совместимость).
        // Размер/вид префаба настраивается в редакторе в любое время.
        // ════════════════════════════════════════════════════════════════
        [Header("Draggable Container Header (ФИЧА #2)")]
        [SerializeField, Tooltip("Префаб заголовка панели контейнера (DragZone). Если задан — " +
            "инстанцируется при открытии рюкзака-контейнера. Должен содержать RectTransform. " +
            "Текст имени рюкзака будет найден через GetComponentInChildren<TextMeshProUGUI>(). " +
            "Если null — генерируется программно с параметрами ниже.")]
        private GameObject _containerHeaderPrefab;

        [SerializeField, Tooltip("Высота заголовка панели (px). Только для программной генерации, " +
            "когда _containerHeaderPrefab не задан.")]
        private float _containerHeaderHeight = 32f;

        [SerializeField, Tooltip("Цвет фона заголовка панели. Только для программной генерации.")]
        private Color _containerHeaderColor = new Color(0.12f, 0.13f, 0.15f, 0.95f);

        [Header("Background")]
        [SerializeField, Tooltip("Объект с фоном инвентаря (Image). Raycast Target должен быть снят.")]
        private GameObject _inventoryBackground;

        [Header("Health Doll")]
        [SerializeField, Tooltip("Панель куклы здоровья. Используется во вкладке 'Здоровье'.")]
        private GameObject _healthDollPanel;

        [Header("Tab System")]

        [SerializeField, Tooltip("Панель содержимого вкладки 'Инвентарь' (сетки, слоты экипировки).")]
        private GameObject _inventoryContentPane;

        [SerializeField, Tooltip("Панель содержимого вкладки 'Здоровье' (кукла, эффекты, состояние).")]
        private GameObject _healthContentPane;

        [SerializeField, Tooltip("Кнопки вкладок. Индекс 0 = Инвентарь, индекс 1 = Здоровье.")]
        private GameObject[] _tabButtons;

        // UI-STYLE: Inspector border color for the corresponding tab state.
        [SerializeField, Tooltip("Цвет активной кнопки вкладки.")]
        private Color _activeTabColor = new Color(1f, 0.85f, 0f, 0.8f);

        // UI-STYLE: Inspector border color for the corresponding tab state.
        [SerializeField, Tooltip("Цвет неактивной кнопки вкладки.")]
        private Color _inactiveTabColor = new Color(0.6f, 0.6f, 0.6f, 0.5f);

        [SerializeField, Tooltip("Tab fill color; Inspector is the runtime source.")]
        private Color _tabFillColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 4f / 255f);
        [SerializeField, Tooltip("Tab text color; Inspector is the runtime source.")]
        private Color _tabTextColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 1f);

        [Header("Configuration")]
        [SerializeField] private KeyCode _openCloseKey = KeyCode.Tab;
        [SerializeField] private KeyCode _rotateKey = KeyCode.R;
        [SerializeField, Tooltip("Клавиша быстрого свернуть/развернуть наведённый рюкзак в инвентаре.")]
        private KeyCode _foldKey = KeyCode.F;

        [Header("UI Colors")]
        [SerializeField] private Color _dragValidColor = new Color(0.33f, 0.55f, 0.33f, 0.7f);
        [SerializeField] private Color _dragInvalidColor = new Color(0.71f, 0.24f, 0.24f, 0.7f);

        [Header("Hover Highlight")]
        [SerializeField, Tooltip("Включить выделение предмета при наведении")]
        private bool _enableHoverHighlight = true;

        [Header("Occupied Cell Tint")]
        [SerializeField, Tooltip("Тонировка ячеек, занятых предметом. alpha=0 → выключено.")]
        private Color _occupiedCellTint = new Color(1f, 1f, 1f, 0f); // белая, но alpha=0 → невидимо

        [Header("Internal Border Hiders")]
        [SerializeField, Tooltip("Цвет перекрытия внутренних границ. Подбери под цвет фона ячейки.")]
        private Color _borderHiderColor = new Color(0.12f, 0.12f, 0.12f, 1f);
        [SerializeField, Tooltip("Толщина перекрытия границы (px). Ширина вертикальной / высота горизонтальной линии.")]
        private float _borderHiderThickness = 3f;

        [Header("Border Hider Inset (отступы от краёв ячейки)")]
        [SerializeField, Tooltip("Отступ сверху для вертикальных hider'ов. Отрицательное = выходит за верх ячейки.")]
        private float _bhInsetTop = 1f;
        [SerializeField, Tooltip("Отступ снизу для вертикальных hider'ов. Отрицательное = выходит за низ ячейки.")]
        private float _bhInsetBottom = 1f;
        [SerializeField, Tooltip("Отступ слева для горизонтальных hider'ов. Отрицательное = выходит за левый край.")]
        private float _bhInsetLeft = 1f;
        [SerializeField, Tooltip("Отступ справа для горизонтальных hider'ов. Отрицательное = выходит за правый край.")]
        private float _bhInsetRight = 1f;

        [Header("Grid Bottom Border Fix (PP)")]
        [SerializeField, Tooltip("Цвет нарисованной нижней границы. Подбери под цвет рамок ячеек.")]
    private Color _gridBottomBorderColor = new Color(0.3f, 0.3f, 0.3f, 1f);

        [Header("Internal Borders (grid lines inside items)")]
        [SerializeField, Tooltip("Если true — линии сетки внутри многоячеечных предметов " +
                                 "скрываются (предмет выглядит как единая плитка). " +
                                 "Если false (по умолчанию) — линии остаются видимыми, " +
                                 "предмет выглядит как набор отдельных ячеек с иконкой.")]
        private bool _hideBordersUnderItems = false;
        [SerializeField, Tooltip("Толщина нарисованной нижней границы (px).")]
        private float _gridBottomBorderHeight = 1f;
        [SerializeField, Tooltip("Сдвиг границы вверх от математического низа (px). Увеличь если линия обрезается.")]
        private float _gridBottomBorderOffset = 1f;

        [Header("Drag Outline Highlight")]
        [SerializeField, Tooltip("Цвет рамки при валидной позиции drag")]
        private Color _dragOutlineValidColor = new Color(1f, 0.85f, 0f, 0.8f);
        [SerializeField, Tooltip("Цвет рамки при невалидной позиции drag")]
        private Color _dragOutlineInvalidColor = new Color(0.85f, 0.15f, 0.15f, 0.8f);

        [SerializeField, Tooltip("Цвет рамки когда ячейка занята и произойдёт замена (swap) предметов")]
        private Color _dragOutlineSwapColor = new Color(0.2f, 0.6f, 1f, 0.85f);
        [SerializeField, Tooltip("Толщина рамки подсветки при drag (px)")]
        private float _dragOutlineThickness = 2f;

        [Header("Context Menu Style")]
        [SerializeField, Tooltip("Ассет визуального стиля контекстного меню. Создайте через Create > K Context Menu Style. " +
            "Если null — используются дефолтные значения. Редактируется в Inspector в любое время, даже вне Play-режима!")]
        private K_ContextMenuStyle _contextMenuStyle;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false;

     
        public bool DebugLogs => _debugLogs;

        #endregion

        #region Constants
        public const int MAX_BACKPACK_NESTING_DEPTH = 3; // Лимит вложенности (0 = инвентарь, 1 = первый рюкзак, 2 = второй, 3 = третий (макс))
        private const int POCKET_COLUMNS = 2;
        private const int POCKET_ROWS = 2;
        private const int BACKPACK_BASE_COLS = 8;
        private const int BACKPACK_BASE_ROWS = 10;

        private const int POOL_PREWARM_COUNT = 100;
        private const float UI_REFRESH_THROTTLE = 0.3f;
        private const float DROP_FALLBACK_DELAY = 0.05f;

        private const float WEIGHT_WARNING_RATIO = 0.9f;
        private const float WEIGHT_CRITICAL_RATIO = 1.1f;
    private const string SURROUNDINGS_TOP_LINE_NAME   = "TopLine";
private const string SURROUNDINGS_HEADER_NAME     = "SurroundingsHeader";
private const string SURROUNDINGS_TITLE_NAME      = "Title";
private const string SURROUNDINGS_BOTTOM_LINE_NAME= "BottomLine";
private const string SURROUNDINGS_BORDER_TOP_NAME   = "SurroundingsBorderTop";
private const string SURROUNDINGS_BORDER_BOTTOM_NAME= "SurroundingsBorderBottom";
private const string SURROUNDINGS_BORDER_LEFT_NAME  = "SurroundingsBorderLeft";
private const string SURROUNDINGS_BORDER_RIGHT_NAME = "SurroundingsBorderRight";

        #endregion

        #region Fields

        // ═══ ВЕС ИГРОКА ═══
[SerializeField, Tooltip("Внешняя система веса/перегруза (K_WeightManager). Если null — найдётся автоматически.")]
private K_WeightManager _weightManager;

private K_WeightManager _cachedWeightManager;
private Action<K_EquipmentSlotUI, InventoryItem, InventoryItem> _onEquipmentChangedHandler;
       
// ═══ ЭТАП 3: Сервис сбора медикаментов инвентаря игрока ═══
[Header("Medical")]
[SerializeField, Tooltip("База медицинских предметов. Если null — берётся MedicalDatabase.Instance.")]
private MedicalDatabase _medicalDatabase;

[SerializeField, Tooltip("Зеркало медикаментов (вкладка «Здоровье»). " +
    "Источник K_MedicalApplyService для ПКМ-применения.")]
private K_MedicalMirrorPanel _medicalMirrorPanel;
private bool _medicalMirrorPanelSearched;

private MedicalInventoryService _medicalInventoryService;
        private BackpackStateManager _backpackStateManager;
        private BackpackContainerManager _backpackManager;
        private LootSessionController _lootSession;
        private WorldLootSession _groundLoot;
        private GroundLootPanelView _groundLootView;
        private int _groundCanvasSibling = -1;
        private InventorySaveSync _saveSync;
        private bool _isExecutingRefresh = false;
        private bool _isReturningAllItemsToPool = false;

        private InventoryGridBuilder _gridBuilder;
        private InventoryUISync _uiSync;


        public bool IsReturningAllItemsToPool => _uiSync?.IsReturningAllItemsToPool ?? false;

        private InventoryController _pocketsController;
        private InventoryController _pocket2Controller;
        private InventoryController _backpackController;
        private CanvasGroup _canvasGroup;

        [SerializeField] private K_PlayerMotor _playerMotor;

        private bool _isOpen;
        // _isLootingContainer перенесён в LootSessionController (Задача 5D).
        // Все чтения идут через свойство IsLooting ниже; все записи — через _lootSession.
        private bool _pendingRefresh;
        private float _lastRefreshTime;

        private bool _isDragging;
      
        private InventoryItem _loadedBackpackItem;
        private bool _isUpdatingBackpackProjection;
        private bool _backpackEquipped;
        private UI_Item _draggedItem;

        // ═══════════════════════════════════════════════════════════════
        // DRAG PRESENTATION (Задача 5F):
        // Поля ghost/outline/hover/raycast ПЕРЕНЕСЕНЫ в DragGhostPresenter и
        // DragHighlightController. K_InventoryUI хранит только ссылки на
        // контроллеры и публичные доступы к состоянию drag-сессии.
        // ═══════════════════════════════════════════════════════════════
        private DragHighlightController _highlightController;
        private DragGhostPresenter _ghostPresenter;

        private Transform _rootCanvasTransform;
        private UnityEngine.Camera _rootCanvasCamera;

      
        private readonly Queue<GameObject> _borderHiderPool = new Queue<GameObject>();
        private readonly List<GameObject> _activeBorderHiders = new List<GameObject>();

             private K_EquipmentSlotUI _draggedFromEquipmentSlot;
        private InventoryItem _draggedFromSlotItem;
       
        private int _activeTab = 0; 
        private GameObject _tabBar;
        private UnityEngine.UI.Button _tabBtnInventory;
        private UnityEngine.UI.Button _tabBtnHealth;
      
        private float _draggedFromSlotIconRotation = 0f;

        private GridType _dragOriginGridType;
        private int _dragOriginX, _dragOriginY;
        private int _dragOriginRotationAngle;
        private bool _dragOriginFolded;  
        private bool _dragItemRemoved;

       

        private Vector2 _pocketsGridPadding = Vector2.zero;
        private Vector2 _pocket2GridPadding = Vector2.zero;
        private Vector2 _backpackGridPadding = Vector2.zero;
        private Vector2 _containerGridPadding = Vector2.zero;

        private Coroutine _equipDragCleanupCoroutine;

      
        private int _currentBackpackCols = BACKPACK_BASE_COLS;
        private int _currentBackpackRows = BACKPACK_BASE_ROWS;

      
        private int _currentContainerCols;
        private int _currentContainerRows;

      
        private InventoryController _dropTargetController;
        public void SetDropTargetController(InventoryController c) { _dropTargetController = c; }

    
        private Action _onInventoryChangedHandler;
        private Action<float> _onWeightChangedHandler;
        private Action<InventoryItem, int, int> _onItemPlacedHandler;
        private Action<InventoryItem> _onItemChangedHandler;

        private Coroutine _refreshCoroutine;


        public static event Action<InventoryController> OnContainerClosed;
/// <summary>
/// Этап 5: событие обновления инвентаря. Вызывается в начале ForceRefresh().
/// Используется внешними UI-панелями (например, K_MedicalMirrorPanel),
/// которым нужно знать, что MedicalInventoryService сбросил кеш.
/// </summary>
public event Action OnInventoryRefreshed;
        #endregion

        #region Properties

        public bool HasEquippedBackpack => _backpackSlot != null &&
            _backpackSlot.EquippedItem?.Data?.IsBackpack == true;

        /// <summary>Only the fully loaded owner may publish the equipped grid as its contents.</summary>
        public InventoryController GetEquippedBackpackProjection(InventoryItem owner)
        {
            if (owner == null || !_backpackEquipped || _isUpdatingBackpackProjection ||
                (_backpackStateManager?.IsUpdatingEquippedContents ?? false) ||
                !ReferenceEquals(_loadedBackpackItem, owner) ||
                !ReferenceEquals(_backpackSlot?.EquippedItem, owner) ||
                _backpackController == null || _backpackController.IsDisposed) return null;
            return _backpackController;
        }

        public bool IsGroundLootOpen => _groundLoot != null;
        public IReadOnlyList<InventoryItem> GroundLootItems => _groundLoot?.Items ?? Array.Empty<InventoryItem>();
        public bool IsGroundLootController(InventoryController controller) =>
            _groundLoot != null && ReferenceEquals(_groundLoot.Controller, controller);
        public bool IsGroundLootItem(InventoryItem item) => item != null && _groundLoot != null &&
            ReferenceEquals(_groundLoot.Controller.GetItemByInstanceID(item.InstanceID), item);

        public bool CanEquipGroundLootItem(InventoryItem item)
        {
            if (!IsGroundLootItem(item)) return true;
            foreach (var slot in new[] { _primarySlot1, _primarySlot2, _pistolSlot, _meleeSlot,
                _backpackSlot, _armorSlot, _headgearSlot })
                if (slot != null && !slot.IsOccupied && slot.ValidateItemForSlot(item)) return true;
            return false;
        }

        /// <summary>Публичный доступ к dragged UI_Item для InventoryUISync.</summary>
        public UI_Item DraggedUIItem => _draggedItem;

        /// <summary>Обнуляет _draggedItem после FinishDragAndPool.</summary>
        public void ClearDraggedItem()
        {
            _isDragging = false;
            _draggedItem = null;
        }
        /// <summary>Обновляет визуал всех слотов экипировки (силуэты/иконки).</summary>
          /// <summary>Обновляет визуал всех слотов экипировки (силуэты/иконки).</summary>
        public void RefreshEquipmentSlots()
        {
#if UNITY_EDITOR
            Debug.Log($"[SLOT-DIAG] RefreshEquipmentSlots called. " +
                      $"melee={_meleeSlot?.gameObject.GetInstanceID()} " +
                      $"armor={_armorSlot?.gameObject.GetInstanceID()} " +
                      $"headgear={_headgearSlot?.gameObject.GetInstanceID()} " +
                      $"armor==melee: {_armorSlot == _meleeSlot} " +
                      $"headgear==melee: {_headgearSlot == _meleeSlot} " +
                      $"armor==headgear: {_armorSlot == _headgearSlot}");
#endif

            _primarySlot1?.Refresh();
            _primarySlot2?.Refresh();
            _pistolSlot?.Refresh();
            _meleeSlot?.Refresh();
            _backpackSlot?.Refresh();
            _armorSlot?.Refresh();
            _headgearSlot?.Refresh();
        }

public K_EquipmentSlotUI GetEquipmentSlotByType(EquipmentSlotType type)
{
    return type switch
    {
        EquipmentSlotType.Primary => _primarySlot1 ?? _primarySlot2,
        EquipmentSlotType.Pistol => _pistolSlot,
        EquipmentSlotType.Melee => _meleeSlot,
        EquipmentSlotType.Backpack => _backpackSlot,
        EquipmentSlotType.BodyArmor => _armorSlot,
        EquipmentSlotType.HeadGear => _headgearSlot,
        _ => null
    };
}
        private Transform GetGridTransform(GridType type) => type switch
        {
            GridType.Pockets => _pocketsGrid,
            GridType.Pocket2 => _pocket2Grid,
            GridType.Backpack => _backpackGrid,
            GridType.Container => _surroundingsGrid,
            _ => null
        };
        public bool IsOpen => _isOpen;
        public bool IsLooting => _lootSession?.IsLooting ?? false;
        public bool IsDragging => _isDragging;
        public float SlotSize => _slotSize;
        public float SlotSpacing => _slotSpacing;
        public GameObject SlotPrefab => _slotPrefab;

        internal void GetContainerWindowHeaderStyle(out float height, out Color fill,
            out Color border, out float thickness)
        {
            height = _containerHeaderPrefab != null ? _containerHeaderHeight : 32f;
            fill = K_ResponsiveCanvasLayout.ResolveLineColor(_inventoryContentPane != null
                ? _inventoryContentPane.transform : _rootCanvasTransform);
            border = fill;
            thickness = _containerWindowBorderThickness;
        }

             public bool IsDraggingFromEquipmentSlot => _draggedFromEquipmentSlot != null && _draggedFromSlotItem != null;
        public InventoryItem DraggedFromSlotItem => _draggedFromSlotItem;

        /// <summary>
        /// Задача 1 (swap-обводка): read-only доступ к ИСХОДНОМУ слоту экипировки,
        /// из которого начат drag. Нужен DragHighlightController.DrawVisualSwapOutline
        /// для проверки ValidateItemForSlot(target) — паритет highlight↔transaction.
        /// Возвращает null, если drag начат не из слота экипировки.
        /// </summary>
        public K_EquipmentSlotUI DraggedFromEquipmentSlot => _draggedFromEquipmentSlot;

        /// <summary>Read-only доступ к контроллерам игрока для InventorySaveSync и LootSessionController.</summary>
        public InventoryController BackpackController => _backpackController;
        public InventoryController PocketsController => _pocketsController;
        public InventoryController Pocket2Controller => _pocket2Controller;
        public K_EquipmentSlotUI BackpackEquipmentSlot => _backpackSlot;
        public BackpackContainerManager BackpackManager => _backpackManager;
        public LootSessionController LootSession => _lootSession;
  
        /// <summary>
/// Сервис сбора медицинских предметов инвентаря игрока (Этап 3).
/// Используется будущим UI-зеркалом (Этап 5).
/// </summary>
public MedicalInventoryService MedicalInventoryService => _medicalInventoryService;

// Stage 4: cached in Start, also available while the health tab is inactive.
public K_HealthSystem AppliedHealth { get; private set; }
public K_MedicalMirrorPanel MedicalMirrorPanel => _medicalMirrorPanel;

/// <summary>
/// Этап 6.6: сервис применения медикаментов. Lazy-резолв панели зеркала,
/// включая неактивные объекты (health-таб отключён по умолчанию).
/// </summary>
public K_MedicalApplyService MedicalApplyService
{
    get
    {
        // Stage 4: scene lookup is performed only in Start.
        return _medicalMirrorPanel != null ? _medicalMirrorPanel.ApplyService : null;
    }
}
        // ═══════════════════════════════════════════════════════════════
        //  ДОСТУПЫ ДЛЯ DragHighlightController / DragGhostPresenter (Задача 5F)
        // ═══════════════════════════════════════════════════════════════
        public Transform RootCanvasTransform => _rootCanvasTransform;
        public UnityEngine.Camera RootCanvasCamera => _rootCanvasCamera;
        public Transform PocketsGrid => _pocketsGrid;
        public Transform Pocket2Grid => _pocket2Grid;
        public Transform BackpackGrid => _backpackGrid;
        public bool DragItemRemoved => _dragItemRemoved;
        public int DragOriginX => _dragOriginX;
        public int DragOriginY => _dragOriginY;
        public GridType DragOriginGridType => _dragOriginGridType;
         public IReadOnlyDictionary<string, UI_Item> ActiveItemsView => _uiSync?.ActiveItems;        public DragHighlightController HighlightController => _highlightController;
        public DragGhostPresenter GhostPresenter => _ghostPresenter;
        public void CleanupWindowItems(string backpackInstanceId) => _uiSync?.CleanupWindowItems(backpackInstanceId);

        #endregion

        #region Unity Lifecycle

        private void OnValidate()
        {
            if (_weightTextGradient == null)
                _weightTextGradient = CreateDefaultWeightGradient();
        }

        private void Awake()
{
    _rootCanvasTransform = FindRootCanvas();
    K_ResponsiveCanvasLayout.Ensure(_rootCanvasTransform as RectTransform,
        _inventoryContentPane != null ? _inventoryContentPane.transform as RectTransform : null,
        _inventoryBackground != null ? _inventoryBackground.transform as RectTransform : null);
    _canvasGroup = GetComponent<CanvasGroup>();
    if (_canvasGroup == null) _canvasGroup = gameObject.AddComponent<CanvasGroup>();
    InitializeCanvasState();
    if (_weightTextGradient == null)
        _weightTextGradient = CreateDefaultWeightGradient();

    // UI-STYLE: Inspector is the authoritative palette source.

    // ═══ МУЛЬТИОКОННАЯ СИСТЕМА: сохраняем оригинальные ссылки ═══
    _originalSurroundingsPanel = _surroundingsPanel;
    _originalSurroundingsGrid = _surroundingsGrid;
    _originalSurroundingsItemsContainer = _surroundingsItemsContainer;

    // Если floatingWindowsRoot не задан — создаём автоматически
    if (_floatingWindowsRoot == null && _originalSurroundingsPanel != null)
    {
        var rootObj = new GameObject("FloatingWindowsRoot", typeof(RectTransform));
        rootObj.transform.SetParent(_originalSurroundingsPanel.transform.parent, false);
        rootObj.transform.SetAsLastSibling();
        var rootRT = rootObj.GetComponent<RectTransform>();
        rootRT.anchorMin = Vector2.zero;
        rootRT.anchorMax = Vector2.one;
        rootRT.pivot = new Vector2(0.5f, 0.5f);
        rootRT.sizeDelta = Vector2.zero;
        rootRT.localScale = Vector3.one;
        _floatingWindowsRoot = rootObj.transform;
        Debug.Log("[MULTI-WIN] Auto-created FloatingWindowsRoot");
    }

    if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
    if (_backpackPanel != null) _backpackPanel.SetActive(false);
    if (_inventoryBackground != null) _inventoryBackground.SetActive(false);
    EnsureTabBar();
    EnsureTabButtonsStyled();
    if (_tabBar != null) _tabBar.SetActive(false);
    if (_healthContentPane != null) _healthContentPane.SetActive(false);
    if (_inventoryContentPane != null) _inventoryContentPane.SetActive(false);

    _rootCanvasTransform = FindRootCanvas();

    // ═══════════════════════════════════════════════════════════════
    //  ШАГ 4: Создание GridBuilder и UISync (замена старого пула)
    // ═══════════════════════════════════════════════════════════════
    _gridBuilder = new InventoryGridBuilder(
        this, _slotSize, _slotSpacing, _slotPrefab,
        _gridBottomBorderColor, _gridBottomBorderHeight, _gridBottomBorderOffset);

    _uiSync = new InventoryUISync(
        this, _slotSize, _slotSpacing, _occupiedCellTint,
        _hideBordersUnderItems, _borderHiderColor, _borderHiderThickness,
        _bhInsetTop, _bhInsetBottom, _bhInsetLeft, _bhInsetRight,
        _uiItemPrefab, POOL_PREWARM_COUNT);

    _uiSync.Initialize(
        this, _gridBuilder,
        _pocketsGrid, _pocket2Grid, _backpackGrid, _surroundingsGrid,
        _pocketsItemsContainer, _pocket2ItemsContainer,
        _backpackItemsContainer, _surroundingsItemsContainer);

    _uiSync.PreWarmPool();

    // ═══ ШАГ 5A: BackpackContainerManager ═══
    _backpackManager = new BackpackContainerManager(
        _slotPrefab, _slotSize, _slotSpacing,
        _containerHeaderColor, _containerHeaderHeight, _containerHeaderPrefab,
        _containerWindowFillColor, _containerWindowBorderColor, _containerWindowBorderThickness);

    // ═══ ШАГ 5D: LootSessionController (лут-режим внешних контейнеров) ═══
    _lootSession = new LootSessionController();
    _lootSession.Initialize(this, _backpackManager);

    // ═══ ШАГ 5E: InventorySaveSync (синхронизация перед Save) ═══
    _saveSync = new InventorySaveSync();
    _saveSync.Initialize(this, _backpackManager);

    // ═══ ШАГ 5F: Drag presentation (подсветка + ghost) ═══
    _highlightController = new DragHighlightController();
    _ghostPresenter = new DragGhostPresenter();
    _ghostPresenter.Initialize(this, _highlightController);
    _highlightController.Initialize(
        this, _backpackManager, _ghostPresenter,
        _dragOutlineValidColor, _dragOutlineInvalidColor,
        _dragOutlineSwapColor, _dragOutlineThickness);
    _ghostPresenter.CreateGhost(_dragGhostPrefab);

    _backpackManager.Initialize(
        this,
        _floatingWindowsRoot,
        _originalSurroundingsPanel?.transform,
        _originalSurroundingsGrid,
        _originalSurroundingsItemsContainer,
        _backpackPanel,
        _inventoryBackground,
        _containerNameText,
        _pocketsController, _pocket2Controller, _backpackController,
        _backpackSlot,
        ForceRefresh,
        SetCanvasActive,
        SubscribeToContainerEvents,
        UnsubscribeFromContainerEvents,
        SetAllGridSlotsRaycast,
        StyleWindowHeader,
        RestoreLootControllerAfterBackpack,
        () => _groundLoot?.Controller ?? _lootSession.GetLootControllerFromSlots(),
        FindItemByInstanceId,
        () => IsLooting);

    SetupItemsContainerRaycasts();
    SetupBackgroundRaycast();

    // Репарентинг itemsContainer'ов внутрь grid'ов
    _gridBuilder.ReparentItemsContainerIntoGrid(_pocketsGrid, _pocketsItemsContainer);
    _gridBuilder.ReparentItemsContainerIntoGrid(_pocket2Grid, _pocket2ItemsContainer);
    _gridBuilder.ReparentItemsContainerIntoGrid(_backpackGrid, _backpackItemsContainer);

    ProtectItemsContainersFromLayout();

    EnsureContextMenu();

    // ═══ ШАГ 5C: BackpackStateManager ═══
    _backpackStateManager = new BackpackStateManager();
    _backpackStateManager.Initialize(
        _backpackController, _pocketsController, _pocket2Controller, _backpackSlot,
        _backpackManager,
        ForceRefresh,
        ClearGrid,
        RebuildBackpackGrid,
        StopCoroutine,
        TryPlaceInAnyPlayerGrid,
        FindItemLocation,
        FindControllerForItem,
        GetControllerForGrid,
        GetEffectiveGridSize,
        CancelDrag,
        GetEquippedBackpackProjection);
}
 private void Start()
{
    if (!InitializeReferences())
    {
        enabled = false;
        return;
    }

    if (!InventoryTransactionService.Instance.BindInventoryOwner(this))
    {
        enabled = false;
        return;
    }

    // 6.6: резолв зеркала медикаментов (вкладка «Здоровье») — нужен для
    // MedicalApplyService, который дёргается из Update даже когда панель
    // выключена (например, активна вкладка «Инвентарь»).
    if (!_medicalMirrorPanelSearched)
    {
        _medicalMirrorPanel = FindFirstObjectByType<K_MedicalMirrorPanel>(
            FindObjectsInactive.Include);
        _medicalMirrorPanelSearched = true;
    }

    // КОРЕНЬ ФИКС: контроллеры созданы в Start, но BackpackContainerManager
    // получил их как null в Awake. Обновляем сейчас.
    _backpackManager.SetPlayerControllers(_pocketsController, _pocket2Controller, _backpackController);
    AppliedHealth = FindFirstObjectByType<K_HealthSystem>();
    K_AppliedMedicalInventoryBridge.Initialize(this, AppliedHealth);
    
    // ═══ ЭТАП 3: Создаём MedicalInventoryService после инициализации контроллеров.
// _backpackManager к этому моменту уже создан в Awake и получил контроллеры.
// _medicalDatabase берём из сериализованного поля; fallback — MedicalDatabase.Instance.
if (_medicalDatabase == null)
    _medicalDatabase = MedicalDatabase.Instance;
// Stage 4: mechanical menus work before the health tab runs its Start.
AppliedHealth?.AppliedMedical?.ConfigureMedicalDatabase(_medicalDatabase);

_medicalInventoryService = new MedicalInventoryService(
    _pocketsController,
    _pocket2Controller,
    _backpackController,
    _backpackManager,
    _medicalDatabase,
    K_InventorySetup.DatabaseInstance);
    if (_playerMotor == null)
        _playerMotor = FindFirstObjectByType<K_PlayerMotor>();

    _gridBuilder.BuildAllGrids(
        _pocketsGrid, _pocket2Grid, _backpackGrid,
        _pocketsItemsContainer, _pocket2ItemsContainer, _backpackItemsContainer,
        POCKET_COLUMNS, POCKET_ROWS);

    SetupEquipmentSlots();
    EnsureItemsContainersOnTop();
    SubscribeToEvents();

    // ═══ ВЕС: находим менеджер, подписываемся, считаем стартовую сумму ═══
    if (_weightManager == null)
        _weightManager = FindFirstObjectByType<K_WeightManager>();
    _cachedWeightManager = _weightManager;

    if (_cachedWeightManager != null)
        _cachedWeightManager.OnWeightChanged += UpdateWeightDisplay;

    _onEquipmentChangedHandler = OnAnyEquipmentChanged;
    SubscribeToEquipmentSlotEvents();

    _combatContext = FindFirstObjectByType<K_Incident.Core.Combat.K_CombatContext>();
    InitializeCombatIntegration();
    RefreshCombatWeight();

    ForceRefresh();
}
        private void Update()
        {
            DrainQueuedRefresh();
            bool quantityEscape = K_SplitStackDialog.ConsumeEscapeForInventory(this);
            if (IsGroundLootOpen && ((!quantityEscape && Input.GetKeyDown(KeyCode.Escape)) || Input.GetKeyDown(KeyCode.Tab)))
            {
                CloseAll();
                return;
            }
            if (Input.GetKeyDown(_openCloseKey)) ToggleInventory();

            // 6.6: тик apply-сессии. Тикер здесь, а не в панели, потому что
            // панель может быть выключена (вкладка «Инвентарь»), а apply должен
            // продвигаться и при ПКМ-старте из инвентаря.
            MedicalApplyService?.Tick(Time.deltaTime);

            if (_isDragging)
            {
                if (Input.GetKeyDown(_rotateKey))
                    RotateDraggedItem();
            }

            // F сворачивает/разворачивает ТАЩИМЫЙ рюкзак (только во время drag).
            if (_isOpen && _isDragging && Input.GetKeyDown(_foldKey))
                ToggleDraggedBackpackFold();
        }
        private void ProtectItemsContainersFromLayout()
        {
            ProtectFromLayout(_pocketsGrid, _pocketsItemsContainer);
            ProtectFromLayout(_pocket2Grid, _pocket2ItemsContainer);
            ProtectFromLayout(_backpackGrid, _backpackItemsContainer);
            ProtectFromLayout(_surroundingsGrid, _surroundingsItemsContainer);
        }

        private void ProtectFromLayout(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;
            if (itemsContainer.parent == grid)
            {
                var le = itemsContainer.GetComponent<LayoutElement>();
                if (le == null) le = itemsContainer.gameObject.AddComponent<LayoutElement>();
                le.ignoreLayout = true;
                var graphic = itemsContainer.GetComponent<Graphic>();
                if (graphic != null) graphic.raycastTarget = false;
                // itemsContainer должен быть ВЫШЕ слотов для правильного raycast
                itemsContainer.SetAsLastSibling();
            }
        }

        // ═══════════════════════════════════════════════════════════
        //  SAVE-СИНХРОНИЗАЦИЯ (делегирование в InventorySaveSync)
        // ═══════════════════════════════════════════════════════════
        // SyncAllOpenBackpacksForSave / SyncAllBackpacksRecursiveForSave /
        // SyncBackpacksBottomUp перенесены в InventorySaveSync (Задача 5E).
        //
        // Тонкая обёртка ниже — единая точка входа для PlayerEquipmentSaveService.Save().
        // Старые имена методов убраны; вызов из PlayerEquipmentSaveService обновлён
        // на SyncAllBackpacksForSave() (см. PlayerEquipmentSaveService.cs).
        public void SyncAllBackpacksForSave()
        {
            _saveSync?.SyncAllBackpacksForSave();
            SynchronizeGroundLoot(true);
        }

        private void LateUpdate()
        {
            if (_groundLoot == null || IsDragging) return;
            SynchronizeGroundLoot();
        }

        private void SynchronizeGroundLoot(bool flushContents = false)
        {
            if (_groundLoot == null) return;
            var previous = _groundLoot.Controller;
            if (!_groundLoot.Synchronize(flushContents)) return;
            RefreshGroundLootLayout(previous);
        }

        public void RefreshGroundLootItems(IReadOnlyList<K_WorldItem> worlds)
        {
            if (_groundLoot == null || IsDragging) return;
            var previous = _groundLoot.Controller;
            // Retire taken world owners before importing a dropped item with
            // the same ID. Existing live items remain part of the same session.
            bool changed = _groundLoot.Synchronize();
            changed |= _groundLoot.AddWorldItems(worlds);
            if (changed) RefreshGroundLootLayout(previous);
        }

        private void RefreshGroundLootLayout(InventoryController previous)
        {
            bool replaced = !ReferenceEquals(previous, _groundLoot.Controller);
            if (replaced)
            {
                UnsubscribeFromContainerEvents();
                SetActiveContainerController(_groundLoot.Controller);
                SubscribeToContainerEvents();
                if (_draggedItem != null && ReferenceEquals(_draggedItem.BoundController, previous) &&
                    _groundLoot.Controller.TryGetItemPosition(_draggedItem.Item.InstanceID, out int x, out int y))
                {
                    _draggedItem.RebindGridPosition(_groundLoot.Controller, x, y);
                    _dragOriginX = x;
                    _dragOriginY = y;
                    UpdateBackpackManagerDragState();
                }
            }
            if (replaced || _currentContainerRows != _groundLoot.Rows)
            {
                RebuildSurroundingsGrid(WorldLootSession.Columns, _groundLoot.Rows);
                _groundLootView?.Resize();
            }
            ForceRefresh();
        }

        private void RestoreLootControllerAfterBackpack()
        {
            if (_groundLoot == null) { _lootSession.RestoreLootControllerIfLooting(); return; }
            SetActiveContainerController(_groundLoot.Controller);
            SetCurrentContainerDimensions(WorldLootSession.Columns, _groundLoot.Rows);
        }

        private void RotateDraggedItem()
        {
            var item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (K_SplitStackDialog.IsItemLocked(item)) return;
            if (!IsGroundLootItem(item)) { _ghostPresenter?.Rotate(); return; }
            var previous = _groundLoot.Controller;
            if (!_groundLoot.TryRotateItem(item)) return;
            RefreshGroundLootLayout(previous);
            _ghostPresenter?.RefreshGhostAfterFold(item);
            _highlightController?.UpdateCellHighlights();
        }

        private void ToggleDraggedBackpackFold()
        {
            var item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null || !item.CanFold) return;

            bool fold = !item.IsFolded;
            if (!fold && IsAtMaxNestingDepth(item))
            {
                Debug.Log($"[FOLD-F] Cannot unfold '{item.Data?.DisplayName}' — max nesting depth reached!");
                return;
            }
            if (fold)
            {
                SyncBackpackContentsBeforeFold(item);
                if (!IsBackpackContentsEmpty(item))
                {
                    Debug.Log($"[FOLD-F] Cannot fold '{item.Data?.DisplayName}' — not empty!");
                    return;
                }
            }

            bool groundItem = IsGroundLootItem(item);
            if (groundItem && !_groundLoot.CanSetFolded(item, fold)) return;
            if (fold) CloseAllWindowsForBackpack(item);

            if (groundItem)
            {
                // Меняется размер источника drag: перепаковываем проекцию и
                // привязываем drag к новому контроллеру, не прерывая перенос.
                var previous = _groundLoot.Controller;
                if (!_groundLoot.TrySetFolded(item, fold)) return;
                RefreshGroundLootLayout(previous);
            }
            else if (!item.ToggleFold(contentsEmpty: true)) return;

            _ghostPresenter?.RefreshGhostAfterFold(item);
            _highlightController?.UpdateCellHighlights();
        }

        public bool OpenGroundLoot(IReadOnlyList<K_WorldItem> items)
        {
            if (IsOpen || IsLooting || _groundLoot != null || _surroundingsPanel == null ||
                _surroundingsGrid == null || _lootSession == null || K_InventorySetup.DatabaseInstance == null)
                return false;
            _groundLoot = new WorldLootSession(items, K_InventorySetup.DatabaseInstance);
            try
            {
                if (_playerMotor != null)
                    _playerMotor.GetComponent<K_InteractionSystem>()?.CancelForGroundLoot();
                _lootSession.Open(_groundLoot.Controller, "ПОДБОР", WorldLootSession.Columns, _groundLoot.Rows);
                var canvasRect = _rootCanvasTransform as RectTransform;
                float availableHeight = canvasRect != null ? canvasRect.rect.height * .85f : 800f;
                _groundLootView = new GroundLootPanelView(_surroundingsPanel.GetComponent<RectTransform>(),
                    _surroundingsGrid.GetComponent<RectTransform>(), _slotSize, _slotSpacing,
                    _surroundingsHeaderHeight, availableHeight, _surroundingsBorderColor);
                if (_rootCanvasTransform != null)
                {
                    _groundCanvasSibling = _rootCanvasTransform.GetSiblingIndex();
                    _rootCanvasTransform.SetAsLastSibling();
                }
                return true;
            }
            catch
            {
                CloseAll();
                throw;
            }
        }

        private void DisposeGroundLoot()
        {
            _groundLootView?.Dispose();
            _groundLootView = null;
            _groundLoot?.Dispose();
            _groundLoot = null;
            if (_groundCanvasSibling >= 0 && _rootCanvasTransform != null)
                _rootCanvasTransform.SetSiblingIndex(_groundCanvasSibling);
            _groundCanvasSibling = -1;
        }
       private void OnDestroy()
{
    _saveSync?.SyncAllBackpacksForSave();
    _backpackManager?.DisposeForOwnerDestroy();
    K_SplitStackDialog.ForgetOwner(this);
    _highlightController?.Dispose();
    UI_Item.ResetMissingFoldIconDiagnostics();
    DisposeCombatIntegration();
    UnsubscribeFromEvents();
    UnsubscribeFromContainerEvents();
    UnsubscribeFromEquipmentSlotEvents();
    DisposeGroundLoot();

    if (_cachedWeightManager != null)
        _cachedWeightManager.OnWeightChanged -= UpdateWeightDisplay;

    _uiSync?.ClearPooledItems();
    _uiSync?.StopTextRebuildCoroutine();
    _ghostPresenter?.DestroyGhost();
}
        #endregion

        #region Initialization

        private Transform FindRootCanvas()
        {
            // UI_Inventory is a separate scene root. Its serialized inventory
            // pane, rather than an arbitrary scene Canvas, owns this UI.
            Canvas owner = _inventoryContentPane != null ? _inventoryContentPane.GetComponentInParent<Canvas>() : null;
            if (owner == null && _inventoryBackground != null) owner = _inventoryBackground.GetComponentInParent<Canvas>();
            if (owner == null && _pocketsGrid != null) owner = _pocketsGrid.GetComponentInParent<Canvas>();
            if (owner == null) owner = GetComponentInParent<Canvas>();
            if (owner == null) { _rootCanvasCamera = null; return null; }
            owner = owner.rootCanvas;
            _rootCanvasCamera = owner.renderMode == RenderMode.ScreenSpaceOverlay ? null : owner.worldCamera;
            return owner.transform;
        }

        public void RecycleBorderHidersBeforeGridDestroy(Transform grid)
            => _uiSync?.PoolBorderHidersBeforeGridDestroy(grid);

        public Transform GetItemsContainerForGrid(GridType type) => type switch
        {
            GridType.Pockets => _pocketsItemsContainer,
            GridType.Pocket2 => _pocket2ItemsContainer,
            GridType.Backpack => _backpackItemsContainer,
            GridType.Container => _surroundingsItemsContainer,
            _ => null
        };

        private void InitializeCanvasState()
        {
            _canvasGroup.alpha = 0f;
            _canvasGroup.interactable = false;
            _canvasGroup.blocksRaycasts = false;
        }

        private void SetupItemsContainerRaycasts()
        {
            var containers = new[] { _pocketsItemsContainer, _pocket2ItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                // Отключаем raycast на самом контейнере (чтобы он не блокировал предметы)
                var graphic = container.GetComponent<Graphic>();
                if (graphic != null) graphic.raycastTarget = false;
                // ФИКС MissingComponentException: CanvasGroup ДОЛЖЕН быть на каждом контейнере.
                var cg = container.GetComponent<CanvasGroup>();
                if (cg == null)
                    cg = container.gameObject.AddComponent<CanvasGroup>();
                cg.blocksRaycasts = true;
                cg.interactable = true;
                cg.alpha = 1f;
            }
        }

        private void SetupBackgroundRaycast()
        {
            if (_inventoryBackground != null)
            {
                var bgGraphic = _inventoryBackground.GetComponent<Graphic>();
                if (bgGraphic != null) bgGraphic.raycastTarget = false;
            }
        }

        private bool InitializeReferences()
        {
            if (_inventorySetup == null)
                _inventorySetup = FindFirstObjectByType<K_InventorySetup>();

            _pocketsController = _inventorySetup?.PocketsController;
            _pocket2Controller = _inventorySetup?.Pocket2Controller;
            _backpackController = _inventorySetup?.BackpackController;

            if (_pocketsController == null || _pocket2Controller == null || _backpackController == null)
            {
                Debug.LogError("[InventoryUI] Controllers are null! Check K_InventorySetup.");
                return false;
            }
            return true;
        }





        #endregion

        #region Grid Management

        // ═══════════════════════════════════════════════════════════════
        //  ДЕЛЕГАТОРЫ: перенаправление в _gridBuilder и _uiSync
        //  Эти методы сохраняют обратную совместимость — весь остальной
        //  код K_InventoryUI продолжает вызывать их по старым именам.
        // ═══════════════════════════════════════════════════════════════

        private void ClearGrid(Transform parent, Transform preserveChild = null)
        {
            _gridBuilder?.ClearGrid(parent, preserveChild);
        }

        public void DrawGridBottomBorder(Transform grid, int columns, int rows, Vector2 padding)
        {
            _gridBuilder?.DrawGridBottomBorder(grid, columns, rows, padding);
        }

        public Vector2 GetPaddingForGrid(GridType type)
        {
            return _gridBuilder?.GetPaddingForGrid(type) ?? Vector2.zero;
        }

        private void EnsureContainerAboveGrid(Transform grid, Transform itemsContainer)
        {
            _gridBuilder?.EnsureContainerAboveGrid(grid, itemsContainer);
        }

        private void ReturnToPool(UI_Item item)
        {
            _uiSync?.ReturnToPool(item);
        }

        private void ReturnAllItemsToPool()
        {
            _uiSync?.ReturnAllItemsToPool();
        }

        private void FinishDragAndPool(UI_Item ui)
        {
            _uiSync?.FinishDragAndPool(ui);
        }

        private void ReturnAllBorderHidersToPool()
        {
            _uiSync?.ReturnAllBorderHidersToPool();
        }

        public K_InventorySlotUI GetSlotAt(GridType gridType, int x, int y)
        {
            Transform grid = GetGridTransform(gridType);
            if (grid == null) return null;
            return _uiSync?.GetSlotAt(grid, x, y, GetGridWidth(gridType));
        }
        private void EnsureItemsContainersOnTop()
        {
            if (_gridBuilder == null) return;
            _gridBuilder.EnsureContainerAboveGrid(_pocketsGrid, _pocketsItemsContainer);
            _gridBuilder.EnsureContainerAboveGrid(_pocket2Grid, _pocket2ItemsContainer);
            _gridBuilder.EnsureContainerAboveGrid(_backpackGrid, _backpackItemsContainer);
            _gridBuilder.EnsureContainerAboveGrid(_surroundingsGrid, _surroundingsItemsContainer);
            foreach (var window in _backpackManager.OpenWindows)
            {
                if (window == null || window.GridRect == null || window.ItemsContainer == null) continue;
                _gridBuilder.EnsureContainerAboveGrid(window.GridRect, window.ItemsContainer);
            }
        }

          private void SetupEquipmentSlots()
        {
#if UNITY_EDITOR
            Debug.Log($"[SLOT-DIAG] SetupEquipmentSlots refs: " +
                      $"primary1={(_primarySlot1 != null ? _primarySlot1.gameObject.name + "/" + _primarySlot1.gameObject.GetInstanceID() : "null")} " +
                      $"primary2={(_primarySlot2 != null ? _primarySlot2.gameObject.name + "/" + _primarySlot2.gameObject.GetInstanceID() : "null")} " +
                      $"pistol={(_pistolSlot != null ? _pistolSlot.gameObject.name + "/" + _pistolSlot.gameObject.GetInstanceID() : "null")} " +
                      $"melee={(_meleeSlot != null ? _meleeSlot.gameObject.name + "/" + _meleeSlot.gameObject.GetInstanceID() : "null")} " +
                      $"backpack={(_backpackSlot != null ? _backpackSlot.gameObject.name + "/" + _backpackSlot.gameObject.GetInstanceID() : "null")} " +
                      $"armor={(_armorSlot != null ? _armorSlot.gameObject.name + "/" + _armorSlot.gameObject.GetInstanceID() : "null")} " +
                      $"headgear={(_headgearSlot != null ? _headgearSlot.gameObject.name + "/" + _headgearSlot.gameObject.GetInstanceID() : "null")}");
#endif

            _primarySlot1?.Initialize(this, EquipmentSlotType.Primary);
            _primarySlot2?.Initialize(this, EquipmentSlotType.Primary);
            _pistolSlot?.Initialize(this, EquipmentSlotType.Pistol);
            _meleeSlot?.Initialize(this, EquipmentSlotType.Melee);
            _backpackSlot?.Initialize(this, EquipmentSlotType.Backpack);
            _armorSlot?.Initialize(this, EquipmentSlotType.BodyArmor);
            _headgearSlot?.Initialize(this, EquipmentSlotType.HeadGear);
        }

        #endregion
        
        #region UI Control

        public void ToggleInventory()
        {
            if (_isOpen) CloseAll();
            else OpenInventoryOnly();
        }

        private void OpenInventoryOnly()
{
    _isOpen = true;
    SetCanvasActive(true);
    if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);
    if (_backpackPanel != null) _backpackPanel.SetActive(true);
    if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
    if (_tabBar != null) _tabBar.SetActive(true);

    // Спека п.1/п.3.1: любой способ открытия инвентаря — активная вкладка = 0.
    // SwitchTab(0) выставит _activeTab=0 и через ApplyTabState переключит
    // InventoryContentPane/HealthContentPane, синхронизирует LeftPane
    // (SyncBackpackPanelState) и перекрасит кнопки (UpdateTabButtonColors).
    SwitchTab(0);

    SyncBackpackPanelState();
    ForceRefresh();
}

        public void PrepareForLoad()
        {
            K_SplitStackDialog.CancelForInventory(this);
            // Old drag/apply sessions and same-ID backpack windows belong to the
            // current timeline. Dispose them before save data replaces any roots.
            MedicalApplyService?.CancelApply("save-loaded");
            CloseAll();
        }

        public void CloseAll()
        {
            // ФИКС БАГ (audit) #13 / user feedback — duplication when closing inventory during drag:
            // СНАЧАЛА отменяем drag и возвращаем предмет в исходный controller,
            // ЗАТЕМ уничтожаем окна и controllers. Раньше порядок был обратный:
            // DestroyAllContainerWindows + CloseAllOpenedBackpacks сначала,
            // CancelDrag потом — и CancelDrag находил disposed origin controller,
            // предмет оставался «в воздухе», при следующем OnDrop дублировался.
            //
            // Правильный порядок (по аудиту):
            //   1. Block new input
            //   2. Cancel drag and restore exact source
            //   3. Flush nested windows from deepest to root
            //   4. Destroy windows
            //   5. Dispose controllers
            //   6. Close visual UI

            // Закрываем контекстное меню если открыто
            if (K_ContextMenu.Instance != null)
                K_ContextMenu.Instance.Hide();

            // 6.6: отменяем apply-сессию при закрытии инвентаря.
            MedicalApplyService?.CancelApply("inventory-closed");

            // 1. СНАЧАЛА отменяем drag — предмет возвращается в исходный controller.
            CancelDrag();

            // 2. Теперь безопасно закрываем окна и controllers.
            // МУЛЬТИОКОННАЯ СИСТЕМА: закрываем все окна контейнеров
            DestroyAllContainerWindows();

            // ФИКС v2: Закрываем все открытые рюкзаки-контейнеры (с сохранением содержимого)
            CloseAllOpenedBackpacks();

            // ФИКС БАГ #2: Отписываемся от событий контейнера
            UnsubscribeFromContainerEvents();
            _highlightController?.ClearHover();
            DisposeGroundLoot();

            _isOpen = false;
            _lootSession?.ResetLootState();
            SetActiveContainerController(null);

            SetCanvasActive(false);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(true);
            if (_backpackPanel != null) _backpackPanel.SetActive(false);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(false);
            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);

            if (_healthContentPane != null) _healthContentPane.SetActive(false);
            if (_inventoryContentPane != null) _inventoryContentPane.SetActive(false);
            if (_tabBar != null) _tabBar.SetActive(false);

            ReturnAllItemsToPool();
            ReturnAllBorderHidersToPool();
            OnContainerClosed?.Invoke(_pocketsController);
        }

        /// <summary>
        /// Экстренная отмена drag (например, при закрытии инвентаря).
        /// Скрывает ghost (у которого свой Canvas ScreenSpaceOverlay),
        /// возвращает предмет на исходную позицию, очищает все drag-переменные.
        /// Без этого ghost зависает на экране после закрытия инвентаря.
        /// </summary>
  private void CancelDrag()
{
    if (!_isDragging && !_dragItemRemoved) return;

    if (IsDraggingFromEquipmentSlot)
    {
        ClearEquipmentDragState(true);
        return;
    }

    _ghostPresenter?.End();

    var itemToRestore = _draggedItem != null ? _draggedItem.Item : _draggedFromSlotItem;
    if (itemToRestore != null)
    {
        itemToRestore.RestoreRotationState(_dragOriginRotationAngle);
        if (itemToRestore.Data != null && itemToRestore.Data.CanFold
            && itemToRestore.IsFolded != _dragOriginFolded)
            itemToRestore.SetFolded(_dragOriginFolded);
    }

    if (_draggedItem != null && _draggedItem.Item != null && _dragItemRemoved)
    {
        var item = _draggedItem.Item;
        bool alreadyPlaced = false;
        var (foundGrid, _, _) = FindItemLocation(item);
        if (foundGrid != null)
            alreadyPlaced = true;
        if (!alreadyPlaced)
        {
            var controller = (_dragOriginGridType == GridType.Container && _draggedItem.BoundController != null)
                ? _draggedItem.BoundController
                : GetControllerForGrid(_dragOriginGridType);
            if (controller != null)
            {
                bool placed = controller.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
                if (!placed)
                    placed = controller.PlaceExistingItemInFirstFreeSlot(item);
                if (!placed)
                {
                    Debug.LogWarning($"[CANCEL-DRAG] Origin grid '{_dragOriginGridType}' full. " +
                        "Trying all player grids.");
                    placed = TryPlaceInAnyPlayerGrid(item);
                }
                if (!placed)
                    Debug.LogError($"[CANCEL-DRAG] Could not return item '{item.Data?.DisplayName}' " +
                        $"to ANY grid. Item is LOST! InstanceID={item.InstanceID}");
            }
            else
            {
                bool placed = TryPlaceInAnyPlayerGrid(item);
                if (!placed)
                    Debug.LogError($"[CANCEL-DRAG] No controller + no fallback grid. " +
                        $"Item '{item.Data?.DisplayName}' is LOST!");
            }
        }
    }

    if (_refreshCoroutine != null)
    {
        StopCoroutine(_refreshCoroutine);
        _refreshCoroutine = null;
    }
    _pendingRefresh = false;

    var draggedToPool = _draggedItem;
    _isDragging = false;
    _draggedItem = null;
    _draggedFromEquipmentSlot = null;
    _draggedFromSlotItem = null;
    _draggedFromSlotIconRotation = 0f;
    _dragItemRemoved = false;
    _highlightController?.ClearHover();

    if (draggedToPool != null)
        ReturnToPool(draggedToPool);

    _highlightController?.HideAll();
    SetAllGridSlotsRaycast(false);
    UpdateBackpackManagerDragState();
    SynchronizeGroundLoot();
}
        public void OpenContainer(InventoryController containerController, string containerName, int width, int height)
        {
            if (IsGroundLootOpen) return;
            _lootSession?.Open(containerController, containerName, width, height);
        }

        /// <summary>
        /// Визуальная активация панели лута. Вызывается из LootSessionController.Open
        /// после установки loot-состояния. Отвечает за:
        ///   - сброс флагов drag-панели
        ///   - активацию canvas / панелей / вкладок
        ///   - блокировку движения игрока
        ///   - отображение _surroundingsPanel + имени контейнера
        ///   - RebuildSurroundingsGrid + SetupBackgroundRaycast + ForceRefresh
        /// </summary>
 public void BeginLootVisuals(string containerName, int cols, int rows)
{
    _isOpen = true;

    SetCanvasActive(true);
    if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);

    if (_backpackPanel != null) _backpackPanel.SetActive(true);
    if (_inventoryBackground != null) _inventoryBackground.SetActive(true);

    // Спека п.2: во время E-лута tab bar ДОЛЖЕН быть активен и кликабелен.
    if (_tabBar != null) _tabBar.SetActive(true);

    // Спека п.1/п.3.2: при E-луте активная вкладка = 0 (Снаряжение).
    // SwitchTab(0) активирует InventoryContentPane, чем делает видимой
    // _surroundingsPanel (её дочерний объект), а также сбрасывает _activeTab
    // и перекрашивает кнопки.
    SwitchTab(0);

    if (_surroundingsPanel == null)
    {
        SetupBackgroundRaycast();
        ForceRefresh();
        return;
    }

    _surroundingsPanel.SetActive(true);

    var panelRect = _surroundingsPanel.GetComponent<RectTransform>();
    var gridRect  = _surroundingsGrid != null ? _surroundingsGrid.GetComponent<RectTransform>() : null;

    if (panelRect == null)
    {
        SetupBackgroundRaycast();
        ForceRefresh();
        return;
    }

    // ═══ ШАГ 1: нормализация anchor/pivot панели.
    panelRect.anchorMin = new Vector2(0f, 1f);
    panelRect.anchorMax = new Vector2(0f, 1f);
    panelRect.pivot     = new Vector2(0f, 1f);

    // ═══ ШАГ 2: захват TL СЕТКИ — инвариант, который НЕ должен меняться.
    Vector3 savedGridTopLeftWorld = Vector3.zero;
    bool hasSavedGridTL = false;
    if (gridRect != null)
    {
        Vector3[] gc = new Vector3[4];
        gridRect.GetWorldCorners(gc);
        savedGridTopLeftWorld = gc[1];
        hasSavedGridTL = true;
    }

#if UNITY_EDITOR
    AuditPanelAndGrid("BEFORE-rebuild", containerName, cols, rows);
#endif

    if (_containerNameText != null)
    {
        _containerNameText.text = containerName;
        _containerNameText.raycastTarget = false;
    }

    // ═══ ШАГ 3: rebuild + header.
    RebuildSurroundingsGrid(cols, rows);
    EnsureSurroundingsHeader(containerName);

#if UNITY_EDITOR
    AuditPanelAndGrid("AFTER-EnsureHeader", containerName, cols, rows);
#endif

    // ═══ ШАГ 4: восстановление TL СЕТКИ.
    if (hasSavedGridTL && gridRect != null)
    {
        Vector3 currentGridTL = gridRect.position;
        Vector3 delta = savedGridTopLeftWorld - currentGridTL;
        panelRect.position += delta;
    }

#if UNITY_EDITOR
    AuditPanelAndGrid("AFTER-restore", containerName, cols, rows);
#endif

    SetupBackgroundRaycast();
    ForceRefresh();

#if UNITY_EDITOR
    AuditPanelAndGrid("AfterSetRaycastTrue", containerName, cols, rows);
#endif
}

private void EnsureSurroundingsHeader(string containerName)
{
    if (_surroundingsPanel == null) return;
    var panelRect = _surroundingsPanel.GetComponent<RectTransform>();
    if (panelRect == null) return;

    // Older scenes keep a separate drag strip. Preserve its hit area and layout,
    // but give it the same palette as the visible surroundings header.
    var legacyDragZone = panelRect.Find("DragZone");
    var legacyBackground = legacyDragZone != null ? legacyDragZone.GetComponent<Image>() : null;
    if (legacyBackground != null)
        legacyBackground.color = K_ResponsiveCanvasLayout.ResolveLineColor(panelRect);

    // a) Найти или создать шапку.
    Transform headerTr = _surroundingsPanel.transform.Find(SURROUNDINGS_HEADER_NAME);
    RectTransform headerRect;
    if (headerTr == null)
    {
        var headerGo = new GameObject(SURROUNDINGS_HEADER_NAME, typeof(RectTransform));
        headerGo.transform.SetParent(_surroundingsPanel.transform, false);
        headerRect = headerGo.GetComponent<RectTransform>();
    }
    else
    {
        headerRect = headerTr as RectTransform;
    }
    if (headerRect == null) return;

    // a1) Удалить легаси-дочерние элементы прошлых итераций.
    CleanupLegacyHeaderChildren(headerRect);

    // a2) Обязательные дети: Title + BottomLine.
    EnsureHeaderChildTitle(headerRect);
    EnsureHeaderChildBottomLine(headerRect);

    // b) Геометрия шапки.
    headerRect.anchorMin = new Vector2(0f, 1f);
    headerRect.anchorMax = new Vector2(1f, 1f);
    headerRect.pivot     = new Vector2(0.5f, 1f);
    headerRect.anchoredPosition = Vector2.zero;
    headerRect.sizeDelta = new Vector2(0f, _surroundingsHeaderHeight);
    headerRect.localScale = Vector3.one;

    // c) Шапка — последний ребёнок панели на данном этапе.
    headerRect.SetAsLastSibling();

    // d) Стиль/текст.
    ApplySurroundingsHeaderStyle(headerRect, containerName);

    // e) Единая заливка панели.
    EnsureSurroundingsPanelBackground(panelRect);

    // f) Панель + сетка.
    //    ПОРЯДОК (требование ТЗ п.2):
    //      1) grid.anchorMin/Max/pivot = (0,1)
    //      2) grid.anchoredPosition / sizeDelta
    //      3) panel.anchorMin/Max/pivot = (0,1)
    //      4) panel.sizeDelta
    //    Позиция панели (anchoredPosition) здесь НЕ трогается —
    //    top-left восстанавливает внешний BeginLootVisuals.
    if (_surroundingsGrid != null)
    {
        var gridRect = _surroundingsGrid.GetComponent<RectTransform>();
        if (gridRect != null)
        {
            // 1) Сначала anchor/pivot сетки.
            gridRect.anchorMin = new Vector2(0f, 1f);
            gridRect.anchorMax = new Vector2(0f, 1f);
            gridRect.pivot     = new Vector2(0f, 1f);
            gridRect.localScale = Vector3.one;

            // 2) Позиция сетки относительно панели — под шапкой.
            gridRect.anchoredPosition = new Vector2(0f, -_surroundingsHeaderHeight);

            // 3) Anchor/pivot панели — ДО sizeDelta.
            panelRect.anchorMin = new Vector2(0f, 1f);
            panelRect.anchorMax = new Vector2(0f, 1f);
            panelRect.pivot     = new Vector2(0f, 1f);

            // 4) SizeDelta панели = grid + header.
            float gridW = gridRect.sizeDelta.x;
            float gridH = gridRect.sizeDelta.y;
            panelRect.sizeDelta = new Vector2(gridW, gridH + _surroundingsHeaderHeight);
        }
    }

    // g) Бордер по периметру: 4 стрипа.
    EnsureSurroundingsPanelBorder(panelRect);

    // g2) ItemsContainer не должен перекрывать верхнюю область панели.
    EnsureSurroundingsItemsContainerBelowGrid();
}
private void EnsureSurroundingsItemsContainerBelowGrid()
{
    if (_surroundingsItemsContainer == null) return;

    // Если уже внутри grid — ничего не делаем.
    if (_surroundingsGrid != null && _surroundingsItemsContainer.parent == _surroundingsGrid)
        return;

    // Если parented на panel — репарентим в grid.
    if (_surroundingsGrid != null && _surroundingsItemsContainer.parent == _surroundingsPanel.transform)
    {
        _surroundingsItemsContainer.SetParent(_surroundingsGrid, false);
        var rt = _surroundingsItemsContainer.GetComponent<RectTransform>();
        if (rt != null)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }
    }
}

private void EnsureHeaderChildTitle(RectTransform headerRect)
{
    if (headerRect == null) return;
    if (headerRect.Find(SURROUNDINGS_TITLE_NAME) != null) return;

    var go = new GameObject(SURROUNDINGS_TITLE_NAME, typeof(RectTransform), typeof(TextMeshProUGUI));
    go.transform.SetParent(headerRect, false);
    var rt = go.GetComponent<RectTransform>();
    rt.anchorMin = Vector2.zero;
    rt.anchorMax = Vector2.one;
    rt.pivot     = new Vector2(0.5f, 0.5f);
    rt.offsetMin = new Vector2(8f, 0f);
    rt.offsetMax = new Vector2(-8f, 0f);
    rt.localScale = Vector3.one;

    var tmp = go.GetComponent<TextMeshProUGUI>();
    ApplyTitleTmpStyle(tmp);
}

/// <summary>
/// Find-or-create нижней границы шапки (1px #9F9F9F α255) — разделитель шапки/сетки.
/// Идемпотентно.
/// </summary>
 
// ═══════════════════════════════════════════════════════════════
//  RunSurroundingsAuditOnce — ПОЛНАЯ ЗАМЕНА
//  Добавлен вывод _surroundingsTopBorderThickness.
// ═══════════════════════════════════════════════════════════════






private void EnsureHeaderChildBottomLine(RectTransform headerRect)
{
    if (headerRect == null) return;

    Transform existing = headerRect.Find(SURROUNDINGS_BOTTOM_LINE_NAME);
    RectTransform rt;
    Image img;

    if (existing == null)
    {
        var go = new GameObject(SURROUNDINGS_BOTTOM_LINE_NAME, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(headerRect, false);
        rt  = go.GetComponent<RectTransform>();
        img = go.GetComponent<Image>();
        img.sprite = null;
        img.type   = Image.Type.Simple;
        img.maskable = true;
    }
    else
    {
        rt  = existing as RectTransform;
        img = existing.GetComponent<Image>();
        if (img == null) img = existing.gameObject.AddComponent<Image>();
    }

    if (rt == null || img == null) return;

    rt.anchorMin = new Vector2(0f, 0f);
    rt.anchorMax = new Vector2(1f, 0f);
    rt.pivot     = new Vector2(0.5f, 0f);
    rt.anchoredPosition = Vector2.zero;
    rt.sizeDelta = new Vector2(0f, Mathf.Max(1f, _surroundingsBorderThickness));
    rt.localScale = Vector3.one;

    img.color = K_ResponsiveCanvasLayout.ResolveLineColor(headerRect);
    img.raycastTarget = false;

    // Последний сиблинг ВНУТРИ шапки — поверх Title.
    rt.SetAsLastSibling();
}

// ═══════════════════════════════════════════════════════════════
//  ApplySurroundingsHeaderStyle — ПОЛНАЯ ЗАМЕНА
// ═══════════════════════════════════════════════════════════════
private void ApplySurroundingsHeaderStyle(RectTransform headerRect, string containerName)
{
    if (headerRect == null) return;
    Color lineColor = K_ResponsiveCanvasLayout.ResolveLineColor(headerRect);
    var background = headerRect.GetComponent<Image>();
    if (background == null)
    {
        background = headerRect.gameObject.AddComponent<Image>();
        background.raycastTarget = false;
    }
    background.sprite = null;
    background.type = Image.Type.Simple;
    background.color = lineColor;

    // Title
    var titleTr = headerRect.Find(SURROUNDINGS_TITLE_NAME);
    if (titleTr != null)
    {
        var titleRect = titleTr as RectTransform;
        if (titleRect != null)
        {
            titleRect.anchorMin = Vector2.zero;
            titleRect.anchorMax = Vector2.one;
            titleRect.pivot     = new Vector2(0.5f, 0.5f);
            titleRect.offsetMin = new Vector2(8f, 0f);
            titleRect.offsetMax = new Vector2(-8f, 0f);
        }
        var titleTmp = titleTr.GetComponent<TextMeshProUGUI>();
        if (titleTmp != null)
        {
            ApplyTitleTmpStyle(titleTmp);
            titleTmp.text = containerName ?? string.Empty;
        }
    }

    // BottomLine — разделитель шапки и сетки.
    // TopLine больше НЕ трогаем: верхняя кромка панели —
    // отдельный бордер-стрип на панели.
    var bottomLineTr = headerRect.Find(SURROUNDINGS_BOTTOM_LINE_NAME);
    if (bottomLineTr != null)
    {
        var bottomLineRect = bottomLineTr as RectTransform;
        if (bottomLineRect != null)
        {
            bottomLineRect.anchorMin = new Vector2(0f, 0f);
            bottomLineRect.anchorMax = new Vector2(1f, 0f);
            bottomLineRect.pivot     = new Vector2(0.5f, 0f);
            bottomLineRect.anchoredPosition = Vector2.zero;
            bottomLineRect.sizeDelta = new Vector2(0f, _surroundingsBorderThickness);
        }
        var bottomLineImg = bottomLineTr.GetComponent<Image>();
        if (bottomLineImg != null)
        {
            bottomLineImg.color = lineColor;
            bottomLineImg.raycastTarget = false;
        }
        // Разделитель шапки — поверх Title внутри шапки.
        bottomLineTr.SetAsLastSibling();
    }
}
private static void ApplyTitleTmpStyle(TMPro.TextMeshProUGUI tmp)
{
    if (tmp == null) return;
    K_ContainerWindow.ApplyHeaderTitleStyle(tmp);
    if (tmp.font == null && TMP_Settings.defaultFontAsset != null)
        tmp.font = TMP_Settings.defaultFontAsset;
}

/// <summary>
/// Идемпотентно обеспечивает единую заливку _surroundingsPanel:
///   - если у панели уже есть Image — перекрашивает в _surroundingsFillColor;
///   - если нет — добавляет и красит;
///   - raycastTarget = true, чтобы шапку можно было тащить.
/// Отдельной тёмной плашки под шапкой НЕТ — фон шапки и сетки — это и есть эта заливка.
/// </summary>
private void EnsureSurroundingsPanelBackground(RectTransform panelRect)
{
    if (panelRect == null) return;

    var img = panelRect.GetComponent<Image>();
    if (img == null)
        img = panelRect.gameObject.AddComponent<Image>();

    img.sprite = null;
    img.type = Image.Type.Simple;
    img.color = _surroundingsFillColor;
    img.raycastTarget = true;
    img.maskable = true;
}
/// <summary>
/// Удаляет легаси-дочерние элементы под SurroundingsHeader от предыдущей итерации:
/// «Background» (тёмная плашка) и «Vignette» (пелена). Ничего иного не трогает.
/// Идемпотентно: если детей нет — no-op.
/// </summary>
/// <summary>
/// Удаляет легаси-дочерние элементы под SurroundingsHeader от предыдущих итераций:
///   - «Background» (тёмная плашка);
///   - «Vignette» (пелена);
///   - TopLine — верхняя граница шапки от прошлой версии; теперь верхняя
///     кромка панели живёт как SURROUNDINGS_BORDER_TOP_NAME на самой панели.
/// Идемпотентно.
/// </summary>
// ═══════════════════════════════════════════════════════════════
//  CleanupLegacyHeaderChildren — ПОЛНАЯ ЗАМЕНА
//  Удаляет Background, Vignette, TopLine из шапки.
// ═══════════════════════════════════════════════════════════════
private void CleanupLegacyHeaderChildren(RectTransform headerRect)
{
    if (headerRect == null) return;

    Transform bg = headerRect.Find("Background");
    if (bg != null) UnityEngine.Object.Destroy(bg.gameObject);

    Transform vig = headerRect.Find("Vignette");
    if (vig != null) UnityEngine.Object.Destroy(vig.gameObject);

    // TopLine — верхняя граница шапки от прошлой версии.
    // Теперь верхняя кромка панели живёт как SURROUNDINGS_BORDER_TOP_NAME
    // на самой панели (4-й бордер-стрип).
    Transform topLine = headerRect.Find(SURROUNDINGS_TOP_LINE_NAME);
    if (topLine != null) UnityEngine.Object.Destroy(topLine.gameObject);
}
// ═══════════════════════════════════════════════════════════════
//  EnsureSurroundingsPanelBorder — ПОЛНАЯ ЗАМЕНА
//  4 стрипа: bottom → left → right → top.
//  Top использует отдельную толщину _surroundingsTopBorderThickness.
// ═══════════════════════════════════════════════════════════════
private void EnsureSurroundingsPanelBorder(RectTransform panelRect)
{
    if (panelRect == null) return;

    // Bottom
    EnsureBorderStrip(
        panelRect, SURROUNDINGS_BORDER_BOTTOM_NAME,
        new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f),
        Vector2.zero, new Vector2(0f, _surroundingsBorderThickness));

    // Left
    EnsureBorderStrip(
        panelRect, SURROUNDINGS_BORDER_LEFT_NAME,
        new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(0f, 0.5f),
        Vector2.zero, new Vector2(_surroundingsBorderThickness, 0f));

    // Right
    EnsureBorderStrip(
        panelRect, SURROUNDINGS_BORDER_RIGHT_NAME,
        new Vector2(1f, 0f), new Vector2(1f, 1f), new Vector2(1f, 0.5f),
        Vector2.zero, new Vector2(_surroundingsBorderThickness, 0f));

    // Top — 4-й стрип, симметричен bottom, но с ОТДЕЛЬНОЙ толщиной
    // для компенсации субпиксельного рендеринга верхней кромки.
    EnsureBorderStrip(
        panelRect, SURROUNDINGS_BORDER_TOP_NAME,
        new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0.5f, 1f),
        Vector2.zero, new Vector2(0f, _surroundingsTopBorderThickness));
}
private void EnsureBorderStrip(
    RectTransform panelRect, string name,
    Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot,
    Vector2 anchoredPos, Vector2 sizeDelta)
{
    if (panelRect == null) return;

    Transform tr = panelRect.Find(name);
    RectTransform rect;
    Image img;

    if (tr == null)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(panelRect, false);
        rect = go.GetComponent<RectTransform>();
        img  = go.GetComponent<Image>();
        img.sprite = null;
        img.type   = Image.Type.Simple;
        img.maskable = true;
    }
    else
    {
        rect = tr as RectTransform;
        img  = tr.GetComponent<Image>();
        if (img == null) img = tr.gameObject.AddComponent<Image>();
    }

    if (rect == null || img == null) return;

    rect.anchorMin = anchorMin;
    rect.anchorMax = anchorMax;
    rect.pivot     = pivot;
    rect.anchoredPosition = anchoredPos;
    rect.sizeDelta = sizeDelta;
    rect.localScale = Vector3.one;

    img.color = K_ResponsiveCanvasLayout.ResolveLineColor(panelRect);
    img.raycastTarget = false;   // клики проходят сквозь бордер

    // ВСЕ 4 бордер-стрипа всегда на верхушке z-order среди детей панели.
    rect.SetAsLastSibling();
}
        public void EndLootVisuals()
        {
            if (_surroundingsPanel != null)
                _surroundingsPanel.SetActive(false);

            if (_surroundingsGrid != null)
                ClearGrid(_surroundingsGrid, _surroundingsItemsContainer);

            ForceRefresh();
        }

        /// <summary>
        /// Зеркалирование loot-размерностей в K_InventoryUI._currentContainerCols/Rows.
        /// Нужно для backwards compat: GetGridWidth/Height, RebuildSurroundingsGrid,
        /// SetupSurroundingsPanelHierarchy и т.д. читают эти поля напрямую.
        /// </summary>
        public void SetCurrentContainerDimensions(int cols, int rows)
        {
            _currentContainerCols = cols;
            _currentContainerRows = rows;
        }

        // SubscribeToContainerEvents / UnsubscribeFromContainerEvents — публичные
        // (нужны LootSessionController для подписки/отписки на события активного лут-контроллера).
        public void SubscribeToContainerEvents()
        {
            if (ActiveContainerController == null) return;
            ActiveContainerController.OnInventoryChanged += _onInventoryChangedHandler;
            ActiveContainerController.OnItemPlaced += _onItemPlacedHandler;
            ActiveContainerController.OnItemRemoved += _onItemChangedHandler;
            ActiveContainerController.OnItemRotated += _onItemChangedHandler;
            ActiveContainerController.OnItemQuantityChanged += _onItemChangedHandler;
        }

        /// <summary>
        /// ФИКС БАГ #2: Отписка от событий активного контейнера.
        /// </summary>
        public void UnsubscribeFromContainerEvents()
        {
            if (ActiveContainerController == null) return;
            ActiveContainerController.OnInventoryChanged -= _onInventoryChangedHandler;
            ActiveContainerController.OnItemPlaced -= _onItemPlacedHandler;
            ActiveContainerController.OnItemRemoved -= _onItemChangedHandler;
            ActiveContainerController.OnItemRotated -= _onItemChangedHandler;
            ActiveContainerController.OnItemQuantityChanged -= _onItemChangedHandler;
        }

        private void SetCanvasActive(bool active)
        {
            if (_canvasGroup == null) return;
            _canvasGroup.alpha = active ? 1f : 0f;
            _canvasGroup.interactable = active;
            _canvasGroup.blocksRaycasts = active;
        }

       
       
      

        #region Multi-Window Focus System
        // >>> FIX проблема 4: стилизация хедера окна (контраст + линия + жирный текст) <<<
       /// <summary>
/// Оставлен для обратной совместимости вызова из BackpackContainerManager.CreateContainerWindow.
/// После правки весь стиль окна (заливка панели, рамка, шапка, разделитель, текст)
/// задаётся в K_ContainerWindow.Initialize. Метод больше ничего не перекрашивает,
/// чтобы не перебивать палитру панели лута.
/// </summary>
private void StyleWindowHeader(K_ContainerWindow window)
{
    // no-op: стиль полностью задан в K_ContainerWindow.Initialize.
}
        #endregion

        public void OnBackpackEquipped(InventoryItem backpackItem)
{
    if (_isUpdatingBackpackProjection)
        throw new System.InvalidOperationException("Backpack projection update is already active.");
    if (backpackItem?.Data != null && !InventoryGridBounds.IsValidBackpack(backpackItem.Data))
        throw new System.ArgumentOutOfRangeException(nameof(backpackItem), "Backpack dimensions must be between 1 and 20.");
    if (backpackItem == null || backpackItem.Data == null) return;

    string bpIdStr = backpackItem.InstanceID.ToString();
    if (_backpackManager.IsBackpackOpenInCache(bpIdStr)
        || _backpackManager.OpenWindows.Any(w => w != null && w.BackpackInstanceID == bpIdStr))
    {
        var liveCtrl = _backpackManager.GetLiveController(bpIdStr);
        if  (liveCtrl != null)
        {
            var liveItems = liveCtrl.GetSaveData()?.GetItems();
            if (liveItems != null) backpackItem.ReplaceBackpackContents(liveItems);
        }
        CloseAllWindowsForBackpack(backpackItem);
    }

    int w = backpackItem.Data.BackpackWidth;
    int h = backpackItem.Data.BackpackHeight;
    if (w <= 0 || h <= 0 || _backpackController == null || _backpackGrid == null) return;

    if (_loadedBackpackItem != backpackItem)
    {
        // Окна предметов внутри СТАРОГО содержимого _backpackController закрываем
        // ДО чтения старых данных и Clear — иначе их живые объекты станут сиротами,
        // а в данные попадёт устаревший снапшот.
        _backpackManager?.CloseWindowsInsideSubtree(_backpackController);

        if (_loadedBackpackItem != null)
        {
            _backpackController.RefreshAllItemsInData();
            var oldItems = _backpackController.GetSaveData()?.GetItems();
            if (oldItems != null) _loadedBackpackItem.ReplaceBackpackContents(oldItems);
        }

        // Read and validate the entire incoming tree before clearing the current
        // projection. A missing template or invalid child must never consume data.
        var savedContents = new List<SavedItem>();
        foreach (var saved in backpackItem.GetBackpackSavedItems())
            savedContents.Add(SavedItem.DeepClone(saved));
        var restored = new List<(InventoryItem item, int x, int y)>(savedContents.Count);
        if (savedContents.Count > 0)
        {
            var db = K_InventorySetup.DatabaseInstance;
            using (var validation = new SaveLoadValidationContext())
                InventoryLoadReader.ValidateTree(savedContents, w, h, db, validation,
                    "EquippedBackpack/" + backpackItem.InstanceID);
            foreach (var saved in savedContents)
            {
                var innerItem = InventoryItem.FromSaveData(saved, db.GetItemData(saved.ItemID));
                if (innerItem == null)
                    throw new System.IO.InvalidDataException("Cannot restore backpack item " + saved.InstanceID);
                restored.Add((innerItem, saved.X, saved.Y));
            }
        }

        var restoreProjection = _backpackController.CaptureAtomicRestore();
        var restoreIncoming = backpackItem.CaptureAtomicRestore();
        var previousOwner = _loadedBackpackItem;
        bool previousEquipped = _backpackEquipped;
        int previousCols = _currentBackpackCols, previousRows = _currentBackpackRows;
        _isUpdatingBackpackProjection = true;
        try
        {
            _backpackController.Clear();
            if (!_backpackController.Resize(w, h))
                throw new System.InvalidOperationException("Cannot resize backpack projection.");
            foreach (var entry in restored)
                if (!_backpackController.PlaceExistingItem(entry.item, entry.x, entry.y))
                    throw new System.InvalidOperationException("Validated backpack placement failed for " + entry.item.InstanceID);

            // Keep an independent snapshot; the equipped controller is a projection,
            // not a reason to erase the portable item's nested state.
            backpackItem.ReplaceBackpackContents(savedContents);
            _loadedBackpackItem = backpackItem;
            _backpackEquipped = true;
            if (backpackItem.CanFold) backpackItem.SetFolded(false);
            RebuildBackpackGrid(w, h);
        }
        catch
        {
            restoreProjection();
            restoreIncoming();
            _loadedBackpackItem = previousOwner;
            _backpackEquipped = previousEquipped;
            _currentBackpackCols = previousCols;
            _currentBackpackRows = previousRows;
            throw;
        }
        finally { _isUpdatingBackpackProjection = false; }
        if (restored.Count > 0)
            Debug.Log($"[OnBackpackEquipped] Restored {restored.Count} items " +
                $"(skipped 0) from save into '{backpackItem.Data.DisplayName}' ({w}x{h} grid).");
        return;
    }

    _backpackEquipped = true;
    if (backpackItem.CanFold) backpackItem.SetFolded(false);
    RebuildBackpackGrid(w, h);
}
     public void OnBackpackUnequipped()
{
    if (_isUpdatingBackpackProjection)
        throw new System.InvalidOperationException("Backpack projection update is already active.");
    // The slot may already be empty or hold the next backpack. Only the item
    // that loaded this projection owns its contents. Repeated detach is a no-op.
    var owner = _loadedBackpackItem;
    if (owner != null)
    {
        _backpackManager?.CloseWindowsInsideSubtree(_backpackController);
        if (_backpackController != null && !_backpackController.IsDisposed)
        {
            _backpackController.RefreshAllItemsInData();
            var savedItems = _backpackController.GetSaveData()?.GetItems()
                ?? System.Array.Empty<SavedItem>();
            var restoreProjection = _backpackController.CaptureAtomicRestore();
            var restoreOwner = owner.CaptureAtomicRestore();
            bool previousEquipped = _backpackEquipped;
            _isUpdatingBackpackProjection = true;
            try
            {
                owner.ReplaceBackpackContents(savedItems);
                _loadedBackpackItem = null;
                _backpackEquipped = false;
                _backpackController.Clear();
            }
            catch
            {
                restoreProjection();
                restoreOwner();
                _loadedBackpackItem = owner;
                _backpackEquipped = previousEquipped;
                throw;
            }
            finally { _isUpdatingBackpackProjection = false; }
        }
    }

    _backpackEquipped = false;
    _loadedBackpackItem = null;
    if (_backpackGrid != null)
        ClearGrid(_backpackGrid, _backpackItemsContainer);
    _currentBackpackCols = 0;
    _currentBackpackRows = 0;
}

        #region Tab System

        /// <summary>
        /// Переключить вкладку: 0 = Инвентарь, 1 = Здоровье.
        /// Вызывать из кнопок в UI.
        /// </summary>
        public void SwitchTab(int tabIndex)
        {
            if (tabIndex < 0 || tabIndex > 1) return;
            _activeTab = tabIndex;
            ApplyTabState();
        }

        /// <summary>Переключить на следующую вкладку (инвентарь ↔ здоровье).</summary>
        public void ToggleTab()
        {
            SwitchTab(_activeTab == 0 ? 1 : 0);
        }

      private void ApplyTabState()
{
    bool showInventory = _activeTab == 0;
    bool showHealth = _activeTab == 1;

    if (_inventoryContentPane != null)
        _inventoryContentPane.SetActive(showInventory);
    if (_healthContentPane != null)
        _healthContentPane.SetActive(showHealth);

    // FIX: при переключении вкладок пересинхронизируем _backpackPanel (LeftPane).
    // Иначе после CloseAll с _activeTab==1 / повторного OpenInventoryOnly без надетого
    // рюкзака панель LeftPane (EquipmentGroup, WeightText, CONNECTORS) остаётся выключенной,
    // и клик по вкладке "Инвентарь" показывает пустой InventoryContentPane.
    SyncBackpackPanelState();

    UpdateTabButtonColors();
}

      private void UpdateTabButtonColors()
{
    if (_tabButtons == null) return;
    for (int i = 0; i < _tabButtons.Length; i++)
    {
        if (_tabButtons[i] != null)
        {
            ApplyTabButtonStyle(_tabButtons[i], i == _activeTab);
        }
    }
}

private void EnsureTabBar()
{
    if (_tabBar != null) return;
    if (_tabButtons == null || _tabButtons.Length == 0 || _tabButtons[0] == null)
    {
        Debug.LogWarning("[K_InventoryUI] Cannot resolve _tabBar: _tabButtons is null, empty, or first element is null.");
        return;
    }

    _tabBar = _tabButtons[0].transform.parent != null ? _tabButtons[0].transform.parent.gameObject : null;
    // Активность НЕ трогать.
}

private void EnsureTabButtonsStyled()
{
    EnsureTabBar();
    if (_tabButtons == null) return;

    for (int i = 0; i < _tabButtons.Length; i++)
    {
        if (_tabButtons[i] != null)
        {
            ApplyTabButtonStyle(_tabButtons[i], i == _activeTab);
        }
    }
}

private void ApplyTabButtonStyle(GameObject tabButton, bool isActive)
{
    if (tabButton == null) return;

    // 1. Fill
    var fillImg = tabButton.GetComponent<Image>();
    if (fillImg == null)
    {
        fillImg = tabButton.AddComponent<Image>();
    }
    fillImg.sprite = null;
    fillImg.type = Image.Type.Simple;
    fillImg.color = new Color(159f / 255f, 159f / 255f, 159f / 255f, 4f / 255f);
    fillImg.color = _tabFillColor; // UI-STYLE: Inspector is authoritative.
    fillImg.raycastTarget = true;

    // 2. Button
    var btn = tabButton.GetComponent<Button>();
    if (btn != null)
    {
        btn.transition = Selectable.Transition.None;
    }

    // 3. Text
    var tmp = tabButton.GetComponentInChildren<TextMeshProUGUI>(true);
    if (tmp != null)
    {
        tmp.fontStyle = FontStyles.Bold;
        tmp.fontSize = 14f;
        tmp.color = new Color(159f / 255f, 159f / 255f, 159f / 255f, 1f);
        tmp.color = _tabTextColor; // UI-STYLE: Inspector is authoritative.
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.textWrappingMode = TextWrappingModes.NoWrap;
        tmp.overflowMode = TextOverflowModes.Truncate;
        tmp.raycastTarget = false;

        if (tmp.font == null && TMP_Settings.defaultFontAsset != null)
        {
            tmp.font = TMP_Settings.defaultFontAsset;
        }
    }

    // 4. Border strips
    Color borderColor = isActive
        ? new Color(159f / 255f, 159f / 255f, 159f / 255f, 255f / 255f) // <-- Изменено с 45f на 255f
        : new Color(159f / 255f, 159f / 255f, 159f / 255f, 4f / 255f);
    borderColor = isActive ? _activeTabColor : _inactiveTabColor;

    EnsureTabBorderStrip(tabButton.transform, "TabBtnBorderTop",
        new Vector2(0, 1), new Vector2(1, 1), new Vector2(0.5f, 1), new Vector2(0, 2), borderColor);
    EnsureTabBorderStrip(tabButton.transform, "TabBtnBorderBottom",
        new Vector2(0, 0), new Vector2(1, 0), new Vector2(0.5f, 0), new Vector2(0, 1), borderColor);
    EnsureTabBorderStrip(tabButton.transform, "TabBtnBorderLeft",
        new Vector2(0, 0), new Vector2(0, 1), new Vector2(0, 0.5f), new Vector2(1, 0), borderColor);
    EnsureTabBorderStrip(tabButton.transform, "TabBtnBorderRight",
        new Vector2(1, 0), new Vector2(1, 1), new Vector2(1, 0.5f), new Vector2(1, 0), borderColor);

    // Set border strips as first siblings so text renders on top
    var topBorder = tabButton.transform.Find("TabBtnBorderTop");
    if (topBorder != null) topBorder.SetAsFirstSibling();
    var bottomBorder = tabButton.transform.Find("TabBtnBorderBottom");
    if (bottomBorder != null) bottomBorder.SetAsFirstSibling();
    var leftBorder = tabButton.transform.Find("TabBtnBorderLeft");
    if (leftBorder != null) leftBorder.SetAsFirstSibling();
    var rightBorder = tabButton.transform.Find("TabBtnBorderRight");
    if (rightBorder != null) rightBorder.SetAsFirstSibling();
}

private void EnsureTabBorderStrip(Transform parent, string name,
    Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 sizeDelta, Color color)
{
    if (parent == null) return;

    Transform existing = parent.Find(name);
    RectTransform rt;
    Image img;

    if (existing == null)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(parent, false);
        rt = go.GetComponent<RectTransform>();
        img = go.GetComponent<Image>();
    }
    else
    {
        rt = existing as RectTransform;
        img = existing.GetComponent<Image>();
        if (img == null) img = existing.gameObject.AddComponent<Image>();
    }

    if (rt == null || img == null) return;

    rt.anchorMin = anchorMin;
    rt.anchorMax = anchorMax;
    rt.pivot = pivot;
    rt.anchoredPosition = Vector2.zero;
    rt.sizeDelta = sizeDelta;
    rt.localScale = Vector3.one;

    img.sprite = null;
    img.type = Image.Type.Simple;
    img.color = color;
    img.raycastTarget = false;
    img.maskable = true;

    rt.SetAsFirstSibling();
}
        /// <summary>Текущая активная вкладка (0=Инвентарь, 1=Здоровье).</summary>
        public int ActiveTab => _activeTab;

        /// <summary>
        /// Синхронизирует видимость панели рюкзака с состоянием экипировки.
        /// Если рюкзак не надет — скрывает _backpackPanel.
        /// </summary>
        private void SyncBackpackPanelState()
        {
            if (_backpackSlot == null || _backpackPanel == null) return;
            bool hasBackpack = _backpackSlot.IsOccupied && _backpackSlot.EquippedItem?.Data?.IsBackpack == true;
            _backpackPanel.SetActive(hasBackpack || _activeTab == 0); // Всегда показываем на вкладке инвентаря
            if (hasBackpack)
                OnBackpackEquipped(_backpackSlot.EquippedItem);
        }

        #endregion

       
        private IEnumerator EnforceBackpackContainerSize(int width, int height)
        {
            for (int frame = 0; frame < 5; frame++)
            {
                yield return null; // ждём следующий кадр

                if (_backpackGrid == null) yield break;

                var gridRT = _backpackGrid.GetComponent<RectTransform>();
                var gridLayout = _backpackGrid.GetComponent<GridLayoutGroup>();
                if (gridRT == null || gridLayout == null) yield break;

                float padLeft = gridLayout.padding.left;
                float padRight = gridLayout.padding.right;
                float padTop = gridLayout.padding.top;
                float padBot = gridLayout.padding.bottom;
                float correctW = padLeft + width * _slotSize + Mathf.Max(0, width - 1) * _slotSpacing + padRight;
                float correctH = padTop + height * _slotSize + Mathf.Max(0, height - 1) * _slotSpacing + padBot;

                // Исправляем размер grid'а если его перезаписали
                if (Mathf.Abs(gridRT.sizeDelta.x - correctW) > 0.5f ||
                    Mathf.Abs(gridRT.sizeDelta.y - correctH) > 0.5f)
                {
                    gridRT.sizeDelta = new Vector2(correctW, correctH);
                }

                // Исправляем размер itemsContainer'а
                if (_backpackItemsContainer != null)
                {
                    var itemsRT = _backpackItemsContainer.GetComponent<RectTransform>();
                    if (itemsRT != null)
                    {
                        if (Mathf.Abs(itemsRT.sizeDelta.x - correctW) > 0.5f ||
                            Mathf.Abs(itemsRT.sizeDelta.y - correctH) > 0.5f)
                        {
                            itemsRT.sizeDelta = new Vector2(correctW, correctH);
                        }
                        // Также гарантируем что anchoredPosition = (0,0)
                        // чтобы контейнер точно совпадал с гридом
                        if (itemsRT.anchoredPosition != Vector2.zero)
                            itemsRT.anchoredPosition = Vector2.zero;
                    }
                }
            }
        }

      

        #region Refresh System

        public void RefreshAll()
        {
            _medicalInventoryService?.MarkDirty();
            _pendingRefresh = true;
            if (_dragItemRemoved || _isExecutingRefresh || _uiSync == null || _uiSync.IsReturningAllItemsToPool) return;
            if (_refreshCoroutine != null || Time.time - _lastRefreshTime < UI_REFRESH_THROTTLE) return;
            if (gameObject.activeInHierarchy) _refreshCoroutine = StartCoroutine(RefreshNextFrame());
        }

        private IEnumerator RefreshNextFrame()
        {
            yield return null;
            _refreshCoroutine = null;
            if (_pendingRefresh) ForceRefresh();
        }

        public void ForceRefresh()
        {
            _medicalInventoryService?.MarkDirty();
            _pendingRefresh = true;
            if (_uiSync == null || _uiSync.IsReturningAllItemsToPool || _dragItemRemoved || _isExecutingRefresh) return;
            if (_refreshCoroutine != null)
            {
                StopCoroutine(_refreshCoroutine);
                _refreshCoroutine = null;
            }
            _pendingRefresh = false;
            _isExecutingRefresh = true;
            _lastRefreshTime = Time.time;
            try
            {
                OnInventoryRefreshed?.Invoke();
                RefreshCombatWeight();
                _uiSync.ExecuteRefreshImmediate();
            }
            finally { _isExecutingRefresh = false; }
        }

        // A blocked request stays queued until its owner can perform it.
        private void DrainQueuedRefresh()
        {
            if (_pendingRefresh && _refreshCoroutine == null) RefreshAll();
        }

#region Player Weight (single source of truth)

/// <summary>
/// Рекурсивный вес одного предмета (кг).
/// Открытый рюкзак → живой контроллер; закрытый → serialized-дерево.
/// Один общий метод для всех точек расчёта (спека §2.1).
/// </summary>
public float WeightOfItem(InventoryItem item)
{
    if (item?.Data == null) return 0f;

    float baseKg = item.Data.WeightGrams * item.Quantity / 1000f;
    if (!item.Data.IsBackpack) return baseKg;

    // Открытый рюкзак: содержимое — в живом контроллере
    string idStr = item.InstanceID.ToString();
    var liveCtrl = GetEquippedBackpackProjection(item) ??
        (_backpackManager != null ? _backpackManager.GetLiveController(idStr) : null);
    if (liveCtrl != null && !liveCtrl.IsDisposed)
    {
        float inner = 0f;
        for (int y = 0; y < liveCtrl.Height; y++)
            for (int x = 0; x < liveCtrl.Width; x++)
            {
                var child = liveCtrl.GetItemAt(x, y);
                if (child != null && liveCtrl.IsRootCell(child.InstanceID, x, y))
                    inner += WeightOfItem(child);
            }
        return baseKg + inner;
    }

    // Закрытый рюкзак: содержимое — в _backpackContentsSerialized
    var raw = item.GetBackpackContentsRaw();
    if (raw != null && raw.Count > 0)
    {
        float inner = 0f;
        for (int i = 0; i < raw.Count; i++)
            inner += WeightOfSavedItem(raw[i]);
        return baseKg + inner;
    }

    return baseKg;
}

/// <summary>
/// Рекурсивный вес SavedItem (без аллокации InventoryItem).
/// </summary>
private float WeightOfSavedItem(SavedItem saved)
{
    var db = K_InventorySetup.DatabaseInstance;
    if (db == null) return 0f;

    var template = db.GetItemData(saved.ItemID);
    if (template == null) return 0f;

    float baseKg = template.WeightGrams * Mathf.Max(1, saved.Quantity) / 1000f;
    if (!template.IsBackpack) return baseKg;
    if (saved.BackpackContents == null || saved.BackpackContents.Count == 0) return baseKg;

    float inner = 0f;
    for (int i = 0; i < saved.BackpackContents.Count; i++)
        inner += WeightOfSavedItem(saved.BackpackContents[i]);
    return baseKg + inner;
}

/// <summary>
/// Сумма веса всех root-предметов одного контроллера с рекурсией.
/// </summary>
private float SumControllerWeight(InventoryController ctrl)
{
    if (ctrl == null || ctrl.IsDisposed) return 0f;
    float sum = 0f;
    for (int y = 0; y < ctrl.Height; y++)
        for (int x = 0; x < ctrl.Width; x++)
        {
            var item = ctrl.GetItemAt(x, y);
            if (item == null) continue;
            if (!ctrl.IsRootCell(item.InstanceID, x, y)) continue;
            sum += WeightOfItem(item);
        }
    return sum;
}

/// <summary>
/// Сумма веса всего, что несёт игрок (спека §2.2).
/// Слот Backpack ИСКЛЮЧЁН — содержимое экипированного рюкзака уже в _backpackController.
/// Слоты экипировки: Primary×2, Pistol, Melee, BodyArmor, HeadGear.
/// </summary>
public float CalculateTotalPlayerWeight()
{
    float total = 0f;

    total += SumControllerWeight(_pocketsController);
    total += SumControllerWeight(_pocket2Controller);
    total += SumControllerWeight(_backpackController);

    if (_primarySlot1 != null && _primarySlot1.EquippedItem != null) total += WeightOfItem(_primarySlot1.EquippedItem);
    if (_primarySlot2 != null && _primarySlot2.EquippedItem != null) total += WeightOfItem(_primarySlot2.EquippedItem);
    if (_pistolSlot   != null && _pistolSlot.EquippedItem   != null) total += WeightOfItem(_pistolSlot.EquippedItem);
    if (_meleeSlot    != null && _meleeSlot.EquippedItem    != null) total += WeightOfItem(_meleeSlot.EquippedItem);
    if (_armorSlot    != null && _armorSlot.EquippedItem    != null) total += WeightOfItem(_armorSlot.EquippedItem);
    if (_headgearSlot != null && _headgearSlot.EquippedItem != null) total += WeightOfItem(_headgearSlot.EquippedItem);

    // ═══ Слот Backpack: сам предмет-рюкзак весит, но его содержимое уже посчитано
    // через SumControllerWeight(_backpackController). Поэтому берём только base-вес
    // (WeightGrams × Quantity), без рекурсии в _backpackContentsSerialized —
    // иначе был бы double-count содержимого. ═══
    if (_backpackSlot != null && _backpackSlot.EquippedItem != null)
    {
        var bp = _backpackSlot.EquippedItem;
        if (bp.Data != null)
            total += bp.Data.WeightGrams * Mathf.Max(1, bp.Quantity) / 1000f;
    }

    var applied = AppliedHealth?.AppliedMedical?.Records;
    var database = K_InventorySetup.DatabaseInstance;
    if (applied != null && applied.Count > 0 && database != null)
    {
        var equipment = new[] { _primarySlot1?.EquippedItem, _primarySlot2?.EquippedItem,
            _pistolSlot?.EquippedItem, _meleeSlot?.EquippedItem, _backpackSlot?.EquippedItem,
            _armorSlot?.EquippedItem, _headgearSlot?.EquippedItem };
        var physicalRoots = Combat.CombatPlayerInventory.CollectOwnedRoots(equipment,
            _pocketsController, _pocket2Controller, _backpackController);
        var calculator = new Combat.CombatWeightCalculator(new Combat.CombatItemStateRegistry(), database.GetItemData);
        total += calculator.GetAdditionalAppliedMedicalWeightGrams(physicalRoots, applied) / 1000f;
    }

    return total;
}
public void RefreshTotalWeight()
{
    if (_cachedWeightManager == null)
    {
        UpdateWeightDisplay();
        return;
    }

    float total = CalculateTotalPlayerWeight();
    _cachedWeightManager.SetWeight(total);
    UpdateWeightDisplay();
}

/// <summary>
/// Обновление текста веса. Источник данных — K_WeightManager (ratio, пороги, MaxCapacity).
/// Формат: "X.X / Y.Y кг" (спека §3.1).
/// </summary>
private void UpdateWeightDisplay()
{
    if (_weightText == null) return;

    if (_cachedWeightManager == null)
    {
        _weightText.text = "0.0 / 0.0 кг";
        return;
    }

    float current = _cachedWeightManager.CurrentWeight;
    float max     = _cachedWeightManager.MaxCapacity;
    float ratio   = _cachedWeightManager.GetCurrentWeightRatio();

    float criticalCeil = _cachedWeightManager.CriticalThreshold > 0f
        ? _cachedWeightManager.CriticalThreshold
        : 1.1f;

    float t = Mathf.Clamp01(ratio / criticalCeil);

    Color c = (_weightTextGradient != null)
        ? _weightTextGradient.Evaluate(t)
        : Color.white;

    _weightText.text = $"<color=#{ColorUtility.ToHtmlStringRGB(c)}>{current:F1} / {max:F1} кг</color>";
}

private Gradient CreateDefaultWeightGradient()
{
    // UpdateWeightDisplay нормирует t = ratio / criticalThreshold (= 1.1).
    // Пороги в t-пространстве:
    //   ratio 0.0   (0 кг)     → t 0.000 — светлый
    //   ratio 0.769 (50 кг)    → t 0.699 — светлый (начало дебаффов)
    //   ratio 0.9   (58.5 кг)  → t 0.818 — жёлтый
    //   ratio 1.0   (65 кг)    → t 0.909 — красный
    //   ratio 1.1+  (71.5+ кг) → t 1.000 — красный
    var g = new Gradient();
    g.SetKeys(
        new GradientColorKey[]
        {
            new GradientColorKey(new Color(0.71f, 0.73f, 0.75f), 0.000f), // светлый
            new GradientColorKey(new Color(0.71f, 0.73f, 0.75f), 0.699f), // светлый (до 50 кг)
            new GradientColorKey(new Color(0.71f, 0.55f, 0.24f), 0.818f), // жёлтый (58.5 кг)
            new GradientColorKey(new Color(0.71f, 0.24f, 0.24f), 0.909f), // красный (65 кг)
            new GradientColorKey(new Color(0.71f, 0.24f, 0.24f), 1.000f), // красный
        },
        new GradientAlphaKey[]
        {
            new GradientAlphaKey(1f, 0.0f),
            new GradientAlphaKey(1f, 1.0f),
        });
    return g;
}

private void SubscribeToEquipmentSlotEvents()
{
    if (_onEquipmentChangedHandler == null) return;
    if (_primarySlot1 != null) _primarySlot1.OnEquipmentChanged += _onEquipmentChangedHandler;
    if (_primarySlot2 != null) _primarySlot2.OnEquipmentChanged += _onEquipmentChangedHandler;
    if (_pistolSlot   != null) _pistolSlot.OnEquipmentChanged   += _onEquipmentChangedHandler;
    if (_meleeSlot    != null) _meleeSlot.OnEquipmentChanged    += _onEquipmentChangedHandler;
    if (_backpackSlot != null) _backpackSlot.OnEquipmentChanged += _onEquipmentChangedHandler;
    if (_armorSlot    != null) _armorSlot.OnEquipmentChanged    += _onEquipmentChangedHandler;
    if (_headgearSlot != null) _headgearSlot.OnEquipmentChanged += _onEquipmentChangedHandler;
}

private void UnsubscribeFromEquipmentSlotEvents()
{
    if (_onEquipmentChangedHandler == null) return;
    if (_primarySlot1 != null) _primarySlot1.OnEquipmentChanged -= _onEquipmentChangedHandler;
    if (_primarySlot2 != null) _primarySlot2.OnEquipmentChanged -= _onEquipmentChangedHandler;
    if (_pistolSlot   != null) _pistolSlot.OnEquipmentChanged   -= _onEquipmentChangedHandler;
    if (_meleeSlot    != null) _meleeSlot.OnEquipmentChanged    -= _onEquipmentChangedHandler;
    if (_backpackSlot != null) _backpackSlot.OnEquipmentChanged -= _onEquipmentChangedHandler;
    if (_armorSlot    != null) _armorSlot.OnEquipmentChanged    -= _onEquipmentChangedHandler;
    if (_headgearSlot != null) _headgearSlot.OnEquipmentChanged -= _onEquipmentChangedHandler;
}

private void OnAnyEquipmentChanged(K_EquipmentSlotUI slot, InventoryItem oldItem, InventoryItem newItem)
{
    RefreshCombatWeight();
}

#endregion
      
        private Transform GetItemsContainer(GridType type) => type switch
        {
            GridType.Pockets => _pocketsItemsContainer,
            GridType.Pocket2 => _pocket2ItemsContainer,
            GridType.Backpack => _backpackItemsContainer,
            GridType.Container => _surroundingsItemsContainer,
            _ => null
        };

      
      
        #endregion

        #region Drag & Drop System

        public void StartDrag(UI_Item draggedItem, PointerEventData eventData)
        {
            // ФИКС БАГ (audit) #11: делегируем в TryStartDrag и игнорируем bool.
            // Реальная проверка ошибки делается в TryStartDrag.
            TryStartDrag(draggedItem, eventData);
        }

        /// <summary>
        /// ФИКС БАГ (audit) #11: Безопасный BeginDrag с возвращаемым значением.
        /// Возвращает false, если drag не удалось начать (item==null, либо
        /// source controller не смог RemoveItem). В этом случае UI_Item НЕ
        /// должен скрывать CanvasGroup — предмет остаётся видимым.
        /// </summary>
      public bool TryStartDrag(UI_Item draggedItem, PointerEventData eventData)
{
    if (draggedItem?.Item == null || _ghostPresenter == null || !_ghostPresenter.IsGhostAvailable) return false;
    if (K_SplitStackDialog.IsItemLocked(draggedItem.Item)) return false;

    // ФИКС: Запрещаем перетаскивание на ПКМ/средней.
    if (eventData.button != PointerEventData.InputButton.Left) return false;

    // ═══ ДИАГНОСТИКА: проверяем синхронизацию UI_Item с контроллером ═══
    var controller = GetControllerForGrid(draggedItem.GridType);
    if (controller != null)
    {
        var atPos = controller.GetItemAt(draggedItem.X, draggedItem.Y);
        if (atPos == null || atPos.InstanceID != draggedItem.Item.InstanceID)
        {
            Debug.LogWarning($"[TryStartDrag] UI_Item DESYNC detected: " +
                $"UI_Item at ({draggedItem.X},{draggedItem.Y}) but controller has " +
                $"{(atPos?.Data?.DisplayName ?? "null")} there. " +
                $"Dragged item '{draggedItem.Item.Data?.DisplayName}' may be elsewhere.");
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // ФАЗА 2: Транзакционный drag — предмет НЕ удаляется из контроллера.
    // UI_Item остаётся в сетке данных, но помечается как IsBeingDragged.
    // Ghost показывается поверх, RefreshGrid игнорирует этот UI_Item.
    // При drop — транзакция через TransactionService (Фаза 3).
    // При неудаче — данные не меняются, предмет остаётся на месте.
    // ═══════════════════════════════════════════════════════════════

    _draggedFromEquipmentSlot = null;
    _draggedFromSlotItem = null;
    _draggedFromSlotIconRotation = 0f;
    _draggedItem = draggedItem;
    _isDragging = true;

    // Сохраняем оригинальную позицию (для отката при неудачном drop)
    _dragOriginGridType = draggedItem.GridType;
    _dragOriginX = draggedItem.X;
    _dragOriginY = draggedItem.Y;
    _dragOriginRotationAngle = draggedItem.Item.RotationAngle;
    _dragOriginFolded = draggedItem.Item.IsFolded;

    // ФАЗА 2: _dragItemRemoved больше не используется (предмет остаётся в данных)
    _dragItemRemoved = false;

    // ФАЗА 2: Помечаем UI_Item как "в процессе drag"
    draggedItem.IsBeingDragged = true;

    // Снимаем hover при начале drag
    _highlightController?.ClearHoverIfMatchesDragged(draggedItem);

    _ghostPresenter.Begin(draggedItem.Item);

    // ФИКС БАГ #3 (v2): Включаем raycast на слотах для OnDrop
    SetAllGridSlotsRaycast(true);

  
    _ghostPresenter.Show();
    _ghostPresenter.UpdatePosition(eventData);

    // ═══ ФИКС ДВОЕНИЯ ИКОНОК: скрываем оригинальный UI_Item ═══
    var cg = draggedItem.GetComponent<CanvasGroup>();
    if (cg == null) cg = draggedItem.gameObject.AddComponent<CanvasGroup>();
    cg.alpha = 0f; // Полностью скрыть (ghost показывает предмет)
    cg.blocksRaycasts = false;

    // ФАЗА 2: уведомляем BackpackStateManager о новом drag
    UpdateBackpackManagerDragState();

    return true;
}
       // ============================================================
//  ИСПРАВЛЕНИЕ БАГА 3: корректировка поворота для ВСЕХ слотов
// ============================================================
public void StartDragFromEquipmentSlot(K_EquipmentSlotUI slot, PointerEventData eventData)
{
    if (slot?.EquippedItem == null || _ghostPresenter == null || !_ghostPresenter.IsGhostAvailable) return;
    if (_isDragging) return;
    if (eventData.button != PointerEventData.InputButton.Left)
    {
        var icon = slot.transform.Find("Icon");
        if (icon != null)
        {
            var cg = icon.GetComponent<CanvasGroup>();
            if (cg != null)
            {
                cg.alpha = 1f;
                cg.blocksRaycasts = true;
            }
        }
        return;
    }

    var item = slot.EquippedItem;
    int originRotationAngle = item.RotationAngle;
    bool originFolded = item.IsFolded;

    // The two model orientations repeat the rectangular footprint every 180 degrees.
    // A slot showing +90 and a model showing -90 therefore share one geometry.
    if (!InventoryUiGeometry.SameFootprintOrientation(item.IconBaseRotation - item.RotationAngle, slot.IconEulerZ))
        item.Rotate();

    _draggedFromEquipmentSlot = slot;
    _draggedFromSlotItem = item;
    _draggedItem = null;
    _isDragging = true;
    _dragItemRemoved = false;
    _draggedFromSlotIconRotation = slot.IconEulerZ;
    _dragOriginRotationAngle = originRotationAngle;
    _dragOriginFolded = originFolded;

    _ghostPresenter.Begin(item);
    SetAllGridSlotsRaycast(true);
    _ghostPresenter.Show();
    _ghostPresenter.UpdatePosition(eventData);
}
        public void UpdateDragGhostPosition(PointerEventData eventData)
            => _ghostPresenter?.UpdatePosition(eventData);
        /// <summary>Пересекает ли снап-позиция тащимого предмета footprint целевого рюкзака.</summary>


        /// <summary>v12: поиск UI_Item по InventoryItem (для подсветки рюкзака).</summary>
        /// <remarks>ФАЗА 3: метод сделан public — он используется K_InventorySlotUI.OnDrop
        /// для нахождения UI_Item целевого предмета при swap через InventoryTransactionService.</remarks>
               /// <summary>
        /// АУДИТ-ФИКС: ищет в _uiSync.ActiveItems (реальный источник правды),
        /// а НЕ в локальном _activeItems который всегда пуст.
        /// </summary>
        public UI_Item FindUIItemForItem(InventoryItem item)
        {
            if (item == null) return null;
            var activeItems = _uiSync?.ActiveItems;
            if (activeItems == null) return null;
            foreach (var kvp in activeItems)
                if (kvp.Value != null && kvp.Value.Item == item)
                    return kvp.Value;
            return null;
        }
        private void SetAllGridSlotsRaycast(bool enabled)
        {
            SetGridSlotsRaycast(_pocketsGrid, enabled);
            SetGridSlotsRaycast(_pocket2Grid, enabled);
            SetGridSlotsRaycast(_backpackGrid, enabled);
            SetGridSlotsRaycast(_surroundingsGrid, enabled);

            // FIX БАГ 1: Переключаем raycast на слотах ВСЕХ открытых окон.
            foreach (var window in _backpackManager.OpenWindows)
            {
                if (window == null || window.GridRect == null) continue;
                SetGridSlotsRaycast(window.GridRect, enabled);
            }

            // FIX БАГ 1: КРИТИЧЕСКИЙ вызов — переключает blocksRaycasts на контейнерах.
            SetItemsContainersBlocksRaycasts(!enabled);
        }
        private void SetItemsContainersBlocksRaycasts(bool blocksRaycasts)
        {
            // FIX: Чтобы работал Drag-and-Drop по картинке рюкзака (UI_Item), 
            // blocksRaycasts ВСЕГДА должен быть true для контейнеров с предметами.
            var containers = new[] { _pocketsItemsContainer, _pocket2ItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                var cg = container.GetComponent<CanvasGroup>();
                if (cg != null)
                    cg.blocksRaycasts = true; // Жестко ставим true
            }

            // Окна-контейнеры: blocksRaycasts тоже ВСЕГДА true.
            foreach (var window in _backpackManager.OpenWindows)
            {
                if (window == null || window.ItemsContainer == null) continue;
                var cg = window.ItemsContainer.GetComponent<CanvasGroup>();
                if (cg != null)
                    cg.blocksRaycasts = true;
            }
        }

        private void SetGridSlotsRaycast(Transform grid, bool enabled)
        {
            if (grid == null) return;

            for (int i = 0; i < grid.childCount; i++)
            {
                var slotUI = grid.GetChild(i).GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    slotUI.SetRaycastEnabled(enabled);
                }
            }
        }

     public bool TryPlaceItem(UI_Item draggedItem, GridType targetGrid, int targetX, int targetY)
{
    if (draggedItem?.Item == null) return false;

    if (!_isDragging || _draggedItem != draggedItem)
    {
        return false;
    }

    var item = draggedItem.Item;

    var targetController = (targetGrid == GridType.Container && _dropTargetController != null)
        ? _dropTargetController : GetControllerForGrid(targetGrid);

    if (targetController == null) return false;

    var sourceController = (draggedItem.GridType == GridType.Container && draggedItem.BoundController != null)
        ? draggedItem.BoundController
        : GetControllerForGrid(draggedItem.GridType);
        
                // ═══ СВАП: ищем цель по визуальному пересечению UI ═══
            if (!targetController.CanPlaceItem(item, targetX, targetY))
            {
                InventoryItem swapTarget = FindBestSwapTargetByUIRect(item);

                if (swapTarget != null)
                {
                    // Обновляем targetController на тот, где реально лежит найденный предмет
                    targetController = FindControllerForItem(swapTarget);
                    if (targetController != null)
                    {
                        bool isUnfoldedBackpack = swapTarget.Data != null && swapTarget.Data.IsBackpack
                            && !swapTarget.IsFolded && swapTarget.HasInternalGrid;
                        if (!isUnfoldedBackpack)
                        {
                            return TrySwapItems(draggedItem, targetGrid, swapTarget, targetX, targetY);
                        }
                    }
                }
            }
            // ═══ КОНЕЦ БЛОКА СВАПА ═══

    // ИСПРАВЛЕНИЕ: вызов метода внутри самого K_InventoryUI вместо несуществующего _highlightController.FindBackpackInFootprint
    InventoryItem backpackInFootprint = FindBackpackInFootprint(targetController, targetX, targetY, item);
    bool directPlacePossible = targetController.CanPlaceItem(item, targetX, targetY);

    if (backpackInFootprint != null && !directPlacePossible)
    {
        if (TryDropItemIntoBackpack(draggedItem, backpackInFootprint, false))
            return true;

        if (sourceController != null && _dragItemRemoved)
        {
            bool restored = sourceController.PlaceExistingItem(item, draggedItem.X, draggedItem.Y);
            if (!restored) restored = sourceController.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
            if (!restored) TryPlaceInAnyPlayerGrid(item);
        }

        _dragItemRemoved = false;
        _isDragging = false;
        _draggedItem = null;
        _draggedFromEquipmentSlot = null;
        _draggedFromSlotItem = null;
        _draggedFromSlotIconRotation = 0f;

        if (draggedItem != null) { FinishDragAndPool(draggedItem); }
        _ghostPresenter?.End();
        _highlightController?.HideAll();
        SetAllGridSlotsRaycast(false);
        _highlightController?.ClearHover();
        ForceRefresh();
        return false;
    }

    if (sourceController == targetController)
    {
        if (_dragItemRemoved)
        {
            bool placed = targetController.PlaceExistingItem(item, targetX, targetY);
            if (placed)
            {
                _isDragging = false;
                _draggedItem = null;
                _draggedFromEquipmentSlot = null;
                _draggedFromSlotItem = null;
                _draggedFromSlotIconRotation = 0f;
                _dragItemRemoved = false;

                if (draggedItem != null) { FinishDragAndPool(draggedItem); }
                EndDragComplete();
                ForceRefresh();
                return true;
            }

            bool restoredBack = sourceController.PlaceExistingItem(item, draggedItem.X, draggedItem.Y);
            if (!restoredBack) restoredBack = sourceController.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
            if (!restoredBack) TryPlaceInAnyPlayerGrid(item);

            _dragItemRemoved = false;
            _isDragging = false;
            _draggedItem = null;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedFromSlotIconRotation = 0f;

            if (draggedItem != null) { FinishDragAndPool(draggedItem); }
            _ghostPresenter?.End();
            _highlightController?.HideAll();
            SetAllGridSlotsRaycast(false);
            ForceRefresh();
            return false;
        }
        else
        {
            bool moved = sourceController.MoveItem(item, targetX, targetY);
            if (moved)
            {
                _isDragging = false;
                _draggedItem = null;
                if (draggedItem != null) { FinishDragAndPool(draggedItem); }
                EndDragComplete();
                ForceRefresh();
            }
            return moved;
        }
    }

    // Кросс-грид: проверки циклов
    if (targetGrid == GridType.Backpack && item.Data?.IsBackpack == true)
    {
        bool isEquippedBackpack = _backpackSlot != null && _backpackSlot.EquippedItem == item;
        if (isEquippedBackpack) return false;

        if (_backpackSlot != null && _backpackSlot.EquippedItem != null)
        {
            if (DraggedContainsTarget(item, _backpackSlot.EquippedItem.InstanceID)) return false;
        }
    }

    if (targetGrid == GridType.Container
        && _backpackManager.OpenWindows.Any(w => w != null && w.Controller == targetController
            && w.BackpackInstanceID == item.InstanceID.ToString()))
    {
        return false;
    }

    if (targetGrid == GridType.Container)
{
    InventoryItem targetBackpack = null;
    var targetWindow = _backpackManager.OpenWindows.FirstOrDefault(w => w.Controller == targetController);
    if (targetWindow != null && uint.TryParse(targetWindow.BackpackInstanceID, out uint targetId))
    {
        targetBackpack = FindItemByInstanceId(targetId);
    }
    if (targetBackpack != null && DraggedContainsTarget(item, targetBackpack.InstanceID))
    {
        return false;
    }
    
    // ⬇️ НОВАЯ ПРОВЕРКА: Блокировка превышения лимита вложенности
    if (targetBackpack != null && item.Data.IsBackpack && WouldExceedMaxNestingDepth(item, targetBackpack))
    {
        Debug.Log($"[NESTING-BLOCK] Cannot place '{item.Data.DisplayName}' into '{targetBackpack.Data.DisplayName}' — max nesting depth exceeded.");
        return false;
    }
}

    if (item.Data != null && item.Data.IsBackpack && _backpackManager.IsBackpackOpenInCache(item.InstanceID.ToString()))
        CloseAllWindowsForBackpack(item);

    // Размещение в другой контроллер
    if (_dragItemRemoved)
    {
        bool placed = targetController.PlaceExistingItem(item, targetX, targetY);
        if (placed)
        {
            _isDragging = false;
            _draggedItem = null;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedFromSlotIconRotation = 0f;
            _dragItemRemoved = false;

            if (draggedItem != null) { FinishDragAndPool(draggedItem); }
            EndDragComplete();
            ForceRefresh();
            return true;
        }

        if (sourceController != null)
        {
            bool restored = sourceController.PlaceExistingItem(item, draggedItem.X, draggedItem.Y);
            if (!restored) restored = sourceController.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
            if (!restored) TryPlaceInAnyPlayerGrid(item);
        }
        else
        {
            TryPlaceInAnyPlayerGrid(item);
        }

        _dragItemRemoved = false;
        _isDragging = false;
        _draggedItem = null;
        _draggedFromEquipmentSlot = null;
        _draggedFromSlotItem = null;
        _draggedFromSlotIconRotation = 0f;

        if (draggedItem != null) { FinishDragAndPool(draggedItem); }
        _ghostPresenter?.End();
        _highlightController?.HideAll();
        SetAllGridSlotsRaycast(false);
        ForceRefresh();
        return false;
    }

    int originX = draggedItem.X;
    int originY = draggedItem.Y;

    if (!sourceController.RemoveItem(item))
        return false;

    bool success = targetController.PlaceExistingItem(item, targetX, targetY);

    if (!success)
    {
        bool restored = sourceController.PlaceExistingItem(item, originX, originY);
        if (!restored) restored = sourceController.PlaceExistingItemInFirstFreeSlot(item);
        if (!restored) restored = TryPlaceInAnyPlayerGrid(item);
    }

    if (success)
    {
        _isDragging = false;
        _draggedItem = null;
        if (draggedItem != null) { FinishDragAndPool(draggedItem); }
        EndDragComplete();
        ForceRefresh();
    }
    else
    {
        _dragItemRemoved = false;
        _isDragging = false;
        _draggedItem = null;

        if (draggedItem != null) { FinishDragAndPool(draggedItem); }
        _ghostPresenter?.End();
        _highlightController?.HideAll();
        SetAllGridSlotsRaycast(false);
        ForceRefresh();
    }

    return success;
}
/// <summary>
/// Ищет предмет для свапа по визуальному пересечению UI прямоугольников (Ghost и UI_Item).
/// Полностью отвязывает логику свапа от позиции курсора и ячеек сетки.
/// </summary>
/// <summary>
/// Ищет предмет для свапа по визуальному пересечению UI прямоугольников (Ghost и UI_Item).
/// Полностью отвязывает логику свапа от позиции курсора и ячеек сетки.
/// </summary>
/// <summary>
/// Ищет предмет для свапа по визуальному пересечению UI прямоугольников (Ghost и UI_Item).
/// Полностью отвязывает логику свапа от позиции курсора и ячеек сетки.
/// </summary>
        /// <summary>
        /// Ищет предмет для свапа по визуальному пересечению UI прямоугольников (Ghost и UI_Item).
        /// Полностью отвязывает логику свапа от позиции курсора и ячеек сетки.
        /// АУДИТ-ФИКС: итерирует _uiSync.ActiveItems (реальный источник правды),
        /// а НЕ локальный _activeItems который всегда пуст.
        /// </summary>
               /// <summary>
/// Ищет предмет для свапа по визуальному пересечению UI прямоугольников (Ghost и UI_Item).
/// Полностью отвязывает логику свапа от позиции курсора и ячеек сетки.
/// ЕДИНСТВЕННЫЙ критерий — пересечение отрисованных областей иконок.
/// Цели-фильтры: развёрнутые рюкзаки и рюкзаки, содержащие тащимый предмет, не участвуют.
/// </summary>
// K_InventoryUI.cs — ПОЛНАЯ ЗАМЕНА метода FindBestSwapTargetByUIRect
public InventoryItem FindBestSwapTargetByUIRect(InventoryItem draggedItem)
{
    if (draggedItem == null) return null;
    if (_ghostPresenter == null) return null;
    if (!_ghostPresenter.TryGetVisualScreenBounds(out Vector2 gMin, out Vector2 gMax)) return null;

    Vector2 gCenter = (gMin + gMax) * 0.5f;
    var cam = RootCanvasCamera;
    var activeItems = _uiSync?.ActiveItems;
    if (activeItems == null || activeItems.Count == 0) return null;

    float areaG = (gMax.x - gMin.x) * (gMax.y - gMin.y);
    if (areaG <= 0f) return null;

    // ═══ КОРНЕВОЙ ФИКС: Определяем верхнее окно под центром ghost'а.
    // Предметы из других (нижних) окон не могут быть целями свапа. ═══
    K_ContainerWindow topmostWindow = null;
    if (EventSystem.current != null)
    {
        var pointerData = new PointerEventData(EventSystem.current) { position = (Vector3)gCenter };
        var results = new List<RaycastResult>();
        EventSystem.current.RaycastAll(pointerData, results);
        if (results.Count > 0)
        {
            topmostWindow = results[0].gameObject.GetComponentInParent<K_ContainerWindow>();
        }
    }

    InventoryItem bestItem = null;
    float bestScore = -1f;

    foreach (var kvp in activeItems)
    {
        var ui = kvp.Value;
        if (ui == null || ui.Item == null || ui.Item == draggedItem) continue;
        if (!ui.gameObject.activeInHierarchy) continue;

        var candidate = ui.Item;
        if (candidate.Data == null) continue;

        // ═══ ФИКС: Если определено верхнее окно, пропускаем предметы из других окон ═══
        if (topmostWindow != null)
        {
            var candidateWindow = ui.GetComponentInParent<K_ContainerWindow>();
            if (candidateWindow != null && candidateWindow != topmostWindow) continue;
        }

        // Развёрнутый рюкзак — никогда не цель свапа.
        if (candidate.Data.IsBackpack && !candidate.IsFolded) continue;
        // Рюкзак, содержащий тащимый предмет, — не цель свапа (матрёшка).
        if (candidate.Data.IsBackpack && candidate.ContainsDescendant(draggedItem.InstanceID)) continue;

        if (!ui.TryGetVisualScreenBounds(cam, out Vector2 bMin, out Vector2 bMax)) continue;

        float ix = Mathf.Min(gMax.x, bMax.x) - Mathf.Max(gMin.x, bMin.x);
        float iy = Mathf.Min(gMax.y, bMax.y) - Mathf.Max(gMin.y, bMin.y);
        if (ix <= 0f || iy <= 0f) continue;

        float overlap = ix * iy;
        float areaB = (bMax.x - bMin.x) * (bMax.y - bMin.y);
        float minArea = Mathf.Min(areaG, areaB);

        Vector2 bCenter = (bMin + bMax) * 0.5f;
        bool centerGinB = gCenter.x >= bMin.x && gCenter.x <= bMax.x && gCenter.y >= bMin.y && gCenter.y <= bMax.y;
        bool centerBinG = bCenter.x >= gMin.x && bCenter.x <= gMax.x && bCenter.y >= gMin.y && bCenter.y <= gMax.y;

        if (!centerGinB && !centerBinG && overlap < minArea * 0.1f) continue;

        float score = overlap
            + (centerBinG ? 1e6f : 0f)
            + (centerGinB ? 1e6f : 0f)
            - Vector2.Distance(gCenter, bCenter) * 0.01f;

        if (score > bestScore) { bestScore = score; bestItem = candidate; }
    }

    return bestItem;
}      private bool TrySwapItems(UI_Item draggedUI, GridType targetGrid, InventoryItem targetItem, int dropX, int dropY)
{
    if (draggedUI?.Item == null || targetItem == null) return false;
    if (!_isDragging || _draggedItem != draggedUI) return false;

    var item = draggedUI.Item;
    if (item == targetItem) return false;

    var targetController = (targetGrid == GridType.Container && _dropTargetController != null)
        ? _dropTargetController : GetControllerForGrid(targetGrid);

    var sourceController = (_dragOriginGridType == GridType.Container && draggedUI.BoundController != null)
        ? draggedUI.BoundController
        : GetControllerForGrid(_dragOriginGridType);

    if (targetController == null || sourceController == null) return false;

    if (targetItem.Data != null && targetItem.Data.IsBackpack && !targetItem.IsFolded)
        return false;

    if (item.Data != null && item.Data.IsBackpack)
    {
        if (DraggedContainsTarget(item, targetItem.InstanceID)) return false;
    }
    if (targetItem.Data != null && targetItem.Data.IsBackpack)
    {
        if (DraggedContainsTarget(targetItem, item.InstanceID)) return false;
    }

    if (_backpackSlot != null && _backpackSlot.EquippedItem == item && targetController == _backpackController)
        return false;

    // ФИКС: Единый источник правды для координат targetItem
    var (tX, tY) = targetController.FindItemRootPosition(targetItem.InstanceID);
    if (tX == -1) return false;

    // ФИКС: Единый источник правды для source-позиции вместо _dragOriginX/Y
    var (sX, sY) = sourceController.FindItemRootPosition(item.InstanceID);
    if (sX == -1) return false;

    var itemSize = item.CurrentSize;
    if (tX < 0 || tY < 0) return false;
    if (tX + itemSize.x > targetController.Width) return false;
    if (tY + itemSize.y > targetController.Height) return false;

    var allTargets = new List<InventoryItem>(4);
    for (int dy = 0; dy < itemSize.y; dy++)
    {
        for (int dx = 0; dx < itemSize.x; dx++)
        {
            var occ = targetController.GetItemAt(tX + dx, tY + dy);
            if (occ != null && occ != item && !allTargets.Contains(occ))
                allTargets.Add(occ);
        }
    }

    if (allTargets.Count == 0) return false;

    for (int dy = 0; dy < itemSize.y; dy++)
    {
        for (int dx = 0; dx < itemSize.x; dx++)
        {
            var occ = targetController.GetItemAt(tX + dx, tY + dy);
            if (occ == null || occ == item) continue;
            if (!allTargets.Contains(occ)) return false;
        }
    }

    foreach (var t in allTargets)
    {
        if (t.Data != null && t.Data.IsBackpack && !t.IsFolded) return false;

        if (item.Data != null && item.Data.IsBackpack)
        {
            if (DraggedContainsTarget(item, t.InstanceID)) return false;
        }
        if (t.Data != null && t.Data.IsBackpack)
        {
            if (DraggedContainsTarget(t, item.InstanceID)) return false;
        }
    }

    if (sX < 0 || sY < 0) return false;
    if (sX + itemSize.x > sourceController.Width) return false;
    if (sY + itemSize.y > sourceController.Height) return false;

    var savedStates = new List<(InventoryItem item, int rootX, int rootY, int angle)>(allTargets.Count);
    foreach (var t in allTargets)
    {
        // ФИКС: Замена ручных циклов на FindItemRootPosition
        var (rx, ry) = targetController.FindItemRootPosition(t.InstanceID);
        if (rx == -1) return false;
        savedStates.Add((t, rx, ry, t.RotationAngle));
    }

    // Phase 1: Удаляем все targets из targetController.
    foreach (var t in allTargets)
    {
        if (!targetController.RemoveItem(t))
        {
            foreach (var s in savedStates)
            {
                if (targetController.GetItemAt(s.rootX, s.rootY) == null)
                    targetController.PlaceExistingItem(s.item, s.rootX, s.rootY);
            }
            return false;
        }
    }

    bool itemPlaced = targetController.PlaceExistingItem(item, tX, tY);

    if (!itemPlaced)
    {
        foreach (var s in savedStates)
        {
            s.item.RestoreRotationState(s.angle);
            targetController.PlaceExistingItem(s.item, s.rootX, s.rootY);
        }
        return false;
    }

    var placedTargets = new List<(InventoryItem item, InventoryController ctrl)>(allTargets.Count);
    bool allPlaced = true;

    foreach (var s in savedStates)
    {
        var t = s.item;
        bool placed = false;

        if (InventoryValidationService.GridSpaceCheckIgnoring(sourceController, t, sX, sY, item))
        {
            if (sourceController.PlaceExistingItem(t, sX, sY))
            {
                placedTargets.Add((t, sourceController));
                placed = true;
            }
        }

        if (!placed && t.Data != null && t.Data.CanRotate)
        {
            int savedAngle = t.RotationAngle;
            t.Rotate();
            if (InventoryValidationService.GridSpaceCheckIgnoring(sourceController, t, sX, sY, item))
            {
                if (sourceController.PlaceExistingItem(t, sX, sY))
                {
                    placedTargets.Add((t, sourceController));
                    placed = true;
                }
                else
                {
                    t.RestoreRotationState(savedAngle);
                }
            }
            else
            {
                t.Rotate();
                if (InventoryValidationService.GridSpaceCheckIgnoring(sourceController, t, sX, sY, item))
                {
                    if (sourceController.PlaceExistingItem(t, sX, sY))
                    {
                        placedTargets.Add((t, sourceController));
                        placed = true;
                    }
                    else
                    {
                        t.RestoreRotationState(savedAngle);
                    }
                }
                else
                {
                    t.RestoreRotationState(savedAngle);
                }
            }
        }

        if (!placed)
        {
            placed = TryPlaceNearPosition(sourceController, t, sX, sY);
            if (placed)
                placedTargets.Add((t, sourceController));
        }

        if (!placed)
        {
            if (sourceController.PlaceExistingItemInFirstFreeSlot(t))
            {
                placedTargets.Add((t, sourceController));
                placed = true;
            }
        }

        if (!placed)
        {
            t.RestoreRotationState(s.angle);
            allPlaced = false;
            break;
        }
    }

    if (!allPlaced)
    {
        foreach (var pt in placedTargets)
        {
            pt.ctrl.RemoveItem(pt.item);
        }

        targetController.RemoveItem(item);

        foreach (var s in savedStates)
        {
            s.item.RestoreRotationState(s.angle);
            targetController.PlaceExistingItem(s.item, s.rootX, s.rootY);
        }

        item.RestoreRotationState(_dragOriginRotationAngle);
        if (item.Data != null && item.Data.CanFold && item.IsFolded != _dragOriginFolded)
            item.SetFolded(_dragOriginFolded);
        if (!sourceController.PlaceExistingItem(item, sX, sY))
        {
            if (!sourceController.PlaceExistingItemInFirstFreeSlot(item))
                TryPlaceInAnyPlayerGrid(item);
        }
        return false;
    }

    _dragItemRemoved = false;
    FinishDragAndPool(draggedUI);
    EndDragComplete();
    ForceRefresh();
    return true;
}

// Legacy, использовать TryPlaceItemFromEquipmentSlotAtomic; retained compatibility API per iteration 8d contract.
[System.Obsolete("Только для посадки в ПУСТУЮ клетку. Swap идёт через " +
                 "InventoryTransactionService.TrySwapEquipmentItemWithGridItem.")]
public bool TryPlaceItemFromEquipmentSlot(GridType targetGrid, int targetX, int targetY,
    InventoryController boundController = null)
{
    if (_draggedFromEquipmentSlot == null || _draggedFromSlotItem == null) return false;
    if (!_isDragging) return false;

    var item = _draggedFromSlotItem;

    if (targetGrid == GridType.Backpack && item.Data?.IsBackpack == true)
    {
        bool isEquippedBackpack = _backpackSlot != null && _backpackSlot.EquippedItem == item;
        if (isEquippedBackpack) return false;
    }

    var targetController = boundController ??
        ((targetGrid == GridType.Container && _dropTargetController != null)
            ? _dropTargetController : GetControllerForGrid(targetGrid));
    if (targetController == null || targetController.IsDisposed) return false;

#if UNITY_EDITOR
    {
        var cellOcc = targetController.GetItemAt(targetX, targetY);
        Debug.Log($"[TPSI-AUDIT] enter: dragged id={item.InstanceID} size={item.CurrentSize} " +
                  $"rot={item.RotationAngle} grid={targetGrid} tx={targetX} ty={targetY} " +
                  $"targetAtCell id={(cellOcc != null ? cellOcc.InstanceID.ToString() : "null")}");
    }
#endif

    // Cycle-guard для рюкзаков.
    if (item.Data != null && item.Data.IsBackpack)
    {
        if (targetController == _backpackController) return false;

        if (targetGrid == GridType.Container)
        {
            var targetWindow = _backpackManager.OpenWindows.FirstOrDefault(
                w => w != null && w.Controller == targetController);
            if (targetWindow != null && uint.TryParse(targetWindow.BackpackInstanceID, out uint targetOwnerId))
            {
                if (item.InstanceID == targetOwnerId || DraggedContainsTarget(item, targetOwnerId))
                {
                    return false;
                }
            }
        }
    }

    // ═══ ЕДИНСТВЕННЫЙ разрешённый сценарий: постановка в СВОБОДНУЮ клетку. ═══
    if (!targetController.CanPlaceItem(item, targetX, targetY))
    {
#if UNITY_EDITOR
        Debug.LogError(
            $"[TPSI-AUDIT] REJECTED: cell ({targetX},{targetY}) occupied. " +
            "Swap path must be routed via InventoryTransactionService.TrySwapEquipmentItemWithGridItem.");
#endif
        return false;
    }

    if (targetGrid == GridType.Container && ActiveBackpackContainer != null
        && ActiveBackpackContainer.InstanceID == item.InstanceID
        && targetController == ActiveContainerController)
    {
        return false;
    }

    if (_draggedFromEquipmentSlot.SlotType == EquipmentSlotType.Backpack
        && item.Data != null && item.Data.IsBackpack)
    {
        OnBackpackUnequipped();
    }

    if (targetController.PlaceExistingItem(item, targetX, targetY))
    {
        _draggedFromEquipmentSlot.SetEquippedItem(null);
#if UNITY_EDITOR
        Debug.Log($"[TPSI-AUDIT] path: RemoveItem→PlaceExistingItem OK at ({targetX},{targetY})");
#endif
        ClearEquipmentDragState();
        ForceRefresh();
        return true;
    }

#if UNITY_EDITOR
    Debug.LogError($"[TPSI-AUDIT] FAIL: PlaceExistingItem at ({targetX},{targetY}) returned false " +
                   "after CanPlaceItem returned true — geometry desync.");
#endif

    if (_draggedFromEquipmentSlot.SlotType == EquipmentSlotType.Backpack
        && item.Data != null && item.Data.IsBackpack)
    {
        OnBackpackEquipped(item);
    }
    return false;
}
        public bool TryEquipItemFromSlot(K_EquipmentSlotUI sourceSlot, K_EquipmentSlotUI targetSlot)
        {
            if (sourceSlot?.EquippedItem == null || targetSlot == null || sourceSlot == targetSlot) return false;

            var item = sourceSlot.EquippedItem;
            if (!ValidateEquipItem(item, targetSlot)) return false;

            // Если целевой слот занят — пробуем swap между слотами
            if (targetSlot.IsOccupied && targetSlot.EquippedItem != null)
            {
                var oldTargetItem = targetSlot.EquippedItem;

                // Проверяем: может ли старый предмет целевого слота поместиться в исходный слот?
                if (sourceSlot.ValidateItemForSlot(oldTargetItem))
                {
                    // Swap: старый предмет → исходный слот
                    sourceSlot.SetEquippedItem(oldTargetItem);
                    targetSlot.SetEquippedItem(null);
                }
                else
                {
                    // Старый предмет не подходит для исходного слота — пробуем unequip в инвентарь.
                    // Наследуем разворот нового предмета перед размещением в сетке.
                    oldTargetItem.RestoreRotationState(item.RotationAngle);
                    targetSlot.Unequip();
                    if (targetSlot.IsOccupied) return false; // Не получилось разместить
                }
            }
            else
            {
                // Целевой слот пуст — просто убираем из исходного
                sourceSlot.SetEquippedItem(null);
            }

            targetSlot.OnDropItem(item);

            // Хук: рюкзак экипирован из другого слота
            if (targetSlot.SlotType == EquipmentSlotType.Backpack && item.Data?.IsBackpack == true)
                OnBackpackEquipped(item);
            // Хук: рюкзак убран из слота при swap
            if (sourceSlot.SlotType == EquipmentSlotType.Backpack && !targetSlot.ValidateItemForSlot(sourceSlot.EquippedItem))
                OnBackpackUnequipped();

            return true;
        }

        /// <summary>
        /// ФИКС #3 + #6 + БАГ ИСЧЕЗНОВЕНИЯ: При отмене drag — вернуть предмет на исходную позицию.
        ///
        /// КРИТИЧЕСКИЙ ФИКС: OnDrop и OnEndDrag оба могут завершать drag;
        /// повторный cleanup не должен откатывать уже успешный перенос.
        /// Раньше EndDragComplete немедленно возвращал предмет через TryPlaceItem,
        /// который создавал НОВЫЙ InventoryItem (новый InstanceID). Затем OnDrop
        /// пытался оперировать ОРИГИНАЛЬНЫМ item'ом (которого больше не было в
        /// _positionCache) → MoveItem/RemoveItem silent-fail → предмет терялся.
        ///
        /// Решение (Фаза 2+3): транзакционный drag через InventoryTransactionService.
        /// Предмет НЕ удаляется из контроллера в начале drag, а все операции
        /// (move/swap/drop-into-backpack/equip) выполняются атомарно. Если
        /// транзакция падает — данные откатываются автоматически, предмет
        /// остаётся на старом месте. EndDragComplete только очищает UI-стейт.
        /// </summary>
        /// /// <summary> Помещает предмет в слот экипировки. Если слот занят, меняет их местами. </summary>
       public void EquipItemFromContextMenu(InventoryItem item)
{
    if (item == null) return;

    EquipmentSlotType targetSlotType;
    if (item.Type == ItemType.Armor)
    {
        targetSlotType = item.Data.EquipAffinity switch
        {
            EquipAffinity.BodyArmor => EquipmentSlotType.BodyArmor,
            EquipAffinity.HeadGear => EquipmentSlotType.HeadGear,
            _ => EquipmentSlotType.Melee // fallback
        };
    }
    else
    {
        targetSlotType = item.Type switch
        {
            ItemType.Weapon => item.Data.IsPistol ? EquipmentSlotType.Pistol : EquipmentSlotType.Primary,
            ItemType.Backpack => EquipmentSlotType.Backpack,
            _ => EquipmentSlotType.Melee
        };
    }

    K_EquipmentSlotUI targetSlot = GetEquipmentSlotByType(targetSlotType);
    if (targetSlot == null) return;

    var (originGrid, x, y) = FindItemLocation(item);
    if (originGrid == null) return;

    var sourceController = GetControllerForGrid(originGrid.Value);
    if (sourceController == null) return;

    if (targetSlot.IsOccupied && targetSlot.EquippedItem != null)
    {
        var oldItem = targetSlot.EquippedItem;
        sourceController.RemoveItem(item);
        targetSlot.SetEquippedItem(item);

        oldItem.RestoreRotationState(0);
        if (!sourceController.PlaceExistingItem(oldItem, x, y))
        {
            if (!sourceController.PlaceExistingItemInFirstFreeSlot(oldItem))
            {
                TryPlaceInAnyPlayerGrid(oldItem);
            }
        }

        if (targetSlot.SlotType == EquipmentSlotType.Backpack)
            OnBackpackEquipped(item);

        ForceRefresh();
    }
    else
    {
        sourceController.RemoveItem(item);
        targetSlot.SetEquippedItem(item);
        if (targetSlot.SlotType == EquipmentSlotType.Backpack)
            OnBackpackEquipped(item);
        ForceRefresh();
    }
}
 public void EndDragComplete(bool restoreOriginState = false)
{
    if (_isReturningAllItemsToPool) return;

    var equipmentSourceSlot = _draggedFromEquipmentSlot;
    _isDragging = false;
    _highlightController?.HideAll();
    _ghostPresenter?.End();
    SetAllGridSlotsRaycast(false);

    // ═══ Откат черновых мутаций (R / F) — только если есть что откатывать ═══
    var originItem = _draggedItem != null ? _draggedItem.Item : _draggedFromSlotItem;
    bool hadOrigin = originItem != null;

    if (restoreOriginState && originItem != null)
    {
        originItem.RestoreRotationState(_dragOriginRotationAngle);
        if (originItem.Data != null && originItem.Data.CanFold
            && originItem.IsFolded != _dragOriginFolded)
            originItem.SetFolded(_dragOriginFolded);
    }

    equipmentSourceSlot?.MarkDragFinished();

    if (_draggedItem != null)
    {
        _draggedItem.IsBeingDragged = false;
        var cg = _draggedItem.GetComponent<CanvasGroup>();
        if (cg != null)
        {
            cg.alpha = 1f;
            cg.blocksRaycasts = true;
            cg.interactable = true;
        }

        // ═══ БАГ 3 ФИКС (профилактика И6): пулим дубликаты того же InstanceID
        // ДО сброса _draggedItem. Если в _activeItems есть второй UI_Item с тем же
        // Item, он стал orphan — ReturnToPool его уберёт. ═══
        _uiSync?.ReturnDuplicatesByItem(_draggedItem.Item, _draggedItem);
    }

    _dragItemRemoved = false;
    _draggedItem = null;
    _draggedFromEquipmentSlot = null;
    _draggedFromSlotItem = null;
    _draggedFromSlotIconRotation = 0f;
    _dropTargetController = null;

    if (_equipDragCleanupCoroutine != null)
    {
        StopCoroutine(_equipDragCleanupCoroutine);
        _equipDragCleanupCoroutine = null;
    }

    _dragOriginGridType = GridType.Pockets;
    _dragOriginX = -1;
    _dragOriginY = -1;
    _dragOriginRotationAngle = 0;
    _dragOriginFolded = false;

    UpdateBackpackManagerDragState();

    // ═══ БАГ 1 ФИКС: лишний ForceRefresh после EndDragComplete(true)
    // из OnEndDrag, когда OnDrop уже вызвал EndDragComplete(false)
    // и обнулил _draggedItem. Обновляем только если реально был
    // откат черновых мутаций или есть отложенный рефреш. ═══
    bool needRefresh = _pendingRefresh;
    SynchronizeGroundLoot();
    if (restoreOriginState && hadOrigin)
        needRefresh = true;
    if (needRefresh)
        ForceRefresh();
}
     public void EndDragFromEquipmentSlot()
{
    // A successful OnDrop has already cleared the session. Any remaining
    // equipment session is a cancelled drop, including release over a background.
    if (IsDraggingFromEquipmentSlot)
        EndDragComplete(true);
}

public void ClearEquipmentDragState(bool restoreOriginState = false)
{
    if (!IsDraggingFromEquipmentSlot) return;
    EndDragComplete(restoreOriginState);
}
        /// <summary>
        /// Вызывается из OnDrop (сетка) при успешном дропе предмета из слота экипировки.
        /// </summary>
        public void FinalizeEquipSlotDrag()
{
    if (_equipDragCleanupCoroutine != null)
    {
        StopCoroutine(_equipDragCleanupCoroutine);
        _equipDragCleanupCoroutine = null;
    }

    if (_draggedFromEquipmentSlot != null &&
        _draggedFromEquipmentSlot.SlotType == EquipmentSlotType.Backpack)
    {
        OnBackpackUnequipped();
    }

    // ═══ H5 УСИЛЕННЫЙ ФИКС: safety-net переведён в error-уровень. ═══
    // Если после успешной транзакции source slot всё ещё держит предмет —
    // это расхождение highlight/transaction, а не штатное состояние.
    // Clean — no-op; dirty — громкая ошибка и принудительная очистка.
    if (_draggedFromEquipmentSlot != null &&
        _draggedFromSlotItem != null &&
        ReferenceEquals(_draggedFromEquipmentSlot.EquippedItem, _draggedFromSlotItem))
    {
        Debug.LogError(
            $"[FinalizeEquipSlotDrag] SOURCE SLOT STILL HELD '{_draggedFromSlotItem.Data?.DisplayName}' " +
            $"(id={_draggedFromSlotItem.InstanceID}) after successful equip transaction. " +
            "This is highlight/transaction desync — highlight promised drop was impossible. " +
            "Forcing slot clear to prevent duplication.");
        _draggedFromEquipmentSlot.SetEquippedItem(null);
    }

    EndDragComplete();
    ForceRefresh();

    if (_pendingRefresh) ForceRefresh();
}

       public bool ValidateEquipItem(InventoryItem item, K_EquipmentSlotUI slot)
{
    if (item?.Data == null) return false;

    return slot.SlotType switch
    {
        EquipmentSlotType.Primary => item.Type == ItemType.Weapon && !item.Data.IsPistol && !item.Data.IsMelee,
        EquipmentSlotType.Pistol => item.Type == ItemType.Weapon && item.Data.IsPistol,
        EquipmentSlotType.Melee => item.Data.IsMelee,
        EquipmentSlotType.Backpack => item.Data.IsBackpack,
        EquipmentSlotType.BodyArmor => item.Type == ItemType.Armor && item.Data.EquipAffinity == EquipAffinity.BodyArmor,
        EquipmentSlotType.HeadGear => item.Type == ItemType.Armor && item.Data.EquipAffinity == EquipAffinity.HeadGear,
        _ => false
    };
}

        #endregion

        #region Event Handling

       private void SubscribeToEvents()
{
    _onInventoryChangedHandler = RefreshAll;
    _onItemPlacedHandler = (item, x, y) => RefreshAll();
    _onItemChangedHandler = _ => RefreshAll();

    if (_pocketsController != null)
    {
        _pocketsController.OnInventoryChanged += _onInventoryChangedHandler;
        _pocketsController.OnItemPlaced += _onItemPlacedHandler;
        _pocketsController.OnItemRemoved += _onItemChangedHandler;
        _pocketsController.OnItemRotated += _onItemChangedHandler;
        _pocketsController.OnItemQuantityChanged += _onItemChangedHandler;
    }

    if (_pocket2Controller != null)
    {
        _pocket2Controller.OnInventoryChanged += _onInventoryChangedHandler;
        _pocket2Controller.OnItemPlaced += _onItemPlacedHandler;
        _pocket2Controller.OnItemRemoved += _onItemChangedHandler;
        _pocket2Controller.OnItemRotated += _onItemChangedHandler;
        _pocket2Controller.OnItemQuantityChanged += _onItemChangedHandler;
    }

    if (_backpackController != null)
    {
        _backpackController.OnInventoryChanged += _onInventoryChangedHandler;
        _backpackController.OnItemPlaced += _onItemPlacedHandler;
        _backpackController.OnItemRemoved += _onItemChangedHandler;
        _backpackController.OnItemRotated += _onItemChangedHandler;
        _backpackController.OnItemQuantityChanged += _onItemChangedHandler;
    }
}

        private void UnsubscribeFromEvents()
{
    if (_pocketsController != null)
    {
        _pocketsController.OnInventoryChanged -= _onInventoryChangedHandler;
        _pocketsController.OnItemPlaced -= _onItemPlacedHandler;
        _pocketsController.OnItemRemoved -= _onItemChangedHandler;
        _pocketsController.OnItemRotated -= _onItemChangedHandler;
        _pocketsController.OnItemQuantityChanged -= _onItemChangedHandler;
    }

    if (_pocket2Controller != null)
    {
        _pocket2Controller.OnInventoryChanged -= _onInventoryChangedHandler;
        _pocket2Controller.OnItemPlaced -= _onItemPlacedHandler;
        _pocket2Controller.OnItemRemoved -= _onItemChangedHandler;
        _pocket2Controller.OnItemRotated -= _onItemChangedHandler;
        _pocket2Controller.OnItemQuantityChanged -= _onItemChangedHandler;
    }

    if (_backpackController != null)
    {
        _backpackController.OnInventoryChanged -= _onInventoryChangedHandler;
        _backpackController.OnItemPlaced -= _onItemPlacedHandler;
        _backpackController.OnItemRemoved -= _onItemChangedHandler;
        _backpackController.OnItemRotated -= _onItemChangedHandler;
        _backpackController.OnItemQuantityChanged -= _onItemChangedHandler;
    }
}
      

        #endregion


        #region Public API

    public bool IsAtMaxNestingDepth(InventoryItem item)
{
    if (item == null || !item.Data.IsBackpack) return false;
    int depth = GetBackpackNestingDepth(item);
    return depth >= MAX_BACKPACK_NESTING_DEPTH;
}

   public bool WouldExceedMaxNestingDepth(InventoryItem itemToPlace, InventoryItem targetBackpack)
{
    if (itemToPlace == null || !itemToPlace.Data.IsBackpack || targetBackpack == null)
        return false;

    // Свёрнутые рюкзаки не создают новых переносных сеток
    if (itemToPlace.IsFolded) return false;

    // Делегируем в единственный источник правды
    return !_backpackManager.CanPlaceUnfoldedBackpack(targetBackpack, itemToPlace, out _);
}
        public InventoryController GetControllerForGrid(GridType gridType) => gridType switch
        {
            GridType.Pockets => _pocketsController,
            GridType.Pocket2 => _pocket2Controller,
            GridType.Backpack => _backpackController,
            GridType.Container => ActiveContainerController,
            _ => null
        };

        /// <summary>
        /// ФИКС БАГ "предметы бесследно исчезают": Пробует разместить item в ЛЮБОЙ
        /// сетке игрока (Pockets, Pocket2, Backpack). Возвращает true если хотя бы
        /// в одной сетке нашлось место.
        ///
        /// Используется как LAST-RESORT fallback в:
        /// - CancelDrag: когда TryPlaceItemInFirstFreeSlot не сработал.
        /// - StartDrag orphan-handling: когда возвращаем "зависший" предмет.
        /// - TryPlaceItem/TrySwapItems: когда восстановление на исходную позицию не удалось.
        ///
        /// ВАЖНО: НЕ пытаемся разместить в Container (это содержимое рюкзака,
        /// может создать цикл). Только в сетки самого игрока.
        /// </summary>
        private bool TryPlaceInAnyPlayerGrid(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;

            // Порядок: Pockets → Pocket2 → Backpack (Container НЕ трогаем — может быть цикл)
            var controllers = new[]
            {
                    _pocketsController,
                    _pocket2Controller,
                    HasEquippedBackpack ? _backpackController : null
                };

            foreach (var ctrl in controllers)
            {
                if (ctrl == null) continue;
                try
                {
                    if (ctrl.PlaceExistingItemInFirstFreeSlot(item))
                    {
                        Debug.Log($"[ITEM-LOSS-PREVENTION] Placed '{item.Data.DisplayName}' " +
                                  $"in grid '{ctrl.SaveID}' as fallback.");
                        return true;
                    }
                }
                catch (System.Exception ex)
                {
                    Debug.LogError($"[ITEM-LOSS-PREVENTION] Exception placing item in " +
                                   $"grid '{ctrl.SaveID}': {ex.Message}");
                }
            }

            return false;
        }
        // v12: Восстановление состояния предмета (поворот + fold) на момент старта drag
        // реализовано инлайн в CancelDrag/TrySwapItems через item.RestoreRotationState
        // + item.SetFolded(...). Отдельный helper-метод удалён в Фазе 4.

        public int GetGridWidth(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_COLUMNS;
            if (gridType == GridType.Pocket2) return POCKET_COLUMNS;
            if (gridType == GridType.Backpack) return _currentBackpackCols; // ФИКС БАГ #4
            if (gridType == GridType.Container) return _currentContainerCols; // ФИКС БАГ #2
            var c = GetControllerForGrid(gridType);
            return c?.Width ?? 0;
        }

        public int GetGridHeight(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_ROWS;
            if (gridType == GridType.Pocket2) return POCKET_ROWS;
            if (gridType == GridType.Backpack) return _currentBackpackRows; // ФИКС БАГ #4
            if (gridType == GridType.Container) return _currentContainerRows; // ФИКС БАГ #2
            var c = GetControllerForGrid(gridType);
            return c?.Height ?? 0;
        }
        // >>> FIX unfold-overflow: видимый размер сетки <<<"
        private (int width, int height) GetEffectiveGridSize(GridType gridType, InventoryController controller)
        {
            if (IsGroundLootController(controller)) return (controller.Width, controller.Height);
            int cw = controller != null ? controller.Width : 0;
            int ch = controller != null ? controller.Height : 0;
            int uw = GetGridWidth(gridType);
            int uh = GetGridHeight(gridType);
            int w = (cw > 0 && uw > 0) ? Mathf.Min(cw, uw) : Mathf.Max(cw, uw);
            int h = (ch > 0 && uh > 0) ? Mathf.Min(ch, uh) : Mathf.Max(ch, uh);
            return (w, h);
        }
        // >>> END FIX <<<

        /// <summary>
        /// ФАЗА 3: Транзакционная экипировка предмета через InventoryTransactionService.
        /// Вызывается из K_EquipmentSlotUI.OnDrop при перетаскивании предмета на слот экипировки.
        /// Вся логика валидации, проверки циклов и swap'а перемещена в TransactionService —
        /// здесь только вызов транзакции и завершение drag.
        /// </summary>
public void OnEquipmentSlotDrop(K_EquipmentSlotUI targetSlot)
{
    if (targetSlot == null) return;
    if (TryHandleCombatItemDrop(targetSlot.EquippedItem)) return;

    if (_draggedItem != null && _draggedItem.Item != null)
    {
        var draggedItem = _draggedItem.Item;

        if (targetSlot.SlotType == EquipmentSlotType.Backpack
            && targetSlot.IsOccupied
            && targetSlot.EquippedItem?.Data?.IsBackpack == true
            && (draggedItem.Data == null || !draggedItem.Data.IsBackpack))
        {
            bool success = InventoryTransactionService.Instance.TryDropIntoEquippedBackpackAtomic(
                _draggedItem, targetSlot, out string dropErr);
            if (success) { EndDragComplete(); ForceRefresh(); }
            else
            {
                Debug.LogWarning($"[OnEquipmentSlotDrop] Drop into equipped backpack failed: {dropErr}");
                EndDragComplete(true);
            }
            return;
        }

        if (IsGroundLootItem(draggedItem) && targetSlot.IsOccupied)
        {
            EndDragComplete(true);
            return;
        }

        bool equipSuccess = InventoryTransactionService.Instance.TryEquipFromDragAtomic(
            _draggedItem, targetSlot, out string errorMessage);
        if (equipSuccess) { EndDragComplete(); ForceRefresh(); }
        else
        {
            Debug.LogWarning($"[OnEquipmentSlotDrop] Equip failed: {errorMessage}");
            EndDragComplete(true);
        }
        return;
    }

    if (IsDraggingFromEquipmentSlot && _draggedFromEquipmentSlot != null)
    {
        var sourceSlot = _draggedFromEquipmentSlot;
        if (sourceSlot == targetSlot)
        {
            ClearEquipmentDragState(true);
            return;
        }
        bool success = InventoryTransactionService.Instance.TrySwapEquipmentSlotsAtomic(
            sourceSlot, targetSlot, out string errorMessage);
        if (success)
        {
            ClearEquipmentDragState();
            ForceRefresh();
        }
        else
        {
            Debug.LogWarning($"[OnEquipmentSlotDrop] Swap slots failed: {errorMessage}");
            ClearEquipmentDragState(true);
        }
    }
}

        #endregion

        #region Hover Highlight

        /// <summary>
        /// TASK 1: Выделение предмета при наведении (hover).
        /// Вызывается из UI_Item.OnPointerEnter.
        /// </summary>
        public void OnItemHovered(UI_Item hoveredItem)
        {
            if (!_enableHoverHighlight) return;
            if (hoveredItem == null || hoveredItem.Item == null) return;
            if (_isDragging) return;

            // Делегируем в DragHighlightController — он хранит _hoveredItem.
            _highlightController?.SetHoveredItem(hoveredItem);
        }

        /// <summary>Снять выделение при уходе курсора.</summary>
        public void OnItemUnhovered(UI_Item unhoveredItem)
        {
            if (unhoveredItem == null) return;
            _highlightController?.ClearHoverIfMatches(unhoveredItem);
        }

        /// <summary>Снять hover со всех предметов. Делегирует в DragHighlightController.</summary>
        private void ClearHover() => _highlightController?.ClearHover();

        #endregion

        #region Drag Outline & Snap Helpers

        /// <summary>
        /// ФИКС #1: Вычисляет top-left позицию предмета из позиции курсора (центр предмета).
        /// </summary>
        public static (int x, int y) CalculateSnapPosition(
            int cursorSlotX, int cursorSlotY, Vector2Int itemSize, int gridWidth, int gridHeight)
        {
            // Cursor = центр предмета. Top-left = cursor - size/2.
            int targetX = cursorSlotX - itemSize.x / 2;
            int targetY = cursorSlotY - itemSize.y / 2;

            // Clamp чтобы предмет не вылезал за сетку
            int maxX = Mathf.Max(0, gridWidth - itemSize.x);
            int maxY = Mathf.Max(0, gridHeight - itemSize.y);

            targetX = Mathf.Clamp(targetX, 0, maxX);
            targetY = Mathf.Clamp(targetY, 0, maxY);

            return (targetX, targetY);
        }
        /// <summary>
        /// Пытается разместить предмет: точная позиция → спиральный поиск → первый свободный слот.
        /// </summary>
        private bool TryPlaceNearPosition(
            InventoryController controller,
            InventoryItem item,
            int targetX, int targetY)
        {
            if (controller == null || item == null) return false;

            // 1. Точная позиция
            if (controller.PlaceExistingItem(item, targetX, targetY))
                return true;

            // 2. Спиральный поиск вокруг целевой позиции
            int maxRadius = Mathf.Max(controller.Width, controller.Height);
            var size = item.CurrentSize;
            for (int radius = 1; radius <= maxRadius; radius++)
            {
                for (int dy = -radius; dy <= radius; dy++)
                {
                    for (int dx = -radius; dx <= radius; dx++)
                    {
                        if (Mathf.Abs(dx) != radius && Mathf.Abs(dy) != radius)
                            continue;

                        int nx = targetX + dx;
                        int ny = targetY + dy;

                        if (nx < 0 || ny < 0 || nx + size.x > controller.Width || ny + size.y > controller.Height)
                            continue;

                        if (controller.PlaceExistingItem(item, nx, ny))
                            return true;
                    }
                }
            }

            // 3. Fallback
            return controller.PlaceExistingItemInFirstFreeSlot(item);
        }
        public (int x, int y) GetAdjustedDropPosition(int slotX, int slotY, Vector2Int itemSize, GridType gridType)
        {
            // ФИКС БАГ #2: Используем реальные размеры UI-сетки, не controller.Width
            int gridW = GetGridWidth(gridType);
            int gridH = GetGridHeight(gridType);
            if (gridW <= 0 || gridH <= 0)
            {
                var controller = GetControllerForGrid(gridType);
                gridW = controller?.Width ?? 0;
                gridH = controller?.Height ?? 0;
            }
            if (gridW <= 0) return (slotX, slotY);
            return CalculateSnapPosition(slotX, slotY, itemSize, gridW, gridH);
        }

        /// <summary>
        /// ═══ БАГ 3 ФИКС: перегрузка с явным boundController ═══
        /// Без этого CalculateSnapPosition использовал глобальные _currentContainerCols/Rows,
        /// которые относятся к АКТИВНОМУ окну-контейнеру. Если игрок drag-and-droпает
        /// в НЕ активное окно (особенно если у окон разные размеры) — Clamp в
        /// CalculateSnapPosition работает с неправильными границами, и предмет
        /// placed на 1 клетку ниже/правее ожидаемого (или выше/левее — зависит
        /// от того, какое окно активно).
        ///
        /// Теперь K_InventorySlotUI.OnDrop передаёт свой _boundController напрямую,
        /// и размеры берутся из него — что всегда соответствует окну, над которым
        /// находится слот.
        /// </summary>
        public (int x, int y) GetAdjustedDropPosition(
            int slotX, int slotY, Vector2Int itemSize, GridType gridType,
            InventoryController boundController)
        {
            int gridW, gridH;

            // Приоритет 1: boundController (если передан и валиден).
            // Это критично для Container — окно, которому принадлежит слот,
            // может отличаться от активного окна.
            if (boundController != null && boundController.Width > 0 && boundController.Height > 0)
            {
                gridW = boundController.Width;
                gridH = boundController.Height;
            }
            else
            {
                // Приоритет 2: GetGridWidth/Height (для Pockets/Pocket2/Backpack
                // это константы; для Container — _currentContainerCols/Rows).
                gridW = GetGridWidth(gridType);
                gridH = GetGridHeight(gridType);

                // Приоритет 3: контроллер сетки (через GetControllerForGrid).
                if (gridW <= 0 || gridH <= 0)
                {
                    var controller = GetControllerForGrid(gridType);
                    gridW = controller?.Width ?? 0;
                    gridH = controller?.Height ?? 0;
                }
            }

            if (gridW <= 0) return (slotX, slotY);
            return CalculateSnapPosition(slotX, slotY, itemSize, gridW, gridH);
        }

        #endregion

      /// <summary>
/// Ищет свободную ячейку для предмета в контроллере.
/// Сначала пробует точную позицию, затем сканирует всю сетку.
/// </summary>
private bool TryFindFreeCell(InventoryController ctrl, InventoryItem item, out int px, out int py)
{
    px = 0; py = 0;
    if (ctrl == null || item == null) return false;
    Vector2Int size = item.CurrentSize;
    for (int y = 0; y <= ctrl.Height - size.y; y++)
    {
        for (int x = 0; x <= ctrl.Width - size.x; x++)
        {
            if (ctrl.CanPlaceItem(item, x, y))
            {
                px = x; py = y;
                return true;
            }
        }
    }
    return false;
}

/// <summary>
/// Ищет свободную ячейку для предмета с учётом авто-поворота.
/// Сначала пробует текущую ориентацию, затем повёрнутую (если CanRotate).
/// </summary>
private bool TryFindPlacementWithAutoRotate(InventoryController ctrl, InventoryItem item, out int px, out int py)
{
    px = 0; py = 0;
    if (TryFindFreeCell(ctrl, item, out px, out py)) return true;
    if (item.Data != null && item.Data.CanRotate && item.CurrentSize.x != item.CurrentSize.y)
    {
        item.Rotate();
        if (TryFindFreeCell(ctrl, item, out px, out py)) return true;
        item.Rotate();
    }
    return false;
}

        public bool TryDropItemIntoBackpack(UI_Item draggedUI, InventoryItem target, bool fromEquip)
        {
            // ФИКС БАГ (user feedback — duplication): защита от OnDrop после abort.
            if (!_isDragging)
            {
                Debug.LogWarning(
                    "[TryDropItemIntoBackpack] Rejected: drag session not active.");
                return false;
            }

            InventoryItem item = fromEquip ? _draggedFromSlotItem : (draggedUI != null ? draggedUI.Item : null);
            if (item == null || target == null || target.Data == null || !target.Data.IsBackpack) return false;
            if (target.IsFolded && !target.Data.AlwaysShowGrid) return false;
            if (!target.HasInternalGrid || item == target) return false;

            if (item.Data != null && item.Data.IsBackpack)
            {
                // ═══ НОВЫЙ ФИКС: синхронизация перед WouldCreateCircularReference ═══
                SyncBackpackForValidation(item);
                SyncBackpackForValidation(target);

                if (WouldCreateCircularReference(item, target))
                {
                    Debug.Log($"[CYCLE-BLOCK] TryDropItemIntoBackpack rejected: " +
                              $"'{item.Data?.DisplayName}' → '{target.Data?.DisplayName}' would create cycle.");
                    return false;
                }
            }

            int origAngle = item.RotationAngle;
            var db = K_InventorySetup.DatabaseInstance;
            if (db == null) return false;
            int w = target.Data.BackpackWidth, h = target.Data.BackpackHeight;
            if (w <= 0 || h <= 0) return false;

            // FIX: Ищем контроллер в кэше открытых рюкзаков BackpackContainerManager,
            // а не только в активном окне. Это позволяет корректно бросать предметы
            // в неактивные открытые рюкзаки.
            InventoryController liveCtrl = null;
            var openCtrl = _backpackManager.GetLiveController(target.InstanceID.ToString());
            if (openCtrl != null)
                liveCtrl = openCtrl;

            InventoryController workCtrl; bool workIsTemp;
            if (liveCtrl != null)
            {
                workCtrl = liveCtrl;
                workIsTemp = false;
            }
            else
            {
                var data = new InventoryData(w, h);
                var savedItems = target.GetBackpackSavedItems();
                if (savedItems != null) foreach (var s in savedItems) data.AddItem(s);
                workCtrl = new InventoryController(data, db, "TempDrop_" + target.InstanceID);
                workIsTemp = true;
            }

            if (!TryFindPlacementWithAutoRotate(workCtrl, item, out int px, out int py))
            {
                // ФИКС БАГ (audit) #15: RestoreRotationState вместо while.
                item.RestoreRotationState(origAngle);
                if (workIsTemp) workCtrl.Dispose();
                return false; // предмет вернёт EndDragComplete
            }

            // FIX: Размещаем предмет напрямую в workCtrl, минуя TryPlaceItem.
            // TryPlaceItem ломался, если target не был активным окном, так как он обращался к ActiveContainerController.
            bool placed = workCtrl.PlaceExistingItem(item, px, py);
            if (!placed)
                placed = workCtrl.PlaceExistingItemInFirstFreeSlot(item);

            if (placed)
            {
                // Если использовали временный контроллер, сохраняем данные обратно в рюкзак
                if (workIsTemp)
                {
                    target.ReplaceBackpackContents(workCtrl.GetSaveData().GetItems());
                    workCtrl.Dispose();
                }

                // Очищаем состояние drag-and-drop
                if (fromEquip)
                {
                    FinalizeEquipSlotDrag();
                }
                else
                {
                    if (draggedUI != null)
                    {
                        // ═══ АУДИТ-ФИКС: безопасный пулинг через FinishDragAndPool.
                        // ═══
                        FinishDragAndPool(draggedUI);
                    }
                }

                // FIX БАГ 1 & 2: Предмет был деактивирован (draggedUI.SetActive(false)), 
                // поэтому Unity Event System НЕ вызовет OnEndDrag. Мы должны вызвать 
                // EndDragComplete() вручную, чтобы скрыть призрак (ghost) и отключить 
                // raycast на слотах (SetAllGridSlotsRaycast(false)). Иначе сетки "залипают".
                _dragItemRemoved = false;
                _draggedItem = null;

                EndDragComplete();

                ForceRefresh(); // Обновляем UI всех окон
                return true;
            }

            // Если placement вдруг не удался (хотя должен был), откатываем вращение
            // ФИКС БАГ (audit) #15: RestoreRotationState вместо while.
            item.RestoreRotationState(origAngle);
            if (workIsTemp) workCtrl.Dispose();
            return false;
        }
        
       
        #region Context Menu

        /// <summary>
        /// Автоматически создаёт K_ContextMenu если его ещё нет на сцене.
        /// Вызывается из Awake после инициализации Canvas.
        /// </summary>
        private void EnsureContextMenu()
        {
            if (K_ContextMenu.Instance != null) return;

            var rootCanvas = FindRootCanvas();
            var go = new GameObject("ContextMenu", typeof(RectTransform), typeof(Image), typeof(CanvasGroup));
            if (rootCanvas != null)
                go.transform.SetParent(rootCanvas.transform, false);
            else
                go.transform.SetParent(transform.root, false);
            // НЕ деактивируем до AddComponent — иначе Awake отложится
            // и GetComponentInParent не найдёт Canvas

            var ctx = go.AddComponent<K_ContextMenu>();
            ctx.Initialize(rootCanvas);

            // Передаём стиль из Inspector, если назначен
            if (_contextMenuStyle != null)
                ctx.SetStyle(_contextMenuStyle);

            // Теперь деактивируем — меню скрыто по умолчанию
            go.SetActive(false);
        }

        #endregion

        #region Backpack Fold/Unfold

        /// <summary>
        /// ФИКС v2: Проверяет, пуст ли рюкзак внутри.
        /// - Для экипированного: проверяет _backpackController И сериализованные данные.
        /// - Для неэкипированного: проверяет сериализованные данные (InventoryItem.HasBackpackContents)
        ///   а также активный контроллер рюкзака-контейнера, если он сейчас открыт.
        /// </summary>
        /// <summary>
        /// Синхронизирует содержимое рюкзака из ВСЕХ возможных источников
        /// (экипированный контроллер, открытый контейнер) в _backpackContentsSerialized.
        /// Вызывать ПЕРЕД любой проверки "пуст ли рюкзак".
        /// </summary>
              
       
        
                      
        
        

       
        

                      public void RebuildBackpackGrid(int width, int height)
        {
            InventoryGridBounds.Require(width, height);
            if (_backpackGrid == null || _slotPrefab == null) return;
            _currentBackpackCols = width;
            _currentBackpackRows = height;
            if (_gridBuilder != null)
                _gridBuilder.RebuildBackpackGrid(width, height, _backpackGrid, _backpackItemsContainer);
            RefreshAll();
            StartCoroutine(EnforceBackpackContainerSize(width, height));
        }
      private void RebuildSurroundingsGrid(int width, int height)
{
    if (_surroundingsGrid == null || _slotPrefab == null) return;
    _currentContainerCols = width;
    _currentContainerRows = height;
    if (_gridBuilder != null)
        _gridBuilder.RebuildSurroundingsGrid(
            width, height, _surroundingsGrid, _surroundingsItemsContainer, ActiveContainerController);

    // ФИКС H7: синхронизируем itemsContainer с сеткой немедленно,
    // не откладывая до ForceRefresh. Устраняет окно рассинхрона при
    // быстром drag на больших сетках (10×10, 12×12).
    _uiSync?.SyncItemsContainerPositions();

    SetGridSlotsRaycast(_surroundingsGrid, _isDragging);
    if (ActiveBackpackContainer == null)
        DisableSurroundingsPanelDrag();
}
        
       
       
        
        public bool WouldCreateCircularReference(InventoryItem item, InventoryItem targetBackpack = null)
        {
            var target = targetBackpack ?? ActiveBackpackContainer;
            if (target == null) return false;
            if (item == null) return false;

            // Прямая ссылка: item == target (перенос сам в себя)
            if (item.InstanceID == target.InstanceID)
            {
                Debug.Log($"[BUG4-CYCLE] Detected: item == target (self-drop).");
                return true;
            }

            uint targetId = target.InstanceID;
            uint itemId = item.InstanceID;

            // ═══ Синхронизируем ЦЕЛЕВОЙ рюкзак из живого контроллера ═══
            string targetIdStr = target.InstanceID.ToString();
            var targetCtrl = _backpackManager.GetLiveController(targetIdStr);
            if  (targetCtrl != null)
            {
                var targetSavedItems = targetCtrl.GetSaveData()?.GetItems();
                if (targetSavedItems != null)
                    target.ReplaceBackpackContents(targetSavedItems);
            }

            // ═══ Синхронизируем item (если рюкзак) ═══
            if (item.Data.IsBackpack)
            {
                if (GetEquippedBackpackProjection(item) is var equippedController && equippedController != null)
                {
                    var equippedSavedItems = equippedController.GetSaveData()?.GetItems();
                    if (equippedSavedItems != null)
                        item.ReplaceBackpackContents(equippedSavedItems);
                }
                else if ((_backpackManager.GetLiveController(item.InstanceID.ToString())) is var itemCtrl && itemCtrl != null)
                {
                    var itemSavedItems = itemCtrl.GetSaveData()?.GetItems();
                    if (itemSavedItems != null)
                        item.ReplaceBackpackContents(itemSavedItems);
                }
            }

            // ═══ ПРОВЕРКА 1: item содержит target → цикл при placement в target ═══
            // Актуально ТОЛЬКО для рюкзаков (не-рюкзак не может "содержать" target).
            if (item.Data.IsBackpack)
            {
                if (GetEquippedBackpackProjection(item) is var equippedController && equippedController != null)
                {
                    if (DoesControllerContainItemRecursive(equippedController, targetId)) return true;
                }
                else if ((_backpackManager.GetLiveController(item.InstanceID.ToString())) is var itemCtrl && itemCtrl != null)
                {
                    if (DoesControllerContainItemRecursive(itemCtrl, targetId)) return true;
                }
                else
                {
                    if (item.ContainsDescendant(targetId)) return true;
                }
            }

            // ═══ ПРОВЕРКА 2: target содержит item ═══
            // ═══════════════════════════════════════════════════════════════
            // ФИКС БАГ (матрёшка): Раньше эта проверка блокировала ЛЮБОЙ
            // предмет, который уже находился внутри target (даже через
            // вложенный рюкзак). Например: C содержит D, D содержит X.
            // Перетаскивание X из D в C блокировалось, потому что
            // C.ContainsDescendant(X) == true (X внутри D, D внутри C).
            //
            // Но это НЕ циклическая ссылка! Это просто перемещение
            // предмета из вложенного рюкзака в родительский.
            //
            // Циклическая ссылка для НЕ-рюкзаков невозможна в принципе
            // (не-рюкзак не может содержать другой предмет).
            //
            // Для РЮКЗАКОВ: если item-рюкзак уже внутри target, и мы
            // хотим положить item в target — это тоже НЕ цикл (item
            // просто переместится из вложенного рюкзака в parent).
            // Цикл был бы только если target внутри item (проверка 1).
            //
            // ЕДИНСТВЕННЫЙ случай, когда target.ContainsDescendant(item)
            // должен блокировать: item == target (уже проверено выше).
            //
            // Поэтому: для НЕ-рюкзаков проверка 2 ПОЛНОСТЬЮ УБРАНА.
            // Для рюкзаков проверка 1 уже покрывает все случаи цикла.
            // ═══════════════════════════════════════════════════════════════

            return false;
        }
        /// <summary>
        /// Находит, в какой сетке и на какой позиции лежит предмет.
        /// Возвращает (gridType, x, y) или (null, 0, 0) если не найден.
        /// </summary>


        private (GridType? gridType, int x, int y) FindItemLocation(InventoryItem item)
        {
            if (item == null) return (null, 0, 0);
            uint id = item.InstanceID;
            var grids = new (GridType type, InventoryController controller)[]
            {
            (GridType.Pockets, _pocketsController),
            (GridType.Pocket2, _pocket2Controller),
            (GridType.Backpack, _backpackController),
            };
            foreach (var (type, controller) in grids)
            {
                if (controller == null) continue;
                for (int y = 0; y < controller.Height; y++)
                    for (int x = 0; x < controller.Width; x++)
                    {
                        var atPos = controller.GetItemAt(x, y);
                        if (atPos != null && atPos.InstanceID == id) return (type, x, y);
                    }
            }
            // FIX баг3: ищем во ВСЕХ открытых окнах-контейнерах, а не только в активном.
            for (int i = 0; i < _backpackManager.OpenWindows.Count; i++)
            {
                var w = _backpackManager.OpenWindows[i];
                if (w == null || w.Controller == null) continue;
                var c = w.Controller;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var atPos = c.GetItemAt(x, y);
                        if (atPos != null && atPos.InstanceID == id) return (GridType.Container, x, y);
                    }
            }
            // v13: сетка окружения (лут) НЕ входит в _backpackManager.OpenWindows —
            // проверяем её отдельно (во время лутания ActiveContainerController
            // и есть контроллер лута). Тогда «Опустошить», fold и unfold работают
            // относительно контейнера, в котором лежит рюкзак, а не падают
            // в fallback «в инвентарь игрока».
            // v17: контроллер лута берём из ActiveContainerController, а если он
            // null/протух — восстанавливаем из слотов окружения.
            if (IsLooting)
            {
                var c = ActiveContainerController != null ? ActiveContainerController : _lootSession?.GetLootControllerFromSlots();
                if (c != null)
                {
                    for (int y = 0; y < c.Height; y++)
                        for (int x = 0; x < c.Width; x++)
                        {
                            var atPos = c.GetItemAt(x, y);
                            if (atPos != null && atPos.InstanceID == id) return (GridType.Container, x, y);
                        }
                }
            }
            return (null, 0, 0);
        }

        public InventoryController FindControllerForItem(InventoryItem item)
        {
            if (item == null) return null;
            uint id = item.InstanceID;
            var players = new[] { _pocketsController, _pocket2Controller, _backpackController };
            foreach (var c in players)
            {
                if (c == null) continue;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var at = c.GetItemAt(x, y);
                        if (at != null && at.InstanceID == id) return c;
                    }
            }
            foreach (var w in _backpackManager.OpenWindows)
            {
                var c = w?.Controller;
                if (c == null) continue;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var at = c.GetItemAt(x, y);
                        if (at != null && at.InstanceID == id) return c;
                    }
            }
            // ═══ ФИКС БАГ 2 (v18): ищем также в контроллере ЛУТА (сетка окружения).
            // Без этого CanUnfoldInCurrentGrid / HandleInventoryBackpackFold получали
            // null для рюкзака, лежащего в луте → «Развернуть» не работало. ═══
            if (IsLooting)
            {
                var c = ActiveContainerController != null ? ActiveContainerController : _lootSession?.GetLootControllerFromSlots();
                if (c != null)
                {
                    for (int y = 0; y < c.Height; y++)
                        for (int x = 0; x < c.Width; x++)
                        {
                            var at = c.GetItemAt(x, y);
                            if (at != null && at.InstanceID == id) return c;
                        }
                }
            }
            return null;
        }
        #endregion

        #region Backpack As Container


        /// <summary>
        /// ФИКС: Раньше гарантировала наличие DragZone на _surroundingsPanel.
        /// Сейчас режим переключён на "drag from anywhere" — DragZone НЕ нужна.
        /// Метод оставлен как no-op для обратной совместимости со старыми вызовами.
        /// </summary>
      
    
     
       
      


        /// <summary>
        /// ФИЧА #2: Находит TextMeshProUGUI в DragZone (внутри K_DraggablePanel)
        /// и устанавливает текст названия контейнера.
        /// </summary>

        // RestoreLootControllerIfLooting() и GetLootControllerFromSlots() перенесены
        // в LootSessionController (Задача 5D). Вызовы осуществляются через
        // _lootSession.RestoreLootControllerIfLooting() / _lootSession.GetLootControllerFromSlots().

        /// <summary>
        /// Поиск предмета по InstanceID во всех контроллерах игрока
        /// (pockets, pocket2, backpack) и в активном контейнере.
        /// </summary>
        public InventoryItem FindItemByInstanceId(uint instanceId)
        {
            var registeredItem = InventoryOwnershipRegistry.FindLiveItem(instanceId);
            if (registeredItem != null) return registeredItem;
            var controllers = new[] { _pocketsController, _pocket2Controller, _backpackController };
            foreach (var ctrl in controllers)
            {
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var it = ctrl.GetItemAt(x, y);
                        if (it != null && it.InstanceID == instanceId) return it;
                    }
            }
            if (_backpackSlot != null && _backpackSlot.EquippedItem != null && _backpackSlot.EquippedItem.InstanceID == instanceId)
                return _backpackSlot.EquippedItem;
            // FIX баг3: ищем во всех открытых окнах-контейнерах.
            for (int i = 0; i < _backpackManager.OpenWindows.Count; i++)
            {
                var w = _backpackManager.OpenWindows[i];
                if (w == null || w.Controller == null) continue;
                var c = w.Controller;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var it = c.GetItemAt(x, y);
                        if (it != null && it.InstanceID == instanceId) return it;
                    }
            }
            return null;
        }

        #endregion
        /// <summary>
        /// Содержит ли рюкзак dragged предмет с targetId на любой глубине.
        /// Использует ЖИВЫЕ контроллеры открытых окон — работает на любой глубине вложенности.
        /// </summary>
        public bool DraggedContainsTarget(InventoryItem dragged, uint targetId)
        {
            if (dragged == null || dragged.Data == null || !dragged.Data.IsBackpack) return false;
            if (dragged.InstanceID == targetId) return true;

            // Ищем живой контроллер содержимого dragged
            InventoryController ctrl = null;
            if (GetEquippedBackpackProjection(dragged) is var equippedController && equippedController != null)
                ctrl = equippedController;
            else if ((_backpackManager.GetLiveController(dragged.InstanceID.ToString())) is var c && c != null)
                ctrl = c;

            if (ctrl != null)
                return DoesControllerContainItemRecursive(ctrl, targetId);

            SyncBackpackForValidation(dragged);
            return dragged.ContainsDescendant(targetId);
        }
        #region Debug Helpers

        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs)
                UnityEngine.Debug.Log(message);
        }

        #endregion

        #region BackpackContainerManager Delegators

        // ═══════════════════════════════════════════════════════════
        //  ДЕЛЕГАТОРЫ В BackpackContainerManager
        //  Обратная совместимость: все вызовы из остального кода
        //  K_InventoryUI продолжают работать через эти методы.
        // ═══════════════════════════════════════════════════════════
        public void SetupSurroundingsPanelHierarchy()
        {
            if (_groundLootView != null) { _groundLootView.Resize(); return; }
            _backpackManager?.SetupSurroundingsPanelHierarchy(_currentContainerCols, _currentContainerRows);
        }
        public void EnableDraggableSurroundingsPanel()
        {
            if (_groundLootView != null) return;
            _backpackManager?.EnableDraggableSurroundingsPanel();
        }
        public void DisableSurroundingsPanelDrag()
        {
            if (_groundLootView != null) { _groundLootView.Resize(); return; }
            _backpackManager?.DisableSurroundingsPanelDrag();
        }
        public void LinkSurroundingsHierarchy()
        {
            if (_groundLootView != null) { _groundLootView.Resize(); return; }
            _backpackManager?.LinkSurroundingsHierarchy();
        }
        public void AlignPanelToGridExact() => _backpackManager?.AlignPanelToGridExact();
        public void DetachGridFromPanel() => _backpackManager?.DetachGridFromPanel();
        public void DetachPanelAsFloatingWindow() => _backpackManager?.DetachPanelAsFloatingWindow();
        public void SyncDraggablePanelHeaderSettings(K_DraggablePanel draggable) => _backpackManager?.SyncDraggablePanelHeaderSettings(draggable);
        public void SetContainerHeaderText(K_DraggablePanel draggable, string text) => _backpackManager?.SetContainerHeaderText(draggable, text);
        public void NotifyPanelDragStarted() => _backpackManager?.NotifyPanelDragStarted();
        public void NotifyPanelDragEnded() => _backpackManager?.NotifyPanelDragEnded();
        public void EnsureDragZoneExists() => _backpackManager?.EnsureDragZoneExists();
        public void CloseSpecificBackpackWindow(string instanceID) => _backpackManager?.CloseSpecificBackpackWindow(instanceID);
        public void OpenBackpackAsContainer(InventoryItem item) => _backpackManager?.OpenBackpack(item);
        // ═══════════════════════════════════════════════════════════
//  ДЕЛЕГАТОРЫ В BackpackStateManager
// ═══════════════════════════════════════════════════════════
// Дополнительные делегаторы для BackpackStateManager
public void SyncBackpackContentsBeforeFold(InventoryItem item) => _backpackStateManager?.SyncBackpackContentsBeforeFold(item);
public void SyncBackpackForValidation(InventoryItem item) => _backpackStateManager?.SyncBackpackForValidationPublic(item);
     public void ToggleBackpackFold(InventoryItem item, bool fold)
     {
         if (!IsGroundLootItem(item)) { _backpackStateManager?.ToggleBackpackFold(item, fold); return; }
         if (item.IsFolded == fold || !item.CanFold) return;
         CancelDrag();
         SyncBackpackContentsBeforeFold(item);
         if (fold && !IsBackpackContentsEmpty(item)) return;
         if (!_groundLoot.CanSetFolded(item, fold)) return;
         CloseAllWindowsForBackpack(item);
         var previous = _groundLoot.Controller;
         if (_groundLoot.TrySetFolded(item, fold)) RefreshGroundLootLayout(previous);
     }
     public bool IsBackpackContentsEmpty(InventoryItem item) => _backpackStateManager?.IsBackpackContentsEmpty(item) ?? true;
     public bool CanUnfoldInCurrentGrid(InventoryItem item) => IsGroundLootItem(item)
         ? _groundLoot.CanSetFolded(item, false)
         : _backpackStateManager?.CanUnfoldInCurrentGrid(item) ?? false;
     public void SyncBackpackForValidationPublic(InventoryItem item) => _backpackStateManager?.SyncBackpackForValidationPublic(item);
    public int EmptyBackpackContents(InventoryItem item) => _backpackStateManager?.EmptyBackpackContents(item, IsLooting, ActiveContainerController) ?? 0;

// Метод для обновления drag-состояния в менеджере (вызывается из drag-логики)
public void UpdateBackpackManagerDragState()
{
    _backpackStateManager?.UpdateDragState(
        _isDragging, _dragItemRemoved, _draggedItem,
        _dragOriginX, _dragOriginY, _dragOriginGridType);
}
        public void CloseBackpackAsContainer() => _backpackManager?.CloseActiveBackpack();
        public void CloseBackpackWindowByItem(InventoryItem item) => _backpackManager?.CloseBackpackByItem(item);
        public void CloseAllOpenedBackpacks() => _backpackManager?.CloseAllBackpacks();
        public void CloseAllWindowsForBackpack(InventoryItem item) => _backpackManager?.CloseAllWindowsForBackpackItem(item);
        public void CloseNestedBackpackWindows(InventoryItem item) => _backpackManager?.CloseNestedBackpacks(item);
        public void DestroyAllContainerWindows() => _backpackManager?.DestroyAllWindows();
        public bool IsBackpackWindowOpen(InventoryItem item) => _backpackManager?.IsBackpackWindowOpen(item) ?? false;
        public bool CanOpenBackpackAsContainer(InventoryItem item) => _backpackManager?.CanOpenBackpack(item) ?? false;
        public K_ContainerWindow FindWindowByController(InventoryController ctrl) => _backpackManager?.FindWindowByController(ctrl);
        public int GetBackpackNestingDepth(InventoryItem item) => _backpackManager?.GetNestingDepth(item) ?? 0;
        public bool DoesControllerContainBackpack(InventoryController ctrl, string id) => _backpackManager?.IsControllerContainingBackpack(ctrl, id) ?? false;
        public bool IsWindowAncestorOfRecursive(InventoryController ancestor, string descendantId) => _backpackManager?.IsAncestorOf(ancestor, descendantId) ?? false;
        public bool DoesControllerContainItemRecursive(InventoryController ctrl, uint id) => _backpackManager?.ContainsItemRecursive(ctrl, id) ?? false;
        public void SuspendBackpackWindowsForLoot() => _backpackManager?.SuspendForLoot();
        public void ResumeBackpackWindowsAfterLoot() => _backpackManager?.ResumeAfterLoot();

        // Read-only прокси для свойств менеджера.
        // Внимание: ActiveContainerController теперь маршрутизируется —
        // при активном луте отдаётся LootSessionController.ActiveLootController,
        // иначе — _backpackManager.ActiveContainerController (для окон рюкзаков).
        public IReadOnlyList<K_ContainerWindow> GetOpenContainerWindows() => _backpackManager?.OpenWindows ?? new List<K_ContainerWindow>();
        public InventoryItem ActiveBackpackContainer => _backpackManager?.ActiveBackpackContainer;
        public K_ContainerWindow ActiveContainerWindow => _backpackManager?.ActiveWindow;
        public InventoryController ActiveContainerController =>
            (_lootSession != null && _lootSession.IsLooting)
                ? _lootSession.ActiveLootController
                : _backpackManager?.ActiveContainerController;
        public Transform SurroundingsPanel => _backpackManager?.SurroundingsPanel ?? _originalSurroundingsPanel?.transform;
        public Transform SurroundingsGrid => _backpackManager?.SurroundingsGrid ?? _originalSurroundingsGrid;
        public Transform SurroundingsItemsContainer => _backpackManager?.SurroundingsItemsContainer ?? _originalSurroundingsItemsContainer;

        // Мутация ActiveContainerController. При активном луте — пишем в LootSessionController,
        // иначе — в _backpackManager (для окон рюкзаков). Единый источник правды для каждой моды.
        public void SetActiveContainerController(InventoryController ctrl)
        {
            if (_lootSession != null && _lootSession.IsLooting)
            {
                _lootSession.SetActiveLootController(ctrl);
                if (_groundLoot != null) _backpackManager?.SetActiveContainerController(ctrl);
            }
            else
                _backpackManager?.SetActiveContainerController(ctrl);
        }

        #endregion


        // ИСПРАВЛЕНИЕ: добавлен метод FindBackpackInFootprint в сам K_InventoryUI
        private InventoryItem FindBackpackInFootprint(InventoryController ctrl, int x, int y, InventoryItem dragged)
        {
            if (ctrl == null || dragged == null) return null;
            var size = dragged.CurrentSize;
            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    int cx = x + dx, cy = y + dy;
                    if (cx < 0 || cy < 0 || cx >= ctrl.Width || cy >= ctrl.Height) continue;
                    
                    var occupant = ctrl.GetItemAt(cx, cy);
                    if (occupant == null || occupant == dragged) continue;
                    
                    if (occupant.Data != null && occupant.Data.IsBackpack)
                        return occupant;
                }
            }
            return null;
        }
      #if UNITY_EDITOR
// ═══════════════════════════════════════════════════════════════
//  LOOT-AUDIT (Шаг 1 ТЗ). Только для Editor. Не влияет на логику.
// ═══════════════════════════════════════════════════════════════
private void AuditPanelAndGrid(string phase, string containerName, int cols, int rows)
{
    var sb = new System.Text.StringBuilder(1024);
    sb.AppendLine($"══════════ [LOOT-AUDIT] {phase} ══════════");
    sb.AppendLine($"[LOOT-AUDIT] Requested grid: {cols}x{rows}  container='{containerName}'");

    // ── Panel ──
    var panelRect = _surroundingsPanel != null ? _surroundingsPanel.GetComponent<RectTransform>() : null;
    if (panelRect != null)
    {
        var parentRT = panelRect.parent as RectTransform;
        Vector3[] pc = new Vector3[4];
        panelRect.GetWorldCorners(pc);
        sb.AppendLine($"[LOOT-AUDIT] _surroundingsPanel ({phase}):");
        sb.AppendLine($"    parent={(parentRT != null ? parentRT.name : "null")} parentRect={(parentRT != null ? parentRT.rect.ToString() : "-")}");
        sb.AppendLine($"    anchorMin={panelRect.anchorMin} anchorMax={panelRect.anchorMax} pivot={panelRect.pivot}");
        sb.AppendLine($"    sizeDelta={panelRect.sizeDelta} anchoredPosition={panelRect.anchoredPosition}");
        sb.AppendLine($"    world[1=TL]={pc[1]} world[3=BR]={pc[3]}");
    }
    else sb.AppendLine($"[LOOT-AUDIT] _surroundingsPanel = NULL");

    // ── Grid ──
    var gridRect = _surroundingsGrid != null ? _surroundingsGrid.GetComponent<RectTransform>() : null;
    if (gridRect != null)
    {
        var parentRT = gridRect.parent as RectTransform;
        Vector3[] gc = new Vector3[4];
        gridRect.GetWorldCorners(gc);
        sb.AppendLine($"[LOOT-AUDIT] _surroundingsGrid ({phase}):");
        sb.AppendLine($"    parent={(parentRT != null ? parentRT.name : "null")} parentRect={(parentRT != null ? parentRT.rect.ToString() : "-")}");
        sb.AppendLine($"    anchorMin={gridRect.anchorMin} anchorMax={gridRect.anchorMax} pivot={gridRect.pivot}");
        sb.AppendLine($"    sizeDelta={gridRect.sizeDelta} anchoredPosition={gridRect.anchoredPosition}");
        sb.AppendLine($"    world[1=TL]={gc[1]} world[3=BR]={gc[3]}");
        sb.AppendLine($"    childCount={gridRect.childCount}");
    }
    else sb.AppendLine($"[LOOT-AUDIT] _surroundingsGrid = NULL");

    // ── ItemsContainer ──
    var icRect = _surroundingsItemsContainer != null ? _surroundingsItemsContainer.GetComponent<RectTransform>() : null;
    var icCg   = _surroundingsItemsContainer != null ? _surroundingsItemsContainer.GetComponent<CanvasGroup>() : null;
    if (icRect != null)
    {
        sb.AppendLine($"[LOOT-AUDIT] ItemsContainer ({phase}):");
        sb.AppendLine($"    parent={icRect.parent?.name ?? "null"} sizeDelta={icRect.sizeDelta} anchoredPosition={icRect.anchoredPosition}");
        sb.AppendLine($"    anchorMin={icRect.anchorMin} anchorMax={icRect.anchorMax} pivot={icRect.pivot}");
        sb.AppendLine($"    cg.blocksRaycasts={(icCg != null ? icCg.blocksRaycasts.ToString() : "no-cg")}");
    }
    else sb.AppendLine($"[LOOT-AUDIT] ItemsContainer = NULL");

    // ── Children of panel ──
    if (panelRect != null)
    {
        sb.AppendLine($"[LOOT-AUDIT] Children of panel ({phase}) → name → raycastTarget:");
        for (int i = 0; i < panelRect.childCount; i++)
        {
            var ch = panelRect.GetChild(i);
            var img = ch.GetComponent<UnityEngine.UI.Image>();
            var mask = ch.GetComponent<UnityEngine.UI.RectMask2D>() != null
                    || ch.GetComponent<UnityEngine.UI.Mask>() != null;
            string rc = img != null ? img.raycastTarget.ToString() : "-";
            sb.AppendLine($"    [{i}] {ch.name}  rt={rc}  mask={mask}  act={ch.gameObject.activeSelf}");
        }
    }

    // ── Children of grid ──
    if (gridRect != null)
    {
        int slotCount = 0;
        K_InventorySlotUI first = null, last = null;
        for (int i = 0; i < gridRect.childCount; i++)
        {
            var s = gridRect.GetChild(i).GetComponent<K_InventorySlotUI>();
            if (s == null) continue;
            slotCount++;
            if (first == null) first = s;
            last = s;
        }
        sb.AppendLine($"[LOOT-AUDIT] Grid children ({phase}): total={gridRect.childCount} slots={slotCount}");
        if (first != null) sb.AppendLine($"    first K_InventorySlotUI ({first.X},{first.Y})");
        if (last  != null) sb.AppendLine($"    last  K_InventorySlotUI ({last.X},{last.Y})");

        if (phase.Contains("AfterSetRaycastTrue"))
        {
            int broken = 0;
            for (int i = 0; i < gridRect.childCount; i++)
            {
                var s = gridRect.GetChild(i).GetComponent<K_InventorySlotUI>();
                if (s == null) continue;
                var bg = s.BackgroundImage;
                if (bg == null || !bg.raycastTarget) broken++;
            }
            sb.AppendLine($"[LOOT-AUDIT] Slots with bg.raycastTarget=false: {broken} (must be 0 during drag)");
        }
    }

    Debug.Log(sb.ToString());
}
#endif  
    }
}
 #endregion
