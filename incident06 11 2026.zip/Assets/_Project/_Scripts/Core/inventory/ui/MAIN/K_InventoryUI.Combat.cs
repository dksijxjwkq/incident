using System.Collections.Generic;
using K_Incident.Core.Combat;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public partial class K_InventoryUI
    {
        [Header("Combat 5.2")]
        [SerializeField] private WeaponBalanceConfig _combatBalance;
        private K_CombatContext _combatContext;
        public K_PlayerCombatController CombatController { get; private set; }
        public InventoryItem PrimaryCombatItem => _primarySlot1?.EquippedItem ?? _primarySlot2?.EquippedItem;

        public InventoryItem GetCombatItem(ActiveCombatSlot slot) => slot switch
        {
            ActiveCombatSlot.Primary1 => _primarySlot1?.EquippedItem,
            ActiveCombatSlot.Primary2 => _primarySlot2?.EquippedItem,
            ActiveCombatSlot.Pistol => _pistolSlot?.EquippedItem,
            ActiveCombatSlot.Melee => _meleeSlot?.EquippedItem,
            ActiveCombatSlot.None => null,
            _ => throw new System.ArgumentOutOfRangeException(nameof(slot))
        };

        // Called by Start, after controllers and equipment references have been initialized.
        private void InitializeCombatIntegration()
        {
            var owner = AppliedHealth != null ? AppliedHealth.gameObject :
                (_playerMotor != null ? _playerMotor.gameObject : gameObject);
            if (_combatContext == null) _combatContext = owner.GetComponent<K_CombatContext>();
            if (_combatContext == null) _combatContext = owner.AddComponent<K_CombatContext>();
            bool createdRuntimeBalance = _combatContext.Balance == null && _combatBalance == null;
            if (_combatContext.Balance == null)
                _combatContext.ConfigureBalance(_combatBalance != null ? _combatBalance :
                    ScriptableObject.CreateInstance<WeaponBalanceConfig>());
            if (createdRuntimeBalance) _combatContext.AdoptRuntimeBalance(_combatContext.Balance);
            _combatContext.ConfigureDatabase(K_InventorySetup.DatabaseInstance);
            _combatContext.EnsureSaveRegistration();
            CombatController = owner.GetComponent<K_PlayerCombatController>();
            if (CombatController == null) CombatController = owner.AddComponent<K_PlayerCombatController>();
            CombatController.Initialize(this, _combatContext, AppliedHealth);
        }

        private void DisposeCombatIntegration()
        {
            CombatController?.DetachInventory(this);
            CombatController = null;
            _combatContext = null;
        }

        public List<InventoryItem> GetCombatOwnedRoots()
        {
            var equipment = new[] { _primarySlot1?.EquippedItem, _primarySlot2?.EquippedItem,
                _pistolSlot?.EquippedItem, _meleeSlot?.EquippedItem, _backpackSlot?.EquippedItem,
                _armorSlot?.EquippedItem, _headgearSlot?.EquippedItem };
            return CombatPlayerInventory.CollectOwnedRoots(equipment, _pocketsController, _pocket2Controller,
                GetEquippedBackpackProjection(_backpackSlot?.EquippedItem), SyncBackpackForValidation);
        }

        public CombatReloadSources GetCombatReloadSources() => new CombatReloadSources(
            _pocketsController, _pocket2Controller, GetEquippedBackpackProjection(_backpackSlot?.EquippedItem));

        public bool TryCycleWeaponChamber(InventoryItem item, out string reason)
        {
            reason = "Combat controller is unavailable.";
            return CombatController != null && CombatController.TryCycleWeaponChamber(item, out reason);
        }

        public bool TryDetachWeaponMagazine(InventoryItem item, out string reason)
        {
            reason = "Combat controller is unavailable.";
            return CombatController != null && CombatController.TryDetachWeaponMagazine(item, out reason);
        }

        public bool TryClearWeaponChamber(InventoryItem item, out string reason)
        {
            reason = "Combat controller is unavailable.";
            return CombatController != null && CombatController.TryClearWeaponChamber(item, out reason);
        }

        public bool TryCheckWeaponMagazine(InventoryItem item, out string text, out string reason)
        {
            text = null;
            reason = "Combat controller is unavailable.";
            return CombatController != null && CombatController.TryCheckWeaponMagazine(item, out text, out reason);
        }

        public bool OwnsCombatTarget(InventoryItem target)
        {
            if (target == null) return false;
            foreach (var item in GetCombatOwnedRoots())
                if (ReferenceEquals(item, target)) return true;
            return false;
        }

        public void RefreshCombatWeight()
        {
            if (_combatContext == null || K_InventorySetup.DatabaseInstance == null || _cachedWeightManager == null)
            {
                // Initialization-only fallback; the legacy method is kept intact for old callers.
                RefreshTotalWeight();
                return;
            }
            _combatContext.UpdateCarriedWeight(GetCombatOwnedRoots(), K_InventorySetup.DatabaseInstance,
                _cachedWeightManager, AppliedHealth?.AppliedMedical?.Records);
            UpdateWeightDisplay();
        }

        public bool CanPreviewCombatAmmoDrop(InventoryItem ammo, InventoryItem target)
        {
            return CombatController != null && CombatController.CanPreviewAmmoDrop(ammo, target);
        }

        public static bool IsCombatItemDrop(InventoryItem source, InventoryItem target)
        {
            if (source?.Data == null || target?.Data == null) return false;
            return (source.Data.Type == ItemType.Ammo &&
                    (target.Data.Type == ItemType.Weapon || target.Data.Type == ItemType.Magazine)) ||
                (source.Data.Type == ItemType.Magazine && target.Data.Type == ItemType.Weapon);
        }

        public bool CanPreviewCombatItemDrop(InventoryItem source, InventoryItem target)
        {
            if (!IsCombatItemDrop(source, target) || K_SplitStackDialog.IsItemLocked(source) ||
                K_SplitStackDialog.IsItemLocked(target)) return false;
            return source.Data.Type == ItemType.Ammo ? CanPreviewCombatAmmoDrop(source, target) :
                CombatController != null && CombatController.CanPreviewMagazineDrop(source, target);
        }

        /// <summary>Recognized interactions finish the drag even on refusal, before equip/swap routes.</summary>
        public bool TryHandleCombatItemDrop(InventoryItem target)
        {
            var source = _draggedItem?.Item;
            if (!IsCombatItemDrop(source, target)) return false;
            bool valid = CanPreviewCombatItemDrop(source, target);
            // Finish the drag before the timed service starts; the original item stays in its grid.
            CancelDrag();
            if (valid && CombatController != null)
            {
                if (source.Data.Type == ItemType.Ammo) CombatController.TryBeginAmmoDrop(source, target);
                else CombatController.TryBeginMagazineDrop(source, target);
            }
            ForceRefresh();
            return true;
        }

        public bool TryHandleCombatAmmoDrop(InventoryItem target) =>
            _draggedItem?.Item?.Data?.Type == ItemType.Ammo && TryHandleCombatItemDrop(target);
    }
}
