using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Shared target geometry for swap preview and drop; never changes items or grid cells.</summary>
    public static class InventorySwapGeometry
    {
        public static bool SameDimensions(Vector2Int first, Vector2Int second) =>
            first.x > 0 && first.y > 0 && second.x > 0 && second.y > 0 &&
            ((first.x == second.x && first.y == second.y) ||
             (first.x == second.y && first.y == second.x));

        public static (int x, int y) ResolveAnchor(InventoryItem dragged, InventoryItem target,
            InventoryController targetController, int fallbackX, int fallbackY)
        {
            if (dragged == null || target == null || targetController == null || targetController.IsDisposed ||
                !SameDimensions(dragged.CurrentSize, target.CurrentSize))
                return (fallbackX, fallbackY);

            // Equal-sized items exchange occupied places; cursor overlap only selects the target.
            // The existing validator still checks placement with the dragged item's current rotation.
            var root = targetController.FindItemRootPosition(target.InstanceID);
            return root.x >= 0 && root.y >= 0 ? root : (fallbackX, fallbackY);
        }
    }
}
