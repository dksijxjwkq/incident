using K_Incident.Core.UI;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Keeps the authored inventory composition stable while the screen aspect changes.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Canvas))]
    [DefaultExecutionOrder(1000)]
    public sealed class K_ResponsiveCanvasLayout : MonoBehaviour
    {
        [SerializeField, Min(0f), Tooltip("Отступ основного HUD от границ Canvas в единицах интерфейса.")]
        private float _hudMargin = 8f;

        private Canvas _canvas;
        private CanvasScaler _scaler;
        private RectTransform _canvasRect, _inventoryFrame, _background, _hudRoot, _clock;
        private Graphic[] _hudGraphics;
        private readonly Vector3[] _corners = new Vector3[4];
        private Vector2 _lastCanvasSize = new Vector2(-1f, -1f);
        private Vector2 _lastReference;
        private Vector2 _hudReferenceOffset, _clockReferenceOffset;
        private bool _capturedHud;
        private K_UIConnector _connectors;
        private bool _lineScanPending;
        private readonly List<PixelLine> _pixelLines = new List<PixelLine>();

        private sealed class PixelLine
        {
            public Image Image;
            public bool Vertical;
            public float Thickness;
        }

        internal Color InventoryLineColor
        {
            get
            {
                if (_connectors == null && _inventoryFrame != null)
                    _connectors = _inventoryFrame.GetComponentInChildren<K_UIConnector>(true);
                return _connectors != null ? _connectors.LineColor :
                    new Color(159f / 255f, 159f / 255f, 159f / 255f, 45f / 255f);
            }
        }

        public static Color ResolveLineColor(Component view)
        {
            var layout = view != null ? view.GetComponentInParent<K_ResponsiveCanvasLayout>() : null;
            return layout != null ? layout.InventoryLineColor :
                new Color(159f / 255f, 159f / 255f, 159f / 255f, 45f / 255f);
        }

        public static void TrackPixelLine(Image image)
        {
            if (image == null) return;
            var layout = image.GetComponentInParent<K_ResponsiveCanvasLayout>();
            if (layout != null) layout.RegisterPixelLine(image);
        }

        private void RegisterPixelLine(Image image)
        {
            foreach (var line in _pixelLines) if (line.Image == image) return;
            var size = image.rectTransform.rect.size;
            if (size.x <= 0f || size.y <= 0f) return;
            bool vertical = size.x < size.y;
            _pixelLines.Add(new PixelLine { Image = image, Vertical = vertical, Thickness = vertical ? size.x : size.y });
            image.color = InventoryLineColor;
        }

        private void ConfigureInventoryLines()
        {
            if (_inventoryFrame == null) return;
            _connectors = _inventoryFrame.GetComponentInChildren<K_UIConnector>(true);
            foreach (var frame in _inventoryFrame.GetComponentsInChildren<K_InventoryFrameImage>(true))
                if (frame.UseInventoryLineColor) frame.BorderColor = InventoryLineColor;
            foreach (var image in _inventoryFrame.GetComponentsInChildren<Image>(true))
            {
                string name = image.gameObject.name;
                if (name != "borderLeft" && name != "borderright" && name != "bordertop" &&
                    name != "borderLow" && name != "borderDown" && name != "MediumBorderInventory") continue;
                for (var parent = image.transform.parent; parent != null && parent != _inventoryFrame; parent = parent.parent)
                    if (parent.gameObject.name == "equipmentBadge") { RegisterPixelLine(image); break; }
            }
        }

        private void FitPixelLines()
        {
            for (int i = _pixelLines.Count - 1; i >= 0; i--)
            {
                var line = _pixelLines[i];
                if (line.Image == null) { _pixelLines.RemoveAt(i); continue; }
                line.Image.color = InventoryLineColor;
                if (!line.Image.gameObject.activeInHierarchy) continue;
                var rect = line.Image.rectTransform;
                K_InventoryFrameImage.ReadPixelsPerUnit(rect, _canvas, _corners, out float pixelsX, out float pixelsY);
                float pixels = line.Vertical ? pixelsX : pixelsY;
                if (pixels <= 0f) continue;
                float thickness = Mathf.Max(line.Thickness, 1f / pixels);
                float current = line.Vertical ? rect.rect.width : rect.rect.height;
                if (!Mathf.Approximately(current, thickness))
                {
                    rect.SetSizeWithCurrentAnchors(line.Vertical ? RectTransform.Axis.Horizontal : RectTransform.Axis.Vertical, thickness);
                    if (!line.Vertical && line.Image.gameObject.name == "BottomBorderFix")
                        rect.anchoredPosition += new Vector2(0f, (thickness - current) * rect.pivot.y);
                }
            }
        }

        public static void Ensure(RectTransform canvasRoot, RectTransform inventoryPane, RectTransform background)
        {
            if (canvasRoot == null || inventoryPane == null) return;
            var canvas = canvasRoot.GetComponent<Canvas>();
            var frame = inventoryPane.parent as RectTransform;
            if (canvas == null || canvas.renderMode == RenderMode.WorldSpace || frame == null || frame.parent != canvasRoot)
                return;
            var layout = canvasRoot.GetComponent<K_ResponsiveCanvasLayout>();
            if (layout != null && !layout.enabled) return;
            if (layout == null) layout = canvasRoot.gameObject.AddComponent<K_ResponsiveCanvasLayout>();
            var health = canvasRoot.GetComponentInChildren<K_HealthWidget>(true);
            RectTransform hud = null;
            if (health != null)
            {
                Transform current = health.transform;
                while (current.parent != null && current.parent != canvasRoot) current = current.parent;
                if (current.parent == canvasRoot && current != frame) hud = current as RectTransform;
            }
            layout.Configure(frame, background, hud, health != null ? health.ClockRect : null);
        }

        public void Configure(RectTransform inventoryFrame, RectTransform background, RectTransform hudRoot, RectTransform clock)
        {
            bool retainHudReference = _capturedHud && _hudRoot == hudRoot && _clock == clock;
            _canvas = GetComponent<Canvas>();
            _canvasRect = transform as RectTransform;
            _scaler = GetComponent<CanvasScaler>();
            _inventoryFrame = inventoryFrame;
            _background = background;
            _hudRoot = hudRoot;
            _clock = clock;
            _hudGraphics = hudRoot != null ? hudRoot.GetComponentsInChildren<Graphic>(true) : null;
            _capturedHud = retainHudReference;
            _lastCanvasSize = new Vector2(-1f, -1f);
            if (_scaler != null && _scaler.uiScaleMode == CanvasScaler.ScaleMode.ScaleWithScreenSize)
            {
                // One scale for slots, ghosts, dialogs and HUD. No extra scaled wrapper is needed.
                _scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.Expand;
                SetInventoryFrame(_scaler.referenceResolution);
            }
            _lineScanPending = true;
        }

        private void LateUpdate() => RefreshLayout();

        public void RefreshLayout()
        {
            if (_canvas == null || _canvasRect == null || _scaler == null ||
                _canvas.renderMode == RenderMode.WorldSpace ||
                _scaler.uiScaleMode != CanvasScaler.ScaleMode.ScaleWithScreenSize) return;
            Vector2 reference = _scaler.referenceResolution;
            Vector2 size = _canvasRect.rect.size;
            if (reference.x <= 0f || reference.y <= 0f || size.x <= 0f || size.y <= 0f) return;
            if (_lineScanPending) { ConfigureInventoryLines(); _lineScanPending = false; }
            FitPixelLines();
            if (_lastCanvasSize == size && _lastReference == reference) return;

            if (!_capturedHud)
            {
                Vector2 center = _canvasRect.rect.center;
                if (_hudRoot != null)
                    _hudReferenceOffset = (Vector2)_canvasRect.InverseTransformPoint(_hudRoot.position) - center;
                if (_clock != null)
                    _clockReferenceOffset = (Vector2)_canvasRect.InverseTransformPoint(_clock.position) - center;
                _capturedHud = true;
            }
            SetInventoryFrame(reference);
            FitBackground();
            FitHud(reference);
            _lastCanvasSize = size;
            _lastReference = reference;
        }

        private void SetInventoryFrame(Vector2 reference)
        {
            if (_inventoryFrame == null || reference.x <= 0f || reference.y <= 0f) return;
            Vector2 offset = _inventoryFrame.anchoredPosition;
            _inventoryFrame.anchorMin = _inventoryFrame.anchorMax = new Vector2(0.5f, 0.5f);
            _inventoryFrame.sizeDelta = reference;
            _inventoryFrame.anchoredPosition = offset;
        }

        private void FitBackground()
        {
            if (_background == null || !(_background.parent is RectTransform parent)) return;
            _canvasRect.GetWorldCorners(_corners);
            Vector2 min = parent.InverseTransformPoint(_corners[0]);
            Vector2 max = min;
            for (int i = 1; i < 4; i++)
            {
                Vector2 point = parent.InverseTransformPoint(_corners[i]);
                min = Vector2.Min(min, point);
                max = Vector2.Max(max, point);
            }
            _background.anchorMin = _background.anchorMax = _background.pivot = new Vector2(0.5f, 0.5f);
            _background.sizeDelta = max - min;
            Vector2 center = (min + max) * 0.5f;
            _background.localPosition = new Vector3(center.x, center.y, _background.localPosition.z);
        }

        private void FitHud(Vector2 reference)
        {
            if (_hudRoot == null) return;
            _hudRoot.anchorMin = _hudRoot.anchorMax = new Vector2(1f, 0.5f);
            _hudRoot.anchoredPosition = new Vector2(_hudReferenceOffset.x - reference.x * 0.5f, _hudReferenceOffset.y);
            bool any = false;
            Vector2 min = Vector2.zero, max = Vector2.zero;
            foreach (var graphic in _hudGraphics)
            {
                if (graphic == null || (_clock != null && graphic.transform.IsChildOf(_clock))) continue;
                var rect = graphic.GetComponent<RectTransform>();
                if (rect == null) continue;
                rect.GetWorldCorners(_corners);
                foreach (var corner in _corners)
                {
                    Vector2 point = _canvasRect.InverseTransformPoint(corner);
                    if (!any) { min = max = point; any = true; }
                    else { min = Vector2.Min(min, point); max = Vector2.Max(max, point); }
                }
            }
            if (any)
            {
                Rect bounds = _canvasRect.rect;
                float margin = Mathf.Max(0f, _hudMargin);
                float lowX = bounds.xMin + margin - min.x, highX = bounds.xMax - margin - max.x;
                float lowY = bounds.yMin + margin - min.y, highY = bounds.yMax - margin - max.y;
                Vector2 delta = new Vector2(lowX <= highX ? Mathf.Clamp(0f, lowX, highX) : (lowX + highX) * 0.5f,
                    lowY <= highY ? Mathf.Clamp(0f, lowY, highY) : (lowY + highY) * 0.5f);
                var worldDelta = _canvasRect.TransformVector(new Vector3(delta.x, delta.y, 0f));
                _hudRoot.position += worldDelta;
            }
            if (_clock != null)
            {
                // Keep its CanvasGroup/collapse parent, but retain top-center placement when HUD is clamped.
                Rect bounds = _canvasRect.rect;
                Vector3 position = _canvasRect.TransformPoint(new Vector3(bounds.center.x + _clockReferenceOffset.x,
                    bounds.yMax - reference.y * 0.5f + _clockReferenceOffset.y, 0f));
                position.z = _clock.position.z;
                _clock.position = position;
            }
        }
    }
}
