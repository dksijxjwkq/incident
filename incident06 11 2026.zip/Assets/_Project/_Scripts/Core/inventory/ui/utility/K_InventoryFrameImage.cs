using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Texture-independent slot fill and a frame with a minimum screen-space width.</summary>
    [AddComponentMenu("UI/INCIDENT/Inventory Frame Image")]
    public sealed class K_InventoryFrameImage : Image
    {
        [SerializeField, Tooltip("Рисовать все четыре стороны рамки. Их цвет и прозрачность задаются полем Border Color отдельно от заливки.")]
        private bool _drawFrame = true;

        [SerializeField, Tooltip("Брать цвет рамки из общей палитры инвентаря. Выключить для независимого цвета панели.")]
        private bool _useInventoryLineColor = true;

        [SerializeField, Tooltip("Цвет и прозрачность всех четырёх сторон рамки. По умолчанию совпадают с соединительными линиями снаряжения.")]
        private Color _borderColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 45f / 255f);

        [SerializeField, Min(0f), Tooltip("Толщина рамки в единицах интерфейса до масштабирования Canvas.")]
        private float _borderThickness = 1f;

        [SerializeField, Min(0f), Tooltip("Минимальная толщина каждой стороны в пикселях экрана. 0 отключает ограничение; рамка остаётся внутри слота.")]
        private float _minimumPixelThickness = 1f;

        [SerializeField, Tooltip("Цвет заливки внутри рамки. Умножается на Color компонента Image; не зависит от текстуры Sprite.")]
        private Color _fillColor = new Color(0.02f, 0.02f, 0.02f, 1f);

        private readonly Vector3[] _worldCorners = new Vector3[4];
        private float _lastPixelsX = -1f, _lastPixelsY = -1f;
        private K_ResponsiveCanvasLayout _lineStyle;
        private Color _lastBorderColor;

        public bool DrawFrame => _drawFrame;
        public bool UseInventoryLineColor
        {
            get => _useInventoryLineColor;
            set { if (_useInventoryLineColor == value) return; _useInventoryLineColor = value; SetVerticesDirty(); }
        }
        public Color FillColor
        {
            get => _fillColor;
            set { if (_fillColor == value) return; _fillColor = value; SetVerticesDirty(); }
        }
        public float BorderThickness
        {
            get => _borderThickness;
            set { if (_borderThickness == value) return; _borderThickness = value; SetVerticesDirty(); }
        }
        public Color BorderColor
        {
            get
            {
                if (_useInventoryLineColor && _lineStyle == null) _lineStyle = GetComponentInParent<K_ResponsiveCanvasLayout>();
                return _useInventoryLineColor && _lineStyle != null && _lineStyle.enabled ? _lineStyle.InventoryLineColor : _borderColor;
            }
            set
            {
                if (_borderColor == value) return;
                _borderColor = value;
                SetVerticesDirty();
            }
        }
        public override Texture mainTexture => Texture2D.whiteTexture;

        protected override void OnEnable()
        {
            base.OnEnable();
            _lastPixelsX = _lastPixelsY = -1f;
            _lineStyle = GetComponentInParent<K_ResponsiveCanvasLayout>();
        }

        private void LateUpdate()
        {
            Color border = BorderColor;
            if (border != _lastBorderColor) { _lastBorderColor = border; SetVerticesDirty(); }
            if (!_drawFrame || !IsPositiveFinite(_minimumPixelThickness)) return;
            ReadPixelsPerUnit(out float pixelsX, out float pixelsY);
            if (Mathf.Approximately(pixelsX, _lastPixelsX) && Mathf.Approximately(pixelsY, _lastPixelsY)) return;
            _lastPixelsX = pixelsX;
            _lastPixelsY = pixelsY;
            SetVerticesDirty();
        }

        protected override void OnPopulateMesh(VertexHelper vertices)
        {
            vertices.Clear();
            Rect rect = rectTransform.rect;
            if (!IsPositiveFinite(rect.width) || !IsPositiveFinite(rect.height)) return;

            Color fill = _fillColor * color;
            if (!_drawFrame)
            {
                AddQuad(vertices, rect.xMin, rect.yMin, rect.xMax, rect.yMax, fill);
                return;
            }

            ReadPixelsPerUnit(out float pixelsX, out float pixelsY);
            float baseThickness = IsPositiveFinite(_borderThickness) ? _borderThickness : 0f;
            float minimum = IsPositiveFinite(_minimumPixelThickness) ? _minimumPixelThickness : 0f;
            float width = pixelsX > 0f ? Mathf.Max(baseThickness, minimum / pixelsX) : baseThickness;
            float height = pixelsY > 0f ? Mathf.Max(baseThickness, minimum / pixelsY) : baseThickness;
            width = Mathf.Min(width, rect.width * 0.5f);
            height = Mathf.Min(height, rect.height * 0.5f);

            float left = rect.xMin + width, right = rect.xMax - width;
            float bottom = rect.yMin + height, top = rect.yMax - height;
            Color border = BorderColor;
            // The interior and four strips do not overlap, including the corners.
            // Use the raw rectangle: native pixel adjustment must not collapse a thin side.
            AddQuad(vertices, left, bottom, right, top, fill);
            AddQuad(vertices, rect.xMin, rect.yMin, rect.xMax, bottom, border);
            AddQuad(vertices, rect.xMin, top, rect.xMax, rect.yMax, border);
            AddQuad(vertices, rect.xMin, bottom, left, top, border);
            AddQuad(vertices, right, bottom, rect.xMax, top, border);
        }

        private static void AddQuad(VertexHelper vertices, float left, float bottom, float right, float top, Color tint)
        {
            if (right <= left || top <= bottom) return;
            int first = vertices.currentVertCount;
            vertices.AddVert(new Vector3(left, bottom, 0f), tint, new Vector2(0f, 0f));
            vertices.AddVert(new Vector3(left, top, 0f), tint, new Vector2(0f, 1f));
            vertices.AddVert(new Vector3(right, top, 0f), tint, new Vector2(1f, 1f));
            vertices.AddVert(new Vector3(right, bottom, 0f), tint, new Vector2(1f, 0f));
            vertices.AddTriangle(first, first + 1, first + 2);
            vertices.AddTriangle(first + 2, first + 3, first);
        }

        private void ReadPixelsPerUnit(out float pixelsX, out float pixelsY)
            => ReadPixelsPerUnit(rectTransform, canvas, _worldCorners, out pixelsX, out pixelsY);

        internal static void ReadPixelsPerUnit(RectTransform rectTransform, Canvas owner, Vector3[] worldCorners,
            out float pixelsX, out float pixelsY)
        {
            pixelsX = pixelsY = 0f;
            if (owner == null) return;
            Canvas root = owner.rootCanvas;
            UnityEngine.Camera camera = root.renderMode == RenderMode.ScreenSpaceOverlay ? null : root.worldCamera;
            if (root.renderMode != RenderMode.ScreenSpaceOverlay && camera == null) return;

            Vector3 worldX = rectTransform.TransformVector(new Vector3(1f, 0f, 0f));
            Vector3 worldY = rectTransform.TransformVector(new Vector3(0f, 1f, 0f));
            if (root.renderMode == RenderMode.ScreenSpaceOverlay)
            {
                // Overlay projection is affine: the same metric applies at every corner.
                // Most inventory cells use this path; avoid sixteen native projections per cell.
                float area = Mathf.Abs(worldX.x * worldY.y - worldX.y * worldY.x);
                float lengthX = ((Vector2)worldX).magnitude, lengthY = ((Vector2)worldY).magnitude;
                if (IsPositiveFinite(area) && IsPositiveFinite(lengthX) && IsPositiveFinite(lengthY))
                {
                    pixelsX = area / lengthY;
                    pixelsY = area / lengthX;
                }
                return;
            }
            rectTransform.GetWorldCorners(worldCorners);
            float minimumX = float.PositiveInfinity, minimumY = float.PositiveInfinity;
            for (int i = 0; i < worldCorners.Length; i++)
            {
                Vector3 world = worldCorners[i];
                if (camera != null && camera.WorldToScreenPoint(world).z <= 0f) return;
                Vector2 point = RectTransformUtility.WorldToScreenPoint(camera, world);
                Vector2 x = RectTransformUtility.WorldToScreenPoint(camera, world + worldX) - point;
                Vector2 y = RectTransformUtility.WorldToScreenPoint(camera, world + worldY) - point;
                float area = Mathf.Abs(x.x * y.y - x.y * y.x);
                float xLength = x.magnitude, yLength = y.magnitude;
                if (!IsPositiveFinite(area) || !IsPositiveFinite(xLength) || !IsPositiveFinite(yLength)) return;
                minimumX = Mathf.Min(minimumX, area / yLength);
                minimumY = Mathf.Min(minimumY, area / xLength);
            }
            if (!IsPositiveFinite(minimumX) || !IsPositiveFinite(minimumY)) return;
            pixelsX = minimumX;
            pixelsY = minimumY;
        }

        private static bool IsPositiveFinite(float value)
            => value > 0f && !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
