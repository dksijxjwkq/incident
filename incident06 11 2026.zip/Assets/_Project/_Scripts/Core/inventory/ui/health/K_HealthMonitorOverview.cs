using System.Collections.Generic;
using System.Text;

namespace K_Incident.Core.Inventory
{
    public static class K_HealthMonitorOverview
    {
        public static string Build(IReadOnlyList<HealthGadgetEntry> effects, IReadOnlyList<HealthGadgetEntry> indicators,
            K_HealthSystem health, K_VitalitySystem vitality, K_BloodSystem blood, K_WeightManager weight, bool preview)
        {
            var text = new StringBuilder();
            if (!preview && health==null && effects.Count==0 && indicators.Count==0) return "Нет показаний.";

            if (!preview && health != null && health.IsDead) return "<b>Пульс отсутствует</b>\nЛечение невозможно.";
            text.Append("<b>В первую очередь</b>\n");
            int urgent = 0;
            if (!preview && blood != null && (blood.State == BloodState.Shock || blood.State == BloodState.Weakness))
            { text.Append("• Опасная кровопотеря: остановите кровотечения и восполните кровь.\n"); urgent++; }
            if (Has(effects, HealthGadgetKind.Bleeding))
            { text.Append("• Наружное кровотечение: остановите его бинтом, давящим пакетом или гемостатической марлей.\n"); urgent++; }
            if (Has(effects, HealthGadgetKind.InternalBleeding))
            { text.Append("• Обнаружено внутреннее кровотечение: Транексам уменьшает потерю крови. Подготовьте участок гемостатической губкой, затем обработайте хирургическим набором.\n"); urgent++; }
            if ((!preview && vitality != null && vitality.IsColdCritical) || (preview && Critical(indicators, HealthGadgetKind.Cold)))
            { text.Append("• Критическое переохлаждение: перейдите в более тёплое место.\n"); urgent++; }
            if ((!preview && vitality != null && vitality.Radiation >= 75f) || (preview && Critical(indicators, HealthGadgetKind.Radiation, .75f)))
            { text.Append("• Высокая радиация: избегайте облучения, следите за показателем и кровотечениями.\n"); urgent++; }
            if (!preview && health != null)
                foreach (var part in new[] { BodyPart.Head, BodyPart.Chest })
                    if (health.GetHPPercent(part) <= .25f)
                    { text.Append("• Критическое повреждение ").Append(part == BodyPart.Head ? "головы" : "груди").Append(": займитесь этой травмой как можно скорее.\n"); urgent++; }
            if (urgent == 0) text.Append("Срочных угроз по показаниям нет.\n");
            text.Append("\n<b>Восстановление</b>\n");
            bool blockers = false;
            foreach (var kind in new[] { HealthGadgetKind.Gunshot })
                if (Has(effects, kind)) { text.Append("• ").Append(K_HealthGadgetContent.GetTitle(kind)).Append(" — заживление повреждённых участков остановлено.\n"); blockers = true; }
            if (Has(effects,HealthGadgetKind.Fracture))
            {
                text.Append("• Переломы: проверьте фиксацию и оставшееся время восстановления.\n");
                blockers = true;
            }
            if ((preview && Has(effects, HealthGadgetKind.Laceration)) || (!preview && health != null && health.HasAnyOpenLaceration()))
            { text.Append("• Открытые раны нужно закрыть.\n"); blockers = true; }
            if (Has(effects, HealthGadgetKind.Bleeding) || Has(effects, HealthGadgetKind.InternalBleeding))
            { text.Append("• Остановите кровотечения: из-за них повреждённые участки не заживают.\n"); blockers = true; }
            if (Has(effects, HealthGadgetKind.WoundInfection))
            { text.Append("• Инфекция раны мешает заживлению. Обработайте участок и начните курс антибиотика.\n"); blockers = true; }
            if (Has(effects, HealthGadgetKind.ColdIllness))
                text.Append("• При простуде больше отдыхайте: в покое она проходит быстрее.\n");
            if (!blockers) text.Append("Известных травм, мешающих заживлению, нет. Следите за едой и водой. Раневой гидрогель может ускорить восстановление обработанных мягких тканей.\n");
            if (!preview && weight != null && !weight.CanSprint()) text.Append("• Груз мешает спринту: оставьте часть вещей.\n");
            text.Append("\n<b>Текущие показатели</b>\n");
            foreach (var entry in indicators) text.Append(entry.Title).Append(": ").Append(entry.Value).Append('\n');
            text.Append("\nО травмах и других состояниях — во вкладке «Эффекты». Подходящие средства — в «Лечении».");
            return text.ToString();
        }
        private static bool Has(IReadOnlyList<HealthGadgetEntry> entries, HealthGadgetKind kind)
        { foreach (var e in entries) if (e.Kind == kind) return true; return false; }
        private static bool Critical(IReadOnlyList<HealthGadgetEntry> entries, HealthGadgetKind kind, float threshold=.99f)
        { foreach (var e in entries) if (e.Kind == kind) return e.NormalizedValue >= threshold; return false; }
    }
}
