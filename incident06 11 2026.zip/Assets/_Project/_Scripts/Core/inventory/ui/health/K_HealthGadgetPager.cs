using UnityEngine;
using UnityEngine.EventSystems;

namespace K_Incident.Core.Inventory
{
    /// <summary>Wheel input stays inside the effect area; detail scrolling uses its own ScrollRect.</summary>
    public sealed class K_HealthGadgetPager : MonoBehaviour, IScrollHandler
    {
        public K_HealthStatusGadget Owner { get; set; }
        public void OnScroll(PointerEventData eventData)
        {
            if (Owner == null || eventData == null || Mathf.Abs(eventData.scrollDelta.y) < 0.01f) return;
            Owner.ChangePage(eventData.scrollDelta.y < 0f ? 1 : -1);
            eventData.Use();
        }
    }
}
