using K_Incident.Core;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>Read-only segment details. One nonblocking popup serves the whole inventory doll.</summary>
public sealed class K_HealthSegmentTooltip : MonoBehaviour
{
    private static readonly string[] PartNames =
    {
        "Голова", "Грудь", "Живот", "Таз", "Левое плечо", "Правое плечо",
        "Левый бицепс", "Правый бицепс", "Левое предплечье", "Правое предплечье",
        "Левая кисть", "Правая кисть", "Левое бедро", "Правое бедро",
        "Левое колено", "Правое колено", "Левая голень", "Правая голень",
        "Левая стопа", "Правая стопа"
    };

    private K_InventoryHealthWidget _owner;
    private K_HealthSystem _health;
    private K_DebuffSystem _debuffs;
    private TMP_FontAsset _font;
    private bool _bound;
    private bool _hovering;
    private BodyPart _part;
    private PointerEventData _pointer;
    private GameObject _root;
    private RectTransform _panel;
    private TextMeshProUGUI _label;
    private float _nextRefresh;

    internal void Bind(K_InventoryHealthWidget owner, K_HealthSystem health,
        Image[] segments, TextMeshProUGUI fontSource, K_DebuffSystem debuffs = null)
    {
        _owner = owner;
        _health = health;
        _debuffs = debuffs ?? _debuffs;
        _font = fontSource != null ? fontSource.font : TMP_Settings.defaultFontAsset;
        if (_bound || segments == null) return;
        _bound = true;

        for (int i = 0; i < Mathf.Min(segments.Length, PartNames.Length); i++)
        {
            if (segments[i] == null) continue;
            var trigger = segments[i].GetComponent<EventTrigger>();
            if (trigger == null) trigger = segments[i].gameObject.AddComponent<EventTrigger>();
            var part = (BodyPart)i;
            var enter = new EventTrigger.Entry { eventID = EventTriggerType.PointerEnter };
            enter.callback.AddListener(data => Show(part, data as PointerEventData));
            trigger.triggers.Add(enter);
            var exit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
            exit.callback.AddListener(_ => { if (_part == part) Hide(); });
            trigger.triggers.Add(exit);
            var press = new EventTrigger.Entry { eventID = EventTriggerType.PointerDown };
            press.callback.AddListener(_ => Hide());
            trigger.triggers.Add(press);
            var drag = new EventTrigger.Entry { eventID = EventTriggerType.BeginDrag };
            drag.callback.AddListener(_ => Hide());
            trigger.triggers.Add(drag);
        }
    }

    private void Show(BodyPart part, PointerEventData pointer)
    {
        if (_owner == null || !_owner.isActiveAndEnabled || _health == null
            || pointer == null || pointer.dragging) return;
        _part = part;
        _pointer = pointer;
        _hovering = true;
        EnsurePopup();
        _root.SetActive(true);
        _nextRefresh = 0f;
        RefreshPopup();
    }

    private void LateUpdate()
    {
        if (!_hovering) return;
        if (_owner == null || !_owner.isActiveAndEnabled || _health == null
            || _pointer == null || _pointer.dragging)
        {
            Hide();
            return;
        }
        RefreshPopup();
    }

    private void RefreshPopup()
    {
        float width = Mathf.Min(360f, Mathf.Max(1f, Screen.width - 16f));
        _panel.sizeDelta = new Vector2(width, _panel.sizeDelta.y);
        if (Time.unscaledTime >= _nextRefresh)
        {
            _label.text = BuildText(_health, _part, _debuffs);
            _nextRefresh = Time.unscaledTime + 0.1f;
        }
        float height = Mathf.Min(_label.preferredHeight + 20f, Mathf.Max(1f, Screen.height - 16f));
        _panel.sizeDelta = new Vector2(width, height);
        var point = _pointer.position + new Vector2(16f, -16f);
        _panel.anchoredPosition = new Vector2(
            Mathf.Clamp(point.x, 8f, Mathf.Max(8f, Screen.width - width - 8f)),
            Mathf.Clamp(point.y, height + 8f, Mathf.Max(height + 8f, Screen.height - 8f)));
    }

    internal static string BuildText(K_HealthSystem health, BodyPart part, K_DebuffSystem debuffs = null)
    {
        int index = (int)part;
        if (health == null || index < 0 || index >= PartNames.Length) return string.Empty;
        float hp = health.GetHP(part);
        var text = new StringBuilder(PartNames[index]);
        text.Append($"\nHP: {hp:0.#} / {health.GetMaxHP(part):0.#}");
        bool hasInjuries = false;
        void Injury(string line)
        {
            text.Append('\n').Append(line);
            hasInjuries = true;
        }

        // The radiation cap is not damage that a segment medicine can restore.
        if (hp < health.GetEffectiveMaxHP(part)) Injury("Повреждение: гель");
        bool fracture = health.IsFractured(part) && !health.IsSplinted(part);
        bool gunshot = health.IsGunshot(part);
        if (fracture)
            Injury(part == BodyPart.Head ? "Перелом: воротник" : "Перелом: шина / SAM");
        if (gunshot) Injury("Огнестрел: хирург. набор");

        bool mechanicalPart = IsMechanicalApplicationPart(part);
        int bleeding = health.GetBleedingLevel(part);
        if (bleeding > 0)
            Injury($"Кровотечение L{bleeding}: бинт / гемостатик" + (mechanicalPart ? " / жгут" : string.Empty));

        var wound = health.GetLacerationType(part);
        if (wound == LacerationType.Open) Injury("Открытая рана: клей / стрипы / степлер");
        else if (wound == LacerationType.Glued) Injury("Заклеенная рана: стрипы / степлер");

        // Before reveal, the output is identical to a segment without internal bleeding.
        if (health.IsInternalBleedingRevealed(part))
            Injury("Внутреннее кровотечение: коагулянт / Трансамача" + (mechanicalPart ? " / JETT" : string.Empty));

        if (debuffs != null)
        {
            if (part == BodyPart.Head)
            {
                if (debuffs.HasConcussion)
                    Injury(fracture
                        ? "Сотрясение: воротник; обезбол — симптомы"
                        : "Сотрясение: время; обезбол — симптомы");
                if (debuffs.HasTBI) Injury("ЧМТ: воротник");
            }
            else if (part == BodyPart.Chest && debuffs.HasBreathingDifficulty && (fracture || gunshot))
                Injury("Тяжело дышать: " + (fracture ? "шина / SAM" : string.Empty)
                    + (fracture && gunshot ? " + " : string.Empty) + (gunshot ? "хирург. набор" : string.Empty));
            else if (part == BodyPart.Pelvis && debuffs.HasImmobilized && fracture)
                Injury("Обездвижен: шина / SAM");
        }

        if (!hasInjuries) text.Append("\nТравм не обнаружено");
        return text.ToString();
    }

    private static bool IsMechanicalApplicationPart(BodyPart part)
        => part == BodyPart.LeftShoulder || part == BodyPart.RightShoulder
        || part == BodyPart.LeftQuadriceps || part == BodyPart.RightQuadriceps;

    private void EnsurePopup()
    {
        if (_root != null) return;
        // A separate overlay keeps this popup in screen pixels even when the doll uses a world canvas.
        _root = new GameObject("HealthSegmentTooltip", typeof(RectTransform), typeof(Canvas), typeof(CanvasGroup));
        var canvas = _root.GetComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvas.overrideSorting = true;
        canvas.sortingOrder = 31990;
        var group = _root.GetComponent<CanvasGroup>();
        group.interactable = false;
        group.blocksRaycasts = false;

        var panelObject = new GameObject("Panel", typeof(RectTransform), typeof(Image), typeof(Outline));
        panelObject.transform.SetParent(_root.transform, false);
        _panel = panelObject.GetComponent<RectTransform>();
        _panel.anchorMin = _panel.anchorMax = Vector2.zero;
        _panel.pivot = new Vector2(0f, 1f);
        var background = panelObject.GetComponent<Image>();
        background.color = new Color(0.08f, 0.09f, 0.11f, 0.97f);
        background.raycastTarget = false;
        var outline = panelObject.GetComponent<Outline>();
        outline.effectColor = new Color(0.2f, 0.22f, 0.25f, 0.8f);
        outline.effectDistance = new Vector2(1f, -1f);

        var textObject = new GameObject("Text", typeof(RectTransform), typeof(TextMeshProUGUI));
        textObject.transform.SetParent(_panel, false);
        var textRect = textObject.GetComponent<RectTransform>();
        textRect.anchorMin = Vector2.zero;
        textRect.anchorMax = Vector2.one;
        textRect.offsetMin = new Vector2(10f, 10f);
        textRect.offsetMax = new Vector2(-10f, -10f);
        _label = textObject.GetComponent<TextMeshProUGUI>();
        if (_font != null) _label.font = _font;
        _label.fontSize = 13f;
        _label.color = new Color(0.9f, 0.9f, 0.9f, 1f);
        _label.alignment = TextAlignmentOptions.TopLeft;
        _label.textWrappingMode = TextWrappingModes.Normal;
        _label.overflowMode = TextOverflowModes.Truncate;
        _label.richText = false;
        _label.raycastTarget = false;
    }

    private void Hide()
    {
        _hovering = false;
        _pointer = null;
        if (_root != null) _root.SetActive(false);
    }

    private void OnDisable() => Hide();

    private void OnDestroy()
    {
        if (_root != null) Destroy(_root);
    }
}
