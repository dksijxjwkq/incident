using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Read-only presentation of the owned medical apply session on its current item view.</summary>
    public sealed class K_MedicalItemUseProgress : MonoBehaviour
    {
        private const float MaximumDiameter = 32f;
        private K_MedicalApplyService _service;
        private K_MedicalMirrorPanel _mirror;
        private RectTransform _target;
        private UI_Item _ordinaryView;
        private K_MedicalMirrorItem _mirrorView;
        private UnityEngine.UI.Image _shade;
        private K_MedicalUseRingGraphic _ring;
        private uint _itemInstanceId;
        private float _nextViewSearch;

        public bool IsVisible => _shade != null && _shade.gameObject.activeInHierarchy;
        public uint ItemInstanceId => _itemInstanceId;
        public RectTransform ItemView => _target;
        public float RingDiameter => _ring != null ? _ring.rectTransform.rect.width : 0f;
        public float Progress => _ring != null ? _ring.Progress : 0f;

        public void Connect(K_MedicalApplyService service, K_MedicalMirrorPanel mirror, K_InventoryUI inventory)
        {
            if (_service != service) Clear();
            _service = service;
            _mirror = mirror;
        }

        public void Disconnect(K_MedicalApplyService service)
        {
            if (_service != service) return;
            Clear();
            _service = null;
            _mirror = null;
        }

        private void LateUpdate() => RefreshNow();

        public void RefreshNow()
        {
            var item = _service != null && _service.IsApplying ? _service.AppliedRecord.Item : null;
            if (item == null) { Clear(); return; }
            if (_itemInstanceId != item.InstanceID)
            {
                Clear();
                _itemInstanceId = item.InstanceID;
            }

            if (!TargetStillMatches() || Time.unscaledTime >= _nextViewSearch)
            {
                _nextViewSearch = Time.unscaledTime + .1f;
                ResolveVisibleView();
            }
            if (_target == null)
            {
                Hide();
                return;
            }

            EnsureVisual();
            if (_shade.transform.parent != _target) _shade.transform.SetParent(_target, false);
            var rect = _shade.rectTransform;
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = rect.offsetMax = Vector2.zero;
            _shade.transform.SetAsLastSibling();
            float available = Mathf.Min(_target.rect.width, _target.rect.height) - 6f;
            float diameter = Mathf.Clamp(available, 12f, MaximumDiameter);
            _ring.rectTransform.sizeDelta = new Vector2(diameter, diameter);
            _ring.Progress = _service.Progress;
            _shade.gameObject.SetActive(true);
        }

        private bool TargetStillMatches()
        {
            if (_target == null || !Visible(_target)) return false;
            return _mirrorView != null && Matches(_mirrorView.Item) ||
                   _ordinaryView != null && Matches(_ordinaryView.Item);
        }

        private bool Matches(InventoryItem item)
            => item != null && item.InstanceID == _itemInstanceId &&
               object.ReferenceEquals(item, _service.AppliedRecord.Item);

        private void ResolveVisibleView()
        {
            _target = null;
            _ordinaryView = null;
            _mirrorView = null;
            if (_mirror != null && _mirror.isActiveAndEnabled)
                foreach (var view in _mirror.ActiveWidgets)
                    if (view != null && Matches(view.Item) && Visible(view.transform))
                    {
                        _mirrorView = view;
                        _target = view.transform as RectTransform;
                        return;
                    }

            foreach (var view in UnityEngine.Object.FindObjectsByType<UI_Item>(FindObjectsSortMode.None))
                if (view != null && Matches(view.Item) && Visible(view.transform))
                {
                    _ordinaryView = view;
                    _target = view.transform as RectTransform;
                    return;
                }
        }

        private static bool Visible(Transform view)
        {
            if (!view.gameObject.activeInHierarchy) return false;
            for (var current = view; current != null; current = current.parent)
            {
                var group = current.GetComponent<CanvasGroup>();
                if (group == null || !group.enabled) continue;
                if (group.alpha <= .001f) return false;
                if (group.ignoreParentGroups) break;
            }
            return true;
        }

        private void EnsureVisual()
        {
            if (_shade != null) return;
            var root = new GameObject("MedicalItemUse", typeof(RectTransform), typeof(UnityEngine.UI.Image), typeof(CanvasGroup));
            root.hideFlags = HideFlags.DontSave;
            root.layer = _target.gameObject.layer;
            root.transform.SetParent(_target, false);
            _shade = root.GetComponent<UnityEngine.UI.Image>();
            _shade.color = new Color(0f, 0f, 0f, .24f);
            _shade.raycastTarget = false;
            var group = root.GetComponent<CanvasGroup>();
            group.interactable = group.blocksRaycasts = false;

            var ringObject = new GameObject("ProgressRing", typeof(RectTransform), typeof(CanvasRenderer), typeof(K_MedicalUseRingGraphic));
            ringObject.layer = root.layer;
            ringObject.transform.SetParent(root.transform, false);
            _ring = ringObject.GetComponent<K_MedicalUseRingGraphic>();
            _ring.raycastTarget = false;
            _ring.rectTransform.anchorMin = _ring.rectTransform.anchorMax = new Vector2(.5f, .5f);
            _ring.rectTransform.pivot = new Vector2(.5f, .5f);
            _ring.rectTransform.anchoredPosition = Vector2.zero;
        }

        private void Hide()
        {
            if (_shade == null) return;
            _shade.gameObject.SetActive(false);
            _shade.transform.SetParent(transform, false);
        }

        public void Clear()
        {
            Hide();
            _itemInstanceId = 0;
            _target = null;
            _ordinaryView = null;
            _mirrorView = null;
        }

        private void OnDisable() => Clear();
        private void OnDestroy()
        {
            if (_shade != null) Destroy(_shade.gameObject);
        }
    }
}
