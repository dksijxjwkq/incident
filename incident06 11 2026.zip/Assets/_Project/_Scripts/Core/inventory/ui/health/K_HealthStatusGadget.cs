using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

namespace K_Incident.Core.Inventory
{
    public enum HealthGadgetScreen { Icons, Summary, Treatment, Journal, Pulse }
    public enum HealthGadgetFilter { All, Injuries, Treatment }
    /// <summary>Inventory-only, read-only medical display. All values come from the existing player systems.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(RectTransform))]
    [AddComponentMenu("INCIDENT/UI/Health Status Gadget")]
    public sealed class K_HealthStatusGadget : MonoBehaviour
    {
        [Serializable]
        public sealed class IconBinding
        {
            public HealthGadgetKind Kind;
            [Tooltip("Существующий спрайт состояния или предмета. При отсутствии показывается название, а не пустой квадрат.")]
            public Sprite Sprite;
            [Tooltip("Необязательная исходная иконка. Новый спрайт, назначенный ей позже, автоматически появится на мониторе.")]
            public UnityEngine.UI.Image Source;
        }

        [Header("Existing systems")]
        [SerializeField] private K_HealthSystem _health;
        [SerializeField] private K_VitalitySystem _vitality;
        [SerializeField] private K_DebuffSystem _debuffs;
        [SerializeField] private K_BloodSystem _blood;
        [SerializeField] private K_WeightManager _weight;
        [SerializeField] private K_EcgMonitor _ecg;
        [SerializeField] private K_InventoryUI _inventory;
        [SerializeField] private TMP_FontAsset _font;
        [SerializeField] private IconBinding[] _icons = Array.Empty<IconBinding>();
        [SerializeField, Tooltip("Старая группа иконок только инвентаря. Скрывается на время работы гаджета; HUD не затрагивается.")]
        private GameObject _legacyStatuses;

        [Header("Layout")]
        [SerializeField, Tooltip("Пульс отдельной вкладкой внутри гаджета. Auto Size задаёт автоматические размеры, Width и Height — ручные. Выключено — прежняя компоновка под ЭКГ.")]
        private bool _embedPulse = true;
        [SerializeField, Tooltip("Необязательная нижняя граница для Auto Size. Пусто — автоматически находится видимая область медсетки (Viewport). При ручной ссылке корпус выравнивается по нижнему краю выбранного RectTransform.")]
        private RectTransform _medicalPanel;
        [SerializeField, Tooltip("Включено — корпус по ширине ЭКГ и до низа медсетки. Выключено — размеры задаются полями Width и Height ниже. В прежней компоновке под ЭКГ размеры всегда ручные.")]
        private bool _autoSize = false;
        [SerializeField, Min(520f), Tooltip("Ширина корпуса в единицах Canvas, когда Auto Size выключен. Минимум 520. Колонки эффектов подстраиваются под ширину; остальные эффекты доступны на следующих страницах.")]
        private float _width = 760f;
        [SerializeField, Min(520f), Tooltip("Высота корпуса в единицах Canvas, когда Auto Size выключен. Минимум 520; при крупном шрифте минимум увеличивается, чтобы подписи и показатели не накладывались.")]
        private float _height = 520f;
        [SerializeField, Min(0f), Tooltip("Расстояние под ЭКГ в прежнем режиме. При встроенном пульсе не используется.")]
        private float _gapBelowEcg = 12f;
        [SerializeField, Range(3, 6), Tooltip("Число колонок эффектов. Всегда два ряда; остальные эффекты доступны на следующих страницах.")]
        private int _columns = 3;
        [SerializeField, Range(48f, 112f), Tooltip("Размер существующих иконок эффектов. При узкой ячейке размер ограничивается её границами.")]
        private float _iconSize = 80f;
        [SerializeField, Range(0.27f, 0.42f), Tooltip("Доля ширины экрана для постоянных числовых индикаторов.")]
        private float _indicatorWidthFraction = 0.33f;
        [SerializeField, Range(16f, 24f), Tooltip("Основной размер текста. Длинные названия переносятся; подробности открываются по ЛКМ.")]
        private float _fontSize = 18f;

        [Header("Appearance")]
        [SerializeField, Tooltip("Цвет светящихся пиктограмм и текста экрана. Не меняет цвета остального инвентаря или ЭКГ.")]
        private Color _foreground = new Color(0.84f, 0.84f, 0.84f, 1f);
        [SerializeField, Tooltip("Нейтральная заливка корпуса. Линии и шапка наследуют стиль инвентаря.")]
        private Color _caseFill = new Color(0.16f, 0.16f, 0.16f, 1f);
        [SerializeField, Tooltip("Заливка утопленного экрана.")]
        private Color _screenFill = new Color(0.02f, 0.02f, 0.02f, 1f);
        [SerializeField, Range(0f, 1f), Tooltip("Сила коротких помех при открытии вкладки. 0 отключает помехи.")]
        private float _startupNoise = 0.9f;
        [SerializeField, Range(0f, 1.5f), Tooltip("Длительность включения в секундах. Используется время интерфейса, независимо от паузы игры.")]
        private float _startupDuration = 0.85f;
        [SerializeField, Range(0f, 0.1f), Tooltip("Прозрачность спокойных строк экрана. 0 отключает строки.")]
        private float _scanlineOpacity = 0.006f;
        [SerializeField, Tooltip("Мягко менять яркость индикатора питания на корпусе.")]
        private bool _animatePowerLight = true;

        private sealed class Card
        {
            public RectTransform Rect;
            public UnityEngine.UI.Button Button;
            public UnityEngine.UI.Image Icon;
            public TextMeshProUGUI Title;
            public TextMeshProUGUI Value;
            public UnityEngine.UI.Image Track;
            public UnityEngine.UI.Image Fill;
            public UnityEngine.UI.Image Highlight;
            public HealthGadgetKind Kind;
            public bool IsIndicator;
        }

        private readonly List<HealthGadgetEntry> _effects = new List<HealthGadgetEntry>(24);
        private readonly List<HealthGadgetEntry> _indicators = new List<HealthGadgetEntry>(6);
        private readonly List<HealthGadgetKind> _arrivalOrder = new List<HealthGadgetKind>(24);
        private readonly List<HealthGadgetEntry> _orderedEffects = new List<HealthGadgetEntry>(24);
        private readonly List<Card> _effectCards = new List<Card>(12);
        private readonly List<Card> _indicatorCards = new List<Card>(6);
        private readonly Dictionary<HealthGadgetKind, float> _effectHighlightUntil = new Dictionary<HealthGadgetKind, float>();
        private readonly Dictionary<HealthGadgetKind, EffectPresentation> _previousEffects = new Dictionary<HealthGadgetKind, EffectPresentation>();
        private readonly List<HealthGadgetKind> _removedEffects = new List<HealthGadgetKind>();
        private readonly List<UnityEngine.UI.Button> _filterButtons = new List<UnityEngine.UI.Button>(3);
        private RectTransform _filterBar;
        private HealthGadgetFilter _selectedFilter;
        private bool _hasEffectBaseline;
        private struct EffectPresentation
        {
            public float Normalized;
            public string Source;
        }
        private RectTransform _rect, _visualRoot, _screen, _main, _detail, _effectsArea, _indicatorsArea, _popup;
        private RectTransform _header, _footer, _detailContent, _popupBlocker;
        private TextMeshProUGUI _heading, _total, _empty, _pageText, _detailText, _modelLabel;
        private UnityEngine.UI.Button _previous, _next, _close;
        private UnityEngine.UI.ScrollRect _detailScroll;
        private UnityEngine.UI.Image _separator;
        private K_HealthGadgetHardwareGraphic _powerLight, _powerMark;
        private CanvasGroup _screenGroup;
        private K_HealthGadgetScreenFX _screenFx;
        private Material _screenTextMaterial;
        private HealthGadgetKind? _menuKind, _detailKind;
        private bool _built, _legacyWasActive, _legacyHidden;
        private int _page;
        private float _bootStarted, _nextRefresh, _headerHeight = 32f;
        private Vector2 _lastSize;
        private readonly Vector3[] _separatorCorners = new Vector3[4];
        private string _lastDetailText;
        private RectTransform _navigation, _pulseArea;
        private K_EcgMonitor _pulseDisplay;
        private TextMeshProUGUI _pulseNote;
        private bool _ecgWasActive, _ecgHidden;
        private readonly List<UnityEngine.UI.Button> _tabs = new List<UnityEngine.UI.Button>(5);
        private HealthGadgetScreen _selectedScreen;
        private K_HealthMonitorHistory _history;
        private K_MedicalMirrorPanel _medicalMirror;
        private float _nextSectionRefresh;
        public HealthGadgetScreen CurrentScreen => _selectedScreen;
        public HealthGadgetFilter CurrentFilter => _selectedFilter;

        public int ActiveEffectCount => _effects.Count;
        public int VisibleEffectCount => _orderedEffects.Count;
        public int PageCount => Mathf.Max(1, (_orderedEffects.Count + PageCapacity - 1) / PageCapacity);
        public int CurrentPage => _page;
        public int PageCapacity => LayoutColumns * 2;
        public Vector2 CurrentSize => _rect != null ? _rect.rect.size : Vector2.zero;
        public bool AutoSize { get => _autoSize; set { _autoSize = value; RefreshLayout(); } }
        public Vector2 CustomSize
        {
            get => new Vector2(_width, _height);
            set
            {
                _width = SafeDimension(value.x, 760f, 520f);
                _height = SafeDimension(value.y, 520f, MinimumHeight);
                RefreshLayout();
            }
        }
        private float MinimumHeight => Mathf.Max(520f, _headerHeight + 120f + 6f *
            (Mathf.Max(23f, _fontSize * 1.25f) + Mathf.Max(26f, _fontSize * 1.35f) + 10f));
        private float EffectValueHeight => Mathf.Max(32f, (_fontSize - 2f) * 2.2f);
        private int LayoutColumns
        {
            get
            {
                float area = Mathf.Max(1f, (_rect != null ? _rect.rect.width : _width) - 60f);
                float left = area - IndicatorWidth(area) - 20f;
                float cell = Mathf.Max(100f, Mathf.Clamp(_iconSize, 48f, 112f) + 18f);
                return Mathf.Clamp(Mathf.FloorToInt(left / cell), 1, Mathf.Clamp(_columns, 3, 6));
            }
        }
        private float IndicatorWidth(float area) => Mathf.Clamp(area * Mathf.Clamp(_indicatorWidthFraction, .27f, .42f), 148f, Mathf.Max(148f, area - 128f));
        private static float SafeDimension(float value, float fallback, float minimum)
            => Mathf.Clamp(float.IsNaN(value) || float.IsInfinity(value) ? fallback : value, minimum, 4096f);

        private void OnValidate()
        {
            _fontSize = Mathf.Clamp(_fontSize, 16f, 24f);
            _width = SafeDimension(_width, 760f, 520f);
            _height = SafeDimension(_height, 520f, MinimumHeight);
        }

        private void RefreshLayout()
        {
            if (!_built) return;
            FollowEcg();
            Layout();
            _page = Mathf.Clamp(_page, 0, PageCount - 1);
            CloseMenu();
            Present();
        }
        public bool IsDetailOpen => _detailKind.HasValue;
        public bool IsOpenMenuVisible => _menuKind.HasValue;
        public bool IsPowered => isActiveAndEnabled;

#if UNITY_EDITOR
        public void ReplayEditorStartup()
        {
            if (!_built) return;
            BeginBoot();
            AnimateScreen();
        }
#endif

        private void OnEnable()
        {
            if (!Application.isPlaying) return;
            EnsureVisuals();
            _visualRoot.gameObject.SetActive(true);
            HideLegacy();
            SyncOriginalPulse();
            _page = 0;
            _detailKind = null;
            CloseMenu();
            BeginBoot();
            RefreshNow();
        }

        private void OnDisable()
        {
            CloseMenu();
            _detailKind = null;
            if (_visualRoot != null) _visualRoot.gameObject.SetActive(false);
            RestoreLegacy();
            RestoreOriginalPulse();
        }

        private void OnDestroy()
        {
            RestoreLegacy();
            RestoreOriginalPulse();
            if (_visualRoot != null) Destroy(_visualRoot.gameObject);
            if (_screenTextMaterial != null) Destroy(_screenTextMaterial);
        }

        private void HideLegacy()
        {
            if (_legacyStatuses == null || _legacyHidden) return;
            _legacyWasActive = _legacyStatuses.activeSelf;
            _legacyStatuses.SetActive(false);
            _legacyHidden = true;
        }

        private void RestoreLegacy()
        {
            if (_legacyHidden && _legacyStatuses != null) _legacyStatuses.SetActive(_legacyWasActive);
            _legacyHidden = false;
        }

        private void LateUpdate()
        {
            if (!_built) return;
            _history?.ConnectMedicalService(_inventory?.MedicalApplyService, _font);
            SyncOriginalPulse();
            FollowEcg();
            if (_lastSize != _rect.rect.size) RefreshLayout();
            if (Time.unscaledTime >= _nextRefresh) RefreshNow();
            AnimateScreen();
        }

        public void RefreshNow()
        {
            if (!_built) return;
            K_HealthGadgetContent.Collect(_effects, _indicators, _health, _vitality, _debuffs, _blood, _weight);
            ObserveEffectChanges();
            // Existing effects keep their slots; newly appearing types append in arrival order.
            for (int i = _arrivalOrder.Count - 1; i >= 0; i--)
                if (Find(_effects, _arrivalOrder[i]) == null) _arrivalOrder.RemoveAt(i);
            for (int i = 0; i < _effects.Count; i++)
                if (!_arrivalOrder.Contains(_effects[i].Kind)) _arrivalOrder.Add(_effects[i].Kind);
            _orderedEffects.Clear();
            for (int i = 0; i < _arrivalOrder.Count; i++)
            {
                var entry = Find(_effects, _arrivalOrder[i]);
                if (entry != null && MatchesFilter(entry.Kind)) _orderedEffects.Add(entry);
            }
            if (_menuKind.HasValue && Current(_menuKind.Value) == null) CloseMenu();
            FollowEcg();
            Layout();
            _page = Mathf.Clamp(_page, 0, PageCount - 1);
            Present();
            _nextRefresh = Time.unscaledTime + 0.2f;
        }

        private static HealthGadgetEntry Find(List<HealthGadgetEntry> entries, HealthGadgetKind kind)
        {
            for (int i = 0; i < entries.Count; i++) if (entries[i].Kind == kind) return entries[i];
            return null;
        }

        private HealthGadgetEntry Current(HealthGadgetKind kind) => Find(_effects, kind) ?? Find(_indicators, kind);

        private bool MatchesFilter(HealthGadgetKind kind) => _selectedFilter == HealthGadgetFilter.All ||
            (_selectedFilter == HealthGadgetFilter.Injuries ? K_HealthGadgetContent.IsInjury(kind) : K_HealthGadgetContent.IsTreatment(kind));

        public void SelectFilter(HealthGadgetFilter filter)
        {
            if ((int)filter < 0 || (int)filter > (int)HealthGadgetFilter.Treatment || _selectedFilter == filter) return;
            _selectedFilter = filter;
            _page = 0;
            CloseMenu();
            RefreshNow();
        }

        private void ObserveEffectChanges()
        {
            _removedEffects.Clear();
            foreach (var previous in _previousEffects)
                if (Find(_effects, previous.Key) == null) _removedEffects.Add(previous.Key);
            foreach (var removed in _removedEffects) _previousEffects.Remove(removed);
            foreach (var entry in _effects)
            {
                // The first line is a source only on the explicit two-line source/timer card.
                int line = entry.Value != null ? entry.Value.IndexOf('\n') : -1;
                string source = line > 0 ? entry.Value.Substring(0, line) : string.Empty;
                bool known = _previousEffects.TryGetValue(entry.Kind, out var previous);
                bool refreshed = known && (entry.NormalizedValue > previous.Normalized + .005f ||
                    (source.Length > 0 && previous.Source != source));
                if (_hasEffectBaseline && (!known || refreshed)) _effectHighlightUntil[entry.Kind] = Time.unscaledTime + 2.4f;
                _previousEffects[entry.Kind] = new EffectPresentation { Normalized = entry.NormalizedValue, Source = source };
            }
            _hasEffectBaseline = true;
        }

        private void SyncOriginalPulse()
        {
            if (!_embedPulse) { RestoreOriginalPulse(); return; }
            if (_ecgHidden || _ecg == null || _pulseDisplay == null || transform.IsChildOf(_ecg.transform)) return;
            _ecgWasActive = _ecg.gameObject.activeSelf;
            _ecgHidden = true;
            _ecg.gameObject.SetActive(false);
        }

        private void RestoreOriginalPulse()
        {
            if (_ecgHidden && _ecg != null) _ecg.gameObject.SetActive(_ecgWasActive);
            _ecgHidden = false;
        }

        private void FollowEcg()
        {
            if (_rect == null || _ecg == null || !(_rect.parent is RectTransform space)) return;
            if (_embedPulse)
            {
                Rect bounds = _ecg.OuterPanelRect;
                Vector3 topLeft = space.InverseTransformPoint(_ecg.rectTransform.TransformPoint(new Vector3(bounds.xMin, bounds.yMax)));
                Vector3 topRight = space.InverseTransformPoint(_ecg.rectTransform.TransformPoint(new Vector3(bounds.xMax, bounds.yMax)));
                if (_medicalPanel == null && _medicalMirror == null)
                {
                    _medicalMirror = _inventory != null ? _inventory.MedicalMirrorPanel : null;
                    if (_medicalMirror == null && transform.parent != null) _medicalMirror = transform.parent.GetComponentInChildren<K_MedicalMirrorPanel>(true);
                }
                float height = SafeDimension(_height, 520f, MinimumHeight);
                RectTransform medicalBounds = _medicalPanel != null ? _medicalPanel : _medicalMirror != null ? _medicalMirror.ViewportRect : null;
                if (_autoSize && medicalBounds != null)
                {
                    Vector3 bottom = space.InverseTransformPoint(medicalBounds.TransformPoint(new Vector3(medicalBounds.rect.xMin, medicalBounds.rect.yMin)));
                    height = Mathf.Max(MinimumHeight, topLeft.y - bottom.y);
                }
                _rect.anchorMin = _rect.anchorMax = new Vector2(0.5f, 0.5f);
                _rect.pivot = new Vector2(0f, 1f);
                _rect.localRotation = Quaternion.identity;
                _rect.localScale = Vector3.one;
                _rect.anchoredPosition = new Vector2(topLeft.x, topLeft.y) - space.rect.center;
                float panelWidth = _autoSize ? topRight.x - topLeft.x : _width;
                _rect.sizeDelta = new Vector2(SafeDimension(panelWidth, 600f, 520f), height);
                return;
            }
            Rect plot = _ecg.PanelRect;
            Vector3 left = space.InverseTransformPoint(_ecg.rectTransform.TransformPoint(new Vector3(plot.xMin, plot.yMin)));
            Vector3 right = space.InverseTransformPoint(_ecg.rectTransform.TransformPoint(new Vector3(plot.xMax, plot.yMin)));
            _rect.anchorMin = _rect.anchorMax = new Vector2(0.5f, 0.5f);
            _rect.pivot = new Vector2(0f, 1f);
            _rect.localRotation = Quaternion.identity;
            _rect.localScale = Vector3.one;
            _rect.anchoredPosition = new Vector2(left.x, left.y - Mathf.Max(0f, _gapBelowEcg)) - space.rect.center;
            float width = _width > 0f ? _width : right.x - left.x;
            _rect.sizeDelta = new Vector2(SafeDimension(width, 760f, 520f), SafeDimension(_height, 520f, MinimumHeight));
        }

        private void Present()
        {
            _screen.gameObject.SetActive(true);
            bool detail = _detailKind.HasValue;
            bool pulse = !detail && _selectedScreen == HealthGadgetScreen.Pulse;
            bool textScreen = detail || (_selectedScreen != HealthGadgetScreen.Icons && !pulse);
            _main.gameObject.SetActive(!textScreen && !pulse);
            _detail.gameObject.SetActive(textScreen);
            _pulseArea.gameObject.SetActive(pulse);
            _pulseNote.gameObject.SetActive(pulse && _pulseDisplay == null);
            _pulseNote.text = "Нет данных о пульсе";
            _close.gameObject.SetActive(detail);
            _heading.text = detail ? K_HealthGadgetContent.GetTitle(_detailKind.Value) : ScreenTitle(_selectedScreen);
            bool filters = !textScreen && !pulse;
            _filterBar.gameObject.SetActive(filters);
            _heading.gameObject.SetActive(!filters);
            SetRect(_heading.rectTransform, 12f, 0f, _screen.rect.width - (detail ? 54f : 24f), _headerHeight);
            _total.gameObject.SetActive(!textScreen && !pulse);
            _total.text = _selectedFilter == HealthGadgetFilter.All ? "Эффектов: " + _effects.Count
                : _orderedEffects.Count + " из " + _effects.Count;
            _empty.gameObject.SetActive(_orderedEffects.Count == 0);
            _empty.text = _health == null && _vitality == null ? "Нет данных\nо состоянии"
                : _selectedFilter == HealthGadgetFilter.Treatment ? "Активного лечения нет"
                : _selectedFilter == HealthGadgetFilter.Injuries ? "Травм не обнаружено" : "Активных эффектов нет";
            int start = _page * PageCapacity;
            for (int i = 0; i < _effectCards.Count; i++)
            {
                bool visible = i < PageCapacity && start + i < _orderedEffects.Count;
                _effectCards[i].Rect.gameObject.SetActive(visible);
                if (visible) PresentCard(_effectCards[i], _orderedEffects[start + i]);
            }
            for (int i = 0; i < _indicatorCards.Count; i++)
            {
                bool visible = i < _indicators.Count;
                _indicatorCards[i].Rect.gameObject.SetActive(visible);
                if (visible) PresentCard(_indicatorCards[i], _indicators[i]);
            }
            bool paging = PageCount > 1;
            _previous.gameObject.SetActive(paging);
            _next.gameObject.SetActive(paging);
            _previous.interactable = _page > 0;
            _next.interactable = _page < PageCount - 1;
            _pageText.text = _orderedEffects.Count == 0 ? string.Empty :
                (start + 1) + "–" + Mathf.Min(start + PageCapacity, _orderedEffects.Count) + " из " + _orderedEffects.Count +
                (paging ? "  •  " + (_page + 1) + "/" + PageCount : string.Empty);
            if (detail) RefreshDetail();
            else if (textScreen) RefreshSection();
            for (int i=0;i<_tabs.Count;i++)
            {
                var colors=_tabs[i].colors;
                colors.normalColor=new Color(.65f,.65f,.65f,i==(int)_selectedScreen ? .3f : .08f);
                colors.selectedColor=colors.normalColor;
                _tabs[i].colors=colors;
            }
            for (int i = 0; i < _filterButtons.Count; i++)
            {
                var colors = _filterButtons[i].colors;
                colors.normalColor = new Color(.65f, .65f, .65f, i == (int)_selectedFilter ? .3f : .06f);
                colors.selectedColor = colors.normalColor;
                _filterButtons[i].colors = colors;
            }
        }

        private static string ScreenTitle(HealthGadgetScreen screen)
            => screen == HealthGadgetScreen.Summary ? "Сводка состояния" : screen == HealthGadgetScreen.Treatment ? "План лечения" : screen == HealthGadgetScreen.Journal ? "Журнал наблюдений" : screen == HealthGadgetScreen.Pulse ? "Пульс" : "Эффекты";

        public void SelectScreen(HealthGadgetScreen screen)
        {
            if (!_built || (int)screen < 0 || (int)screen > (int)HealthGadgetScreen.Pulse) return;
            _selectedScreen = screen;
            _detailKind = null;
            CloseMenu();
            _lastDetailText = null;
            _nextSectionRefresh = 0f;
            Present();
            Canvas.ForceUpdateCanvases();
            _detailScroll.verticalNormalizedPosition=1f;
        }

        private void RefreshSection()
        {
            if (Time.unscaledTime < _nextSectionRefresh && _lastDetailText != null) return;
            _nextSectionRefresh=Time.unscaledTime+.5f;
            string text;
            if (_selectedScreen == HealthGadgetScreen.Summary)
                text=K_HealthMonitorOverview.Build(_effects,_indicators,_health,_vitality,_blood,_weight,false);
            else if (_selectedScreen == HealthGadgetScreen.Treatment)
                text=K_HealthTreatmentPlan.Build(_effects,_indicators,_health,_inventory,false);
            else text=_history != null ? _history.BuildText() : "Нет записей.";
            if (_lastDetailText == text) return;
            _lastDetailText=text;
            _detailText.text=text;
            UnityEngine.UI.LayoutRebuilder.MarkLayoutForRebuild(_detailContent);
        }

        private void PresentCard(Card card, HealthGadgetEntry entry)
        {
            card.Kind = entry.Kind;
            card.Title.text = entry.Title;
            card.Value.text = entry.Value;
            Sprite sprite = ResolveSprite(entry.Kind);
            card.Icon.sprite = sprite;
            card.Icon.enabled = sprite != null;
            card.Icon.color = _foreground;
            card.Title.fontSizeMax = sprite == null ? _fontSize : _fontSize - 2f;
            if (sprite == null && !card.IsIndicator)
            {
                // Keep an unassigned state legible without manufacturing a replacement icon.
                float top = -card.Icon.rectTransform.anchoredPosition.y;
                float iconHeight = card.Icon.rectTransform.rect.height;
                SetRect(card.Title.rectTransform, 2f, top, card.Rect.rect.width - 4f, iconHeight);
                SetRect(card.Value.rectTransform, 2f, top + iconHeight + 8f, card.Rect.rect.width - 4f, EffectValueHeight);
            }
            if (card.Track != null)
            {
                card.Track.gameObject.SetActive(entry.NormalizedValue >= 0f);
                card.Fill.rectTransform.anchorMax = new Vector2(Mathf.Clamp01(entry.NormalizedValue), 1f);
            }
        }

        private Sprite ResolveSprite(HealthGadgetKind kind)
        {
            for (int i = 0; _icons != null && i < _icons.Length; i++)
            {
                var binding = _icons[i];
                if (binding == null || binding.Kind != kind) continue;
                return binding.Source != null && binding.Source.sprite != null ? binding.Source.sprite : binding.Sprite;
            }
            return null;
        }

        private void ClickCard(Card card)
        {
            if (_detailKind.HasValue || Current(card.Kind) == null) return;
            _menuKind = card.Kind;
            _popupBlocker.gameObject.SetActive(true);
            _popup.gameObject.SetActive(true);
            _popupBlocker.SetAsLastSibling();
            _popup.SetAsLastSibling();
            Vector3 anchor = _screen.InverseTransformPoint(card.Rect.TransformPoint(new Vector3(card.Rect.rect.center.x, card.Rect.rect.yMin)));
            float width = _popup.rect.width;
            float height = _popup.rect.height;
            _popup.anchoredPosition = new Vector2(
                Mathf.Clamp(anchor.x - width * 0.5f, 4f, Mathf.Max(4f, _screen.rect.width - width - 4f)),
                Mathf.Clamp(anchor.y, -_screen.rect.height + height + 4f, -36f));
        }

        private void OpenMenuEntry()
        {
            if (!_menuKind.HasValue || Current(_menuKind.Value) == null) { CloseMenu(); return; }
            _detailKind = _menuKind;
            CloseMenu();
            _lastDetailText = null;
            Present();
            Canvas.ForceUpdateCanvases();
            _detailScroll.verticalNormalizedPosition = 1f;
        }

        private void CloseMenu()
        {
            _menuKind = null;
            if (_popup != null) _popup.gameObject.SetActive(false);
            if (_popupBlocker != null) _popupBlocker.gameObject.SetActive(false);
        }

        public void CloseDetails()
        {
            _detailKind = null;
            CloseMenu();
            if (_built) Present();
        }

        private void RefreshDetail()
        {
            var kind = _detailKind.Value;
            var entry = Current(kind);
            string text = "<b>Сейчас</b>\n" + (entry != null ? entry.Summary : "Состояние больше не активно.") +
                "\n\n<b>На что влияет</b>\n" + K_HealthGadgetContent.GetExplanation(kind) +
                "\n\n<b>Что делать</b>\n" + K_HealthGadgetContent.GetAdvice(kind);
            if (_lastDetailText == text) return;
            _lastDetailText = text;
            _detailText.text = text;
            UnityEngine.UI.LayoutRebuilder.MarkLayoutForRebuild(_detailContent);
        }

        public void ChangePage(int delta)
        {
            if (_detailKind.HasValue) return;
            _page = Mathf.Clamp(_page + delta, 0, PageCount - 1);
            CloseMenu();
            Present();
        }

        private void BeginBoot()
        {
            _bootStarted = Time.unscaledTime;
            _nextRefresh = 0f;
        }

        private void AnimateScreen()
        {
            float duration = Mathf.Max(0f, _startupDuration);
            float elapsed = Time.unscaledTime - _bootStarted;
            float progress = duration <= 0f ? 1f : Mathf.Clamp01(elapsed / duration);
            // Real data is present and interactive from the first frame; startup only affects decoration.
            _screenGroup.alpha = 1f;
            _screenFx.SetPhase(progress, _startupNoise, _scanlineOpacity, _foreground);
            float alpha = _animatePowerLight ? 0.78f + 0.22f * (0.5f + 0.5f * Mathf.Sin(Time.unscaledTime * 2.4f)) : 1f;
            _powerLight.color = new Color(0.8f, 0.8f, 0.8f, alpha);
            foreach (var card in _effectCards)
            {
                float remaining = _effectHighlightUntil.TryGetValue(card.Kind, out float until) ? until - Time.unscaledTime : 0f;
                card.Highlight.color = new Color(_foreground.r, _foreground.g, _foreground.b, Mathf.Clamp01(remaining / 2.4f) * .13f);
            }
        }

        private void EnsureVisuals()
        {
            if (_built) return;
            _rect = (RectTransform)transform;
            if (_font == null) _font = TMP_Settings.defaultFontAsset;
            if (_font != null && _font.material != null)
            {
                // The inventory font preset has a grey face and strong negative dilate.
                // Give the display one shared, owned copy so its brighter text stays crisp.
                _screenTextMaterial = new Material(_font.material) { name = "Health monitor text", hideFlags = HideFlags.DontSave };
                if (_screenTextMaterial.HasProperty("_FaceColor")) _screenTextMaterial.SetColor("_FaceColor", Color.white);
                if (_screenTextMaterial.HasProperty("_FaceDilate")) _screenTextMaterial.SetFloat("_FaceDilate", 0f);
                if (_screenTextMaterial.HasProperty("_OutlineWidth")) _screenTextMaterial.SetFloat("_OutlineWidth", 0f);
                if (_screenTextMaterial.HasProperty("_OutlineSoftness")) _screenTextMaterial.SetFloat("_OutlineSoftness", 0f);
                if (_screenTextMaterial.HasProperty("_UnderlayColor")) _screenTextMaterial.SetColor("_UnderlayColor", Color.clear);
            }
            _visualRoot = MakeRect("Display", transform);
            Stretch(_visualRoot);
            var body = MakeHardware("GadgetCase", _visualRoot, K_HealthGadgetHardwareGraphic.Shape.Case, _caseFill);
            Stretch(body.rectTransform);
            var socket = MakeFrame(_visualRoot, "RecessedScreenRim", new Color(0.008f, 0.008f, 0.008f, 1f), new Color(0.34f, 0.34f, 0.34f, 1f));
            Stretch(socket.rectTransform, 15f, 17f, 15f, 43f);
            _screen = MakeRect("Screen", _visualRoot);
            Stretch(_screen, 18f, 20f, 18f, 46f);
            var screenImage = _screen.gameObject.AddComponent<UnityEngine.UI.Image>();
            screenImage.color = _screenFill;
            screenImage.raycastTarget = true;
            _screenGroup = _screen.gameObject.AddComponent<CanvasGroup>();

            _header = MakeRect("Header", _screen);
            var header = _header.gameObject.AddComponent<UnityEngine.UI.Image>();
            float headerHeight = 32f, thickness = 1f;
            Color headerFill = LineColor(), border = headerFill;
            if (_inventory != null) _inventory.GetContainerWindowHeaderStyle(out headerHeight, out headerFill, out border, out thickness);
            _headerHeight = float.IsNaN(headerHeight) || float.IsInfinity(headerHeight) ? 32f : Mathf.Max(24f, headerHeight);
            header.color = headerFill;
            header.raycastTarget = false;
            _heading = MakeText("Title", _header, "Состояние", _fontSize, TextAlignmentOptions.MidlineLeft);
            _total = MakeText("EffectCount", _header, string.Empty, _fontSize - 2f, TextAlignmentOptions.MidlineRight);
            _total.enableAutoSizing = true;
            _total.fontSizeMin = 12f;
            _total.fontSizeMax = _fontSize - 2f;
            _filterBar = MakeRect("EffectFilters", _header);
            string[] filterNames = { "Все", "Недуги", "Помощь" };
            for (int i = 0; i < filterNames.Length; i++)
            {
                var filter = (HealthGadgetFilter)i;
                _filterButtons.Add(MakeButton("Filter" + i, _filterBar, filterNames[i], () => SelectFilter(filter)));
            }
            _close = MakeButton("CloseDetails", _header, "×", CloseDetails);
            var closeColors = _close.colors;
            closeColors.normalColor = new Color(0.48f, 0.17f, 0.16f, 0.32f);
            closeColors.highlightedColor = new Color(0.78f, 0.22f, 0.19f, 0.95f);
            closeColors.pressedColor = new Color(0.9f, 0.3f, 0.24f, 1f);
            closeColors.selectedColor = closeColors.normalColor;
            _close.colors = closeColors;
            _close.GetComponentInChildren<TMP_Text>().fontSize = 25f;

            _navigation=MakeRect("Navigation",_screen);
            string[] tabNames={"Эффекты","Сводка","Лечение","Журнал","Пульс"};
            for(int i=0;i<tabNames.Length;i++)
            {
                var selected=(HealthGadgetScreen)i;
                _tabs.Add(MakeButton("Tab"+i,_navigation,tabNames[i],()=>SelectScreen(selected)));
            }

            _main = MakeRect("Overview", _screen);
            _effectsArea = MakeRect("Effects", _main);
            var wheel = _effectsArea.gameObject.AddComponent<K_HealthGadgetPager>();
            wheel.Owner = this;
            var hit = _effectsArea.gameObject.AddComponent<UnityEngine.UI.Image>();
            hit.color = Color.clear;
            hit.raycastTarget = true;
            _empty = MakeText("Empty", _effectsArea, string.Empty, _fontSize, TextAlignmentOptions.Center);
            _indicatorsArea = MakeRect("Indicators", _main);
            Color separatorColor = LineColor();
            separatorColor.a = Mathf.Max(0.65f, separatorColor.a);
            _separator = MakeImage("Separator", _main, separatorColor);
            for (int i = 0; i < 12; i++) _effectCards.Add(MakeCard(_effectsArea, "Effect_" + i, false));
            for (int i = 0; i < 6; i++) _indicatorCards.Add(MakeCard(_indicatorsArea, "Indicator_" + i, true));
            _footer = MakeRect("Pages", _main);
            _previous = MakeButton("PreviousPage", _footer, "<", () => ChangePage(-1));
            _next = MakeButton("NextPage", _footer, ">", () => ChangePage(1));
            _pageText = MakeText("PageCount", _footer, string.Empty, _fontSize - 2f, TextAlignmentOptions.Center);
            MakeDetails();
            _pulseArea = MakeRect("Pulse", _screen);
            var pulseRect = MakeRect("ECG", _pulseArea);
            Stretch(pulseRect, 0f, 0f, 0f, 28f);
            pulseRect.gameObject.SetActive(false);
            if (_ecg != null)
            {
                _pulseDisplay = pulseRect.gameObject.AddComponent<K_EcgMonitor>();
                _pulseDisplay.ConfigureEmbeddedDisplay(_ecg, _vitality, _font);
                pulseRect.gameObject.SetActive(true);
            }
            _pulseNote = MakeText("PulseNote", _pulseArea, string.Empty, _fontSize - 2f, TextAlignmentOptions.BottomLeft);

            var fxRect = MakeRect("ScreenTexture", _screen);
            Stretch(fxRect);
            _screenFx = fxRect.gameObject.AddComponent<K_HealthGadgetScreenFX>();
            _screenFx.raycastTarget = false;

            _popupBlocker = MakeRect("DismissOpenMenu", _screen);
            Stretch(_popupBlocker);
            var dismissImage = _popupBlocker.gameObject.AddComponent<UnityEngine.UI.Image>();
            dismissImage.color = Color.clear;
            var dismiss = _popupBlocker.gameObject.AddComponent<UnityEngine.UI.Button>();
            dismiss.targetGraphic = dismissImage;
            dismiss.transition = UnityEngine.UI.Selectable.Transition.None;
            dismiss.onClick.AddListener(CloseMenu);
            var open = MakeButton("OpenMenu", _screen, "Открыть", OpenMenuEntry);
            _popup = (RectTransform)open.transform;
            SetRect(_popup, 0f, 0f, 136f, 40f);
            _popup.GetComponent<UnityEngine.UI.Image>().color = new Color(0.18f, 0.18f, 0.18f, 1f);
            open.transition = UnityEngine.UI.Selectable.Transition.None;
            open.targetGraphic.CrossFadeColor(Color.white, 0f, true, true);
            var outline = _popup.gameObject.AddComponent<UnityEngine.UI.Outline>();
            outline.effectColor = LineColor();
            outline.effectDistance = new Vector2(1f, -1f);

            _powerMark = MakeHardware("PowerMark", _visualRoot, K_HealthGadgetHardwareGraphic.Shape.Power, new Color(0.52f, 0.52f, 0.52f, 1f));
            _modelLabel = MakeText("Model", _visualRoot, "INCIDENT  /  M01", 13f, TextAlignmentOptions.MidlineLeft);
            _modelLabel.color = new Color(0.51f, 0.51f, 0.51f, 1f);
            _powerLight = MakeHardware("PowerLight", _visualRoot, K_HealthGadgetHardwareGraphic.Shape.Led, _foreground);
            if (_health != null)
            {
                _history=_health.GetComponent<K_HealthMonitorHistory>();
                if (_history==null) _history=_health.gameObject.AddComponent<K_HealthMonitorHistory>();
                _history.Initialize(_health,_vitality,_debuffs,_blood,_weight);
                _history.ConnectMedicalService(_inventory != null ? _inventory.MedicalApplyService : null, _font);
            }
            _built = true;
            FollowEcg();
            Layout();
            CloseMenu();
        }

        private void MakeDetails()
        {
            _detail = MakeRect("Details", _screen);
            _detailScroll = _detail.gameObject.AddComponent<UnityEngine.UI.ScrollRect>();
            _detailScroll.horizontal = false;
            _detailScroll.vertical = true;
            _detailScroll.movementType = UnityEngine.UI.ScrollRect.MovementType.Clamped;
            _detailScroll.scrollSensitivity = 25f;
            var viewport = MakeRect("Viewport", _detail);
            Stretch(viewport, 0f, 0f, 14f, 0f);
            var image = viewport.gameObject.AddComponent<UnityEngine.UI.Image>();
            image.color = Color.white;
            var mask = viewport.gameObject.AddComponent<UnityEngine.UI.Mask>();
            mask.showMaskGraphic = false;
            _detailContent = MakeRect("Content", viewport);
            _detailContent.anchorMin = new Vector2(0f, 1f);
            _detailContent.anchorMax = Vector2.one;
            _detailContent.pivot = new Vector2(0.5f, 1f);
            _detailContent.anchoredPosition = Vector2.zero;
            _detailContent.sizeDelta = Vector2.zero;
            var group = _detailContent.gameObject.AddComponent<UnityEngine.UI.VerticalLayoutGroup>();
            group.padding = new RectOffset(2, 8, 2, 16);
            group.childControlWidth = group.childControlHeight = true;
            group.childForceExpandWidth = true;
            group.childForceExpandHeight = false;
            var fitter = _detailContent.gameObject.AddComponent<UnityEngine.UI.ContentSizeFitter>();
            fitter.verticalFit = UnityEngine.UI.ContentSizeFitter.FitMode.PreferredSize;
            fitter.horizontalFit = UnityEngine.UI.ContentSizeFitter.FitMode.Unconstrained;
            _detailText = MakeText("Description", _detailContent, string.Empty, _fontSize, TextAlignmentOptions.TopLeft);
            _detailText.textWrappingMode = TextWrappingModes.Normal;
            _detailText.overflowMode = TextOverflowModes.Overflow;
            _detailText.richText = true;
            _detailText.lineSpacing = 5f;
            _detailScroll.viewport = viewport;
            _detailScroll.content = _detailContent;
            var barRect = MakeRect("Scrollbar", _detail);
            Stretch(barRect);
            barRect.anchorMin = new Vector2(1f, 0f);
            barRect.offsetMin = new Vector2(-6f, 0f);
            barRect.offsetMax = Vector2.zero;
            var track = barRect.gameObject.AddComponent<UnityEngine.UI.Image>();
            track.color = new Color(_foreground.r, _foreground.g, _foreground.b, 0.12f);
            var bar = barRect.gameObject.AddComponent<UnityEngine.UI.Scrollbar>();
            var handle = MakeImage("Handle", barRect, LineColor());
            Stretch(handle.rectTransform);
            bar.handleRect = handle.rectTransform;
            bar.targetGraphic = handle;
            bar.direction = UnityEngine.UI.Scrollbar.Direction.BottomToTop;
            _detailScroll.verticalScrollbar = bar;
            _detailScroll.verticalScrollbarVisibility = UnityEngine.UI.ScrollRect.ScrollbarVisibility.AutoHide;
        }

        private Card MakeCard(RectTransform parent, string name, bool indicator)
        {
            var card = new Card { Rect = MakeRect(name, parent), IsIndicator = indicator };
            var image = card.Rect.gameObject.AddComponent<UnityEngine.UI.Image>();
            image.color = Color.white;
            if (!indicator)
            {
                card.Highlight = MakeImage("RecentChange", card.Rect, Color.clear);
                Stretch(card.Highlight.rectTransform);
            }
            card.Button = card.Rect.gameObject.AddComponent<UnityEngine.UI.Button>();
            card.Button.targetGraphic = image;
            SetButtonColors(card.Button, false);
            card.Button.onClick.AddListener(() => ClickCard(card));
            card.Icon = MakeImage("Icon", card.Rect, _foreground);
            card.Icon.preserveAspect = true;
            card.Title = MakeText("Name", card.Rect, string.Empty, _fontSize - 2f,
                indicator ? TextAlignmentOptions.MidlineLeft : TextAlignmentOptions.Center);
            card.Title.textWrappingMode = indicator ? TextWrappingModes.NoWrap : TextWrappingModes.Normal;
            card.Title.enableAutoSizing = true;
            card.Title.fontSizeMin = 14f;
            card.Title.fontSizeMax = _fontSize - 2f;
            card.Value = MakeText("Value", card.Rect, string.Empty, _fontSize,
                indicator ? TextAlignmentOptions.MidlineRight : TextAlignmentOptions.Center);
            card.Value.textWrappingMode = TextWrappingModes.Normal;
            card.Value.enableAutoSizing = true;
            card.Value.fontSizeMin = 12f;
            card.Value.fontSizeMax = _fontSize;
            card.Track = MakeImage("Track", card.Rect, new Color(_foreground.r, _foreground.g, _foreground.b, 0.14f));
            card.Fill = MakeImage("Fill", card.Track.rectTransform, _foreground);
            Stretch(card.Fill.rectTransform);
            return card;
        }

        private void Layout()
        {
            if (!_built) return;
            _lastSize = _rect.rect.size;
            float width = Mathf.Max(1f, _rect.rect.width - 36f);
            float screenHeight = Mathf.Max(1f, _rect.rect.height - 66f);
            float headerHeight = _headerHeight;
            _heading.fontSize = _empty.fontSize = _detailText.fontSize = _fontSize;
            _total.fontSize = _pageText.fontSize = _pulseNote.fontSize = _fontSize - 2f;
            SetRect(_header, 0f, 0f, width, headerHeight);
            SetRect(_heading.rectTransform, 12f, 0f, width - (_detailKind.HasValue || _selectedScreen != HealthGadgetScreen.Icons ? 54f : 164f), headerHeight);
            SetRect(_total.rectTransform, width - 142f, 0f, 130f, headerHeight);
            SetRect(_filterBar, 12f, 2f, Mathf.Max(1f, width - 164f), headerHeight - 4f);
            float filterWidth = _filterBar.rect.width / Mathf.Max(1, _filterButtons.Count);
            for (int i = 0; i < _filterButtons.Count; i++)
            {
                SetRect((RectTransform)_filterButtons[i].transform, i * filterWidth, 0f, filterWidth - 3f, headerHeight - 4f);
                _filterButtons[i].GetComponentInChildren<TMP_Text>().fontSizeMax = _fontSize - 2f;
            }
            SetRect((RectTransform)_close.transform, width - 34f, 2f, 30f, 28f);
            SetRect(_navigation,12f,headerHeight+4f,width-24f,30f);
            float tabWidth=(width-24f)/_tabs.Count;
            for(int i=0;i<_tabs.Count;i++)
            {
                SetRect((RectTransform)_tabs[i].transform,i*tabWidth,0f,tabWidth-4f,30f);
                _tabs[i].GetComponentInChildren<TMP_Text>().fontSizeMax = _fontSize;
            }
            SetRect(_main, 12f, headerHeight + 44f, width - 24f, screenHeight - headerHeight - 54f);
            SetRect(_detail, 12f, headerHeight + 46f, width - 24f, screenHeight - headerHeight - 58f);
            SetRect(_pulseArea, 12f, headerHeight + 46f, width - 24f, screenHeight - headerHeight - 58f);
            SetRect(_pulseNote.rectTransform, 4f, screenHeight - headerHeight - 86f, width - 32f, 26f);
            float areaWidth = width - 24f;
            float areaHeight = screenHeight - headerHeight - 54f;
            float rightWidth = IndicatorWidth(areaWidth);
            float leftWidth = areaWidth - rightWidth - 20f;
            SetRect(_effectsArea, 0f, 0f, leftWidth, areaHeight - 32f);
            SetRect(_indicatorsArea, leftWidth + 20f, 0f, rightWidth, areaHeight);
            K_InventoryFrameImage.ReadPixelsPerUnit(_separator.rectTransform, _separator.canvas, _separatorCorners, out float pixelsX, out _);
            float separatorPixels = Mathf.Max(0.01f, pixelsX);
            float separatorWidth = Mathf.Max(1f, 1.5f / separatorPixels);
            SetRect(_separator.rectTransform, leftWidth + 10f - separatorWidth * .5f, 0f, separatorWidth, areaHeight);
            SetRect(_footer, 0f, areaHeight - 28f, leftWidth, 28f);
            SetRect((RectTransform)_previous.transform, 0f, 0f, 28f, 28f);
            SetRect((RectTransform)_next.transform, leftWidth - 28f, 0f, 28f, 28f);
            SetRect(_pageText.rectTransform, 32f, 0f, Mathf.Max(1f, leftWidth - 64f), 28f);
            Stretch(_empty.rectTransform, 8f, 8f, 8f, 8f);
            int columns = LayoutColumns;
            float cellWidth = leftWidth / columns;
            float cellHeight = (areaHeight - 32f) * 0.5f;
            float titleHeight = Mathf.Max(38f, (_fontSize - 2f) * 2.4f);
            float valueHeight = Mathf.Max(28f, _fontSize * 1.35f);
            for (int i = 0; i < _effectCards.Count; i++)
            {
                var card = _effectCards[i];
                card.Value.fontSizeMax = _fontSize;
                SetRect(card.Rect, (i % columns) * cellWidth, (i / columns) * cellHeight,
                    cellWidth - 4f, cellHeight - 6f);
                float labelHeight = titleHeight + EffectValueHeight + 14f;
                float iconSize = Mathf.Max(1f, Mathf.Min(Mathf.Clamp(_iconSize, 48f, 112f), cellWidth - 18f, cellHeight - labelHeight - 18f));
                float top = Mathf.Max(6f, (cellHeight - iconSize - labelHeight) * 0.5f);
                SetRect(card.Icon.rectTransform, (cellWidth - 4f - iconSize) * 0.5f, top, iconSize, iconSize);
                SetRect(card.Title.rectTransform, 2f, top + iconSize + 5f, cellWidth - 8f, titleHeight);
                SetRect(card.Value.rectTransform, 2f, top + iconSize + titleHeight + 8f, cellWidth - 8f, EffectValueHeight);
                SetRect(card.Track.rectTransform, 6f, card.Rect.rect.height - 5f, card.Rect.rect.width - 12f, 3f);
            }
            float rowHeight = areaHeight / Mathf.Max(1, _indicators.Count);
            for (int i = 0; i < _indicatorCards.Count; i++)
            {
                var card = _indicatorCards[i];
                card.Value.fontSizeMax = _fontSize;
                SetRect(card.Rect, 0f, i * rowHeight, rightWidth, rowHeight - 2f);
                SetRect(card.Icon.rectTransform, 0f, Mathf.Max(5f, (rowHeight - 38f) * .5f), 36f, 38f);
                float indicatorTitleHeight = Mathf.Max(23f, _fontSize * 1.25f);
                SetRect(card.Title.rectTransform, 44f, 0f, rightWidth - 46f, indicatorTitleHeight);
                SetRect(card.Value.rectTransform, 44f, indicatorTitleHeight - 1f, rightWidth - 46f, valueHeight);
                SetRect(card.Track.rectTransform, 44f, rowHeight - 8f, rightWidth - 48f, 3f);
            }
            SetRect(_powerMark.rectTransform, _rect.rect.width - 48f, _rect.rect.height - 37f, 28f, 28f);
            SetRect(_powerLight.rectTransform, _rect.rect.width - 82f, _rect.rect.height - 33f, 20f, 20f);
            SetRect(_modelLabel.rectTransform, 23f, _rect.rect.height - 34f, 200f, 22f);
        }

        private K_HealthGadgetHardwareGraphic MakeHardware(string name, Transform parent, K_HealthGadgetHardwareGraphic.Shape shape, Color tint)
        {
            var rect = MakeRect(name, parent);
            var graphic = rect.gameObject.AddComponent<K_HealthGadgetHardwareGraphic>();
            graphic.Mode = shape;
            graphic.color = tint;
            graphic.raycastTarget = false;
            return graphic;
        }

        private Color LineColor() => K_ResponsiveCanvasLayout.ResolveLineColor(this);

        private K_InventoryFrameImage MakeFrame(Transform parent, string name, Color fill, Color line)
        {
            var rect = MakeRect(name, parent);
            var frame = rect.gameObject.AddComponent<K_InventoryFrameImage>();
            frame.UseInventoryLineColor = false;
            frame.BorderColor = line;
            frame.FillColor = fill;
            frame.BorderThickness = 1f;
            frame.color = Color.white;
            frame.raycastTarget = false;
            return frame;
        }

        private RectTransform MakeRect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.layer = gameObject.layer;
            var rect = (RectTransform)go.transform;
            rect.SetParent(parent, false);
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0f, 1f);
            return rect;
        }

        private UnityEngine.UI.Image MakeImage(string name, Transform parent, Color tint)
        {
            var rect = MakeRect(name, parent);
            var image = rect.gameObject.AddComponent<UnityEngine.UI.Image>();
            image.color = tint;
            image.raycastTarget = false;
            return image;
        }

        private TextMeshProUGUI MakeText(string name, Transform parent, string text, float size, TextAlignmentOptions alignment)
        {
            var rect = MakeRect(name, parent);
            var label = rect.gameObject.AddComponent<TextMeshProUGUI>();
            label.font = _font;
            if (_screenTextMaterial != null) label.fontSharedMaterial = _screenTextMaterial;
            label.fontSize = Mathf.Max(12f, size);
            label.color = _foreground;
            label.fontStyle = FontStyles.Normal;
            label.alignment = alignment;
            label.textWrappingMode = TextWrappingModes.NoWrap;
            label.overflowMode = TextOverflowModes.Ellipsis;
            label.raycastTarget = false;
            label.text = text;
            return label;
        }

        private UnityEngine.UI.Button MakeButton(string name, Transform parent, string text, UnityEngine.Events.UnityAction action)
        {
            var rect = MakeRect(name, parent);
            var image = rect.gameObject.AddComponent<UnityEngine.UI.Image>();
            image.color = Color.white;
            var button = rect.gameObject.AddComponent<UnityEngine.UI.Button>();
            button.targetGraphic = image;
            SetButtonColors(button, true);
            button.onClick.AddListener(action);
            var label = MakeText("Label", rect, text, _fontSize, TextAlignmentOptions.Center);
            label.enableAutoSizing = true;
            label.fontSizeMin = 14f;
            label.fontSizeMax = _fontSize;
            Stretch(label.rectTransform, 3f, 0f, 3f, 0f);
            return button;
        }

        private void SetButtonColors(UnityEngine.UI.Button button, bool filled)
        {
            var colors = button.colors;
            colors.normalColor = new Color(0.5f, 0.5f, 0.5f, filled ? 0.22f : 0f);
            colors.highlightedColor = new Color(0.65f, 0.65f, 0.65f, 0.20f);
            colors.pressedColor = new Color(0.7f, 0.7f, 0.7f, 0.3f);
            colors.selectedColor = colors.normalColor;
            colors.disabledColor = new Color(0.4f, 0.4f, 0.4f, 0.08f);
            colors.fadeDuration = 0.08f;
            button.colors = colors;
            var navigation = button.navigation;
            navigation.mode = UnityEngine.UI.Navigation.Mode.None;
            button.navigation = navigation;
        }

        private static void SetRect(RectTransform rect, float x, float top, float width, float height)
        {
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0f, 1f);
            rect.anchoredPosition = new Vector2(x, -top);
            rect.sizeDelta = new Vector2(Mathf.Max(1f, width), Mathf.Max(1f, height));
        }

        private static void Stretch(RectTransform rect, float left = 0f, float top = 0f, float right = 0f, float bottom = 0f)
        {
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.pivot = new Vector2(0f, 1f);
            rect.offsetMin = new Vector2(left, bottom);
            rect.offsetMax = new Vector2(-right, -top);
        }
    }
}
