using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public enum HealthGadgetKind
    {
        Hunger, Thirst, Radiation, Cold, Overload, Blood,
        Bleeding, Laceration, Fracture, Gunshot, Concussion, Tbi,
        BreathingDifficulty, Immobilized, InternalBleeding,
        StimOn, StimCooldown, Fatigue, Drunk, Hangover, Painkiller,
        HealBoost, Coagulant, Tourniquet, Jett, Shock,
        Txa, ChestSeal, PelvicBinder, Recovery,
        ColdIllness, WoundInfection, AntibioticTreatment
    }

    /// <summary>A presentation snapshot. Reading it never applies treatment or advances a timer.</summary>
    public sealed class HealthGadgetEntry
    {
        public HealthGadgetKind Kind;
        public string Title;
        public string Value;
        public string Summary;
        public string Explanation;
        public string Advice;
        public bool IsIndicator;
        // -1 means that this state has no meaningful normalized progress bar.
        public float NormalizedValue = -1f;
    }

    /// <summary>Read-only adapter over existing health systems; no duplicate gameplay state.</summary>
    public static class K_HealthGadgetContent
    {
        private static readonly CultureInfo Russian = CultureInfo.GetCultureInfo("ru-RU");
        private static readonly string[] PartNames =
        {
            "Голова", "Грудь", "Живот", "Таз", "Левое плечо", "Правое плечо",
            "Левый бицепс", "Правый бицепс", "Левое предплечье", "Правое предплечье",
            "Левая кисть", "Правая кисть", "Левое бедро", "Правое бедро",
            "Левое колено", "Правое колено", "Левая голень", "Правая голень",
            "Левая стопа", "Правая стопа"
        };

        private sealed class Description
        {
            public HealthGadgetKind Kind;
            public string Title;
            public string Explanation;
            public string Advice;
        }

        // These literal strings are exported verbatim to the task's STATUS_TEXTS.md report.
        private static readonly Description[] Descriptions =
        {
            D(HealthGadgetKind.Hunger, "Сытость", "Запас питания: 100% — сытость, 0% — голодание. При нехватке еды здоровье не восстанавливается. Голод наносит урон животу; если его здоровье упало до нуля — груди, затем голове. От голода тот же груз ощущается тяжелее и может мешать движению.", "Поешьте, если сытость снизилась. Еда: ПКМ → «Съесть», затем выберите порцию. При 100% есть не нужно. Для заживления также нужны вода и обработанные травмы. Если голод вызвал перегрузку, поешьте или оставьте часть вещей."),
            D(HealthGadgetKind.Thirst, "Вода", "Запас воды: 100% — воды достаточно, 0% — обезвоживание. При нехватке воды здоровье не восстанавливается. Обезвоживание наносит урон животу; если его здоровье упало до нуля — груди, затем голове. Еда утоляет голод, напитки — жажду.", "Попейте, если запас воды снизился. Напиток: ПКМ → «Выпить», затем выберите количество. При 100% пить не нужно. Не забывайте есть и лечить травмы: вода не устраняет переломы, раны и кровотечения."),
            D(HealthGadgetKind.Radiation, "Радиация", "Накопленная радиация снижает максимальное здоровье и ускоряет расход еды и воды. При высоком уровне замедляет движение и может вызвать наружное кровотечение. При 100% наступает смерть.", "Избегайте дальнейшего облучения. Радиация постепенно снижается сама; пока ждёте, следите за едой и водой. Наружное кровотечение остановите бинтом или гемостатической марлей. После снижения радиации потерянные здоровье и кровь придётся восстановить отдельно."),
            D(HealthGadgetKind.Cold, "Холод", "Переохлаждение нарастает на холоде. При 100% холод повреждает части тела и мешает двигаться. В тепле переохлаждение постепенно проходит.", "Найдите более тёплое место и проверьте, снижается ли показатель. Безопасная зона не поможет согреться, если в ней всё ещё слишком холодно. Когда согреетесь, займитесь травмами: тепло не возвращает потерянное здоровье."),
            D(HealthGadgetKind.Overload, "Нагрузка", "Тяжёлый груз сначала мешает спринту, затем замедляет ходьбу. При предельной нагрузке двигаться нельзя. От голода тот же груз создаёт большую нагрузку. Точные ограничения указаны в разделе «Сейчас».", "Оставьте часть вещей на земле или в хранилище. Перекладывание между своими сумками вес не уменьшит. Если голодны — поешьте. Спринт вернётся, когда нагрузка опустится ниже указанного порога."),
            D(HealthGadgetKind.Blood, "Кровь", "Процент показывает запас до смертельной кровопотери: полный объём — 100%, смертельный порог — 0%. Миллилитры показывают оставшийся объём крови. Потеря крови вызывает слабость, затем шок.", "Остановите кровотечение подходящим средством. При недостатке крови используйте пакет донорской крови и выберите объём. Переливание не закрывает раны и не останавливает продолжающуюся кровопотерю."),
            D(HealthGadgetKind.Bleeding, "Кровотечение", "Наружное кровотечение уменьшает объём крови и не даёт повреждённому участку заживать. Уровень от 1 до 3 показывает тяжесть. Чем выше средний пульс, тем быстрее теряется кровь.", "Гемостатическая марля останавливает наружное кровотечение любого уровня. Давящий перевязочный пакет подходит для уровней 1 и 2. Бинт снижает кровотечение постепенно: три применения с уровня 3 до 2, ещё два — до 1, ещё одно — до 0. Турникет CAT или эластичный жгут на соответствующем плече или бедре перекроет кровотечение конечности до снятия. Открытую рану закройте отдельно, потерянную кровь восполните пакетом донорской крови."),
            D(HealthGadgetKind.Laceration, "Рваные раны", "Открытая рана не даёт участку заживать. Заклеенная или закрытая уже не мешает восстановлению, но остаётся в списке. Закрытие раны не останавливает кровотечение.", "Открытую рану обработайте «Медицинским клеем», «Шовными пластырями» или «Медицинским степлером». Прыжок разрывает клей и возвращает кровотечение, даже под обезболиванием. Заклеенную рану можно закрыть пластырями или степлером. Закрытую повторно обрабатывать не нужно. Наружное кровотечение остановите отдельно бинтом или гемостатической марлей."),
            D(HealthGadgetKind.Fracture, "Переломы", "Неустойчивый перелом мешает работе повреждённой части тела. Фиксация уменьшает последствия, после чего требуется время на восстановление. Кость не становится здоровой сразу после наложения шины.", "На конечность наложите деревянную или формуемую шину. Для таза нужен тазовый бандаж, для тяжёлой травмы головы — набор помощи при ЧМТ. Перелом груди восстанавливается в покое. Обезболивание облегчает последствия, но не заменяет лечение."),
            D(HealthGadgetKind.Gunshot, "Огнестрельные ранения", "Повреждённый участок требует обработки. Кровотечение, открытая рана и нарушение дыхания могут сопровождать попадание и лечатся по своим причинам.", "Сначала остановите наружное кровотечение. Обработайте ранение хирургическим набором. Если обнаружено внутреннее кровотечение, сначала подготовьте этот участок гемостатической губкой. Подходящее проникающее ранение груди требует клапанной наклейки для стабилизации дыхания."),
            D(HealthGadgetKind.Concussion, "Сотрясение", "Сотрясение после удара проходит со временем. Повреждение костей головы может поддерживать симптомы дольше. Обезболивающее облегчает боль, но не устраняет травму мозга.", "Избегайте новой травмы, дождитесь восстановления. Парацетамол помогает с небольшой болью, морфин даёт более сильное обезболивание. При переломе головы или ЧМТ требуется соответствующее лечение; таблетки его не заменяют."),
            D(HealthGadgetKind.Tbi, "ЧМТ", "Тяжёлая травма головы. После специализированной помощи требуется период восстановления в покое. Сопутствующие раны и кровотечения продолжают действовать отдельно.", "Примените набор помощи при ЧМТ и дождитесь восстановления. Остановите имеющиеся кровотечения и обработайте раны. Движение задерживает восстановление; обезболивание само по себе ЧМТ не лечит."),
            D(HealthGadgetKind.BreathingDifficulty, "Тяжело дышать", "Нарушение дыхания вызвано травмой груди. Перелом и проникающее ранение имеют разные способы лечения.", "При подходящем проникающем ранении груди наложите клапанную окклюзионную наклейку, затем обработайте повреждение. Перелом груди требует покоя и восстановления. Обычные шины и наклейка не лечат перелом рёбер."),
            D(HealthGadgetKind.Immobilized, "Ограничение движения", "Повреждение таза ограничивает движение и спринт. Фиксация стабилизирует таз, но остаточные ограничения сохраняются до восстановления.", "Используйте тазовый бандаж. Дайте травме восстановиться в покое. Если двигаться всё ещё трудно, проверьте ноги, живот и вес вещей. Обезболивание не заменяет фиксацию."),
            D(HealthGadgetKind.InternalBleeding, "Внутреннее кровотечение", "Обнаружено внутреннее кровотечение. Кровь может продолжать теряться, даже когда наружная рана закрыта.", "Транексам временно уменьшает кровопотерю. Для устранения обнаруженного источника подготовьте участок гемостатической губкой, затем примените хирургический набор. Потерянную кровь восполните отдельно."),
            D(HealthGadgetKind.StimOn, "Бодрость", "Действует кофеин. Скорость действий временно повышена, пульс может участиться. После действия наступают откат и усталость.", "Следите за таймером. Кофеин не лечит травмы, не восполняет кровь и не увеличивает грузоподъёмность. Следующее применение доступно после окончания всех этапов."),
            D(HealthGadgetKind.StimCooldown, "После кофеина", "Основное действие кофеина закончилось. Позднее наступит усталость; принимать кофеин повторно пока рано.", "Дождитесь восстановления после кофеина. Ускорение действий уже закончилось."),
            D(HealthGadgetKind.Fatigue, "Усталость", "Усталость после стимулятора. Лечение, работа с предметами и перезарядка замедлены. Новый стимулятор пока недоступен.", "Дождитесь конца таймера. На лечение и перезарядку уйдёт больше времени — учитывайте это заранее. Средства от этой усталости нет. Когда она пройдёт, стимулятор снова станет доступен."),
            D(HealthGadgetKind.Drunk, "Опьянение", "Алкоголь мешает двигаться и обращаться с оружием. Когда опьянение пройдёт, начнётся похмелье. Новая порция обновляет таймер опьянения и увеличивает будущее похмелье. Слишком много выпитого может привести к смерти.", "Дождитесь конца таймера, а затем — похмелья. Не пытайтесь снять опьянение новой дозой. Пока оно действует, двигаться и обращаться с оружием будет труднее. Травмы, кровотечения и кровопотерю лечите отдельно."),
            D(HealthGadgetKind.Hangover, "Похмелье", "Последствие алкоголя: хуже работают руки и ноги, шаги слышны дальше. Также замедляются лечение, работа с предметами и перезарядка, если их скорость сейчас не изменена стимулятором или усталостью.", "Дождитесь конца таймера — средства от похмелья нет. Перед лечением и перезарядкой проверьте указанную скорость действий. Шаги стали громче: двигайтесь осторожно, если хотите остаться незамеченным. Новая порция алкоголя снова вызовет опьянение и здоровье не восстановит."),
            D(HealthGadgetKind.Painkiller, "Обезболивание", "Временное облегчение боли. Морфин действует сильнее парацетамола. Обезболивание не удаляет травмы и не устраняет причины кровопотери или нарушения дыхания.", "Используйте время действия для лечения причин боли. В карточке указаны препарат, начало действия и оставшееся время. После окончания оставшаяся травма продолжит влиять на состояние."),
            D(HealthGadgetKind.HealBoost, "Раневой уход", "Раневой гидрогель ускоряет восстановление обработанных мягких тканей конечности. На разных участках действуют отдельные таймеры.", "Применяйте гидрогель к повреждённой конечности после обработки ран и кровотечений. Он не лечит переломы, огнестрельные повреждения, мозг и внутренние органы. Для заживления нужны достаточные еда и вода."),
            D(HealthGadgetKind.Coagulant, "Местный гемостаз", "Обработанные участки перечислены в разделе «Сейчас». Гемостатическая губка подготавливает обнаруженный источник внутреннего кровотечения к хирургической обработке.", "Если участок подготовлен к операции, примените хирургический набор к этому же участку. Губка сама по себе не восстанавливает кровь и не устраняет все внутренние кровотечения."),
            D(HealthGadgetKind.Tourniquet, "Наложенные жгуты", "Турникет CAT или эластичный жгут временно перекрывает наружное кровотечение конечности. Устройство остаётся установленным до снятия.", "Следите за временем с наложения. Перед снятием подготовьте гемостатическую марлю или бинты: исходное кровотечение может вернуться. ПКМ по устройству в сетке медикаментов → «Снять». Освободите место для возвращаемого предмета."),
            D(HealthGadgetKind.Jett, "Компрессионный турникет", "Устройство контролирует подходящее узловое кровотечение у основания конечности. Оно не устраняет произвольные внутренние кровотечения всей конечности.", "Подготовьте средства обработки раны до снятия. ПКМ по устройству в сетке медикаментов → «Снять». Следите за временем с наложения; объём потерянной крови восстанавливается отдельно."),
            D(HealthGadgetKind.Shock, "Огневой шок", "Короткая острая реакция на попадание. Влияет на пульс и проходит со временем. Это отдельное состояние от шока при кровопотере.", "Остановите кровотечение и обработайте ранения. Отдельного лекарства для этой краткой реакции не требуется. При продолжающемся ухудшении лечите имеющиеся травмы, не ждите окончания этого таймера."),
        };

        public static string PartName(BodyPart part)
            => (int)part >= 0 && (int)part < PartNames.Length ? PartNames[(int)part] : "Участок";
        public static bool IsInjury(HealthGadgetKind kind)
            => kind >= HealthGadgetKind.Bleeding && kind <= HealthGadgetKind.InternalBleeding || kind == HealthGadgetKind.Shock ||
               kind == HealthGadgetKind.ColdIllness || kind == HealthGadgetKind.WoundInfection;
        public static bool IsTreatment(HealthGadgetKind kind)
            => kind == HealthGadgetKind.StimOn || kind == HealthGadgetKind.StimCooldown || kind == HealthGadgetKind.Painkiller ||
               kind == HealthGadgetKind.HealBoost || kind == HealthGadgetKind.Coagulant || kind == HealthGadgetKind.Tourniquet ||
               kind == HealthGadgetKind.Jett || kind == HealthGadgetKind.Txa || kind == HealthGadgetKind.ChestSeal ||
               kind == HealthGadgetKind.PelvicBinder || kind == HealthGadgetKind.Recovery || kind == HealthGadgetKind.AntibioticTreatment;
        public static string GetTitle(HealthGadgetKind kind) => GetDescription(kind).Title;
        public static string GetExplanation(HealthGadgetKind kind) => GetDescription(kind).Explanation;
        public static string GetAdvice(HealthGadgetKind kind) => GetDescription(kind).Advice;

        public static void Collect(List<HealthGadgetEntry> effects, List<HealthGadgetEntry> indicators,
            K_HealthSystem health, K_VitalitySystem vitality, K_DebuffSystem debuffs,
            K_BloodSystem blood, K_WeightManager weight)
        {
            if (effects == null) throw new ArgumentNullException(nameof(effects));
            if (indicators == null) throw new ArgumentNullException(nameof(indicators));
            effects.Clear();
            indicators.Clear();

            CollectIndicators(indicators, vitality, blood, weight);
            if (health != null) CollectInjuries(effects, health);
            if (debuffs != null) CollectDebuffs(effects, health, debuffs);
            if (vitality != null) CollectVitalityEffects(effects, vitality);
            if (debuffs != null && (debuffs.IsUnderPainkiller || debuffs.HasPendingPainkiller))
            {
                bool pending = debuffs.HasPendingPainkiller && !debuffs.IsUnderPainkiller;
                string source = debuffs.PainkillerSourceItemID == "paracetamol" ? "Парацетамол" : "Морфин";
                float remaining = pending ? debuffs.PainkillerOnsetSecondsRemaining : debuffs.PainkillerSecondsRemaining;
                Add(effects, HealthGadgetKind.Painkiller, source + "\n" + (pending ? "Начало " : "Осталось ") + Timer(remaining),
                    "Препарат: " + source + ".\n" + (pending ? "До начала действия: " : "До окончания действия: ") + Timer(remaining) +
                    ".\nСила обезболивания: " + Percent(debuffs.PainReliefFraction * 100f) + ".",
                    false, !pending && debuffs.PainkillerFullDuration > 0f ? remaining / debuffs.PainkillerFullDuration : -1f);
            }
            if (health != null) CollectTreatments(effects, health);
            if (health?.Illnesses != null) CollectIllnesses(effects,health.Illnesses);
        }

        private static void CollectIllnesses(List<HealthGadgetEntry> result, K_IllnessSystem illnesses)
        {
            if (illnesses.HasCold)
                Add(result,HealthGadgetKind.ColdIllness,"Осталось " + Timer(illnesses.ColdSecondsRemaining),
                    "До восстановления: " + Timer(illnesses.ColdSecondsRemaining) + ".\nВ покое восстановление идёт быстрее.\n" +
                    "Скорость действий из-за простуды: " + Percent(illnesses.ColdActionSpeedMultiplier*100f) + ".",
                    false,illnesses.ColdFullDuration > 0f ? illnesses.ColdSecondsRemaining/illnesses.ColdFullDuration : -1f);
            if (illnesses.HasWoundInfection)
            {
                var sites = new StringBuilder();
                int recovering = 0;
                for (int i=0;i<20;i++)
                {
                    var part = (BodyPart)i;
                    if (!illnesses.IsWoundInfected(part)) continue;
                    bool active = illnesses.IsWoundInfectionRecovering(part);
                    float remaining = illnesses.GetWoundInfectionRecoverySeconds(part);
                    if (active) recovering++;
                    Line(sites,PartNames[i] + (active ? ": восстановление " + Timer(remaining) : ": восстановление приостановлено") + ".");
                }
                Add(result,HealthGadgetKind.WoundInfection,Zones(illnesses.WoundInfectionCount),
                    "Поражено участков: " + illnesses.WoundInfectionCount + ".\nНа лечении: " + recovering + ".\n" + sites);
            }
            if (illnesses.AntibioticSecondsRemaining > 0f)
                Add(result,HealthGadgetKind.AntibioticTreatment,"Курс\n" + Timer(illnesses.AntibioticSecondsRemaining),
                    "Амоксициллин/клавуланат.\nДо окончания курса: " + Timer(illnesses.AntibioticSecondsRemaining) +
                    ".\nИнфицированный участок восстанавливается после обработки раны. На простуду антибиотик не действует.",
                    false,illnesses.AntibioticFullDuration > 0f ? illnesses.AntibioticSecondsRemaining/illnesses.AntibioticFullDuration : -1f);
        }

        private static void CollectIndicators(List<HealthGadgetEntry> result,
            K_VitalitySystem vitality, K_BloodSystem blood, K_WeightManager weight)
        {
            if (vitality != null)
            {
                Add(result, HealthGadgetKind.Hunger, Percent(vitality.Hunger),
                    "Запас питания: " + Percent(vitality.Hunger) + "." +
                    (vitality.Hunger <= 0f ? "\nГолодание: запас полностью исчерпан." : string.Empty), true, vitality.Hunger / 100f);
                Add(result, HealthGadgetKind.Thirst, Percent(vitality.Thirst),
                    "Запас воды: " + Percent(vitality.Thirst) + "." +
                    (vitality.Thirst <= 0f ? "\nОбезвоживание: запас полностью исчерпан." : string.Empty), true, vitality.Thirst / 100f);
                Add(result, HealthGadgetKind.Cold, Percent(vitality.ColdExposure * 100f),
                    "Переохлаждение: " + Percent(vitality.ColdExposure * 100f) + ".\nТемпература вокруг: " +
                    Number(vitality.CurrentTemperature) + " °C.\n" +
                    (vitality.IsColdCritical ? "Критическое переохлаждение." : "Критический порог не достигнут."), true, vitality.ColdExposure);
                Add(result, HealthGadgetKind.Radiation, Percent(vitality.Radiation),
                    "Накопленная радиация: " + Percent(vitality.Radiation) + ".\nСкорость при облучении: " +
                    Percent(vitality.RadiationSpeedMult * 100f) + " от обычной.\nЗащита алкоголем от нового облучения: " +
                    (vitality.HasRadiationImmunity ? "действует." : "нет."), true, vitality.Radiation / 100f);
            }
            if (weight != null)
            {
                float effectiveWeight = weight.CurrentWeight;
                if (vitality != null && vitality.Hunger <= 30f) effectiveWeight /= 0.75f;
                Add(result, HealthGadgetKind.Overload, Number(weight.CurrentWeight) + " кг",
                    "Вес вещей: " + Number(weight.CurrentWeight) + " / " + Number(weight.MaxCapacity) + " кг.\n" +
                    "Нагрузка с учётом голода: " + Number(effectiveWeight) + " кг.\n" +
                    "Спринт недоступен от: " + Number(weight.DebuffStartWeight) + " кг.\n" +
                    "Скорость из-за нагрузки: " + Percent(weight.GetSpeedMultiplier() * 100f) + " от обычной.\n" +
                    "Спринт при этой нагрузке: " + (weight.CanSprint() ? "доступен." : "недоступен.") +
                    (weight.IsFullyStopped() ? "\nДвижение остановлено перегрузкой." : string.Empty), true, weight.GetCurrentWeightRatio());
            }
            if (blood != null)
                Add(result, HealthGadgetKind.Blood, Number(blood.CurrentVolumeMl, "0") + " мл · " + BloodReservePercent(blood),
                    "Объём крови: " + Number(blood.CurrentVolumeMl, "0") + " / " + Number(blood.MaxVolumeMl, "0") +
                    " мл.\nЗапас до смертельной кровопотери: " + BloodReservePercent(blood) + ".\n" +
                    Number(blood.MaxVolumeMl,"0") + " мл — 100%. " + Number(blood.DeathThresholdMl,"0") + " мл — 0%, смерть.\nСостояние: " +
                    BloodStateName(blood.State) + ".\nСкорость из-за кровопотери: " + Percent(blood.GetSpeedMultiplier() * 100f) +
                    " от обычной.", true, blood.BloodPercent);
        }

        public static string BloodReservePercent(K_BloodSystem blood)
        {
            if (blood == null || blood.BloodPercent <= 0f) return "0%";
            if (blood.CurrentVolumeMl >= blood.MaxVolumeMl) return "100%";
            float percent = blood.BloodPercent * 100f;
            return percent < 1f ? "<1%" : Mathf.FloorToInt(percent).ToString(CultureInfo.InvariantCulture) + "%";
        }

        private static void CollectInjuries(List<HealthGadgetEntry> result, K_HealthSystem health)
        {
            int count = health.GetBleedingLimbsCount();
            if (count > 0)
                Add(result, HealthGadgetKind.Bleeding, "Ур. " + health.GetMaxBleedingLevel(),
                    "Кровоточащих участков: " + count + ".\n" + Parts(health, HealthGadgetKind.Bleeding));
            count = health.GunshotCount;
            if (count > 0)
                Add(result, HealthGadgetKind.Gunshot, Zones(count),
                    "Раненых участков: " + count + ".\n" + Parts(health, HealthGadgetKind.Gunshot));
            count = 0;
            for (int i = 0; i < 20; i++) if (health.IsFractured((BodyPart)i)) count++;
            if (count > 0)
                Add(result, HealthGadgetKind.Fracture, Zones(count),
                    "Участков с переломами: " + count + ".\n" + Parts(health, HealthGadgetKind.Fracture));
            if (health.HasAnyLaceration())
            {
                int open = 0, glued = 0, sealedCount = 0;
                for (int i = 0; i < 20; i++)
                {
                    var wound = health.GetLacerationType((BodyPart)i);
                    if (wound == LacerationType.Open) open++;
                    else if (wound == LacerationType.Glued) glued++;
                    else if (wound == LacerationType.Sealed) sealedCount++;
                }
                Add(result, HealthGadgetKind.Laceration, Zones(open + glued + sealedCount),
                    "Открытых: " + open + "; заклеенных: " + glued + "; закрытых: " + sealedCount + ".\n" +
                    Parts(health, HealthGadgetKind.Laceration));
            }
            // Never derive presence, count, locations or a timer from unrevealed IB.
            count = health.GetInternalBleedingRevealedCount();
            if (count > 0)
                Add(result, HealthGadgetKind.InternalBleeding, Zones(count),
                    "Обнаруженных участков: " + count + ".\n" + Parts(health, HealthGadgetKind.InternalBleeding));
            if (health.IsShocked)
                Add(result, HealthGadgetKind.Shock, Timer(health.ShockSecondsRemaining),
                    "До окончания огневого шока: " + Timer(health.ShockSecondsRemaining) + ".");
        }

        private static void CollectDebuffs(List<HealthGadgetEntry> result, K_HealthSystem health, K_DebuffSystem debuffs)
        {
            if (debuffs.HasConcussion)
            {
                string remaining = debuffs.HasFractureConcussion ? "До лечения" : Timer(debuffs.ConcussionSecondsRemaining);
                string cause = debuffs.HasFractureConcussion ? "Сотрясение из-за перелома головы." : "Временное сотрясение после травмы.";
                if (debuffs.ConcussionSecondsRemaining > 0f)
                    cause += "\nТаймер сотрясения от удара: " + Timer(debuffs.ConcussionSecondsRemaining) + ".";
                Add(result, HealthGadgetKind.Concussion, remaining, cause + DebuffModifiers(DebuffKind.Concussion, debuffs, health));
            }
            if (debuffs.HasTBI)
                Add(result, HealthGadgetKind.Tbi, debuffs.IsTbiRecovering ? "Восстановление\n" + Timer(debuffs.TbiRecoverySecondsRemaining) : "До лечения",
                    (debuffs.IsTbiRecovering ? "Помощь оказана. Осталось восстановления в покое: " + Timer(debuffs.TbiRecoverySecondsRemaining) + "." : "Тяжёлая травма головы. Требуется лечение.") +
                    DebuffModifiers(DebuffKind.TBI, debuffs, health));
            if (debuffs.HasBreathingDifficulty)
            {
                string cause = "Травмы груди:";
                if (health != null && health.IsFractured(BodyPart.Chest) && !health.IsSplinted(BodyPart.Chest)) cause += " перелом;";
                if (health != null && health.IsGunshot(BodyPart.Chest)) cause += " огнестрельное ранение;";
                Add(result, HealthGadgetKind.BreathingDifficulty, "До лечения", cause.TrimEnd(';') + "." +
                    DebuffModifiers(DebuffKind.BreathingDifficulty, debuffs, health));
            }
            if (debuffs.HasImmobilized)
                Add(result, HealthGadgetKind.Immobilized, "Нет спринта", "Причина: перелом таза." +
                    DebuffModifiers(DebuffKind.Immobilized, debuffs, health));
        }

        private static void CollectVitalityEffects(List<HealthGadgetEntry> result, K_VitalitySystem vitality)
        {
            if (vitality.IsStimOn)
                Add(result, HealthGadgetKind.StimOn, Timer(vitality.StimulatorSecondsRemaining),
                    "До конца действия: " + Timer(vitality.StimulatorSecondsRemaining) +
                    ".\nПрепарат: кофеин.\nТекущая скорость действий: " + Percent(vitality.ActionSpeedMult * 100f) + " от обычной.",
                    false, vitality.StimulatorSecondsRemaining / vitality.StimulatorFullDuration);
            if (vitality.IsStimOff)
                Add(result, HealthGadgetKind.StimCooldown, Timer(vitality.StimCooldownSecondsRemaining),
                    "До начала усталости: " + Timer(vitality.StimCooldownSecondsRemaining) + ".\nПовторное применение пока недоступно.",
                    false, vitality.StimCooldownSecondsRemaining / vitality.StimCooldownFullDuration);
            if (vitality.IsFatigued)
                Add(result, HealthGadgetKind.Fatigue, Timer(vitality.FatigueSecondsRemaining),
                    "До окончания усталости: " + Timer(vitality.FatigueSecondsRemaining) +
                    ".\nСкорость действий от усталости: " + Percent(vitality.FatigueActionSpeedMultiplier * 100f) + " от обычной.",
                    false, vitality.FatigueSecondsRemaining / vitality.FatigueFullDuration);
            if (vitality.IsDrunk)
                Add(result, HealthGadgetKind.Drunk, Timer(vitality.DrunkSecondsRemaining),
                    "До окончания опьянения: " + Timer(vitality.DrunkSecondsRemaining) +
                    ".\nУровень алкоголя: " + Percent(vitality.AlcoholConcentration * 100f) +
                    ".\nЗащита от нового облучения: " + (vitality.HasRadiationImmunity ? "действует." : "нет."));
            if (vitality.IsHangover)
                Add(result, HealthGadgetKind.Hangover, Timer(vitality.HangoverSecondsRemaining),
                    "До окончания похмелья: " + Timer(vitality.HangoverSecondsRemaining) +
                    ".\nТекущая скорость действий: " + Percent(vitality.ActionSpeedMult * 100f) +
                    " от обычной.\nРадиус слышимости шагов: ×" + Number(vitality.HangoverFootstepNoiseMultiplier, "0.##") + ".");
        }

        private static void CollectTreatments(List<HealthGadgetEntry> result, K_HealthSystem health)
        {
            int gelCount = 0, coagulantCount = 0, recoveringCount = 0;
            float gelMin = float.MaxValue, coagulantMin = float.MaxValue, legacyMin = float.MaxValue;
            var gel = new StringBuilder();
            var coagulant = new StringBuilder();
            var recovery = new StringBuilder();
            for (int i = 0; i < 20; i++)
            {
                var part = (BodyPart)i;
                float seconds = health.GetHealBoostSecondsRemaining(part);
                if (seconds > 0f)
                {
                    gelCount++;
                    gelMin = Mathf.Min(gelMin, seconds);
                    bool blocked = health.IsFractured(part) || health.IsGunshot(part) ||
                        health.GetLacerationType(part) == LacerationType.Open || health.GetBleedingLevel(part) > 0;
                    Line(gel, PartNames[i] + ": " + Timer(seconds) + (blocked ? "; заживление приостановлено из-за травмы." : "; средство нанесено."));
                }
                if (health.IsSurgicalHemostatPrepared(part))
                {
                    coagulantCount++;
                    Line(coagulant, PartNames[i] + ": готово к хирургической обработке.");
                }
                seconds = health.GetRevealedCoagulantSecondsRemaining(part);
                if (seconds > 0f)
                {
                    coagulantCount++;
                    legacyMin = Mathf.Min(legacyMin,seconds);
                    Line(coagulant,PartNames[i] + ": лечение кровотечения, осталось " + Timer(seconds) + ".");
                }
                seconds = health.GetSplintRecoverySecondsRemaining(part);
                if (seconds > 0f && health.IsFractured(part))
                {
                    recoveringCount++;
                    coagulantMin = Mathf.Min(coagulantMin, seconds);
                    Line(recovery, PartNames[i] + ": " + Timer(seconds) + ".");
                }
            }
            if (gelCount > 0)
                Add(result, HealthGadgetKind.HealBoost, Timer(gelMin),
                    "Обработанных участков: " + gelCount + ".\nНа карточке — ближайшее окончание.\nКоэффициент при доступном заживлении: ×" +
                    Number(health.HealBoostMultiplier, "0.##") + ".\n" + gel);
            if (coagulantCount > 0)
                Add(result, HealthGadgetKind.Coagulant, legacyMin < float.MaxValue ? Timer(legacyMin) : Zones(coagulantCount),
                    "Участков на лечении: " + coagulantCount + ".\n" + coagulant);
            if (recoveringCount > 0)
                Add(result, HealthGadgetKind.Recovery, Timer(coagulantMin),
                    "Восстанавливающихся участков: " + recoveringCount + ".\n" +
                    (health.IsRestingForRecovery ? "Отсчёт идёт в покое.\n" : "Отсчёт приостановлен: нужен покой.\n") + recovery);
            if (health.TxaSecondsRemaining > 0f)
                Add(result, HealthGadgetKind.Txa, "Транексам\nОсталось " + Timer(health.TxaSecondsRemaining),
                    "До окончания действия: " + Timer(health.TxaSecondsRemaining) + ".\nСдерживает кровопотерю. Источник кровотечения требует отдельного лечения.",
                    false, health.TxaFullDuration > 0f ? health.TxaSecondsRemaining / health.TxaFullDuration : -1f);
            if (health.HasChestSeal)
                Add(result, HealthGadgetKind.ChestSeal, "Установлена\nС " + Timer(health.ChestSealElapsedSeconds),
                    "Клапанная наклейка на груди.\nВремя с наложения: " + Timer(health.ChestSealElapsedSeconds) + ".\nПроникающее повреждение требует дальнейшей обработки.");
            if (health.IsPelvisStabilized)
                Add(result, HealthGadgetKind.PelvicBinder, "Установлен\nС " + Timer(health.PelvicBinderElapsedSeconds),
                    "Таз зафиксирован.\nВремя с наложения: " + Timer(health.PelvicBinderElapsedSeconds) + ".\nВосстановление продолжается в покое.");
            CollectDevices(result, health.AppliedMedical, AppliedGhostKind.Tourniquet, HealthGadgetKind.Tourniquet);
            CollectDevices(result, health.AppliedMedical, AppliedGhostKind.JETT, HealthGadgetKind.Jett);
        }

        private static void CollectDevices(List<HealthGadgetEntry> result, K_AppliedMedicalManager manager,
            AppliedGhostKind appliedKind, HealthGadgetKind kind)
        {
            if (manager == null) return;
            int count = 0;
            float remaining = float.MaxValue;
            var text = new StringBuilder();
            var records = manager.Records;
            for (int i = 0; i < records.Count; i++)
            {
                var record = records[i];
                if (record == null || record.Kind != appliedKind || (!record.IsPersistent && record.RemainingSeconds <= 0f)) continue;
                count++;
                remaining = Mathf.Min(remaining, record.IsPersistent ? record.ElapsedSeconds : record.RemainingSeconds);
                int index = (int)record.AppliedTo;
                string name = index >= 0 && index < PartNames.Length ? PartNames[index] : "Участок не определён";
                string itemName = MedicalDatabase.Instance?.GetEntry(record.VirtualItemID)?.DisplayName ??
                    (appliedKind == AppliedGhostKind.JETT ? "Компрессионный турникет" : record.VirtualItemID == "tourniquet_elastic" ? "Эластичный жгут" : "Турникет CAT");
                Line(text, itemName + " · " + name + (record.IsPersistent ? ": с наложения " + Timer(record.ElapsedSeconds) : ": осталось " + Timer(record.RemainingSeconds)) + ".");
            }
            if (count > 0)
                Add(result, kind, "Установлено " + count, "Установлено: " + count + ".\n" + text);
        }

        private static string Parts(K_HealthSystem health, HealthGadgetKind kind)
        {
            var text = new StringBuilder();
            for (int i = 0; i < 20; i++)
            {
                var part = (BodyPart)i;
                string detail = null;
                switch (kind)
                {
                    case HealthGadgetKind.Bleeding:
                        int level = health.GetBleedingLevel(part);
                        if (level > 0) detail = "уровень " + level;
                        break;
                    case HealthGadgetKind.Gunshot:
                        if (health.IsGunshot(part)) detail = "огнестрельное ранение";
                        break;
                    case HealthGadgetKind.Fracture:
                        if (health.IsFractured(part)) detail = health.IsSplinted(part) ? "перелом зафиксирован; восстановление " + Timer(health.GetSplintRecoverySecondsRemaining(part)) : "перелом без фиксации";
                        break;
                    case HealthGadgetKind.Laceration:
                        var wound = health.GetLacerationType(part);
                        if (wound == LacerationType.Open) detail = "открытая рана";
                        else if (wound == LacerationType.Glued) detail = "заклеенная рана";
                        else if (wound == LacerationType.Sealed) detail = "закрытая рана";
                        break;
                    case HealthGadgetKind.InternalBleeding:
                        if (health.IsInternalBleedingRevealed(part)) detail = "внутреннее кровотечение обнаружено";
                        break;
                }
                if (detail != null) Line(text, PartNames[i] + ": " + detail + ".");
            }
            return text.ToString();
        }

        private static string DebuffModifiers(DebuffKind kind, K_DebuffSystem debuffs, K_HealthSystem health)
        {
            var config = K_HealthConfig.Instance;
            if (config == null) return string.Empty;
            var settings = config.GetDebuff(kind);
            var text = new StringBuilder();
            bool masked = debuffs.IsUnderPainkiller;
            if (masked) text.Append("\nОбезболивание временно ослабило нарушения движения и работы рук.");
            if (!masked)
            {
                if (kind != DebuffKind.Immobilized && !Mathf.Approximately(settings.speedMultiplier, 1f))
                    text.Append("\nСкорость движения с этим эффектом: ").Append(Percent(settings.speedMultiplier * 100f)).Append(" от обычной.");
            }
            if (health != null && (kind == DebuffKind.Concussion || kind == DebuffKind.TBI))
                text.Append("\nУстойчивость оружия: ")
                    .Append(Percent(health.GetArmAimMultiplier() * 100f)).Append(" от обычной.");
            if (settings.blockSprint && kind != DebuffKind.BreathingDifficulty)
                text.Append("\nСпринт недоступен даже под обезболиванием.");
            return text.ToString();
        }

        private static void Add(List<HealthGadgetEntry> target, HealthGadgetKind kind, string value,
            string summary, bool indicator = false, float normalized = -1f)
        {
            var description = GetDescription(kind);
            target.Add(new HealthGadgetEntry
            {
                Kind = kind, Title = description.Title, Value = value, Summary = summary,
                Explanation = description.Explanation, Advice = description.Advice,
                IsIndicator = indicator, NormalizedValue = normalized < 0f ? -1f : Mathf.Clamp01(normalized)
            });
        }

        private static Description D(HealthGadgetKind kind, string title, string explanation, string advice)
            => new Description { Kind = kind, Title = title, Explanation = explanation, Advice = advice };

        private static Description GetDescription(HealthGadgetKind kind)
        {
            switch (kind)
            {
                case HealthGadgetKind.ColdIllness: return D(kind,"Простуда","Вирусная болезнь немного замедляет действия и восстановление выносливости. Отдых ускоряет восстановление.","Отдохните и дождитесь восстановления. В покое простуда проходит быстрее. Отдельного лекарства от неё нет; антибиотик против вирусной простуды не действует.");
                case HealthGadgetKind.WoundInfection: return D(kind,"Инфекция раны","Бактериальная инфекция мешает заживлению поражённого участка. Риск растёт, пока рваная рана остаётся открытой или огнестрельное ранение не обработано. Кровотечение для заражения не обязательно.","Остановите кровотечение, обработайте огнестрельное ранение и закройте открытую рану. Примите курс амоксициллина/клавуланата. Восстановление идёт, когда участок обработан и антибиотик действует.");
                case HealthGadgetKind.AntibioticTreatment: return D(kind,"Антибактериальное лечение","Действует курс амоксициллина/клавуланата от инфекции раны. Для восстановления нужна обработанная рана.","Следите за состоянием поражённого участка. Остановите кровотечение и обработайте повреждение. Вирусная простуда не требует этого средства.");
                case HealthGadgetKind.Txa: return D(kind,"Действие TXA","Действует Транексам. Препарат временно уменьшает кровопотерю, но не восстанавливает повреждённые сосуды.","Используйте время действия для лечения источника кровотечения. Следите за объёмом крови; повторная доза не заменяет хирургическую помощь.");
                case HealthGadgetKind.ChestSeal: return D(kind,"Наклейка на груди","Клапанная наклейка стабилизирует дыхание при подходящем проникающем ранении груди. Она остаётся установленной.","Обработайте само ранение. Наклейка не лечит перелом рёбер и внутреннее кровотечение.");
                case HealthGadgetKind.PelvicBinder: return D(kind,"Таз зафиксирован","Тазовый бандаж уменьшает нестабильность повреждённого таза. Перелом восстанавливается со временем.","Дайте травме восстановиться в покое. Лечите кровотечения отдельно. Фиксация не возвращает полноценный спринт сразу.");
                case HealthGadgetKind.Recovery: return D(kind,"Восстановление","После помощи повреждённым костям требуется время на восстановление. Восстановление продолжается только в покое.","Остановитесь в безопасном месте. Движение задерживает восстановление.");
            }
            for (int i = 0; i < Descriptions.Length; i++)
                if (Descriptions[i].Kind == kind) return Descriptions[i];
            throw new ArgumentOutOfRangeException(nameof(kind));
        }

        private static void Line(StringBuilder text, string value)
        {
            if (text.Length > 0) text.Append('\n');
            text.Append(value);
        }

        private static string Number(float value, string format = "0.#") => value.ToString(format, Russian);
        private static string Percent(float value) => Number(value) + "%";

        public static string Timer(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds < 0f) return "—";
            int total = Mathf.CeilToInt(seconds);
            return (total / 60).ToString("00", CultureInfo.InvariantCulture) + ":" +
                (total % 60).ToString("00", CultureInfo.InvariantCulture);
        }

        private static string Zones(int count)
        {
            int last = count % 10;
            bool teens = count % 100 >= 11 && count % 100 <= 14;
            return count + (teens || last == 0 || last >= 5 ? " зон" : last == 1 ? " зона" : " зоны");
        }

        private static string BloodStateName(BloodState state)
        {
            switch (state)
            {
                case BloodState.Normal: return "норма";
                case BloodState.Warning: return "кровопотеря";
                case BloodState.Weakness: return "слабость";
                case BloodState.Shock: return "кровопотерный шок";
                case BloodState.Dead: return "смертельный уровень";
                default: return "неизвестно";
            }
        }
    }
}
