using System.Globalization;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Canvas-native ECG graphic: configurable panel, sweeping PQRST history and BPM readout.</summary>
    [AddComponentMenu("INCIDENT/UI/ECG Monitor")]
    [RequireComponent(typeof(CanvasRenderer))]
    public sealed class K_EcgMonitor : MaskableGraphic
    {
        [SerializeField, Tooltip("Витальность игрока. Если ссылка не назначена, ищется один раз в Start.")]
        private K_VitalitySystem _vitality;
        [SerializeField, Tooltip("Необязательный текст BPM. При отсутствии создаётся внутри монитора.")]
        private TextMeshProUGUI _bpmText;
        [SerializeField, Min(1f), Tooltip("Базовая скорость линии при 60 BPM, в пикселях Canvas в секунду.")]
        private float _pixelsPerSecond = 80f;
        [SerializeField, Min(0.5f), Tooltip("Толщина ЭКГ-линии в пикселях Canvas.")]
        private float _lineThickness = 1.5f;
        [SerializeField, Tooltip("Цвет фона ЭКГ. Альфа управляет прозрачностью: 0 — прозрачный фон, 1 — непрозрачный.")]
        private Color _backgroundColor = Color.black;
        [SerializeField, Tooltip("Независимый размер фона в пикселях Canvas. 0 по оси — размер RectTransform. Меняй эти поля, чтобы фон рос без изменения линии ЭКГ.")]
        private Vector2 _backgroundSize = Vector2.zero;
        [SerializeField, Tooltip("Смещение центра фона относительно центра RectTransform. Не сдвигает линию и число BPM.")]
        private Vector2 _backgroundOffset = Vector2.zero;

        [Header("ECG Background Grid")]
        [SerializeField, Tooltip("Тонкая сетка позади ЭКГ. Использует существующий цвет линий инвентаря и не меняет цвета фона, пульса или текста.")]
        private bool _showGrid = true;
        [SerializeField, Range(8f, 256f), Tooltip("Шаг квадратной сетки в единицах Canvas. Сетка следует размеру и смещению фона.")]
        private float _gridSpacing = 24f;
        [SerializeField, Range(0f, 1f), Tooltip("Множитель прозрачности сетки относительно существующих линий инвентаря.")]
        private float _gridOpacity = 0.3f;
        [SerializeField, Range(0.5f, 2f), Tooltip("Толщина линий сетки в единицах Canvas. Сохраняется минимум один экранный пиксель.")]
        private float _gridThickness = 0.5f;

        [Header("Panel Header and Frame")]
        [SerializeField, Tooltip("Показывать шапку над фоном ЭКГ в стиле сетки медикаментов.")]
        private bool _showHeader = true;
        [SerializeField, Tooltip("Надпись в шапке ЭКГ.")]
        private string _headerTitle = "Пульс";
        [SerializeField, Min(1f), Tooltip("Высота шапки в единицах Canvas. Не меняет размеры линии и текста BPM.")]
        private float _headerHeight = 32f;
        [SerializeField, Tooltip("Показывать рамки фона и шапки. Следуют размеру и смещению фона.")]
        private bool _showFrame = true;
        [SerializeField, Min(0.5f), Tooltip("Толщина рамок в единицах Canvas. Минимум один экранный пиксель сохраняет их видимыми при уменьшении UI.")]
        private float _frameThickness = 1f;

        [Header("ECG Line")]
        [SerializeField, Tooltip("Цвет ЭКГ при пульсе до 140 BPM включительно.")]
        private Color _normalColor = new Color(0.2f, 1f, 0.3f, 1f);
        [SerializeField, Tooltip("Цвет ЭКГ при пульсе выше 140 BPM.")]
        private Color _criticalColor = new Color(1f, 0.2f, 0.15f, 1f);
        [SerializeField, Range(40f, 200f), Tooltip("Пульс, выше которого линия и число BPM становятся критического цвета.")]
        private float _criticalThresholdBpm = 140f;

        [Header("BPM Readout")]
        [SerializeField, Tooltip("Автоматически брать цвет числа и букв BPM из цвета линии. Выключено — используются отдельные цвета ниже.")]
        private bool _readoutFollowsPulseColor = false;
        [SerializeField, Tooltip("Цвет числа пульса, независимо от фона и линии ЭКГ.")]
        private Color _numberColor = new Color(0.2f, 1f, 0.3f, 1f);
        [SerializeField, Range(0f, 2f), Tooltip("Множитель яркости числа пульса. 1 — заданный цвет; прозрачность регулируется альфой цвета.")]
        private float _numberBrightness = 1f;
        [SerializeField, Min(1f), Tooltip("Размер шрифта самого числа пульса в пикселях Canvas.")]
        private float _numberFontSize = 16f;
        [SerializeField, Tooltip("Цвет букв BPM, независимо от числа, фона и линии ЭКГ.")]
        private Color _unitColor = new Color(0.2f, 1f, 0.3f, 1f);
        [SerializeField, Range(0f, 2f), Tooltip("Множитель яркости букв BPM; не влияет на число, фон и линию.")]
        private float _unitBrightness = 1f;
        [SerializeField, Min(1f), Tooltip("Размер шрифта букв BPM, независимо от размера числа.")]
        private float _unitFontSize = 16f;

        private K_VitalitySystem _subscribed;
        private float _bpm = K_VitalitySystem.RestingBpm;
        private bool _hasPulse;
        private int _lastDisplayedBpm = -1;
        private float _lastUnitFontSize = -1f;
        private Color _lastNumberColor;
        private Color _lastUnitColor;
        private TextMeshProUGUI _headerText;
        private Color _lastPanelColor;
        private readonly Vector3[] _panelCorners = new Vector3[4];

        private bool _embeddedDisplay;
        private float _embeddedWaveformHeight;
        private bool ShowPanelHeader => _showHeader && !_embeddedDisplay;

        /// <summary>Actual background bounds in this monitor's local space, excluding its header.</summary>
        public Rect PanelRect => GetBackgroundRect(GetPixelAdjustedRect());
        public Rect OuterPanelRect
        {
            get
            {
                Rect bounds = PanelRect;
                if (ShowPanelHeader) bounds.yMax += Mathf.Max(1f, _headerHeight);
                return bounds;
            }
        }

        /// <summary>Configure an owned display-only view of the same player trace. The source is untouched.</summary>
        public void ConfigureEmbeddedDisplay(K_EcgMonitor source, K_VitalitySystem fallback, TMP_FontAsset font)
        {
            if (source == null || source == this) return;
            _embeddedDisplay = true;
            _embeddedWaveformHeight = source.rectTransform.rect.height;
            _pixelsPerSecond = source._pixelsPerSecond;
            _lineThickness = source._lineThickness;
            _backgroundColor = source._backgroundColor;
            _showGrid = source._showGrid;
            _gridSpacing = source._gridSpacing;
            _gridOpacity = source._gridOpacity;
            _gridThickness = source._gridThickness;
            _normalColor = source._normalColor;
            _criticalColor = source._criticalColor;
            _criticalThresholdBpm = source._criticalThresholdBpm;
            _readoutFollowsPulseColor = source._readoutFollowsPulseColor;
            _numberColor = source._numberColor;
            _numberBrightness = source._numberBrightness;
            _numberFontSize = source._numberFontSize;
            _unitColor = source._unitColor;
            _unitBrightness = source._unitBrightness;
            _unitFontSize = source._unitFontSize;
            color = source.color;
            material = source.material;
            EnsureReadout();
            // Copy font settings, never the source text reference: PositionReadout owns its child.
            if (source._bpmText != null)
            {
                _bpmText.font = source._bpmText.font;
                _bpmText.fontSharedMaterial = source._bpmText.fontSharedMaterial;
                _bpmText.fontStyle = source._bpmText.fontStyle;
            }
            else if (font != null) _bpmText.font = font;
            Bind(source._vitality != null ? source._vitality : fallback);
            RefreshPanelHeader();
            RefreshReadout();
            SetVerticesDirty();
        }

        protected override void OnEnable()
        {
            base.OnEnable();
            raycastTarget = false;
            // The player keeps sampling ECG even while this UI is inactive.
            Subscribe();
        }

        private void Start()
        {
            if (_vitality == null) _vitality = FindFirstObjectByType<K_VitalitySystem>();
            EnsureReadout();
            RefreshPanelHeader();
            Subscribe();
            RefreshReadout();
        }

        public void Bind(K_VitalitySystem vitality)
        {
            if (_vitality == vitality)
            {
                if (isActiveAndEnabled) Subscribe();
                return;
            }
            Unsubscribe();
            _vitality = vitality;
            if (isActiveAndEnabled) Subscribe();
        }

        protected override void OnDisable()
        {
            Unsubscribe();
            if (_headerText != null) _headerText.gameObject.SetActive(false);
            base.OnDisable();
        }

        private void Subscribe()
        {
            if (_subscribed != _vitality)
            {
                Unsubscribe();
                _subscribed = _vitality;
                if (_subscribed != null) _subscribed.OnPulseChanged += HandlePulseChanged;
            }
            if (_vitality != null)
            {
                HandlePulseChanged(_vitality.CurrentBpm);
            }
        }

        private void Unsubscribe()
        {
            if (_subscribed != null) _subscribed.OnPulseChanged -= HandlePulseChanged;
            _subscribed = null;
        }

        private void HandlePulseChanged(float bpm)
        {
            _bpm = bpm;
            bool alive = _vitality != null && _vitality.HasPulse;
            _hasPulse = alive;
            RefreshReadout();
            SetVerticesDirty();
        }

        private void Update()
        {
            RefreshPanelHeader();
            if (_vitality == null) return;
            _bpm = _vitality.CurrentBpm;
            bool alive = _vitality.HasPulse;
            _hasPulse = alive;
            RefreshReadout();
            SetVerticesDirty();
        }

        private void EnsureReadout()
        {
            if (_bpmText != null) return;
            var go = new GameObject("BPM", typeof(RectTransform), typeof(TextMeshProUGUI));
            var rect = go.GetComponent<RectTransform>();
            rect.SetParent(transform, false);
            rect.anchorMin = rect.anchorMax = rect.pivot = Vector2.one;
            rect.anchoredPosition = new Vector2(-8f, -4f);
            rect.sizeDelta = new Vector2(120f, 24f);
            _bpmText = go.GetComponent<TextMeshProUGUI>();
            _bpmText.fontSize = 16f;
            _bpmText.fontStyle = FontStyles.Bold;
            _bpmText.alignment = TextAlignmentOptions.Right;
            _bpmText.textWrappingMode = TextWrappingModes.NoWrap;
            _bpmText.raycastTarget = false;
            if (_bpmText.font == null && TMP_Settings.defaultFontAsset != null)
                _bpmText.font = TMP_Settings.defaultFontAsset;
        }

        private void RefreshReadout()
        {
            if (_bpmText == null) return;
            Color pulseColor = _bpm > _criticalThresholdBpm ? _criticalColor : _normalColor;
            Color number = ApplyBrightness(_readoutFollowsPulseColor ? pulseColor : _numberColor, _numberBrightness);
            Color unit = ApplyBrightness(_readoutFollowsPulseColor ? pulseColor : _unitColor, _unitBrightness);
            _bpmText.richText = true;
            _bpmText.enableAutoSizing = false;
            _bpmText.fontSize = Mathf.Max(1f, _numberFontSize);
            _bpmText.overflowMode = TextOverflowModes.Overflow;
            _bpmText.color = Color.white;
            int rounded = _hasPulse ? Mathf.RoundToInt(_bpm) : 0;
            float unitSize = Mathf.Max(1f, _unitFontSize);
            if (_lastDisplayedBpm == rounded && _lastUnitFontSize == unitSize &&
                _lastNumberColor.Equals(number) && _lastUnitColor.Equals(unit)) return;
            _lastDisplayedBpm = rounded;
            _lastUnitFontSize = unitSize;
            _lastNumberColor = number;
            _lastUnitColor = unit;
            _bpmText.text = $"<color=#{ColorUtility.ToHtmlStringRGBA(number)}>{rounded}</color> " +
                $"<size={unitSize.ToString("0.###", CultureInfo.InvariantCulture)}><color=#{ColorUtility.ToHtmlStringRGBA(unit)}>BPM</color></size>";
        }

        private static Color ApplyBrightness(Color tint, float brightness)
        {
            brightness = Mathf.Max(0f, brightness);
            return new Color(tint.r * brightness, tint.g * brightness, tint.b * brightness, tint.a);
        }

        private Rect GetBackgroundRect(Rect waveformRect)
        {
            if (_embeddedDisplay) return waveformRect;
            var size = new Vector2(_backgroundSize.x > 0f ? _backgroundSize.x : waveformRect.width,
                _backgroundSize.y > 0f ? _backgroundSize.y : waveformRect.height);
            Vector2 center = waveformRect.center + _backgroundOffset;
            return new Rect(center - size * 0.5f, size);
        }

        private void RefreshPanelHeader()
        {
            Color panelColor = K_ResponsiveCanvasLayout.ResolveLineColor(this);
            if (panelColor != _lastPanelColor) { _lastPanelColor = panelColor; SetVerticesDirty(); }
            Rect background = GetBackgroundRect(GetPixelAdjustedRect());
            float height = Mathf.Max(1f, _headerHeight);
            PositionReadout(background, height);
            if (!ShowPanelHeader)
            {
                if (_headerText != null) _headerText.gameObject.SetActive(false);
                return;
            }
            if (_headerText == null)
            {
                var existing = transform.Find("EcgHeaderTitle");
                var go = existing != null ? existing.gameObject :
                    new GameObject("EcgHeaderTitle", typeof(RectTransform), typeof(TextMeshProUGUI));
                if (existing == null) go.transform.SetParent(transform, false);
                _headerText = go.GetComponent<TextMeshProUGUI>();
                if (_headerText == null) _headerText = go.AddComponent<TextMeshProUGUI>();
                var layout = go.GetComponent<LayoutElement>();
                if (layout == null) layout = go.AddComponent<LayoutElement>();
                layout.ignoreLayout = true;
            }
            if (!_headerText.gameObject.activeSelf) _headerText.gameObject.SetActive(true);
            var rect = _headerText.GetComponent<RectTransform>();
            var centerAnchor = new Vector2(0.5f, 0.5f);
            if (rect.anchorMin != centerAnchor) rect.anchorMin = centerAnchor;
            if (rect.anchorMax != centerAnchor) rect.anchorMax = centerAnchor;
            if (rect.pivot != centerAnchor) rect.pivot = centerAnchor;
            Vector2 position = new Vector2(background.center.x, background.yMax + height * 0.5f) - rectTransform.rect.center;
            Vector2 size = new Vector2(Mathf.Max(1f, background.width - 16f), height);
            if (rect.anchoredPosition != position) rect.anchoredPosition = position;
            if (rect.sizeDelta != size) rect.sizeDelta = size;
            rect.localScale = Vector3.one;
            _headerText.text = string.IsNullOrWhiteSpace(_headerTitle) ? "Пульс" : _headerTitle;
            K_ContainerWindow.ApplyHeaderTitleStyle(_headerText);
            if (_headerText.font == null && TMP_Settings.defaultFontAsset != null)
                _headerText.font = TMP_Settings.defaultFontAsset;
        }

        private void PositionReadout(Rect background, float headerHeight)
        {
            if (_bpmText == null) return;
            var rect = _bpmText.GetComponent<RectTransform>();
            Vector2 size = rect.rect.size;
            if (rect.parent != transform) rect.SetParent(transform, false);
            var anchor = new Vector2(0.5f, 0.5f);
            var pivot = new Vector2(1f, ShowPanelHeader ? 0.5f : 1f);
            if (rect.anchorMin != anchor) rect.anchorMin = anchor;
            if (rect.anchorMax != anchor) rect.anchorMax = anchor;
            if (rect.pivot != pivot) rect.pivot = pivot;
            if (rect.sizeDelta != size) rect.sizeDelta = size;
            Vector2 position = new Vector2(background.xMax - 8f,
                ShowPanelHeader ? background.yMax + headerHeight * 0.5f : background.yMax - 4f) - rectTransform.rect.center;
            if (rect.anchoredPosition != position) rect.anchoredPosition = position;
            _bpmText.alignment = TextAlignmentOptions.Right;
            _bpmText.raycastTarget = false;
        }

        private void DrawPanelChrome(VertexHelper mesh, Rect background)
        {
            Color tint = K_ResponsiveCanvasLayout.ResolveLineColor(this);
            Rect header = new Rect(background.xMin, background.yMax, background.width, Mathf.Max(1f, _headerHeight));
            if (ShowPanelHeader) AddRect(mesh, header, tint);
            if (!_showFrame || _embeddedDisplay) return;
            K_InventoryFrameImage.ReadPixelsPerUnit(rectTransform, canvas, _panelCorners, out float pixelsX, out float pixelsY);
            float thickness = Mathf.Max(0.5f, _frameThickness);
            float horizontal = pixelsX > 0f ? Mathf.Max(thickness, 1f / pixelsX) : thickness;
            float vertical = pixelsY > 0f ? Mathf.Max(thickness, 1f / pixelsY) : thickness;
            AddFrame(mesh, background, horizontal, vertical, tint);
            if (ShowPanelHeader) AddFrame(mesh, header, horizontal, vertical, tint);
        }

        private void DrawBackgroundGrid(VertexHelper mesh, Rect background)
        {
            if (!_showGrid || background.width <= 0f || background.height <= 0f) return;
            float spacing = Finite(_gridSpacing) ? Mathf.Clamp(_gridSpacing, 8f, 256f) : 24f;
            float opacity = Finite(_gridOpacity) ? Mathf.Clamp01(_gridOpacity) : 0.3f;
            if (opacity <= 0f) return;
            Color tint = K_ResponsiveCanvasLayout.ResolveLineColor(this);
            tint.a *= opacity;
            K_InventoryFrameImage.ReadPixelsPerUnit(rectTransform, canvas, _panelCorners,
                out float pixelsX, out float pixelsY);
            float thickness = Finite(_gridThickness) ? Mathf.Clamp(_gridThickness, 0.5f, 2f) : 0.5f;
            float width = pixelsX > 0f ? Mathf.Max(thickness, 1f / pixelsX) : thickness;
            float height = pixelsY > 0f ? Mathf.Max(thickness, 1f / pixelsY) : thickness;

            // A fixed cap keeps malformed or unusually large authored backgrounds bounded.
            for (int i = 1; i <= 256; i++)
            {
                float x = background.xMin + i * spacing;
                if (x >= background.xMax) break;
                float left = Mathf.Max(background.xMin, x - width * 0.5f);
                float right = Mathf.Min(background.xMax, x + width * 0.5f);
                AddRect(mesh, new Rect(left, background.yMin, right - left, background.height), tint);
            }
            for (int i = 1; i <= 256; i++)
            {
                float y = background.yMin + i * spacing;
                if (y >= background.yMax) break;
                float bottom = Mathf.Max(background.yMin, y - height * 0.5f);
                float top = Mathf.Min(background.yMax, y + height * 0.5f);
                AddRect(mesh, new Rect(background.xMin, bottom, background.width, top - bottom), tint);
            }
        }

        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);

        private static void AddRect(VertexHelper mesh, Rect rect, Color tint)
        {
            if (rect.width <= 0f || rect.height <= 0f) return;
            AddQuad(mesh, new Vector2(rect.xMin, rect.yMin), new Vector2(rect.xMin, rect.yMax),
                new Vector2(rect.xMax, rect.yMax), new Vector2(rect.xMax, rect.yMin), tint);
        }

        private static void AddFrame(VertexHelper mesh, Rect rect, float width, float height, Color tint)
        {
            width = Mathf.Min(width, rect.width * 0.5f);
            height = Mathf.Min(height, rect.height * 0.5f);
            AddRect(mesh, new Rect(rect.xMin, rect.yMin, rect.width, height), tint);
            AddRect(mesh, new Rect(rect.xMin, rect.yMax - height, rect.width, height), tint);
            AddRect(mesh, new Rect(rect.xMin, rect.yMin + height, width, rect.height - 2f * height), tint);
            AddRect(mesh, new Rect(rect.xMax - width, rect.yMin + height, width, rect.height - 2f * height), tint);
        }

        protected override void OnPopulateMesh(VertexHelper mesh)
        {
            mesh.Clear();
            Rect rect = GetPixelAdjustedRect();
            if (rect.width <= 0f || rect.height <= 0f) return;
            Rect background = GetBackgroundRect(rect);
            AddQuad(mesh, new Vector2(background.xMin, background.yMin), new Vector2(background.xMin, background.yMax),
                new Vector2(background.xMax, background.yMax), new Vector2(background.xMax, background.yMin), _backgroundColor);
            DrawBackgroundGrid(mesh, background);
            if (_embeddedDisplay)
            {
                // More screen space must not stretch the authored ECG amplitude.
                float height = Mathf.Min(Mathf.Max(1f, _embeddedWaveformHeight), Mathf.Max(1f, rect.height - 40f));
                rect = new Rect(rect.xMin, rect.center.y - height * 0.5f - 12f, rect.width, height);
            }
            Color lineColor = _bpm > _criticalThresholdBpm ? _criticalColor : _normalColor;
            float plotHeight = Mathf.Max(1f, rect.height - 28f);
            float center = rect.yMin + plotHeight * 0.5f;
            if (!_hasPulse)
            {
                AddLine(mesh, new Vector2(rect.xMin, center), new Vector2(rect.xMax, center), lineColor);
                DrawPanelChrome(mesh, background);
                return;
            }
            Vector2 previous = Vector2.zero;
            bool connected = false;
            var trace = _vitality != null ? _vitality.PulseTrace : null;
            float distanceScale = Mathf.Max(1f, _pixelsPerSecond);
            for (int i = 0; trace != null && i < trace.Count; i++)
            {
                var point = trace.GetPoint(i);
                if ((trace.Distance - point.Distance) * distanceScale > Mathf.Max(0f, rect.width - 10f))
                { connected = false; continue; }
                var current = new Vector2(rect.xMin + (float)((point.Distance * distanceScale) % rect.width),
                    center + point.Value * plotHeight * 0.4f);
                if (connected && current.x > previous.x) AddLine(mesh, previous, current, lineColor);
                previous = current;
                connected = true;
            }
            DrawPanelChrome(mesh, background);
        }

        private void AddLine(VertexHelper mesh, Vector2 a, Vector2 b, Color tint)
        {
            Vector2 delta = b - a;
            if (delta.sqrMagnitude < 0.0001f) return;
            Vector2 normal = new Vector2(-delta.y, delta.x).normalized * (Mathf.Max(0.5f, _lineThickness) * 0.5f);
            AddQuad(mesh, a - normal, a + normal, b + normal, b - normal, tint);
        }

        private static void AddQuad(VertexHelper mesh, Vector2 a, Vector2 b, Vector2 c, Vector2 d, Color tint)
        {
            int start = mesh.currentVertCount;
            mesh.AddVert(a, tint, Vector2.zero);
            mesh.AddVert(b, tint, Vector2.zero);
            mesh.AddVert(c, tint, Vector2.zero);
            mesh.AddVert(d, tint, Vector2.zero);
            mesh.AddTriangle(start, start + 1, start + 2);
            mesh.AddTriangle(start, start + 2, start + 3);
        }
    }
}
