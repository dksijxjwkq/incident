using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Small vector details of the field monitor; no texture or material allocations.</summary>
    [RequireComponent(typeof(CanvasRenderer))]
    public sealed class K_HealthGadgetHardwareGraphic : MaskableGraphic
    {
        public enum Shape { Case, Power, Led }
        public Shape Mode { get; set; }

        protected override void OnPopulateMesh(VertexHelper mesh)
        {
            mesh.Clear();
            Rect r = GetPixelAdjustedRect();
            if (r.width <= 0f || r.height <= 0f) return;
            if (Mode == Shape.Case)
            {
                // Stepped, chamfered shell with light on its upper edge and a dark lower lip.
                Plate(mesh, r, 10f, new Color(.04f, .04f, .04f, 1f), new Color(.018f, .018f, .018f, 1f));
                Plate(mesh, Inset(r, 1.5f), 9f, new Color(.4f, .4f, .4f, 1f), new Color(.11f, .11f, .11f, 1f));
                Plate(mesh, Inset(r, 3.5f), 7f, new Color(.23f, .23f, .23f, 1f), new Color(.075f, .075f, .075f, 1f));
                Plate(mesh, Inset(r, 7f), 4f, color * 1.12f, color * .74f);
            }
            else if (Mode == Shape.Led)
            {
                Vector2 c = r.center;
                float radius = Mathf.Min(r.width, r.height) * .5f;
                Disc(mesh, c, radius, WithAlpha(color, .015f), WithAlpha(color, 0f));
                Disc(mesh, c, radius * .75f, WithAlpha(color, .16f), WithAlpha(color, 0f));
                Disc(mesh, c, radius * .36f, WithAlpha(color, .95f), WithAlpha(color, .35f));
                Disc(mesh, c + new Vector2(-.6f, .7f), radius * .14f, new Color(.95f, .95f, .95f, color.a), WithAlpha(color, .8f));
            }
            else
            {
                Vector2 c = r.center;
                float radius = Mathf.Min(r.width, r.height) * .46f;
                Disc(mesh, c, radius, new Color(.03f, .03f, .03f, 1f), new Color(.3f, .3f, .3f, 1f));
                Disc(mesh, c, radius - 1.5f, new Color(.1f, .1f, .1f, 1f), new Color(.13f, .13f, .13f, 1f));
                float glyph = radius * .48f;
                for (int i = 0; i < 24; i++)
                {
                    float a = (40f + i * 280f / 24f) * Mathf.Deg2Rad;
                    float b = (40f + (i + 1) * 280f / 24f) * Mathf.Deg2Rad;
                    Segment(mesh, c + new Vector2(Mathf.Sin(a), Mathf.Cos(a)) * glyph,
                        c + new Vector2(Mathf.Sin(b), Mathf.Cos(b)) * glyph, 1.3f, color);
                }
                Segment(mesh, c + Vector2.up * glyph * 1.18f, c + Vector2.up * glyph * .1f, 1.5f, color);
            }
        }

        private static Color WithAlpha(Color c, float a) { c.a *= a; return c; }
        private static Rect Inset(Rect r, float n) => new Rect(r.x + n, r.y + n, r.width - n * 2f, r.height - n * 2f);

        private static void Plate(VertexHelper mesh, Rect r, float cut, Color upper, Color lower)
        {
            cut = Mathf.Min(cut, Mathf.Min(r.width, r.height) * .25f);
            int start = mesh.currentVertCount;
            mesh.AddVert(r.center, Color.Lerp(lower, upper, .5f), Vector2.zero);
            Vertex(mesh, r, r.xMin + cut, r.yMin, upper, lower);
            Vertex(mesh, r, r.xMin, r.yMin + cut, upper, lower);
            Vertex(mesh, r, r.xMin, r.yMax - cut, upper, lower);
            Vertex(mesh, r, r.xMin + cut, r.yMax, upper, lower);
            Vertex(mesh, r, r.xMax - cut, r.yMax, upper, lower);
            Vertex(mesh, r, r.xMax, r.yMax - cut, upper, lower);
            Vertex(mesh, r, r.xMax, r.yMin + cut, upper, lower);
            Vertex(mesh, r, r.xMax - cut, r.yMin, upper, lower);
            for (int i = 0; i < 8; i++) mesh.AddTriangle(start, start + 1 + i, start + 1 + (i + 1) % 8);
        }

        private static void Vertex(VertexHelper mesh, Rect r, float x, float y, Color upper, Color lower)
            => mesh.AddVert(new Vector3(x, y), Color.Lerp(lower, upper, Mathf.InverseLerp(r.yMin, r.yMax, y)), Vector2.zero);

        private static void Disc(VertexHelper mesh, Vector2 center, float radius, Color inner, Color outer)
        {
            const int segments = 32;
            int start = mesh.currentVertCount;
            mesh.AddVert(center, inner, Vector2.zero);
            for (int i = 0; i < segments; i++)
            {
                float angle = i * Mathf.PI * 2f / segments;
                mesh.AddVert(center + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * radius, outer, Vector2.zero);
            }
            for (int i = 0; i < segments; i++) mesh.AddTriangle(start, start + 1 + i, start + 1 + (i + 1) % segments);
        }

        private static void Segment(VertexHelper mesh, Vector2 a, Vector2 b, float width, Color tint)
        {
            Vector2 d = (b - a).normalized;
            Vector2 n = new Vector2(-d.y, d.x) * width * .5f;
            int i = mesh.currentVertCount;
            mesh.AddVert(a - n, tint, Vector2.zero); mesh.AddVert(a + n, tint, Vector2.zero);
            mesh.AddVert(b + n, tint, Vector2.zero); mesh.AddVert(b - n, tint, Vector2.zero);
            mesh.AddTriangle(i, i + 1, i + 2); mesh.AddTriangle(i, i + 2, i + 3);
        }
    }
}
