using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Player-owned observations and treatment feedback, with a bounded saved journal.</summary>
    public sealed class K_HealthMonitorHistory : MonoBehaviour, ISaveable, IPreLoad, IPostLoad, ISavePayloadValidator
    {
        [SerializeField] private TMP_FontAsset _feedbackFont;
        private K_HealthSystem _health;
        private K_VitalitySystem _vitality;
        private K_DebuffSystem _debuffs;
        private K_BloodSystem _blood;
        private K_WeightManager _weight;
        private readonly List<HealthGadgetEntry> _effects = new List<HealthGadgetEntry>();
        private readonly List<HealthGadgetEntry> _indicators = new List<HealthGadgetEntry>();
        private readonly HealthMonitorEventLog _log = new HealthMonitorEventLog();
        private float _nextSample;
        private bool _initialized;
        private K_MedicalApplyService _medicalService;
        private Canvas _feedbackCanvas;
        private TextMeshProUGUI _feedbackText;
        private CanvasGroup _feedbackGroup;
        private float _feedbackUntil;
        private bool _wasPainkiller;
        public string CurrentFeedback => _feedbackText != null && Time.unscaledTime < _feedbackUntil ? _feedbackText.text : string.Empty;
        public int EntryCount => _log.EntryCount;
        public string SaveID => "PlayerHealthJournal";
        public bool IsDirty { get; set; } = true;
        public double ElapsedSeconds => _log.ElapsedSeconds;
        private void Start()
        {
            if (!_initialized) Initialize(GetComponent<K_HealthSystem>(), GetComponent<K_VitalitySystem>(), GetComponent<K_DebuffSystem>(), GetComponent<K_BloodSystem>(), GetComponent<K_WeightManager>());
            K_SaveManager.Instance?.Register(this);
        }
        public void Initialize(K_HealthSystem health, K_VitalitySystem vitality, K_DebuffSystem debuffs, K_BloodSystem blood, K_WeightManager weight)
        { if (_initialized) return; _health=health; _vitality=vitality; _debuffs=debuffs; _blood=blood; _weight=weight; _initialized=true; Sample(); }
        private void Update()
        {
            if (_initialized && _log.Tick(Time.deltaTime)) IsDirty = true;
            if (_initialized && Time.unscaledTime >= _nextSample) Sample();
            if (_feedbackGroup != null)
                _feedbackGroup.alpha = Mathf.Clamp01((_feedbackUntil - Time.unscaledTime) / .35f);
        }
        public void ConnectMedicalService(K_MedicalApplyService service, TMP_FontAsset font)
        {
            font = _feedbackFont != null ? _feedbackFont : font;
            if (_medicalService != service)
            {
                DisconnectMedicalService();
                _medicalService = service;
                if (service != null)
                {
                    service.OnApplyStarted += AppliedStarted;
                    service.OnApplyProgress += AppliedProgress;
                    service.OnApplyCompleted += AppliedCompleted;
                    service.OnApplyCancelled += AppliedCancelled;
                    service.OnApplyRejected += AppliedCancelled;
                }
            }
            if (_feedbackCanvas != null || font == null) return;
            var root = new GameObject("MedicalFeedback", typeof(RectTransform), typeof(Canvas), typeof(UnityEngine.UI.CanvasScaler));
            root.hideFlags = HideFlags.DontSave;
            root.transform.SetParent(transform, false);
            _feedbackCanvas = root.GetComponent<Canvas>();
            _feedbackCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
            _feedbackCanvas.sortingOrder = 250;
            var scaler = root.GetComponent<UnityEngine.UI.CanvasScaler>();
            scaler.uiScaleMode = UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f,1080f);
            scaler.matchWidthOrHeight = .5f;
            var panel = new GameObject("Notice", typeof(RectTransform), typeof(K_InventoryFrameImage), typeof(CanvasGroup));
            panel.transform.SetParent(root.transform, false);
            var rect = panel.GetComponent<RectTransform>();
            rect.anchorMin = rect.anchorMax = new Vector2(.5f,.16f);
            rect.sizeDelta = new Vector2(460f,48f);
            var background = panel.GetComponent<K_InventoryFrameImage>();
            background.UseInventoryLineColor = false;
            background.FillColor = new Color(.045f,.045f,.045f,.96f);
            background.BorderColor = new Color(.48f,.48f,.48f,.72f);
            background.BorderThickness = 1f;
            background.color = Color.white;
            background.raycastTarget = false;
            _feedbackGroup = panel.GetComponent<CanvasGroup>();
            _feedbackGroup.interactable = _feedbackGroup.blocksRaycasts = false;
            _feedbackGroup.alpha = 0f;
            var label = new GameObject("Text", typeof(RectTransform), typeof(TextMeshProUGUI));
            label.transform.SetParent(rect, false);
            var labelRect = label.GetComponent<RectTransform>();
            labelRect.anchorMin = Vector2.zero; labelRect.anchorMax = Vector2.one;
            labelRect.offsetMin = new Vector2(12f,6f); labelRect.offsetMax = new Vector2(-12f,-6f);
            _feedbackText = label.GetComponent<TextMeshProUGUI>();
            _feedbackText.font = font;
            _feedbackText.color = new Color(.9f,.9f,.9f,1f);
            _feedbackText.fontSize = 20f;
            _feedbackText.enableAutoSizing = true;
            _feedbackText.fontSizeMin = 15f; _feedbackText.fontSizeMax = 20f;
            _feedbackText.alignment = TextAlignmentOptions.Center;
            _feedbackText.raycastTarget = false;
            _feedbackText.richText = false;
        }
        private void DisconnectMedicalService()
        {
            if (_medicalService == null) return;
            _medicalService.OnApplyStarted -= AppliedStarted;
            _medicalService.OnApplyProgress -= AppliedProgress;
            _medicalService.OnApplyCompleted -= AppliedCompleted;
            _medicalService.OnApplyCancelled -= AppliedCancelled;
            _medicalService.OnApplyRejected -= AppliedCancelled;
            _medicalService = null;
        }
        private void OnDestroy() { DisconnectMedicalService(); K_SaveManager.Instance?.Unregister(this); }
        private string ItemName(MedicalItemRecord record)
        {
            var item = record.Item;
            if (item?.Data == null) return "средство";
            return _medicalService?.MedicalDatabase?.GetEntry(item.Data.ItemID)?.DisplayName ?? item.Data.DisplayName;
        }
        private string Target(MedicalItemRecord record, BodyPart part)
            => record.Item?.Data == null || (_medicalService?.MedicalDatabase?.IsSystemic(record.Item.Data.ItemID) ?? false)
                ? string.Empty : " · " + K_HealthGadgetContent.PartName(part);
        private void Notice(string text, float duration = 3.5f)
        {
            if (_feedbackText != null) _feedbackText.text = text;
            _feedbackUntil = Time.unscaledTime + duration;
        }
        private void AppliedStarted(MedicalItemRecord record, BodyPart part) { }
        private void AppliedProgress(MedicalItemRecord record, float progress) { }
        private void AppliedCompleted(MedicalItemRecord record, BodyPart part)
        {
            string message = "Применено: " + ItemName(record) + Target(record,part) + ".";
            _log.RecordTreatment(_log.ElapsedSeconds,message);
            IsDirty = true;
            Notice(message);
        }
        private void AppliedCancelled(MedicalItemRecord record, BodyPart part)
        {
            string message = "Не применено: " + ItemName(record) + ".";
            _log.RecordTreatment(_log.ElapsedSeconds,message);
            IsDirty = true;
            Notice(message);
        }
        private void Sample()
        {
            K_HealthGadgetContent.Collect(_effects, _indicators, _health, _vitality, _debuffs, _blood, _weight);
            bool painkiller = false;
            foreach (var effect in _effects) if (effect.Kind == HealthGadgetKind.Painkiller) painkiller = true;
            if (_wasPainkiller && !painkiller && _health != null && !_health.IsDead)
                Notice("Обезболивание больше не действует.");
            _wasPainkiller = painkiller;
            _log.Observe(_effects, _log.ElapsedSeconds, _health != null && _health.IsDead);
            IsDirty = true;
            _nextSample=Time.unscaledTime+.25f;
        }
        public string BuildText() => _log.BuildText();
        public void Save(BinaryWriter writer) => _log.Save(writer);
        public void Load(BinaryReader reader) { _log.Load(reader); IsDirty = false; }
        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context) => _log.ValidateLoad(reader);
        public void OnBeforeLoad()
        {
            _log.Reset(); _wasPainkiller = false; _feedbackUntil = 0f;
            if (_feedbackGroup != null) _feedbackGroup.alpha = 0f;
            IsDirty = false;
        }
        public void OnAfterLoad()
        {
            K_HealthGadgetContent.Collect(_effects, _indicators, _health, _vitality, _debuffs, _blood, _weight);
            _log.Rebase(_effects, _health != null && _health.IsDead);
            _wasPainkiller = _debuffs != null && (_debuffs.IsUnderPainkiller || _debuffs.HasPendingPainkiller);
            _nextSample = Time.unscaledTime + .25f;
        }
    }

}
