
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Этап 5: виджет одного медикамента в зеркале.
    /// Этап 6.1: LMB-drag — источник ghost-сессии.
    ///
    /// Отображает (иконка + количество), реагирует на левый клик
    /// (OnItemClicked), инициирует drag-сессию на LMB.
    ///
    /// НЕ выполняет drop / применение / списание — это подэтапы 6.2+.
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    public class K_MedicalMirrorItem : MonoBehaviour,
        IPointerClickHandler, IBeginDragHandler, IDragHandler, IEndDragHandler
    {
        [Header("Widget References")]
        [SerializeField] private Image _icon;
        [SerializeField] private TextMeshProUGUI _quantityText;

        private MedicalItemRecord _record;
        private int _index = -1;
        private K_MedicalMirrorPanel _owner;
        // Stage 4: applied view не создаёт второй реальный предмет в инвентаре.
        private AppliedMedicalRecord _appliedRecord;
        private InventoryItem _displayItem;
        private Image _chargeBar;
        private CanvasGroup _quantityLockGroup;
        private TextMeshProUGUI _iconFallbackText;

        /// <summary>Данные предмета. Валидны только пока виджет активен.</summary>
        public MedicalItemRecord Record => _record;

        /// <summary>Порядковый номер в списке MedicalInventoryService.GetMedicalItems().</summary>
        public int Index => _index;

        /// <summary>Владелец-панель. Может быть null после Reset().</summary>
        public K_MedicalMirrorPanel Owner => _owner;

        /// <summary>Прямая ссылка на InventoryItem для Этапа 6.</summary>
        public InventoryItem Item => _displayItem ?? _record.Item;
        public AppliedMedicalRecord AppliedRecord => _appliedRecord;
        public bool IsApplied => _appliedRecord != null;

        /// <summary>true если виджет держит валидную запись.</summary>
        public bool HasData => _record.Item != null || _appliedRecord != null;

        internal void BindReferences(Image icon, TextMeshProUGUI quantityText)
        {
            _icon = icon;
            _quantityText = quantityText;
        }

        internal void Setup(MedicalItemRecord record, int index, K_MedicalMirrorPanel owner)
        {
            _record = record;
            _index = index;
            _owner = owner;
            _displayItem = record.Item;
            _appliedRecord = owner?.HealthSystem?.AppliedMedical?.GetRecordForInstance(
                record.Item != null ? record.Item.InstanceID : 0);

            var item = record.Item;
            if (item == null || item.Data == null)
            {
                if (_icon != null) { _icon.sprite = null; _icon.enabled = false; }
                if (_quantityText != null) { _quantityText.text = string.Empty; _quantityText.gameObject.SetActive(false); }
                if (_chargeBar != null) _chargeBar.gameObject.SetActive(false);
                if (_iconFallbackText != null) _iconFallbackText.gameObject.SetActive(false);
                return;
            }

            if (_icon != null)
            {
                _icon.sprite = item.CurrentIcon;
                _icon.preserveAspect = true;
                _icon.enabled = _icon.sprite != null;
            }
            RefreshIconFallback(item.Data.DisplayName, item.Data.ItemID);

            if (_quantityText != null)
            {
                if (item.Quantity > 1)
                {
                    _quantityText.text = item.Quantity.ToString();
                    if (!_quantityText.gameObject.activeSelf)
                        _quantityText.gameObject.SetActive(true);
                }
                else
                {
                    _quantityText.text = string.Empty;
                    if (_quantityText.gameObject.activeSelf)
                        _quantityText.gameObject.SetActive(false);
                }
            }
            RefreshAppliedState();
        }

        private void LateUpdate()
        {
            RefreshQuantityLock();
        }

        private void RefreshQuantityLock()
        {
            bool locked = K_SplitStackDialog.IsItemLocked(Item);
            if (locked && _quantityLockGroup == null)
                _quantityLockGroup = GetComponent<CanvasGroup>() ?? gameObject.AddComponent<CanvasGroup>();
            if (_quantityLockGroup != null) _quantityLockGroup.alpha = locked ? 0.7f : 1f;
        }

        /// <summary>Stage 4: виртуальная запись контейнера в общем списке зеркала.</summary>
        internal void SetupApplied(AppliedMedicalRecord record, K_MedicalMirrorPanel owner)
        {
            _record = default;
            _index = -1;
            _owner = owner;
            _appliedRecord = record;
            _displayItem = record != null && !record.IsVirtual
                ? K_AppliedMedicalInventoryBridge.FindItem(owner?.InventoryUI, record.InstanceID)
                : null;
            var data = _displayItem?.Data ?? K_InventorySetup.DatabaseInstance?.GetItemData(
                record?.VirtualItemID);
            if (_icon != null)
            {
                _icon.sprite = _displayItem != null ? _displayItem.CurrentIcon : data?.Icon;
                _icon.preserveAspect = true;
                _icon.enabled = _icon.sprite != null;
            }
            RefreshIconFallback(data?.DisplayName, data?.ItemID ?? record?.VirtualItemID);
            if (_quantityText != null)
            {
                int quantity = _displayItem != null ? _displayItem.Quantity : record?.VirtualQuantity ?? 0;
                _quantityText.text = quantity > 1 ? quantity.ToString() : string.Empty;
                _quantityText.gameObject.SetActive(quantity > 1);
            }
            RefreshAppliedState();
        }

        private void RefreshIconFallback(string displayName, string itemID)
        {
            bool show = _icon == null || _icon.sprite == null;
            if (!show)
            {
                if (_iconFallbackText != null) _iconFallbackText.gameObject.SetActive(false);
                return;
            }
            if (_iconFallbackText == null)
            {
                var go = new GameObject("ItemNameFallback", typeof(RectTransform), typeof(TextMeshProUGUI));
                go.transform.SetParent(transform, false);
                var rect = go.GetComponent<RectTransform>();
                rect.anchorMin = Vector2.zero;
                rect.anchorMax = Vector2.one;
                rect.offsetMin = new Vector2(4f, 6f);
                rect.offsetMax = new Vector2(-4f, -4f);
                _iconFallbackText = go.GetComponent<TextMeshProUGUI>();
                _iconFallbackText.alignment = TextAlignmentOptions.Center;
                _iconFallbackText.fontSize = 11f;
                _iconFallbackText.enableAutoSizing = true;
                _iconFallbackText.fontSizeMin = 7f;
                _iconFallbackText.fontSizeMax = 11f;
                _iconFallbackText.textWrappingMode = TextWrappingModes.Normal;
                _iconFallbackText.overflowMode = TextOverflowModes.Ellipsis;
                _iconFallbackText.color = Color.white;
                _iconFallbackText.raycastTarget = false;
                if (_iconFallbackText.font == null && TMP_Settings.defaultFontAsset != null)
                    _iconFallbackText.font = TMP_Settings.defaultFontAsset;
            }
            _iconFallbackText.text = !string.IsNullOrWhiteSpace(displayName) ? displayName : itemID ?? "Медикамент";
            _iconFallbackText.gameObject.SetActive(true);
        }

        // Stage 4: вызывается панелью по OnHealthChanged; pooled widgets не подписываются.
        internal void RefreshAppliedState()
        {
            RefreshQuantityLock();
            if (_record.Item != null)
                _appliedRecord = _owner?.HealthSystem?.AppliedMedical?.GetRecordForInstance(
                    _record.Item.InstanceID);
            if (_icon != null)
                _icon.color = new Color(1f, 1f, 1f, IsApplied ? 0.5f : 1f);
            if (_iconFallbackText != null)
                _iconFallbackText.color = new Color(1f, 1f, 1f, IsApplied ? 0.5f : 1f);

            var item = Item;
            bool hasCharge = IsApplied || (item?.Data != null && item.Data.HasIndividualCharge);
            if (_appliedRecord != null && _appliedRecord.IsPersistent) hasCharge = false;
            if (item?.Data != null && (item.Data.ItemID == "tourniquet" || item.Data.ItemID == "tourniquet_elastic" || item.Data.ItemID == "jett")) hasCharge = false;
            if (!hasCharge)
            {
                if (_chargeBar != null) _chargeBar.gameObject.SetActive(false);
                return;
            }
            EnsureChargeBar();
            int percent = IsApplied ? _appliedRecord.ChargePercent : item.ChargePercent;
            var rect = _chargeBar.rectTransform;
            rect.anchorMax = new Vector2(Mathf.Clamp01(percent / 100f), 0f);
            _chargeBar.gameObject.SetActive(true);
        }

        private void EnsureChargeBar()
        {
            if (_chargeBar != null) return;
            var go = new GameObject("Stage4Charge", typeof(RectTransform), typeof(Image));
            go.transform.SetParent(transform, false);
            _chargeBar = go.GetComponent<Image>();
            _chargeBar.color = new Color(0.2f, 0.85f, 0.3f, 1f);
            _chargeBar.raycastTarget = false;
            var rect = _chargeBar.rectTransform;
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = new Vector2(1f, 0f);
            rect.pivot = Vector2.zero;
            rect.offsetMin = new Vector2(0f, 1f);
            rect.offsetMax = new Vector2(0f, 4f);
            rect.localScale = Vector3.one;
        }

        internal void Reset()
        {
            // Этап 6.1: если этот виджет — источник активного drag'а,
            // панель обязана отменить сессию ДО того, как мы обнулим _owner.
            if (_owner != null)
                _owner.NotifyWidgetReset(this);

            _record = default;
            _index = -1;
            _owner = null;
            _appliedRecord = null;
            _displayItem = null;
            if (_quantityLockGroup != null) _quantityLockGroup.alpha = 1f;
            if (_chargeBar != null) _chargeBar.gameObject.SetActive(false);
            if (_iconFallbackText != null) _iconFallbackText.gameObject.SetActive(false);
            if (_icon != null)
            {
                _icon.sprite = null;
                _icon.enabled = false;
                _icon.color = Color.white;
            }
            if (_quantityText != null)
            {
                _quantityText.text = string.Empty;
                _quantityText.gameObject.SetActive(false);
            }
        }

        // ═══════════════════════════════════════════════════════════════
        //  Pointer / Drag
        // ═══════════════════════════════════════════════════════════════

        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData == null) return;
            if (_owner == null) return;
            if (!HasData) return;
            if (K_SplitStackDialog.IsItemLocked(Item)) return;

            // Stage 4: active real/virtual views share the removable context.
            if (eventData.button == PointerEventData.InputButton.Right && IsApplied)
            {
                K_ContextMenu.Instance?.ShowApplied(_appliedRecord, eventData.position,
                    _owner.InventoryUI, _owner.HealthSystem);
                return;
            }
            if (_record.Item == null) return;

            // LMB — клик-форвард.
            if (eventData.button == PointerEventData.InputButton.Left)
            {
                _owner.RaiseItemClicked(this, _record);
                return;
            }

            // Этап 6.6: ПКМ — контекстное меню медикамента.
            if (eventData.button == PointerEventData.InputButton.Right)
            {
                var ui = _owner.InventoryUI;
                if (ui == null) return;
                K_ContextMenu.Instance?.Show(_record.Item, eventData.position, ui, null, _record);
            }
        }

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (eventData == null) return;
            if (eventData.button != PointerEventData.InputButton.Left) return;
            if (_owner == null) return;
            if (IsApplied) return;
            if (_record.Item == null) return;
            if (K_SplitStackDialog.IsItemLocked(Item)) return;
            _owner.BeginItemDrag(this, _record, eventData);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (eventData == null) return;
            if (_owner == null) return;
            _owner.UpdateItemDrag(this, _record, eventData);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (_owner == null) return;
            _owner.EndItemDrag(this, _record, eventData);
        }
    }
}
