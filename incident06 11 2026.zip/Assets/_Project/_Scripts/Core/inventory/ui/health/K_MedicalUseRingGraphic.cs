using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>A fixed-size UI ring, independent of the medicine's grid footprint or artwork.</summary>
    [RequireComponent(typeof(CanvasRenderer))]
    public sealed class K_MedicalUseRingGraphic : UnityEngine.UI.MaskableGraphic
    {
        private float _progress;
        public float Progress
        {
            get => _progress;
            set
            {
                float accepted = float.IsNaN(value) || float.IsInfinity(value) ? 0f : Mathf.Clamp01(value);
                if (Mathf.Approximately(_progress, accepted)) return;
                _progress = accepted;
                SetVerticesDirty();
            }
        }

        protected override void OnPopulateMesh(UnityEngine.UI.VertexHelper vertices)
        {
            vertices.Clear();
            var rect = rectTransform.rect;
            float radius = Mathf.Max(0f, Mathf.Min(rect.width, rect.height) * .5f - 1f);
            if (radius <= 0f) return;
            float thickness = Mathf.Min(2.5f, radius * .35f);
            AddArc(vertices, rect.center, radius, thickness, 1f, new Color(.12f, .12f, .12f, .92f));
            AddArc(vertices, rect.center, radius, thickness, _progress, new Color(.86f, .86f, .84f, 1f));
        }

        private static void AddArc(UnityEngine.UI.VertexHelper vertices, Vector2 center, float radius,
            float thickness, float portion, Color tint)
        {
            int segments = Mathf.CeilToInt(64f * portion);
            if (segments <= 0) return;
            for (int segment = 0; segment < segments; segment++)
            {
                float from = (segment / 64f) * Mathf.PI * 2f;
                float to = Mathf.Min((segment + 1) / 64f, portion) * Mathf.PI * 2f;
                var outerA = new Vector2(Mathf.Sin(from), Mathf.Cos(from));
                var outerB = new Vector2(Mathf.Sin(to), Mathf.Cos(to));
                int start = vertices.currentVertCount;
                vertices.AddVert(center + outerA * (radius - thickness), tint, Vector2.zero);
                vertices.AddVert(center + outerA * radius, tint, Vector2.zero);
                vertices.AddVert(center + outerB * radius, tint, Vector2.zero);
                vertices.AddVert(center + outerB * (radius - thickness), tint, Vector2.zero);
                vertices.AddTriangle(start, start + 1, start + 2);
                vertices.AddTriangle(start, start + 2, start + 3);
            }
        }
    }
}
