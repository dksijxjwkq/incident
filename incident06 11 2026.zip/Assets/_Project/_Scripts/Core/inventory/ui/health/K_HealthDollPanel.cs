using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Reversible decoration behind the inventory doll, fitted only to its body segments.</summary>
    [DisallowMultipleComponent]
    [DefaultExecutionOrder(1100)]
    [AddComponentMenu("INCIDENT/UI/Health Doll Panel")]
    public sealed class K_HealthDollPanel : MonoBehaviour
    {
        [Serializable]
        public sealed class Settings
        {
            [Tooltip("Показывать программную рамку и подложку куклы. При выключении восстанавливаются исходные ручные линии.")]
            public bool Enabled = true;
            [Tooltip("Независимый цвет и прозрачность рамки куклы.")]
            public Color FrameColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 100f / 255f);
            [Tooltip("Цвет заливки под куклой. Альфа управляет прозрачностью; заливка не перекрывает сегменты.")]
            public Color FillColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 4f / 255f);
            [Min(0f), Tooltip("Толщина рамки в единицах Canvas. Минимум один экранный пиксель сохраняется при уменьшении интерфейса.")]
            public float Thickness = 1f;
            [Min(0f), Tooltip("Ширина рамки и заливки в единицах Canvas, без правой декоративной полосы. 0 — автоматический размер. Размер куклы не меняется.")]
            public float Width = 0f;
            [Min(0f), Tooltip("Высота рамки и заливки в единицах Canvas. 0 — автоматический размер. Правая полоса следует за высотой рамки; размер куклы не меняется.")]
            public float Height = 0f;
            [Tooltip("Дополнительные отступы от исходной рамки: X — слева, Y — справа, Z — сверху, W — снизу. Отрицательные значения уменьшают автоматический размер. При заданной ширине или высоте отступы по этой оси влияют только на положение центра.")]
            public Vector4 ExtraPadding = Vector4.zero;
            [Tooltip("Показывать правую декоративную полосу, как у исходной ручной рамки.")]
            public bool ShowSideStrip = true;
            [Min(0f), Tooltip("Ширина правой декоративной полосы в единицах Canvas.")]
            public float SideStripWidth = 16.5f;
            [Tooltip("Независимый цвет и прозрачность правой декоративной полосы.")]
            public Color SideStripColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 100f / 255f);
            [Header("Header")]
            [Tooltip("Показывать шапку над куклой. Стиль и высота берутся из тех же настроек, что у зеркала медикаментов.")]
            public bool ShowHeader = true;
            [Tooltip("Подпись шапки куклы здоровья. Пустое значение заменяется на «Вы».")]
            public string HeaderLabel = "Вы";
        }

        private static readonly string[] LegacyNames =
            { "MedicalLine1", "MedicalLine2", "MedicalLine3", "MedicalLine4", "MedicalPel1" };
        private readonly Image[] _legacyImages = new Image[5];
        private readonly bool[] _legacyEnabled = new bool[5];
        private readonly Vector3[] _corners = new Vector3[4];
        private MonoBehaviour _owner;
        private Image[] _segments;
        private Settings _settings;
        private RectTransform _space;
        private K_InventoryFrameImage _panel;
        private Image _sideStrip;
        private K_InventoryUI _inventoryUI;
        private K_InventoryFrameImage _header;
        private TextMeshProUGUI _headerText;
        private bool _legacySearched, _calibrated;
        private Vector4 _padding;

        public static K_HealthDollPanel Ensure(MonoBehaviour owner, Image[] segments, Settings settings,
            K_InventoryUI inventoryUI = null)
        {
            if (owner == null) return null;
            var panel = owner.GetComponent<K_HealthDollPanel>();
            if (panel == null) panel = owner.gameObject.AddComponent<K_HealthDollPanel>();
            panel.Configure(owner, segments, settings);
            if (inventoryUI != null) panel._inventoryUI = inventoryUI;
            panel.Refresh();
            return panel;
        }

        private void Configure(MonoBehaviour owner, Image[] segments, Settings settings)
        {
            var space = owner.transform.parent as RectTransform;
            if (_owner != owner || _segments != segments || _space != space)
            {
                RestoreLegacy();
                HidePanel();
                Array.Clear(_legacyImages, 0, _legacyImages.Length);
                _legacySearched = _calibrated = false;
                _inventoryUI = owner.GetComponentInParent<K_InventoryUI>();
            }
            _owner = owner;
            _segments = segments;
            _settings = settings;
            _space = space;
        }

        private void OnEnable() => Refresh();
        private void LateUpdate() => Refresh();
        private void OnDisable() { HidePanel(); RestoreLegacy(); }
        private void OnDestroy() { HidePanel(); RestoreLegacy(); }

        public void Refresh()
        {
            if (!isActiveAndEnabled || _owner == null || !_owner.isActiveAndEnabled ||
                _settings == null || !_settings.Enabled)
            {
                HidePanel();
                RestoreLegacy();
                return;
            }
            var currentSpace = _owner.transform.parent as RectTransform;
            if (currentSpace != _space) Configure(_owner, _segments, _settings);
            if (_space == null || !TryBounds(_segments, 20, false, out Rect segments))
            {
                HidePanel();
                RestoreLegacy();
                return;
            }
            if (!_legacySearched) FindLegacy();
            if (!_calibrated)
            {
                bool hasFourLines = _legacyImages[0] != null && _legacyImages[1] != null &&
                    _legacyImages[2] != null && _legacyImages[3] != null;
                if (hasFourLines)
                {
                    if (!TryBounds(_legacyImages, 4, true, out Rect authored))
                    {
                        HidePanel();
                        RestoreLegacy();
                        return;
                    }
                    _padding = new Vector4(segments.xMin - authored.xMin, authored.xMax - segments.xMax,
                        authored.yMax - segments.yMax, segments.yMin - authored.yMin);
                }
                else _padding = new Vector4(24f, 24f, 24f, 12f);
                _calibrated = true;
            }
            Vector4 padding = _padding + _settings.ExtraPadding;
            float left = segments.xMin - padding.x, right = segments.xMax + padding.y;
            float bottom = segments.yMin - padding.w, top = segments.yMax + padding.z;
            if (!Finite(left) || !Finite(right) || !Finite(bottom) || !Finite(top) || right <= left || top <= bottom)
            {
                HidePanel();
                RestoreLegacy();
                return;
            }

            EnsureVisuals();
            var rect = _panel.rectTransform;
            rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(0.5f, 0.5f);
            Vector2 size = new Vector2(right - left, top - bottom);
            Vector2 position = new Vector2((left + right) * 0.5f, (bottom + top) * 0.5f) - _space.rect.center;
            if (Finite(_settings.Width) && _settings.Width > 0f) size.x = _settings.Width;
            if (Finite(_settings.Height) && _settings.Height > 0f) size.y = _settings.Height;
            if (rect.sizeDelta != size) rect.sizeDelta = size;
            if (rect.anchoredPosition != position) rect.anchoredPosition = position;
            rect.localScale = Vector3.one;
            rect.localRotation = Quaternion.identity;
            _panel.UseInventoryLineColor = false;
            _panel.BorderColor = _settings.FrameColor;
            _panel.FillColor = _settings.FillColor;
            _panel.BorderThickness = Finite(_settings.Thickness) ? Mathf.Max(0f, _settings.Thickness) : 1f;
            _panel.color = Color.white;
            _panel.raycastTarget = false;
            if (!_panel.enabled) _panel.enabled = true;

            bool showStrip = _settings.ShowSideStrip && Finite(_settings.SideStripWidth) && _settings.SideStripWidth > 0f;
            if (_sideStrip.gameObject.activeSelf != showStrip) _sideStrip.gameObject.SetActive(showStrip);
            if (showStrip)
            {
                var strip = _sideStrip.rectTransform;
                strip.anchorMin = strip.anchorMax = new Vector2(1f, 0.5f);
                strip.pivot = new Vector2(0f, 0.5f);
                strip.anchoredPosition = new Vector2(0.15f, 0f);
                Vector2 stripSize = new Vector2(_settings.SideStripWidth, size.y);
                if (strip.sizeDelta != stripSize) strip.sizeDelta = stripSize;
                _sideStrip.color = _settings.SideStripColor;
                _sideStrip.raycastTarget = false;
            }
            RefreshHeader(size, showStrip);
            if (!_panel.gameObject.activeSelf) _panel.gameObject.SetActive(true);
            for (int i = 0; i < _legacyImages.Length; i++)
                if (_legacyImages[i] != null) _legacyImages[i].enabled = false;
        }

        private void RefreshHeader(Vector2 size, bool showStrip)
        {
            if (!_settings.ShowHeader)
            {
                if (_header != null) _header.gameObject.SetActive(false);
                return;
            }

            float height = 32f, thickness = 1f;
            Color fill = K_ResponsiveCanvasLayout.ResolveLineColor(this), border = fill;
            if (_inventoryUI != null)
                _inventoryUI.GetContainerWindowHeaderStyle(out height, out fill, out border, out thickness);
            height = Finite(height) ? Mathf.Max(1f, height) : 32f;
            thickness = Finite(thickness) ? Mathf.Max(1f, thickness) : 1f;

            if (_header == null)
            {
                var existing = _panel.transform.Find("HealthDollHeader");
                var go = existing != null ? existing.gameObject :
                    new GameObject("HealthDollHeader", typeof(RectTransform));
                if (existing == null)
                {
                    go.layer = gameObject.layer;
                    go.transform.SetParent(_panel.transform, false);
                }
                _header = go.GetComponent<K_InventoryFrameImage>();
                if (_header == null) _header = go.AddComponent<K_InventoryFrameImage>();
                var layout = go.GetComponent<LayoutElement>();
                if (layout == null) layout = go.AddComponent<LayoutElement>();
                layout.ignoreLayout = true;
            }

            var rect = _header.rectTransform;
            rect.anchorMin = rect.anchorMax = new Vector2(0.5f, 1f);
            rect.pivot = new Vector2(0.5f, 0f);
            // Keep the left edge fixed and include the full right strip, including its gap.
            float rightExtension = showStrip
                ? _sideStrip.rectTransform.anchoredPosition.x + _sideStrip.rectTransform.rect.width : 0f;
            var headerPosition = new Vector2(rightExtension * 0.5f, 0f);
            if (rect.anchoredPosition != headerPosition) rect.anchoredPosition = headerPosition;
            var headerSize = new Vector2(size.x + rightExtension, height);
            if (rect.sizeDelta != headerSize) rect.sizeDelta = headerSize;
            rect.localScale = Vector3.one;
            rect.localRotation = Quaternion.identity;
            _header.UseInventoryLineColor = false;
            _header.BorderColor = border;
            _header.FillColor = fill;
            _header.BorderThickness = thickness;
            _header.color = Color.white;
            _header.raycastTarget = false;

            if (_headerText == null)
            {
                var existing = rect.Find("WindowTitle");
                var go = existing != null ? existing.gameObject :
                    new GameObject("WindowTitle", typeof(RectTransform), typeof(TextMeshProUGUI));
                if (existing == null)
                {
                    go.layer = gameObject.layer;
                    go.transform.SetParent(rect, false);
                }
                _headerText = go.GetComponent<TextMeshProUGUI>();
                if (_headerText == null) _headerText = go.AddComponent<TextMeshProUGUI>();
            }
            var titleRect = _headerText.GetComponent<RectTransform>();
            titleRect.anchorMin = titleRect.anchorMax = titleRect.pivot = new Vector2(0.5f, 0.5f);
            if (titleRect.anchoredPosition != Vector2.zero) titleRect.anchoredPosition = Vector2.zero;
            var titleSize = new Vector2(Mathf.Max(0f, headerSize.x - 16f), height);
            if (titleRect.sizeDelta != titleSize) titleRect.sizeDelta = titleSize;
            titleRect.localScale = Vector3.one;
            _headerText.text = string.IsNullOrWhiteSpace(_settings.HeaderLabel) ? "Вы" : _settings.HeaderLabel;
            K_ContainerWindow.ApplyHeaderTitleStyle(_headerText);
            if (_headerText.font == null && TMP_Settings.defaultFontAsset != null)
                _headerText.font = TMP_Settings.defaultFontAsset;
            if (!_header.gameObject.activeSelf) _header.gameObject.SetActive(true);
        }

        private void FindLegacy()
        {
            _legacySearched = true;
            for (Transform ancestor = _space; ancestor != null; ancestor = ancestor.parent)
            {
                bool found = false;
                for (int i = 0; i < LegacyNames.Length; i++)
                {
                    var child = ancestor.Find(LegacyNames[i]);
                    var image = child != null ? child.GetComponent<Image>() : null;
                    _legacyImages[i] = image;
                    if (image == null) continue;
                    found = true;
                    _legacyEnabled[i] = image.enabled;
                }
                if (found) return;
            }
        }

        private bool TryBounds(Image[] images, int maximum, bool requireAll, out Rect bounds)
        {
            bounds = default;
            if (images == null) return false;
            int count = images.Length < maximum ? images.Length : maximum;
            if (requireAll && count < maximum) return false;
            bool any = false;
            Vector2 min = Vector2.zero, max = Vector2.zero;
            for (int i = 0; i < count; i++)
            {
                var image = images[i];
                if (image == null) { if (requireAll) return false; continue; }
                var rect = image.rectTransform;
                if (rect.rect.width <= 0f || rect.rect.height <= 0f) return false;
                rect.GetWorldCorners(_corners);
                for (int corner = 0; corner < _corners.Length; corner++)
                {
                    Vector2 point = _space.InverseTransformPoint(_corners[corner]);
                    if (!Finite(point.x) || !Finite(point.y)) return false;
                    if (!any) { min = max = point; any = true; }
                    else { min = Vector2.Min(min, point); max = Vector2.Max(max, point); }
                }
            }
            if (!any || max.x <= min.x || max.y <= min.y) return false;
            bounds = new Rect(min, max - min);
            return true;
        }

        private void EnsureVisuals()
        {
            if (_panel == null)
            {
                for (int i = 0; i < _space.childCount; i++)
                {
                    var child = _space.GetChild(i);
                    if (child.gameObject.name != "HealthDollPanel") continue;
                    _panel = child.GetComponent<K_InventoryFrameImage>();
                    if (_panel != null) break;
                }
                if (_panel == null)
                {
                    var go = new GameObject("HealthDollPanel", typeof(RectTransform));
                    go.SetActive(false);
                    go.layer = gameObject.layer;
                    go.transform.SetParent(_space, false);
                    _panel = go.AddComponent<K_InventoryFrameImage>();
                }
                var layout = _panel.GetComponent<LayoutElement>();
                if (layout == null) layout = _panel.gameObject.AddComponent<LayoutElement>();
                layout.ignoreLayout = true;
            }
            if (_panel.transform.parent != _space) _panel.transform.SetParent(_space, false);
            if (_panel.transform.GetSiblingIndex() != 0) _panel.transform.SetAsFirstSibling();
            if (_sideStrip == null)
            {
                var existing = _panel.transform.Find("SideStrip");
                if (existing != null) _sideStrip = existing.GetComponent<Image>();
                if (_sideStrip == null)
                {
                    var go = new GameObject("SideStrip", typeof(RectTransform), typeof(Image));
                    go.layer = gameObject.layer;
                    go.transform.SetParent(_panel.transform, false);
                    _sideStrip = go.GetComponent<Image>();
                }
                _sideStrip.sprite = null;
                _sideStrip.type = Image.Type.Simple;
                _sideStrip.raycastTarget = false;
            }
        }

        private void HidePanel()
        {
            if (_panel != null && _panel.gameObject.activeSelf) _panel.gameObject.SetActive(false);
        }

        private void RestoreLegacy()
        {
            for (int i = 0; i < _legacyImages.Length; i++)
            {
                var image = _legacyImages[i];
                if (image == null) continue;
                image.enabled = _legacyEnabled[i];
            }
        }

        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
