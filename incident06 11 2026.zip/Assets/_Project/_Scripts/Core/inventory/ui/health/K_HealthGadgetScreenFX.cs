using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Mesh-only screen startup and glass shading. Bounded below 2,000 vertices; never intercepts clicks.</summary>
    [RequireComponent(typeof(CanvasRenderer))]
    public sealed class K_HealthGadgetScreenFX : MaskableGraphic
    {
        private float _progress = 1f, _strength, _scanline;
        private Color _tint;
        public void SetPhase(float progress, float strength, float scanline, Color tint)
        {
            progress = Mathf.Clamp01(progress);
            strength = Mathf.Clamp01(strength);
            scanline = Mathf.Clamp(scanline, 0f, 0.1f);
            if (_progress == progress && _strength == strength && _scanline == scanline && _tint == tint) return;
            _progress = progress;
            _strength = strength;
            _scanline = scanline;
            _tint = tint;
            raycastTarget = false;
            SetVerticesDirty();
        }

        protected override void OnPopulateMesh(VertexHelper mesh)
        {
            mesh.Clear();
            Rect rect = GetPixelAdjustedRect();
            if (rect.width <= 0f || rect.height <= 0f) return;
            Color tint = WithAlpha(_tint, _scanline);
            float step = Mathf.Max(4f, rect.height / 150f);
            for (float y = rect.yMin; y < rect.yMax; y += step)
                Quad(mesh, new Rect(rect.xMin, y, rect.width, 0.5f), tint);

            // A narrow, stepped vignette makes the display feel recessed in its bezel.
            // It remains completely static once the startup phase has finished.
            float edge = Mathf.Min(16f, Mathf.Min(rect.width, rect.height) * 0.06f);
            for (int i = 0; i < 8; i++)
            {
                float inset = edge * i / 8f;
                float thickness = edge / 8f;
                Color shadow = new Color(0f, 0f, 0f, 0.19f * (1f - i / 8f));
                Quad(mesh, new Rect(rect.xMin + inset, rect.yMin + inset,
                    rect.width - 2f * inset, thickness), shadow);
                Quad(mesh, new Rect(rect.xMin + inset, rect.yMax - inset - thickness,
                    rect.width - 2f * inset, thickness), shadow);
                Quad(mesh, new Rect(rect.xMin + inset, rect.yMin + inset + thickness,
                    thickness, rect.height - 2f * inset - 2f * thickness), shadow);
                Quad(mesh, new Rect(rect.xMax - inset - thickness, rect.yMin + inset + thickness,
                    thickness, rect.height - 2f * inset - 2f * thickness), shadow);
            }
            if (_progress >= 1f || _strength <= 0f) return;

            float p = _progress;
            int phase = Mathf.FloorToInt(p * 38f);
            float reveal = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(0.13f, 0.74f, p));
            float envelope = 1f - Mathf.SmoothStep(0.44f, 1f, p);
            float openingHeight = Mathf.Max(1.5f, rect.height * reveal);
            float center = rect.center.y;
            float lower = center - openingHeight * 0.5f;
            float upper = center + openingHeight * 0.5f;

            // The real information stays in place: only the decorative screen shutters open.
            // A brief black display and a collapsing/expanding beam read as hardware startup,
            // rather than as a color fade of the entire interface.
            Color blackout = new Color(0.004f, 0.004f, 0.004f,
                _strength * (1f - Mathf.SmoothStep(0.61f, 0.86f, p)));
            Quad(mesh, new Rect(rect.xMin, rect.yMin, rect.width, lower - rect.yMin), blackout);
            Quad(mesh, new Rect(rect.xMin, upper, rect.width, rect.yMax - upper), blackout);

            float beamWidth = rect.width * Mathf.Lerp(0.08f, 1f, Mathf.SmoothStep(0f, 1f, p / 0.15f));
            float beamX = rect.center.x - beamWidth * 0.5f;
            float beamAlpha = _strength * (1f - Mathf.SmoothStep(0.25f, 0.78f, p));
            for (int i = 3; i >= 0; i--)
            {
                float height = 1f + i * 3f;
                Color glow = WithAlpha(_tint, beamAlpha * (i == 0 ? 0.92f : 0.075f));
                Quad(mesh, new Rect(beamX, lower - height * 0.5f, beamWidth, height), glow);
                if (openingHeight > height * 2f)
                    Quad(mesh, new Rect(beamX, upper - height * 0.5f, beamWidth, height), glow);
            }

            if (p < 0.12f) return;
            float noiseEnvelope = envelope * _strength;
            // Short bands change at a deliberately uneven cadence. No UnityEngine.Random calls,
            // textures or material instances are used, so startup cannot perturb game randomness.
            for (int i = 0; i < 18; i++)
            {
                float u = Hash(i * 13 + phase * 47);
                float v = Hash(i * 71 + phase * 19);
                float width = rect.width * (0.12f + 0.63f * Hash(i * 23 + phase * 5));
                float height = i % 4 == 0 ? 3f + Hash(i + phase) * 8f : 1f;
                bool dark = i % 3 == 0;
                tint = dark ? new Color(0f, 0f, 0f, noiseEnvelope * 0.75f) :
                    WithAlpha(_tint, noiseEnvelope * (i % 4 == 0 ? 0.42f : 0.18f));
                Quad(mesh, new Rect(rect.xMin + u * (rect.width - width),
                    rect.yMin + v * Mathf.Max(0f, rect.height - height), width, height), tint);
            }
            for (int i = 0; i < 180; i++)
            {
                float u = Hash(i * 31 + phase * 97);
                float v = Hash(i * 59 + phase * 43);
                float width = 1f + 6f * Hash(i * 7 + phase * 3);
                float height = i % 7 == 0 ? 2f : 1f;
                tint = WithAlpha(_tint, noiseEnvelope * (0.12f + 0.34f * Hash(i * 17 + phase)));
                Quad(mesh, new Rect(rect.xMin + u * Mathf.Max(0f, rect.width - width),
                    rect.yMin + v * Mathf.Max(0f, rect.height - height), width, height), tint);
            }
        }

        private static Color WithAlpha(Color value, float alpha)
        {
            value.a = alpha;
            return value;
        }

        private static float Hash(int seed)
        {
            unchecked
            {
                uint bits = (uint)(seed + 1) * 747796405u + 2891336453u;
                bits = ((bits >> (int)((bits >> 28) + 4)) ^ bits) * 277803737u;
                bits = (bits >> 22) ^ bits;
                return (bits & 0x00ffffffu) / 16777215f;
            }
        }

        private static void Quad(VertexHelper mesh, Rect r, Color tint)
        {
            if (r.width <= 0f || r.height <= 0f || tint.a <= 0f) return;
            int i = mesh.currentVertCount;
            mesh.AddVert(new Vector3(r.xMin, r.yMin), tint, Vector2.zero);
            mesh.AddVert(new Vector3(r.xMin, r.yMax), tint, Vector2.zero);
            mesh.AddVert(new Vector3(r.xMax, r.yMax), tint, Vector2.zero);
            mesh.AddVert(new Vector3(r.xMax, r.yMin), tint, Vector2.zero);
            mesh.AddTriangle(i, i + 1, i + 2);
            mesh.AddTriangle(i, i + 2, i + 3);
        }
    }
}
