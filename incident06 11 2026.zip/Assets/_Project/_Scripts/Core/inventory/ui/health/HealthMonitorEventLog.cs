using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace K_Incident.Core.Inventory
{
    /// <summary>Bounded observation history with an independent, saved elapsed clock.</summary>
    public sealed class HealthMonitorEventLog
    {
        private const int PayloadMarker = 0x314C4A48; // HJL1
        private const int Capacity = 60;
        private const int MaximumMessageLength = 512;
        private const int MaximumMessageBytes = MaximumMessageLength * 4;
        private const double MaximumTime = 315576000d;
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);
        private readonly Dictionary<HealthGadgetKind, string> _previous = new Dictionary<HealthGadgetKind, string>();
        private readonly Dictionary<HealthGadgetKind, string> _current = new Dictionary<HealthGadgetKind, string>();
        private readonly List<Entry> _entries = new List<Entry>(Capacity);
        private bool _baseline, _dead;
        private double _elapsedSeconds;
        private sealed class Entry
        {
            public double Seconds;
            public string Message;
        }
        private sealed class State
        {
            public double Seconds;
            public readonly List<Entry> Entries = new List<Entry>(Capacity);
        }

        public int EntryCount => _entries.Count;
        public double ElapsedSeconds => _elapsedSeconds;
        public bool Tick(float deltaTime)
        {
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime <= 0f || _elapsedSeconds >= MaximumTime) return false;
            _elapsedSeconds = Math.Min(MaximumTime, _elapsedSeconds + deltaTime);
            return true;
        }
        public void RecordTreatment(double seconds, string message) => Add(seconds, message);
        public void Observe(IReadOnlyList<HealthGadgetEntry> effects, double seconds, bool dead = false)
        {
            FillCurrent(effects);
            if (!_baseline)
            {
                if (effects.Count == 0) Add(seconds, "Осмотр: отклонений не обнаружено.");
                else foreach (var entry in effects) Add(seconds, "Первичный осмотр: " + entry.Title + ".");
                _baseline = true;
            }
            else
            {
                foreach (var pair in _current)
                {
                    string title = K_HealthGadgetContent.GetTitle(pair.Key);
                    if (!_previous.ContainsKey(pair.Key))
                        Add(seconds, pair.Key == HealthGadgetKind.InternalBleeding ? "Обнаружено внутреннее кровотечение." : "Выявлено: " + title + ".");
                    else if (_previous[pair.Key] != pair.Value)
                        Add(seconds, "Изменение: " + title + " — " + CurrentValue(effects, pair.Key) + ".");
                }
                foreach (var pair in _previous)
                    if (!_current.ContainsKey(pair.Key)) Add(seconds, "Больше не наблюдается: " + K_HealthGadgetContent.GetTitle(pair.Key) + ".");
                if (dead && !_dead) Add(seconds, "Пульс отсутствует.");
            }
            CopyBaseline(dead);
        }
        public void Rebase(IReadOnlyList<HealthGadgetEntry> effects, bool dead)
        {
            FillCurrent(effects);
            _baseline = true;
            CopyBaseline(dead);
        }
        private void FillCurrent(IReadOnlyList<HealthGadgetEntry> effects)
        {
            _current.Clear();
            foreach (var entry in effects) _current[entry.Kind] = TracksValue(entry.Kind) ? entry.Summary : string.Empty;
        }
        private void CopyBaseline(bool dead)
        {
            _previous.Clear();
            foreach (var pair in _current) _previous.Add(pair.Key, pair.Value);
            _dead = dead;
        }
        private void Add(double seconds, string message)
        {
            if (!ValidTime(seconds) || !ValidMessage(message)) return;
            _elapsedSeconds = Math.Max(_elapsedSeconds, seconds);
            if (_entries.Count == Capacity) _entries.RemoveAt(0);
            _entries.Add(new Entry { Seconds = _elapsedSeconds, Message = message });
        }
        private static bool TracksValue(HealthGadgetKind kind) => kind == HealthGadgetKind.Bleeding || kind == HealthGadgetKind.Fracture ||
            kind == HealthGadgetKind.Gunshot || kind == HealthGadgetKind.Laceration || kind == HealthGadgetKind.InternalBleeding;
        private static string CurrentValue(IReadOnlyList<HealthGadgetEntry> effects, HealthGadgetKind kind)
        { foreach (var entry in effects) if (entry.Kind == kind) return entry.Value; return string.Empty; }

        public string BuildText()
        {
            var text = new StringBuilder("<b>Журнал состояний</b>\n\n");
            for (int i = _entries.Count - 1; i >= 0; i--)
            {
                long seconds = (long)_entries[i].Seconds;
                text.Append((seconds / 3600).ToString("00")).Append(':')
                    .Append((seconds / 60 % 60).ToString("00")).Append(':')
                    .Append((seconds % 60).ToString("00")).Append("  ").Append(_entries[i].Message).Append('\n');
            }
            if (_entries.Count == 0) text.Append("Записей пока нет.");
            return text.ToString();
        }
        public void Save(BinaryWriter writer)
        {
            writer.Write(PayloadMarker);
            writer.Write(_elapsedSeconds);
            writer.Write(_entries.Count);
            foreach (var entry in _entries)
            {
                writer.Write(entry.Seconds);
                byte[] bytes = StrictUtf8.GetBytes(entry.Message);
                writer.Write(bytes.Length);
                writer.Write(bytes);
            }
        }
        public void Load(BinaryReader reader)
        {
            State state = ReadState(reader);
            Reset();
            _elapsedSeconds = state.Seconds;
            _entries.AddRange(state.Entries);
        }
        public void ValidateLoad(BinaryReader reader) => ReadState(reader);
        public void Reset()
        {
            _entries.Clear(); _previous.Clear(); _current.Clear();
            _elapsedSeconds = 0d; _baseline = _dead = false;
        }
        private static State ReadState(BinaryReader reader)
        {
            if (reader.ReadInt32() != PayloadMarker) throw new InvalidDataException("Invalid health journal marker.");
            var state = new State { Seconds = reader.ReadDouble() };
            if (!ValidTime(state.Seconds)) throw new InvalidDataException("Invalid health journal clock.");
            int count = reader.ReadInt32();
            if (count < 0 || count > Capacity) throw new InvalidDataException("Invalid health journal count.");
            double previous = 0d;
            for (int i = 0; i < count; i++)
            {
                double seconds = reader.ReadDouble();
                if (!ValidTime(seconds) || seconds < previous || seconds > state.Seconds)
                    throw new InvalidDataException("Invalid health journal timestamp.");
                int length = reader.ReadInt32();
                if (length <= 0 || length > MaximumMessageBytes) throw new InvalidDataException("Invalid health journal message length.");
                byte[] bytes = reader.ReadBytes(length);
                if (bytes.Length != length) throw new EndOfStreamException("Truncated health journal message.");
                string message = StrictUtf8.GetString(bytes);
                if (!ValidMessage(message)) throw new InvalidDataException("Invalid health journal message.");
                state.Entries.Add(new Entry { Seconds = seconds, Message = message });
                previous = seconds;
            }
            if (reader.BaseStream.Position != reader.BaseStream.Length) throw new InvalidDataException("Unexpected health journal payload bytes.");
            return state;
        }
        private static bool ValidTime(double value) => !double.IsNaN(value) && !double.IsInfinity(value) && value >= 0d && value <= MaximumTime;
        private static bool ValidMessage(string text)
        {
            if (string.IsNullOrWhiteSpace(text) || text.Length > MaximumMessageLength) return false;
            foreach (char c in text) if (char.IsControl(c) || c == '<' || c == '>') return false;
            return true;
        }
    }
}
