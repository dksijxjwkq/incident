using System;
using System.Collections.Generic;
using System.Text;

namespace K_Incident.Core.Inventory
{
    /// <summary>Read-only plan. Inventory ownership and admission remain with the existing medical service.</summary>
    public static class K_HealthTreatmentPlan
    {
        private static readonly string[] Parts = { "Голова", "Грудь", "Живот", "Таз", "Левое плечо", "Правое плечо", "Левый бицепс", "Правый бицепс", "Левое предплечье", "Правое предплечье", "Левая кисть", "Правая кисть", "Левое бедро", "Правое бедро", "Левое колено", "Правое колено", "Левая голень", "Правая голень", "Левая стопа", "Правая стопа" };

        public static string Build(IReadOnlyList<HealthGadgetEntry> effects, IReadOnlyList<HealthGadgetEntry> indicators,
            K_HealthSystem health, K_InventoryUI inventory, bool preview)
        {
            var text = new StringBuilder();

            if (!preview && health != null && health.IsDead) return "Пульс отсутствует. Лечение невозможно.";
            var service = inventory != null ? inventory.MedicalApplyService : null;
            var liveRecords = inventory?.MedicalInventoryService?.GetMedicalItems();
            // Admission may rebuild the shared inventory cache; enumerate a stable snapshot.
            var records = liveRecords != null ? new List<MedicalItemRecord>(liveRecords) : null;
            bool inventoryKnown = service != null && records != null;
            if (!inventoryKnown) text.Append("<b>Не удалось проверить медикаменты.</b>\nНаличие средств пока неизвестно.\n\n");
            else text.Append("Подходящие средства и запас при себе.\n\n");
            var problems = new List<HealthGadgetKind>();
            foreach (var entry in effects) if (Candidates(entry.Kind).Length > 0 && entry.Kind != HealthGadgetKind.HealBoost) problems.Add(entry.Kind);
            foreach (var e in indicators) if (e.Kind == HealthGadgetKind.Blood && e.NormalizedValue < 1f) problems.Insert(0, e.Kind);
            if (!preview && health != null)
                for (int i=0;i<20;i++) if (health.GetHP((BodyPart)i) < health.GetEffectiveMaxHP((BodyPart)i)) { problems.Add(HealthGadgetKind.HealBoost); break; }
            problems.Sort((a,b)=>Priority(a).CompareTo(Priority(b)));
            bool listed = false;
            foreach (var problem in problems)
            {
                text.Append("<b>").Append(problem == HealthGadgetKind.HealBoost ? "Раневой уход — при необходимости" : K_HealthGadgetContent.GetTitle(problem)).Append("</b>\n");
                int choices = 0, readyChoices = 0;
                foreach (string id in Candidates(problem))
                {
                    var targets = new List<BodyPart>();
                    if (!preview && service != null)
                        foreach (var part in service.GetValidPartsForItem(id)) if (ForProblem(problem, part, id, health)) targets.Add(part);
                    if (!preview && service != null && targets.Count == 0) continue;
                    choices++;
                    string name = service?.MedicalDatabase?.GetEntry(id)?.DisplayName ?? Name(id);
                    int owned = 0, ready = 0;
                    string refusal = null;
                    var usable = new HashSet<BodyPart>();
                    if (records != null)
                        foreach (var record in records)
                        {
                            if (record.Item?.Data == null || !string.Equals(record.Item.Data.ItemID, id, StringComparison.OrdinalIgnoreCase)) continue;
                            owned += Math.Max(0, record.Item.Quantity);
                            if (preview || service == null) continue;
                            bool itemReady = false;
                            foreach (var part in service.GetValidPartsForItem(record))
                                if (targets.Contains(part)) { usable.Add(part); itemReady = true; }
                            if (itemReady) ready++;
                            else if (targets.Count > 0 && refusal == null) refusal = service.GetCurrentAvailabilityReason(record, targets[0]);
                        }
                    text.Append("• ").Append(name).Append(": ");
                    if (!inventoryKnown) text.Append("наличие неизвестно");
                    else if (owned == 0) text.Append("<b>нет при себе</b>");
                    else if (preview) text.Append("есть: ").Append(owned).Append("; пригодность к применению не определена");
                    else if (ready == 0) text.Append("есть: ").Append(owned).Append("; <b>сейчас недоступно</b> — ").Append(refusal ?? "сейчас нет подходящего участка для лечения");
                    else
                    {
                        readyChoices++;
                        text.Append("<b>доступно сейчас</b>, есть: ").Append(ready);
                        if (!(service?.MedicalDatabase?.IsSystemic(id) ?? false))
                        {
                            text.Append(". Участки: ");
                            bool first = true;
                            for (int i=0;i<20;i++) if (usable.Contains((BodyPart)i)) { if (!first) text.Append(", "); text.Append(Parts[i]); first=false; }
                        }
                    }
                    text.Append(".\n");
                }
                if (choices == 0)
                    text.Append(problem == HealthGadgetKind.Laceration ? "Сейчас нет ран, которые можно обработать этими средствами.\n" : "Сейчас эти средства применить нельзя. Проверьте, не идёт ли уже лечение.\n");
                else if (inventoryKnown && !preview && readyChoices == 0) text.Append("<b>Ни одно из этих средств сейчас нельзя применить.</b>\n");
                if (problem == HealthGadgetKind.InternalBleeding)
                {
                    text.Append("Порядок помощи: Транексам сдерживает кровопотерю; подготовьте обнаруженный участок гемостатической губкой, затем обработайте хирургическим набором.\n");
                    text.Append("Гемостатическая губка — ").Append(Stock(records,"coagulant")).Append("; хирургический набор — ").Append(Stock(records,"surgery_kit")).Append(".\n");
                }
                if (problem == HealthGadgetKind.HealBoost) text.Append("Гидрогель подходит для мягких тканей обработанных конечностей. Для заживления нужны достаточные еда и вода.\n");
                text.Append('\n'); listed=true;
            }
            if (!listed) text.Append("Дополнительных назначений нет.\n\n");
            text.Append("<b>Дополнительно</b>\n");
            if (Has(effects,HealthGadgetKind.Coagulant) && health != null)
                for (int i = 0; i < 20; i++)
                    if (health.IsInternalBleedingRevealed((BodyPart)i) && health.IsSurgicalHemostatPrepared((BodyPart)i))
                    {
                        text.Append("• После подготовки участка гемостатической губкой примените хирургический набор к тому же участку.\n");
                        break;
                    }
            if (Has(effects,HealthGadgetKind.ColdIllness)) text.Append("• Простуда проходит со временем, в покое быстрее. Антибиотик от неё не нужен.\n");
            if (Has(effects,HealthGadgetKind.WoundInfection)) text.Append("• При инфекции обработайте повреждение и закройте рану. Для восстановления нужен действующий курс антибиотика.\n");
            if (Has(effects,HealthGadgetKind.AntibioticTreatment)) text.Append("• Курс антибиотика уже идёт. Проверьте, обработаны ли поражённые участки.\n");
            if (Has(effects,HealthGadgetKind.Txa)) text.Append("• Транексам действует. Лечите источник кровотечения, пока препарат сдерживает потерю крови.\n");
            if (Has(effects,HealthGadgetKind.Recovery)) text.Append("• После фиксации кости восстанавливаются в покое. Остаток времени указан во вкладке «Эффекты».\n");
            if (Has(effects,HealthGadgetKind.Tourniquet) || Has(effects,HealthGadgetKind.Jett))
            {
                text.Append("• Под жгутом можно обработать наружное кровотечение бинтом или гемостатической марлей до снятия. ПКМ по устройству в сетке медикаментов → «Снять». Без обработки кровотечение может вернуться.\n");
                text.Append("Средства для обработки: гемостатическая марля — ").Append(Stock(records,"hemostatic")).Append("; бинт — ").Append(Stock(records,"bandage")).Append(".\n");
            }
            foreach (var e in indicators)
            {
                if (e.Kind == HealthGadgetKind.Hunger && e.NormalizedValue < .25f) text.Append("• Поешьте: ПКМ по еде → «Съесть».\n");
                if (e.Kind == HealthGadgetKind.Thirst && e.NormalizedValue < .25f) text.Append("• Попейте: ПКМ по напитку → «Выпить».\n");
                if (e.Kind == HealthGadgetKind.Cold && e.NormalizedValue > 0f) text.Append("• Найдите более тёплое место.\n");
            }
            foreach (var e in effects)
                if (e.Kind == HealthGadgetKind.Shock || e.Kind == HealthGadgetKind.Fatigue || e.Kind == HealthGadgetKind.StimCooldown || e.Kind == HealthGadgetKind.Drunk || e.Kind == HealthGadgetKind.Hangover)
                    text.Append("• ").Append(e.Title).Append(": дождитесь конца таймера. Лекарства от этого эффекта нет.\n");
            if (Has(effects, HealthGadgetKind.Concussion) && (preview || health == null || !health.IsFractured(BodyPart.Head)))
                text.Append("• Сотрясение от удара проходит со временем. Парацетамол облегчает небольшую боль, но не убирает травму мозга.\n");
            text.Append("\nЛечение: ПКМ по средству в сетке медикаментов → «Применить» → нужный участок. Таблетки принимаются без выбора участка. При переливании выберите объём крови. Подробности — во вкладке «Эффекты».");
            return text.ToString();
        }

        private static bool ForProblem(HealthGadgetKind kind, BodyPart part, string id, K_HealthSystem health)
        {
            if (health == null) return false;
            if (kind == HealthGadgetKind.WoundInfection && id == "amoxiclav") return health.Illnesses != null && health.Illnesses.HasWoundInfection;
            if ((id == "painkiller" || id == "paracetamol") &&
                (kind == HealthGadgetKind.Concussion || kind == HealthGadgetKind.BreathingDifficulty)) return true;
            bool mechanical = id == "tourniquet" || id == "tourniquet_elastic" || id == "jett";
            if (kind == HealthGadgetKind.Bleeding && mechanical)
            { foreach(var p in health.GetMechanicalLimbChain(part)) if(health.GetTreatableBleedingLevel(p)>0)return true; return false; }
            switch(kind)
            {
                case HealthGadgetKind.Bleeding: return health.GetTreatableBleedingLevel(part)>0;
                case HealthGadgetKind.Laceration: return health.GetLacerationType(part)==LacerationType.Open || health.GetLacerationType(part)==LacerationType.Glued;
                case HealthGadgetKind.Fracture: return health.IsFractured(part) && !health.IsSplinted(part);
                case HealthGadgetKind.Gunshot: return health.IsGunshot(part);
                case HealthGadgetKind.Concussion: return part==BodyPart.Head && health.IsFractured(part);
                case HealthGadgetKind.Tbi: return part==BodyPart.Head;
                case HealthGadgetKind.BreathingDifficulty: return part==BodyPart.Chest;
                case HealthGadgetKind.Immobilized: return part==BodyPart.Pelvis;
                case HealthGadgetKind.InternalBleeding: return id == "transamacha" ? health.GetInternalBleedingRevealedCount() > 0 : health.IsInternalBleedingRevealed(part);
                default: return true;
            }
        }
        private static bool Has(IReadOnlyList<HealthGadgetEntry> entries,HealthGadgetKind kind)
        { foreach(var e in entries)if(e.Kind==kind)return true;return false; }
        private static string Stock(IReadOnlyList<MedicalItemRecord> records,string id)
        {
            if(records==null)return "наличие неизвестно";
            int count=0;foreach(var record in records)if(record.Item?.Data!=null && string.Equals(record.Item.Data.ItemID,id,StringComparison.OrdinalIgnoreCase))count+=Math.Max(0,record.Item.Quantity);
            return count>0 ? "при себе: "+count : "нет при себе";
        }
        private static int Priority(HealthGadgetKind kind)
            => kind==HealthGadgetKind.Bleeding ? 0 : kind==HealthGadgetKind.InternalBleeding ? 1 : kind==HealthGadgetKind.Blood ? 2 : kind==HealthGadgetKind.HealBoost ? 100 : (int)kind;
        private static string[] Candidates(HealthGadgetKind kind)
        {
            switch(kind)
            {
                case HealthGadgetKind.Bleeding:return new[]{"hemostatic","bandage","pressure_bandage","tourniquet","tourniquet_elastic","jett"};
                case HealthGadgetKind.Laceration:return new[]{"glue_medical","strips_wound","stapler_medical"};
                case HealthGadgetKind.Fracture:return new[]{"splint_wood","splint_sam","pelvic_binder","collar_neck"};
                case HealthGadgetKind.Gunshot:return new[]{"surgery_kit"};
                case HealthGadgetKind.Concussion:return new[]{"paracetamol","painkiller","collar_neck"};
                case HealthGadgetKind.Tbi:return new[]{"collar_neck"};
                case HealthGadgetKind.BreathingDifficulty:return new[]{"chest_seal","surgery_kit","painkiller","paracetamol"};
                case HealthGadgetKind.Immobilized:return new[]{"pelvic_binder"};
                case HealthGadgetKind.InternalBleeding:return new[]{"coagulant","surgery_kit","transamacha"};
                case HealthGadgetKind.Blood:return new[]{"transfusion"};
                case HealthGadgetKind.HealBoost:return new[]{"gel_heal"};
                case HealthGadgetKind.WoundInfection:return new[]{"amoxiclav"};
                default:return Array.Empty<string>();
            }
        }
        private static string Name(string id)
        {
            switch(id)
            {
                case "hemostatic":return "Гемостатическая марля";case "bandage":return "Бинт";case "tourniquet":return "Турникет CAT";
                case "jett":return "Компрессионный турникет";case "glue_medical":return "Медицинский клей";case "strips_wound":return "Шовные пластыри";
                case "stapler_medical":return "Медицинский степлер";case "splint_wood":return "Деревянная шина";case "splint_sam":return "Формуемая шина";
                case "collar_neck":return "Набор помощи при ЧМТ";case "surgery_kit":return "Хирургический набор";case "coagulant":return "Гемостатическая губка";
                case "transamacha":return "Транексам (TXA)";case "transfusion":return "Пакет донорской крови";case "gel_heal":return "Раневой гидрогель";
                case "paracetamol":return "Парацетамол";case "painkiller":return "Морфин — автоинъектор";case "tourniquet_elastic":return "Эластичный жгут";
                case "pressure_bandage":return "Давящий перевязочный пакет";case "chest_seal":return "Клапанная окклюзионная наклейка";
                case "pelvic_binder":return "Тазовый бандаж";case "amoxiclav":return "Амоксициллин/клавуланат";default:return id;
            }
        }
    }
}
