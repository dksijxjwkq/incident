
using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Этап 5: зеркало медикаментов во вкладке «Здоровье».
    /// Этап 6.1: публичный API для drag-сессии (события + IsDragging).
    /// Этап 6.2: подсветка drop-зон куклы здоровья во время drag.
    /// Этап 6.3.1: сессия применения медикамента после drop (без UI).
    /// Этап 6.4: применение эффектов медикамента через MedicalEffectApplier.
    ///
    /// Источник данных — K_InventoryUI.MedicalInventoryService (read-only).
    /// НЕ открывает рюкзаки, НЕ реализует drop-эффект/списание (6.4/6.5).
    /// </summary>
    public class K_MedicalMirrorPanel : MonoBehaviour
    {
        [Header("References")]
        [SerializeField, Tooltip("Корень инвентаря. Если null — ищется в родителях.")]
        private K_InventoryUI _inventoryUI;

        [SerializeField, Tooltip("Родитель для виджетов. На него будет навешан GridLayoutGroup.")]
        private Transform _contentContainer;

        [SerializeField, Tooltip("Резервный префаб ячейки, если у корня инвентаря не назначен SlotPrefab.")]
        private GameObject _itemWidgetPrefab;

        [Header("Header")]
        [SerializeField] private TextMeshProUGUI _headerText;
        [SerializeField] private string _headerLabel = "Сетка медикаментов";

        // Retain old scene references only to hide the former in-grid placeholder.
        [SerializeField, HideInInspector]
        private TextMeshProUGUI _emptyStateText;

        [Header("Grid Layout")]
        [SerializeField] private Vector2 _cellSize = new Vector2(48f, 48f);
        [SerializeField] private Vector2 _spacing = new Vector2(4f, 4f);
        [SerializeField] private int _paddingLeft = 4;
        [SerializeField] private int _paddingRight = 4;
        [SerializeField] private int _paddingTop = 4;
        [SerializeField] private int _paddingBottom = 4;
        [SerializeField, Min(1), Tooltip("Точное количество колонок; размер ячеек берётся из обычного инвентаря.")]
        private int _columns = 7;
        [SerializeField, Min(1), Tooltip("Количество видимых строк. Дополнительные медикаменты доступны прокруткой.")]
        private int _visibleRows = 7;
        [SerializeField] private TextAnchor _alignment = TextAnchor.UpperLeft;

        [Header("Drag Session (Этап 6.1)")]
        [SerializeField, Tooltip("Размер ghost'а drag-сессии (px). Ghost показывается 1:1 при LMB drag.")]
        private float _dragGhostSize = 64f;

        // ═══════════════════════════════════════════════════════════════
        //  ЭТАП 6.2: ПОДСВЕТКА DROP-ЗОН
        // ═══════════════════════════════════════════════════════════════
        // ═══════════════════════════════════════════════════════════════
        //  Stage 1: подсветка drop-зон теперь работает через
        //  K_InventoryHealthWidget (Image сегмента), без реестра слотов.
        // ═══════════════════════════════════════════════════════════════
        [Header("Drop Zone Highlight (Stage 1)")]
        [SerializeField, Tooltip("База данных медикаментов для проверки " +
            "IsApplicable(itemID, BodyPart) при подсветке и при apply. " +
            "Если null — подсветка/apply отключатся с однократным предупреждением.")]
        private MedicalDatabase _medicalDatabase;

        [SerializeField, Tooltip("Цвет Image сегмента, когда предмет применим (#FFFFFF).")]
        private Color _highlightValidColor = Color.white;

        [SerializeField, Tooltip("Цвет Image сегмента, когда предмет неприменим (#BC0404).")]
        private Color _highlightInvalidColor = new Color(188f / 255f, 4f / 255f, 4f / 255f, 1f);

        // ═══════════════════════════════════════════════════════════════
        //  ЭТАП 6.3.1: СЕССИЯ ПРИМЕНЕНИЯ
        // ═══════════════════════════════════════════════════════════════
        [Header("Apply Session (Этап 6.3.1)")]
        [SerializeField, Tooltip("Здоровье игрока. Для подписки на OnDamageTaken (отмена apply по урону). " +
            "Если null — отмена по урону отключена (однократный warning).")]
        private K_HealthSystem _healthSystem;

        // 6.4: дополнительные ссылки для MedicalEffectApplier.
        [SerializeField, Tooltip("Кровь игрока. Для BloodRestore. Null → эффект пропускается (warn).")]
        private K_BloodSystem _bloodSystem;

        [SerializeField, Tooltip("Витальность игрока. Для Stimulator. Null → эффект пропускается (warn).")]
        private K_VitalitySystem _vitalitySystem;

        [SerializeField, Tooltip("Дебафф-система. Для Painkiller. Null → эффект пропускается (warn).")]
        private K_DebuffSystem _debuffSystem;

        // ═══ Runtime ═══
        private GridLayoutGroup _layout;
        private readonly List<K_MedicalMirrorItem> _activeWidgets = new List<K_MedicalMirrorItem>(32);
        private readonly Stack<K_MedicalMirrorItem> _pool = new Stack<K_MedicalMirrorItem>(32);
        private readonly List<Image> _emptyCells = new List<Image>(32);
        private bool _slotPrefabWarned;
        private int _borderColumns = -1;
        private int _borderRows = -1;
        private Vector2 _borderPadding;
        private ScrollRect _medicalScroll;
        private RectTransform _medicalViewport;
        /// <summary>Visible medical grid bounds, including its authored offset inside the panel.</summary>
        public RectTransform ViewportRect => _medicalViewport != null ? _medicalViewport : transform as RectTransform;
        private Scrollbar _medicalScrollbar;
        private bool _pendingLayoutRefresh;
        private K_MedicalItemUseProgress _itemUseProgress;
        private bool _subscribed;
        private bool _initialized;
        // Stage 4: topology cache keeps charge ticks from resetting pooled widgets.
        private readonly List<AppliedMedicalRecord> _knownAppliedRecords = new List<AppliedMedicalRecord>(4);

        private K_MedicalMirrorDragController _dragController;

        // Этап 6.4: ленивый аппликатор эффектов.
       

        // Этап 6.2: throttle-параметры hit-test (hybrid distance + max-age).
        private const float HIT_TEST_MIN_DIST_SQ = 1f;    // 1 px²
        private const float HIT_TEST_MAX_AGE     = 0.1f;  // 100 ms

// 6.6: apply-сервис (тонкий драйвер — панель).
private K_MedicalApplyService _applyService;

public K_MedicalApplyService ApplyService
{
    get
    {
        if (_applyService == null)
            EnsureApplyService();
        return _applyService;
    }
}

    
        // Этап 6.2: состояние подсветки.
        private BodyPart? _currentHighlightPart;
        private bool _currentHighlightApplicable;
        private Vector2 _lastHitTestPos;
        private float _lastHitTestTime;
        private bool _hasLastHitTestPos;
              private bool _medicalDbWarned;

        // Stage 1: drop-цель — Image сегмента куклы в инвентаре.
        // Резолвится в Start (инвариант №9).
        private K_InventoryHealthWidget _healthWidget;

        // Этап 6.3.1: apply-сессия.
       

        /// <summary>Этап 5: клик по виджету (ЛКМ без drag).</summary>
        public event Action<MedicalItemRecord> OnItemClicked;

        /// <summary>Этап 6.1: старт drag-сессии (LMB + превышен порог).</summary>
        public event Action<MedicalItemRecord> OnDragStarted;

        /// <summary>Этап 6.1: обновление позиции ghost'а. Payload — screenPos (eventData.position).</summary>
        public event Action<MedicalItemRecord, Vector2> OnDragUpdated;

        /// <summary>Этап 6.1: завершение drag-сессии (нормальное или отменённое).</summary>
        public event Action<MedicalItemRecord> OnDragCancelled;

        /// <summary>Этап 6.3.1: старт сессии применения.</summary>
        public event Action<MedicalItemRecord, BodyPart> OnApplyStarted;

        /// <summary>Этап 6.3.1: прогресс применения, раз в кадр. progress ∈ [0..1].</summary>
        public event Action<MedicalItemRecord, float> OnApplyProgress;

        /// <summary>Этап 6.3.1: применение успешно завершено (без списания и эффекта).</summary>
        public event Action<MedicalItemRecord, BodyPart> OnApplyCompleted;

        /// <summary>Этап 6.3.1: применение отменено. Причина — в reason, здесь не передаётся (для UI 6.3.2).</summary>
        public event Action<MedicalItemRecord, BodyPart> OnApplyCancelled;

        /// <summary>Этап 6.1: true пока идёт drag-сессия.</summary>
        public bool IsDragging => _dragController != null && _dragController.IsDragging;

        /// <summary>Этап 6.3.1: true пока идёт сессия применения.</summary>
       /// <summary>Этап 6.3.1: true пока идёт сессия применения.</summary>
public bool IsApplying => _applyService != null && _applyService.IsApplying;

/// <summary>
/// Этап 6.3.1: сегмент, на который сейчас идёт apply.
/// Валиден только при IsApplying == true (иначе — default).
/// </summary>
public BodyPart AppliedPart => _applyService != null ? _applyService.AppliedPart : default;

        /// <summary>
        /// Stage 1 (временный прокси): переадресация в K_MedicalApplyService.
        /// Нужен, пока K_DropZoneSlot.cs не удалён (UI-итерация).
        /// После удаления K_DropZone* — можно убрать.
        /// </summary>
        public void CancelApply(string reason)
        {
            _applyService?.CancelApply(reason);
        }
        /// <summary>Активные (не в пуле) виджеты. Read-only для UI-валидации.</summary>
        public IReadOnlyList<K_MedicalMirrorItem> ActiveWidgets => _activeWidgets;

        public K_InventoryUI InventoryUI => _inventoryUI;
        public K_HealthSystem HealthSystem => _healthSystem;
        // ═══════════════════════════════════════════════════════════════
//  ЭТАП 6.3.2: ВИЗУАЛ APPLY
// ═══════════════════════════════════════════════════════════════
[Header("Apply Visual (Этап 6.3.2)")]
[SerializeField, Tooltip("Цвет слота, когда он locked (идёт apply или hover на locked). " +
    "Дефолт — #9F9F9F alpha 60.")]
private Color _highlightLockedColor = new Color(159f / 255f, 159f / 255f, 159f / 255f, 60f / 255f);

[SerializeField, Tooltip("Цвет прогресс-бара применения.")]
private Color _applyProgressColor = new Color(0.25f, 0.85f, 0.25f, 1f);

[SerializeField, Tooltip("Спрайт прогресс-бара (опционально). Для radial рекомендуется ring-спрайт.")]
private Sprite _applyProgressSprite;

[SerializeField, Tooltip("Метод заливки. Radial360 — круговой, Horizontal — линейный.")]
private Image.FillMethod _applyProgressFillMethod = Image.FillMethod.Radial360;

[SerializeField, Tooltip("Точка старта заливки (int). Для Radial360: 0=Bottom, 1=Right, 2=Top, 3=Left. " +
    "Для Horizontal: 0=Left, 1=Right.")]
private int _applyProgressFillOrigin = 2;

[SerializeField, Tooltip("Направление заливки по часовой стрелке.")]
private bool _applyProgressClockwise = true;

[SerializeField, Range(0f, 1f), Tooltip("Прозрачность призрачной иконки медикамента.")]
private float _ghostIconAlpha = 0.5f;

[SerializeField, Tooltip("Отступ призрачной иконки от краёв слота (px).")]
private float _ghostIconPadding = 4f;

// Этап 6.3.2: кеш locked-состояния последнего подсвеченного слота.
private bool _currentHighlightLocked;

        // ═══════════════════════════════════════════════════════════════
        //  Публичный API
        // ═══════════════════════════════════════════════════════════════
        public void Refresh()
        {
            if (!_initialized) return;
            if (_inventoryUI == null) { ClearAll(); UpdateGridVisuals(); return; }

            var service = _inventoryUI.MedicalInventoryService;
            var records = service != null ? service.GetMedicalItems() : null;
            Rebuild(records);
        }

        /// <summary>Stage 4: grid/container drag uses the same immediate apply path.</summary>
        public bool TryApplyInventoryItem(
            InventoryItem item, InventoryController source, Vector2 screenPosition)
        {
            ClearDropZoneHighlights();
            if (item?.Data == null || _healthWidget == null || IsApplying) return false;
            if (!K_AppliedMedicalManager.TryGetKind(
                _medicalDatabase ?? MedicalDatabase.Instance, item.Data.ItemID, out var kind)) return false;
            if (!_healthWidget.TryGetPartAtScreenPoint(screenPosition, out var parent)) return false;
            if (_healthWidget.IsSegmentLocked(parent)) return false;
            bool applied = K_AppliedMedicalInventoryBridge.TryApply(
                _inventoryUI, _healthSystem, item, source, parent, kind, out var reason);
            if (!applied) Debug.LogWarning($"[K_MedicalMirrorPanel] {reason}");
            return applied;
        }

        /// <summary>Stage 4: only currently valid limb parents are highlighted.</summary>
        public void HighlightInventoryItem(InventoryItem item, Vector2 screenPosition)
        {
            ClearDropZoneHighlights();
            if (item?.Data == null || _healthWidget == null) return;
            var manager = _healthSystem?.AppliedMedical;
            if (manager == null || !K_AppliedMedicalManager.TryGetKind(
                _medicalDatabase ?? MedicalDatabase.Instance, item.Data.ItemID, out var kind)) return;
            var parents = new[] { BodyPart.LeftShoulder, BodyPart.RightShoulder,
                BodyPart.LeftQuadriceps, BodyPart.RightQuadriceps };
            foreach (var parent in parents)
                if (!_healthWidget.IsSegmentLocked(parent) &&
                    manager.CanApply(item, parent, kind, out _))
                    _healthWidget.SetSegmentColor(parent, _highlightValidColor);
        }

        public void ClearInventoryItemHighlight() => ClearDropZoneHighlights();

        // ═══════════════════════════════════════════════════════════════
        //  Unity Lifecycle
        // ═══════════════════════════════════════════════════════════════
        private void Awake()
        {
            if (_inventoryUI == null)
                _inventoryUI = GetComponentInParent<K_InventoryUI>();

            if (_inventoryUI == null)
            {
                Debug.LogError("[K_MedicalMirrorPanel] K_InventoryUI not found. Panel disabled.");
                enabled = false;
                return;
            }
            if (_contentContainer == null)
            {
                Debug.LogError("[K_MedicalMirrorPanel] _contentContainer is not assigned. Panel disabled.");
                enabled = false;
                return;
            }

            EnsureLayout();
            UpdateGridVisuals();
            // Stage 4: Refresh must be enabled after the layout is ready.
            _initialized = true;
            // Stage 1: реестр удалён. Резолв виджета — в Start.
        }
        /// <summary>
        /// Stage 1: резолв виджета куклы и бинд DragOut-компонентов.
        /// Инвариант №9: FindFirstObjectByType — только в Start.
        /// </summary>
        private void Start()
        {
            // Stage 4: all scene-wide lookups stay in Start.
            _healthWidget = FindFirstObjectByType<K_InventoryHealthWidget>(FindObjectsInactive.Include);
            if (_healthSystem == null) _healthSystem = FindFirstObjectByType<K_HealthSystem>();
            if (_applyService != null && _applyService.HealthSystem != _healthSystem)
            {
                _applyService.Dispose();
                _applyService.OnApplyStarted -= HandleServiceApplyStarted;
                _applyService.OnApplyProgress -= HandleServiceApplyProgress;
                _applyService.OnApplyCompleted -= HandleServiceApplyCompleted;
                _applyService.OnApplyCancelled -= HandleServiceApplyCancelled;
                _applyService = null;
            }
            EnsureApplyService();
            K_AppliedMedicalInventoryBridge.Initialize(_inventoryUI, _healthSystem);
            Unsubscribe();
            Subscribe();

            if (_healthWidget != null)
            {
                _healthWidget.EnsureDragOutComponents();
                _healthWidget.ConfigureDragOuts(
                    this,
                    _applyProgressColor, _applyProgressSprite,
                    _applyProgressFillMethod, _applyProgressFillOrigin,
                    _applyProgressClockwise, _ghostIconAlpha, _ghostIconPadding);
            }
            else
            {
                Debug.LogWarning("[K_MedicalMirrorPanel] K_InventoryHealthWidget not found — " +
                                 "drop-zone highlight and apply-visual are disabled.");
            }
            Refresh();
            RestoreApplyVisualIfRunning();
        }
       private void OnEnable()
{
    EnsureApplyService();
    Subscribe();
    // 6.6: _applyService.Subscribe() живёт в EnsureApplyService — не здесь.
    Refresh();

    // 6.6 (доработка 2): восстановление визуала apply при возврате на вкладку.
    RestoreApplyVisualIfRunning();
}
private void OnDisable()
{
    CancelActiveDragInternal();
    // 6.6: apply-сессия НЕ отменяется при выключении панели.
    // 6.6: _applyService.Unsubscribe() живёт в Dispose — не здесь.
    Unsubscribe();
}
        private void LateUpdate()
        {
            if (!_pendingLayoutRefresh || !_initialized) return;
            UpdateGridVisuals();
        }
        private void OnDestroy()
        {
            _itemUseProgress?.Disconnect(_applyService);
            if (_applyService != null)
            {
                _applyService.Dispose();

                _applyService.OnApplyStarted   -= HandleServiceApplyStarted;
                _applyService.OnApplyProgress  -= HandleServiceApplyProgress;
                _applyService.OnApplyCompleted -= HandleServiceApplyCompleted;
                _applyService.OnApplyCancelled -= HandleServiceApplyCancelled;

                _applyService = null;
            }

            ClearDropZoneHighlights();

            if (_dragController != null)
            {
                _dragController.Dispose();
                _dragController = null;
            }
            Unsubscribe();
        }

        // ═══════════════════════════════════════════════════════════════
        //  Этап 6.3.1: TICK ПРОГРЕССА
        // ═══════════════════════════════════════════════════════════════
   
        private void Subscribe()
        {
            if (_subscribed) return;
            if (_inventoryUI != null)
                _inventoryUI.OnInventoryRefreshed += Refresh;
            if (_healthSystem != null)
                _healthSystem.OnHealthChanged += HandleAppliedHealthChanged;
            _subscribed = true;
        }

        private void Unsubscribe()
        {
            if (!_subscribed) return;
            if (_inventoryUI != null)
                _inventoryUI.OnInventoryRefreshed -= Refresh;
            if (_healthSystem != null)
                _healthSystem.OnHealthChanged -= HandleAppliedHealthChanged;
            _subscribed = false;
        }

        private void HandleAppliedHealthChanged()
        {
            var applied = _healthSystem?.AppliedMedical?.Records;
            int count = applied != null ? applied.Count : 0;
            bool changed = count != _knownAppliedRecords.Count;
            if (!changed)
                for (int i = 0; i < count; i++)
                    if (!ReferenceEquals(applied[i], _knownAppliedRecords[i]))
                    {
                        changed = true;
                        break;
                    }
            if (changed)
            {
                // Stage 4: a mechanical item was applied, removed or expired.
                Refresh();
                return;
            }
            foreach (var widget in _activeWidgets)
                if (widget != null) widget.RefreshAppliedState();
        }

       

        // ═══════════════════════════════════════════════════════════════
        //  Layout / Header / Empty state
        // ═══════════════════════════════════════════════════════════════
        private void EnsureLayout()
        {
            if (_inventoryUI != null)
            {
                _cellSize = Vector2.one * _inventoryUI.SlotSize;
                _spacing = Vector2.one * _inventoryUI.SlotSpacing;
            }
            _cellSize = new Vector2(Mathf.Max(1f, _cellSize.x), Mathf.Max(1f, _cellSize.y));
            _spacing = new Vector2(Mathf.Max(0f, _spacing.x), Mathf.Max(0f, _spacing.y));
            _columns = Mathf.Max(1, _columns);
            _visibleRows = Mathf.Max(1, _visibleRows);
            _layout = _contentContainer.GetComponent<GridLayoutGroup>();
            if (_layout == null)
                _layout = _contentContainer.gameObject.AddComponent<GridLayoutGroup>();

            _layout.cellSize = _cellSize;
            _layout.spacing = _spacing;
            _layout.padding = new RectOffset(_paddingLeft, _paddingRight, _paddingTop, _paddingBottom);
            _layout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            _layout.constraintCount = Mathf.Max(1, _columns);
            _layout.childAlignment = _alignment;
            _layout.startCorner = GridLayoutGroup.Corner.UpperLeft;
            _layout.startAxis = GridLayoutGroup.Axis.Horizontal;
        }

        private void UpdateGridVisuals()
        {
            if (!(_contentContainer is RectTransform content)) return;
            EnsureLayout();
            EnsureScrollView(content);
            _pendingLayoutRefresh = false;

            // GridLayoutGroup positions children; it does not draw an empty grid.
            // Inspector dimensions own the viewport; item count only grows the scroll content.
            int columns = _columns;
            int visibleRows = _visibleRows;
            float width = _layout.padding.horizontal + columns * _cellSize.x + (columns - 1) * _spacing.x;
            float visibleHeight = _layout.padding.vertical + visibleRows * _cellSize.y + (visibleRows - 1) * _spacing.y;
            var hostRect = _medicalScroll.GetComponent<RectTransform>();
            hostRect.sizeDelta = new Vector2(width + 12f, visibleHeight);
            _medicalViewport.sizeDelta = new Vector2(width, visibleHeight);
            UpdateScrollbarGeometry();
            EnsureHeader();
            HideLegacyEmptyState();
            if (transform is RectTransform panelRect)
            {
                panelRect.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, width + 12f);
                panelRect.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, visibleHeight);
            }
            float oldOffset = content.anchoredPosition.y;
            content.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, width);

            _layout.constraintCount = columns;
            int occupiedRows = Mathf.CeilToInt(_activeWidgets.Count / (float)columns);
            int emptyCount = Mathf.Max(visibleRows, occupiedRows) * columns - _activeWidgets.Count;

            while (_emptyCells.Count < emptyCount)
            {
                var go = CreateSlotVisual("MedicalMirrorEmptyCell", false);
                if (go == null) break;
                var image = go.GetComponent<Image>();
                _emptyCells.Add(image);
            }

            // Pooled inactive cards are ignored by the layout. Live cards always precede empty cells.
            foreach (var widget in _activeWidgets)
                widget.transform.SetAsLastSibling();
            for (int i = 0; i < _emptyCells.Count; i++)
            {
                var cell = _emptyCells[i];
                cell.gameObject.SetActive(i < emptyCount);
                if (i < emptyCount) cell.transform.SetAsLastSibling();
            }
            int rows = Mathf.Max(visibleRows, occupiedRows);
            float contentHeight = Mathf.Max(visibleHeight,
                _layout.padding.vertical + rows * _cellSize.y + (rows - 1) * _spacing.y);
            content.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, contentHeight);
            content.anchoredPosition = new Vector2(0f, Mathf.Clamp(oldOffset, 0f, contentHeight - visibleHeight));
            _medicalScroll.StopMovement();
            _medicalScroll.scrollSensitivity = _cellSize.y + _spacing.y;
            bool overflow = contentHeight > visibleHeight + 0.1f;
            // uGUI also hides a Permanent scrollbar when its scroll axis is disabled.
            // Clamped bounds prevent movement when the content fits; keep the bar visible.
            _medicalScroll.vertical = true;
            _medicalScrollbar.gameObject.SetActive(true);
            _medicalScrollbar.interactable = overflow;
            var padding = new Vector2(_layout.padding.left, _layout.padding.top);
            // A content child scrolls out of sight. Keep the ordinary border beside the masked viewport.
            var oldContentBorder = content.Find("BottomBorderFix");
            if (oldContentBorder != null)
            {
                oldContentBorder.gameObject.SetActive(false);
                Destroy(oldContentBorder.gameObject);
            }
            if (_inventoryUI != null && (columns != _borderColumns || visibleRows != _borderRows ||
                padding != _borderPadding || hostRect.Find("BottomBorderFix") == null))
            {
                var oldBorder = hostRect.Find("BottomBorderFix");
                if (oldBorder != null)
                {
                    oldBorder.gameObject.SetActive(false);
                    oldBorder.SetParent(null, false);
                    Destroy(oldBorder.gameObject);
                }
                _inventoryUI.DrawGridBottomBorder(hostRect, columns, visibleRows, padding);
                _borderColumns = columns;
                _borderRows = visibleRows;
                _borderPadding = padding;
            }
            hostRect.Find("BottomBorderFix")?.SetAsLastSibling();
            LayoutRebuilder.MarkLayoutForRebuild(content);
        }

        private void EnsureScrollView(RectTransform content)
        {
            if (_medicalScroll != null) return;

            // Same UI components/settings as GroundLootPanelView, sized by the configured grid dimensions.
            const float barWidth = 12f;
            float width = _layout.padding.horizontal + _columns * _cellSize.x + (_columns - 1) * _spacing.x + barWidth;
            float height = _layout.padding.vertical + _visibleRows * _cellSize.y + (_visibleRows - 1) * _spacing.y;

            var host = new GameObject("MedicalMirrorScroll", typeof(RectTransform), typeof(Image), typeof(ScrollRect));
            var hostRect = host.GetComponent<RectTransform>();
            hostRect.SetParent(content.parent, false);
            hostRect.anchorMin = hostRect.anchorMax = new Vector2(0f, 1f);
            hostRect.pivot = new Vector2(0f, 1f);
            hostRect.anchoredPosition = content.anchoredPosition;
            hostRect.sizeDelta = new Vector2(width, height);
            host.GetComponent<Image>().color = Color.clear;

            var viewport = new GameObject("Viewport", typeof(RectTransform), typeof(RectMask2D));
            _medicalViewport = viewport.GetComponent<RectTransform>();
            _medicalViewport.SetParent(hostRect, false);
            _medicalViewport.anchorMin = _medicalViewport.anchorMax = new Vector2(0f, 1f);
            _medicalViewport.pivot = new Vector2(0f, 1f);
            _medicalViewport.sizeDelta = new Vector2(width - barWidth, height);
            content.SetParent(_medicalViewport, false);
            content.anchorMin = content.anchorMax = new Vector2(0f, 1f);
            content.pivot = new Vector2(0f, 1f);
            content.anchoredPosition = Vector2.zero;

            var bar = new GameObject("VerticalScrollbar", typeof(RectTransform), typeof(Image), typeof(Scrollbar));
            var barRect = bar.GetComponent<RectTransform>();
            barRect.SetParent(hostRect, false);
            var normalImage = _inventoryUI?.SlotPrefab?.GetComponent<Image>();
            Color color = normalImage != null ? normalImage.color : Color.white;
            bar.GetComponent<Image>().color = new Color(color.r, color.g, color.b, 0.2f);
            var handle = new GameObject("Handle", typeof(RectTransform), typeof(Image));
            var handleRect = handle.GetComponent<RectTransform>();
            handleRect.SetParent(barRect, false);
            handleRect.anchorMin = Vector2.zero;
            handleRect.anchorMax = Vector2.one;
            handleRect.offsetMin = handleRect.offsetMax = Vector2.zero;
            handle.GetComponent<Image>().color = color;
            _medicalScrollbar = bar.GetComponent<Scrollbar>();
            _medicalScrollbar.direction = Scrollbar.Direction.BottomToTop;
            _medicalScrollbar.handleRect = handleRect;
            _medicalScrollbar.targetGraphic = handle.GetComponent<Image>();

            _medicalScroll = host.GetComponent<ScrollRect>();
            _medicalScroll.viewport = _medicalViewport;
            _medicalScroll.content = content;
            _medicalScroll.horizontal = false;
            _medicalScroll.vertical = true;
            _medicalScroll.inertia = false;
            _medicalScroll.movementType = ScrollRect.MovementType.Clamped;
            _medicalScroll.verticalScrollbar = _medicalScrollbar;
            _medicalScroll.verticalScrollbarVisibility = ScrollRect.ScrollbarVisibility.Permanent;
            UpdateScrollbarGeometry();
        }

        private void UpdateScrollbarGeometry()
        {
            // Match the painted cells, excluding the viewport's outer padding.
            var barRect = _medicalScrollbar.GetComponent<RectTransform>();
            barRect.anchorMin = barRect.anchorMax = new Vector2(0f, 1f);
            barRect.pivot = new Vector2(0f, 1f);
            barRect.anchoredPosition = new Vector2(
                _layout.padding.left + InventoryUiGeometry.GridExtent(_columns, _cellSize.x, _spacing.x),
                -_layout.padding.top);
            barRect.sizeDelta = new Vector2(12f,
                InventoryUiGeometry.GridExtent(_visibleRows, _cellSize.y, _spacing.y));
        }

        private GameObject CreateSlotVisual(string name, bool interactive)
        {
            var prefab = _inventoryUI != null ? _inventoryUI.SlotPrefab : null;
            if (prefab == null) prefab = _itemWidgetPrefab;
            if (prefab == null || prefab.GetComponent<Image>() == null || prefab.GetComponent<RectTransform>() == null)
            {
                if (!_slotPrefabWarned)
                {
                    Debug.LogError("[K_MedicalMirrorPanel] Inventory SlotPrefab with Image/RectTransform is required for medical cells.");
                    _slotPrefabWarned = true;
                }
                return null;
            }
            var go = Instantiate(prefab, _contentContainer);
            go.name = name;
            go.transform.localScale = Vector3.one;
            go.GetComponent<RectTransform>().sizeDelta = _cellSize;
            // The clone supplies the existing cell artwork only, never a second inventory/drop binding.
            foreach (var slot in go.GetComponentsInChildren<K_InventorySlotUI>(true)) slot.enabled = false;
            foreach (var graphic in go.GetComponentsInChildren<Graphic>(true)) graphic.raycastTarget = false;
            go.GetComponent<Image>().raycastTarget = interactive;
            return go;
        }

        private void EnsureHeader()
        {
            if (_medicalScroll == null || _inventoryUI == null) return;
            _inventoryUI.GetContainerWindowHeaderStyle(out float height, out Color fill,
                out Color border, out float thickness);
            var host = _medicalScroll.GetComponent<RectTransform>();
            var header = host.Find("MedicalMirrorHeader") as RectTransform;
            if (header == null)
            {
                var go = new GameObject("MedicalMirrorHeader", typeof(RectTransform), typeof(Image));
                header = go.GetComponent<RectTransform>();
                header.SetParent(host, false);
            }

            // The header sits above the painted cells and stays outside the scrolling mask.
            header.anchorMin = header.anchorMax = new Vector2(0f, 1f);
            header.pivot = new Vector2(0f, 0f);
            header.anchoredPosition = new Vector2(_layout.padding.left, -_layout.padding.top);
            header.sizeDelta = new Vector2(
                InventoryUiGeometry.GridExtent(_columns, _cellSize.x, _spacing.x) + 12f,
                Mathf.Max(1f, height));
            header.localScale = Vector3.one;
            var background = header.GetComponent<Image>();
            background.sprite = null;
            background.type = Image.Type.Simple;
            background.color = fill;
            background.raycastTarget = false;

            if (_headerText == null)
            {
                var go = new GameObject("WindowTitle", typeof(RectTransform), typeof(TextMeshProUGUI));
                _headerText = go.GetComponent<TextMeshProUGUI>();
            }
            var titleRect = _headerText.GetComponent<RectTransform>();
            if (titleRect.parent != header) titleRect.SetParent(header, false);
            titleRect.anchorMin = Vector2.zero;
            titleRect.anchorMax = Vector2.one;
            titleRect.pivot = new Vector2(0.5f, 0.5f);
            titleRect.anchoredPosition = Vector2.zero;
            titleRect.sizeDelta = Vector2.zero;
            titleRect.offsetMin = new Vector2(8f, 0f);
            titleRect.offsetMax = new Vector2(-8f, 0f);
            titleRect.localScale = Vector3.one;
            // Existing scenes still serialize the former default label.
            if (string.IsNullOrWhiteSpace(_headerLabel) || _headerLabel == "Медикаменты")
                _headerLabel = "Сетка медикаментов";
            _headerText.text = _headerLabel;
            K_ContainerWindow.ApplyHeaderTitleStyle(_headerText);

            thickness = Mathf.Max(1f, thickness);
            K_ContainerWindow.EnsurePanelBorderStrip(header, "HeaderBottomLine",
                new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f),
                Vector2.zero, new Vector2(0f, thickness), border);
            K_ContainerWindow.EnsurePanelBorderStrip(header, "HeaderTopLine",
                new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0.5f, 1f),
                Vector2.zero, new Vector2(0f, thickness), border);
            K_ContainerWindow.EnsurePanelBorderStrip(header, "HeaderLeftLine",
                new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(0f, 0.5f),
                Vector2.zero, new Vector2(thickness, 0f), border);
            K_ContainerWindow.EnsurePanelBorderStrip(header, "HeaderRightLine",
                new Vector2(1f, 0f), new Vector2(1f, 1f), new Vector2(1f, 0.5f),
                Vector2.zero, new Vector2(thickness, 0f), border);
        }

        private void HideLegacyEmptyState()
        {
            if (_emptyStateText == null)
                _emptyStateText = _contentContainer.Find("EmptyStateText")?.GetComponent<TextMeshProUGUI>();
            if (_emptyStateText != null)
                _emptyStateText.gameObject.SetActive(false);
        }

        // ═══════════════════════════════════════════════════════════════
        //  Rebuild
        // ═══════════════════════════════════════════════════════════════
        private void Rebuild(IReadOnlyList<MedicalItemRecord> records)
        {
            ClearAll();
            var shownApplied = new HashSet<uint>();
            for (int i = 0; records != null && i < records.Count; i++)
            {
                var widget = AcquireWidget();
                if (widget == null) continue;

                widget.Setup(records[i], i, this);
                _activeWidgets.Add(widget);
                if (widget.IsApplied) shownApplied.Add(widget.AppliedRecord.InstanceID);
            }

            // Stage 4: shared grid, live records annotate their existing view;
            // container virtual records append once and never read loot containers.
            _knownAppliedRecords.Clear();
            var applied = _healthSystem?.AppliedMedical?.Records;
            if (applied != null)
                foreach (var record in applied)
                {
                    _knownAppliedRecords.Add(record);
                    if (shownApplied.Contains(record.InstanceID)) continue;
                    var widget = AcquireWidget();
                    if (widget == null) continue;
                    widget.SetupApplied(record, this);
                    _activeWidgets.Add(widget);
                }

            UpdateGridVisuals();
        }

        private void ClearAll()
        {
            for (int i = 0; i < _activeWidgets.Count; i++)
            {
                var w = _activeWidgets[i];
                if (w == null) continue;
                w.Reset();
                if (w.gameObject.activeSelf)
                    w.gameObject.SetActive(false);
                _pool.Push(w);
            }
            _activeWidgets.Clear();
        }

        private K_MedicalMirrorItem AcquireWidget()
        {
            K_MedicalMirrorItem widget = null;
            while (_pool.Count > 0 && widget == null)
                widget = _pool.Pop();

            if (widget != null)
            {
                // Stage 4: pooled UI keeps unit scale.
                widget.transform.localScale = Vector3.one;
                if (!widget.gameObject.activeSelf)
                    widget.gameObject.SetActive(true);
                return widget;
            }

            return CreateWidgetProgrammatically();
        }

        private K_MedicalMirrorItem CreateWidgetProgrammatically()
        {
            var go = CreateSlotVisual("MedicalMirrorItem", true);
            if (go == null) return null;

            var rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot     = new Vector2(0f, 1f);
            rt.sizeDelta = _cellSize;
            rt.localScale = Vector3.one;

            var iconGo = new GameObject("Icon", typeof(RectTransform), typeof(Image));
            iconGo.transform.SetParent(go.transform, false);
            var iconRT = iconGo.GetComponent<RectTransform>();
            iconRT.anchorMin = Vector2.zero;
            iconRT.anchorMax = Vector2.one;
            iconRT.offsetMin = new Vector2(2f, 2f);
            iconRT.offsetMax = new Vector2(-2f, -2f);
            iconRT.localScale = Vector3.one;
            var iconImg = iconGo.GetComponent<Image>();
            iconImg.raycastTarget = false;
            iconImg.preserveAspect = true;

            var qtyGo = new GameObject("Qty", typeof(RectTransform), typeof(TextMeshProUGUI));
            qtyGo.transform.SetParent(go.transform, false);
            var qtyRT = qtyGo.GetComponent<RectTransform>();
            qtyRT.anchorMin = new Vector2(1f, 0f);
            qtyRT.anchorMax = new Vector2(1f, 0f);
            qtyRT.pivot     = new Vector2(1f, 0f);
            qtyRT.anchoredPosition = new Vector2(-2f, 2f);
            qtyRT.sizeDelta = new Vector2(28f, 14f);
            qtyRT.localScale = Vector3.one;
            var qtyTmp = qtyGo.GetComponent<TextMeshProUGUI>();
            qtyTmp.alignment = TextAlignmentOptions.BottomRight;
            qtyTmp.fontSize = 11f;
            qtyTmp.fontStyle = FontStyles.Bold;
            qtyTmp.color = Color.white;
            qtyTmp.raycastTarget = false;
            qtyTmp.textWrappingMode = TextWrappingModes.NoWrap;
            qtyTmp.overflowMode = TextOverflowModes.Overflow;
            qtyTmp.outlineColor = new Color(0f, 0f, 0f, 0.85f);
            qtyTmp.outlineWidth = 0.2f;
            if (qtyTmp.font == null && TMP_Settings.defaultFontAsset != null)
                qtyTmp.font = TMP_Settings.defaultFontAsset;

            var widget = go.GetComponent<K_MedicalMirrorItem>() ?? go.AddComponent<K_MedicalMirrorItem>();
            widget.BindReferences(iconImg, qtyTmp);
            return widget;
        }

        // ═══════════════════════════════════════════════════════════════
        //  Click forwarding
        // ═══════════════════════════════════════════════════════════════
        internal void RaiseItemClicked(K_MedicalMirrorItem widget, MedicalItemRecord record)
        {
            OnItemClicked?.Invoke(record);
        }

        // ═══════════════════════════════════════════════════════════════
        //  Drag-сессия (Этап 6.1) + подсветка (Этап 6.2) + drop→apply (6.3.1)
        // ═══════════════════════════════════════════════════════════════
        internal void BeginItemDrag(
            K_MedicalMirrorItem widget, MedicalItemRecord record, PointerEventData eventData)
        {
            if (widget == null || record.Item == null || eventData == null) return;
            if (widget.IsApplied) return;

            EnsureDragController();
            if (_dragController == null) return;

            if (!_dragController.Begin(widget, record, eventData)) return;

            _currentHighlightPart = null;
            _currentHighlightApplicable = false;
            _hasLastHitTestPos = false;
            _lastHitTestTime = 0f;
            UpdateDropZoneHighlight(eventData.position);

            OnDragStarted?.Invoke(record);
        }

        internal void UpdateItemDrag(
            K_MedicalMirrorItem widget, MedicalItemRecord record, PointerEventData eventData)
        {
            if (_dragController == null || !_dragController.IsDragging) return;
            if (_dragController.SourceWidget != widget) return;
            if (eventData == null) return;

            _dragController.Update(eventData);
            OnDragUpdated?.Invoke(_dragController.Record, eventData.position);

            UpdateDropZoneHighlight(eventData.position);
        }

            internal void EndItemDrag(
            K_MedicalMirrorItem widget, MedicalItemRecord record, PointerEventData eventData)
        {
            if (_dragController == null || !_dragController.IsDragging) return;
            if (_dragController.SourceWidget != widget) return;

            var cached = _dragController.Record;

            _dragController.End();

            // Снять подсветку drag ДО старта apply, чтобы не сбить
            // locked-цвет, который установит SetApplyVisual.
            ClearDropZoneHighlights();

            bool startedApply = false;

            if (eventData != null
                && _healthWidget != null
                && _applyService != null)
            {
                if (_healthWidget.TryGetPartAtScreenPoint(eventData.position, out BodyPart part))
                {
                    var item = cached.Item;
                    bool mechanical = item?.Data != null &&
                        K_AppliedMedicalManager.TryGetKind(
                            _medicalDatabase ?? MedicalDatabase.Instance, item.Data.ItemID, out _);
                    if (item != null && item.Data != null
                        && (mechanical || (_medicalDatabase != null &&
                            _medicalDatabase.IsApplicable(item.Data.ItemID, part))))
                    {
                        startedApply = _applyService.TryStartApply(cached, part, widget);
                    }
                }
            }

            if (!startedApply)
                OnDragCancelled?.Invoke(cached);
        }
        /// <summary>
        /// Этап 6.1/6.2/6.3.1: виджет возвращается в пул (Reset вызывается из ClearAll).
        /// Если виджет — источник активного drag'а, drag отменяется.
        /// Apply-сессия принадлежит предмету и переживает пересоздание UI.
        /// </summary>
        internal void NotifyWidgetReset(K_MedicalMirrorItem widget)
        {
            // Drag-ветка.
            if (_dragController != null && _dragController.IsDragging
                && _dragController.SourceWidget == widget)
            {
                var cached = _dragController.Record;
                _dragController.End();
                OnDragCancelled?.Invoke(cached);
                ClearDropZoneHighlights();
            }

        }

        /// <summary>Отменяет активный drag. Идемпотентно. Всегда снимает подсветку.</summary>
        private void CancelActiveDragInternal()
        {
            if (_dragController != null && _dragController.IsDragging)
            {
                var cached = _dragController.Record;
                _dragController.End();
                OnDragCancelled?.Invoke(cached);
            }

            ClearDropZoneHighlights();
        }

        /// <summary>
        /// Ленивая инициализация drag-контроллера.
        /// Резолв root-canvas: приоритет — K_InventoryUI.RootCanvasTransform,
        /// fallback — GetComponentInParent<Canvas>() с подъёмом к корню.
        /// </summary>
        private void EnsureDragController()
        {
            if (_dragController != null) return;

            Transform canvasTr = null;
            UnityEngine.Camera canvasCam = null;

            if (_inventoryUI != null && _inventoryUI.RootCanvasTransform != null)
            {
                canvasTr = _inventoryUI.RootCanvasTransform;
                canvasCam = _inventoryUI.RootCanvasCamera;
            }
            else
            {
                var canvas = GetComponentInParent<Canvas>();
                if (canvas != null)
                {
                    var root = canvas;
                    while (root.transform.parent != null)
                    {
                        var up = root.transform.parent.GetComponent<Canvas>();
                        if (up == null) break;
                        root = up;
                    }
                    canvasTr = root.transform;
                    canvasCam = root.renderMode == RenderMode.ScreenSpaceCamera
                        ? root.worldCamera : null;
                }
            }

            if (canvasTr == null)
            {
                Debug.LogError("[K_MedicalMirrorPanel] Cannot resolve root canvas for drag ghost. Drag disabled.");
                return;
            }

            _dragController = new K_MedicalMirrorDragController(
                canvasTr, canvasCam, _dragGhostSize);
        }

        /// <summary>
        /// Этап 6.4: ленивая инициализация аппликатора эффектов.
        /// </summary>
      

        // ═══════════════════════════════════════════════════════════════
        //  Этап 6.2: Логика подсветки drop-зон
        // ═══════════════════════════════════════════════════════════════
            private void UpdateDropZoneHighlight(Vector2 screenPos)
        {
            if (_healthWidget == null) return;

            // Throttle: hybrid distance + max-age.
            if (_hasLastHitTestPos)
            {
                float age = Time.unscaledTime - _lastHitTestTime;
                if (age < HIT_TEST_MAX_AGE
                    && (screenPos - _lastHitTestPos).sqrMagnitude < HIT_TEST_MIN_DIST_SQ)
                    return;
            }
            _lastHitTestPos = screenPos;
            _lastHitTestTime = Time.unscaledTime;
            _hasLastHitTestPos = true;

            var record = _dragController != null ? _dragController.Record : default;
            var item = record.Item;
            if (item == null || item.Data == null)
            {
                ClearDropZoneHighlights();
                return;
            }

            if (K_AppliedMedicalManager.TryGetKind(
                _medicalDatabase ?? MedicalDatabase.Instance, item.Data.ItemID, out _))
            {
                HighlightInventoryItem(item, screenPos);
                return;
            }

            if (_medicalDatabase == null)
            {
                if (!_medicalDbWarned)
                {
                    _medicalDbWarned = true;
                    Debug.LogWarning("[K_MedicalMirrorPanel] MedicalDatabase is not assigned — " +
                                     "drop-zone highlight is disabled.");
                }
                return;
            }

            if (!_healthWidget.TryGetPartAtScreenPoint(screenPos, out BodyPart part))
            {
                ClearDropZoneHighlights();
                return;
            }

            bool applicable = _medicalDatabase.IsApplicable(item.Data.ItemID, part);
            bool isLocked = _healthWidget.IsSegmentLocked(part);

            // Три состояния — locked / valid / invalid.
            Color targetColor;
            if (isLocked)
                targetColor = _highlightLockedColor;
            else if (applicable)
                targetColor = _highlightValidColor;
            else
                targetColor = _highlightInvalidColor;

            if (_currentHighlightPart == part
                && _currentHighlightApplicable == applicable
                && _currentHighlightLocked == isLocked)
                return;

            _healthWidget.RestoreAllSegmentColors();
            _healthWidget.SetSegmentColor(part, targetColor);

            _currentHighlightPart = part;
            _currentHighlightApplicable = applicable;
            _currentHighlightLocked = isLocked;
        }
         private void ClearDropZoneHighlights()
        {
            if (_healthWidget != null)
                _healthWidget.RestoreAllSegmentColors();

            _currentHighlightPart = null;
            _currentHighlightApplicable = false;
            _currentHighlightLocked = false;
        }
        // ═══════════════════════════════════════════════════════════════
        //  ЭТАП 6.3.1: Сессия применения
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Попытка стартовать сессию применения. Возвращает false, если
        /// сессия уже идёт, данные невалидны, слот залочен или duration &lt;= 0.
        /// </summary>
   
        // ═══════════════════════════════════════════════════════════════
        //  Editor-time re-apply
        // ═══════════════════════════════════════════════════════════════
        private void OnValidate()
        {
            // Unity can call validation outside the normal UI lifecycle. Defer all object work.
            _columns = Mathf.Max(1, _columns);
            _visibleRows = Mathf.Max(1, _visibleRows);
            _pendingLayoutRefresh = true;
        }

        private void EnsureApplyService()
        {
            if (_applyService != null)
            {
                EnsureItemUseProgress();
                return;
            }
            if (_inventoryUI == null) _inventoryUI = GetComponentInParent<K_InventoryUI>();
            _applyService = new K_MedicalApplyService(
                _healthSystem, _bloodSystem, _vitalitySystem,
                _debuffSystem, _medicalDatabase, _inventoryUI);
            _applyService.OnApplyStarted += HandleServiceApplyStarted;
            _applyService.OnApplyProgress += HandleServiceApplyProgress;
            _applyService.OnApplyCompleted += HandleServiceApplyCompleted;
            _applyService.OnApplyCancelled += HandleServiceApplyCancelled;
            _applyService.Subscribe();
            EnsureItemUseProgress();
        }

        private void EnsureItemUseProgress()
        {
            if (_itemUseProgress == null)
            {
                var owner = _inventoryUI != null ? _inventoryUI.gameObject : gameObject;
                _itemUseProgress = owner.GetComponent<K_MedicalItemUseProgress>();
                if (_itemUseProgress == null) _itemUseProgress = owner.AddComponent<K_MedicalItemUseProgress>();
            }
            _itemUseProgress.Connect(_applyService, this, _inventoryUI);
            _healthSystem?.GetComponent<K_HealthMonitorHistory>()?.ConnectMedicalService(
                _applyService, _headerText != null ? _headerText.font : TMP_Settings.defaultFontAsset);
        }
/// <summary>
/// 6.6: при возврате панели в активное состояние (переключение на вкладку
/// «Здоровье» во время apply) — восстановить визуал БЕЗ форварда OnApplyStarted.
/// </summary>
        private void RestoreApplyVisualIfRunning()
        {
            if (_applyService == null || !_applyService.IsApplying) return;

            ShowSharedApplyVisual(_applyService.AppliedRecord, _applyService.AppliedPart, _applyService.Progress);

            // Stage 4: Start resolves the doll; no scene lookup during OnEnable.
            if (_healthWidget == null) return;

            var part = _applyService.AppliedPart;

            _healthWidget.SetSegmentLocked(part, true);


        }
        private void HandleServiceApplyStarted(MedicalItemRecord record, BodyPart part)
        {
            ShowSharedApplyVisual(record, part, 0f);
            if (_healthWidget != null)
            {
                _healthWidget.SetSegmentLocked(part, true);

            }
            OnApplyStarted?.Invoke(record, part);
        }

        private void HandleServiceApplyProgress(MedicalItemRecord record, float progress)
        {
            if (_applyService != null)
                ShowSharedApplyVisual(record, _applyService.AppliedPart, progress);

            OnApplyProgress?.Invoke(record, progress);
        }

        private void HandleServiceApplyCompleted(MedicalItemRecord record, BodyPart part)
        {
            HideSharedApplyVisual();
            if (_healthWidget != null)
            {
                _healthWidget.SetSegmentLocked(part, false);
                var drag = _healthWidget.GetDragOutComponent(part);
                drag?.ClearApplyVisual();
            }
            OnApplyCompleted?.Invoke(record, part);
        }

        private void HandleServiceApplyCancelled(MedicalItemRecord record, BodyPart part)
        {
            HideSharedApplyVisual();
            if (_healthWidget != null)
            {
                _healthWidget.SetSegmentLocked(part, false);
                var drag = _healthWidget.GetDragOutComponent(part);
                drag?.ClearApplyVisual();
            }
            OnApplyCancelled?.Invoke(record, part);
        }

        private void ShowSharedApplyVisual(MedicalItemRecord record, BodyPart part, float progress)
        {
            EnsureItemUseProgress();
            _itemUseProgress.RefreshNow();
        }

        private void HideSharedApplyVisual()
        {
            _itemUseProgress?.Clear();
        }
    }
}
