
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// ��������� �� K_InventoryUI (������ 7).
    /// �������� ������ �� ���������� � ������������ ����� �� ������.
    /// �� ��������� ��������, ������ ��� K_DraggablePanel � ��� ���������������
    /// BackpackContainerManager (������ 5).
    /// 
    /// ����������� ������������� ����� Initialize() � ������� FindFirstObjectByType.
    /// </summary>
    public sealed class InventoryGridBuilder
    {
        // ������������ (��������� �� K_InventoryUI)
        private readonly float _slotSize;
        private readonly float _slotSpacing;
        private readonly GameObject _slotPrefab;
        private readonly Color _gridBottomBorderColor;
        private readonly float _gridBottomBorderHeight;
        private readonly float _gridBottomBorderOffset;

        // ������ �� UI-�������� (���������� �� K_InventoryUI)
        private readonly K_InventoryUI _inventoryUI;

        private Vector2 _pocketsGridPadding = Vector2.zero;
        private Vector2 _pocket2GridPadding = Vector2.zero;
        private Vector2 _backpackGridPadding = Vector2.zero;
        private Vector2 _containerGridPadding = Vector2.zero;

        public InventoryGridBuilder(
            K_InventoryUI inventoryUI,
            float slotSize,
            float slotSpacing,
            GameObject slotPrefab,
            Color gridBottomBorderColor,
            float gridBottomBorderHeight,
            float gridBottomBorderOffset)
        {
            _inventoryUI = inventoryUI;
            _slotSize = slotSize;
            _slotSpacing = slotSpacing;
            _slotPrefab = slotPrefab;
            _gridBottomBorderColor = gridBottomBorderColor;
            _gridBottomBorderHeight = gridBottomBorderHeight;
            _gridBottomBorderOffset = gridBottomBorderOffset;
        }

        public Vector2 GetPaddingForGrid(GridType type) => type switch
        {
            GridType.Pockets => _pocketsGridPadding,
            GridType.Pocket2 => _pocket2GridPadding,
            GridType.Backpack => _backpackGridPadding,
            GridType.Container => _containerGridPadding,
            _ => Vector2.zero
        };

        /// <summary>
        /// ������ ��� ������� ����� ������ ��� ������.
        /// ������ �� �������� ����� � ������ ��� ���������� ����� RebuildBackpackGrid.
        /// </summary>
        public void BuildAllGrids(
            Transform pocketsGrid,
            Transform pocket2Grid,
            Transform backpackGrid,
            Transform pocketsItemsContainer,
            Transform pocket2ItemsContainer,
            Transform backpackItemsContainer,
            int pocketColumns,
            int pocketRows)
        {
            if (pocketsGrid == null) Debug.LogError("[GridBuilder] _pocketsGrid NOT assigned!");
            if (pocket2Grid == null) Debug.LogError("[GridBuilder] _pocket2Grid NOT assigned!");
            if (pocket2ItemsContainer == null) Debug.LogError("[GridBuilder] _pocket2ItemsContainer NOT assigned!");
            if (pocketsItemsContainer == null) Debug.LogError("[GridBuilder] _pocketsItemsContainer NOT assigned!");

            BuildGrid(pocketsGrid, pocketColumns * pocketRows, pocketColumns, GridType.Pockets);
            BuildGrid(pocket2Grid, pocketColumns * pocketRows, pocketColumns, GridType.Pocket2);

            ReparentItemsContainerIntoGrid(pocketsGrid, pocketsItemsContainer);
            ReparentItemsContainerIntoGrid(pocket2Grid, pocket2ItemsContainer);
            ReparentItemsContainerIntoGrid(backpackGrid, backpackItemsContainer);

            EnsureContainerAboveGrid(pocketsGrid, pocketsItemsContainer);
            EnsureContainerAboveGrid(pocket2Grid, pocket2ItemsContainer);
            EnsureContainerAboveGrid(backpackGrid, backpackItemsContainer);
        }

        /// <summary>
        /// ������ ���� �����: ������ �����, ����������� GridLayoutGroup,
        /// ��������� ������ gridRT � ������ ������ �������.
        /// </summary>
        public void BuildGrid(Transform parent, int slotCount, int columns, GridType gridType)
        {
            if (parent == null || _slotPrefab == null || columns <= 0 || slotCount < 0) return;

            var containerToPreserve = GetItemsContainer(gridType);
            if (containerToPreserve != null && containerToPreserve.parent == parent)
            {
                var le = containerToPreserve.GetComponent<LayoutElement>();
                if (le == null) le = containerToPreserve.gameObject.AddComponent<LayoutElement>();
                le.ignoreLayout = true;
                var graphic = containerToPreserve.GetComponent<Graphic>();
                if (graphic != null) graphic.raycastTarget = false;
            }

            ClearGrid(parent, containerToPreserve);
            SetupGridLayout(parent, columns);
            CacheGridLayoutPadding(parent, gridType);

            for (int i = 0; i < slotCount; i++)
            {
                var slot = Object.Instantiate(_slotPrefab, parent);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % columns;
                    int y = i / columns;
                    slotUI.Setup(x, y, gridType, _inventoryUI);
                }
            }

            // ����� ������ ����� ����
            var gridRT = parent.GetComponent<RectTransform>();
            var gridLayout = parent.GetComponent<GridLayoutGroup>();
            if (gridLayout != null && gridRT != null)
            {
                Vector3[] corners = new Vector3[4];
                gridRT.GetWorldCorners(corners);
                Vector3 savedWorldTopLeft = corners[1];
                int rows = InventoryUiGeometry.GridRows(slotCount, columns);
                float padLeft = gridLayout.padding.left;
                float padRight = gridLayout.padding.right;
                float padTop = gridLayout.padding.top;
                float padBot = gridLayout.padding.bottom;
                float w = padLeft + InventoryUiGeometry.GridExtent(columns, _slotSize, _slotSpacing) + padRight;
                float h = padTop + InventoryUiGeometry.GridExtent(rows, _slotSize, _slotSpacing) + padBot;
                gridRT.anchorMin = new Vector2(0f, 1f);
                gridRT.anchorMax = new Vector2(0f, 1f);
                gridRT.pivot = new Vector2(0f, 1f);
                gridRT.sizeDelta = new Vector2(w, h);

                if (gridRT.parent != null)
                {
                    Vector2 localTL = gridRT.parent.InverseTransformPoint(savedWorldTopLeft);
                    RectTransform pr = gridRT.parent as RectTransform;
                    if (pr != null) localTL -= new Vector2(pr.rect.xMin, pr.rect.yMax);
                    gridRT.anchoredPosition = localTL;
                }
            }
            LayoutRebuilder.ForceRebuildLayoutImmediate(parent.GetComponent<RectTransform>());
            DrawGridBottomBorder(parent, columns, InventoryUiGeometry.GridRows(slotCount, columns), GetPaddingForGrid(gridType));

            var container = GetItemsContainer(gridType);
            if (container != null)
                EnsureContainerAboveGrid(parent, container);
        }

        /// <summary>
        /// ������������� ����� �������������� �������.
        /// ���������� true ���� ������������ �������.
        /// </summary>
        public bool RebuildBackpackGrid(
            int width, int height,
            Transform backpackGrid,
            Transform backpackItemsContainer)
        {
            if (backpackGrid == null || _slotPrefab == null) return false;

            ClearGrid(backpackGrid, backpackItemsContainer);
            SetupGridLayout(backpackGrid, width);
            CacheGridLayoutPadding(backpackGrid, GridType.Backpack);

            for (int i = 0; i < width * height; i++)
            {
                var slot = Object.Instantiate(_slotPrefab, backpackGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % width;
                    int y = i / width;
                    slotUI.Setup(x, y, GridType.Backpack, _inventoryUI);
                }
            }

            EnsureContainerAboveGrid(backpackGrid, backpackItemsContainer);

            var gridRT = backpackGrid.GetComponent<RectTransform>();
            var gridLayout = backpackGrid.GetComponent<GridLayoutGroup>();
            if (gridRT != null && gridLayout != null)
            {
                Vector3[] corners = new Vector3[4];
                gridRT.GetWorldCorners(corners);
                Vector3 savedWorldTopLeft = corners[1];
                int rows = height;
                float padLeft = gridLayout.padding.left;
                float padRight = gridLayout.padding.right;
                float padTop = gridLayout.padding.top;
                float padBot = gridLayout.padding.bottom;
                float w = padLeft + width * _slotSize + Mathf.Max(0, width - 1) * _slotSpacing + padRight;
                float h = padTop + rows * _slotSize + Mathf.Max(0, rows - 1) * _slotSpacing + padBot;
                gridRT.anchorMin = new Vector2(0f, 1f);
                gridRT.anchorMax = new Vector2(0f, 1f);
                gridRT.pivot = new Vector2(0f, 1f);
                gridRT.sizeDelta = new Vector2(w, h);
                if (gridRT.parent != null)
                {
                    Vector2 localTL = gridRT.parent.InverseTransformPoint(savedWorldTopLeft);
                    RectTransform pr = gridRT.parent as RectTransform;
                    if (pr != null) localTL -= new Vector2(pr.rect.xMin, pr.rect.yMax);
                    gridRT.anchoredPosition = localTL;
                }
            }

            var gridLe = backpackGrid.GetComponent<LayoutElement>();
            if (gridLe == null) gridLe = backpackGrid.gameObject.AddComponent<LayoutElement>();
            gridLe.ignoreLayout = true;

            var existingGridMask = backpackGrid.GetComponent<RectMask2D>();
            if (existingGridMask != null) Object.Destroy(existingGridMask);

            LayoutRebuilder.ForceRebuildLayoutImmediate(backpackGrid.GetComponent<RectTransform>());

            if (backpackItemsContainer != null)
            {
                var itemsRT = backpackItemsContainer.GetComponent<RectTransform>();
                var gRT = backpackGrid.GetComponent<RectTransform>();
                if (itemsRT != null && gRT != null)
                {
                    itemsRT.anchorMin = new Vector2(0f, 1f);
                    itemsRT.anchorMax = new Vector2(0f, 1f);
                    itemsRT.pivot = new Vector2(0f, 1f);
                    itemsRT.sizeDelta = gRT.sizeDelta;
                    itemsRT.anchoredPosition = Vector2.zero;
                    itemsRT.localScale = Vector3.one;
                    itemsRT.localRotation = Quaternion.identity;
                }
                var cg = backpackItemsContainer.GetComponent<CanvasGroup>();
                if (cg != null)
                {
                    cg.alpha = 1f;
                    cg.interactable = true;
                    cg.blocksRaycasts = true;
                }
            }

            DrawGridBottomBorder(backpackGrid, width, height, _backpackGridPadding);
            return true;
        }

        /// <summary>
        /// ������������� ����� ��������� (��� ��� �������� ����).
        /// </summary>
       public bool RebuildSurroundingsGrid(
    int width, int height,
    Transform surroundingsGrid,
    Transform surroundingsItemsContainer,
    InventoryController activeContainerController)
{
    if (surroundingsGrid == null || _slotPrefab == null) return false;

    if (surroundingsItemsContainer != null)
        surroundingsItemsContainer.SetParent(_inventoryUI.transform, false);

    ClearGrid(surroundingsGrid, surroundingsItemsContainer);
    SetupGridLayout(surroundingsGrid, width);
    CacheGridLayoutPadding(surroundingsGrid, GridType.Container);

    for (int i = 0; i < width * height; i++)
    {
        var slot = Object.Instantiate(_slotPrefab, surroundingsGrid);
        var slotUI = slot.GetComponent<K_InventorySlotUI>();
        if (slotUI != null)
        {
            int x = i % width;
            int y = i / width;
            slotUI.Setup(x, y, GridType.Container, _inventoryUI);
            slotUI.BindController(activeContainerController);
        }
    }

    var gridRect = surroundingsGrid.GetComponent<RectTransform>();
    if (gridRect != null)
    {
        var gridLayout = surroundingsGrid.GetComponent<GridLayoutGroup>();
        if (gridLayout != null)
        {
            Vector3[] corners = new Vector3[4];
            gridRect.GetWorldCorners(corners);
            Vector3 savedWorldTopLeft = corners[1];
            int rows = height;
            float padL = gridLayout.padding.left;
            float padR = gridLayout.padding.right;
            float padT = gridLayout.padding.top;
            float padB = gridLayout.padding.bottom;
            float w = padL + width * _slotSize + Mathf.Max(0, width - 1) * _slotSpacing + padR;
            float h = padT + rows * _slotSize + Mathf.Max(0, rows - 1) * _slotSpacing + padB;
            gridRect.anchorMin = new Vector2(0f, 1f);
            gridRect.anchorMax = new Vector2(0f, 1f);
            gridRect.pivot = new Vector2(0f, 1f);
            gridRect.sizeDelta = new Vector2(w, h);
            if (gridRect.parent != null)
            {
                Vector2 localTL = gridRect.parent.InverseTransformPoint(savedWorldTopLeft);
                RectTransform parentRT = gridRect.parent as RectTransform;
                if (parentRT != null)
                    localTL -= new Vector2(parentRT.rect.xMin, parentRT.rect.yMax);
                gridRect.anchoredPosition = localTL;
            }
        }
        LayoutRebuilder.ForceRebuildLayoutImmediate(gridRect);
    }

    DrawGridBottomBorder(surroundingsGrid, width, height, _containerGridPadding);

    if (surroundingsItemsContainer != null && surroundingsGrid != null)
    {
        var syncRT = surroundingsItemsContainer.GetComponent<SyncRectTransform>();
        if (syncRT != null) syncRT.enabled = false;
        surroundingsItemsContainer.SetParent(surroundingsGrid, false);
        surroundingsItemsContainer.SetAsLastSibling();
        var layoutElem = surroundingsItemsContainer.GetComponent<LayoutElement>();
        if (layoutElem == null) layoutElem = surroundingsItemsContainer.gameObject.AddComponent<LayoutElement>();
        layoutElem.ignoreLayout = true;
        var canvasGroup = surroundingsItemsContainer.GetComponent<CanvasGroup>();
        if (canvasGroup != null) canvasGroup.blocksRaycasts = true;

        // ═══ ФИКС H7: явно синхронизируем itemsContainer с gridRect сразу,
        // не дожидаясь следующего SyncItemsContainerPositions(). ═══
        var itemsRT = surroundingsItemsContainer.GetComponent<RectTransform>();
        if (itemsRT != null && gridRect != null)
        {
            itemsRT.anchorMin = new Vector2(0f, 1f);
            itemsRT.anchorMax = new Vector2(0f, 1f);
            itemsRT.pivot     = new Vector2(0f, 1f);
            itemsRT.sizeDelta = gridRect.sizeDelta;
            itemsRT.anchoredPosition = Vector2.zero;
            itemsRT.localScale = Vector3.one;
        }
    }
    return true;
}
        public void DrawGridBottomBorder(Transform grid, int columns, int rows, Vector2 padding)
        {
            if (grid == null || columns <= 0 || rows <= 0) return;
            Transform existing = grid.Find("BottomBorderFix");
            if (existing != null)
            {
                existing.gameObject.SetActive(false);
                existing.SetParent(null, false);
                Object.Destroy(existing.gameObject);
            }
            var frame = _slotPrefab != null ? _slotPrefab.GetComponent<K_InventoryFrameImage>() : null;
            // Cell frames already include their bottom edge. The medical mirror's fixed
            // viewport host has no GridLayoutGroup and still needs its own outer strip.
            if (frame != null && grid.GetComponent<GridLayoutGroup>() != null) return;

            var obj = new GameObject("BottomBorderFix", typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(grid, false);
            obj.AddComponent<LayoutElement>().ignoreLayout = true;

            float step = _slotSize + _slotSpacing;
            float lineWidth = columns * step;
            float posY = -(padding.y + rows * step) + _gridBottomBorderOffset;
            // SUP-05: apply the same content extent as BuildGrid, excluding trailing spacing.
            lineWidth = InventoryUiGeometry.GridExtent(columns, _slotSize, _slotSpacing);
            posY = -(padding.y + InventoryUiGeometry.GridExtent(rows, _slotSize, _slotSpacing)) + _gridBottomBorderOffset;

            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(padding.x, posY);
            rt.sizeDelta = new Vector2(lineWidth, _gridBottomBorderHeight);
            rt.localScale = Vector3.one;

            var img = obj.GetComponent<Image>();
            img.color = frame != null ? frame.BorderColor : _gridBottomBorderColor;
            img.raycastTarget = false;
            img.maskable = true;
            if (frame != null) K_ResponsiveCanvasLayout.TrackPixelLine(img);
        }

        /// <summary>
        /// ������� �������� ����� grid'�, �������� itemsContainer.
        /// </summary>
        public void ClearGrid(Transform parent, Transform preserveChild = null)
        {
            if (parent == null) return;
            _inventoryUI?.RecycleBorderHidersBeforeGridDestroy(parent);
            for (int i = parent.childCount - 1; i >= 0; i--)
            {
                var child = parent.GetChild(i);
                if (child == preserveChild) continue;
                  // Destroy is deferred. Remove old slots from layout and hit
                  // testing before new slots are created in the same frame.
                  child.gameObject.SetActive(false);
                  child.SetParent(null, false);
                Object.Destroy(child.gameObject);
            }
        }

        private void SetupGridLayout(Transform parent, int columns)
        {
            var grid = parent.GetComponent<GridLayoutGroup>();
            if (grid == null) grid = parent.gameObject.AddComponent<GridLayoutGroup>();
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = columns;
            grid.cellSize = new Vector2(_slotSize, _slotSize);
            grid.spacing = new Vector2(_slotSpacing, _slotSpacing);
            grid.childAlignment = TextAnchor.UpperLeft;
        }

        private void CacheGridLayoutPadding(Transform grid, GridType gridType)
        {
            if (grid == null) return;
            var layout = grid.GetComponent<GridLayoutGroup>();
            if (layout != null)
            {
                Vector2 padding = new Vector2(layout.padding.left, layout.padding.top);
                switch (gridType)
                {
                    case GridType.Pockets: _pocketsGridPadding = padding; break;
                    case GridType.Pocket2: _pocket2GridPadding = padding; break;
                    case GridType.Backpack: _backpackGridPadding = padding; break;
                    case GridType.Container: _containerGridPadding = padding; break;
                }
            }
        }

        /// <summary>
        /// ���������� itemsContainer ������ grid'� ��� ����������� raycast � ����������������.
        /// </summary>
        public void ReparentItemsContainerIntoGrid(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;
            if (itemsContainer.parent == grid) return;

            var syncRT = itemsContainer.GetComponent<SyncRectTransform>();
            if (syncRT != null) syncRT.enabled = false;

            var layoutElem = itemsContainer.GetComponent<LayoutElement>();
            if (layoutElem == null) layoutElem = itemsContainer.gameObject.AddComponent<LayoutElement>();
            layoutElem.ignoreLayout = true;

            var canvasGroup = itemsContainer.GetComponent<CanvasGroup>();
            if (canvasGroup == null) canvasGroup = itemsContainer.gameObject.AddComponent<CanvasGroup>();
            canvasGroup.blocksRaycasts = true;
            canvasGroup.interactable = true;
            canvasGroup.alpha = 1f;

            itemsContainer.SetParent(grid, false);
            itemsContainer.SetAsLastSibling();

            var gridRT = grid.GetComponent<RectTransform>();
            if (gridRT != null) LayoutRebuilder.ForceRebuildLayoutImmediate(gridRT);

            var itemsRT = itemsContainer.GetComponent<RectTransform>();
            if (itemsRT != null && gridRT != null)
            {
                itemsRT.anchorMin = new Vector2(0f, 1f);
                itemsRT.anchorMax = new Vector2(0f, 1f);
                itemsRT.pivot = new Vector2(0f, 1f);
                itemsRT.sizeDelta = gridRT.sizeDelta;
                itemsRT.anchoredPosition = Vector2.zero;
                itemsRT.localScale = Vector3.one;
                itemsRT.localRotation = Quaternion.identity;
            }
        }

        /// <summary>
        /// �����������, ��� itemsContainer ���� ������ � ��������.
        /// </summary>
        public void EnsureContainerAboveGrid(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;
            if (itemsContainer.parent == grid) { itemsContainer.SetAsLastSibling(); return; }
            if (itemsContainer.parent == grid.parent) { itemsContainer.SetAsLastSibling(); return; }
            itemsContainer.SetAsLastSibling();
        }

        private Transform GetItemsContainer(GridType type) => _inventoryUI?.GetItemsContainerForGrid(type);


    }
}
