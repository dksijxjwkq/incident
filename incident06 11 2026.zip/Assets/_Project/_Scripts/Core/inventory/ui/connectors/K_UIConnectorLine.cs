using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Plain connector quad without native pixel adjustment of its rotated rectangle.</summary>
    [AddComponentMenu("")]
    public sealed class K_UIConnectorLine : Image
    {
        protected override void OnPopulateMesh(VertexHelper vertices)
        {
            // The connector already enforces screen-space thickness. PixelAdjustRect on a
            // thin rotated Image can collapse its mesh even when its RectTransform is valid.
            Rect rect = rectTransform.rect;
            vertices.Clear();
            if (rect.width <= 0f || rect.height <= 0f) return;

            vertices.AddVert(new Vector3(rect.xMin, rect.yMin, 0f), color, new Vector2(0f, 0f));
            vertices.AddVert(new Vector3(rect.xMin, rect.yMax, 0f), color, new Vector2(0f, 1f));
            vertices.AddVert(new Vector3(rect.xMax, rect.yMax, 0f), color, new Vector2(1f, 1f));
            vertices.AddVert(new Vector3(rect.xMax, rect.yMin, 0f), color, new Vector2(1f, 0f));
            vertices.AddTriangle(0, 1, 2);
            vertices.AddTriangle(2, 3, 0);
        }
    }
}
