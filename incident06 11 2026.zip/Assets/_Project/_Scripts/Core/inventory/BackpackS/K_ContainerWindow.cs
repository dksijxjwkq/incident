﻿
﻿
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Самостоятельное плавающее окно одного открытого контейнера (рюкзака).
    /// Создаёт свою иерархию: Panel > DragZone + Grid > Slots + ItemsContainer.
    /// Управляет перетаскиванием (через K_DraggablePanel).
    ///
    /// Z-ORDER ПЕРЕКЛЮЧЕНИЕ ОТКЛЮЧЕНО (баг-фикс):
    /// Окна больше не прыгают наверх при клике. BringToFront() — no-op.
    /// OnPointerDown больше не вызывает OnWindowFocused.
    /// Все окна всегда интерактивны одновременно.
    /// </summary>
    public class K_ContainerWindow : MonoBehaviour
    {
        #region Public Properties
private const string BORDER_TOP_NAME     = "PanelBorderTop";
private const string BORDER_BOTTOM_NAME  = "PanelBorderBottom";
private const string BORDER_LEFT_NAME    = "PanelBorderLeft";
private const string BORDER_RIGHT_NAME   = "PanelBorderRight";
private const string HEADER_BOTTOM_LINE  = "HeaderBottomLine";
        public InventoryController Controller { get; private set; }
        public string BackpackInstanceID { get; private set; }
        public int GridWidth { get; private set; }
        public int GridHeight { get; private set; }
        public bool IsActive { get; set; }
        public RectTransform PanelRect { get; private set; }
        public RectTransform GridRect { get; private set; }
        public Transform ItemsContainer { get; private set; }
        public K_DraggablePanel DraggablePanel { get; private set; }
        public Transform DragZoneTransform { get; private set; }

        #endregion

        #region Events

        public event Action<K_ContainerWindow> OnWindowFocused;

        #endregion

        #region Initialization

        public void Initialize(
    InventoryController controller,
    string backpackInstanceID,
    int width, int height,
    GameObject slotPrefab,
    float slotSize, float slotSpacing,
    Color headerColor, float headerHeight,
    K_InventoryUI inventoryUI,
    Sprite backgroundSprite,
    string displayName,
    Color fillColor,
    Color borderColor,
    float borderThickness)
{
    Controller = controller;
    BackpackInstanceID = backpackInstanceID;
    GridWidth = width;
    GridHeight = height;

    // ────────────────────────────────────────────────────────────
    // 1. PANEL — единая заливка панели лута (пелена #9F9F9F alpha 4)
    // ────────────────────────────────────────────────────────────
    gameObject.name = $"Window_{backpackInstanceID}";
    PanelRect = GetComponent<RectTransform>();
    if (PanelRect == null) PanelRect = gameObject.AddComponent<RectTransform>();
    PanelRect.anchorMin = new Vector2(0f, 1f);
    PanelRect.anchorMax = new Vector2(0f, 1f);
    PanelRect.pivot = new Vector2(0f, 1f);
    headerColor = K_ResponsiveCanvasLayout.ResolveLineColor(PanelRect);
    borderColor = headerColor;

    var panelImg = GetComponent<Image>();
    if (panelImg == null) panelImg = gameObject.AddComponent<Image>();
    panelImg.sprite = null;
    panelImg.type = Image.Type.Simple;
    panelImg.color = fillColor;
    panelImg.raycastTarget = true;   // нужен для K_DraggablePanel drag-from-anywhere
    panelImg.maskable = true;

    var panelCG = GetComponent<CanvasGroup>();
    if (panelCG == null) panelCG = gameObject.AddComponent<CanvasGroup>();
    panelCG.alpha = 1f;
    panelCG.interactable = true;
    panelCG.blocksRaycasts = true;

    // ────────────────────────────────────────────────────────────
    // 2. DRAGZONE — заливка в общей палитре линий снаряжения.
    // ────────────────────────────────────────────────────────────
    var dzObj = new GameObject("DragZone", typeof(RectTransform), typeof(Image));
    dzObj.transform.SetParent(transform, false);
    dzObj.transform.SetAsFirstSibling();

    var dzRT = dzObj.GetComponent<RectTransform>();
    dzRT.anchorMin = new Vector2(0f, 1f);
    dzRT.anchorMax = new Vector2(1f, 1f);
    dzRT.pivot = new Vector2(0.5f, 1f);
    dzRT.anchoredPosition = Vector2.zero;
    dzRT.sizeDelta = new Vector2(0f, headerHeight);
    dzRT.localScale = Vector3.one;

    var dzLayout = dzObj.AddComponent<LayoutElement>();
    dzLayout.ignoreLayout = true;

    var dzImg = dzObj.GetComponent<Image>();
    dzImg.sprite = null;
    dzImg.type = Image.Type.Simple;
    dzImg.color = headerColor;
    dzImg.raycastTarget = true;   // ловит drag и клики по шапке

    DragZoneTransform = dzObj.transform;

    // ────────────────────────────────────────────────────────────
    // 2a. WINDOW TITLE
    // ────────────────────────────────────────────────────────────
    if (!string.IsNullOrEmpty(displayName))
    {
        var nameObj = new GameObject("WindowTitle", typeof(RectTransform));
        nameObj.transform.SetParent(dzObj.transform, false);
        var nameRT = nameObj.GetComponent<RectTransform>();
        nameRT.anchorMin = Vector2.zero;
        nameRT.anchorMax = Vector2.one;
        nameRT.pivot = new Vector2(0.5f, 0.5f);
        nameRT.sizeDelta = Vector2.zero;
        nameRT.localScale = Vector3.one;
        // Правый offset уже оставляет место под крестик.
        nameRT.offsetMin = new Vector2(8f, 0f);
        nameRT.offsetMax = new Vector2(-headerHeight, 0f);

        var nameText = nameObj.AddComponent<TMPro.TextMeshProUGUI>();
        nameText.text = displayName;
        ApplyHeaderTitleStyle(nameText);
    }

    // ────────────────────────────────────────────────────────────
    // 2b. HEADER BOTTOM LINE — разделитель в той же палитре, что и шапка.
    //     Создаётся ДО CloseButton, чтобы тот оказался выше по иерархии.
    // ────────────────────────────────────────────────────────────
    EnsureHeaderBottomLine(dzObj.transform, borderColor, borderThickness);

    // ────────────────────────────────────────────────────────────
    // 2c. CLOSE BUTTON — правый край шапки
    // ────────────────────────────────────────────────────────────
    CreateCloseButton(dzObj.transform, headerHeight, inventoryUI);

    // ────────────────────────────────────────────────────────────
    // 3. GRID (подложка чёрная — оставляем как было)
    // ────────────────────────────────────────────────────────────
    var gridObj = new GameObject("Grid", typeof(RectTransform), typeof(Image),
        typeof(GridLayoutGroup), typeof(LayoutElement));
    gridObj.transform.SetParent(transform, false);
    gridObj.transform.SetAsLastSibling();

    float gridW = width * slotSize + Mathf.Max(0, width - 1) * slotSpacing;
    float gridH = height * slotSize + Mathf.Max(0, height - 1) * slotSpacing;

    GridRect = gridObj.GetComponent<RectTransform>();
    GridRect.anchorMin = new Vector2(0f, 1f);
    GridRect.anchorMax = new Vector2(0f, 1f);
    GridRect.pivot = new Vector2(0f, 1f);
    GridRect.sizeDelta = new Vector2(gridW, gridH);
    GridRect.anchoredPosition = new Vector2(0f, -headerHeight);
    GridRect.localScale = Vector3.one;

    var gridImg = gridObj.GetComponent<Image>();
    gridImg.color = Color.black;
    gridImg.raycastTarget = true;
    gridImg.maskable = false;

    var gridLayout = gridObj.GetComponent<GridLayoutGroup>();
    gridLayout.cellSize = new Vector2(slotSize, slotSize);
    gridLayout.spacing = new Vector2(slotSpacing, slotSpacing);
    gridLayout.startCorner = GridLayoutGroup.Corner.UpperLeft;
    gridLayout.startAxis = GridLayoutGroup.Axis.Horizontal;
    gridLayout.childAlignment = TextAnchor.UpperLeft;
    gridLayout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
    gridLayout.constraintCount = width;

    var gridLe = gridObj.GetComponent<LayoutElement>();
    gridLe.ignoreLayout = true;

    // ────────────────────────────────────────────────────────────
    // 4. SLOTS
    // ────────────────────────────────────────────────────────────
    for (int i = 0; i < width * height; i++)
    {
        var slot = Instantiate(slotPrefab, gridObj.transform);
        var slotUI = slot.GetComponent<K_InventorySlotUI>();
        if (slotUI != null)
        {
            int x = i % width;
            int y = i / width;
            slotUI.Setup(x, y, GridType.Container, inventoryUI);
            slotUI.BindController(controller);
        }
    }

    if (inventoryUI != null)
        inventoryUI.DrawGridBottomBorder(gridObj.transform, width, height, Vector2.zero);

    // ────────────────────────────────────────────────────────────
    // 5. ITEMS CONTAINER
    // ────────────────────────────────────────────────────────────
    var icObj = new GameObject("ItemsContainer", typeof(RectTransform), typeof(CanvasGroup));
    icObj.transform.SetParent(gridObj.transform, false);
    icObj.transform.SetAsLastSibling();

    var icRT = icObj.GetComponent<RectTransform>();
    icRT.anchorMin = new Vector2(0f, 1f);
    icRT.anchorMax = new Vector2(0f, 1f);
    icRT.pivot = new Vector2(0f, 1f);
    icRT.sizeDelta = GridRect.sizeDelta;
    icRT.anchoredPosition = Vector2.zero;
    icRT.localScale = Vector3.one;

    var icCG = icObj.GetComponent<CanvasGroup>();
    icCG.alpha = 1f;
    icCG.interactable = true;
    icCG.blocksRaycasts = true;

    var icLe = icObj.AddComponent<LayoutElement>();
    icLe.ignoreLayout = true;

    ItemsContainer = icObj.transform;

    // ────────────────────────────────────────────────────────────
    // 6. PANEL SIZE
    // ────────────────────────────────────────────────────────────
    PanelRect.sizeDelta = new Vector2(gridW, gridH + headerHeight);

    // ────────────────────────────────────────────────────────────
    // 6a. PANEL BORDER — 4 стрипа поверх всего (raycastTarget=false)
    //     Layout симметричен панели лута.
    // ────────────────────────────────────────────────────────────
    EnsurePanelBorderStrip(PanelRect, BORDER_BOTTOM_NAME,
        new Vector2(0f, 0f), new Vector2(1f, 0f), new Vector2(0.5f, 0f),
        Vector2.zero, new Vector2(0f, borderThickness), borderColor);

    EnsurePanelBorderStrip(PanelRect, BORDER_LEFT_NAME,
        new Vector2(0f, 0f), new Vector2(0f, 1f), new Vector2(0f, 0.5f),
        Vector2.zero, new Vector2(borderThickness, 0f), borderColor);

    EnsurePanelBorderStrip(PanelRect, BORDER_RIGHT_NAME,
        new Vector2(1f, 0f), new Vector2(1f, 1f), new Vector2(1f, 0.5f),
        Vector2.zero, new Vector2(borderThickness, 0f), borderColor);

    EnsurePanelBorderStrip(PanelRect, BORDER_TOP_NAME,
        new Vector2(0f, 1f), new Vector2(1f, 1f), new Vector2(0.5f, 1f),
        Vector2.zero, new Vector2(0f, borderThickness), borderColor);

    // ────────────────────────────────────────────────────────────
    // 7. K_DRAGGABLE PANEL
    // ────────────────────────────────────────────────────────────
    DraggablePanel = gameObject.AddComponent<K_DraggablePanel>();

    Debug.Log($"[CONTAINER-WIN] Created window '{displayName}' " +
              $"({width}x{height}), size={gridW:F0}x{gridH + headerHeight:F0}");
}

        #endregion

        #region Close Button

        private Button _closeButton;

        /// <summary>
        /// Крестик в правой части шапки окна. Клик закрывает окно через
        /// K_InventoryUI.CloseSpecificBackpackWindow — тот же путь, что ПКМ → «Закрыть»:
        /// содержимое сохраняется в предмет (ToSaveData), окно уничтожается
        /// каскадно вместе с дочерними окнами, лут-контроллер восстанавливается.
        /// Кнопка — Selectable, поэтому K_DraggablePanel не начинает перетаскивание
        /// окна при клике по крестику.
        /// </summary>
        #region Close Button



        private void CreateCloseButton(Transform header, float headerHeight, K_InventoryUI inventoryUI)
{
    var closeObj = new GameObject("CloseButton", typeof(RectTransform), typeof(Image), typeof(Button));
    closeObj.transform.SetParent(header, false);

    var rt = closeObj.GetComponent<RectTransform>();
    rt.anchorMin = new Vector2(1f, 0.5f);
    rt.anchorMax = new Vector2(1f, 0.5f);
    rt.pivot = new Vector2(1f, 0.5f);
    rt.anchoredPosition = new Vector2(-4f, 0f);
    rt.sizeDelta = new Vector2(headerHeight - 8f, headerHeight - 8f);
    rt.localScale = Vector3.one;

    var img = closeObj.GetComponent<Image>();
    img.color = new Color(1f, 1f, 1f, 0.06f);
    img.raycastTarget = true;

    var btn = closeObj.GetComponent<Button>();
    btn.targetGraphic = img;
    btn.transition = Selectable.Transition.None;

    float lineLen = Mathf.Max(10f, (headerHeight - 8f) * 0.6f);
    var line1 = CreateCrossLine(closeObj.transform, 45f, lineLen);
    var line2 = CreateCrossLine(closeObj.transform, -45f, lineLen);

    var trigger = closeObj.AddComponent<EventTrigger>();
    var enter = new EventTrigger.Entry { eventID = EventTriggerType.PointerEnter };
    enter.callback.AddListener(_ =>
    {
        img.color = new Color(1f, 1f, 1f, 0.18f);
        line1.color = Color.white;
        line2.color = Color.white;
    });
    var exit = new EventTrigger.Entry { eventID = EventTriggerType.PointerExit };
    exit.callback.AddListener(_ =>
    {
        img.color = new Color(1f, 1f, 1f, 0.06f);
        line1.color = new Color(0.92f, 0.92f, 0.95f, 1f);
        line2.color = new Color(0.92f, 0.92f, 0.95f, 1f);
    });
    trigger.triggers.Add(enter);
    trigger.triggers.Add(exit);

    var id = BackpackInstanceID;
    btn.onClick.AddListener(() =>
    {
        Debug.Log($"[CONTAINER-WIN] Close (X) clicked: window '{id}'");
        if (inventoryUI != null)
            inventoryUI.CloseSpecificBackpackWindow(id);
    });

    _closeButton = btn;

    // ═══ Крестик — поверх HeaderBottomLine внутри DragZone ═══
    closeObj.transform.SetAsLastSibling();
}

/// <summary>
/// Find-or-create нижней границы шапки (разделитель шапки и сетки).
/// Идемпотентно. SetAsLastSibling внутри DragZone — поверх Title.
/// </summary>
private void EnsureHeaderBottomLine(Transform dragZone, Color borderColor, float borderThickness)
{
    if (dragZone == null) return;

    Transform existing = dragZone.Find(HEADER_BOTTOM_LINE);
    RectTransform rt;
    Image img;

    if (existing == null)
    {
        var go = new GameObject(HEADER_BOTTOM_LINE, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(dragZone, false);
        rt = go.GetComponent<RectTransform>();
        img = go.GetComponent<Image>();
        img.sprite = null;
        img.type = Image.Type.Simple;
        img.maskable = true;
    }
    else
    {
        rt = existing as RectTransform;
        img = existing.GetComponent<Image>();
        if (img == null) img = existing.gameObject.AddComponent<Image>();
    }

    if (rt == null || img == null) return;

    rt.anchorMin = new Vector2(0f, 0f);
    rt.anchorMax = new Vector2(1f, 0f);
    rt.pivot = new Vector2(0.5f, 0f);
    rt.anchoredPosition = Vector2.zero;
    rt.sizeDelta = new Vector2(0f, Mathf.Max(1f, borderThickness));
    rt.localScale = Vector3.one;

    img.color = borderColor;
    img.raycastTarget = false;

    // Поверх Title внутри DragZone.
    rt.SetAsLastSibling();
}

/// <summary>
/// Find-or-create одного бордер-стрипа панели. Идемпотентно.
/// Все стрипы — SetAsLastSibling на панели → поверх DragZone/Grid.
/// raycastTarget=false — клики уходят внутрь.
/// </summary>
internal static void EnsurePanelBorderStrip(
    RectTransform panelRect, string name,
    Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot,
    Vector2 anchoredPos, Vector2 sizeDelta,
    Color borderColor)
{
    if (panelRect == null) return;

    Transform tr = panelRect.Find(name);
    RectTransform rect;
    Image img;

    if (tr == null)
    {
        var go = new GameObject(name, typeof(RectTransform), typeof(Image));
        go.transform.SetParent(panelRect, false);
        rect = go.GetComponent<RectTransform>();
        img = go.GetComponent<Image>();
        img.sprite = null;
        img.type = Image.Type.Simple;
        img.maskable = true;
    }
    else
    {
        rect = tr as RectTransform;
        img = tr.GetComponent<Image>();
        if (img == null) img = tr.gameObject.AddComponent<Image>();
    }

    if (rect == null || img == null) return;

    rect.anchorMin = anchorMin;
    rect.anchorMax = anchorMax;
    rect.pivot = pivot;
    rect.anchoredPosition = anchoredPos;
    rect.sizeDelta = sizeDelta;
    rect.localScale = Vector3.one;

    img.color = borderColor;
    img.raycastTarget = false;

    // Поверх всех детей панели (DragZone + Grid).
    rect.SetAsLastSibling();
}

internal static void ApplyHeaderTitleStyle(TMPro.TextMeshProUGUI title)
{
    title.alignment = TMPro.TextAlignmentOptions.Center;
    title.fontStyle = TMPro.FontStyles.Bold;
    title.fontSize = 14f;
    title.color = new Color(0.92f, 0.92f, 0.95f, 1f);
    title.overflowMode = TMPro.TextOverflowModes.Truncate;
    title.textWrappingMode = TMPro.TextWrappingModes.NoWrap;
    title.raycastTarget = false;
}
        private static Image CreateCrossLine(Transform parent, float angle, float lineLen)
        {
            var lineObj = new GameObject("CrossLine", typeof(RectTransform), typeof(Image));
            lineObj.transform.SetParent(parent, false);
            var rt = lineObj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0.5f, 0.5f);
            rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = new Vector2(lineLen, 2f);
            rt.localRotation = Quaternion.Euler(0f, 0f, angle);
            var img = lineObj.GetComponent<Image>();
            img.color = new Color(0.92f, 0.92f, 0.95f, 1f);
            img.raycastTarget = false;
            return img;
        }

        #endregion


        public void SetPosition(Vector2 position)
        {
            if (PanelRect != null)
                PanelRect.anchoredPosition = position;
        }

        public Vector2 GetPosition()
        {
            return PanelRect != null ? PanelRect.anchoredPosition : Vector2.zero;
        }

        

        public void SetInteractable(bool interactable)
        {
            var panelCG = GetComponent<CanvasGroup>();
            if (panelCG == null) return;
            panelCG.interactable = interactable;
            panelCG.blocksRaycasts = interactable;
            // Мягкий визуальный индикатор фокуса (НЕ влияет на raycast/логику).
            panelCG.alpha = interactable ? 1f : 0.85f;
        }

        #endregion

    
    }
}

