using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core
{
    public class K_VitalitySystem : MonoBehaviour, ISaveable, IPostLoad
        , ISavePayloadValidator
    {
        public string SaveID => "PlayerVitality";
        public bool IsDirty { get; set; } = true;

        public event Action OnMetabolismChanged;
        public event Action OnStimulatorChanged;
        public event Action OnHangoverChanged;
        public event Action OnColdExposureChanged;
        public event Action OnOverloadChanged;
        public event Action<float> OnPulseChanged;

        public const float RestingBpm = 60f;
        public const float MinimumBpm = 40f;
        public const float MaximumBpm = 200f;
        [Header("Pulse")]
        [SerializeField, Range(0f, MaximumBpm), Tooltip("Текущий пульс: 40–200 у живого персонажа, 0 при смерти. Для тестов используй Pulse — Debug.")]
        private float _currentBpm = RestingBpm;
        [SerializeField, Range(0f, MaximumBpm)] private float _targetBpm = RestingBpm;
        [SerializeField, Min(0.01f), Tooltip("Время роста пульса в секундах; за это время проходит около 63% изменения.")]
        private float _pulseRiseSeconds = 1.5f;
        [SerializeField, Min(0.01f), Tooltip("Время спада пульса в секундах; за это время проходит около 63% изменения.")]
        private float _pulseFallSeconds = 8f;
        [Header("Pulse — Debug")]
        [SerializeField, Tooltip("Тестовый ручной пульс: текущее и целевое BPM удерживаются на заданном значении. Выключи для возврата к обычному расчёту.")]
        private bool _debugPulseOverride = false;
        [SerializeField, Range(MinimumBpm, MaximumBpm), Tooltip("Тестовый BPM. При включённом Debug Pulse Override применяется сразу в следующем Update, без травм и медикаментов.")]
        private float _debugPulseBpm = RestingBpm;
        [Header("Pulse — Target Bonuses")]
        [SerializeField, Min(0f), Tooltip("Прибавка BPM при ходьбе.")]
        private float _pulseWalkBonus = 20f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM при спринте.")]
        private float _pulseSprintBonus = 80f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM при движении присев.")]
        private float _pulseCrouchBonus = 10f;
        [SerializeField, Min(0f), Tooltip("Максимальная прибавка за HP ниже 50%; линейно от 0 при 50% до этого значения при 0%.")]
        private float _pulseLowHealthBonus = 40f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM за наличие хотя бы одного перелома.")]
        private float _pulseFractureBonus = 10f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM за наличие огнестрельной травмы.")]
        private float _pulseGunshotBonus = 30f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM за наличие открытой раны.")]
        private float _pulseOpenWoundBonus = 10f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM за наличие внутреннего кровотечения, включая скрытое.")]
        private float _pulseInternalBleedingBonus = 20f;
        [Header("Pulse — Additional Injury Types")]
        [SerializeField, Min(0f), Tooltip("Прибавка BPM за наружное кровотечение. Учитывается один раз независимо от числа участков; кровопотеря влияет дополнительно через состояние крови.")]
        private float _pulseBleedingBonus = 10f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM за сотрясение. Один раз за тип травмы.")]
        private float _pulseConcussionBonus = 5f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM за ЧМТ. Один раз за тип травмы.")]
        private float _pulseTbiBonus = 10f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM за затруднённое дыхание. Прибавляется отдельно от вызвавшей его травмы груди.")]
        private float _pulseBreathingBonus = 10f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM за обездвиживание. Прибавляется отдельно от перелома таза.")]
        private float _pulseImmobilizedBonus = 5f;
        [SerializeField, Min(0f), Tooltip("Краткая прибавка BPM во время огневого шока. Не заменяет влияние кровопотерного шока.")]
        private float _pulseFirearmShockBonus = 5f;
        [Header("Pulse — Blood State Bonuses")]
        [SerializeField, Min(0f), Tooltip("Прибавка BPM в состоянии крови Normal. Мелкие потери крови не учащают пульс.")]
        private float _bloodPulseBonusNormal = 0f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM в состоянии крови Warning; без интерполяции между состояниями.")]
        private float _bloodPulseBonusWarning = 20f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM в состоянии крови Weakness; без интерполяции между состояниями.")]
        private float _bloodPulseBonusWeakness = 40f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM при кровопотерном шоке. Краткий огневой шок настраивается отдельно.")]
        private float _bloodPulseBonusShock = 60f;
        [Header("Pulse — Status Bonuses")]
        [SerializeField, Min(0f), Tooltip("Прибавка BPM во время действия кофеина.")]
        private float _pulseStimBonus = 10f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM при ColdExposure от 0.5 включительно до 1. При 1 цель всегда 40 BPM.")]
        private float _pulseColdBonus = 20f;
        [SerializeField, Min(0f), Tooltip("Прибавка BPM при нулевом голоде или жажде; однократно, даже если оба на нуле.")]
        private float _pulseStarvationBonus = 20f;
        [Header("Pulse — Pain and Acute Reaction")]
        [SerializeField, Range(0f, 1f), Tooltip("Доля болевого вклада травм в покое. При движении используется полный вклад. Кровопотеря и нарушение дыхания от отдыха не исчезают.")]
        private float _pulseRestingPainFraction = 0.6f;
        [SerializeField, Min(0f), Tooltip("Игровая прибавка среднего пульса при простуде. Учитывается один раз.")]
        private float _pulseCommonColdBonus = 3f;
        [SerializeField, Min(0f), Tooltip("Игровая прибавка при инфекции раны. Не складывается по участкам.")]
        private float _pulseWoundInfectionBonus = 6f;
        [SerializeField, Min(0f), Tooltip("Краткий всплеск BPM при появлении новой травмы. Повторная травма обновляет реакцию, не складывает постоянные прибавки.")]
        private float _pulseAcuteInjuryPeak = 24f;
        [SerializeField, Min(0f), Tooltip("Максимальный краткий всплеск BPM, общий для повторных попаданий и новых травм.")]
        private float _pulseAcuteMaximum = 35f;
        [SerializeField, Min(0f), Tooltip("Прибавка краткой реакции на единицу прямого урона. Метаболизм, холод и кровотечение не вызывают новый всплеск каждый тик.")]
        private float _pulseAcuteDamageScale = 0.45f;
        [SerializeField, Min(0.01f), Tooltip("Время нарастания острой реакции в игровых секундах.")]
        private float _pulseAcuteRiseSeconds = 0.45f;
        [SerializeField, Min(0.01f), Tooltip("Время спада острой реакции: за этот срок остаётся около 37% её источника. Не убирает продолжающуюся кровопотерю и боль.")]
        private float _pulseAcuteDecaySeconds = 18f;
        [SerializeField, Range(0f, 1f), Tooltip("Доля острой реакции, связанная с болью. Обезболивающее ослабляет эту долю, но не всю стрессовую реакцию.")]
        private float _pulseAcutePainFraction = 0.5f;
        [Header("Pulse — Breathing Variation")]
        [SerializeField, Range(0f, 5f), Tooltip("Небольшая плавная дыхательная вариация BPM. Не влияет на множитель кровопотери и не создаёт аритмии.")]
        private float _pulseBreathingAmplitude = 1.5f;
        [SerializeField, Min(0.1f), Tooltip("Длительность дыхательной волны в игровых секундах. Пауза останавливает фазу.")]
        private float _pulseBreathingPeriodSeconds = 4.5f;
        private float _pulseMeanBpm = RestingBpm;
        private float _pulseAcuteDrive;
        private float _pulseAcuteResponse;
        private double _pulseBreathingPhase;
        private PulseInjurySnapshot _pulseObservedInjuries;
        private K_PlayerMotor _pulseMotor;
        public float CurrentBpm => HasPulse ? (_currentBpm == 0f ? RestingBpm : Mathf.Clamp(_currentBpm, MinimumBpm, MaximumBpm)) : 0f;
        public float TargetBpm => HasPulse ? CalculateTargetBpm() : 0f;
        /// <summary>Smoothed sustained physiology, excluding acute peaks and respiratory variation.</summary>
        public float MeanBpm => !HasPulse ? 0f : _debugPulseOverride ? DebugPulseBpm
            : _pulseMeanBpm == 0f ? RestingBpm : Mathf.Clamp(_pulseMeanBpm, MinimumBpm, MaximumBpm);
        public float AcutePulseBonus => HasPulse && !_debugPulseOverride && _coldExposure < 1f
            ? _pulseAcuteResponse * (1f - PainReliefFraction * Mathf.Clamp01(_pulseAcutePainFraction)) : 0f;
        public float PainPulseBonus => HasPulse ? CalculatePainPulseBonus() : 0f;
        public bool HasPulse => _cachedHealth == null || !_cachedHealth.IsDead;
        // One bounded, runtime-only history per player; hidden or multiple monitors only read it.
        private readonly EcgTrace _pulseTrace = new EcgTrace();
        private bool _ecgHasPulse = true;
        internal EcgTrace PulseTrace => _pulseTrace;
        // The bounded average excludes brief stress peaks/respiration and limits blood/pulse feedback.
        public float PulseBleedingMultiplier => Mathf.Clamp(MeanBpm / 100f, 1f, 1.5f);

        // =====================================================================
        // КОНСТАНТЫ БАЛАНСА (Аспект №11, №5, №9)
        // =====================================================================
        private const float MAX_VITALITY = 100f;
        private const float MIN_VITALITY = 0f;
        private const float HUNGER_DECAY_TIME = 9000f;
        private const float THIRST_DECAY_TIME = 4800f;
        private const float THIRST_DAMAGE_PER_SEC = 0.15f;
        private const float HUNGER_DAMAGE_PER_SEC = 0.1f;
        private const float RADIATION_METABOLISM_MULTIPLIER = 2.0f;
        private const float SAFE_ZONE_MULTIPLIER = 0.2f;
        private const float METABOLISM_TICK_RATE = 1.0f;
        private const float STIM_ON_DURATION = 85f;
        private const float STIM_OFF_DURATION = 200f;
        private const float FATIGUE_DURATION = 30f;
        private const float COLD_LETHAL_THRESHOLD = -25f;
        private const float COLD_WARNING_THRESHOLD = -20f;
        private const float COLD_EXPOSURE_GAIN_RATE = 0.00037f;
        private const float COLD_DAMAGE_PER_SEC = 1.0f;
        private const float SAFE_ZONE_COLD_RECOVERY_TIME = 60f;
        private const float ALCOHOL_RADIATION_IMMUNITY_THRESHOLD = 0.5f;
        private const float ALCOHOL_COLD_THRESHOLD_OFFSET = 10f;
        private const float BLACKOUT_HANGOVER_DURATION = 240f;
        private const float ALCOHOL_RADIATION_REDUCTION_PER_100ML = 5f;

        // =====================================================================
        // ПАРАМЕТРЫ
        // =====================================================================
        [Header("Vitality Stats (Max 100)")]
        [SerializeField, Range(0f, 100f)] private float _hunger = 100f;
        [SerializeField, Range(0f, 100f)] private float _thirst = 100f;
        [SerializeField, Range(0f, 100f)] private float _radiation = 0f;

        [Header("Radiation Decay")]
        [Tooltip("Percentage points removed per second. Default: 0.5 per minute.")]
        [SerializeField, Min(0f)] private float _radiationDecayPerSecond = 0.5f / 60f;
        // Derived runtime state only; the existing radiation and segment bleeding save slots suffice.
        private bool _radiationBleedActive;
        private float _lastAppliedRadiation = float.NaN;
        private const float RADIATION_HEALTH_UPDATE_EPSILON = 0.01f;

        [Header("Stimulator & Debuffs")]
        [SerializeField] private float _stimulatorTimer = 0f;
        [SerializeField] private float _stimOffTimer = 0f;
        [SerializeField] private float _fatigueTimer = 0f;
        [SerializeField, Range(0.01f, 1f)] private float _fatigueStaminaMultiplier = 0.75f;
        [SerializeField, Range(0.01f, 1f)] private float _fatigueActionSpeedMultiplier = 0.85f;

        [Header("Alcohol System")]
        [SerializeField] private float _alcoholConcentration = 0f;
        [SerializeField] private float _drunkTimer = 0f;
        [SerializeField] private float _hangoverTimer = 0f;
        [SerializeField] private float _totalAlcoholConsumed = 0f;
        // H07a: queued while drunk; persisted only as an optional trailing vitality field.
        private float _pendingHangoverSeconds;
        [Header("Alcohol Death Rolls")]
        [SerializeField, Range(0, 3)] private int _deathRollsRemaining = 0;
        [SerializeField, Min(0f)] private float _deathRollTimer = 0f;
        [SerializeField, Range(0f, 1f)] private float _deathRollChance = 0.5f;
        [SerializeField, Min(0.001f)] private float _deathRollInterval = 60f;
        [Header("Cold System")]
        [SerializeField, Range(0f, 1f)] private float _coldExposure = 0f;
        [SerializeField, Range(-40f, 10f)] private float _currentTemperature = -15f;

        // Stage 1 §8.3: константы холода в инспекторе.
        [Header("Cold System — Stage 1 §8.3")]
        [SerializeField, Min(0f)] private float _coldDamagePerSec = 1.25f;
        [Tooltip("Веса 10 пар. Индекс: 0=Стопы, 1=Кисти, 2=Колени, 3=Голени, 4=Предплечья, " +
                 "5=Бицепсы, 6=Бёдра, 7=Плечи, 8=Таз, 9=Живот.")]
        [SerializeField] private float[] _coldPairWeights = { 100f, 95f, 85f, 80f, 70f, 60f, 55f, 45f, 35f, 20f };
        [SerializeField, Range(0f, 1f)] private float _coldHeadPercentAlive  = 0.01f;
        [SerializeField, Range(0f, 1f)] private float _coldChestPercentAlive = 0.01f;
        [SerializeField, Range(0f, 1f)] private float _coldHeadPercentFinal  = 0.30f;
        [SerializeField, Range(0f, 1f)] private float _coldChestPercentFinal = 0.70f;

        [Header("Other Debuffs")]
        [SerializeField] private bool _isOverloaded = false;

        [Header("Zone & FX Status")]
        [SerializeField] private bool _isInSafeZone = false;
        [SerializeField] private GameObject _bloodDecalPrefab;
        private readonly List<ActiveSafeZone> _activeSafeZones = new List<ActiveSafeZone>();
        private readonly object _manualSafeZoneSource = new object();
        private float _safeZoneColdRecoveryTime = SAFE_ZONE_COLD_RECOVERY_TIME;
        private float _safeZoneMetabolismMultiplier = SAFE_ZONE_MULTIPLIER;

        private sealed class ActiveSafeZone
        {
            public object Source;
            public float ColdRecoveryTime;
            public float MetabolismMultiplier;
        }

        // =====================================================================
        // КЭШИРОВАННЫЕ ССЫЛКИ
        // =====================================================================
     private K_HealthSystem _cachedHealth;
     private K_BloodSystem _cachedBlood;
     private K_DebuffSystem _cachedDebuffs;

#if UNITY_EDITOR
        private float _previousRadiation = 0f;
#endif

        // Stage 1 §8.3: раскладка 10 пар. isPair=false — одиночный сегмент (Таз, Живот).
        // Порядок строго соответствует индексам _coldPairWeights.
        private static readonly (BodyPart a, BodyPart b, bool isPair)[] ColdPairLayout =
        {
            (BodyPart.LeftFoot,       BodyPart.RightFoot,       true),  // 0  Стопы
            (BodyPart.LeftHand,       BodyPart.RightHand,       true),  // 1  Кисти
            (BodyPart.LeftKnee,       BodyPart.RightKnee,       true),  // 2  Колени
            (BodyPart.LeftShin,       BodyPart.RightShin,       true),  // 3  Голени
            (BodyPart.LeftForearm,    BodyPart.RightForearm,    true),  // 4  Предплечья
            (BodyPart.LeftBiceps,     BodyPart.RightBiceps,     true),  // 5  Бицепсы
            (BodyPart.LeftQuadriceps, BodyPart.RightQuadriceps, true),  // 6  Бёдра
            (BodyPart.LeftShoulder,   BodyPart.RightShoulder,   true),  // 7  Плечи
            (BodyPart.Pelvis,         BodyPart.Pelvis,          false), // 8  Таз
            (BodyPart.Stomach,        BodyPart.Stomach,         false), // 9  Живот
        };
        // =====================================================================
        // ТАЙМЕРЫ И ОТСЛЕЖИВАНИЕ РЕСУРСОВ (ИСПРАВЛЕНИЕ УТЕЧЕК)
        // =====================================================================
        private float _bloodDecalTimer = 0f;
        private Coroutine _tickerCoroutine;
        private Coroutine _temperatureLerpCoroutine; // ДОБАВЛЕНО: отслеживание корутины температуры
        private bool _subscribedToTime;
        private K_TimeSystem _subscribedTimeSystem;

        // ДОБАВЛЕНО: список для отслеживания созданных декалей крови
        private readonly List<GameObject> _spawnedBloodDecals = new List<GameObject>();

        // =====================================================================
        // ГЕТТЕРЫ
        // =====================================================================
        public float Hunger => _hunger;
        public float Thirst => _thirst;
        public float Radiation => _radiation;
        public float RadiationSpeedMult => _radiation >= 50f ? 0.75f : _radiation >= 25f ? 0.9f : 1f;
        public float RadiationRegenMult => _radiation >= 50f ? 0.75f : _radiation >= 25f ? 0.9f : 1f;
        public float CurrentTemperature => _currentTemperature;
        public bool IsStimOn => _stimulatorTimer > 0f;
        public bool IsStimOff => _stimOffTimer > 0f;
        public bool IsFatigued => _fatigueTimer > 0f;
        public bool IsStimReady => _stimulatorTimer <= 0f && _stimOffTimer <= 0f && _fatigueTimer <= 0f;
        public bool IsHangover => _hangoverTimer > 0f;
        public bool IsDrunk => _drunkTimer > 0f;
        // Read-only presentation values; the original timers remain the only source of truth.
        public float StimulatorSecondsRemaining => Mathf.Max(0f, _stimulatorTimer);
        public float StimCooldownSecondsRemaining => Mathf.Max(0f, _stimOffTimer);
        public float FatigueSecondsRemaining => Mathf.Max(0f, _fatigueTimer);
        public float StimulatorFullDuration => STIM_ON_DURATION;
        public float StimCooldownFullDuration => STIM_OFF_DURATION;
        public float FatigueFullDuration => FATIGUE_DURATION;
        public float DrunkSecondsRemaining => Mathf.Max(0f, _drunkTimer);
        public float HangoverSecondsRemaining => Mathf.Max(0f, _hangoverTimer);
        public float FatigueActionSpeedMultiplier => _fatigueActionSpeedMultiplier;
        public bool IsColdCritical => _coldExposure >= 1.0f;
        public bool IsOverloaded => _isOverloaded;
        public bool IsStaminaFree => _cachedHealth != null && _cachedHealth.IsShocked;
        public float AlcoholConcentration => _alcoholConcentration;
        public float TotalAlcoholConsumed => _totalAlcoholConsumed;
        public bool HasRadiationImmunity => _alcoholConcentration > ALCOHOL_RADIATION_IMMUNITY_THRESHOLD;
        public float FOVModifier => 1f;
        public float AimStability => IsStimOn ? 1.0f : (IsHangover ? 0.7f : 1.0f);
        public float ActionSpeedMult => (IsStimOn ? 1.10f
            : IsFatigued ? _fatigueActionSpeedMultiplier : IsHangover ? 0.8f : 1f)
            * (_cachedDebuffs != null ? _cachedDebuffs.PainkillerActionSpeedMultiplier : 1f)
            * (_cachedHealth?.Illnesses != null ? _cachedHealth.Illnesses.ColdActionSpeedMultiplier : 1f);
        private float StimStaminaMult => IsStimOn ? 1.5f : IsFatigued ? _fatigueStaminaMultiplier : 1f;
        public float StaminaRegenMult
        {
            get
            {
                float baseMult = IsStimOn || IsFatigued ? StimStaminaMult : IsHangover ? 0.5f : 1f;
                float bloodMult = _cachedBlood != null ? _cachedBlood.GetStaminaRegenMultiplier() : 1f;
                float debuffMult = _cachedDebuffs != null ? _cachedDebuffs.GetStaminaRegenMultiplier() : 1f;
                return baseMult * bloodMult * debuffMult * RadiationRegenMult *
                    (_cachedHealth?.Illnesses != null ? _cachedHealth.Illnesses.ColdStaminaRegenMultiplier : 1f);
            }
        }
        /// <summary>Capacity and recovery share the stimulant bonus and configurable fatigue penalty.</summary>
        public float StaminaMaxMult => StimStaminaMult *
            (_cachedDebuffs != null ? _cachedDebuffs.GetStaminaMaxMultiplier() : 1f);
        public float StaminaDrainMult => _cachedDebuffs != null
            ? _cachedDebuffs.GetStaminaDrainMultiplier() : 1f;
        public float FractureChanceMult => IsHangover ? 1.75f : 1.0f;
        public float NoiseRadius => IsHangover ? 10.0f : 0f;
        // Audit CA-08: hangover scales only footstep radius; legacy NoiseRadius remains unchanged.
        public float HangoverFootstepNoiseMultiplier => IsHangover ? 1.5f : 1f;
        public float ColdExposure => _coldExposure;
        public bool IsInSafeZone => _isInSafeZone;
        public int ActiveSafeZoneCount => _activeSafeZones.Count;
        public float SafeZoneColdRecoveryTime => _safeZoneColdRecoveryTime;
        public float SafeZoneMetabolismMultiplier => _safeZoneMetabolismMultiplier;
        public bool Icon_Hunger => _hunger <= 50f;
        public bool Icon_Thirst => _thirst <= 50f;
        public bool Icon_Radiation => _radiation > 5f && !HasRadiationImmunity;
        public int Icon_Bleeding => _cachedHealth != null ? _cachedHealth.GetMaxBleedingLevel() : 0;
        public bool Icon_Fracture => _cachedHealth != null && _cachedHealth.FractureCount > 0;
        public bool Icon_Laceration => _cachedHealth != null && _cachedHealth.HasAnyLaceration();
        public bool Icon_StimOn => IsStimOn;
        public bool Icon_StimOff => IsStimOff;
        public bool Icon_Hangover => IsHangover;
        public bool Icon_Cold => _coldExposure > 0.5f;
        public bool Icon_Overload => _isOverloaded;
        public bool Icon_Drunk => IsDrunk;

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
{
    ResetStimulatorEffects();
    _cachedHealth = GetComponent<K_HealthSystem>();
    if (_cachedHealth != null)
    {
        _cachedHealth.OnDeath += StopPulse;
        _cachedHealth.OnDamageTaken += OnPulseDamageTaken;
        _cachedHealth.OnSegmentDamageApplied += OnPulseDamageTaken;
    }
    _pulseMotor = GetComponent<K_PlayerMotor>();
    if (_cachedHealth == null)
        Debug.LogError("[K_VitalitySystem] K_HealthSystem NOT FOUND on this GameObject!");

    // Stage 1 §8.3: защита массива весов холода.
    if (_coldPairWeights == null || _coldPairWeights.Length != 10)
        _coldPairWeights = new float[] { 100f, 95f, 85f, 80f, 70f, 60f, 55f, 45f, 35f, 20f };
    _cachedBlood = GetComponent<K_BloodSystem>();
    if (_cachedBlood == null)
        Debug.LogWarning("[K_VitalitySystem] K_BloodSystem not found!");

    if (K_TimeSystem.Instance != null)
        K_TimeSystem.Instance.OnPhaseChanged += OnTimePhaseChanged;

        _cachedDebuffs = GetComponent<K_DebuffSystem>();
        ResetPulseDynamics(_currentBpm);

#if UNITY_EDITOR
    _previousRadiation = _radiation;
#endif
}

        private void Start()
        {
            if (K_SaveManager.Instance != null)
                K_SaveManager.Instance.Register(this);

            ApplyRadiationToHealth();

            TrySubscribeToTime();
            _tickerCoroutine = StartCoroutine(StatsTick());
        }

        private void Update()
        {
            if (!_subscribedToTime) TrySubscribeToTime();
            if (_cachedHealth != null && _cachedHealth.IsDead) { TickPulse(Time.deltaTime); return; }
            UpdateRadiationDecay(Time.deltaTime);
            if (_cachedHealth != null && _cachedHealth.IsDead) { TickPulse(Time.deltaTime); return; }
            UpdateStimulatorTimers(Time.deltaTime);
            TickDeathRolls(Time.deltaTime);
            TickPulse(Time.deltaTime);
        }

        private float DebugPulseBpm => float.IsNaN(_debugPulseBpm) || float.IsInfinity(_debugPulseBpm)
            ? RestingBpm : Mathf.Clamp(_debugPulseBpm, MinimumBpm, MaximumBpm);
        private bool IsPulseMoving => _pulseMotor != null && _pulseMotor.CurrentSpeed > 0.1f;
        private float PainReliefFraction => _cachedDebuffs != null ? Mathf.Clamp01(_cachedDebuffs.PainReliefFraction) : 0f;
        private float PulseBreathingOffset => _coldExposure >= 1f || _debugPulseOverride ? 0f
            : Mathf.Clamp(_pulseBreathingAmplitude, 0f, 5f) * (float)Math.Sin(_pulseBreathingPhase);

        /// <summary>One sustained contribution per injury type; hidden IB affects physiology, never revelation.</summary>
        private float CalculatePainPulseBonus()
        {
            float pain = 0f;
            if (_cachedHealth != null)
            {
                if (_cachedHealth.HasFracture) pain += _pulseFractureBonus * (_cachedHealth.HasUnstabilizedFracture ? 1f : .5f);
                if (_cachedHealth.HasGunshot) pain += _pulseGunshotBonus;
                if (_cachedHealth.HasAnyOpenLaceration()) pain += _pulseOpenWoundBonus;
            }
            if (_cachedDebuffs != null)
            {
                if (_cachedDebuffs.HasConcussion) pain += _pulseConcussionBonus;
                if (_cachedDebuffs.HasTBI) pain += _pulseTbiBonus;
                if (_cachedDebuffs.HasImmobilized) pain += _pulseImmobilizedBonus;
            }
            return pain * (IsPulseMoving ? 1f : Mathf.Clamp01(_pulseRestingPainFraction)) * (1f - PainReliefFraction);
        }

        private float CalculateMeanTargetBpm()
        {
            if (!HasPulse) return 0f;
            if (_debugPulseOverride) return DebugPulseBpm;
            if (_coldExposure >= 1f) return MinimumBpm;
            float target = RestingBpm + CalculatePainPulseBonus();
            if (IsPulseMoving)
                target += _pulseMotor.IsCrouching ? _pulseCrouchBonus : _pulseMotor.IsSprinting ? _pulseSprintBonus : _pulseWalkBonus;
            if (_cachedHealth != null)
            {
                float hp = 0f, maximum = 0f;
                for (int i = 0; i < 20; i++)
                {
                    hp += _cachedHealth.GetHP((BodyPart)i);
                    maximum += _cachedHealth.GetMaxHP((BodyPart)i);
                }
                float fraction = maximum > 0f ? hp / maximum : 1f;
                target += Mathf.Clamp01((0.5f - fraction) * 2f) * _pulseLowHealthBonus;
                if (_cachedHealth.GetInternalBleedingCount() > 0) target += _pulseInternalBleedingBonus;
                if (_cachedHealth.GetMaxBleedingLevel() > 0) target += _pulseBleedingBonus;
                if (_cachedHealth.IsShocked) target += _pulseFirearmShockBonus;
            }
            if (_cachedDebuffs != null && _cachedDebuffs.HasBreathingDifficulty) target += _pulseBreathingBonus;
            if (_cachedBlood != null)
                target += _cachedBlood.State switch
                {
                    BloodState.Normal => _bloodPulseBonusNormal,
                    BloodState.Warning => _bloodPulseBonusWarning,
                    BloodState.Weakness => _bloodPulseBonusWeakness,
                    BloodState.Shock => _bloodPulseBonusShock,
                    _ => 0f
                };
            if (IsStimOn) target += _pulseStimBonus;
            if (_cachedHealth?.Illnesses != null)
            {
                if (_cachedHealth.Illnesses.HasCold) target += _pulseCommonColdBonus;
                if (_cachedHealth.Illnesses.HasWoundInfection) target += _pulseWoundInfectionBonus;
            }
            if (_coldExposure >= 0.5f) target += _pulseColdBonus;
            if (_hunger <= 0f || _thirst <= 0f) target += _pulseStarvationBonus;
            return Mathf.Clamp(target, MinimumBpm, MaximumBpm);
        }

        public float CalculateTargetBpm()
        {
            if (!HasPulse) return 0f;
            if (_debugPulseOverride) return DebugPulseBpm;
            if (_coldExposure >= 1f) return MinimumBpm;
            return Mathf.Clamp(CalculateMeanTargetBpm() + AcutePulseBonus + PulseBreathingOffset, MinimumBpm, MaximumBpm);
        }

        /// <summary>Refresh a bounded response to a real injury; repeated events never add permanent bonuses.</summary>
        public void RefreshAcutePulseReaction(float peakBpm)
        {
            if (float.IsNaN(peakBpm) || float.IsInfinity(peakBpm) || peakBpm < 0f)
                throw new ArgumentOutOfRangeException(nameof(peakBpm));
            if (!HasPulse || peakBpm == 0f) return;
            _pulseAcuteDrive = Mathf.Max(_pulseAcuteDrive, Mathf.Min(peakBpm, Mathf.Max(0f, _pulseAcuteMaximum)));
        }

        private void OnPulseDamageTaken(BodyPart part, float damage, DamageType source)
        {
            // Continuous systemic damage already has a sustained source; it must not keep restarting stress.
            if (source != DamageType.Generic && source != DamageType.Firearm && source != DamageType.Fall) return;
            if (damage <= 0f || float.IsNaN(damage) || float.IsInfinity(damage)) return;
            RefreshAcutePulseReaction(Mathf.Max(_pulseAcuteInjuryPeak * 0.5f, damage * _pulseAcuteDamageScale));
        }

        private struct PulseInjurySnapshot
        {
            public uint Fractures, Gunshots, OpenWounds, ExternalBleeding, InternalBleeding, Other;

            public bool HasNewInjury(PulseInjurySnapshot previous) =>
                (Fractures & ~previous.Fractures) != 0 || (Gunshots & ~previous.Gunshots) != 0 ||
                (OpenWounds & ~previous.OpenWounds) != 0 || (ExternalBleeding & ~previous.ExternalBleeding) != 0 ||
                (InternalBleeding & ~previous.InternalBleeding) != 0 || (Other & ~previous.Other) != 0;
        }

        private PulseInjurySnapshot ReadPulseInjuries()
        {
            var snapshot = new PulseInjurySnapshot();
            if (_cachedHealth != null)
            {
                for (int i = 0; i < 20; i++)
                {
                    var part = (BodyPart)i;
                    uint bit = 1u << i;
                    if (_cachedHealth.IsFractured(part) && !_cachedHealth.IsSplinted(part)) snapshot.Fractures |= bit;
                    if (_cachedHealth.IsGunshot(part)) snapshot.Gunshots |= bit;
                    if (_cachedHealth.HasOpenLaceration(part)) snapshot.OpenWounds |= bit;
                    if (_cachedHealth.GetBleedingLevel(part) > 0) snapshot.ExternalBleeding |= bit;
                    if (_cachedHealth.HasInternalBleeding(part)) snapshot.InternalBleeding |= bit;
                }
                if (_cachedHealth.IsShocked) snapshot.Other |= 1u;
            }
            if (_cachedDebuffs != null)
            {
                if (_cachedDebuffs.HasConcussion) snapshot.Other |= 2u;
                if (_cachedDebuffs.HasTBI) snapshot.Other |= 4u;
                if (_cachedDebuffs.HasBreathingDifficulty) snapshot.Other |= 8u;
                if (_cachedDebuffs.HasImmobilized) snapshot.Other |= 16u;
            }
            return snapshot;
        }

        private void ResetPulseDynamics(float bpm)
        {
            _pulseMeanBpm = bpm == 0f ? RestingBpm : Mathf.Clamp(bpm, MinimumBpm, MaximumBpm);
            _pulseAcuteDrive = 0f;
            _pulseAcuteResponse = 0f;
            _pulseBreathingPhase = 0d;
            _pulseObservedInjuries = ReadPulseInjuries();
        }

        private static void ValidatePulseSeconds(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds <= 0f)
                throw new InvalidOperationException("Pulse response time must be finite and positive.");
        }

        private void TickAcutePulse(float deltaTime)
        {
            ValidatePulseSeconds(_pulseAcuteRiseSeconds);
            ValidatePulseSeconds(_pulseAcuteDecaySeconds);
            double rise = _pulseAcuteRiseSeconds, decay = _pulseAcuteDecaySeconds;
            double driveDecay = Math.Exp(-deltaTime / decay), responseDecay = Math.Exp(-deltaTime / rise);
            // Exact integration of a decaying impulse through a first-order response, independent of frame partition.
            double forced = Math.Abs(decay - rise) < 0.00001d
                ? _pulseAcuteDrive * deltaTime / rise * responseDecay
                : _pulseAcuteDrive * decay / (decay - rise) * (driveDecay - responseDecay);
            _pulseAcuteResponse = Mathf.Clamp((float)(_pulseAcuteResponse * responseDecay + forced), 0f, Mathf.Max(0f, _pulseAcuteMaximum));
            _pulseAcuteDrive *= (float)driveDecay;
        }

        /// <summary>Scaled time pauses every physiological phase. The source also owns hidden ECG history.</summary>
        public void TickPulse(float deltaTime)
        {
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime < 0f)
                throw new ArgumentOutOfRangeException(nameof(deltaTime));
            if (!HasPulse) { StopPulse(); TickEcgTrace(deltaTime); return; }
            if (deltaTime == 0f) return;
            bool restarting = _currentBpm == 0f;
            if (restarting) ResetPulseDynamics(RestingBpm);
            var injuries = ReadPulseInjuries();
            if (injuries.HasNewInjury(_pulseObservedInjuries)) RefreshAcutePulseReaction(_pulseAcuteInjuryPeak);
            _pulseObservedInjuries = injuries;
            float oldMean = _pulseMeanBpm, oldAcute = _pulseAcuteResponse;
            float meanTarget = CalculateMeanTargetBpm();
            if (_debugPulseOverride)
            {
                _pulseMeanBpm = meanTarget;
            }
            else
            {
                float response = meanTarget > _pulseMeanBpm ? _pulseRiseSeconds : _pulseFallSeconds;
                ValidatePulseSeconds(response);
                ValidatePulseSeconds(_pulseBreathingPeriodSeconds);
                _pulseMeanBpm = Mathf.Lerp(_pulseMeanBpm, meanTarget, (float)(1d - Math.Exp(-deltaTime / response)));
                _pulseBreathingPhase = (_pulseBreathingPhase + deltaTime * (Math.PI * 2d / _pulseBreathingPeriodSeconds)) % (Math.PI * 2d);
            }
            TickAcutePulse(deltaTime);
            _targetBpm = CalculateTargetBpm();
            float next = _debugPulseOverride ? meanTarget
                : Mathf.Clamp(_pulseMeanBpm + AcutePulseBonus + PulseBreathingOffset, MinimumBpm, MaximumBpm);
            // Respiratory phase is procedural and must not force a save on every otherwise idle frame.
            if (oldMean != _pulseMeanBpm || oldAcute != _pulseAcuteResponse || restarting) IsDirty = true;
            if (next != _currentBpm || restarting)
            {
                _currentBpm = next;
                OnPulseChanged?.Invoke(_currentBpm);
            }
            TickEcgTrace(deltaTime);
        }

        private void TickEcgTrace(float deltaTime)
        {
            bool hasPulse = HasPulse;
            if (hasPulse != _ecgHasPulse)
            {
                _pulseTrace.Reset();
                _ecgHasPulse = hasPulse;
            }
            float bpm = CurrentBpm;
            // Normalized sweep units let each monitor retain its own Canvas pixels/second setting.
            float speed = Mathf.Sqrt(Mathf.Max(MinimumBpm, bpm) / RestingBpm);
            _pulseTrace.Tick(deltaTime, bpm, speed, hasPulse);
        }

        private void StopPulse()
        {
            _targetBpm = 0f;
            _pulseMeanBpm = 0f;
            _pulseAcuteDrive = 0f;
            _pulseAcuteResponse = 0f;
            if (_ecgHasPulse)
            {
                _pulseTrace.Reset();
                _ecgHasPulse = false;
            }
            if (_currentBpm == 0f) return;
            _currentBpm = 0f;
            IsDirty = true;
            OnPulseChanged?.Invoke(0f);
        }

        public void OnAfterLoad()
        {
            // Health may load before or after vitality; normalize only after every payload is applied.
            _currentBpm = CurrentBpm;
            ResetPulseDynamics(_currentBpm);
            _targetBpm = TargetBpm;
            _pulseTrace.Reset();
            _ecgHasPulse = HasPulse;
            OnPulseChanged?.Invoke(_currentBpm);
        }

        // =====================================================================
        // ONDESTROY — ОЧИСТКА РЕСУРСОВ (ИСПРАВЛЕНИЕ УТЕЧЕК)
        // =====================================================================
        private void OnDestroy()
        {
            if (_cachedHealth != null)
            {
                _cachedHealth.OnDeath -= StopPulse;
                _cachedHealth.OnDamageTaken -= OnPulseDamageTaken;
                _cachedHealth.OnSegmentDamageApplied -= OnPulseDamageTaken;
            }
            OnPulseChanged = null;
            _activeSafeZones.Clear();
            if (_subscribedTimeSystem != null)
                _subscribedTimeSystem.OnPhaseChanged -= OnTimePhaseChanged;
            _subscribedTimeSystem = null;
            _subscribedToTime = false;
            // Остановка корутин
            if (_tickerCoroutine != null) StopCoroutine(_tickerCoroutine);
            if (_temperatureLerpCoroutine != null) StopCoroutine(_temperatureLerpCoroutine);

            // Отписка от событий времени
            if (K_TimeSystem.Instance != null)
                K_TimeSystem.Instance.OnPhaseChanged -= OnTimePhaseChanged;

            // Очистка декалей крови (ИСПРАВЛЕНИЕ УТЕЧКИ)
            foreach (var decal in _spawnedBloodDecals)
            {
                if (decal != null) Destroy(decal);
            }
            _spawnedBloodDecals.Clear();

            // Отписка от SaveManager (ИСПРАВЛЕНИЕ УТЕЧКИ)
            if (K_SaveManager.Instance != null)
                K_SaveManager.Instance.Unregister(this);
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            _radiation = ValidateRadiation(_radiation);
            if (_cachedHealth != null && Application.isPlaying && Mathf.Abs(_radiation - _previousRadiation) > 0.1f)
            {
                if (HasRadiationImmunity && _radiation > _previousRadiation)
                {
                    _radiation = _previousRadiation;
                    Debug.Log("[Vitality] Radiation immunity blocked manual increase");
                    _previousRadiation = _radiation;
                    return;
                }
                Debug.Log($"[Vitality] Radiation changed in Inspector: {_previousRadiation:F1}% → {_radiation:F1}%");
                ApplyRadiationToHealth();
                _previousRadiation = _radiation;
            }
        }
#endif

        // =====================================================================
        // ОСНОВНОЙ ТИК
        // =====================================================================
        private IEnumerator StatsTick()
        {
            WaitForSeconds waitOneSecond = new WaitForSeconds(METABOLISM_TICK_RATE);
            while (true)
            {
                yield return waitOneSecond;
                // Keep the ticker alive so loading a living save resumes metabolism.
                if (_cachedHealth != null && _cachedHealth.IsDead) continue;
                ProcessMetabolism();
                UpdateDebuffs(METABOLISM_TICK_RATE);
                UpdateTemperature(METABOLISM_TICK_RATE);
                if (_cachedHealth != null && _cachedHealth.GetMaxBleedingLevel() >= 3)
                    HandleBloodDecals();
                NotifyChange();
            }
        }

        // =====================================================================
        // МЕТАБОЛИЗМ
        // =====================================================================
        private void ProcessMetabolism()
        {
            float zoneMultiplier = _isInSafeZone ? _safeZoneMetabolismMultiplier : 1.0f;
            float radiationMultiplier = 1.0f + (_radiation / 100f) * (RADIATION_METABOLISM_MULTIPLIER - 1.0f);
            float thirstDecayPerTick = (MAX_VITALITY / THIRST_DECAY_TIME) * zoneMultiplier * radiationMultiplier;
            float hungerDecayPerTick = (MAX_VITALITY / HUNGER_DECAY_TIME) * zoneMultiplier * radiationMultiplier;

            if (_thirst > MIN_VITALITY)
                _thirst = Mathf.Max(_thirst - thirstDecayPerTick, MIN_VITALITY);
            else if (_cachedHealth != null)
                _cachedHealth.TakeMetabolismDamage(THIRST_DAMAGE_PER_SEC, BodyPart.Stomach);

            if (_hunger > MIN_VITALITY)
                _hunger = Mathf.Max(_hunger - hungerDecayPerTick, MIN_VITALITY);
            else if (_cachedHealth != null)
                _cachedHealth.TakeMetabolismDamage(HUNGER_DAMAGE_PER_SEC, BodyPart.Stomach);
        }

        // =====================================================================
        // СТИМУЛЯТОР
        // =====================================================================
        private void UpdateStimulatorTimers(float deltaTime)
        {
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime <= 0f) return;
            bool phaseChanged = false;
            // Consume the remainder after each boundary: a long frame must not extend any phase.
            while (deltaTime > 0f && !IsStimReady)
            {
                if (_stimulatorTimer > 0f)
                {
                    float consumed = Mathf.Min(deltaTime, _stimulatorTimer);
                    _stimulatorTimer -= consumed;
                    deltaTime -= consumed;
                    if (_stimulatorTimer <= 0f)
                    {
                        _stimOffTimer = STIM_OFF_DURATION;
                        phaseChanged = true;
                        Debug.Log("[Vitality] STIM OFF: Neutral cooldown (200s)");
                    }
                }
                else if (_stimOffTimer > 0f)
                {
                    float consumed = Mathf.Min(deltaTime, _stimOffTimer);
                    _stimOffTimer -= consumed;
                    deltaTime -= consumed;
                    if (_stimOffTimer <= 0f)
                    {
                        _fatigueTimer = FATIGUE_DURATION;
                        phaseChanged = true;
                        Debug.Log($"[Vitality] Fatigue started ({FATIGUE_DURATION}s)");
                    }
                }
                else
                {
                    float consumed = Mathf.Min(deltaTime, _fatigueTimer);
                    _fatigueTimer -= consumed;
                    deltaTime -= consumed;
                    if (_fatigueTimer <= 0f)
                    {
                        phaseChanged = true;
                        Debug.Log("[Vitality] Fatigue ended. Stimulator fully ready.");
                    }
                }
            }
            if (phaseChanged) OnStimulatorChanged?.Invoke();
        }

        private void ResetStimulatorEffects()
        {
            _stimulatorTimer = 0f;
            _stimOffTimer = 0f;
            _fatigueTimer = 0f;
        }

        // =====================================================================
        // ДЕБАФФЫ
        // =====================================================================
        private void UpdateDebuffs(float deltaTime)
        {
            if (_alcoholConcentration > 0f)
            {
                _alcoholConcentration -= 0.00083f * deltaTime;
                _alcoholConcentration = Mathf.Max(_alcoholConcentration, 0f);
            }

            if (_drunkTimer > 0f)
            {
                _drunkTimer -= deltaTime;
                if (_drunkTimer <= 0f)
                {
                    _drunkTimer = 0f;
                    _hangoverTimer = _pendingHangoverSeconds;
                    _pendingHangoverSeconds = 0f;
                    Debug.Log($"[Vitality] Hangover started ({_hangoverTimer:F1}s)");
                    OnHangoverChanged?.Invoke();
                    // Activation starts at this boundary; do not charge the same drunk tick twice.
                    return;
                }
            }

            if (_hangoverTimer > 0f)
            {
                _hangoverTimer -= deltaTime;
                if (_hangoverTimer <= 0f)
                {
                    _hangoverTimer = 0f;
                    Debug.Log("[Vitality] Hangover ended");
                }
                OnHangoverChanged?.Invoke();
            }
        }

        // =====================================================================
        // ТЕМПЕРАТУРА И ХОЛОД
        // =====================================================================
        private void UpdateTemperature(float deltaTime)
        {
            float alcoholThresholdOffset = GetColdThresholdOffset();
            float effectiveThreshold = COLD_LETHAL_THRESHOLD - alcoholThresholdOffset;

            if (_currentTemperature <= effectiveThreshold)
            {
                float delta = Mathf.Abs(_currentTemperature) - Mathf.Abs(effectiveThreshold);
                _coldExposure += delta * COLD_EXPOSURE_GAIN_RATE * deltaTime;
                _coldExposure = Mathf.Clamp01(_coldExposure);
                if (_coldExposure > 0f) OnColdExposureChanged?.Invoke();
              if (IsColdCritical) ApplyColdDamage(_coldDamagePerSec * deltaTime);
            }
            else if (_coldExposure > 0f)
            {
                if (_isInSafeZone)
                {
                    _coldExposure -= deltaTime / _safeZoneColdRecoveryTime;
                    _coldExposure = Mathf.Max(0f, _coldExposure);
                    if (_coldExposure <= 0f)
                        Debug.Log($"[Vitality] Safe Zone: Cold exposure fully recovered ({_safeZoneColdRecoveryTime}s)");
                }
                else
                {
                    _coldExposure -= deltaTime * 0.01f;
                    _coldExposure = Mathf.Max(0f, _coldExposure);
                }
                OnColdExposureChanged?.Invoke();
            }
        }

             /// <summary>
        /// Stage 1 §8.3: распределение общего урона холода по 10 парам.
        /// Пока жива хоть одна пара: 1% голова, 1% грудь, 98% — пропорционально
        /// весам живых пар. Внутри пары: 50/50 (обе живы), 100% (одна жива).
        /// Все 10 пар мертвы: 30% голова, 70% грудь.
        /// </summary>
        private void ApplyColdDamage(float totalDamage)
        {
            if (_cachedHealth == null) return;
            if (totalDamage <= 0f) return;

            int n = ColdPairLayout.Length;
            float wAlive = 0f;
            var aAlive    = new bool[n];
            var bAlive    = new bool[n];
            var pairAlive = new bool[n];

            for (int i = 0; i < n; i++)
            {
                var (a, b, isPair) = ColdPairLayout[i];
                float hpA = _cachedHealth.GetHP(a);
                float hpB = isPair ? _cachedHealth.GetHP(b) : hpA;
                aAlive[i]    = hpA > 0f;
                bAlive[i]    = isPair ? hpB > 0f : hpA > 0f;
                pairAlive[i] = isPair ? (aAlive[i] || bAlive[i]) : aAlive[i];
                if (pairAlive[i]) wAlive += _coldPairWeights[i];
            }

            _cachedHealth.BeginColdDamageBatch();

            if (wAlive <= 0f)
            {
                _cachedHealth.ApplyColdDamageToSegment(BodyPart.Head,  totalDamage * _coldHeadPercentFinal);
                _cachedHealth.ApplyColdDamageToSegment(BodyPart.Chest, totalDamage * _coldChestPercentFinal);
                _cachedHealth.FinishColdDamageBatch();
                return;
            }

            _cachedHealth.ApplyColdDamageToSegment(BodyPart.Head,  totalDamage * _coldHeadPercentAlive);
            _cachedHealth.ApplyColdDamageToSegment(BodyPart.Chest, totalDamage * _coldChestPercentAlive);

            float pairPool = totalDamage * (1f - _coldHeadPercentAlive - _coldChestPercentAlive);

            for (int i = 0; i < n; i++)
            {
                if (!pairAlive[i]) continue;
                var (a, b, isPair) = ColdPairLayout[i];
                float pairDmg = (_coldPairWeights[i] / wAlive) * pairPool;

                if (!isPair)
                {
                    _cachedHealth.ApplyColdDamageToSegment(a, pairDmg);
                }
                else if (aAlive[i] && bAlive[i])
                {
                    _cachedHealth.ApplyColdDamageToSegment(a, pairDmg * 0.5f);
                    _cachedHealth.ApplyColdDamageToSegment(b, pairDmg * 0.5f);
                }
                else if (aAlive[i]) _cachedHealth.ApplyColdDamageToSegment(a, pairDmg);
                else if (bAlive[i]) _cachedHealth.ApplyColdDamageToSegment(b, pairDmg);
            }

            _cachedHealth.FinishColdDamageBatch();
        }

        // =====================================================================
        // СМЕНА ФАЗЫ ВРЕМЕНИ (ИСПРАВЛЕНИЕ: ОТСЛЕЖИВАНИЕ КОРУТИНЫ)
        // =====================================================================
        private void TrySubscribeToTime()
        {
            if (_subscribedToTime || K_TimeSystem.Instance == null) return;
            var timeSystem = K_TimeSystem.Instance;
            // Awake may already own this handler; normalize it without changing Awake.
            timeSystem.OnPhaseChanged -= OnTimePhaseChanged;
            timeSystem.OnPhaseChanged += OnTimePhaseChanged;
            _subscribedTimeSystem = timeSystem;
            _subscribedToTime = true;
            OnTimePhaseChanged(timeSystem.CurrentPhase);
        }

        private void OnTimePhaseChanged(K_Incident.Core.TimePhase phase)
        {
            float targetTemp = phase switch
            {
                K_Incident.Core.TimePhase.Night => UnityEngine.Random.Range(-40f, -30f),
                K_Incident.Core.TimePhase.Morning => UnityEngine.Random.Range(-24f, -20f),
                K_Incident.Core.TimePhase.Day => UnityEngine.Random.Range(-20f, -15f),
                K_Incident.Core.TimePhase.Evening => UnityEngine.Random.Range(-25f, -20f),
                _ => -25f
            };

            // Останавливаем предыдущую корутину если есть
            if (_temperatureLerpCoroutine != null) StopCoroutine(_temperatureLerpCoroutine);
            _temperatureLerpCoroutine = StartCoroutine(TemperatureLerpRoutine(targetTemp));
        }

        private IEnumerator TemperatureLerpRoutine(float targetTemp)
        {
            float startTemp = _currentTemperature;
            float duration = 120f;
            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                _currentTemperature = Mathf.Lerp(startTemp, targetTemp, elapsed / duration);
                yield return null;
            }
            _currentTemperature = targetTemp;
            _temperatureLerpCoroutine = null; // Очищаем ссылку после завершения
            Debug.Log($"[Vitality] Temperature transition complete: {targetTemp:F1}°C");
        }

        // =====================================================================
        // КРОВЬ (ИСПРАВЛЕНИЕ: ОТСЛЕЖИВАНИЕ ДЕКАЛЕЙ)
        // =====================================================================
        private void HandleBloodDecals()
        {
            if (_bloodDecalPrefab == null) return;
            _bloodDecalTimer += METABOLISM_TICK_RATE;
            if (_bloodDecalTimer >= 2.0f)
            {
                _bloodDecalTimer = 0f;
                SpawnBloodDecal();
            }
        }

        private void SpawnBloodDecal()
        {
            if (Physics.Raycast(transform.position + Vector3.up * 0.5f, Vector3.down, out RaycastHit hit, 2.0f))
            {
                GameObject decal = Instantiate(_bloodDecalPrefab, hit.point + Vector3.up * 0.01f, Quaternion.LookRotation(hit.normal));
                _spawnedBloodDecals.Add(decal); // ДОБАВЛЕНО: отслеживаем созданный декаль

                // Авто-удаление через 30 секунд чтобы не засорять память
                Destroy(decal, 30f);

                // Очищаем список от уничтоженных объектов
                _spawnedBloodDecals.RemoveAll(d => d == null);
            }
        }

        // =====================================================================
        // СТИМУЛЯТОР
        // =====================================================================
        public void UseStimulatorEnhanced()
        {
            if (_stimulatorTimer > 0f || _stimOffTimer > 0f || _fatigueTimer > 0f)
            {
                Debug.Log($"[Vitality] Stimulator on cooldown! {_stimOffTimer + _fatigueTimer:F1}s remaining");
                return;
            }
            _stimulatorTimer = STIM_ON_DURATION;
            Debug.Log("[Vitality] STIM ON: Enhanced perception (85s)");
            OnStimulatorChanged?.Invoke();
            NotifyChange();
        }

        // =====================================================================
        // АЛКОГОЛЬНАЯ СИСТЕМА
        // =====================================================================
        public void ConsumeVodka(float volumeMl)
        {
            if (float.IsNaN(volumeMl) || float.IsInfinity(volumeMl) || volumeMl <= 0f) return;
            float concentrationGain = volumeMl / 1000f;
            _alcoholConcentration = Mathf.Min(_alcoholConcentration + concentrationGain, 1.0f);
            _drunkTimer = 120f;
            _hangoverTimer = 0f;
            _totalAlcoholConsumed += volumeMl;
            AccumulateAlcoholHangover(volumeMl);
            float radiationReduction = (volumeMl / 100f) * ALCOHOL_RADIATION_REDUCTION_PER_100ML;
            if (_cachedHealth != null)
            {
                float currentRad = _radiation;
                _radiation = Mathf.Max(_radiation - radiationReduction, 0f);
                Debug.Log($"[Vitality] Vodka consumed: {volumeMl}ml | Radiation: {currentRad:F1} → {_radiation:F1} (-{radiationReduction:F1})");
                ApplyRadiationToHealth();
            }
            if (_totalAlcoholConsumed >= 4000f) TriggerBlackout();
            Debug.Log($"[Vitality] Vodka: {volumeMl}ml | Concentration: {_alcoholConcentration:F2} | Total: {_totalAlcoholConsumed:F0}ml | Immunity: {(HasRadiationImmunity ? "ACTIVE" : "NONE")}");
            NotifyChange();
        }

        private void TriggerBlackout()
        {
            Debug.LogWarning("[Vitality] BLACKOUT TRIGGERED! 4+ liters consumed!");
            _totalAlcoholConsumed = 0f;
            _alcoholConcentration = 0f;
            _pendingHangoverSeconds = BLACKOUT_HANGOVER_DURATION;
            Debug.Log($"[Vitality] Blackout: pending hangover ({BLACKOUT_HANGOVER_DURATION}s), waiting for intoxication to end.");
            if (_deathRollsRemaining == 0)
            {
                ValidateDeathRollConfiguration();
                _deathRollsRemaining = 3;
                _deathRollTimer = _deathRollInterval;
                IsDirty = true;
            }
        }

        private void TickDeathRolls(float deltaTime)
        {
            if (_cachedHealth == null || _cachedHealth.IsDead) return;
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime <= 0f) return;
            ValidateDeathRollState();
            if (_deathRollsRemaining == 0) return;
            ValidateDeathRollConfiguration();

            _deathRollTimer -= deltaTime;
            IsDirty = true;
            if (_deathRollTimer > 0f) return;

            int rollNumber = 4 - _deathRollsRemaining;
            float sample = UnityEngine.Random.value;
            bool died = _deathRollChance >= 1f || sample < _deathRollChance;
            _deathRollsRemaining--;
            _deathRollTimer = _deathRollInterval;
            if (died)
            {
                // Publish inactive state before ForceDeath and its synchronous callbacks.
                _deathRollsRemaining = 0;
                _deathRollTimer = 0f;
                Debug.LogWarning($"[Vitality] Death roll {rollNumber}/3 — DEATH");
                _cachedHealth.ForceDeath();
                return;
            }

            if (_deathRollsRemaining == 0) _deathRollTimer = 0f;
            Debug.LogWarning($"[Vitality] Death roll {rollNumber}/3 — survived");
        }

        private void ValidateDeathRollConfiguration()
        {
            if (float.IsNaN(_deathRollChance) || float.IsInfinity(_deathRollChance)
                || _deathRollChance < 0f || _deathRollChance > 1f)
                throw new InvalidOperationException("Death roll chance must be finite and between zero and one.");
            if (float.IsNaN(_deathRollInterval) || float.IsInfinity(_deathRollInterval) || _deathRollInterval <= 0f)
                throw new InvalidOperationException("Death roll interval must be finite and positive.");
        }

        private void ValidateDeathRollState()
        {
            if (_deathRollsRemaining < 0 || _deathRollsRemaining > 3
                || float.IsNaN(_deathRollTimer) || float.IsInfinity(_deathRollTimer) || _deathRollTimer < 0f
                || (_deathRollsRemaining == 0 && _deathRollTimer != 0f))
                throw new InvalidOperationException("Death roll state must contain zero/zero or one to three rolls and a finite nonnegative timer.");
        }

        private void ValidateDeathRollSaveState()
        {
            ValidateDeathRollState();
            if (!IsValidSavedBpm(CurrentBpm))
                throw new InvalidOperationException("Pulse must be zero on death or finite and between 40 and 200 BPM.");
            if (float.IsNaN(_pendingHangoverSeconds) || float.IsInfinity(_pendingHangoverSeconds) || _pendingHangoverSeconds < 0f)
                throw new InvalidOperationException("Pending hangover must be finite and nonnegative.");
        }

        private static void ValidateDeathRollPayload(BinaryReader reader)
        {
            if (K_SaveManager.LoadedSchemaRevision < 5) return;
            long start = reader.BaseStream.Position;
            long length = reader.BaseStream.Length - start;
            if (length != 50 && length != 54 && length != 62 && length != 66)
                throw new InvalidDataException("Vitality payload must contain exactly 50, 54, 62 or 66 bytes.");
            if (length == 50) return;
            try
            {
                reader.BaseStream.Position = start + 50;
                float pending = reader.ReadSingle();
                if (float.IsNaN(pending) || float.IsInfinity(pending) || pending < 0f)
                    throw new InvalidDataException("Pending hangover must be finite and nonnegative.");
                if (length >= 62)
                {
                    int rolls = reader.ReadInt32();
                    float timer = reader.ReadSingle();
                    int minRolls = length == 66 ? 0 : 1;
                    if (rolls < minRolls || rolls > 3 || float.IsNaN(timer) || float.IsInfinity(timer) || timer < 0f ||
                        (rolls == 0 && timer != 0f))
                        throw new InvalidDataException("Death roll payload must contain valid active rolls or zero/zero in the pulse-extended layout.");
                }
                if (length == 66 && !IsValidSavedBpm(reader.ReadSingle()))
                    throw new InvalidDataException("Saved pulse must be zero or finite and between 40 and 200 BPM.");
            }
            finally { reader.BaseStream.Position = start; }
        }

        private static bool IsValidSavedBpm(float bpm) =>
            !float.IsNaN(bpm) && !float.IsInfinity(bpm) && (bpm == 0f || (bpm >= MinimumBpm && bpm <= MaximumBpm));

        private void LoadDeathRollState(BinaryReader reader)
        {
            _deathRollsRemaining = 0;
            _deathRollTimer = 0f;
            if (K_SaveManager.LoadedSchemaRevision >= 5 && reader.BaseStream.Position < reader.BaseStream.Length)
            {
                _deathRollsRemaining = reader.ReadInt32();
                _deathRollTimer = reader.ReadSingle();
            }
        }

        private void AccumulateAlcoholHangover(float volumeMl)
        {
            float duration = volumeMl / 1000f * 60f;
            if (IsDrunk) _pendingHangoverSeconds += duration;
            else _hangoverTimer += duration;
        }

        public float GetColdThresholdOffset() => _alcoholConcentration > 0f ? ALCOHOL_COLD_THRESHOLD_OFFSET : 0f;

        // =====================================================================
        // ХОЛОД, ПЕРЕГРУЗ, ПОТРЕБЛЕНИЕ
        // =====================================================================
        public void SetColdExposure(float exposure)
        {
            _coldExposure = Mathf.Clamp01(exposure);
            OnColdExposureChanged?.Invoke();
            NotifyChange();
            if (_coldExposure >= 1.0f) Debug.Log("[Vitality] CRITICAL FROSTBITE!");
        }

        public void SetTemperature(float temp)
        {
            _currentTemperature = temp;
            Debug.Log($"[Vitality] Temperature set to {temp:F1}°C");
        }

        public void SetOverload(bool overloaded)
        {
            if (_isOverloaded != overloaded)
            {
                _isOverloaded = overloaded;
                Debug.Log($"[Vitality] Overload: {(_isOverloaded ? "ON" : "OFF")}");
                OnOverloadChanged?.Invoke();
                NotifyChange();
            }
        }

        public void ConsumeFoodWater(float food, float water)
        {
            _hunger = Mathf.Clamp(_hunger + food, MIN_VITALITY, MAX_VITALITY);
            _thirst = Mathf.Clamp(_thirst + water, MIN_VITALITY, MAX_VITALITY);
            NotifyChange();
        }

        public void AddRadiation(float amount)
        {
            // A non-finite scale/input must never enter the health or save paths.
            if (float.IsNaN(amount) || float.IsInfinity(amount))
            {
                _radiation = ValidateRadiation(amount);
                ApplyRadiationToHealth();
                NotifyChange();
                return;
            }
            float previousRadiation = _radiation;
            _radiation = ValidateRadiation(_radiation);
            if (HasRadiationImmunity)
            {
                if (_radiation != previousRadiation)
                {
                    ApplyRadiationToHealth();
                    NotifyChange();
                }
                Debug.Log("[Vitality] Radiation immunity active — radiation blocked");
                return;
            }
            _radiation = Mathf.Clamp(_radiation + amount, MIN_VITALITY, MAX_VITALITY);
            Debug.Log($"[Vitality] Radiation added: {amount:F1}% → Total: {_radiation:F1}%");
            ApplyRadiationToHealth();
            NotifyChange();
        }

        /// <summary>Remove a fixed number of percentage points; alcohol immunity does not block treatment.</summary>
        public void ApplyAntiRad(float percent)
        {
            if (float.IsNaN(percent) || float.IsInfinity(percent))
                _radiation = ValidateRadiation(percent);
            else
                _radiation = Mathf.Max(0f, ValidateRadiation(_radiation) - Mathf.Max(0f, percent));
            ApplyRadiationToHealth();
            NotifyChange();
        }

        private static float ValidateRadiation(float value)
        {
            if (float.IsNaN(value) || float.IsInfinity(value))
            {
                Debug.LogError("[Vitality] Radiation must be finite; reset to 0%.");
                return 0f;
            }
            return Mathf.Clamp(value, MIN_VITALITY, MAX_VITALITY);
        }

        private void ApplyRadiationToHealth()
        {
            _radiation = ValidateRadiation(_radiation);
            if (_cachedHealth == null) return;
            if (_radiation >= MAX_VITALITY)
                _cachedHealth.ApplyRadiationClamp(_radiation);
            else
            {
                _cachedHealth.ApplyRadiationMaxHPReduction(_radiation);
                UpdateRadiationBleeding();
            }
            _lastAppliedRadiation = _radiation;
        }

        private void UpdateRadiationBleeding()
        {
            if (_radiation < 75f)
            {
                _radiationBleedActive = false;
                return;
            }
            if (_radiationBleedActive || _cachedHealth == null || _cachedHealth.IsDead) return;
            _radiationBleedActive = true;
            BodyPart part = (BodyPart)UnityEngine.Random.Range(0, 20);
            int current = _cachedHealth.GetBleedingLevel(part);
            _cachedHealth.SetBleedingLevelOnPart(part, Mathf.Max(current, 1));
        }

        private void UpdateRadiationDecay(float deltaTime)
        {
            float previous = _radiation;
            _radiation = ValidateRadiation(_radiation);
            // Check fatal exposure before removing any amount, including a long-frame decay.
            if (_radiation >= MAX_VITALITY)
            {
                ApplyRadiationToHealth();
                return;
            }
            UpdateRadiationBleeding();
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime < 0f)
            {
                Debug.LogError("[Vitality] Radiation decay deltaTime must be finite and nonnegative.");
                deltaTime = 0f;
            }
            if (float.IsNaN(_radiationDecayPerSecond) || float.IsInfinity(_radiationDecayPerSecond)
                || _radiationDecayPerSecond < 0f)
            {
                Debug.LogError("[Vitality] Radiation decay rate must be finite and nonnegative; disabled.");
                _radiationDecayPerSecond = 0f;
            }
            _radiation = Mathf.Max(0f, _radiation - _radiationDecayPerSecond * deltaTime);
            UpdateRadiationBleeding();
            if (_radiation != previous) IsDirty = true;
            // Compare to the last applied value, not this frame: tiny steps accumulate.
            if (float.IsNaN(_lastAppliedRadiation)
                || Mathf.Abs(_radiation - _lastAppliedRadiation) >= RADIATION_HEALTH_UPDATE_EPSILON
                || (_radiation == 0f && previous != 0f))
            {
                ApplyRadiationToHealth();
                NotifyChange();
            }
        }

        public void SetSafeZoneState(bool isSafe)
        {
            SetSafeZoneState(_manualSafeZoneSource, isSafe,
                SAFE_ZONE_COLD_RECOVERY_TIME, SAFE_ZONE_MULTIPLIER);
        }

        /// <summary>Last entered active zone supplies settings; leaving it restores the previous zone.</summary>
        public void SetSafeZoneState(object source, bool isSafe, float coldRecoveryTime = SAFE_ZONE_COLD_RECOVERY_TIME,
            float metabolismMultiplier = SAFE_ZONE_MULTIPLIER)
        {
            if (source == null) throw new ArgumentNullException(nameof(source));
            if (float.IsNaN(coldRecoveryTime) || float.IsInfinity(coldRecoveryTime) || coldRecoveryTime <= 0f)
                throw new ArgumentOutOfRangeException(nameof(coldRecoveryTime));
            if (float.IsNaN(metabolismMultiplier) || float.IsInfinity(metabolismMultiplier) || metabolismMultiplier < 0f)
                throw new ArgumentOutOfRangeException(nameof(metabolismMultiplier));
            int index = _activeSafeZones.FindIndex(zone => ReferenceEquals(zone.Source, source));
            if (isSafe)
            {
                if (index >= 0)
                {
                    _activeSafeZones[index].ColdRecoveryTime = coldRecoveryTime;
                    _activeSafeZones[index].MetabolismMultiplier = metabolismMultiplier;
                }
                else _activeSafeZones.Add(new ActiveSafeZone
                {
                    Source = source, ColdRecoveryTime = coldRecoveryTime, MetabolismMultiplier = metabolismMultiplier
                });
            }
            else
            {
                if (index < 0)
                {
                    if (!ReferenceEquals(source, _manualSafeZoneSource) || _activeSafeZones.Count > 0 || !_isInSafeZone) return;
                }
                else _activeSafeZones.RemoveAt(index);
            }
            ApplyActiveSafeZoneSettings();
            Debug.Log($"[Vitality] Safe Zone: {(_isInSafeZone ? "ENTERED" : "LEFT")} " +
                $"(active={_activeSafeZones.Count}, metabolism={_safeZoneMetabolismMultiplier}, cold={_safeZoneColdRecoveryTime}s)");
            NotifyChange();
        }

        private void ApplyActiveSafeZoneSettings()
        {
            _isInSafeZone = _activeSafeZones.Count > 0;
            var effective = _isInSafeZone ? _activeSafeZones[_activeSafeZones.Count - 1] : null;
            _safeZoneColdRecoveryTime = effective != null ? effective.ColdRecoveryTime : SAFE_ZONE_COLD_RECOVERY_TIME;
            _safeZoneMetabolismMultiplier = effective != null ? effective.MetabolismMultiplier : SAFE_ZONE_MULTIPLIER;
        }

        // =====================================================================
        // УВЕДОМЛЕНИЯ И СОХРАНЕНИЕ
        // =====================================================================
        private void NotifyChange()
        {
            IsDirty = true;
            OnMetabolismChanged?.Invoke();
        }

        public void Save(BinaryWriter writer)
        {
            ValidateDeathRollSaveState();
            writer.Write(_hunger); writer.Write(_thirst); writer.Write(_radiation);
            // Retain the V10/rev6 slots; temporary stimulant phases never survive a save/load.
            writer.Write(0f); writer.Write(0f); writer.Write(0f);
            writer.Write(_alcoholConcentration); writer.Write(_drunkTimer); writer.Write(_hangoverTimer);
            writer.Write(_totalAlcoholConsumed); writer.Write(_coldExposure); writer.Write(_isOverloaded);
            writer.Write(_currentTemperature); writer.Write(_isInSafeZone);
            // Preserve the legacy 50-byte layout when the optional value is its zero default.
            bool hasPulseTail = CurrentBpm != RestingBpm;
            if (_pendingHangoverSeconds != 0f || hasPulseTail) writer.Write(_pendingHangoverSeconds);
            if (_deathRollsRemaining > 0 || hasPulseTail)
            {
                if (_pendingHangoverSeconds == 0f && !hasPulseTail) writer.Write(0f);
                writer.Write(_deathRollsRemaining);
                writer.Write(_deathRollTimer);
            }
            // Fixed offset 62 avoids ambiguity with the existing optional hangover float at offset 50.
            if (hasPulseTail) writer.Write(CurrentBpm);
        }

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            ValidateDeathRollPayload(reader);
            for (int i = 0; i < 11; i++) SaveLoadValidationContext.ReadFinite(reader);
            reader.ReadBoolean();
            SaveLoadValidationContext.ReadFinite(reader);
            reader.ReadBoolean();
            if (K_SaveManager.LoadedSchemaRevision >= 5 && reader.BaseStream.Position < reader.BaseStream.Length)
                SaveLoadValidationContext.ReadFinite(reader, true);
            if (K_SaveManager.LoadedSchemaRevision >= 5 && reader.BaseStream.Position < reader.BaseStream.Length)
            {
                int rolls = reader.ReadInt32();
                if (rolls < 0 || rolls > 3) throw new InvalidDataException("Invalid saved death roll count.");
                SaveLoadValidationContext.ReadFinite(reader, true);
            }
            if (K_SaveManager.LoadedSchemaRevision >= 5 && reader.BaseStream.Position < reader.BaseStream.Length)
                reader.ReadSingle(); // Range/finite checked by the read-only preflight above.
        }

        public void Load(BinaryReader reader)
        {
            ValidateDeathRollPayload(reader);
            // Audit H06: a transition belongs to the previous timeline, never to the loaded temperature.
            if (_temperatureLerpCoroutine != null)
            {
                StopCoroutine(_temperatureLerpCoroutine);
                _temperatureLerpCoroutine = null;
            }
            _hunger = reader.ReadSingle(); _thirst = reader.ReadSingle(); _radiation = reader.ReadSingle();
            reader.ReadSingle(); reader.ReadSingle(); reader.ReadSingle();
            ResetStimulatorEffects();
            _alcoholConcentration = reader.ReadSingle(); _drunkTimer = reader.ReadSingle(); _hangoverTimer = reader.ReadSingle();
            _totalAlcoholConsumed = reader.ReadSingle(); _coldExposure = reader.ReadSingle(); _isOverloaded = reader.ReadBoolean();
            _currentTemperature = reader.ReadSingle(); _isInSafeZone = reader.ReadBoolean();
            // Scene memberships are runtime references; keep currently overlapping
            // zone settings authoritative when loading the historical boolean slot.
            _activeSafeZones.RemoveAll(zone => ReferenceEquals(zone.Source, _manualSafeZoneSource));
            if (_activeSafeZones.Count > 0) ApplyActiveSafeZoneSettings();
            else
            {
                _safeZoneColdRecoveryTime = SAFE_ZONE_COLD_RECOVERY_TIME;
                _safeZoneMetabolismMultiplier = SAFE_ZONE_MULTIPLIER;
            }
            // Revision 4 is unframed: bytes after this record belong to the next section.
            // Framed records append pending hangover, optional death rolls, then optional BPM.
            _pendingHangoverSeconds = 0f;
            if (K_SaveManager.LoadedSchemaRevision >= 5 && reader.BaseStream.Position < reader.BaseStream.Length)
                _pendingHangoverSeconds = reader.ReadSingle();
            LoadDeathRollState(reader);
            _currentBpm = RestingBpm;
            if (K_SaveManager.LoadedSchemaRevision >= 5 && reader.BaseStream.Position < reader.BaseStream.Length)
                _currentBpm = reader.ReadSingle();
            ResetPulseDynamics(_currentBpm);
            _targetBpm = _currentBpm;
            _radiation = ValidateRadiation(_radiation);
            // Segment bleeding is loaded separately. Restore the latch without adding a new wound.
            _radiationBleedActive = _radiation >= 75f;
            _lastAppliedRadiation = float.NaN;
            // K_HealthSystem.OnAfterLoad restores radiation limits before saved HP.
            OnStimulatorChanged?.Invoke();
            NotifyChange();
            OnPulseChanged?.Invoke(CurrentBpm);
        }

        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Debug: Use Stimulator")] public void DebugStim() => UseStimulatorEnhanced();
        [ContextMenu("Debug: Print Pulse")]
        public void DebugPrintPulse() => Debug.Log($"[Pulse] current={CurrentBpm:F1} BPM, target={TargetBpm:F1} BPM, bleeding x{PulseBleedingMultiplier:F2}");
        [ContextMenu("Debug: Consume 500ml Vodka")] public void DebugVodka500() => ConsumeVodka(500f);
        [ContextMenu("Debug: Set Radiation 50")] public void DebugRad50() { _radiation = 50f; ApplyRadiationToHealth(); NotifyChange(); }
        [ContextMenu("Debug: Set Hunger 0")] public void DebugStarve() { _hunger = 0f; NotifyChange(); }
        [ContextMenu("Debug: Set Thirst 0")] public void DebugThirst() { _thirst = 0f; NotifyChange(); }
        [ContextMenu("Debug: Add 50 Radiation")] public void DebugRadiation() { AddRadiation(50f); }
        [ContextMenu("Debug: Set Cold Exposure 1.0")] public void DebugColdCritical() { SetColdExposure(1.0f); }
        [ContextMenu("Debug: Set Temperature -40")] public void DebugTempLethal() { SetTemperature(-40f); }
        [ContextMenu("Debug: Toggle Overload")] public void DebugOverload() { SetOverload(!_isOverloaded); }
        [ContextMenu("Debug: Enter Safe Zone")] public void DebugEnterSafeZone() { SetSafeZoneState(true); }
        [ContextMenu("Debug: Leave Safe Zone")] public void DebugLeaveSafeZone() { SetSafeZoneState(false); }
    }
}
