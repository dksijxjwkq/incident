using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>An explicit level-authored viral source. Ambient cold alone is not a source.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(BoxCollider), typeof(Rigidbody))]
    public sealed class K_ViralExposureZone : MonoBehaviour
    {
        [SerializeField, Min(0f), Tooltip("Сила явно заданного вирусного источника. 1 добавляет одну секунду контакта за секунду внутри зоны. 0 отключает заражение.")]
        private float _exposureMultiplier = 1f;

        private readonly Dictionary<K_IllnessSystem, float> _lastExposureStep = new Dictionary<K_IllnessSystem, float>();
        private readonly List<K_IllnessSystem> _staleOwners = new List<K_IllnessSystem>();
        private float _nextCleanup;

        private void OnTriggerStay(Collider other)
        {
            if (!isActiveAndEnabled || other == null || Time.timeScale <= 0f ||
                float.IsNaN(_exposureMultiplier) || float.IsInfinity(_exposureMultiplier) || _exposureMultiplier <= 0f) return;
            var health = other.GetComponentInParent<K_HealthSystem>();
            var illnesses = health != null && !health.IsDead ? health.Illnesses : null;
            if (illnesses == null) return;
            float step = Time.fixedTime;
            if (_lastExposureStep.TryGetValue(illnesses, out float previous) && previous == step) return;
            _lastExposureStep[illnesses] = step;
            illnesses.ReportViralExposure(Time.fixedDeltaTime * _exposureMultiplier);

            if (step < _nextCleanup) return;
            _nextCleanup = step + 10f;
            _staleOwners.Clear();
            foreach (var owner in _lastExposureStep)
                if (owner.Key == null || step - owner.Value > 1f) _staleOwners.Add(owner.Key);
            foreach (var owner in _staleOwners) _lastExposureStep.Remove(owner);
            _staleOwners.Clear();
        }

        private void OnDisable()
        {
            _lastExposureStep.Clear();
            _staleOwners.Clear();
            _nextCleanup = 0f;
        }

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            var box = GetComponent<BoxCollider>();
            if (box == null) return;
            var oldMatrix = Gizmos.matrix;
            var oldColor = Gizmos.color;
            Gizmos.matrix = transform.localToWorldMatrix;
            Gizmos.color = new Color(.45f,.75f,.8f,.8f);
            Gizmos.DrawWireCube(box.center, box.size);
            Gizmos.matrix = oldMatrix;
            Gizmos.color = oldColor;
        }
#endif
    }
}
