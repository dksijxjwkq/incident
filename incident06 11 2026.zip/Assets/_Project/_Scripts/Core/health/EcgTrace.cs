using System;

namespace K_Incident.Core
{
    /// <summary>Bounded ECG history sampled in game time. Rendering and UI lifecycle stay outside it.</summary>
    public sealed class EcgTrace
    {
        public readonly struct Point
        {
            public readonly double Distance;
            public readonly float Value;
            public Point(double distance, float value) { Distance = distance; Value = value; }
        }

        private const double SampleInterval = 1d / 120d;
        private readonly Point[] _points;
        private int _next;
        private double _carry;
        private double _phase;
        public int Count { get; private set; }
        public double Distance { get; private set; }

        public EcgTrace(int capacity = 1024)
        {
            if (capacity < 2 || capacity > 2048) throw new ArgumentOutOfRangeException(nameof(capacity));
            _points = new Point[capacity];
        }

        public Point GetPoint(int index)
        {
            if (index < 0 || index >= Count) throw new ArgumentOutOfRangeException(nameof(index));
            return _points[(_next - Count + index + _points.Length) % _points.Length];
        }

        public void Reset()
        {
            Count = _next = 0;
            _carry = _phase = Distance = 0d;
        }

        public void Tick(float deltaTime, float bpm, float pixelsPerSecond, bool hasPulse = true)
        {
            if (float.IsNaN(deltaTime) || float.IsInfinity(deltaTime) || deltaTime < 0f)
                throw new ArgumentOutOfRangeException(nameof(deltaTime));
            if (float.IsNaN(bpm) || float.IsInfinity(bpm) ||
                !((bpm >= 40f && bpm <= 200f) || (!hasPulse && bpm == 0f)))
                throw new ArgumentOutOfRangeException(nameof(bpm));
            if (float.IsNaN(pixelsPerSecond) || float.IsInfinity(pixelsPerSecond) || pixelsPerSecond <= 0f)
                throw new ArgumentOutOfRangeException(nameof(pixelsPerSecond));
            double beatsPerSecond = hasPulse ? bpm / 60d : 0d;
            double steps = Math.Floor((_carry + deltaTime) / SampleInterval);
            int retained = (int)Math.Min(steps, _points.Length);
            for (int i = 0; i < retained; i++)
            {
                double time = (steps - retained + i + 1d) * SampleInterval - _carry;
                _points[_next] = new Point(Distance + pixelsPerSecond * time,
                    hasPulse ? SampleWave(_phase + beatsPerSecond * time) : 0f);
                _next = (_next + 1) % _points.Length;
                Count = Math.Min(Count + 1, _points.Length);
            }
            _carry = (_carry + deltaTime) - steps * SampleInterval;
            _phase = (_phase + beatsPerSecond * deltaTime) % 1d;
            Distance += pixelsPerSecond * (double)deltaTime;
        }

        public static float SampleWave(double phase)
        {
            phase -= Math.Floor(phase);
            return (float)(0.12d * Triangle(phase, 0.12d, 0.05d) -
                0.18d * Triangle(phase, 0.24d, 0.018d) + Triangle(phase, 0.28d, 0.025d) -
                0.3d * Triangle(phase, 0.32d, 0.025d) + 0.25d * Triangle(phase, 0.55d, 0.1d));
        }

        private static double Triangle(double value, double center, double halfWidth) =>
            Math.Max(0d, 1d - Math.Abs(value - center) / halfWidth);
    }
}
