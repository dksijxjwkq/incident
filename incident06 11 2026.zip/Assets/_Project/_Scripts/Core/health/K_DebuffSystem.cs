using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core
{
    public class K_DebuffSystem : MonoBehaviour, ISaveable
        , ISavePayloadValidator
    {
        [Header("References (auto-find)")]
        [SerializeField] private K_HealthSystem _healthSystem;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false;

        private const float DERIVED_CHECK_INTERVAL = 0.2f;
        private float _derivedCheckTimer;

        private float _concussionTimer;

        // ═══ Этап 6.4: Painkiller (не сохраняется в Save) ═══
        private float _painkillerTimer;
        private float _painkillerFullDuration;
        private float _mildPainkillerTimer;
        private float _mildPainkillerOnsetTimer;
        private float _mildPainkillerFullDuration;
        private float _pendingMildPainkillerDuration;
        private float _tbiRecoveryTimer;
        private const int MEDICAL_DEBUFF_TAIL = 0x3144424D; // MBD1
        [Header("Medical recovery")]
        [SerializeField, Min(0f), Tooltip("Игровая задержка начала действия парацетамола, в секундах.")]
        private float _paracetamolOnsetSeconds = 15f;

        private bool _tbiActive;
        private bool _breathingActive;
        private bool _immobilizedActive;
        private bool _internalBleedingActive;
        // Stage 1 §5.1: сотрясение от перелома головы (без шины).
        private bool _fractureConcussionActive;

        private bool _lastConcussion, _lastTbi, _lastBreathing, _lastImmobilized, _lastInternalBleeding;

        public event Action OnDebuffsChanged;

        /// <summary>
        /// Stage 1 §5.1: два независимых источника — таймер и перелом головы.
        /// Не складываются. True, если активен хотя бы один.
        /// </summary>
        public bool HasConcussion => IsDebuffEnabled(DebuffKind.Concussion) && (_concussionTimer > 0f || _fractureConcussionActive);
        public bool HasTBI => IsDebuffEnabled(DebuffKind.TBI) && _tbiActive;
        public bool HasBreathingDifficulty => IsDebuffEnabled(DebuffKind.BreathingDifficulty) && _breathingActive;
        public bool HasImmobilized => IsDebuffEnabled(DebuffKind.Immobilized) && _immobilizedActive;
        public bool HasInternalBleeding =>
            IsDebuffEnabled(DebuffKind.InternalBleeding) && _healthSystem != null && _healthSystem.HasAnyInternalBleedingRevealed();

        private static bool IsDebuffEnabled(DebuffKind kind)
        {
            var config = K_HealthConfig.Instance;
            return config == null || config.GetDebuff(kind).enabled;
        }

        public bool IsUnderPainkiller => PainReliefFraction > 0f;
        public bool HasPendingPainkiller => _mildPainkillerOnsetTimer > 0f;
        public float PainReliefFraction => _painkillerTimer > 0f ? 0.85f : _mildPainkillerTimer > 0f ? 0.35f : 0f;
        public string PainkillerSourceItemID => _painkillerTimer > 0f ? "painkiller" :
            (_mildPainkillerTimer > 0f || HasPendingPainkiller) ? "paracetamol" : string.Empty;
        public float PainkillerFullDuration => _painkillerTimer > 0f ? _painkillerFullDuration :
            _mildPainkillerTimer > 0f ? _mildPainkillerFullDuration : _pendingMildPainkillerDuration;
        public float PainkillerOnsetSecondsRemaining => _painkillerTimer > 0f ? 0f : Mathf.Max(0f, _mildPainkillerOnsetTimer);
        public float PainkillerActionSpeedMultiplier => _painkillerTimer > 0f ? 0.9f : 1f;
        public float TbiRecoverySecondsRemaining => Mathf.Max(0f, _tbiRecoveryTimer);
        public bool IsTbiRecovering => _tbiRecoveryTimer > 0f;
        public float ConcussionSecondsRemaining => Mathf.Max(0f, _concussionTimer);
        public float PainkillerSecondsRemaining => Mathf.Max(0f, _painkillerTimer > 0f ? _painkillerTimer : _mildPainkillerTimer);
        public bool HasFractureConcussion => IsDebuffEnabled(DebuffKind.Concussion) && _fractureConcussionActive;

        public string SaveID => "PlayerDebuffs";
        public bool IsDirty { get; set; } = true;

        private void Awake()
        {
            if (_healthSystem == null) _healthSystem = GetComponent<K_HealthSystem>();
            if (_healthSystem == null)
                Debug.LogError("[DebuffSystem] K_HealthSystem not found!");
        }

        private void OnEnable()
        {
            if (_healthSystem != null)
                _healthSystem.OnDamageTaken += HandleDamageTaken;
        }

        private void OnDisable()
        {
            if (_healthSystem != null)
                _healthSystem.OnDamageTaken -= HandleDamageTaken;
        }

        private void Start()
        {
            K_SaveManager.Instance?.Register(this);
            RefreshDerivedDebuffs();
        }

        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
            OnDebuffsChanged = null;
        }

        private void Update()
        {
            if (_healthSystem != null && _healthSystem.IsDead) return;
            if (_concussionTimer > 0f)
            {
                _concussionTimer -= Time.deltaTime;
                if (_concussionTimer <= 0f)
                {
                    _concussionTimer = 0f;
                    if (_debugLogs) Debug.Log("[DebuffSystem] Concussion expired.");
                    FireChangedIfNeeded();
                }
            }

            // ═══ Этап 6.4: Painkiller tick ═══
            if (_painkillerTimer > 0f)
            {
                _painkillerTimer -= Time.deltaTime;
                if (_painkillerTimer <= 0f)
                {
                    _painkillerTimer = 0f;
                    if (_debugLogs) Debug.Log("[DebuffSystem] Painkiller expired.");
                    OnDebuffsChanged?.Invoke();
                }
            }

            float medicalDelta = Time.deltaTime;
            // An active dose keeps expiring while a replacement dose is pending.
            if (_mildPainkillerTimer > 0f)
            {
                _mildPainkillerTimer = Mathf.Max(0f, _mildPainkillerTimer - medicalDelta);
                if (_mildPainkillerTimer <= 0f) OnDebuffsChanged?.Invoke();
            }
            if (_mildPainkillerOnsetTimer > 0f)
            {
                float carry = Mathf.Max(0f, medicalDelta - _mildPainkillerOnsetTimer);
                _mildPainkillerOnsetTimer = Mathf.Max(0f, _mildPainkillerOnsetTimer - medicalDelta);
                if (_mildPainkillerOnsetTimer <= 0f)
                {
                    _mildPainkillerFullDuration = _pendingMildPainkillerDuration;
                    _pendingMildPainkillerDuration = 0f;
                    _mildPainkillerTimer = Mathf.Max(0f, _mildPainkillerFullDuration - carry);
                    OnDebuffsChanged?.Invoke();
                }
            }
            if (_tbiRecoveryTimer > 0f && (_healthSystem == null || _healthSystem.IsRestingForRecovery))
            {
                _tbiRecoveryTimer = Mathf.Max(0f, _tbiRecoveryTimer - medicalDelta);
                IsDirty = true;
                if (_tbiRecoveryTimer <= 0f) CureTBI();
            }

            _derivedCheckTimer += Time.deltaTime;
            if (_derivedCheckTimer >= DERIVED_CHECK_INTERVAL)
            {
                _derivedCheckTimer = 0f;
                RefreshDerivedDebuffs();
            }
        }

        private void HandleDamageTaken(BodyPart part, float damage, DamageType type)
        {
            if (part != BodyPart.Head) return;
            if (type != DamageType.Firearm) return;

            var config = K_HealthConfig.Instance;
            if (config == null)
            {
                Debug.LogWarning("[DebuffSystem] K_HealthConfig.Instance is null — cannot resolve debuff thresholds.");
                return;
            }

            if (!_tbiActive && damage >= config.TbiDamageThreshold)
            {
                var cfg = config.GetDebuff(DebuffKind.TBI);
                if (cfg.enabled)
                {
                    _tbiActive = true;
                    Debug.Log($"[DebuffSystem] TBI activated (damage {damage:F0} ≥ {config.TbiDamageThreshold:F0})");
                }
            }

            if (damage >= config.ConcussionDamageThreshold)
            {
                var cfg = config.GetDebuff(DebuffKind.Concussion);
                if (cfg.enabled)
                {
                    _concussionTimer = Mathf.Max(_concussionTimer, cfg.duration);
                    Debug.Log($"[DebuffSystem] Concussion activated/refreshed (damage {damage:F0}, timer {_concussionTimer:F0}s)");
                }
            }

            FireChangedIfNeeded();
        }

        /// <summary>
        /// Stage 1 §5: пересчёт производных дебаффов.
        /// - BreathingDifficulty: перелом груди без шины ИЛИ огнестрел в грудь.
        /// - Immobilized: перелом таза без шины.
        /// - _fractureConcussionActive: перелом головы без шины (даёт HasConcussion).
        /// - InternalBleeding: реальный revealed IB из K_HealthSystem.
        /// </summary>
        private void RefreshDerivedDebuffs()
        {
            if (_healthSystem == null) return;

            bool chestFracture = _healthSystem.IsFractured(BodyPart.Chest)
                              && !_healthSystem.IsSplinted(BodyPart.Chest);
            bool chestGunshot = _healthSystem.IsGunshot(BodyPart.Chest) && !_healthSystem.HasChestSeal;
            bool breathing = chestFracture || chestGunshot;

            bool immobilized = _healthSystem.IsFractured(BodyPart.Pelvis);

            bool headFracture = _healthSystem.IsFractured(BodyPart.Head)
                             && !_healthSystem.IsSplinted(BodyPart.Head);

            // Stage 2 §4.5: реальный IB от K_HealthSystem (только revealed).
            bool internalBleed = _healthSystem.HasAnyInternalBleedingRevealed();

            bool changed = false;
            if (_breathingActive != breathing) { _breathingActive = breathing; changed = true; }
            if (_immobilizedActive != immobilized) { _immobilizedActive = immobilized; changed = true; }
            if (_internalBleedingActive != internalBleed) { _internalBleedingActive = internalBleed; changed = true; }
            if (_fractureConcussionActive != headFracture) { _fractureConcussionActive = headFracture; changed = true; }

            if (changed) FireChangedIfNeeded();
        }

        public float GetSpeedMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).speedMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).speedMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).speedMultiplier;
            // Immobilized only blocks sprint. The separate leg-zone rules still apply.
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).speedMultiplier;
            return Mathf.Lerp(m, 1f, PainReliefFraction * 0.5f);
        }

        public float GetStaminaRegenMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).staminaRegenMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).staminaRegenMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).staminaRegenMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).staminaRegenMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).staminaRegenMultiplier;
            return Mathf.Lerp(m, 1f, PainReliefFraction * 0.5f);
        }

        public float GetStaminaMaxMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).staminaMaxMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).staminaMaxMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).staminaMaxMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).staminaMaxMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).staminaMaxMultiplier;
            return Mathf.Lerp(m, 1f, PainReliefFraction * 0.5f);
        }

        /// <summary>Breathing difficulty raises stamina expenditure, independently of recovery.</summary>
        public float GetStaminaDrainMultiplier()
            => !HasBreathingDifficulty ? 1f : 1.3f;

        public float GetAimStabilityMultiplier()
        {
            // 6.4: обезбол полностью убирает тряску.

            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).aimStabilityMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).aimStabilityMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).aimStabilityMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).aimStabilityMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).aimStabilityMultiplier;
            return Mathf.Lerp(m, 1f, PainReliefFraction * 0.5f);
        }

        public bool IsSprintBlocked()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return false;

            if (HasConcussion && c.GetDebuff(DebuffKind.Concussion).blockSprint) return true;
            if (HasTBI && c.GetDebuff(DebuffKind.TBI).blockSprint) return true;
            // Breathing difficulty never blocks sprint, including stale serialized configs.
            if (HasImmobilized && c.GetDebuff(DebuffKind.Immobilized).blockSprint) return true;
            if (HasInternalBleeding && c.GetDebuff(DebuffKind.InternalBleeding).blockSprint) return true;
            return false;
        }

        public float GetBloodDrainMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).bloodDrainMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).bloodDrainMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).bloodDrainMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).bloodDrainMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).bloodDrainMultiplier;
            return m;
        }

        private void FireChangedIfNeeded()
        {
            bool changed = false;
            if (_lastConcussion != HasConcussion) { _lastConcussion = HasConcussion; changed = true; }
            if (_lastTbi != HasTBI) { _lastTbi = HasTBI; changed = true; }
            if (_lastBreathing != HasBreathingDifficulty) { _lastBreathing = HasBreathingDifficulty; changed = true; }
            if (_lastImmobilized != HasImmobilized) { _lastImmobilized = HasImmobilized; changed = true; }
            if (_lastInternalBleeding != HasInternalBleeding) { _lastInternalBleeding = HasInternalBleeding; changed = true; }

            if (changed)
            {
                if (_debugLogs)
                {
                    Debug.Log($"[DebuffSystem] State: Concussion={HasConcussion} TBI={HasTBI} " +
                              $"Breathing={HasBreathingDifficulty} Immobilized={HasImmobilized} " +
                              $"InternalBleeding={HasInternalBleeding}");
                }
                IsDirty = true;
                OnDebuffsChanged?.Invoke();
            }
        }

        // 6.4: _painkillerTimer НЕ сохраняется (временный боевой эффект).
        // Existing prefix is unchanged; marked optional tail owns TBI recovery.
        public void Save(BinaryWriter writer)
        {
            writer.Write(_concussionTimer);
            writer.Write(_tbiActive);
            // V6 (Stage 1 §13): сотрясение от перелома головы.
            writer.Write(_fractureConcussionActive);
            writer.Write(MEDICAL_DEBUFF_TAIL);
            writer.Write(_tbiRecoveryTimer);
        }

        public void Load(BinaryReader reader)
        {
            ResetNonPersistentEffectsForLoad();
            _concussionTimer = reader.ReadSingle();
            _tbiActive = reader.ReadBoolean();
            // V6 (Stage 1 §13)
            _fractureConcussionActive = reader.ReadBoolean();
            _tbiRecoveryTimer = ReadRecoveryTail(reader, _tbiActive);
            RefreshDerivedDebuffs();
            FireChangedIfNeeded();
            IsDirty = false;
        }

        /// <summary>Uses the same Load-boundary policy as health boosts and vitality stimulants.</summary>
        public void ResetNonPersistentEffectsForLoad()
        {
            _painkillerTimer = _painkillerFullDuration = 0f;
            _mildPainkillerTimer = _mildPainkillerOnsetTimer = _mildPainkillerFullDuration = _pendingMildPainkillerDuration = 0f;
            _tbiRecoveryTimer = 0f;
        }

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            SaveLoadValidationContext.ReadFinite(reader, true);
            bool tbi = reader.ReadBoolean();
            reader.ReadBoolean();
            ReadRecoveryTail(reader, tbi);
        }

        private static float ReadRecoveryTail(BinaryReader reader, bool tbi)
        {
            if (K_SaveManager.LoadedSchemaRevision < 5 || reader.BaseStream.Position == reader.BaseStream.Length) return 0f;
            if (reader.BaseStream.Length - reader.BaseStream.Position != 8 || reader.ReadInt32() != MEDICAL_DEBUFF_TAIL)
                throw new InvalidDataException("Invalid medical recovery tail.");
            float timer = SaveLoadValidationContext.ReadFinite(reader, true);
            if (timer > 86400f || (timer > 0f && !tbi)) throw new InvalidDataException("Invalid TBI recovery timer.");
            return timer;
        }

        public void CureConcussion()
        {
            if (_concussionTimer <= 0f) return;
            _concussionTimer = 0f;
            Debug.Log("[DebuffSystem] Concussion cured.");
            FireChangedIfNeeded();
        }

        /// <summary>Stage 5.1 explicit status call, independent of HP damage events.</summary>
        public void ApplyCombatConcussion(K_HealthConfig healthConfig = null)
        {
            var config = healthConfig != null ? healthConfig : K_HealthConfig.Instance;
            if (config != null && !config.GetDebuff(DebuffKind.Concussion).enabled) return;
            float duration = config != null ? config.GetDebuff(DebuffKind.Concussion).duration : 60f;
            if (float.IsNaN(duration) || float.IsInfinity(duration) || duration <= 0f)
                throw new InvalidOperationException("Concussion duration must be finite and positive.");
            _concussionTimer = Mathf.Max(_concussionTimer, duration);
            IsDirty = true;
            FireChangedIfNeeded();
        }

        /// <summary>Stage 5.1 permanent TBI status; existing treatment remains available.</summary>
        public void ApplyCombatTBI(K_HealthConfig healthConfig = null)
        {
            var config = healthConfig != null ? healthConfig : K_HealthConfig.Instance;
            if (config != null && !config.GetDebuff(DebuffKind.TBI).enabled) return;
            _tbiActive = true;
            _tbiRecoveryTimer = 0f;
            IsDirty = true;
            FireChangedIfNeeded();
        }

        /// <summary>Stage 5.1 immediate refresh after a separate fracture/gunshot call.</summary>
        public void RefreshCombatDerivedDebuffs() => RefreshDerivedDebuffs();

        /// <summary>
        /// Этап 6.4: активировать/обновить обезбол. Refresh через Max.
        /// duration &lt;= 0 → no-op. Не сохраняется в Save (временный эффект).
        /// </summary>
        public bool CanActivatePainkiller(float duration)
            => CanActivatePainkiller(duration, "painkiller");

        public bool CanActivatePainkiller(float duration, string itemID)
            => !float.IsNaN(duration) && !float.IsInfinity(duration) && duration > 0f &&
                (itemID == "paracetamol" ? _mildPainkillerOnsetTimer <= 0f && duration > _mildPainkillerTimer : duration > _painkillerTimer);

        public void ActivatePainkiller(float duration)
            => ActivatePainkiller(duration, "painkiller");

        public void ActivatePainkiller(float duration, string itemID)
        {
            if (!CanActivatePainkiller(duration, itemID)) return;
            if (itemID == "paracetamol")
            {
                _mildPainkillerOnsetTimer = float.IsNaN(_paracetamolOnsetSeconds) || float.IsInfinity(_paracetamolOnsetSeconds)
                    ? 15f : Mathf.Max(0f, _paracetamolOnsetSeconds);
                if (_mildPainkillerOnsetTimer <= 0f)
                {
                    _mildPainkillerFullDuration = duration;
                    _mildPainkillerTimer = duration;
                    _pendingMildPainkillerDuration = 0f;
                }
                else _pendingMildPainkillerDuration = duration;
            }
            else
            {
                _painkillerTimer = Mathf.Max(_painkillerTimer, duration);
                _painkillerFullDuration = _painkillerTimer;
            }
            OnDebuffsChanged?.Invoke();
            if (_debugLogs)
                Debug.Log($"[DebuffSystem] Painkiller active: {_painkillerTimer:F1}s");
        }

        public void CureTBI()
        {
            _tbiRecoveryTimer = 0f;
            if (!_tbiActive) return;
            _tbiActive = false;
            Debug.Log("[DebuffSystem] TBI cured.");
            FireChangedIfNeeded();
        }

        public bool BeginTbiRecovery(float duration)
        {
            if (float.IsNaN(duration) || float.IsInfinity(duration) || duration <= 0f ||
                !CanBeginTbiRecovery) return false;
            if (!_tbiActive && (_healthSystem == null || !_healthSystem.IsFractured(BodyPart.Head))) return false;
            if (_tbiActive) _tbiRecoveryTimer = duration;
            _healthSystem?.BeginHeadRecovery(duration);
            IsDirty = true;
            OnDebuffsChanged?.Invoke();
            return true;
        }

        public bool CanBeginTbiRecovery => !IsTbiRecovering &&
            (_healthSystem == null || (!_healthSystem.IsDead && _healthSystem.GetBleedingLevel(BodyPart.Head) <= 0 &&
                !_healthSystem.IsGunshot(BodyPart.Head) && !_healthSystem.IsInternalBleedingRevealed(BodyPart.Head))) &&
            (_tbiActive || (_healthSystem != null && _healthSystem.IsFractured(BodyPart.Head) &&
                _healthSystem.GetSplintRecoverySecondsRemaining(BodyPart.Head) <= 0f));

        [ContextMenu("Debug: Apply Concussion (60s)")]
        public void DebugApplyConcussion()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return;
            _concussionTimer = c.GetDebuff(DebuffKind.Concussion).duration;
            FireChangedIfNeeded();
        }

        [ContextMenu("Debug: Apply TBI")]
        public void DebugApplyTBI()
        {
            _tbiActive = true;
            FireChangedIfNeeded();
        }

        [ContextMenu("Debug: Print State")]
        public void DebugPrintState()
        {
            Debug.Log($"[DebuffSystem] Concussion={HasConcussion} ({_concussionTimer:F1}s) " +
                      $"TBI={HasTBI} Breathing={HasBreathingDifficulty} " +
                      $"Immobilized={HasImmobilized} InternalBleeding={HasInternalBleeding}");
        }

        [ContextMenu("Debug: Cure All")]
        public void DebugCureAll()
        {
            _concussionTimer = 0f;
            _tbiActive = false;
            _tbiRecoveryTimer = 0f;
            FireChangedIfNeeded();
        }
    }
}
