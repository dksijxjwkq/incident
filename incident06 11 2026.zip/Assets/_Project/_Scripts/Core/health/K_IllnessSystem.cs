using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>Two source-owned illnesses. Symptoms are not independent debuffs.</summary>
    [DisallowMultipleComponent]
    public sealed class K_IllnessSystem : MonoBehaviour, ISaveable, IPreLoad, IPostLoad, ISavePayloadValidator
    {
        private const int PartCount = 20;
        private const int PayloadMarker = 0x314E4C49; // ILN1
        private const float DurationLimit = 10000000f;

        [Header("Системы персонажа")]
        [SerializeField] private K_HealthSystem _health;

        [Header("Простуда — игровой баланс")]
        [SerializeField, Min(0.1f), Tooltip("Игровое время болезни. Это сокращённая длительность для игры, не медицинский срок.")]
        private float _coldDuration = 600f;
        [SerializeField, Min(0.1f), Tooltip("Сколько секунд контакта с явно заданным вирусным источником вызывает простуду. Сам холод вирусным источником не считается.")]
        private float _viralExposureThreshold = 30f;
        [SerializeField, Min(1f), Tooltip("Во сколько раз быстрее уменьшается остаток простуды в покое.")]
        private float _coldRestRecoveryMultiplier = 1.5f;
        [SerializeField, Range(0.1f, 1f), Tooltip("Скорость действий при простуде: 0.9 означает 90% обычной скорости.")]
        private float _coldActionSpeedMultiplier = 0.9f;
        [SerializeField, Range(0.1f, 1f), Tooltip("Восстановление выносливости при простуде: 0.9 означает 90% обычной скорости.")]
        private float _coldStaminaRegenMultiplier = 0.9f;

        [Header("Инфекция раны — игровой баланс")]
        [SerializeField, Min(0.1f), Tooltip("Сколько игровых секунд открытая рана или необработанный огнестрел остаются без помощи до инфекции. Кровотечение для заражения не требуется. Закрытие раны и обработка огнестрела до этого сбрасывают накопление.")]
        private float _woundInfectionDelay = 180f;
        [SerializeField, Min(0.1f), Tooltip("Время восстановления заражённого участка при обработанной ране и действующем курсе антибиотика.")]
        private float _infectionRecoveryDuration = 180f;
        [SerializeField, Min(0.1f), Tooltip("Длительность одного игрового курса антибиотика. Предмет представляет упаковку для курса, а не одну таблетку.")]
        private float _antibioticDuration = 240f;

        private float _coldRemaining, _coldFullDuration, _viralExposure;
        private float _antibioticRemaining, _antibioticFullDuration;
        private readonly float[] _woundExposure = new float[PartCount];
        private readonly bool[] _infected = new bool[PartCount];
        private readonly float[] _infectionRecovery = new float[PartCount];

        public event Action OnIllnessesChanged;
        public string SaveID => "PlayerIllness";
        public bool IsDirty { get; set; } = true;
        public bool HasCold => _coldRemaining > 0f;
        public float ColdSecondsRemaining => Mathf.Max(0f, _coldRemaining);
        public float ColdFullDuration => _coldFullDuration;
        public float ColdActionSpeedMultiplier => HasCold ? SafeMultiplier(_coldActionSpeedMultiplier) : 1f;
        public float ColdStaminaRegenMultiplier => HasCold ? SafeMultiplier(_coldStaminaRegenMultiplier) : 1f;
        public bool HasWoundInfection => WoundInfectionCount > 0;
        public int WoundInfectionCount
        {
            get { int count = 0; for (int i = 0; i < PartCount; i++) if (_infected[i]) count++; return count; }
        }
        public float AntibioticSecondsRemaining => Mathf.Max(0f, _antibioticRemaining);
        public float AntibioticFullDuration => _antibioticFullDuration;
        public bool CanStartAntibioticCourse => IsAlive && HasWoundInfection && _antibioticRemaining <= 0f;
        private bool IsAlive => _health != null && !_health.IsDead;

        public void Initialize(K_HealthSystem health)
        {
            if (health != null) _health = health;
        }
        private void Awake() { if (_health == null) Initialize(GetComponent<K_HealthSystem>()); }
        private void Start() => K_SaveManager.Instance?.Register(this);
        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
            OnIllnessesChanged = null;
        }
        private void Update() => Tick(Time.deltaTime);

        public bool IsWoundInfected(BodyPart part) => ValidPart(part) && _infected[(int)part];
        public bool IsWoundAtRiskOfInfection(BodyPart part)
            => ValidPart(part) && _health != null &&
               (_health.GetLacerationType(part) == LacerationType.Open || _health.IsGunshot(part));
        public float GetWoundInfectionRecoverySeconds(BodyPart part)
            => IsWoundInfected(part) ? Mathf.Max(0f, _infectionRecovery[(int)part]) : 0f;
        public bool IsWoundInfectionRecovering(BodyPart part)
            => IsAlive && IsWoundInfected(part) && _antibioticRemaining > 0f && IsWoundPrepared(part);

        /// <summary>Only real viral sources call this; ambient temperature alone does not infect.</summary>
        public bool ReportViralExposure(float exposureSeconds)
        {
            if (!IsAlive || HasCold || !FinitePositive(exposureSeconds)) return false;
            _viralExposure = Mathf.Min(DurationLimit, _viralExposure + exposureSeconds);
            IsDirty = true;
            if (_viralExposure >= SafeDuration(_viralExposureThreshold, 30f)) return ApplyCold();
            return true;
        }

        public bool ApplyCold(float duration = -1f)
        {
            if (!IsAlive || float.IsNaN(duration) || float.IsInfinity(duration)) return false;
            float accepted = duration < 0f ? SafeDuration(_coldDuration, 600f) : duration;
            if (!FinitePositive(accepted) || accepted > DurationLimit || HasCold) return false;
            _coldRemaining = _coldFullDuration = accepted;
            _viralExposure = 0f;
            Changed();
            return true;
        }

        /// <summary>Applies a real local illness; intact skin is not a wound source.</summary>
        public bool ApplyWoundInfection(BodyPart part)
        {
            if (!IsAlive || !ValidPart(part) || _infected[(int)part] ||
                (_health.GetLacerationType(part) == LacerationType.None && !_health.IsGunshot(part))) return false;
            int index = (int)part;
            _infected[index] = true;
            _infectionRecovery[index] = SafeDuration(_infectionRecoveryDuration, 180f);
            _woundExposure[index] = 0f;
            Changed();
            return true;
        }

        public bool StartAntibioticCourse(float duration = -1f)
        {
            if (!CanStartAntibioticCourse || float.IsNaN(duration) || float.IsInfinity(duration)) return false;
            float accepted = duration < 0f ? SafeDuration(_antibioticDuration, 240f) : duration;
            if (!FinitePositive(accepted) || accepted > DurationLimit) return false;
            _antibioticRemaining = _antibioticFullDuration = accepted;
            Changed();
            return true;
        }

        public void ClearCold()
        {
            _coldRemaining = _coldFullDuration = _viralExposure = 0f;
            Changed();
        }
        public bool ClearWoundInfection(BodyPart part)
        {
            if (!ValidPart(part)) return false;
            int index = (int)part;
            bool changed = _infected[index] || _woundExposure[index] > 0f;
            _infected[index] = false;
            _woundExposure[index] = _infectionRecovery[index] = 0f;
            if (changed) Changed();
            return changed;
        }
        public bool SetColdRemainingSeconds(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds < 0f || seconds > DurationLimit) return false;
            if (seconds == 0f) { ClearCold(); return true; }
            if (!IsAlive) return false;
            _coldRemaining = seconds;
            _coldFullDuration = Mathf.Max(_coldFullDuration, seconds);
            _viralExposure = 0f;
            Changed();
            return true;
        }
        public bool SetAntibioticRemainingSeconds(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds < 0f || seconds > DurationLimit) return false;
            if (seconds > 0f && (!IsAlive || (_antibioticRemaining <= 0f && !HasWoundInfection))) return false;
            _antibioticRemaining = seconds;
            _antibioticFullDuration = seconds > 0f ? Mathf.Max(_antibioticFullDuration, seconds) : 0f;
            Changed();
            return true;
        }

        /// <summary>Game-time tick. Closing the inventory has no effect on this owner.</summary>
        public void Tick(float deltaTime)
        {
            if (!IsAlive || !FinitePositive(deltaTime)) return;
            deltaTime = Mathf.Min(deltaTime, DurationLimit);
            bool transition = false;
            float antibioticWindow = Mathf.Min(deltaTime, _antibioticRemaining);
            if (_coldRemaining > 0f)
            {
                float rate = _health.IsRestingForRecovery ? SafeDuration(_coldRestRecoveryMultiplier, 1.5f) : 1f;
                _coldRemaining = Mathf.Max(0f, _coldRemaining - deltaTime * Mathf.Max(1f, rate));
                IsDirty = true;
                if (_coldRemaining <= 0f) { _coldFullDuration = 0f; transition = true; }
            }
            if (_antibioticRemaining > 0f)
            {
                _antibioticRemaining = Mathf.Max(0f, _antibioticRemaining - deltaTime);
                IsDirty = true;
                if (_antibioticRemaining <= 0f) { _antibioticFullDuration = 0f; transition = true; }
            }
            for (int i = 0; i < PartCount; i++)
            {
                var part = (BodyPart)i;
                if (!_infected[i])
                {
                    if (IsWoundAtRiskOfInfection(part))
                    {
                        _woundExposure[i] = Mathf.Min(DurationLimit, _woundExposure[i] + deltaTime);
                        IsDirty = true;
                        if (_woundExposure[i] >= SafeDuration(_woundInfectionDelay, 180f))
                        {
                            _infected[i] = true;
                            _infectionRecovery[i] = SafeDuration(_infectionRecoveryDuration, 180f);
                            _woundExposure[i] = 0f;
                            transition = true;
                        }
                    }
                    else if (_woundExposure[i] > 0f) { _woundExposure[i] = 0f; IsDirty = true; }
                    continue;
                }
                if (antibioticWindow <= 0f || !IsWoundPrepared(part)) continue;
                _infectionRecovery[i] = Mathf.Max(0f, _infectionRecovery[i] - antibioticWindow);
                IsDirty = true;
                if (_infectionRecovery[i] <= 0f) { _infected[i] = false; transition = true; }
            }
            if (transition) OnIllnessesChanged?.Invoke();
        }

        private bool IsWoundPrepared(BodyPart part)
            => _health.GetLacerationType(part) != LacerationType.Open &&
               _health.GetBleedingLevel(part) <= 0 && !_health.IsGunshot(part);

        public void ClearIllnesses()
        {
            ResetState();
            Changed();
        }
        private void ResetState()
        {
            _coldRemaining = _coldFullDuration = _viralExposure = 0f;
            _antibioticRemaining = _antibioticFullDuration = 0f;
            Array.Clear(_woundExposure, 0, PartCount);
            Array.Clear(_infected, 0, PartCount);
            Array.Clear(_infectionRecovery, 0, PartCount);
        }
        private void Changed() { IsDirty = true; OnIllnessesChanged?.Invoke(); }
        private static bool ValidPart(BodyPart part) => (int)part >= 0 && (int)part < PartCount;
        private static bool FinitePositive(float value) => !float.IsNaN(value) && !float.IsInfinity(value) && value > 0f;
        private static float SafeDuration(float value, float fallback)
            => FinitePositive(value) ? Mathf.Min(value, DurationLimit) : fallback;
        private static float SafeMultiplier(float value)
            => float.IsNaN(value) || float.IsInfinity(value) ? 1f : Mathf.Clamp(value, .1f, 1f);

        public void Save(BinaryWriter writer)
        {
            writer.Write(PayloadMarker);
            writer.Write(_coldRemaining); writer.Write(_coldFullDuration); writer.Write(_viralExposure);
            writer.Write(_antibioticRemaining); writer.Write(_antibioticFullDuration);
            writer.Write(PartCount);
            for (int i = 0; i < PartCount; i++)
            {
                writer.Write(_woundExposure[i]); writer.Write(_infected[i]); writer.Write(_infectionRecovery[i]);
            }
        }

        public void Load(BinaryReader reader)
        {
            var state = ReadState(reader);
            _coldRemaining = state.Cold; _coldFullDuration = state.ColdFull; _viralExposure = state.Exposure;
            _antibioticRemaining = state.Antibiotic; _antibioticFullDuration = state.AntibioticFull;
            Array.Copy(state.WoundExposure, _woundExposure, PartCount);
            Array.Copy(state.Infected, _infected, PartCount);
            Array.Copy(state.Recovery, _infectionRecovery, PartCount);
            IsDirty = false;
        }
        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context) => ReadState(reader);
        public void OnBeforeLoad() { ResetState(); IsDirty = false; }
        public void OnAfterLoad() => OnIllnessesChanged?.Invoke();

        private sealed class State
        {
            public float Cold, ColdFull, Exposure, Antibiotic, AntibioticFull;
            public readonly float[] WoundExposure = new float[PartCount];
            public readonly bool[] Infected = new bool[PartCount];
            public readonly float[] Recovery = new float[PartCount];
        }
        private static State ReadState(BinaryReader reader)
        {
            if (reader.ReadInt32() != PayloadMarker) throw new InvalidDataException("Invalid illness payload marker.");
            var state = new State
            {
                Cold = ReadTime(reader), ColdFull = ReadTime(reader), Exposure = ReadTime(reader),
                Antibiotic = ReadTime(reader), AntibioticFull = ReadTime(reader)
            };
            if (state.Cold > state.ColdFull || (state.Cold <= 0f && state.ColdFull != 0f) ||
                (state.Cold > 0f && state.Exposure != 0f) ||
                state.Antibiotic > state.AntibioticFull || (state.Antibiotic <= 0f && state.AntibioticFull != 0f))
                throw new InvalidDataException("Inconsistent saved illness timer.");
            if (reader.ReadInt32() != PartCount) throw new InvalidDataException("Invalid illness part count.");
            for (int i = 0; i < PartCount; i++)
            {
                state.WoundExposure[i] = ReadTime(reader);
                byte infected = reader.ReadByte();
                if (infected > 1) throw new InvalidDataException("Invalid infection flag.");
                state.Infected[i] = infected == 1;
                state.Recovery[i] = ReadTime(reader);
                if (state.Infected[i] != (state.Recovery[i] > 0f) ||
                    (state.Infected[i] && state.WoundExposure[i] != 0f))
                    throw new InvalidDataException("Inconsistent saved wound infection.");
            }
            if (reader.BaseStream.Position != reader.BaseStream.Length)
                throw new InvalidDataException("Unexpected illness payload bytes.");
            return state;
        }
        private static float ReadTime(BinaryReader reader)
        {
            float value = SaveLoadValidationContext.ReadFinite(reader, true);
            if (value > DurationLimit) throw new InvalidDataException("Saved illness time exceeds its limit.");
            return value;
        }
    }
}
