using System;
using System.Collections.Generic;
using System.IO;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Stage 4: owned and ticked by K_HealthSystem; no scene searches or coroutines.
    /// Inventory placement/removal is injected without changing transaction services.
    /// </summary>
    public sealed class K_AppliedMedicalManager
    {
        private const float DefaultFullChargeSeconds = 420f;
        private readonly List<AppliedMedicalRecord> _records = new List<AppliedMedicalRecord>();
        private readonly IReadOnlyList<AppliedMedicalRecord> _readOnlyRecords;
        private K_HealthSystem _health;
        private ItemDatabase _itemDatabase;
        private MedicalDatabase _medicalDatabase;
        private Func<uint, InventoryItem> _findItem;
        private Action<uint, int, float> _updateCharge;
        private Func<AppliedMedicalRecord, bool> _canReturn;
        private Func<AppliedMedicalRecord, bool> _returnItem;
        private Action<uint> _expireItem;
        private Action _refreshAfterExpiration;

        public K_AppliedMedicalManager() { _readOnlyRecords = _records.AsReadOnly(); }
        public IReadOnlyList<AppliedMedicalRecord> Records => _readOnlyRecords;

        public void Initialize(K_HealthSystem health)
        {
            _health = health ?? throw new ArgumentNullException(nameof(health));
        }

        public void ConfigureItemDatabase(ItemDatabase database) { _itemDatabase = database; }

        public void ConfigureMedicalDatabase(MedicalDatabase database)
        {
            _medicalDatabase = database;
            _medicalDatabase?.Initialize();
        }

        // Stage 4: the return callback succeeds only after inventory placement commits.
        // World dropping remains in the existing context-menu stub for Stage 4.5.
        public void ConfigureInventory(Func<uint, InventoryItem> findItem,
            Action<uint, int, float> updateCharge, Func<AppliedMedicalRecord, bool> canReturn,
            Func<AppliedMedicalRecord, bool> returnItem, Action<uint> expireItem,
            Action refreshAfterExpiration = null)
        {
            _findItem = findItem;
            _updateCharge = updateCharge;
            _canReturn = canReturn;
            _returnItem = returnItem;
            _expireItem = expireItem;
            _refreshAfterExpiration = refreshAfterExpiration;
        }

        public static bool TryGetKind(string itemID, out AppliedGhostKind kind)
            => TryGetKind(MedicalDatabase.Instance, itemID, out kind);

        public static bool TryGetKind(MedicalDatabase database, string itemID,
            out AppliedGhostKind kind)
        {
            kind = AppliedGhostKind.Tourniquet;
            if (database == null || !database.TryGetEntry(itemID, out var entry)) return false;
            if ((entry.Effects & MedicalEffect.JETT) != 0)
            {
                kind = AppliedGhostKind.JETT;
                return true;
            }
            return (entry.Effects & MedicalEffect.BleedingArterial) != 0;
        }

        public static bool IsParentPart(BodyPart part)
            => part == BodyPart.LeftShoulder || part == BodyPart.RightShoulder
            || part == BodyPart.LeftQuadriceps || part == BodyPart.RightQuadriceps;

        public static BodyPart? GetParentPart(BodyPart part)
        {
            switch (part)
            {
                case BodyPart.LeftShoulder: case BodyPart.LeftBiceps:
                case BodyPart.LeftForearm: case BodyPart.LeftHand: return BodyPart.LeftShoulder;
                case BodyPart.RightShoulder: case BodyPart.RightBiceps:
                case BodyPart.RightForearm: case BodyPart.RightHand: return BodyPart.RightShoulder;
                case BodyPart.LeftQuadriceps: case BodyPart.LeftKnee:
                case BodyPart.LeftShin: case BodyPart.LeftFoot: return BodyPart.LeftQuadriceps;
                case BodyPart.RightQuadriceps: case BodyPart.RightKnee:
                case BodyPart.RightShin: case BodyPart.RightFoot: return BodyPart.RightQuadriceps;
                default: return null;
            }
        }

        public AppliedMedicalRecord GetRecordFor(BodyPart part, AppliedGhostKind kind)
        {
            var record = GetRecordForPart(part);
            return record != null && record.Kind == kind ? record : null;
        }

        public AppliedMedicalRecord GetRecordForPart(BodyPart part)
        {
            var parent = GetParentPart(part);
            if (!parent.HasValue) return null;
            for (int i = 0; i < _records.Count; i++)
                if (_records[i].AppliedTo == parent.Value) return _records[i];
            return null;
        }

        public AppliedMedicalRecord GetRecordForInstance(uint instanceID)
        {
            for (int i = 0; i < _records.Count; i++)
                if (_records[i].InstanceID == instanceID) return _records[i];
            return null;
        }

        public bool CanApplyOnPart(BodyPart parentPart, AppliedGhostKind kind, out string reason)
        {
            reason = null;
            if (_health == null) { reason = "Система здоровья не готова"; return false; }
            if (_health.IsDead) { reason = "Персонаж мёртв"; return false; }
            if (!IsParentPart(parentPart))
            { reason = "Выберите плечо или бедро"; return false; }
            if (kind != AppliedGhostKind.Tourniquet && kind != AppliedGhostKind.JETT)
            { reason = "Неизвестное механическое средство"; return false; }
            if (GetRecordForPart(parentPart) != null)
            { reason = "На этой конечности уже есть жгут или JETT"; return false; }

            var chain = _health.GetMechanicalLimbChain(parentPart);
            if (kind == AppliedGhostKind.JETT)
            {
                if (_health.GetBleedingLevel(parentPart) > 0) return true;
                reason = "Нет наружного кровотечения в паховой или подмышечной области";
                return false;
            }
            for (int i = 0; i < chain.Count; i++)
                if (_health.GetBleedingLevel(chain[i]) > 0)
                    return true;
            reason = kind == AppliedGhostKind.JETT
                ? "На конечности нет внешнего или внутреннего кровотечения"
                : "На конечности нет внешнего кровотечения";
            return false;
        }

        public bool CanApply(InventoryItem item, BodyPart parentPart,
            AppliedGhostKind kind, out string reason)
        {
            reason = null;
            if (item == null || item.Data == null)
            { reason = "Предмет не найден"; return false; }
            if (item.Quantity != 1)
            { reason = "Жгут и JETT должны быть отдельными предметами"; return false; }
            if (!TryGetKind(_medicalDatabase ?? MedicalDatabase.Instance,
                item.Data.ItemID, out var actualKind) || actualKind != kind)
            { reason = "Этот предмет не подходит для выбранного лечения"; return false; }
            // Stage 4: seconds own reusable charge; display rounding cannot replenish it.
            if (!IsFinitePositive(item.RemainingChargeSeconds))
            { reason = "Заряд исчерпан"; return false; }
            if (GetRecordForInstance(item.InstanceID) != null)
            { reason = "Предмет уже применён"; return false; }
            return CanApplyOnPart(parentPart, kind, out reason);
        }

        public bool TryApply(InventoryItem item, BodyPart parentPart,
            AppliedGhostKind kind, out string reason)
        {
            if (!CanApply(item, parentPart, kind, out reason)) return false;
            var record = CreateRecord(item.Data, item.InstanceID, item.Quantity,
                item.Durability, item.ChargePercent, item.RemainingChargeSeconds,
                parentPart, kind, false);
            record.RuntimeItem = item;
            AddAndSuppress(record);
            return true;
        }

        public bool TryApplyFromContainer(string itemID, int quantity, int durability,
            BodyPart parentPart, AppliedGhostKind kind, out string reason)
            => TryApplyFromContainer(itemID, quantity, durability, 100, 0,
                parentPart, kind, out reason);

        // Stage 4: preserve the actual remaining charge and instance identity from loot.
        public bool TryApplyFromContainer(string itemID, int quantity, int durability,
            int chargePercent, uint instanceID, BodyPart parentPart,
            AppliedGhostKind kind, out string reason)
            => TryApplyFromContainer(itemID, quantity, durability, chargePercent,
                -1f, instanceID, parentPart, kind, out reason);

        // Stage 4: this path carries exact saved loot charge across removal/application.
        public bool TryApplyFromContainer(string itemID, int quantity, int durability,
            int chargePercent, float remainingChargeSeconds, uint instanceID,
            BodyPart parentPart, AppliedGhostKind kind, out string reason)
        {
            reason = null;
            var database = _itemDatabase ?? K_InventorySetup.DatabaseInstance;
            var data = database?.GetItemData(itemID);
            if (data == null || quantity <= 0)
            { reason = "Данные предмета не найдены"; return false; }
            if (quantity != 1)
            { reason = "Жгут и JETT должны быть отдельными предметами"; return false; }
            if (!TryGetKind(_medicalDatabase ?? MedicalDatabase.Instance, itemID,
                out var actualKind) || actualKind != kind)
            { reason = "Этот предмет не подходит для выбранного лечения"; return false; }
            if (remainingChargeSeconds != -1f && !IsFinitePositive(remainingChargeSeconds))
            { reason = "Заряд исчерпан"; return false; }
            if (remainingChargeSeconds == -1f && chargePercent <= 0)
            { reason = "Заряд исчерпан"; return false; }
            if (instanceID != 0 && GetRecordForInstance(instanceID) != null)
            { reason = "Предмет уже применён"; return false; }
            if (!CanApplyOnPart(parentPart, kind, out reason)) return false;
            if (instanceID == 0) instanceID = AllocateVirtualID();
            AddAndSuppress(CreateRecord(data, instanceID, quantity, durability,
                chargePercent, remainingChargeSeconds, parentPart, kind, true));
            return true;
        }

        private uint AllocateVirtualID()
        {
            // Stage 4: share the inventory allocator; synthetic high IDs break later registration.
            uint id;
            do { id = GlobalIDManager.GenerateID(); }
            while (id == 0 || GetRecordForInstance(id) != null || _findItem?.Invoke(id) != null);
            return id;
        }

        private static AppliedMedicalRecord CreateRecord(ItemStaticData data,
            uint instanceID, int quantity, int durability, int chargePercent,
            float remainingChargeSeconds, BodyPart parentPart,
            AppliedGhostKind kind, bool isVirtual)
        {
            float duration = data.FullChargeSeconds;
            if (float.IsNaN(duration) || float.IsInfinity(duration) || duration <= 0f)
                duration = DefaultFullChargeSeconds;
            int charge = Mathf.Clamp(chargePercent, 0, 100);
            // Stage 4: integer percent is a display/fresh-item fallback only.
            float remaining = remainingChargeSeconds == -1f
                ? charge / 100f * duration : Mathf.Clamp(remainingChargeSeconds, 0f, duration);
            charge = RemainingPercent(remaining, duration);
            return new AppliedMedicalRecord
            {
                InstanceID = instanceID, AppliedTo = parentPart, Kind = kind,
                ChargePercent = charge, RemainingSeconds = remaining,
                FullChargeSeconds = duration, IsVirtual = isVirtual,
                IsPersistent = true, ElapsedSeconds = 0f,
                VirtualItemID = data.ItemID, VirtualQuantity = quantity,
                VirtualDurability = Mathf.Clamp(durability, 0, data.MaxDurability)
            };
        }

        private void AddAndSuppress(AppliedMedicalRecord record)
        {
            _records.Add(record);
            _health.SuppressMechanicalBleeding(record, captureSnapshot: true);
            _health.NotifyAppliedMedicalChanged();
            Debug.Log($"[Health] Applied {record.Kind} on {record.AppliedTo}: "
                + $"{record.ChargePercent}% ({record.RemainingSeconds:F1}s).");
        }

        // Stage 4: every external-bleeding producer uses this, including direct setters.
        internal bool CaptureSuppressedBleeding(BodyPart part, int proposedLevel)
        {
            var record = GetRecordForPart(part);
            if (record == null) return false;
            int key = (int)part;
            record.SavedBleeding.TryGetValue(key, out int previous);
            record.SavedBleeding[key] = Mathf.Max(previous, Mathf.Clamp(proposedLevel, 0, 3));
            _health.MarkAppliedMedicalDirty();
            return true;
        }

        // Stage 4: reconcile late-loaded inventory without advancing charge, also when dead.
        public void SynchronizeInventory()
        {
            for (int i = 0; i < _records.Count; i++)
                if (!_records[i].IsVirtual) SynchronizeRecord(_records[i]);
        }

        private void SynchronizeRecord(AppliedMedicalRecord record)
        {
            var item = ResolveItem(record);
            if (item != null) item.RemainingChargeSeconds = record.RemainingSeconds;
            // Stage 4: serialized nested contents receive every exact second update too.
            _updateCharge?.Invoke(record.InstanceID, record.ChargePercent, record.RemainingSeconds);
        }

        public void Tick(float dt, Action<uint, int, float> onItemChargeChanged = null,
            Action<AppliedMedicalRecord> onExpired = null)
        {
            // Stage 4: death freezes the record and retains inventory ownership until Load.
            if (_health == null || _health.IsDead) return;
            if (float.IsNaN(dt) || float.IsInfinity(dt) || dt <= 0f) return;
            bool chargeChanged = false;
            bool ownershipChanged = false;
            for (int i = _records.Count - 1; i >= 0; i--)
            {
                var record = _records[i];
                if (record.IsPersistent)
                {
                    record.ElapsedSeconds = Mathf.Min(86400000f, record.ElapsedSeconds + dt);
                    if (!record.IsVirtual) SynchronizeRecord(record);
                    continue;
                }
                record.RemainingSeconds = Mathf.Max(0f, record.RemainingSeconds - dt);
                // Stage 4: ceil keeps 0% exclusive to true expiration; V8 stores exact seconds.
                int percent = RemainingPercent(record.RemainingSeconds, record.FullChargeSeconds);
                bool changed = percent != record.ChargePercent;
                record.ChargePercent = percent;

                if (!record.IsVirtual)
                {
                    SynchronizeRecord(record);
                    onItemChargeChanged?.Invoke(record.InstanceID, percent, record.RemainingSeconds);
                }
                chargeChanged |= changed;
                if (record.RemainingSeconds > 0f) continue;

                // Stage 4: expire removes the source once and never materializes virtual loot.
                if (!record.IsVirtual) _expireItem?.Invoke(record.InstanceID);
                _health.RestoreMechanicalBleeding(record);
                _records.RemoveAt(i);
                ownershipChanged = true;
                Debug.Log($"[Health] Applied {record.Kind} expired on {record.AppliedTo}.");
                onExpired?.Invoke(record);
                chargeChanged = true;
            }
            if (_records.Count > 0 || chargeChanged) _health.MarkAppliedMedicalDirty();
            if (chargeChanged) _health.NotifyAppliedMedicalChanged();
            if (ownershipChanged) _refreshAfterExpiration?.Invoke();
        }

        private InventoryItem ResolveItem(AppliedMedicalRecord record)
            => _findItem?.Invoke(record.InstanceID) ?? record.RuntimeItem;

        public bool CanRemove(AppliedMedicalRecord record, out string reason)
        {
            reason = null;
            if (record == null || !_records.Contains(record))
            { reason = "Средство уже снято"; return false; }
            if (record.IsVirtual)
            {
                if (_returnItem == null || _canReturn == null)
                { reason = "Инвентарь не готов"; return false; }
                if (!_canReturn(record)) { reason = "Нет места в инвентаре"; return false; }
            }
            // Stage 4: held items remain in their slot; lookup availability cannot block removal.
            return true;
        }

        public bool TryRemove(AppliedMedicalRecord record, out string reason)
        {
            if (!CanRemove(record, out reason)) return false;
            if (record.IsVirtual)
            {
                if (!_returnItem(record)) { reason = "Нет места в инвентаре"; return false; }
            }
            else
            {
                var item = ResolveItem(record);
                if (item != null) item.RemainingChargeSeconds = record.RemainingSeconds;
                _updateCharge?.Invoke(record.InstanceID, record.ChargePercent, record.RemainingSeconds);
            }
            FinishRemoval(record);
            return true;
        }

        private void FinishRemoval(AppliedMedicalRecord record)
        {
            _health.RestoreMechanicalBleeding(record);
            _records.Remove(record);
            _health.NotifyAppliedMedicalChanged();
            Debug.Log($"[Health] Removed {record.Kind} from {record.AppliedTo}: {record.ChargePercent}%.");
        }

        public void Save(BinaryWriter writer)
        {
            writer.Write(_records.Count);
            for (int i = 0; i < _records.Count; i++)
            {
                var record = _records[i];
                writer.Write(record.InstanceID);
                writer.Write((byte)record.AppliedTo);
                writer.Write((byte)record.Kind);
                writer.Write(record.ChargePercent);
                writer.Write(record.RemainingSeconds);
                writer.Write(record.FullChargeSeconds);
                writer.Write(record.IsVirtual);
                writer.Write(record.VirtualItemID ?? string.Empty);
                writer.Write(record.VirtualQuantity);
                writer.Write(record.VirtualDurability);
                var chain = _health.GetMechanicalLimbChain(record.AppliedTo);
                writer.Write(chain.Count);
                for (int j = 0; j < chain.Count; j++)
                {
                    int key = (int)chain[j];
                    writer.Write(key);
                    record.SavedBleeding.TryGetValue(key, out int level);
                    writer.Write(level);
                }
            }
        }

// ═══════════════════════════════════════════════════════════════
// Stage 4.5.1: снятие applied-средства под выброс в мир.
//
// Отличие от TryRemove:
//   - НЕ пытается вернуть предмет в инвентарь (нет проверки «Нет места»);
//   - для non-virtual синхронизирует оставшийся заряд в живой предмет;
//   - вызывает FinishRemoval (release effect + restore bleeding);
//   - вызывающий код (K_ContextMenu) ОБЯЗАН:
//       * для non-virtual: удалить живой InventoryItem из контроллера;
//       * для всех: спавнить K_WorldItem в мире.
// ═══════════════════════════════════════════════════════════════
public bool TryRemoveForWorldDrop(AppliedMedicalRecord record, out string reason)
{
    reason = null;
    if (record == null || !_records.Contains(record))
    {
        reason = "Средство уже снято";
        return false;
    }
    if (!record.IsVirtual)
    {
        var item = ResolveItem(record);
        if (item != null) item.RemainingChargeSeconds = record.RemainingSeconds;
    }
    FinishRemoval(record);
    return true;
}
        public void Load(BinaryReader reader)
        {
            // Stage 4: validate all records before replacing the runtime list.
            int count = reader.ReadInt32();
            if (count < 0 || count > 4) throw new InvalidDataException("Invalid applied-medical count.");
            var loaded = new List<AppliedMedicalRecord>(count);
            var parents = new HashSet<BodyPart>();
            var ids = new HashSet<uint>();
            for (int i = 0; i < count; i++)
            {
                var record = new AppliedMedicalRecord
                {
                    InstanceID = reader.ReadUInt32(), AppliedTo = (BodyPart)reader.ReadByte(),
                    Kind = (AppliedGhostKind)reader.ReadByte(), ChargePercent = reader.ReadInt32(),
                    RemainingSeconds = reader.ReadSingle(), FullChargeSeconds = reader.ReadSingle(),
                    IsVirtual = reader.ReadBoolean(), VirtualItemID = reader.ReadString(),
                    VirtualQuantity = reader.ReadInt32(), VirtualDurability = reader.ReadInt32()
                };
                if (!IsParentPart(record.AppliedTo) || !parents.Add(record.AppliedTo)
                    || record.InstanceID == 0 || !ids.Add(record.InstanceID)
                    || (record.Kind != AppliedGhostKind.Tourniquet && record.Kind != AppliedGhostKind.JETT)
                    || record.ChargePercent <= 0 || record.ChargePercent > 100
                    || !IsFinitePositive(record.FullChargeSeconds)
                    || !IsFinitePositive(record.RemainingSeconds)
                    || record.RemainingSeconds > record.FullChargeSeconds
                    || string.IsNullOrEmpty(record.VirtualItemID) || record.VirtualQuantity <= 0
                    || record.VirtualDurability < 0)
                    throw new InvalidDataException("Invalid applied-medical record.");
                var chain = _health.GetMechanicalLimbChain(record.AppliedTo);
                int snapshotCount = reader.ReadInt32();
                if (snapshotCount != chain.Count)
                    throw new InvalidDataException("Invalid applied bleeding snapshot length.");
                for (int j = 0; j < snapshotCount; j++)
                {
                    int key = reader.ReadInt32();
                    int level = reader.ReadInt32();
                    if (key != (int)chain[j] || level < 0 || level > 3)
                        throw new InvalidDataException("Invalid applied bleeding snapshot.");
                    record.SavedBleeding.Add(key, level);
                }
                // Stage 4: exact seconds, never the rounded percentage, own the loaded timer.
                record.ChargePercent = RemainingPercent(record.RemainingSeconds, record.FullChargeSeconds);
                loaded.Add(record);
            }
            _records.Clear();
            _records.AddRange(loaded);
            for (int i = 0; i < _records.Count; i++)
            {
                GlobalIDManager.ObserveID(_records[i].InstanceID);
                _health.SuppressMechanicalBleeding(_records[i], captureSnapshot: false);
            }
        }

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
            => ValidateLoad(reader, context, null);

        internal void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context, ISet<uint> identities)
        {
            int count = reader.ReadInt32();
            if (count < 0 || count > 4) throw new InvalidDataException("Invalid applied-medical count.");
            var parents = new HashSet<BodyPart>();
            var ids = new HashSet<uint>();
            for (int i = 0; i < count; i++)
            {
                uint id = reader.ReadUInt32();
                var parent = (BodyPart)reader.ReadByte();
                var kind = (AppliedGhostKind)reader.ReadByte();
                int charge = reader.ReadInt32();
                float remaining = SaveLoadValidationContext.ReadFinite(reader, true);
                float full = SaveLoadValidationContext.ReadFinite(reader, true);
                bool isVirtual = reader.ReadBoolean();
                string itemID = reader.ReadString();
                int quantity = reader.ReadInt32();
                int durability = reader.ReadInt32();
                if (!IsParentPart(parent) || !parents.Add(parent) || id == 0 || id == uint.MaxValue || !ids.Add(id) ||
                    (kind != AppliedGhostKind.Tourniquet && kind != AppliedGhostKind.JETT) ||
                    charge <= 0 || charge > 100 || remaining <= 0f || full <= 0f || remaining > full ||
                    string.IsNullOrEmpty(itemID) || quantity <= 0 || durability < 0)
                    throw new InvalidDataException("Invalid applied-medical record.");
                var chain = _health.GetMechanicalLimbChain(parent);
                if (reader.ReadInt32() != chain.Count)
                    throw new InvalidDataException("Invalid applied bleeding snapshot length.");
                for (int j = 0; j < chain.Count; j++)
                {
                    int key = reader.ReadInt32(), level = reader.ReadInt32();
                    if (key != (int)chain[j] || level < 0 || level > 3)
                        throw new InvalidDataException("Invalid applied bleeding snapshot.");
                }
                if (isVirtual) context.Own(id, "PlayerHealth virtual applied item");
                identities?.Add(id);
            }
        }

        private static bool IsFinitePositive(float value)
            => !float.IsNaN(value) && !float.IsInfinity(value) && value > 0f;

        private static int RemainingPercent(float remaining, float duration)
            => remaining <= 0f ? 0
                : Mathf.Clamp(Mathf.CeilToInt(100f * remaining / duration), 1, 100);


    }
}
