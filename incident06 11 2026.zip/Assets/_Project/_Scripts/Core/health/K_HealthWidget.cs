﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using System.Collections.Generic; 

namespace K_Incident.Core.UI
{
    public class K_HealthWidget : MonoBehaviour
    {
        // =====================================================================
        // СИСТЕМНЫЕ ССЫЛКИ
        // =====================================================================
        [Header("System References")]
        [SerializeField] private K_HealthSystem _healthSystem;
        [SerializeField] private K_VitalitySystem _vitalitySystem;
        [SerializeField] private K_TimeSystem _timeSystem;
        // Stage 1: _coagulantItem удалён (K_CoagulantItem.cs удалён из проекта).
        [SerializeField] private K_WeightManager _weightManager;

        // =====================================================================
        // КУКЛА ЗДОРОВЬЯ
        // =====================================================================
        [Header("Health Doll (Segments) — index = (int)BodyPart")]
        [SerializeField]
        private Image[] _segmentImages = new Image[20];

        [SerializeField] private Gradient _healthGradient;

        // =====================================================================
        // ИНДИКАТОРЫ МЕТАБОЛИЗМА
        // =====================================================================
        [Header("Metabolism & Status Icons")]
        [SerializeField] private CanvasGroup _metabolismGroup;
        [SerializeField] private Gradient _statusGradient;
        [SerializeField] private Gradient _bleedingGradient;
        [SerializeField] private Gradient _hungerGradient;
        [SerializeField] private Gradient _thirstGradient;
        [SerializeField] private Gradient _radiationGradient;
        [SerializeField] private Gradient _overloadGradient;

        [Space]
        [SerializeField] private Image _iconHunger;
        [SerializeField] private Image _iconThirst;
        [SerializeField] private Image _iconRadiation;
        [SerializeField] private Image _iconCold;
        [SerializeField] private Image _iconOverload;
        [SerializeField] private Image _iconBleeding;
        [SerializeField] private Image _iconLaceration;
        [SerializeField] private Image _iconHangover;
        [SerializeField] private Image _iconDrunk;
        [SerializeField] private Image _iconStimOn;
        [SerializeField] private Image _iconStimOff;
        [SerializeField] private Image _iconCoagulant;
        [SerializeField, Tooltip("Цвет иконки коагулянта при показе.")]
        private Color _coagulantIconColor = Color.white;

        // =====================================================================
        // ИНДИКАТОРЫ ПЕРЕЛОМОВ
        // =====================================================================
        [Header("Fracture Icon (Iteration 5)")]
        [SerializeField] private Image _iconFracture;
        [SerializeField] private TextMeshProUGUI _fractureCountText;

        [Header("Gunshot Icon (Iteration 6)")]
        [SerializeField] private Image _iconGunshot;

        // =====================================================================
        // НАСТРОЙКИ UI
        // =====================================================================
        [Header("UI Settings")]
        [SerializeField] private TextMeshProUGUI _clockText;
        public RectTransform ClockRect => _clockText != null ? _clockText.rectTransform : null;
        [SerializeField] private float _hudDisplayDuration = 4.0f;
        [SerializeField] private float _hudFadeSpeed = 2.0f;

        [Header("Blood UI (Iteration 3)")]
        [SerializeField] private TextMeshProUGUI _bloodText;
        [SerializeField] private Gradient _bloodTextGradient;
        [SerializeField] private K_BloodSystem _bloodSystem;

        [Header("Debuff Icons (Iteration 4 — placeholders)")]
        [SerializeField] private Image _iconConcussion;
        [SerializeField] private Image _iconTBI;
        [SerializeField] private Image _iconBreathingDifficulty;
        [SerializeField] private Image _iconImmobilized;
        [SerializeField] private Image _iconInternalBleeding;
        [SerializeField] private TextMeshProUGUI _ibCountText;
        [SerializeField] private K_DebuffSystem _debuffSystem;

        // =====================================================================
        // ВНУТРЕННИЕ ПЕРЕМЕННЫЕ
        // =====================================================================
             private Coroutine _fadeCoroutine;
        private Coroutine _clockCoroutine;
        private float _displayTimer = 0f;

        private const int SEGMENT_COUNT = 20;

        // Stage 1 диагностика: one-shot логи.
        private readonly HashSet<Image> _iconSetLog = new HashSet<Image>();
        private bool _fractureLogged;
        private bool _gunshotLogged;
        private bool _debuffLogged;
        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================

        private void SetupSegmentClickHandlers()
        {
            if (_segmentImages == null || _segmentImages.Length == 0) return;

            int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
            for (int i = 0; i < count; i++)
            {
                var img = _segmentImages[i];
                if (img == null) continue;

                img.raycastTarget = true;

                var trigger = img.gameObject.GetComponent<EventTrigger>();
                if (trigger == null) trigger = img.gameObject.AddComponent<EventTrigger>();

                var entry = new EventTrigger.Entry { eventID = EventTriggerType.PointerClick };
                int capturedIndex = i;
                entry.callback.AddListener(_ =>
                {
                    var part = (BodyPart)capturedIndex;
                    K_CombatTestController.SetTargetPart(part);
                });
                trigger.triggers.Add(entry);
                img.alphaHitTestMinimumThreshold = 0.1f;
            }
        }

        private void Start()
        {
            // Stage 1 инвариант №9: FindFirstObjectByType — только в Start.
            if (_healthSystem   == null) _healthSystem   = FindFirstObjectByType<K_HealthSystem>();
            if (_vitalitySystem == null) _vitalitySystem = FindFirstObjectByType<K_VitalitySystem>();
            if (_timeSystem     == null) _timeSystem     = FindFirstObjectByType<K_TimeSystem>();
            if (_weightManager  == null) _weightManager  = FindFirstObjectByType<K_WeightManager>();
            if (_bloodSystem    == null) _bloodSystem    = FindFirstObjectByType<K_BloodSystem>();
            if (_debuffSystem   == null) _debuffSystem   = FindFirstObjectByType<K_DebuffSystem>();

            if (_segmentImages == null || _segmentImages.Length != SEGMENT_COUNT)
                Debug.LogWarning($"[K_HealthWidget] _segmentImages должен быть размером {SEGMENT_COUNT}, сейчас {_segmentImages?.Length ?? 0}");

                      SetupSegmentClickHandlers();
            ValidateIconReferences();   // Stage 1: диагностика null / без спрайта
            RefreshDebuffIcons();

            if (_healthSystem == null || _vitalitySystem == null || _timeSystem == null)
            {
                Debug.LogWarning("[K_HealthWidget] Core systems missing. " +
                    $"HealthSystem={_healthSystem != null}, VitalitySystem={_vitalitySystem != null}, TimeSystem={_timeSystem != null}. " +
                    "Assign them in Inspector or ensure they exist in scene.");
            }

            ForceHealthDollVisible();

            if (_metabolismGroup != null && _metabolismGroup.alpha < 1f)
                _metabolismGroup.alpha = 1f;

            // Stage 1: иконка коагулянта — placeholder, скрыта по умолчанию.
            // Будет переиспользована под Icon_Gel в UI-итерации (правка .asset).
            if (_iconCoagulant != null)
                _iconCoagulant.gameObject.SetActive(false);

            // Повторная подписка — OnEnable подписаться не мог (ссылки были null).
            Subscribe();

            RefreshHealth();
            RefreshMetabolism();

            _clockCoroutine = StartCoroutine(ClockUpdateRoutine());

            Debug.Log("[K_HealthWidget] Initialized successfully");
        }

        private void ForceHealthDollVisible()
        {
            if (_segmentImages == null) return;

            foreach (var img in _segmentImages)
            {
                if (img != null)
                {
                    img.enabled = true;
                    img.color = new Color(img.color.r, img.color.g, img.color.b, 1f);
                }
            }
        }

        private void OnEnable()
        {
            ForceHealthDollVisible();
            // Stage 1: подписка до Start — no-op, если системы ещё не найдены.
            // Реальная подписка произойдёт в Start после авто-файнда.
            Subscribe();
            ForceRefresh();
            RefreshBloodUI();
            RefreshDebuffIcons();
        }

        private void OnDisable()
        {
            Unsubscribe();
        }

        /// <summary>
        /// Stage 1: идемпотентная подписка. Сначала снимаем — потом ставим заново.
        /// Вызывается из OnEnable (системы могут быть null) и из Start (системы не null).
        /// </summary>
        private void Subscribe()
        {
            if (_healthSystem != null) _healthSystem.OnHealthChanged -= RefreshHealth;
            if (_vitalitySystem != null)
            {
                _vitalitySystem.OnMetabolismChanged   -= RefreshMetabolism;
                _vitalitySystem.OnStimulatorChanged   -= RefreshMetabolism;
                _vitalitySystem.OnHangoverChanged     -= RefreshMetabolism;
                _vitalitySystem.OnColdExposureChanged -= RefreshMetabolism;
                _vitalitySystem.OnOverloadChanged     -= RefreshMetabolism;
            }
            if (_weightManager != null) _weightManager.OnWeightChanged -= RefreshMetabolism;
            if (_bloodSystem != null)   _bloodSystem.OnBloodChanged    -= RefreshBloodUI;
            if (_debuffSystem != null)  _debuffSystem.OnDebuffsChanged -= RefreshDebuffIcons;

            if (_healthSystem != null) _healthSystem.OnHealthChanged += RefreshHealth;
            if (_vitalitySystem != null)
            {
                _vitalitySystem.OnMetabolismChanged   += RefreshMetabolism;
                _vitalitySystem.OnStimulatorChanged   += RefreshMetabolism;
                _vitalitySystem.OnHangoverChanged     += RefreshMetabolism;
                _vitalitySystem.OnColdExposureChanged += RefreshMetabolism;
                _vitalitySystem.OnOverloadChanged     += RefreshMetabolism;
            }
            if (_weightManager != null) _weightManager.OnWeightChanged += RefreshMetabolism;
            if (_bloodSystem != null)   _bloodSystem.OnBloodChanged    += RefreshBloodUI;
            if (_debuffSystem != null)  _debuffSystem.OnDebuffsChanged += RefreshDebuffIcons;
        }

        private void Unsubscribe()
        {
            if (_healthSystem != null) _healthSystem.OnHealthChanged -= RefreshHealth;
            if (_vitalitySystem != null)
            {
                _vitalitySystem.OnMetabolismChanged   -= RefreshMetabolism;
                _vitalitySystem.OnStimulatorChanged   -= RefreshMetabolism;
                _vitalitySystem.OnHangoverChanged     -= RefreshMetabolism;
                _vitalitySystem.OnColdExposureChanged -= RefreshMetabolism;
                _vitalitySystem.OnOverloadChanged     -= RefreshMetabolism;
            }
            if (_weightManager != null) _weightManager.OnWeightChanged -= RefreshMetabolism;
            if (_bloodSystem != null)   _bloodSystem.OnBloodChanged    -= RefreshBloodUI;
            if (_debuffSystem != null)  _debuffSystem.OnDebuffsChanged -= RefreshDebuffIcons;
        }

        private void OnDestroy()
        {
            if (_clockCoroutine != null) StopCoroutine(_clockCoroutine);
            if (_fadeCoroutine != null) StopCoroutine(_fadeCoroutine);
        }

        // =====================================================================
        // РЕФРЕШИ
        // =====================================================================

        private void RefreshHealth()
        {
            UpdateHealthUI();
            UpdateFractureIcon();
            UpdateGunshotIcon();
            // Stage 3: revealed IB count can change without changing the debuff boolean.
            RefreshDebuffIcons();
            // Stage 1: UpdateCoagulantIcon() удалён — иконка placeholder.
            ShowMetabolismHUD();
        }

        private void RefreshMetabolism()
        {
            UpdateMetabolismUI();
            ShowMetabolismHUD();
        }

        private void RefreshBloodUI()
        {
            if (_bloodText == null || _bloodSystem == null) return;

            float p = _bloodSystem.BloodPercent;
            int percentInt = Mathf.RoundToInt(p * 100f);
            _bloodText.text = $"{percentInt}%";

            if (_bloodTextGradient != null)
            {
                Color c = _bloodTextGradient.Evaluate(p);
                _bloodText.color = c;
            }
        }

        private void UpdateHealthUI()
        {
            if (_healthSystem == null)
            {
                Debug.LogWarning("[K_HealthWidget] HealthSystem is null!");
                return;
            }

            if (_healthGradient == null)
            {
                Debug.LogWarning("[K_HealthWidget] HealthGradient is null!");
                return;
            }

            if (_segmentImages == null) return;

            int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
            for (int i = 0; i < count; i++)
            {
                var part = (BodyPart)i;
                UpdateSegmentColor(_segmentImages[i], part);
            }
        }

        private void UpdateSegmentColor(Image img, BodyPart part)
        {
            if (img == null || _healthSystem == null || _healthGradient == null) return;

            float cur = _healthSystem.GetHP(part);
            float max = _healthSystem.GetMaxHP(part);
            if (max <= 0f) return;

            float ratio = Mathf.Clamp01(cur / max);
            Color c = _healthGradient.Evaluate(ratio);
            img.enabled = true;
            img.color = new Color(c.r, c.g, c.b, 1f);
        }

            private void UpdateFractureIcon()
        {
            if (_healthSystem == null) return;

            int count = _healthSystem.FractureCount;

            if (_iconFracture != null)
                _iconFracture.gameObject.SetActive(count > 0);

            if (_fractureCountText != null)
            {
                _fractureCountText.gameObject.SetActive(count > 1);
                if (count > 1)
                    _fractureCountText.text = count.ToString();
            }

            if (!_fractureLogged)
            {
                _fractureLogged = true;
                Debug.Log($"[K_HealthWidget] UpdateFractureIcon FIRST: count={count}, " +
                          $"_iconFracture={(_iconFracture != null ? "ok" : "NULL")}");
            }
        }

        private void UpdateGunshotIcon()
        {
            if (_healthSystem == null) return;
            if (_iconGunshot == null) return;

            bool any = _healthSystem.HasGunshot;
            if (_iconGunshot.gameObject.activeSelf != any)
                _iconGunshot.gameObject.SetActive(any);

            if (!_gunshotLogged)
            {
                _gunshotLogged = true;
                Debug.Log($"[K_HealthWidget] UpdateGunshotIcon FIRST: any={any}");
            }
        }

        private void UpdateMetabolismUI()
        {
            if (_vitalitySystem == null) return;

            SafeUpdateIcon(_iconHunger, _vitalitySystem.Icon_Hunger, _vitalitySystem.Hunger / 100f, _hungerGradient);
            SafeUpdateIcon(_iconThirst, _vitalitySystem.Icon_Thirst, _vitalitySystem.Thirst / 100f, _thirstGradient);
            SafeUpdateIcon(_iconRadiation, _vitalitySystem.Icon_Radiation, 1f - (_vitalitySystem.Radiation / 100f), _radiationGradient);

            if (_vitalitySystem.Icon_Bleeding > 0)
                SafeUpdateIcon(_iconBleeding, true, _vitalitySystem.Icon_Bleeding / 3f, _bleedingGradient);
            else
                SafeUpdateIcon(_iconBleeding, false);

            SafeUpdateIcon(_iconLaceration, _vitalitySystem.Icon_Laceration);
            SafeUpdateIcon(_iconStimOn,     _vitalitySystem.Icon_StimOn);
            SafeUpdateIcon(_iconStimOff,    _vitalitySystem.Icon_StimOff);
            SafeUpdateIcon(_iconHangover,   _vitalitySystem.Icon_Hangover);
            SafeUpdateIcon(_iconCold,       _vitalitySystem.Icon_Cold);

            if (_weightManager != null)
            {
                float weightRatio = _weightManager.GetCurrentWeightRatio();
                bool isOverloaded = weightRatio >= 0.9f;
                if (isOverloaded)
                {
                    float normalizedRatio = Mathf.Clamp01(Mathf.InverseLerp(0.9f, 1.1f, weightRatio));
                    SafeUpdateIcon(_iconOverload, true, normalizedRatio, _overloadGradient);
                }
                else
                    SafeUpdateIcon(_iconOverload, false);
            }
            else
                SafeUpdateIcon(_iconOverload, _vitalitySystem.Icon_Overload);

            SafeUpdateIcon(_iconDrunk, _vitalitySystem.Icon_Drunk);
        }

        private void SafeUpdateIcon(Image img, bool isActive, float? colorT = null, Gradient customGradient = null)
        {
            if (img == null) return;
            if (img.gameObject.activeSelf != isActive)
                img.gameObject.SetActive(isActive);
            if (isActive && colorT.HasValue)
            {
                Gradient g = customGradient != null ? customGradient : _statusGradient;
                if (g != null)
                    img.color = g.Evaluate(Mathf.Clamp01(colorT.Value));
            }
        }

             private void RefreshDebuffIcons()
        {
            if (_debuffSystem == null)
            {
                if (_ibCountText != null) _ibCountText.gameObject.SetActive(false);
                return;
            }

            SetIconActive(_iconConcussion,          _debuffSystem.HasConcussion);
            SetIconActive(_iconTBI,                 _debuffSystem.HasTBI);
            SetIconActive(_iconBreathingDifficulty, _debuffSystem.HasBreathingDifficulty);
            SetIconActive(_iconImmobilized,         _debuffSystem.HasImmobilized);
            SetIconActive(_iconInternalBleeding,    _debuffSystem.HasInternalBleeding);

            int count = _healthSystem != null ? _healthSystem.GetInternalBleedingRevealedCount() : 0;
            if (_ibCountText != null)
            {
                _ibCountText.gameObject.SetActive(count > 1);
                if (count > 1) _ibCountText.text = count.ToString();
            }

            if (!_debuffLogged)
            {
                _debuffLogged = true;
                Debug.Log($"[K_HealthWidget] RefreshDebuffIcons FIRST: " +
                          $"Concussion={_debuffSystem.HasConcussion}, TBI={_debuffSystem.HasTBI}, " +
                          $"Breathing={_debuffSystem.HasBreathingDifficulty}, " +
                          $"Immobilized={_debuffSystem.HasImmobilized}, IB={_debuffSystem.HasInternalBleeding}");
            }
        }

             private void SetIconActive(Image icon, bool active)
        {
            if (icon == null) return;
            if (icon.gameObject.activeSelf != active)
                icon.gameObject.SetActive(active);

            if (_iconSetLog.Add(icon))
                Debug.Log($"[K_HealthWidget] SetIconActive FIRST: {icon.name} → {active}");
        }
        private IEnumerator ClockUpdateRoutine()
        {
            WaitForSeconds wait = new WaitForSeconds(1.25f);
            while (true)
            {
                if (_timeSystem != null && _clockText != null)
                {
                    float hoursFloat = _timeSystem.CurrentGameHours;
                    int hours = Mathf.FloorToInt(hoursFloat);
                    int minutes = Mathf.FloorToInt((hoursFloat - hours) * 60f);
                    _clockText.text = $"{hours:00}:{minutes:00}";
                }
                yield return wait;
            }
        }

        private void ShowMetabolismHUD()
        {
            if (!gameObject.activeInHierarchy) return;
            _displayTimer = _hudDisplayDuration;
            if (_fadeCoroutine == null)
                _fadeCoroutine = StartCoroutine(FadeHUDRoutine());
        }

        private IEnumerator FadeHUDRoutine()
        {
            if (_metabolismGroup == null) yield break;

            _metabolismGroup.alpha = 1f;

            while (_metabolismGroup.alpha < 1f && _displayTimer > 0f)
            {
                _metabolismGroup.alpha += Time.deltaTime * _hudFadeSpeed;
                yield return null;
            }
            while (_displayTimer > 0f)
            {
                _displayTimer -= Time.deltaTime;
                yield return null;
            }
            while (_metabolismGroup.alpha > 0f)
            {
                _metabolismGroup.alpha -= Time.deltaTime * _hudFadeSpeed;
                yield return null;
            }
            _fadeCoroutine = null;
        }

        public void ForceRefresh()
        {
            RefreshHealth();
            RefreshMetabolism();
        }

        [ContextMenu("Debug: Force All Visible")]
        public void DebugForceAllVisible()
        {
            Debug.Log("[HealthWidget] Forcing all elements visible...");
            ForceHealthDollVisible();

            if (_metabolismGroup != null)
            {
                _metabolismGroup.alpha = 1f;
                _metabolismGroup.interactable = true;
                _metabolismGroup.blocksRaycasts = true;
            }

            var icons = new[] { _iconHunger, _iconThirst, _iconRadiation, _iconCold, _iconOverload, _iconBleeding };
            foreach (var icon in icons)
            {
                if (icon != null)
                {
                    icon.enabled = true;
                    icon.color = Color.white;
                }
            }
            Debug.Log("[HealthWidget] Done.");
        }


                // =====================================================================
        // Stage 1: диагностика иконок
        // =====================================================================
        private void ValidateIconReferences()
        {
            var ctx = "[K_HealthWidget]";
            CheckIcon(_iconHunger,             nameof(_iconHunger),             ctx);
            CheckIcon(_iconThirst,             nameof(_iconThirst),             ctx);
            CheckIcon(_iconRadiation,          nameof(_iconRadiation),          ctx);
            CheckIcon(_iconCold,               nameof(_iconCold),               ctx);
            CheckIcon(_iconOverload,           nameof(_iconOverload),           ctx);
            CheckIcon(_iconBleeding,           nameof(_iconBleeding),           ctx);
            CheckIcon(_iconLaceration,         nameof(_iconLaceration),         ctx);
            CheckIcon(_iconHangover,           nameof(_iconHangover),           ctx);
            CheckIcon(_iconDrunk,              nameof(_iconDrunk),              ctx);
            CheckIcon(_iconStimOn,             nameof(_iconStimOn),             ctx);
            CheckIcon(_iconStimOff,            nameof(_iconStimOff),            ctx);
            CheckIcon(_iconCoagulant,          nameof(_iconCoagulant),          ctx);
            CheckIcon(_iconFracture,           nameof(_iconFracture),           ctx);
            CheckIcon(_iconGunshot,            nameof(_iconGunshot),            ctx);
            CheckIcon(_iconConcussion,         nameof(_iconConcussion),         ctx);
            CheckIcon(_iconTBI,                nameof(_iconTBI),                ctx);
            CheckIcon(_iconBreathingDifficulty,nameof(_iconBreathingDifficulty),ctx);
            CheckIcon(_iconImmobilized,        nameof(_iconImmobilized),        ctx);
            CheckIcon(_iconInternalBleeding,   nameof(_iconInternalBleeding),   ctx);
            if (_ibCountText == null)
                Debug.LogWarning($"{ctx} Count text reference '{nameof(_ibCountText)}' is NULL. Назначь TextMeshProUGUI в инспекторе.");
        }

        private void CheckIcon(Image icon, string fieldName, string ctx)
        {
            if (icon == null)
            {
                Debug.LogWarning($"{ctx} Icon reference '{fieldName}' is NULL. Назначь Image в инспекторе.");
                return;
            }
            if (icon.sprite == null)
            {
                Debug.LogWarning($"{ctx} Icon '{fieldName}' has no Sprite assigned. Иконка не будет видна.");
            }
        }
    }
}
