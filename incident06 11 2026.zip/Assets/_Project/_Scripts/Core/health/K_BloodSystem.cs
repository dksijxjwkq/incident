using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core
{
    public enum BloodState
    {
        Normal = 0,
        Warning = 1,
        Weakness = 2,
        Shock = 3,
        Dead = 4
    }

    public class K_BloodSystem : MonoBehaviour, ISaveable, IPostLoad
        , ISavePayloadValidator
    {
        // =====================================================================
        // КОНФИГУРАЦИЯ
        // =====================================================================
        [Header("Volume")]
        [SerializeField] private float _maxVolumeMl = 5000f;
        [SerializeField] private float _currentVolumeMl = 5000f;

        // Stage 1 §12: смерть при ≤ 1500 мл. Display: 1500 = 0%, 5000 = 100%.
        [SerializeField] private float _deathThresholdMl = 1500f;

        [Header("Bleeding Rates (ml/sec at level 1) — index = (int)BodyPart")]
        [SerializeField]
        private float[] _bleedingRateMlPerSec = new float[20]
        {
            6f,   // Head
            10f,  // Chest
            12f,  // Stomach
            20f,  // Pelvis
            4f,   // L Shoulder
            4f,   // R Shoulder
            5f,   // L Biceps
            5f,   // R Biceps
            3f,   // L Forearm
            3f,   // R Forearm
            2f,   // L Hand
            2f,   // R Hand
            15f,  // L Quadriceps
            15f,  // R Quadriceps
            3f,   // L Knee
            3f,   // R Knee
            8f,   // L Shin
            8f,   // R Shin
            2f,   // L Foot
            2f    // R Foot
        };

        [Header("Bleeding Level Multipliers")]
        [SerializeField] private float _level1Mult = 0.5f;
        [SerializeField] private float _level2Mult = 1.5f;
        [SerializeField] private float _level3Mult = 3.5f;

        [Header("Blood Loss Balance")]
        [SerializeField, Min(0f), Tooltip("Общий масштаб кровопотери. 0 отключает постепенную потерю крови; 0.5 — половина исходных скоростей.")]
        private float _bloodLossScale = 0.5f;
        [SerializeField, Tooltip("Плавно ограничивать суммарную кровопотерю при нескольких тяжёлых ранах. Прямой разовый урон не ограничивается.")]
        private bool _limitBloodLoss = true;
        [SerializeField, Min(0f), Tooltip("До этой скорости кровопотеря не ограничивается, мл/с.")]
        private float _softLimitStartMlPerSec = 15f;
        [SerializeField, Min(0.01f), Tooltip("Предельная постепенная потеря крови, мл/с. 25 оставляет не менее 140 секунд от полной крови до порога смерти только от кровопотери.")]
        private float _maximumDrainMlPerSec = 25f;
        [SerializeField, Range(0f, 1f), Tooltip("Итоговый множитель постепенной кровопотери после плавного ограничения. 0.4 уменьшает любую текущую скорость в 2.5 раза, включая несколько тяжёлых ран. Прямые разовые потери крови не меняет.")]
        private float _bleedingRateMultiplier = 0.4f;

        [Header("Thresholds (percent 0..1)")]
        [SerializeField, Range(0f, 1f)] private float _warningThreshold = 0.70f;
        [SerializeField, Range(0f, 1f)] private float _weaknessThreshold = 0.40f;
        [SerializeField, Range(0f, 1f)] private float _shockThreshold = 0.15f;

        [Header("Shock HP Drain (per second, split across 20 segments)")]
        [SerializeField] private float _shockHpDrainPerSec = 1f;

        [Header("Debuff Multipliers")]
        [SerializeField] private float _weaknessSpeedMult = 0.8f;
        [SerializeField] private float _weaknessStaminaMult = 0.8f;
        [SerializeField] private float _shockSpeedMult = 0.4f;
        [SerializeField] private float _shockStaminaMult = 0.5f;

        [Header("References (auto-find if empty)")]
        [SerializeField] private K_HealthSystem _healthSystem;
        [SerializeField] private K_DebuffSystem _debuffSystem;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false;

        // =====================================================================
        // RUNTIME
        // =====================================================================
        public event Action OnBloodChanged;

        public string SaveID => "PlayerBlood";
        public bool IsDirty { get; set; } = true;

        public float CurrentVolumeMl => _currentVolumeMl;
        public float MaxVolumeMl => _maxVolumeMl;
        public float DeathThresholdMl => _deathThresholdMl;
        public float BleedingRateMultiplier => float.IsNaN(_bleedingRateMultiplier) || float.IsInfinity(_bleedingRateMultiplier)
            ? 0.4f : Mathf.Clamp01(_bleedingRateMultiplier);
        /// <summary>
        /// Stage 1 §12: display = (current − 1500) / 3500.
        /// 1500 мл → 0%, 5000 мл → 100%.
        /// </summary>
        public float BloodPercent
        {
            get
            {
                float range = _maxVolumeMl - _deathThresholdMl;
                if (range <= 0f) return 0f;
                return Mathf.Clamp01((_currentVolumeMl - _deathThresholdMl) / range);
            }
        }
        public BloodState State => EvaluateState(BloodPercent);
        public bool IsDeadFromBlood => _currentVolumeMl <= _deathThresholdMl;

        private bool _deathFired;
        // Stage 2 §4.5: IB-дренаж.
        private const float IB_DRAIN_PER_SEGMENT_ML_PER_SEC = 2f;
        private K_PlayerMotor _playerMotor;
        private K_VitalitySystem _vitalitySystem;
        private float _notifyTimer;
        public float PulseDrainMultiplier => _vitalitySystem != null ? _vitalitySystem.PulseBleedingMultiplier : 1f;
        public float InternalDrainMultiplier =>
            (_playerMotor != null ? _playerMotor.CurrentActivityMultiplier : 1f) * PulseDrainMultiplier;
        public float CurrentDrainMlPerSec
        {
            get
            {
                if (_healthSystem == null || _healthSystem.IsDead || IsDeadFromBlood) return 0f;
                float drain = CalculateDrainMlPerSec() *
                    (_debuffSystem != null ? _debuffSystem.GetBloodDrainMultiplier() : 1f);
                return BalanceDrain(drain, _bloodLossScale, _limitBloodLoss,
                    _softLimitStartMlPerSec, _maximumDrainMlPerSec) * BleedingRateMultiplier * _healthSystem.TxaDrainMultiplier;
            }
        }

        public static float BalanceDrain(float rawMlPerSec, float scale, bool limit, float softStart, float maximum)
        {
            if (float.IsNaN(rawMlPerSec) || float.IsInfinity(rawMlPerSec) || rawMlPerSec <= 0f ||
                float.IsNaN(scale) || float.IsInfinity(scale) || scale <= 0f) return 0f;
            float drain = rawMlPerSec * scale;
            if (float.IsInfinity(drain)) drain = float.MaxValue;
            if (!limit) return drain;
            if (float.IsNaN(maximum) || float.IsInfinity(maximum) || maximum <= 0f) return drain;
            if (float.IsNaN(softStart) || float.IsInfinity(softStart)) softStart = 0f;
            softStart = Mathf.Clamp(softStart, 0f, maximum);
            if (drain <= softStart) return drain;
            float span = maximum - softStart;
            return span <= 0.0001f ? Mathf.Min(drain, maximum) :
                softStart + span * (1f - Mathf.Exp(-(drain - softStart) / span));
        }

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
        {
            if (_healthSystem == null) _healthSystem = GetComponent<K_HealthSystem>();
            _vitalitySystem = GetComponent<K_VitalitySystem>();
            if (_healthSystem == null)
                Debug.LogError("[BloodSystem] K_HealthSystem not found on this GameObject!");
                if (_debuffSystem == null) _debuffSystem = GetComponent<K_DebuffSystem>();
        }

        private void Start()
        {
            K_SaveManager.Instance?.Register(this);

            // Stage 2 §4.5: кеш Motor для activity-множителя.
            if (_playerMotor == null) _playerMotor = GetComponent<K_PlayerMotor>();
        }

        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
            OnBloodChanged = null;
        }

        private void Update()
        {
            if (_currentVolumeMl <= _deathThresholdMl) return;
            if (_healthSystem == null) return;
            if (_healthSystem.IsDead) return;

            float drainMlPerSec = CurrentDrainMlPerSec;
            if (drainMlPerSec > 0f)
            {
                _currentVolumeMl = Mathf.Max(_deathThresholdMl,
                    _currentVolumeMl - drainMlPerSec * Time.deltaTime);
                IsDirty = true;
            }

            // 2. HP-дрейн в состоянии Shock
            BloodState state = State;
            if (state == BloodState.Shock && _shockHpDrainPerSec > 0f)
            {
                _healthSystem.ApplyDistributedDamage(_shockHpDrainPerSec * Time.deltaTime);
            }

            // 3. Stage 1 §12: смерть при ≤ 1500 мл.
            if (_currentVolumeMl <= _deathThresholdMl && !_deathFired)
            {
                _deathFired = true;
                Debug.LogWarning("[BloodSystem] Exsanguination — player dead (≤1500 ml).");
                _healthSystem.ForceDeath();
            }

            // 4. Уведомление (троттлинг 0.5 сек)
            _notifyTimer += Time.deltaTime;
            if (_notifyTimer >= 0.5f)
            {
                _notifyTimer = 0f;
                OnBloodChanged?.Invoke();
                if (_debugLogs) DebugPrintState();
            }
        }

        // =====================================================================
        // ВСПОМОГАТЕЛЬНЫЕ
        // =====================================================================
        private float CalculateDrainMlPerSec()
        {
            float sum = 0f;

            // Существующий внешний дренаж (по уровням кровотечения).
            for (int i = 0; i < 20; i++)
            {
                int level = _healthSystem.GetBleedingLevel((BodyPart)i);
                if (level <= 0) continue;
                float mult = level switch
                {
                    1 => _level1Mult,
                    2 => _level2Mult,
                    3 => _level3Mult,
                    _ => 0f
                };
                sum += _bleedingRateMlPerSec[i] * mult;
            }

            // Stage 2 §4.5: IB-дренаж. 2 мл/сек на каждый IB-сегмент,
            // умножается на activity-множитель (max из idle/walk/sprint/recent).
            // Stage 3: Коагулянт снижает дренаж отдельно для каждого IB-сегмента.
            float activityMult = _playerMotor != null
                ? _playerMotor.CurrentActivityMultiplier
                : 1f;

            for (int i = 0; i < 20; i++)
            {
                BodyPart part = (BodyPart)i;
                if (!_healthSystem.HasInternalBleeding(part)) continue;
                float mult = _healthSystem.GetIBDrainMultiplier(part);
                sum += IB_DRAIN_PER_SEGMENT_ML_PER_SEC * mult * activityMult;
            }

            // Preserve external/IB treatment and activity multipliers; low pulse never reduces drain.
            return sum * PulseDrainMultiplier;
        }

        private BloodState EvaluateState(float p)
        {
            if (p <= 0f) return BloodState.Dead;
            if (p < _shockThreshold) return BloodState.Shock;
            if (p < _weaknessThreshold) return BloodState.Weakness;
            if (p < _warningThreshold) return BloodState.Warning;
            return BloodState.Normal;
        }

        public float GetSpeedMultiplier()
        {
            return State switch
            {
                BloodState.Weakness => _weaknessSpeedMult,
                BloodState.Shock => _shockSpeedMult,
                BloodState.Dead => 0f,
                _ => 1f
            };
        }

        public float GetStaminaRegenMultiplier()
        {
            return State switch
            {
                BloodState.Weakness => _weaknessStaminaMult,
                BloodState.Shock => _shockStaminaMult,
                _ => 1f
            };
        }

        // =====================================================================
        // ПУБЛИЧНОЕ API (для будущих медпредметов — Итерация 5)
        // =====================================================================
        public void AddBlood(float ml)
        {
            if (float.IsNaN(ml) || float.IsInfinity(ml)) return;
            if (ml <= 0f) return;
            _currentVolumeMl = Mathf.Min(_currentVolumeMl + ml, _maxVolumeMl);
            // Stage 1: если кровь поднялась выше порога смерти — сбрасываем флаг
            // «уже умер от крови». НО: если K_HealthSystem.IsDead = true (голова/грудь 0),
            // это НЕ оживит игрока — ForceDeath уже отработал.
            if (_currentVolumeMl > _deathThresholdMl) _deathFired = false;
            IsDirty = true;
            OnBloodChanged?.Invoke();
        }

        public void RemoveBlood(float ml)
        {
            if (float.IsNaN(ml) || float.IsInfinity(ml)) return;
            if (ml <= 0f) return;
            _currentVolumeMl = Mathf.Max(0f, _currentVolumeMl - ml);
            // Audit H02: direct deductions must enforce the same lethal threshold.
            // Latch before callbacks from ForceDeath can deduct blood again.
            if (_currentVolumeMl <= _deathThresholdMl && !_deathFired)
            {
                _deathFired = true;
                if (_healthSystem != null && !_healthSystem.IsDead)
                {
                    Debug.LogWarning("[BloodSystem] Exsanguination — player dead (≤1500 ml).");
                    _healthSystem.ForceDeath();
                }
            }
            IsDirty = true;
            OnBloodChanged?.Invoke();
        }

        public void Transfuse(float ml) => AddBlood(ml);

        // =====================================================================
        // SAVE / LOAD
        // =====================================================================
        public void Save(BinaryWriter writer)
        {
            writer.Write(_currentVolumeMl);
        }

        public void Load(BinaryReader reader)
        {
            _currentVolumeMl = reader.ReadSingle();
            _deathFired = _currentVolumeMl <= _deathThresholdMl;
            IsDirty = false;
            OnBloodChanged?.Invoke();
        }

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            float volume = SaveLoadValidationContext.ReadFinite(reader, true);
            if (volume > _maxVolumeMl) throw new InvalidDataException("Saved blood exceeds its maximum volume.");
        }

        public void OnAfterLoad()
        {
            // Stage 1 §12: смерть при ≤ 1500 мл.
            // All saved death latches are restored before enforcing blood death.
            if (_currentVolumeMl <= _deathThresholdMl)
            {
                _deathFired = true;
                if (_healthSystem != null && !_healthSystem.IsDead)
                {
                    Debug.LogWarning($"[BloodSystem] Loaded with {_currentVolumeMl:F0} ml (≤{_deathThresholdMl:F0}) — forcing death.");
                    _healthSystem.ForceDeath();
                }
            }
            else
            {
                _deathFired = false;
            }

        }

        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Debug: Drain 1000ml")]
        public void DebugDrain1000() => RemoveBlood(1000f);

        [ContextMenu("Debug: Fill 1000ml")]
        public void DebugFill1000() => AddBlood(1000f);

        [ContextMenu("Debug: Print State")]
        public void DebugPrintState()
        {
            Debug.Log($"[BloodSystem] Volume: {_currentVolumeMl:F0}/{_maxVolumeMl:F0} ml " +
                      $"({BloodPercent * 100f:F1}%) | State: {State} | Pulse x{PulseDrainMultiplier:F2} | " +
                      $"IB activity+pulse x{InternalDrainMultiplier:F2} | Drain: {CurrentDrainMlPerSec:F2} ml/s");
        }
    }
}
