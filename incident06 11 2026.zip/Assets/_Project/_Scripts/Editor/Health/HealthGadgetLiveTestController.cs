using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;
using K_Incident.Core;
using K_Incident.Core.Inventory;
using BodyPart = K_Incident.Core.BodyPart;

namespace K_Incident.EditorTools
{
    /// <summary>Editor-only, one-shot setup of real player systems. Never substitutes display data.</summary>
    [InitializeOnLoad]
    public sealed class HealthGadgetLiveTestController
    {
        private const BindingFlags Fields = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
        private const string DeviceKey = "Incident.HealthGadget.CreatedDevices";
        private static readonly HashSet<uint> CreatedDevices = new HashSet<uint>();
        private readonly List<HealthGadgetEntry> _effects = new List<HealthGadgetEntry>();
        private readonly List<HealthGadgetEntry> _indicators = new List<HealthGadgetEntry>();
        public K_HealthSystem Health { get; private set; }
        public K_VitalitySystem Vitality { get; private set; }
        public K_DebuffSystem Debuffs { get; private set; }
        public K_BloodSystem Blood { get; private set; }
        public K_WeightManager Weight { get; private set; }
        public K_HealthStatusGadget Gadget { get; private set; }
        public K_IllnessSystem Illnesses => Health != null ? Health.GetComponent<K_IllnessSystem>() : null;
        public bool IsReady => Application.isPlaying && Health != null && Vitality != null && Debuffs != null && Blood != null && Gadget != null;

        static HealthGadgetLiveTestController()
        {
            if (EditorApplication.isPlaying)
                foreach (string id in SessionState.GetString(DeviceKey, "").Split(','))
                    if (uint.TryParse(id, out uint value)) CreatedDevices.Add(value);
            else SessionState.EraseString(DeviceKey);
            EditorApplication.playModeStateChanged += state =>
            {
                if (state != PlayModeStateChange.EnteredEditMode) return;
                CreatedDevices.Clear(); SessionState.EraseString(DeviceKey);
            };
        }

        public static HealthGadgetLiveTestController Find()
        {
            var health = UnityEngine.Object.FindFirstObjectByType<K_HealthSystem>();
            return new HealthGadgetLiveTestController
            {
                Health = health,
                Vitality = health != null ? health.GetComponent<K_VitalitySystem>() : null,
                Debuffs = health != null ? health.GetComponent<K_DebuffSystem>() : null,
                Blood = health != null ? health.GetComponent<K_BloodSystem>() : null,
                Weight = health != null ? health.GetComponent<K_WeightManager>() : null,
                Gadget = UnityEngine.Object.FindFirstObjectByType<K_HealthStatusGadget>(FindObjectsInactive.Include)
            };
        }

        private static T Get<T>(object target, string name)
            => (T)(target.GetType().GetField(name, Fields) ?? throw new MissingFieldException(target.GetType().Name, name)).GetValue(target);
        private static void Set(object target, string name, object value)
            => (target.GetType().GetField(name, Fields) ?? throw new MissingFieldException(target.GetType().Name, name)).SetValue(target, value);
        private static void Invoke(object target, string name)
            => (target.GetType().GetMethod(name, Fields) ?? throw new MissingMethodException(target.GetType().Name, name)).Invoke(target, null);
        private static void Fire(object target, string name) => (Get<object>(target, name) as Action)?.Invoke();
        private static float Seconds(float value, float fallback) => float.IsNaN(value) || float.IsInfinity(value) || value <= 0 ? fallback : Mathf.Clamp(value, .05f, 3600f);
        private string Guard() => !IsReady ? "Сначала запустите Play Mode." : Health.IsDead ? "Персонаж погиб. Перезапустите Play Mode." : null;
        private void BeginChange() => Set(Vitality, "_debugPulseOverride", false);
        private void Changed()
        {
            Health.IsDirty = Vitality.IsDirty = Debuffs.IsDirty = true;
            Debuffs.RefreshCombatDerivedDebuffs();
            Invoke(Health, "NotifyChange"); Invoke(Vitality, "NotifyChange");
            Invoke(Debuffs, "FireChangedIfNeeded");
            Gadget.RefreshNow();
        }

        public void Read(HealthGadgetPreviewData data)
        {
            if (!IsReady || data == null) return;
            K_HealthGadgetContent.Collect(_effects, _indicators, Health, Vitality, Debuffs, Blood, Weight);
            Array.Clear(data.Enabled, 0, data.Enabled.Length);
            foreach (var entry in _effects) data.Enabled[(int)entry.Kind] = true;
            foreach (var entry in _indicators) data.Enabled[(int)entry.Kind] = true;
            data.Hunger = Vitality.Hunger; data.Thirst = Vitality.Thirst;
            data.Cold = Vitality.ColdExposure * 100f; data.Radiation = Vitality.Radiation;
            data.BloodMl = Blood.CurrentVolumeMl; data.Weight = Weight != null ? Weight.CurrentWeight : 0f;
            foreach (HealthGadgetKind kind in Enum.GetValues(typeof(HealthGadgetKind)))
                if (HealthGadgetPreviewData.IsTimed(kind)) data.SetRemainingSeconds(kind, Remaining(kind));
        }

        private float Remaining(HealthGadgetKind kind)
        {
            switch (kind)
            {
                case HealthGadgetKind.Concussion: return Debuffs.ConcussionSecondsRemaining;
                case HealthGadgetKind.Painkiller: return Debuffs.IsUnderPainkiller ? Debuffs.PainkillerSecondsRemaining : Debuffs.PainkillerOnsetSecondsRemaining;
                case HealthGadgetKind.Tbi: return Debuffs.TbiRecoverySecondsRemaining;
                case HealthGadgetKind.Shock: return Health.ShockSecondsRemaining;
                case HealthGadgetKind.StimOn: return Get<float>(Vitality, "_stimulatorTimer");
                case HealthGadgetKind.StimCooldown: return Get<float>(Vitality, "_stimOffTimer");
                case HealthGadgetKind.Fatigue: return Get<float>(Vitality, "_fatigueTimer");
                case HealthGadgetKind.Drunk: return Get<float>(Vitality, "_drunkTimer");
                case HealthGadgetKind.Hangover: return Get<float>(Vitality, "_hangoverTimer");
                case HealthGadgetKind.HealBoost:
                    float boost = 0f; for (int i=0;i<20;i++) boost = Mathf.Max(boost, Health.GetHealBoostSecondsRemaining((BodyPart)i)); return boost;
                case HealthGadgetKind.Txa: return Health.TxaSecondsRemaining;
                case HealthGadgetKind.Recovery:
                    float recovery = 0f; for (int i=0;i<20;i++) recovery = Mathf.Max(recovery, Health.GetSplintRecoverySecondsRemaining((BodyPart)i)); return recovery;
                case HealthGadgetKind.ColdIllness: return Illnesses != null ? Illnesses.ColdSecondsRemaining : 0f;
                case HealthGadgetKind.AntibioticTreatment: return Illnesses != null ? Illnesses.AntibioticSecondsRemaining : 0f;
                default: return 0f;
            }
        }

        public string SetIndicator(HealthGadgetKind kind, float value)
        {
            string error = Guard(); if (error != null) return error;
            if (float.IsNaN(value) || float.IsInfinity(value)) return "Нужно конечное число.";
            BeginChange();
            switch (kind)
            {
                case HealthGadgetKind.Hunger: Vitality.ConsumeFoodWater(Mathf.Clamp(value,0,100)-Vitality.Hunger,0); break;
                case HealthGadgetKind.Thirst: Vitality.ConsumeFoodWater(0,Mathf.Clamp(value,0,100)-Vitality.Thirst); break;
                case HealthGadgetKind.Cold: Vitality.SetColdExposure(Mathf.Clamp01(value/100f)); break;
                case HealthGadgetKind.Radiation:
                    float delta = Mathf.Clamp(value,0,100)-Vitality.Radiation;
                    if (delta>0) Vitality.AddRadiation(delta); else Vitality.ApplyAntiRad(-delta); break;
                case HealthGadgetKind.Overload: if(Weight!=null) Weight.SetWeight(Mathf.Clamp(value,0,1000)); break;
                case HealthGadgetKind.Blood:
                    float ml = Mathf.Clamp(value,0,Blood.MaxVolumeMl)-Blood.CurrentVolumeMl;
                    if(ml>0) Blood.AddBlood(ml); else Blood.RemoveBlood(-ml); break;
                default: return "Это не числовой показатель.";
            }
            Changed(); return "Показатель изменён.";
        }

        private static BodyPart[] Parts(BodyPart first,int count)
        {
            var parts = new BodyPart[Mathf.Clamp(count,1,20)];
            int start = Mathf.Clamp((int)first,0,19);
            for(int i=0;i<parts.Length;i++) parts[i]=(BodyPart)((start+i)%20);
            return parts;
        }

        public string SetEffect(HealthGadgetKind kind, bool enabled, BodyPart target, int zones, int bleedingLevel, float seconds)
        {
            string error=Guard(); if(error!=null)return error;
            BeginChange();
            foreach(var part in Parts(target,zones))
            {
                switch(kind)
                {
                    case HealthGadgetKind.Bleeding: Health.SetBleedingLevelOnPart(part,enabled?Mathf.Clamp(bleedingLevel,1,3):0); break;
                    case HealthGadgetKind.Laceration: Health.SetCombatLaceration(part,enabled?LacerationType.Open:LacerationType.None); break;
                    case HealthGadgetKind.Fracture: if(enabled)Health.ApplyCombatFracture(part,1f);else Health.ClearFracture(part); break;
                    case HealthGadgetKind.Gunshot: if(enabled)Health.ApplyGunshot(part);else Health.ClearGunshot(part); break;
                    case HealthGadgetKind.InternalBleeding: if(enabled)Health.DebugSetInternalBleeding(part,true);else Health.ClearInternalBleeding(part); break;
                }
            }
            switch(kind)
            {
                case HealthGadgetKind.Concussion:
                    if(enabled){Debuffs.ApplyCombatConcussion();if(seconds>0)Set(Debuffs,"_concussionTimer",Seconds(seconds,60));}
                    else{Debuffs.CureConcussion();Health.ClearFracture(BodyPart.Head);}break;
                case HealthGadgetKind.Tbi: if(enabled)Debuffs.ApplyCombatTBI();else Debuffs.CureTBI();break;
                case HealthGadgetKind.BreathingDifficulty:
                    if(enabled)Health.ApplyCombatFracture(BodyPart.Chest,1f);else{Health.ClearFracture(BodyPart.Chest);Health.ClearGunshot(BodyPart.Chest);}break;
                case HealthGadgetKind.Immobilized: if(enabled)Health.ApplyCombatFracture(BodyPart.Pelvis,1f);else Health.ClearFracture(BodyPart.Pelvis);break;
                case HealthGadgetKind.StimOn:
                case HealthGadgetKind.StimCooldown:
                case HealthGadgetKind.Fatigue:
                    string phase=kind==HealthGadgetKind.StimOn?"_stimulatorTimer":kind==HealthGadgetKind.StimCooldown?"_stimOffTimer":"_fatigueTimer";
                    if(enabled){Set(Vitality,"_stimulatorTimer",0f);Set(Vitality,"_stimOffTimer",0f);Set(Vitality,"_fatigueTimer",0f);}
                    Set(Vitality,phase,enabled?Seconds(seconds,kind==HealthGadgetKind.StimOn?85:kind==HealthGadgetKind.StimCooldown?200:30):0f);
                    Fire(Vitality,"OnStimulatorChanged");break;
                case HealthGadgetKind.Drunk:
                    if(enabled){if(!Vitality.IsDrunk)Vitality.ConsumeVodka(100);if(seconds>0)Set(Vitality,"_drunkTimer",Seconds(seconds,120));}
                    else{Set(Vitality,"_drunkTimer",0f);Set(Vitality,"_alcoholConcentration",0f);Set(Vitality,"_totalAlcoholConsumed",0f);Set(Vitality,"_pendingHangoverSeconds",0f);}Fire(Vitality,"OnHangoverChanged");break;
                case HealthGadgetKind.Hangover:
                    if(enabled){Set(Vitality,"_drunkTimer",0f);Set(Vitality,"_alcoholConcentration",0f);Set(Vitality,"_pendingHangoverSeconds",0f);}
                    Set(Vitality,"_hangoverTimer",enabled?Seconds(seconds,120):0f);Fire(Vitality,"OnHangoverChanged");break;
                case HealthGadgetKind.Painkiller:
                    if(enabled)Debuffs.ActivatePainkiller(Seconds(seconds,180));else ClearPainkillers();break;
                case HealthGadgetKind.Shock:
                    if(enabled){Health.ApplyShock();if(seconds>0)Set(Health,"_shockTimer",Seconds(seconds,5));}else Set(Health,"_shockTimer",0f);break;
                case HealthGadgetKind.HealBoost:
                    if(enabled)
                    {
                        foreach(var part in Parts(target,zones))
                        {
                            if ((int)part < (int)BodyPart.LeftShoulder) continue;
                            if (Health.GetHP(part) >= Health.GetEffectiveMaxHP(part)) Health.ApplySegmentDamage(Mathf.Min(1f,Health.GetEffectiveMaxHP(part)*.1f), part, DamageType.Generic);
                            Health.ActivateHealBoost(part,Seconds(seconds,120));
                        }
                    }
                    else Array.Clear(Get<float[]>(Health,"_healBoostTimers"),0,20);break;
                case HealthGadgetKind.Coagulant:
                    if(enabled)
                    {
                        foreach (var part in Parts(target,zones))
                        {
                            Health.SetBleedingLevelOnPart(part,0);
                            Health.DebugSetInternalBleeding(part,true);
                            Health.ApplyCoagulant(part);
                        }
                    }
                    else Array.Clear(Get<bool[]>(Health,"_surgicalHemostatPrepared"),0,20);break;
                case HealthGadgetKind.Txa:
                    if(enabled){Health.ApplyTransamacha();Set(Health,"_txaTimer",Seconds(seconds,Health.TxaFullDuration));}
                    else Set(Health,"_txaTimer",0f);break;
                case HealthGadgetKind.ChestSeal:
                    if(enabled){Health.ApplyGunshot(BodyPart.Chest);Health.SetCombatLaceration(BodyPart.Chest,LacerationType.Open);Health.ApplyChestSeal();}
                    else Health.RemoveChestSeal();break;
                case HealthGadgetKind.PelvicBinder:
                    if(enabled){Health.ApplyCombatFracture(BodyPart.Pelvis,1f);Health.ApplyPelvicBinder();}
                    else Health.RemovePelvicBinder();break;
                case HealthGadgetKind.Recovery:
                    foreach(var part in Parts(target,zones))
                    {
                        if(!enabled){Health.ClearFracture(part);continue;}
                        Health.ApplyCombatFracture(part,1f);
                        if(part==BodyPart.Head)Debuffs.BeginTbiRecovery(Seconds(seconds,120));
                        else if(part==BodyPart.Pelvis)Health.ApplyPelvicBinder();
                        else if((int)part>=(int)BodyPart.LeftShoulder)Health.ApplySplint(part);
                        if(Health.GetSplintRecoverySecondsRemaining(part)>0)Get<float[]>(Health,"_fractureRecoveryTimers")[(int)part]=Seconds(seconds,240);
                    }
                    break;
                case HealthGadgetKind.ColdIllness:
                    if(Illnesses==null)return "Система болезней недоступна.";
                    if(enabled){if(!Illnesses.ApplyCold(Seconds(seconds,600)))Illnesses.SetColdRemainingSeconds(Seconds(seconds,600));}
                    else Illnesses.ClearCold();break;
                case HealthGadgetKind.WoundInfection:
                    if(Illnesses==null)return "Система болезней недоступна.";
                    foreach(var part in Parts(target,zones))
                    {
                        if(enabled){if(!Health.HasLaceration(part)&&!Health.IsGunshot(part))Health.SetCombatLaceration(part,LacerationType.Open);Illnesses.ApplyWoundInfection(part);}
                        else Illnesses.ClearWoundInfection(part);
                    }
                    break;
                case HealthGadgetKind.AntibioticTreatment:
                    if(Illnesses==null)return "Система болезней недоступна.";
                    if(enabled)
                    {
                        if(!Illnesses.HasWoundInfection){Health.SetCombatLaceration(target,LacerationType.Open);Illnesses.ApplyWoundInfection(target);}
                        if(!Illnesses.StartAntibioticCourse(Seconds(seconds,240)))Illnesses.SetAntibioticRemainingSeconds(Seconds(seconds,240));
                    }
                    else Illnesses.SetAntibioticRemainingSeconds(0f);break;
                case HealthGadgetKind.Tourniquet:
                case HealthGadgetKind.Jett:
                    string deviceError=SetDevice(kind,enabled,target,Seconds(seconds,420));if(deviceError!=null){Changed();return deviceError;}break;
            }
            Changed();return "Состояние изменено. Пульс реагирует плавно.";
        }

        private void SetActiveTimers(string field,float seconds)
        {var timers=Get<float[]>(Health,field);for(int i=0;i<timers.Length;i++)if(timers[i]>0)timers[i]=seconds;}

        private void ClearPainkillers()
        {
            foreach(string field in new[]{"_painkillerTimer","_painkillerFullDuration","_mildPainkillerTimer","_mildPainkillerOnsetTimer","_mildPainkillerFullDuration","_pendingMildPainkillerDuration"})Set(Debuffs,field,0f);
        }

        public string TakeParacetamol(float duration=180f)
        {
            string error=Guard();if(error!=null)return error;
            BeginChange();
            if(!Debuffs.CanActivatePainkiller(Seconds(duration,180),"paracetamol"))return "Парацетамол уже принят; дождитесь начала действия.";
            Debuffs.ActivatePainkiller(Seconds(duration,180),"paracetamol");
            Changed();return "Парацетамол принят. Действие начнётся после задержки.";
        }

        private string SetDevice(HealthGadgetKind kind,bool enabled,BodyPart target,float seconds)
        {
            var type=kind==HealthGadgetKind.Jett?AppliedGhostKind.JETT:AppliedGhostKind.Tourniquet;
            var manager=Health.AppliedMedical;
            if(!enabled)
            {
                foreach(var record in manager.Records.Where(r=>r.Kind==type).ToArray())
                {
                    if(CreatedDevices.Contains(record.InstanceID))
                    {if(!manager.TryRemoveForWorldDrop(record,out string removalReason))return removalReason;CreatedDevices.Remove(record.InstanceID);}
                    else if(!manager.TryRemove(record,out string reason))return reason;
                }
                RememberDevices();return null;
            }
            var parent=K_AppliedMedicalManager.GetParentPart(target);
            if(!parent.HasValue)return "Для устройства выберите руку или ногу.";
            if(manager.GetRecordForPart(parent.Value)!=null)return "На этой конечности уже установлено устройство.";
            if(type==AppliedGhostKind.JETT)Health.SetBleedingLevelOnPart(parent.Value,3);
            else Health.SetBleedingLevelOnPart(target,3);
            string id=type==AppliedGhostKind.JETT?"jett":"tourniquet";
            var data=K_InventorySetup.DatabaseInstance?.GetItemData(id);
            if(data==null)return "Не найден предмет «"+id+"».";
            if(!manager.TryApplyFromContainer(id,1,data.MaxDurability,100,data.FullChargeSeconds,0,parent.Value,type,out string refusal))return refusal;
            CreatedDevices.Add(manager.GetRecordForPart(parent.Value).InstanceID);RememberDevices();return null;
        }
        private static void RememberDevices()=>SessionState.SetString(DeviceKey,string.Join(",",CreatedDevices));

        public string SetTimer(HealthGadgetKind kind,float seconds)
        {
            string error=Guard();if(error!=null)return error;
            if(!HealthGadgetPreviewData.IsTimed(kind))return "У этого состояния нет таймера окончания. Устройство остаётся до снятия.";
            if(float.IsNaN(seconds)||float.IsInfinity(seconds))return "Нужно конечное число.";
            if(seconds<=0)return SetEffect(kind,false,BodyPart.LeftHand,1,3,0);
            if(Remaining(kind)<=0 && !(kind==HealthGadgetKind.Tbi && Debuffs.HasTBI))return "Сначала включите эффект.";
            BeginChange();seconds=Seconds(seconds,1);
            switch(kind)
            {
                case HealthGadgetKind.Concussion:Set(Debuffs,"_concussionTimer",seconds);break;
                case HealthGadgetKind.Painkiller:
                    if(Debuffs.IsUnderPainkiller)
                    {
                        bool strong=Debuffs.PainkillerSourceItemID=="painkiller";
                        string timer=strong?"_painkillerTimer":"_mildPainkillerTimer";
                        string duration=strong?"_painkillerFullDuration":"_mildPainkillerFullDuration";
                        Set(Debuffs,timer,seconds);Set(Debuffs,duration,Mathf.Max(Get<float>(Debuffs,duration),seconds));
                    }
                    else Set(Debuffs,"_mildPainkillerOnsetTimer",seconds);
                    break;
                case HealthGadgetKind.Tbi:
                    if(Debuffs.IsTbiRecovering)Set(Debuffs,"_tbiRecoveryTimer",seconds);
                    else if(!Debuffs.BeginTbiRecovery(seconds))return "Сначала обработайте сопутствующие ранения головы.";
                    if(Health.GetSplintRecoverySecondsRemaining(BodyPart.Head)>0)Get<float[]>(Health,"_fractureRecoveryTimers")[(int)BodyPart.Head]=seconds;
                    break;
                case HealthGadgetKind.Shock:Set(Health,"_shockTimer",seconds);break;
                case HealthGadgetKind.StimOn:Set(Vitality,"_stimulatorTimer",seconds);break;
                case HealthGadgetKind.StimCooldown:Set(Vitality,"_stimOffTimer",seconds);break;
                case HealthGadgetKind.Fatigue:Set(Vitality,"_fatigueTimer",seconds);break;
                case HealthGadgetKind.Drunk:Set(Vitality,"_drunkTimer",seconds);break;
                case HealthGadgetKind.Hangover:Set(Vitality,"_hangoverTimer",seconds);break;
                case HealthGadgetKind.HealBoost:SetActiveTimers("_healBoostTimers",seconds);break;
                case HealthGadgetKind.Txa:Set(Health,"_txaTimer",seconds);break;
                case HealthGadgetKind.Recovery:SetActiveTimers("_fractureRecoveryTimers",seconds);break;
                case HealthGadgetKind.ColdIllness:
                    if(Illnesses==null || !Illnesses.SetColdRemainingSeconds(seconds))return "Простуда сейчас недоступна.";break;
                case HealthGadgetKind.AntibioticTreatment:
                    if(Illnesses==null || !Illnesses.SetAntibioticRemainingSeconds(seconds))return "Лечение инфекции сейчас недоступно.";break;
            }
            Changed();return "Таймер изменён.";
        }

        public static void PreparePreset(HealthGadgetPreviewPreset preset,HealthGadgetPreviewData data)
        {
            data.ApplyPreset(preset);
            Array.Clear(data.IndicatorEdited,0,data.IndicatorEdited.Length);
            if(preset==HealthGadgetPreviewPreset.All||preset==HealthGadgetPreviewPreset.Buffs)
                foreach(var kind in new[]{HealthGadgetKind.StimCooldown,HealthGadgetKind.Fatigue,HealthGadgetKind.Hangover})data.Enabled[(int)kind]=false;
            if(preset==HealthGadgetPreviewPreset.Buffs)
                foreach(var kind in new[]{HealthGadgetKind.Coagulant,HealthGadgetKind.Tourniquet,HealthGadgetKind.Jett,HealthGadgetKind.ChestSeal,HealthGadgetKind.PelvicBinder,HealthGadgetKind.Recovery,HealthGadgetKind.AntibioticTreatment})data.Enabled[(int)kind]=false;
            if(preset!=HealthGadgetPreviewPreset.All)return;
            foreach(var kind in new[]{HealthGadgetKind.Painkiller,HealthGadgetKind.Coagulant,HealthGadgetKind.Tourniquet,HealthGadgetKind.Jett})data.Enabled[(int)kind]=false;
            data.Hunger=60;data.Thirst=70;data.Cold=65;data.Radiation=25;data.BloodMl=4000;
            foreach(int index in new[]{0,1,2,3,5})data.IndicatorEdited[index]=true;
        }
        public string ApplySettings(HealthGadgetPreviewData data,BodyPart target)
        {
            string error=Guard();if(error!=null)return error;
            var enabled=(bool[])data.Enabled.Clone();
            float[] values={data.Hunger,data.Thirst,data.Cold,data.Radiation,data.Weight,data.BloodMl};
            for(int i=0;i<6;i++)if(data.IndicatorEdited[i])SetIndicator((HealthGadgetKind)i,values[i]);
            Array.Clear(data.IndicatorEdited,0,data.IndicatorEdited.Length);
            var messages=new List<string>();
            for(int i=(int)HealthGadgetKind.Bleeding;i<enabled.Length;i++)
            {
                var kind=(HealthGadgetKind)i;if(!enabled[i])continue;
                if((kind==HealthGadgetKind.StimCooldown||kind==HealthGadgetKind.Fatigue)&&enabled[(int)HealthGadgetKind.StimOn])continue;
                if(kind==HealthGadgetKind.Fatigue&&enabled[(int)HealthGadgetKind.StimCooldown])continue;
                if(kind==HealthGadgetKind.Hangover&&enabled[(int)HealthGadgetKind.Drunk])continue;
                var part=kind==HealthGadgetKind.Tourniquet?BodyPart.LeftShoulder:kind==HealthGadgetKind.Jett?BodyPart.RightQuadriceps:target;
                string result=SetEffect(kind,true,part,data.Zones,data.BleedingLevel,data.GetRemainingSeconds(kind));
                if(result!="Состояние изменено. Пульс реагирует плавно.")messages.Add(result);
            }
            return messages.Count>0?string.Join(" ",messages):"Состояния заданы персонажу. Пульс реагирует плавно.";
        }
        public string ApplyPreset(HealthGadgetPreviewPreset preset,HealthGadgetPreviewData data,BodyPart target)
        {
            string error=Guard();if(error!=null)return error;
            PreparePreset(preset,data);
            if(preset!=HealthGadgetPreviewPreset.Empty)return ApplySettings(data,target);
            BeginChange();
            string tourniquetError=SetDevice(HealthGadgetKind.Tourniquet,false,target,1);
            string compressionError=SetDevice(HealthGadgetKind.Jett,false,target,1);
            string deviceError=tourniquetError??compressionError;
            for(int i=0;i<20;i++)
            {
                var part=(BodyPart)i;
                if(Health.GetTreatableBleedingLevel(part)>0)Health.UseHemostatic(part);
                Health.SetBleedingLevelOnPart(part,0);Health.SetCombatLaceration(part,LacerationType.None);
                Health.ClearFracture(part);Health.ClearGunshot(part);Health.ClearInternalBleeding(part);
            }
            Array.Clear(Get<float[]>(Health,"_healBoostTimers"),0,20);Array.Clear(Get<float[]>(Health,"_ibBlockTimer"),0,20);
            Array.Clear(Get<bool[]>(Health,"_surgicalHemostatPrepared"),0,20);
            Debuffs.CureConcussion();Debuffs.CureTBI();ClearPainkillers();Set(Health,"_shockTimer",0f);Set(Health,"_txaTimer",0f);
            Health.RemoveChestSeal();Health.RemovePelvicBinder();Illnesses?.ClearIllnesses();
            foreach(string phase in new[]{"_stimulatorTimer","_stimOffTimer","_fatigueTimer","_drunkTimer","_hangoverTimer","_pendingHangoverSeconds","_alcoholConcentration","_totalAlcoholConsumed"})Set(Vitality,phase,0f);
            Fire(Vitality,"OnStimulatorChanged");Fire(Vitality,"OnHangoverChanged");
            Vitality.ApplyAntiRad(Vitality.Radiation);Vitality.SetColdExposure(0);Vitality.ConsumeFoodWater(100,100);
            Blood.AddBlood(Blood.MaxVolumeMl);Health.HealAll(float.MaxValue);
            UnityEngine.Object.FindFirstObjectByType<K_InventoryUI>()?.ForceRefresh();
            Changed();return deviceError??"Травмы убраны, здоровье и показатели восстановлены.";
        }
    }
}
