using System;
using K_Incident.Core.Inventory;

namespace K_Incident.EditorTools
{
    public enum HealthGadgetPreviewPreset { All, Injuries, Buffs, Empty }

    /// <summary>Prepared controls and last observed player values. No alternate display or timer simulation.</summary>
    public sealed class HealthGadgetPreviewData
    {
        private static readonly int KindCount = Enum.GetValues(typeof(HealthGadgetKind)).Length;
        private const int FirstEffect = (int)HealthGadgetKind.Bleeding;
        public bool[] Enabled = new bool[KindCount];
        public bool[] IndicatorEdited = new bool[FirstEffect];
        public float Hunger = 100f;
        public float Thirst = 100f;
        public float Cold;
        public float Radiation;
        public float Weight;
        public float BloodMl = 5000f;
        public int BleedingLevel = 3;
        public int Zones = 3;
        private readonly float[] _remaining = new float[KindCount];

        public HealthGadgetPreviewData() => ApplyPreset(HealthGadgetPreviewPreset.Empty);

        public int EnabledEffectCount
        {
            get
            {
                int count = 0;
                for (int i = FirstEffect; Enabled != null && i < Enabled.Length; i++)
                    if (Enabled[i]) count++;
                return count;
            }
        }

        public void ApplyPreset(HealthGadgetPreviewPreset preset)
        {
            if (Enabled == null || Enabled.Length != KindCount) Enabled = new bool[KindCount];
            for (int i = 0; i < KindCount; i++)
            {
                var kind = (HealthGadgetKind)i;
                bool injury = IsInjury(kind);
                Enabled[i] = i < FirstEffect || preset == HealthGadgetPreviewPreset.All ||
                    (preset == HealthGadgetPreviewPreset.Injuries && injury) ||
                    (preset == HealthGadgetPreviewPreset.Buffs && !injury);
            }
            ResetTimers();
        }

        public void ResetTimers()
        {
            for (int i = 0; i < KindCount; i++) _remaining[i] = InitialSeconds((HealthGadgetKind)i);
        }

        public float GetRemainingSeconds(HealthGadgetKind kind)
        {
            int index = (int)kind;
            return index >= 0 && index < KindCount && IsTimed(kind) ? _remaining[index] : 0f;
        }

        /// <summary>Stores an input or an observed remaining duration; gameplay owns its countdown.</summary>
        public void SetRemainingSeconds(HealthGadgetKind kind, float seconds)
        {
            int index = (int)kind;
            if (index < 0 || index >= KindCount || !IsTimed(kind) || float.IsNaN(seconds) || float.IsInfinity(seconds)) return;
            _remaining[index] = Math.Max(0f, seconds);
        }

        public static bool IsTimed(HealthGadgetKind kind)
        {
            switch (kind)
            {
                case HealthGadgetKind.Concussion:
                case HealthGadgetKind.StimOn:
                case HealthGadgetKind.StimCooldown:
                case HealthGadgetKind.Fatigue:
                case HealthGadgetKind.Drunk:
                case HealthGadgetKind.Hangover:
                case HealthGadgetKind.Painkiller:
                case HealthGadgetKind.HealBoost:
                case HealthGadgetKind.Shock:
                case HealthGadgetKind.Txa:
                case HealthGadgetKind.Recovery:
                case HealthGadgetKind.Tbi:
                case HealthGadgetKind.ColdIllness:
                case HealthGadgetKind.AntibioticTreatment:
                    return true;
                default:
                    return false;
            }
        }

        private static bool IsInjury(HealthGadgetKind kind)
            => K_HealthGadgetContent.IsInjury(kind);

        // Starting values for the editable controls; these do not change runtime configuration.
        private static float InitialSeconds(HealthGadgetKind kind)
        {
            switch (kind)
            {
                case HealthGadgetKind.Concussion: return 60f;
                case HealthGadgetKind.StimOn: return 85f;
                case HealthGadgetKind.StimCooldown: return 200f;
                case HealthGadgetKind.Fatigue: return 30f;
                case HealthGadgetKind.Drunk: return 120f;
                case HealthGadgetKind.Hangover: return 180f;
                case HealthGadgetKind.Painkiller: return 180f;
                case HealthGadgetKind.HealBoost: return 120f;
                case HealthGadgetKind.Txa: return 180f;
                case HealthGadgetKind.Recovery: return 240f;
                case HealthGadgetKind.Tbi: return 120f;
                case HealthGadgetKind.ColdIllness: return 600f;
                case HealthGadgetKind.AntibioticTreatment: return 240f;
                case HealthGadgetKind.Shock: return 10f;
                default: return 0f;
            }
        }
    }
}
