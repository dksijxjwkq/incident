using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using K_Incident.Core;
using K_Incident.Core.Inventory;
using BodyPart = K_Incident.Core.BodyPart;

namespace K_Incident.EditorTools
{
    public sealed class K_HealthGadgetPreviewWindow : EditorWindow
    {
        private const string Folder = "Assets/_Project/_Scripts/Editor/Health/";
        [SerializeField] private bool _startWhenPlaying, _hasPreparedChanges;
        [SerializeField] private bool _healWhenPlaying;
        [SerializeField] private BodyPart _target = BodyPart.LeftHand;
        [SerializeField] private PreviewState _savedData;
        private HealthGadgetPreviewData _data;
        private HealthGadgetLiveTestController _controller;
        private K_HealthStatusGadget _gadget;
        private bool _active;
        private double _nextRefresh;
        private Label _status;
        private Toggle _preview;
        private string _lastMessage;
        private readonly Dictionary<HealthGadgetKind, Toggle> _effects = new Dictionary<HealthGadgetKind, Toggle>();
        private readonly Dictionary<HealthGadgetKind, FloatField> _seconds = new Dictionary<HealthGadgetKind, FloatField>();
        private readonly Dictionary<HealthGadgetKind, Slider> _indicators = new Dictionary<HealthGadgetKind, Slider>();
        private SliderInt _bleeding, _zones;
        private Button _takeParacetamol;

        [Serializable]
        private sealed class PreviewState
        {
            public bool[] Enabled;
            public bool[] IndicatorEdited;
            public float[] Seconds;
            public float Hunger, Thirst, Cold, Radiation, Weight, BloodMl;
            public int BleedingLevel, Zones;
            public PreviewState(HealthGadgetPreviewData data)
            {
                Enabled = (bool[])data.Enabled.Clone();
                IndicatorEdited = (bool[])data.IndicatorEdited.Clone();
                var kinds = (HealthGadgetKind[])Enum.GetValues(typeof(HealthGadgetKind));
                Seconds = new float[kinds.Length];
                for (int i = 0; i < kinds.Length; i++) Seconds[i] = data.GetRemainingSeconds(kinds[i]);
                Hunger = data.Hunger; Thirst = data.Thirst; Cold = data.Cold; Radiation = data.Radiation;
                Weight = data.Weight; BloodMl = data.BloodMl; BleedingLevel = data.BleedingLevel; Zones = data.Zones;
            }
            public void Restore(HealthGadgetPreviewData data)
            {
                if (Enabled != null) Array.Copy(Enabled, data.Enabled, Math.Min(Enabled.Length, data.Enabled.Length));
                if (IndicatorEdited != null) Array.Copy(IndicatorEdited, data.IndicatorEdited, Math.Min(IndicatorEdited.Length, data.IndicatorEdited.Length));
                var kinds = (HealthGadgetKind[])Enum.GetValues(typeof(HealthGadgetKind));
                for (int i = 0; Seconds != null && i < Math.Min(kinds.Length, Seconds.Length); i++) data.SetRemainingSeconds(kinds[i], Seconds[i]);
                data.Hunger = Hunger; data.Thirst = Thirst; data.Cold = Cold; data.Radiation = Radiation;
                data.Weight = Weight; data.BloodMl = BloodMl; data.BleedingLevel = BleedingLevel; data.Zones = Zones;
            }
        }

        public HealthGadgetPreviewData Data => _data;
        public bool IsPreviewRunning => _active && _controller != null && _controller.IsReady;

        [MenuItem("Incident/Тесты/Панель здоровья")]
        public static void ShowWindow()
        {
            var window = GetWindow<K_HealthGadgetPreviewWindow>();
            window.titleContent = new GUIContent("Состояние персонажа");
            window.minSize = new Vector2(420f, 520f);
            window.Show();
        }
        private void OnEnable()
        {
            _data = new HealthGadgetPreviewData(); _savedData?.Restore(_data);
            EditorApplication.update -= Tick; EditorApplication.update += Tick;
            EditorApplication.playModeStateChanged -= PlayStateChanged; EditorApplication.playModeStateChanged += PlayStateChanged;
            AssemblyReloadEvents.beforeAssemblyReload -= BeforeAssemblyReload; AssemblyReloadEvents.beforeAssemblyReload += BeforeAssemblyReload;
        }
        private void OnDisable()
        {
            CaptureData(); DetachControl();
            EditorApplication.update -= Tick; EditorApplication.playModeStateChanged -= PlayStateChanged;
            AssemblyReloadEvents.beforeAssemblyReload -= BeforeAssemblyReload;
        }
        private void OnDestroy() => StopPreview();
        private void CaptureData() { if (_data != null) _savedData = new PreviewState(_data); }
        private void BeforeAssemblyReload() { CaptureData(); DetachControl(); }

        public void CreateGUI()
        {
            var tree = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(Folder + "K_HealthGadgetPreviewWindow.uxml");
            var sheet = AssetDatabase.LoadAssetAtPath<StyleSheet>(Folder + "K_HealthGadgetPreviewWindow.uss");
            rootVisualElement.Clear();
            if (tree == null || sheet == null) { rootVisualElement.Add(new Label("Не найдены файлы окна рядом со скриптом.")); return; }
            tree.CloneTree(rootVisualElement); rootVisualElement.styleSheets.Add(sheet);
            _status = rootVisualElement.Q<Label>("status"); _preview = rootVisualElement.Q<Toggle>("preview");
            Button("start").clicked += StartPreview; Button("showHealth").clicked += ShowHealth;
            Button("all").clicked += () => ApplyPreset(HealthGadgetPreviewPreset.All);
            Button("injuries").clicked += () => ApplyPreset(HealthGadgetPreviewPreset.Injuries);
            Button("buffs").clicked += () => ApplyPreset(HealthGadgetPreviewPreset.Buffs);
            Button("empty").clicked += () => ApplyPreset(HealthGadgetPreviewPreset.Empty);
            Button("screenIcons").clicked += () => SelectScreen(HealthGadgetScreen.Icons);
            Button("screenSummary").clicked += () => SelectScreen(HealthGadgetScreen.Summary);
            Button("screenTreatment").clicked += () => SelectScreen(HealthGadgetScreen.Treatment);
            Button("screenJournal").clicked += () => SelectScreen(HealthGadgetScreen.Journal);
            Button("screenPulse").clicked += () => SelectScreen(HealthGadgetScreen.Pulse);
            Button("restore").clicked += StopPreview;
            Button("replay").clicked += () => { if (IsPreviewRunning) { ShowHealth(); _gadget?.ReplayEditorStartup(); } };
            Button("previous").clicked += () => { if (IsPreviewRunning) _gadget?.ChangePage(-1); };
            Button("next").clicked += () => { if (IsPreviewRunning) _gadget?.ChangePage(1); };
            Button("resetTimers").clicked += ResetTimers; Button("shortTimers").clicked += ShortTimers;
            _preview.RegisterValueChangedCallback(e => { if (e.newValue) StartPreview(); else StopPreview(); });
            BuildControls(); SyncControls(); UpdateStatus();
        }
        private Button Button(string name) => rootVisualElement.Q<Button>(name);

        private void BuildControls()
        {
            _effects.Clear(); _seconds.Clear(); _indicators.Clear();
            var indicators = rootVisualElement.Q<VisualElement>("indicators");
            AddSlider(indicators, HealthGadgetKind.Hunger, "Сытость, %", 0f, 100f, () => _data.Hunger, v => _data.Hunger = v);
            AddSlider(indicators, HealthGadgetKind.Thirst, "Вода, %", 0f, 100f, () => _data.Thirst, v => _data.Thirst = v);
            AddSlider(indicators, HealthGadgetKind.Cold, "Холод, %", 0f, 100f, () => _data.Cold, v => _data.Cold = v);
            AddSlider(indicators, HealthGadgetKind.Radiation, "Радиация, %", 0f, 100f, () => _data.Radiation, v => _data.Radiation = v);
            AddSlider(indicators, HealthGadgetKind.Overload, "Вес, кг", 0f, 100f, () => _data.Weight, v => _data.Weight = v);
            AddSlider(indicators, HealthGadgetKind.Blood, "Кровь, мл", 0f, 5000f, () => _data.BloodMl, v => _data.BloodMl = v);
            var injuryValues = rootVisualElement.Q<VisualElement>("injuryValues");
            var target = new EnumField("Участок", _target);
            target.RegisterValueChangedCallback(e => { _target = (BodyPart)e.newValue; UpdateStatus(); }); injuryValues.Add(target);
            _bleeding = new SliderInt("Уровень кровотечения", 1, 3) { value = _data.BleedingLevel, showInputField = true };
            _bleeding.AddToClassList("indicator-slider");
            _bleeding.RegisterValueChangedCallback(e => { _data.BleedingLevel = e.newValue; MarkPrepared(); UpdateStatus(); }); injuryValues.Add(_bleeding);
            _zones = new SliderInt("Число участков", 1, 20) { value = _data.Zones, showInputField = true };
            _zones.AddToClassList("indicator-slider");
            _zones.RegisterValueChangedCallback(e => { _data.Zones = e.newValue; MarkPrepared(); UpdateStatus(); }); injuryValues.Add(_zones);
            var medicationActions = new VisualElement(); medicationActions.AddToClassList("actions");
            _takeParacetamol = new Button(() =>
            {
                if(IsPreviewRunning)RunEdit(() => _controller.TakeParacetamol(MedicalDatabase.Instance?.GetEffectDuration("paracetamol") ?? 180f));
            }) { name = "takeParacetamol", text = "Принять парацетамол", tooltip = "В Play Mode запускает настоящее ожидание начала действия, затем отсчёт обезболивания." };
            medicationActions.Add(_takeParacetamol); injuryValues.Add(medicationActions);
            var list = rootVisualElement.Q<VisualElement>("effects");
            foreach (HealthGadgetKind kind in Enum.GetValues(typeof(HealthGadgetKind)))
            {
                if ((int)kind < (int)HealthGadgetKind.Bleeding) continue;
                var row = new VisualElement(); row.AddToClassList("effect-row");
                var toggle = new Toggle(K_HealthGadgetContent.GetTitle(kind)) { name = "effect-" + kind };
                toggle.AddToClassList("effect-toggle");
                toggle.RegisterValueChangedCallback(e =>
                {
                    _data.Enabled[(int)kind] = e.newValue;
                    if (IsPreviewRunning) RunEdit(() => _controller.SetEffect(kind, e.newValue, _target, _data.Zones, _data.BleedingLevel, _data.GetRemainingSeconds(kind)));
                    else { MarkPrepared(); UpdateStatus(); }
                });
                _effects.Add(kind, toggle); row.Add(toggle);
                if (HealthGadgetPreviewData.IsTimed(kind))
                {
                    var field = new FloatField { name = "seconds-" + kind, isDelayed = true, tooltip = "Остаток настоящего эффекта в секундах. 0 завершает эффект. Если эффекта нет, изменение числа его не добавляет." };
                    field.AddToClassList("seconds");
                    field.RegisterValueChangedCallback(e =>
                    {
                        _data.SetRemainingSeconds(kind, e.newValue);
                        if (IsPreviewRunning) RunEdit(() => _controller.SetTimer(kind, e.newValue));
                        else { MarkPrepared(); UpdateStatus(); }
                    });
                    _seconds.Add(kind, field); row.Add(field);
                }
                list.Add(row);
            }
        }
        private void AddSlider(VisualElement parent, HealthGadgetKind kind, string label, float min, float max, Func<float> get, Action<float> set)
        {
            var slider = new Slider(label, min, max) { value = get(), showInputField = true }; slider.AddToClassList("indicator-slider");
            slider.RegisterValueChangedCallback(e =>
            {
                set(e.newValue);
                _data.IndicatorEdited[(int)kind] = !IsPreviewRunning;
                if (IsPreviewRunning) RunEdit(() => _controller.SetIndicator(kind, e.newValue));
                else { MarkPrepared(); UpdateStatus(); }
            });
            _indicators.Add(kind, slider); parent.Add(slider);
        }
        private void MarkPrepared() { if (!IsPreviewRunning) _hasPreparedChanges = true; }
        private void RunEdit(Func<string> edit)
        {
            try { _lastMessage = edit(); } catch (Exception ex) { _lastMessage = ex.GetBaseException().Message; }
            RefreshPreview();
        }

        public void StartPreview()
        {
            if (EditorApplication.isPlaying && !EditorApplication.isPlayingOrWillChangePlaymode)
            { UpdateStatus("Play Mode завершается. Дождитесь возврата в редактор."); return; }
            if (!EditorApplication.isPlaying)
            {
                _startWhenPlaying = true; CaptureData();
                if (!EditorApplication.isPlayingOrWillChangePlaymode) EditorApplication.isPlaying = true;
                SyncControls(); UpdateStatus(); return;
            }
            if (Time.frameCount < 2) { _startWhenPlaying = true; return; }
            _startWhenPlaying = false;
            if (IsPreviewRunning) { ShowHealth(); return; }
            _controller = HealthGadgetLiveTestController.Find();
            if (_controller == null || !_controller.IsReady)
            { _active = false; SyncControls(); UpdateStatus("Системы здоровья персонажа не найдены."); return; }
            _gadget = _controller.Gadget; _active = true; ShowHealth();
            if (_healWhenPlaying)
            {
                _healWhenPlaying = false;
                var prepared = new PreviewState(_data);
                RunEdit(() => _controller.ApplyPreset(HealthGadgetPreviewPreset.Empty, _data, _target));
                prepared.Restore(_data);
            }
            if (_hasPreparedChanges)
            {
                _hasPreparedChanges = false; RunEdit(() => _controller.ApplySettings(_data, _target));
            }
            else RefreshPreview();
            SyncControls(); UpdateStatus();
        }
        public void StopPreview() { _startWhenPlaying = false; DetachControl(); }
        private void DetachControl()
        {
            _active = false; _controller = null; _gadget = null; _lastMessage = null;
            if (_preview != null) _preview.SetValueWithoutNotify(_startWhenPlaying); UpdateStatus();
        }
        public void ApplyPreset(HealthGadgetPreviewPreset preset)
        {
            if (IsPreviewRunning) RunEdit(() => _controller.ApplyPreset(preset, _data, _target));
            else
            {
                HealthGadgetLiveTestController.PreparePreset(preset, _data);
                if (preset == HealthGadgetPreviewPreset.Empty)
                {
                    _healWhenPlaying = true;
                    Array.Clear(_data.IndicatorEdited, 0, _data.IndicatorEdited.Length);
                }
                _hasPreparedChanges = true; SyncControls(); UpdateStatus();
            }
        }
        private void ShowHealth()
        {
            if (!EditorApplication.isPlaying) return;
            var inventory = UnityEngine.Object.FindFirstObjectByType<K_InventoryUI>(); if (inventory == null) return;
            if (!inventory.IsOpen) inventory.ToggleInventory(); inventory.SwitchTab(1); _gadget?.RefreshNow();
        }
        public void RefreshPreview()
        {
            if (IsPreviewRunning) { _controller.Read(_data); _gadget?.RefreshNow(); SyncControls(); } UpdateStatus();
        }
        private void SelectScreen(HealthGadgetScreen screen) { if (IsPreviewRunning) _gadget?.SelectScreen(screen); }
        private void ShortTimers() => ChangeActiveTimers(false);
        private void ResetTimers() => ChangeActiveTimers(true);
        private void ChangeActiveTimers(bool reset)
        {
            bool[] enabled = (bool[])_data.Enabled.Clone(); if (reset) _data.ResetTimers();
            foreach (HealthGadgetKind kind in Enum.GetValues(typeof(HealthGadgetKind)))
            {
                if (!HealthGadgetPreviewData.IsTimed(kind) || !enabled[(int)kind]) continue;
                if (!reset) _data.SetRemainingSeconds(kind, 5f);
                if (IsPreviewRunning)
                {
                    try { _lastMessage = _controller.SetTimer(kind, _data.GetRemainingSeconds(kind)); }
                    catch (Exception ex) { _lastMessage = ex.GetBaseException().Message; }
                }
            }
            if (IsPreviewRunning) RefreshPreview(); else { MarkPrepared(); SyncControls(); UpdateStatus(); }
        }
        private bool IsFocused(VisualElement element)
        {
            var focus = element?.panel?.focusController?.focusedElement as VisualElement;
            return focus != null && (focus == element || element.Contains(focus));
        }
        private void SyncControls()
        {
            if (_preview != null) _preview.SetValueWithoutNotify(IsPreviewRunning || _startWhenPlaying);
            _takeParacetamol?.SetEnabled(IsPreviewRunning);
            foreach (var pair in _effects) pair.Value.SetValueWithoutNotify(_data.Enabled[(int)pair.Key]);
            foreach (var pair in _seconds) if (!IsFocused(pair.Value)) pair.Value.SetValueWithoutNotify(_data.GetRemainingSeconds(pair.Key));
            foreach (var pair in _indicators)
            {
                if (IsFocused(pair.Value)) continue;
                float value = pair.Key == HealthGadgetKind.Hunger ? _data.Hunger : pair.Key == HealthGadgetKind.Thirst ? _data.Thirst :
                    pair.Key == HealthGadgetKind.Cold ? _data.Cold : pair.Key == HealthGadgetKind.Radiation ? _data.Radiation : pair.Key == HealthGadgetKind.Overload ? _data.Weight : _data.BloodMl;
                pair.Value.SetValueWithoutNotify(value);
            }
            if (_bleeding != null && !IsFocused(_bleeding)) _bleeding.SetValueWithoutNotify(_data.BleedingLevel);
            if (_zones != null && !IsFocused(_zones)) _zones.SetValueWithoutNotify(_data.Zones);
        }
        private void Tick()
        {
            if (_startWhenPlaying && EditorApplication.isPlaying && EditorApplication.isPlayingOrWillChangePlaymode &&
                !EditorApplication.isCompiling && !EditorApplication.isUpdating) StartPreview();
            if (!IsPreviewRunning || EditorApplication.timeSinceStartup < _nextRefresh) return;
            _nextRefresh = EditorApplication.timeSinceStartup + .2d; RefreshPreview();
        }
        private void PlayStateChanged(PlayModeStateChange state)
        {
            if (state == PlayModeStateChange.EnteredPlayMode && _startWhenPlaying) StartPreview();
            if (state == PlayModeStateChange.ExitingPlayMode) StopPreview();
            if (state == PlayModeStateChange.EnteredEditMode) { _startWhenPlaying = false; SyncControls(); UpdateStatus(); }
        }
        private void UpdateStatus(string message = null)
        {
            if (_status == null) return;
            string details;
            if (IsPreviewRunning)
            {
                var vitality = UnityEngine.Object.FindFirstObjectByType<K_VitalitySystem>();
                details = "Управление включено. Изменения действуют на персонажа.";
                if (vitality != null) details += " Пульс: " + Mathf.RoundToInt(vitality.CurrentBpm) + " → " + Mathf.RoundToInt(vitality.TargetBpm) + " BPM.";
                if (!string.IsNullOrEmpty(_lastMessage)) details += "\n" + _lastMessage;
            }
            else details = _startWhenPlaying ? "Запускается Play Mode…" :
                EditorApplication.isPlaying ? "Управление выключено. Закрытие окна не снимает травмы." :
                _hasPreparedChanges ? "Настройки подготовлены. Они применятся один раз при запуске." :
                "Запустите Play и откройте здоровье. Без подготовленных изменений состояние останется прежним.";
            _status.text = message ?? details;
            var start = Button("start"); if (start != null) start.text = EditorApplication.isPlaying ? "Управлять состоянием" : "Запустить Play и открыть здоровье";
        }
    }
}
