
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Чистая база данных совместимости медикаментов.
    /// Не MonoBehaviour, не содержит игровой логики применения.
    /// Только структура + API чтения/регистрации.
    /// </summary>
    [CreateAssetMenu(
        fileName = "MedicalDatabase",
        menuName = "Incident/Medical/Medical Database",
        order = 3)]
    public class MedicalDatabase : ScriptableObject
    {
        [SerializeField] private List<MedicalEntry> _entries = new List<MedicalEntry>();

        [System.NonSerialized] private Dictionary<string, MedicalEntry> _cache;
        [System.NonSerialized] private bool _isInitialized;

        /// <summary>
        /// Опциональный convenience-доступ. Выставляется только при явном Initialize().
        /// Основной путь — явная инъекция ссылки на ассет.
        /// </summary>
        public static MedicalDatabase Instance { get; private set; }

        public void Initialize()
        {
            if (_isInitialized) return;

            if (_entries == null)
                _entries = new List<MedicalEntry>();

            BuildCache();
            _isInitialized = true;
            Instance = this;
        }

        private void BuildCache()
        {
            _cache = new Dictionary<string, MedicalEntry>(System.StringComparer.Ordinal);

            for (int i = 0; i < _entries.Count; i++)
            {
                var entry = _entries[i];
                if (entry == null) continue;
                if (string.IsNullOrWhiteSpace(entry.ItemID)) continue;

                if (_cache.ContainsKey(entry.ItemID))
                {
                    Debug.LogError(
                        $"[MedicalDatabase] Duplicate ItemID '{entry.ItemID}' at index {i}. First entry kept.");
                    continue;
                }

                _cache.Add(entry.ItemID, entry);
            }
        }

        /// <summary>
        /// Пытается найти запись по ItemID.
        /// </summary>
        public bool TryGetEntry(string itemID, out MedicalEntry entry)
        {
            if (!_isInitialized) Initialize();

            entry = null;
            if (string.IsNullOrWhiteSpace(itemID)) return false;
            return _cache.TryGetValue(itemID, out entry);
        }

        /// <summary>
        /// Возвращает запись или null.
        /// </summary>
        public MedicalEntry GetEntry(string itemID)
        {
            return TryGetEntry(itemID, out var entry) ? entry : null;
        }

        /// <summary>
        /// Является ли ItemID медицинским (есть запись в БД).
        /// </summary>
        public bool IsMedical(string itemID)
        {
            return TryGetEntry(itemID, out _);
        }

        /// <summary>
        /// Применим ли медикамент к конкретному сегменту тела.
        /// </summary>
        public bool IsApplicable(string itemID, BodyPart part)
        {
            return (int)part >= 0 && (int)part < 20
                && TryGetEntry(itemID, out var entry) && entry.ValidParts.Has(part);
        }

        /// <summary>
        /// Resolve the stable built-in IDs to their current medical roles. Serialized
        /// legacy entries keep their identity, but cannot revive a retired treatment.
        /// Custom/modded IDs continue to use their configured flags.
        /// </summary>
        public static MedicalEffect ResolveEffects(string itemID, MedicalEffect effects)
        {
            if (IsID(itemID, "splint_wood") || IsID(itemID, "splint_sam")) return MedicalEffect.Fracture;
            if (IsID(itemID, "collar_neck") || IsID(itemID, "SheyniyVorotnik")) return MedicalEffect.Collar;
            if (IsID(itemID, "surgery_kit")) return MedicalEffect.Gunshot;
            if (IsID(itemID, "tourniquet") || IsID(itemID, "tourniquet_elastic")) return MedicalEffect.BleedingArterial;
            if (IsID(itemID, "bandage")) return MedicalEffect.BleedingLight;
            if (IsID(itemID, "hemostatic")) return MedicalEffect.BleedingFull;
            if (IsID(itemID, "glue_medical")) return MedicalEffect.Laceration_Glue;
            if (IsID(itemID, "strips_wound")) return MedicalEffect.Laceration_Strips;
            if (IsID(itemID, "stapler_medical")) return MedicalEffect.Laceration_Staples;
            if (IsID(itemID, "coagulant")) return MedicalEffect.InternalBleeding;
            if (IsID(itemID, "transamacha")) return MedicalEffect.Transamacha;
            if (IsID(itemID, "jett")) return MedicalEffect.JETT;
            if (IsID(itemID, "transfusion")) return MedicalEffect.BloodRestore;
            if (IsID(itemID, "stimulator")) return MedicalEffect.Stimulator;
            if (IsID(itemID, "painkiller")) return MedicalEffect.Painkiller;
            if (IsID(itemID, "gel_heal")) return MedicalEffect.HealBoost;
            if (IsID(itemID, "pressure_bandage")) return MedicalEffect.PressureBandage;
            if (IsID(itemID, "paracetamol")) return MedicalEffect.MildPainkiller;
            if (IsID(itemID, "chest_seal")) return MedicalEffect.ChestSeal;
            if (IsID(itemID, "pelvic_binder")) return MedicalEffect.PelvicBinder;
            if (IsID(itemID, "amoxiclav")) return MedicalEffect.Antibiotic;
            return effects;
        }

        private static bool IsID(string itemID, string expected)
            => string.Equals(itemID, expected, System.StringComparison.OrdinalIgnoreCase);

        /// <summary>Systemic medicines are taken once, without selecting a body segment.</summary>
        public bool IsSystemic(string itemID) => IsSystemic(GetEffects(itemID));

        public static bool IsSystemic(MedicalEffect effects)
            => (effects & (MedicalEffect.Stimulator | MedicalEffect.Painkiller |
                MedicalEffect.MildPainkiller | MedicalEffect.Transamacha | MedicalEffect.Antibiotic)) != 0;

        internal static BodyPartMask ResolveValidParts(string itemID, MedicalEffect effects, BodyPartMask serializedParts)
        {
            if ((effects & MedicalEffect.JETT) != 0)
                return BodyPartMask.LeftShoulder | BodyPartMask.RightShoulder
                    | BodyPartMask.LeftQuadriceps | BodyPartMask.RightQuadriceps;
            if ((effects & MedicalEffect.Collar) != 0) return BodyPartMask.Head;
            if ((effects & MedicalEffect.ChestSeal) != 0) return BodyPartMask.Chest;
            if ((effects & MedicalEffect.PelvicBinder) != 0) return BodyPartMask.Pelvis;
            // A canonical body target keeps old drag/drop and save records valid;
            // callers can use IsSystemic to offer the direct "Принять" action.
            if (IsSystemic(effects)) return BodyPartMask.Chest;
            if ((effects & MedicalEffect.HealBoost) != 0) return BodyPartMask.Arms | BodyPartMask.Legs;
            if ((effects & MedicalEffect.Fracture) != 0 &&
                (IsID(itemID, "splint_wood") || IsID(itemID, "splint_sam")))
                return BodyPartMask.Arms | BodyPartMask.Legs;
            return serializedParts & BodyPartMask.All;
        }

        /// <summary>
        /// Возвращает флаги эффектов медикамента.
        /// </summary>
        public MedicalEffect GetEffects(string itemID)
        {
            return TryGetEntry(itemID, out var entry) ? entry.Effects : MedicalEffect.None;
        }

        /// <summary>
        /// Возвращает длительность применения в секундах.
        /// </summary>
        public float GetUseDuration(string itemID)
        {
            return TryGetEntry(itemID, out var entry) ? entry.UseDuration : 0f;
        }

        // ═══ Этап 6.4: параметры эффектов ═══
        public float GetHPRestoreAmount(string itemID)
            => TryGetEntry(itemID, out var entry) ? entry.HPRestoreAmount : 0f;

        public float GetBloodRestoreMl(string itemID)
            => TryGetEntry(itemID, out var entry) ? entry.BloodRestoreMl : 0f;

        public float GetEffectDuration(string itemID)
            => TryGetEntry(itemID, out var entry) ? entry.EffectDuration : 0f;

        /// <summary>
        /// Прерывается ли применение уроном.
        /// </summary>
        public bool IsCancelableByDamage(string itemID)
        {
            return TryGetEntry(itemID, out var entry) && entry.CancelableByDamage;
        }

        /// <summary>
        /// Все записи. Только для чтения.
        /// </summary>
        public IReadOnlyList<MedicalEntry> GetAllEntries()
        {
            if (!_isInitialized) Initialize();
            return _entries;
        }

        /// <summary>
        /// Регистрация или обновление записи в рантайме.
        /// Для тестов и будущих модов.
        /// </summary>
        public bool RegisterOrUpdate(MedicalEntry entry)
        {
            if (entry == null || string.IsNullOrWhiteSpace(entry.ItemID))
            {
                Debug.LogError("[MedicalDatabase] Cannot register entry with empty ItemID.");
                return false;
            }

            if (!_isInitialized) Initialize();

            if (_entries == null)
                _entries = new List<MedicalEntry>();

            int index = _entries.FindIndex(e => e != null && e.ItemID == entry.ItemID);
            if (index >= 0)
                _entries[index] = entry;
            else
                _entries.Add(entry);

            _cache[entry.ItemID] = entry;
            return true;
        }

        /// <summary>
        /// Заполняет матрицу заготовками из дизайна. ItemID оставлены пустыми,
        /// потому что реальные ID берутся из ассета ItemDatabase.
        /// </summary>
        [ContextMenu("Populate Default Matrix")]
        public void PopulateDefaultMatrix()
        {
            _entries = new List<MedicalEntry>
            {
                new MedicalEntry("", "Деревянная шина",
                    BodyPartMask.Arms | BodyPartMask.Legs,
                    MedicalEffect.Fracture, 3f, true),

                new MedicalEntry("", "Формуемая шина",
                    BodyPartMask.Arms | BodyPartMask.Legs,
                    MedicalEffect.Fracture, 2f, true),

                new MedicalEntry("", "Набор помощи при ЧМТ",
                    BodyPartMask.Head,
                    MedicalEffect.Collar, 10f, true),

                // Surgical processing also completes local hemostasis prepared
                // by the sponge; it does not replace splints or wound closure.
                new MedicalEntry("", "Хирургический набор",
                    BodyPartMask.All,
                    MedicalEffect.Gunshot, 10f, true),

                new MedicalEntry("", "Турникет CAT",
                    BodyPartMask.LeftShoulder | BodyPartMask.RightShoulder |
                    BodyPartMask.LeftQuadriceps | BodyPartMask.RightQuadriceps,
                    MedicalEffect.BleedingArterial, 1f, true),

                new MedicalEntry("", "Эластичный жгут",
                    BodyPartMask.LeftShoulder | BodyPartMask.RightShoulder |
                    BodyPartMask.LeftQuadriceps | BodyPartMask.RightQuadriceps,
                    MedicalEffect.BleedingArterial, 3f, true),

                new MedicalEntry("", "Бинт",
                    BodyPartMask.All,
                    MedicalEffect.BleedingLight, 2f, true),

                // 6.4.1: гемостатик теперь BleedingFull (полная остановка L1–L3).
                new MedicalEntry("", "Гемостатическая марля",
                    BodyPartMask.All,
                    MedicalEffect.BleedingFull, 2f, true),

                // 9: три средства от рваных ран.
                new MedicalEntry("", "Медицинский клей",
                    BodyPartMask.All,
                    MedicalEffect.Laceration_Glue, 1f, true),

                new MedicalEntry("", "Шовные пластыри",
                    BodyPartMask.All,
                    MedicalEffect.Laceration_Strips, 3f, true),

                new MedicalEntry("", "Медицинский степлер",
                    BodyPartMask.All,
                    MedicalEffect.Laceration_Staples, 6f, true),

                new MedicalEntry("", "Гемостатическая губка",
                    BodyPartMask.All,
                    MedicalEffect.InternalBleeding, 6f, true),

                new MedicalEntry("", "Транексам (TXA)",
                    BodyPartMask.Chest,
                    MedicalEffect.Transamacha, 3f, true, 180f),

                new MedicalEntry("", "Компрессионный турникет",
                    // Stage 4: all four limb parents; the pelvis is not an apply target.
                    BodyPartMask.LeftShoulder | BodyPartMask.RightShoulder |
                    BodyPartMask.LeftQuadriceps | BodyPartMask.RightQuadriceps,
                    MedicalEffect.JETT, 2f, true),

                new MedicalEntry("", "Пакет донорской крови",
                    BodyPartMask.Chest,
                    MedicalEffect.BloodRestore, 10f, true),

                new MedicalEntry("", "Кофеин — таблетки",
                    BodyPartMask.Chest,
                    MedicalEffect.Stimulator, 2f, true),

                new MedicalEntry("", "Морфин — автоинъектор",
                    BodyPartMask.Chest,
                    MedicalEffect.Painkiller, 2f, true, 180f),

                new MedicalEntry("", "Парацетамол",
                    BodyPartMask.Chest,
                    MedicalEffect.MildPainkiller, 2f, true, 180f),

                new MedicalEntry("", "Амоксициллин/клавуланат",
                    BodyPartMask.Chest,
                    MedicalEffect.Antibiotic, 3f, true, 240f),

                // 6.4.2: гель/аптечка HP теперь даёт HealBoost, не HPRestore.
                // Plan §10.4: the selected segment receives the boost.
                new MedicalEntry("", "Раневой гидрогель",
                    BodyPartMask.Arms | BodyPartMask.Legs,
                    MedicalEffect.HealBoost, 3f, true),

                new MedicalEntry("", "Давящий перевязочный пакет",
                    BodyPartMask.All,
                    MedicalEffect.PressureBandage, 3f, true),

                new MedicalEntry("", "Клапанная окклюзионная наклейка",
                    BodyPartMask.Chest,
                    MedicalEffect.ChestSeal, 3f, true),

                new MedicalEntry("", "Тазовый бандаж",
                    BodyPartMask.Pelvis,
                    MedicalEffect.PelvicBinder, 5f, true),
            };

            foreach (var entry in _entries) entry.ConfigureTransamachaTemplate();

            _isInitialized = false;
            _cache = null;
        }

        /// <summary>
        /// Stage 4: explicit repair for existing configured assets. ItemIDs, durations
        /// and all other treatment fields remain intact; initialization never migrates silently.
        /// </summary>
        [ContextMenu("Stage 4/Repair JETT Entries")]
        public void RepairJETTEntries()
        {
            if (_entries == null) return;
#if UNITY_EDITOR
            UnityEditor.Undo.RecordObject(this, "Stage 4: Repair JETT Entries");
#endif
            int changed = 0;
            foreach (var entry in _entries)
            {
                if (entry == null || ((entry.Effects & MedicalEffect.JETT) == 0 &&
                    entry.DisplayName != "JETT (узловой турникет)")) continue;
                if (entry.ConfigureMechanicalJETT()) changed++;
            }
            if (changed > 0)
            {
                _isInitialized = false;
                _cache = null;
#if UNITY_EDITOR
                UnityEditor.EditorUtility.SetDirty(this);
#endif
            }
            Debug.Log($"[MedicalDatabase] Stage 4 repaired {changed} JETT entries.");
        }

        private void OnValidate()
        {
            _isInitialized = false;
            _cache = null;

            if (_entries == null)
                _entries = new List<MedicalEntry>();
        }

        private void OnDisable()
        {
            if (Instance == this)
                Instance = null;
        }
    }
}
