using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Stage 1 (§10.4): гель per-segment.
    /// Активирует HealBoost только на указанном сегменте.
    ///
    /// НЕ реализует drag-drop — это задача UI-итерации
    /// (K_BodyPartDragOut на Image сегмента куклы).
    ///
    /// Интеграция с MedicalDatabase / MedicalEffectApplier — отдельная задача
    /// UI/инвентарь-этапа. Сейчас API применяется напрямую (см. K_CombatTestController).
    ///
    /// TODO(Stage 11/13): при интеграции с ItemDatabase назначить уникальный
    /// PrefabID. Значение 2001 — временный placeholder, НЕ совпадает с
    /// реальным ItemData в проекте. Не использовать как ключ в ассетах.
    /// </summary>
    public class K_GelItem : MonoBehaviour
    {
        // Stage 1: используется будущим Inventory-слоем. Сейчас — placeholder.
        // TODO(Stage 11/13): заменить на ID из ItemDatabase при интеграции.
        public ushort RequiredPrefabID => 2001;

        [Header("References")]
        [SerializeField] private K_HealthSystem _healthSystem;

        [Header("Icon (placeholder)")]
        [SerializeField] private bool _iconVisible;
        [SerializeField] private float _iconShowTimer;
        [SerializeField] private BodyPart _appliedPart = BodyPart.LeftQuadriceps;

        // The health system owns the lifetime. A hidden/disabled cosmetic adapter
        // cannot pause the medicine or leave a stale icon after expiry/load/death.
        public bool IsIconVisible => IconShowTimer > 0f;
        public float IconShowTimer => _healthSystem != null && !_healthSystem.IsDead
            ? _healthSystem.GetHealBoostSecondsRemaining(_appliedPart) : 0f;

        private void Awake()
        {
            if (_healthSystem == null)
                _healthSystem = GetComponent<K_HealthSystem>();
        }

        private void Update()
        {
            _iconShowTimer = IconShowTimer;
            _iconVisible = _iconShowTimer > 0f;
        }

        /// <summary>
        /// Применить гель на конкретный сегмент.
        /// duration &lt;= 0 → K_HealthSystem возьмёт _healBoostDuration.
        /// Default = 120с (спека ч.10.4).
        /// </summary>
        public bool UseGel(BodyPart part, float duration = 120f)
        {
            if (_healthSystem == null)
            {
                Debug.LogWarning("[K_GelItem] K_HealthSystem not found — gel skipped.");
                return false;
            }

            if (!_healthSystem.TryResolveHealBoostDuration(part, duration, out float acceptedDuration)) return false;
            duration = acceptedDuration;
            _healthSystem.ActivateHealBoost(part, duration);

            _appliedPart = part;
            _iconShowTimer = IconShowTimer;
            _iconVisible = _iconShowTimer > 0f;

            Debug.Log($"[K_GelItem] Gel applied on {part} for {duration:F1}s.");
            return _iconVisible;
        }

        public bool ShouldShowIcon() => IsIconVisible;

        [ContextMenu("Debug: Use Gel on Chest")]
        private void DebugUseGelChest() => UseGel(BodyPart.Chest);

        [ContextMenu("Debug: Use Gel on Left Quadriceps")]
        private void DebugUseGelLeftQuad() => UseGel(BodyPart.LeftQuadriceps);
    }
}
