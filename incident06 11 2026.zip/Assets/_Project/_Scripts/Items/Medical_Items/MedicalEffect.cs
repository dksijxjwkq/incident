namespace K_Incident.Core
{
    /// <summary>
    /// Эффекты медикаментов. Флаги, чтобы один медикамент мог давать
    /// несколько эффектов без изменения API.
    ///
    /// 6.4.1: добавлен BleedingFull.
    /// 6.4.2: добавлен HealBoost.
       /// 9:     Laceration (1<<5) объявлен deprecated, оставлен для
    ///        совместимости .asset. Добавлены три флага для клей/стрипы/степлер.
    /// Legacy names retain their asset bits. Collar starts head/TBI recovery;
    /// InternalBleeding prepares local surgical haemostasis; Transamacha is timed
    /// TXA support; JETT is a junctional external-compression device.
    ///
    /// ВАЖНО: биты НЕ переставлять и НЕ удалять. Новые эффекты — только на
    /// свободные старшие биты. Это инвариант сейв/asset-совместимости.
    /// </summary>
    [System.Flags]
    public enum MedicalEffect
    {
        None              = 0,

        Fracture          = 1 << 0,
        Gunshot           = 1 << 1,
        BleedingLight     = 1 << 2,
        BleedingArterial  = 1 << 3,
        InternalBleeding  = 1 << 4,   // Local surgical haemostat preparation.

        // DEPRECATED в Этапе 9. Раньше означал "любое средство от рваной раны".
        // Оставлен для совместимости с уже заполненными .asset.
        // В applier'е трактуется как Sealed с одноразовым warning'ом.
        Laceration        = 1 << 5,

        HPRestore         = 1 << 6,   // deprecated в 6.4.2
        BloodRestore      = 1 << 7,
        Painkiller        = 1 << 8,
        Stimulator        = 1 << 9,

        BleedingFull      = 1 << 10,
        HealBoost         = 1 << 11,

        // ── Этап 9: три средства от рваных ран ──
        Laceration_Glue    = 1 << 12,
        Laceration_Strips  = 1 << 13,
        Laceration_Staples = 1 << 14,
        Collar             = 1 << 15,

        // ── Этап 3: спец-средства IB ──
        Transamacha        = 1 << 16,
        JETT               = 1 << 17,
        PressureBandage    = 1 << 18,
        MildPainkiller     = 1 << 19,
        ChestSeal          = 1 << 20,
        PelvicBinder       = 1 << 21,
        Antibiotic         = 1 << 22,
    }
}
