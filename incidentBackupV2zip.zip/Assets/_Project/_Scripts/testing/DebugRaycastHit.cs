using UnityEngine;
using UnityEngine.EventSystems;
using System.Text;

public class DebugRaycastHit : MonoBehaviour, IPointerEnterHandler
{
    public void OnPointerEnter(PointerEventData eventData)
    {
        StringBuilder sb = new StringBuilder();
        sb.AppendLine($"=== RAYCAST HIT LIST (Cursor: {eventData.position}) ===");

        var results = new System.Collections.Generic.List<RaycastResult>();
        EventSystem.current.RaycastAll(eventData, results);

        foreach (var res in results)
        {
            sb.AppendLine($" {res.gameObject.name} | Layer: {LayerMask.LayerToName(res.gameObject.layer)} | RaycastTarget: {res.gameObject.GetComponent<UnityEngine.UI.Graphic>()?.raycastTarget}");
        }

        Debug.Log(sb.ToString());
    }
}