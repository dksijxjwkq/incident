﻿using UnityEngine;
using K_Incident.Core.Inventory;

namespace K_Incident.Core
{
    /// <summary>
    /// Отладочный компонент для спавна предметов в инвентарь игрока через Inspector.
    /// Используется ТОЛЬКО для тестирования. Удаляется перед релизом.
    /// ✅ ИСПРАВЛЕНО: Добавлена защита от дублирования предметов
    /// </summary>
    public class Debug_SpawnItem : MonoBehaviour
    {
        [Header("References")]
        [SerializeField, Tooltip("Перетащи сюда Makarov.asset из ItemDatabase")]
        private ItemStaticData _itemToSpawn;

        [SerializeField, Tooltip("Ссылка на K_InventorySetup в сцене")]
        private K_InventorySetup _inventorySetup;

        [Header("Spawn Settings")]
        [SerializeField, Tooltip("Количество предметов")]
        private int _quantity = 1;

        [SerializeField, Tooltip("Прочность (0-100)")]
        private int _durability = 100;

        [SerializeField, Tooltip("Повернуть предмет в сетке?")]
        private bool _rotated = false;

        [Header("Debug")]
        [SerializeField, Tooltip("Показывать логи спавна")]
        private bool _debugLogs = true;

        // Флаг для предотвращения двойного спавна
        private bool _isSpawning = false;

        [ContextMenu("🔫 Spawn Item in Inventory")]
        public void SpawnItem()
        {
            // Защита от повторного вызова
            if (_isSpawning)
            {
                if (_debugLogs) Debug.LogWarning("[Debug] Spawn already in progress, skipping...");
                return;
            }

            if (_itemToSpawn == null || _inventorySetup == null)
            {
                Debug.LogError("[Debug] ItemStaticData или InventorySetup не назначены!");
                return;
            }

            var playerController = _inventorySetup.Controller;
            if (playerController == null)
            {
                Debug.LogError("[Debug] Player InventoryController is null! Проверь K_InventorySetup.");
                return;
            }

            // ✅ Проверка: есть ли уже такой предмет в инвентаре (для одиночных предметов)
            if (_quantity == 1 && _itemToSpawn.HardStackLimit == 1)
            {
                foreach (var existingItem in playerController.GetSaveData().GetItems())
                {
                    if (existingItem.ItemID == _itemToSpawn.ItemID)
                    {
                        if (_debugLogs) Debug.LogWarning($"[Debug] Item '{_itemToSpawn.DisplayName}' already exists in inventory! Skipping spawn.");
                        return;
                    }
                }
            }

            _isSpawning = true;

            try
            {
                // ✅ Создаем уникальный экземпляр предмета из шаблона
                uint instanceID = GlobalIDManager.GenerateID();
                InventoryItem newItem = new InventoryItem(_itemToSpawn, instanceID, _quantity, _durability, _rotated);

                // ✅ Пытаемся поместить в первое свободное место
                bool placed = playerController.TryPlaceItemInFirstFreeSlot(newItem);

                if (placed)
                {
                    if (_debugLogs) Debug.Log($"[Debug] ✅ SUCCESS: Spawned '{_itemToSpawn.DisplayName}' (ID: {instanceID}) x{_quantity}");
                }
                else
                {
                    if (_debugLogs) Debug.LogWarning($"[Debug] ❌ FAILED: Нет свободного места для '{_itemToSpawn.DisplayName}'");
                }
            }
            finally
            {
                _isSpawning = false;
            }
        }

        [ContextMenu("🔫 Spawn 5x Item")]
        public void SpawnMultipleItems()
        {
            int originalQuantity = _quantity;
            _quantity = 5;
            SpawnItem();
            _quantity = originalQuantity;
        }

        [ContextMenu("️ Clear Inventory")]
        public void ClearInventory()
        {
            if (_inventorySetup?.Controller != null)
            {
                _inventorySetup.Controller.Clear();
                if (_debugLogs) Debug.Log("[Debug] Inventory cleared.");
            }
        }
    }
}