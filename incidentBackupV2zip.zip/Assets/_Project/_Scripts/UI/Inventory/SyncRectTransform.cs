using UnityEngine;

public class SyncRectTransform : MonoBehaviour
{
    [SerializeField] private RectTransform _target;

    private void LateUpdate()
    {
        if (_target == null) return;

        RectTransform rt = GetComponent<RectTransform>();
        rt.anchorMin = _target.anchorMin;
        rt.anchorMax = _target.anchorMax;
        rt.pivot = _target.pivot;
        rt.position = _target.position;
        rt.sizeDelta = _target.sizeDelta;
    }
}