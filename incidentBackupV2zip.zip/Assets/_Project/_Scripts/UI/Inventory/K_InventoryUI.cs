﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

namespace K_Incident.Core.Inventory
{
    [RequireComponent(typeof(CanvasGroup))]
    public class K_InventoryUI : MonoBehaviour
    {
        #region Inspector Fields
        [Header("Grid Config")]
        [SerializeField, Tooltip("Размер слота в пикселях (ТЗ: 70×70)")]
        private float _slotSize = 70f;
        [SerializeField, Tooltip("Отступ между слотами.")]
        private float _slotSpacing = 0f;

        [Header("References")]
        [SerializeField] private K_InventorySetup _inventorySetup;
        [SerializeField] private TextMeshProUGUI _weightText;
        [SerializeField] private GameObject _slotPrefab;
        [SerializeField] private GameObject _uiItemPrefab;
        [SerializeField] private GameObject _dragGhostPrefab;

        [Header("Player Inventory (LEFT PANE)")]
        [SerializeField] private Transform _pocketsGrid;
        [SerializeField] private Transform _backpackGrid;
        [SerializeField] private GameObject _backpackPanel;
        [SerializeField] private Transform _pocketsItemsContainer;
        [SerializeField] private Transform _backpackItemsContainer;

        [Header("Equipment Slots")]
        [SerializeField] private K_EquipmentSlotUI _primarySlot1;
        [SerializeField] private K_EquipmentSlotUI _primarySlot2;
        [SerializeField] private K_EquipmentSlotUI _pistolSlot;
        [SerializeField] private K_EquipmentSlotUI _backpackSlot;

        [Header("Surroundings/Container (RIGHT PANE)")]
        [SerializeField] private GameObject _surroundingsPanel;
        [SerializeField] private Transform _surroundingsGrid;
        [SerializeField] private Transform _surroundingsItemsContainer;
        [SerializeField] private TextMeshProUGUI _containerNameText;

        [Header("Background")]
        [SerializeField] private GameObject _inventoryBackground;

        [Header("Configuration")]
        [SerializeField] private KeyCode _openCloseKey = KeyCode.Tab;
        [SerializeField] private KeyCode _rotateKey = KeyCode.R;

        [Header("UI Colors")]
        [SerializeField] private Color _dragValidColor = new Color(0.33f, 0.55f, 0.33f, 0.7f);
        [SerializeField] private Color _dragInvalidColor = new Color(0.71f, 0.24f, 0.24f, 0.7f);
        [SerializeField] private Color _textNormalColor = new Color(0.71f, 0.73f, 0.75f);
        [SerializeField] private Color _textWarningColor = new Color(0.71f, 0.55f, 0.24f);
        [SerializeField] private Color _textCriticalColor = new Color(0.71f, 0.24f, 0.24f);

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = true;
        #endregion

        #region Constants
        private const int POCKET_COLUMNS = 4;
        private const int POCKET_ROWS = 2;
        private const int BACKPACK_BASE_COLS = 8;
        private const int BACKPACK_BASE_ROWS = 10;
        private const int POOL_PREWARM_COUNT = 100;
        private const float UI_REFRESH_THROTTLE = 0.3f;
        private const int GHOST_SORTING_ORDER = 32000;
        private const float WEIGHT_WARNING_RATIO = 0.9f;
        private const float WEIGHT_CRITICAL_RATIO = 1.1f;
        #endregion

        #region Fields
        private InventoryController _playerController;
        private InventoryController _activeContainerController;
        private CanvasGroup _canvasGroup;
        [SerializeField] private K_PlayerMotor _playerMotor;

        private bool _isOpen;
        private bool _isLootingContainer;
        private bool _pendingRefresh;
        private float _lastRefreshTime;

        private bool _isDragging;
        private UI_Item _draggedItem;
        private GameObject _dragGhost;
        private Image _dragGhostImage;
        private CanvasGroup _dragGhostCanvasGroup;
        private Canvas _dragGhostCanvas;
        private RectTransform _dragGhostRT;
        private Transform _rootCanvasTransform;

        private readonly List<RaycastResult> _raycastBuffer = new List<RaycastResult>(8);
        private PointerEventData _cachedEventData;

        private K_EquipmentSlotUI _draggedFromEquipmentSlot;
        private InventoryItem _draggedFromSlotItem;

        private readonly Queue<UI_Item> _itemPool = new Queue<UI_Item>(POOL_PREWARM_COUNT);
        private readonly Dictionary<string, UI_Item> _activeItems = new Dictionary<string, UI_Item>(200);

        private Action _onInventoryChangedHandler;
        private Action<float> _onWeightChangedHandler;
        private Action<InventoryItem, int, int> _onItemPlacedHandler;
        private Action<InventoryItem> _onItemChangedHandler;
        private Coroutine _refreshCoroutine;

        public static event Action<InventoryController> OnContainerClosed;
        #endregion

        #region Properties
        public bool IsOpen => _isOpen;
        public bool IsLooting => _isLootingContainer;
        public bool IsDragging => _isDragging;
        public float SlotSize => _slotSize;
        public float SlotSpacing => _slotSpacing;
        public bool IsDraggingFromEquipmentSlot => _draggedFromEquipmentSlot != null && _draggedFromSlotItem != null;
        #endregion

        #region Unity Lifecycle
        private void Awake()
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null) _canvasGroup = gameObject.AddComponent<CanvasGroup>();
            InitializeCanvasState();

            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(false);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(false);

            _rootCanvasTransform = FindRootCanvas();
            if (_rootCanvasTransform == null) Debug.LogError("[InventoryUI] ❌ CRITICAL: Root Canvas not found!");

            if (_dragGhostPrefab != null)
            {
                _dragGhost = Instantiate(_dragGhostPrefab);
                _dragGhost.SetActive(false);
                _dragGhostImage = _dragGhost.GetComponent<Image>();
                _dragGhostRT = _dragGhost.GetComponent<RectTransform>();

                if (_dragGhostImage == null || _dragGhostRT == null)
                {
                    Debug.LogError("[InventoryUI] ❌ DragGhost Prefab MISSING Image or RectTransform!");
                    _dragGhost = null;
                }
                else
                {
                    _dragGhostImage.raycastTarget = false;
                    _dragGhostCanvasGroup = _dragGhost.GetComponent<CanvasGroup>();
                    if (_dragGhostCanvasGroup == null) _dragGhostCanvasGroup = _dragGhost.AddComponent<CanvasGroup>();
                    _dragGhostCanvasGroup.blocksRaycasts = false;
                    _dragGhostCanvasGroup.interactable = false;
                    _dragGhostCanvasGroup.alpha = 1f;

                    _dragGhostCanvas = _dragGhost.GetComponent<Canvas>();
                    if (_dragGhostCanvas == null) _dragGhostCanvas = _dragGhost.AddComponent<Canvas>();
                    _dragGhostCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                    _dragGhostCanvas.overrideSorting = true;
                    _dragGhostCanvas.sortingOrder = GHOST_SORTING_ORDER;

                    if (_rootCanvasTransform != null)
                        _dragGhost.transform.SetParent(_rootCanvasTransform, false);
                    else
                        _dragGhost.transform.SetParent(transform.root, false);
                }
            }

            _cachedEventData = new PointerEventData(null);
            PreWarmPool(POOL_PREWARM_COUNT);
            DisableLayoutOnItemContainers();
            SetupItemsContainerRaycasts();
        }

        private void Start()
        {
            if (!InitializeReferences())
            {
                Debug.LogError("[InventoryUI] Initialization FAILED!");
                enabled = false;
                return;
            }

            if (_playerMotor == null) _playerMotor = FindFirstObjectByType<K_PlayerMotor>();
            BuildAllGrids();
            SubscribeToEvents();
            UpdateWeightDisplay(_playerController.CurrentWeightKg);
            ForceRefresh();
            SnapGridsToPixels();
        }

        private void Update()
        {
            if (Input.GetKeyDown(_openCloseKey)) ToggleInventory();

            if (_isDragging)
            {
                if (Input.GetKeyDown(_rotateKey)) RotateDraggedItem();
            }
        }

        private void OnDestroy()
        {
            UnsubscribeFromEvents();
            ClearPooledItems();
            if (_dragGhost != null)
            {
                Destroy(_dragGhost);
                _dragGhost = null;
            }
        }
        #endregion

        #region Initialization
        private Transform FindRootCanvas()
        {
            var parentCanvas = GetComponentInParent<Canvas>();
            if (parentCanvas != null)
            {
                while (parentCanvas.transform.parent != null && parentCanvas.transform.parent.GetComponent<Canvas>() != null)
                    parentCanvas = parentCanvas.transform.parent.GetComponent<Canvas>();
                return parentCanvas.transform;
            }
            var sceneCanvas = FindFirstObjectByType<Canvas>();
            return sceneCanvas?.transform;
        }

        private void InitializeCanvasState()
        {
            _canvasGroup.alpha = 0f;
            _canvasGroup.interactable = false;
            _canvasGroup.blocksRaycasts = false;
        }

        private void SetupItemsContainerRaycasts()
        {
            var containers = new[] { _pocketsItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                var graphic = container.GetComponent<Graphic>();
                if (graphic != null) graphic.raycastTarget = false;
            }
        }

        private bool InitializeReferences()
        {
            if (_inventorySetup == null) _inventorySetup = FindFirstObjectByType<K_InventorySetup>();
            _playerController = _inventorySetup?.Controller;
            if (_playerController == null)
            {
                Debug.LogError("[InventoryUI] InventoryController is null!");
                return false;
            }
            return true;
        }

        private void PreWarmPool(int count)
        {
            if (_uiItemPrefab == null) return;
            for (int i = 0; i < count; i++)
            {
                var item = CreateNewPooledItem();
                if (item != null) _itemPool.Enqueue(item);
            }
        }

        private UI_Item CreateNewPooledItem()
        {
            if (_uiItemPrefab == null) return null;
            var newItem = Instantiate(_uiItemPrefab, transform).GetComponent<UI_Item>();
            if (newItem == null) return null;
            newItem.gameObject.SetActive(false);
            var cg = newItem.GetComponent<CanvasGroup>();
            if (cg == null) cg = newItem.gameObject.AddComponent<CanvasGroup>();
            cg.alpha = 1f;
            cg.interactable = true;
            cg.blocksRaycasts = true;
            return newItem;
        }

        private void DisableLayoutOnItemContainers()
        {
            var containers = new[] { _pocketsItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;

                var rect = container.GetComponent<RectTransform>();
                if (rect != null)
                {
                    rect.anchorMin = new Vector2(0f, 1f);
                    rect.anchorMax = new Vector2(0f, 1f);
                    rect.pivot = new Vector2(0f, 1f);
                    rect.anchoredPosition = Vector2.zero;
                }

                var grid = container.GetComponent<GridLayoutGroup>();
                if (grid != null) grid.enabled = false;

                foreach (var graphic in container.GetComponents<Graphic>())
                    graphic.raycastTarget = false;
            }
        }
        #endregion

        #region Grid Management
        private void BuildAllGrids()
        {
            BuildGrid(_pocketsGrid, POCKET_COLUMNS * POCKET_ROWS, POCKET_COLUMNS, GridType.Pockets);
            if (_backpackGrid != null && _backpackPanel != null)
                RebuildBackpackGrid(BACKPACK_BASE_COLS, BACKPACK_BASE_ROWS);
            SetupEquipmentSlots();
        }

        private void SetupEquipmentSlots()
        {
            _primarySlot1?.Initialize(this, EquipmentSlotType.Primary);
            _primarySlot2?.Initialize(this, EquipmentSlotType.Primary);
            _pistolSlot?.Initialize(this, EquipmentSlotType.Pistol);
            _backpackSlot?.Initialize(this, EquipmentSlotType.Backpack);
        }

        private void BuildGrid(Transform parent, int slotCount, int columns, GridType gridType)
        {
            if (parent == null || _slotPrefab == null) return;
            ClearGrid(parent);
            SetupGridLayout(parent, columns);

            for (int i = 0; i < slotCount; i++)
            {
                var slot = Instantiate(_slotPrefab, parent);
                var slotImage = slot.GetComponent<Image>();
                if (slotImage != null)
                {
                    slotImage.color = Color.white;
                    slotImage.material = null;
                }

                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % columns;
                    int y = i / columns;
                    slotUI.Setup(x, y, gridType, this);
                }
            }
            LayoutRebuilder.ForceRebuildLayoutImmediate(parent.GetComponent<RectTransform>());
            SnapTransformToPixels(parent);
        }

        private void ClearGrid(Transform parent)
        {
            if (parent == null) return;
            for (int i = parent.childCount - 1; i >= 0; i--)
                Destroy(parent.GetChild(i).gameObject);
        }

        private void SetupGridLayout(Transform parent, int columns)
        {
            var grid = parent.GetComponent<GridLayoutGroup>();
            if (grid == null) grid = parent.gameObject.AddComponent<GridLayoutGroup>();
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = columns;
            grid.cellSize = new Vector2(_slotSize, _slotSize);
            grid.spacing = new Vector2(_slotSpacing, _slotSpacing);
            grid.childAlignment = TextAnchor.UpperLeft;
        }
        #endregion

        #region UI Control
        public void ToggleInventory()
        {
            if (_isOpen) CloseAll();
            else OpenInventoryOnly();
        }

        private void OpenInventoryOnly()
        {
            _isOpen = true;
            SetCanvasActive(true);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(true);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
            ForceRefresh();
            SnapGridsToPixels();
        }

        public void CloseAll()
        {
            _isOpen = false;
            _isLootingContainer = false;
            _activeContainerController = null;
            SetCanvasActive(false);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(true);
            if (_backpackPanel != null) _backpackPanel.SetActive(false);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(false);
            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
            ReturnAllItemsToPool();
            OnContainerClosed?.Invoke(_playerController);
        }

        public void OpenContainer(InventoryController containerController, string containerName, int width, int height)
        {
            if (containerController == null) return;
            if (_isLootingContainer && _activeContainerController == containerController)
            {
                CloseAll();
                return;
            }

            _activeContainerController = containerController;
            _isLootingContainer = true;
            _isOpen = true;
            SetCanvasActive(true);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(true);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(true);

            if (_surroundingsPanel != null)
            {
                _surroundingsPanel.SetActive(true);
                if (_containerNameText != null) _containerNameText.text = containerName;
                RebuildSurroundingsGrid(width, height);
            }
            ForceRefresh();
            SnapGridsToPixels();
        }

        private void SetCanvasActive(bool active)
        {
            if (_canvasGroup == null) return;
            _canvasGroup.alpha = active ? 1f : 0f;
            _canvasGroup.interactable = active;
            _canvasGroup.blocksRaycasts = active;
        }

        private void RebuildSurroundingsGrid(int width, int height)
        {
            if (_surroundingsGrid == null || _slotPrefab == null) return;
            ClearGrid(_surroundingsGrid);
            SetupGridLayout(_surroundingsGrid, width);

            for (int i = 0; i < width * height; i++)
            {
                var slot = Instantiate(_slotPrefab, _surroundingsGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                var rt = slot.GetComponent<RectTransform>();
                if (rt != null)
                {
                    rt.anchorMin = new Vector2(0f, 1f);
                    rt.anchorMax = new Vector2(0f, 1f);
                    rt.pivot = new Vector2(0.5f, 0.5f);
                    rt.anchoredPosition = Vector2.zero;
                    rt.sizeDelta = new Vector2(_slotSize, _slotSize);
                    rt.localScale = Vector3.one;
                }
                if (slotUI != null)
                {
                    int x = i % width;
                    int y = i / width;
                    slotUI.Setup(x, y, GridType.Container, this);
                }
            }
            LayoutRebuilder.ForceRebuildLayoutImmediate(_surroundingsGrid.GetComponent<RectTransform>());
        }

        public void OnBackpackEquipped(InventoryItem backpackItem)
        {
            if (_backpackGrid != null && backpackItem?.Data != null && _isOpen)
                RebuildBackpackGrid(backpackItem.Data.BackpackWidth, backpackItem.Data.BackpackHeight);
        }

        public void OnBackpackUnequipped()
        {
            if (_backpackGrid != null && _isOpen)
                RebuildBackpackGrid(BACKPACK_BASE_COLS, BACKPACK_BASE_ROWS);
        }

        public void RebuildBackpackGrid(int width, int height)
        {
            if (_backpackGrid == null || _slotPrefab == null) return;
            ClearGrid(_backpackGrid);
            SetupGridLayout(_backpackGrid, width);

            for (int i = 0; i < width * height; i++)
            {
                var slot = Instantiate(_slotPrefab, _backpackGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % width;
                    int y = i / width;
                    slotUI.Setup(x, y, GridType.Backpack, this);
                }
            }
            LayoutRebuilder.ForceRebuildLayoutImmediate(_backpackGrid.GetComponent<RectTransform>());
            RefreshAll();
            SnapTransformToPixels(_backpackGrid);
        }
        #endregion

        #region Refresh System
        public void RefreshAll()
        {
            if (_pendingRefresh) return;
            if (Time.time - _lastRefreshTime < UI_REFRESH_THROTTLE)
            {
                _pendingRefresh = true;
                return;
            }
            _pendingRefresh = true;
            _lastRefreshTime = Time.time;
            if (_refreshCoroutine != null) StopCoroutine(_refreshCoroutine);
            _refreshCoroutine = StartCoroutine(RefreshNextFrame());
        }

        public void ForceRefresh()
        {
            _pendingRefresh = false;
            _lastRefreshTime = 0f;
            if (_refreshCoroutine != null)
            {
                StopCoroutine(_refreshCoroutine);
                _refreshCoroutine = null;
            }
            _refreshCoroutine = StartCoroutine(RefreshNextFrame());
        }

        private IEnumerator RefreshNextFrame()
        {
            yield return null;
            _pendingRefresh = false;
            ReturnAllItemsToPool();

            RefreshGrid(GridType.Pockets, POCKET_COLUMNS, POCKET_ROWS, _pocketsItemsContainer);
            if (_backpackGrid != null)
                RefreshGrid(GridType.Backpack, BACKPACK_BASE_COLS, BACKPACK_BASE_ROWS, _backpackItemsContainer);
            if (_isLootingContainer && _activeContainerController != null)
                RefreshGrid(GridType.Container, _activeContainerController.Width, _activeContainerController.Height, _surroundingsItemsContainer);

            _primarySlot1?.Refresh();
            _primarySlot2?.Refresh();
            _pistolSlot?.Refresh();
            _backpackSlot?.Refresh();
        }

        private void RefreshGrid(GridType type, int cols, int rows, Transform container)
        {
            var controller = (type == GridType.Container) ? _activeContainerController : _playerController;
            if (controller == null || container == null) return;

            for (int y = 0; y < rows; y++)
                for (int x = 0; x < cols; x++)
                    RefreshSlot(type, x, y, controller, container);
        }

        private void RefreshSlot(GridType type, int x, int y, InventoryController controller, Transform container)
        {
            // Предметы в зоне карманов (0..3, 0..1) отрисовываются ТОЛЬКО в панели Pockets
            if (type == GridType.Backpack && x < POCKET_COLUMNS && y < POCKET_ROWS) return;

            string key = GetCellKey(type, x, y);
            var item = controller.GetItemAt(x, y);

            if (_activeItems.TryGetValue(key, out var uiItem))
            {
                if (item == null)
                {
                    ReturnToPool(uiItem);
                    _activeItems.Remove(key);
                }
                else
                {
                    uiItem.UpdateData(item);
                    uiItem.gameObject.SetActive(true);
                }
            }
            else if (item != null && controller.IsRootCell(item.InstanceID, x, y))
            {
                CreateUIItem(item, x, y, type, container);
            }
        }

        private string GetCellKey(GridType type, int x, int y) => $"{type}_{x}_{y}";

        private void CreateUIItem(InventoryItem item, int x, int y, GridType type, Transform container)
        {
            string key = GetCellKey(type, x, y);
            if (_activeItems.ContainsKey(key)) return;

            var parentContainer = GetItemsContainer(type);
            if (parentContainer == null || _uiItemPrefab == null || item == null) return;

            var uiItem = GetPooledItem();
            if (uiItem == null) return;

            uiItem.transform.SetParent(parentContainer, false);
            uiItem.transform.SetAsLastSibling();
            var rect = uiItem.GetComponent<RectTransform>();

            if (rect != null)
            {
                Vector2Int size = item.CurrentSize;
                float widthPx = size.x * _slotSize + (size.x - 1) * _slotSpacing;
                float heightPx = size.y * _slotSize + (size.y - 1) * _slotSpacing;

                // FIX: Математически точное позиционирование. Pivot (0,1) означает, что anchoredPosition задает Верх-Лево-Верхний угол.
                rect.anchorMin = new Vector2(0f, 1f);
                rect.anchorMax = new Vector2(0f, 1f);
                rect.pivot = new Vector2(0f, 1f);
                rect.sizeDelta = new Vector2(widthPx, heightPx);

                // Координата X идет вправо (+), координата Y идет вниз (-) из-за pivot (0,1)
                rect.anchoredPosition = new Vector2(x * (_slotSize + _slotSpacing), -y * (_slotSize + _slotSpacing));
                rect.localScale = Vector3.one;

                // FIX: УБРАНО rect.localRotation. Габариты (sizeDelta) уже отражают поворот предмета.
                // Вращение самого контейнера вокруг верхнего левого угла вызывало "улетание" предмета из сетки.
            }

            uiItem.gameObject.SetActive(true);
            uiItem.Setup(item, this, type, x, y);
            _activeItems[key] = uiItem;
        }

        private Transform GetItemsContainer(GridType type) => type switch
        {
            GridType.Pockets => _pocketsItemsContainer,
            GridType.Backpack => _backpackItemsContainer,
            GridType.Container => _surroundingsItemsContainer,
            _ => null
        };
        #endregion

        #region Drag & Drop System
        private void ForceResetGhostTransform()
        {
            if (_dragGhostRT == null) return;
            _dragGhostRT.anchorMin = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchorMax = new Vector2(0.5f, 0.5f);
            _dragGhostRT.pivot = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchoredPosition = Vector2.zero;
            _dragGhostRT.sizeDelta = new Vector2(_slotSize, _slotSize);
            _dragGhostRT.localScale = Vector3.one;
            _dragGhostRT.localRotation = Quaternion.identity;
        }

        public void StartDrag(UI_Item draggedItem, PointerEventData eventData)
        {
            if (draggedItem == null || draggedItem.Item == null || _dragGhost == null || _dragGhostImage == null || _dragGhostRT == null) return;
            if (draggedItem.Item.Data?.Icon == null) return;

            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedItem = draggedItem;
            _isDragging = true;

            if (_rootCanvasTransform != null)
                _dragGhost.transform.SetParent(_rootCanvasTransform, false);
            else
                _dragGhost.transform.SetParent(transform.root, false);

            ForceResetGhostTransform();
            _dragGhostRT.SetAsLastSibling();
            _dragGhostImage.sprite = draggedItem.Item.Data.Icon;
            _dragGhostImage.enabled = true;
            _dragGhostImage.color = Color.white;
            _dragGhostImage.raycastTarget = false;

            UpdateGhostSize();
            if (draggedItem.Item.IsRotated)
                _dragGhostImage.rectTransform.localRotation = Quaternion.Euler(0, 0, -draggedItem.Item.RotationAngle);

            _dragGhost.SetActive(true);
            UpdateDragGhostPosition(eventData);
        }

        public void StartDragFromEquipmentSlot(K_EquipmentSlotUI slot, PointerEventData eventData)
        {
            if (slot == null || slot.EquippedItem == null || _dragGhost == null || _dragGhostImage == null || _dragGhostRT == null) return;
            var item = slot.EquippedItem;
            if (item.Data?.Icon == null) return;

            _draggedFromEquipmentSlot = slot;
            _draggedFromSlotItem = item;
            _draggedItem = null;
            _isDragging = true;

            if (_rootCanvasTransform != null)
                _dragGhost.transform.SetParent(_rootCanvasTransform, false);
            else
                _dragGhost.transform.SetParent(transform.root, false);

            ForceResetGhostTransform();
            _dragGhostRT.SetAsLastSibling();
            _dragGhostImage.sprite = item.Data.Icon;
            _dragGhostImage.enabled = true;
            _dragGhostImage.color = Color.white;
            _dragGhostImage.raycastTarget = false;

            UpdateGhostSize();
            if (item.IsRotated)
                _dragGhostImage.rectTransform.localRotation = Quaternion.Euler(0, 0, -item.RotationAngle);

            _dragGhost.SetActive(true);
            UpdateDragGhostPosition(eventData);
        }

        public void UpdateDragGhostPosition(PointerEventData eventData)
        {
            if (!_isDragging || _dragGhost == null || !_dragGhost.activeSelf || _dragGhostRT == null) return;
            RectTransform canvasRT = _rootCanvasTransform as RectTransform;
            if (canvasRT == null) return;

            UnityEngine.Camera cam = null;
            var canvas = canvasRT.GetComponent<Canvas>();
            if (canvas != null)
            {
                cam = canvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : canvas.worldCamera;
            }

            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRT, eventData.position, cam, out Vector2 localPoint))
            {
                _dragGhostRT.anchoredPosition = localPoint;
            }
            UpdateGhostColor();
        }

        private void RotateDraggedItem()
        {
            var item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null || !item.Data.CanRotate) return;

            if (_draggedItem != null)
            {
                var controller = GetControllerForGrid(_draggedItem.GridType);
                if (controller != null)
                {
                    if (controller.RotateItem(item))
                    {
                        _draggedItem.UpdateVisuals();
                    }
                    else
                    {
                        LogDebug("[InventoryUI] Rotation rejected (collision or out of bounds)");
                    }
                }
            }
            else
            {
                item.Rotate();
            }

            UpdateGhostSize();
            if (_dragGhostImage != null)
                _dragGhostImage.rectTransform.localRotation = Quaternion.Euler(0, 0, -item.RotationAngle);

            LogDebug($"[InventoryUI] Rotated item. New size: {item.CurrentSize}, angle: {item.RotationAngle}°");
        }

        private void UpdateGhostSize()
        {
            if (_dragGhostImage == null) return;
            Vector2Int size;
            if (_draggedItem?.Item != null) size = _draggedItem.Item.CurrentSize;
            else if (_draggedFromSlotItem != null) size = _draggedFromSlotItem.CurrentSize;
            else size = new Vector2Int(1, 1);

            float w = size.x * _slotSize + (size.x - 1) * _slotSpacing;
            float h = size.y * _slotSize + (size.y - 1) * _slotSpacing;
            _dragGhostImage.rectTransform.sizeDelta = new Vector2(w, h);
        }

        private void UpdateGhostColor()
        {
            if (_dragGhostImage == null || EventSystem.current == null) return;
            InventoryItem item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null) return;

            if (_cachedEventData == null) _cachedEventData = new PointerEventData(EventSystem.current);
            _cachedEventData.position = Input.mousePosition;
            _raycastBuffer.Clear();
            EventSystem.current.RaycastAll(_cachedEventData, _raycastBuffer);

            Color targetColor = _dragInvalidColor;

            foreach (var result in _raycastBuffer)
            {
                var slot = result.gameObject.GetComponent<K_InventorySlotUI>();
                if (slot != null)
                {
                    Vector2Int itemSize = item.CurrentSize;
                    int targetX = slot.X;
                    int targetY = slot.Y;
                    var controller = GetControllerForGrid(slot.GridType);
                    if (controller == null) break;

                    // FIX: Удален искусственный запрет на зону карманов. 
                    // Логический контроллер (8x10) сам проверит валидность. 
                    // Визуальное дублирование предотвращается в RefreshSlot.

                    int controllerWidth = controller.Width;
                    int controllerHeight = controller.Height;

                    bool isOutOfBounds = targetX < 0 || targetY < 0 ||
                                         targetX + itemSize.x > controllerWidth ||
                                         targetY + itemSize.y > controllerHeight;

                    if (isOutOfBounds)
                    {
                        targetColor = _dragInvalidColor;
                        break;
                    }

                    bool canPlace = controller.CanPlaceItem(item, targetX, targetY);
                    targetColor = canPlace ? _dragValidColor : _dragInvalidColor;
                    break;
                }

                var equipSlot = result.gameObject.GetComponent<K_EquipmentSlotUI>();
                if (equipSlot != null)
                {
                    if (ValidateEquipItem(item, equipSlot)) targetColor = _dragValidColor;
                    break;
                }
            }
            _dragGhostImage.color = targetColor;
        }

        public bool TryPlaceItem(UI_Item draggedItem, GridType targetGrid, int targetX, int targetY)
        {
            if (draggedItem?.Item == null) return false;
            var item = draggedItem.Item;
            var sourceController = GetControllerForGrid(draggedItem.GridType);
            var targetController = GetControllerForGrid(targetGrid);
            if (targetController == null) return false;

            // FIX: Удален искусственный запрет. Если игрок перетаскивает предмет в логические координаты (0..3, 0..1),
            // единый контроллер 8x10 успешно его разместит, а UI отрисует его в панели Карманов.

            if (targetX < 0 || targetY < 0 || targetX >= targetController.Width || targetY >= targetController.Height)
            {
                LogDebug($"[InventoryUI] REJECTED - out of bounds ({targetX},{targetY})");
                return false;
            }

            if (sourceController == targetController && draggedItem.X == targetX && draggedItem.Y == targetY)
                return true;

            if (sourceController == targetController)
            {
                bool moved = sourceController.MoveItem(item, targetX, targetY);
                return moved;
            }

            int originX = draggedItem.X;
            int originY = draggedItem.Y;
            if (!sourceController.RemoveItem(item)) return false;

            int placedCount = targetController.TryPlaceItem(item, targetX, targetY);
            bool success = placedCount > 0;
            if (!success) sourceController.TryPlaceItem(item, originX, originY);

            return success;
        }

        public bool TryEquipItem(UI_Item draggedItem, K_EquipmentSlotUI slot)
        {
            if (draggedItem?.Item == null || slot == null) return false;
            var item = draggedItem.Item;
            if (!ValidateEquipItem(item, slot)) { ReturnToPool(draggedItem); return false; }

            var sourceController = GetControllerForGrid(draggedItem.GridType);
            if (sourceController == null) { ReturnToPool(draggedItem); return false; }

            if (sourceController.RemoveItem(item))
            {
                slot.OnDropItem(item);
                slot.SetEquippedItem(item);
                draggedItem.gameObject.SetActive(false);
                ReturnToPool(draggedItem);
                EndDragComplete();
                return true;
            }
            ReturnToPool(draggedItem);
            return false;
        }

        public bool TryPlaceItemFromEquipmentSlot(GridType targetGrid, int targetX, int targetY)
        {
            if (_draggedFromEquipmentSlot == null || _draggedFromSlotItem == null) return false;
            var item = _draggedFromSlotItem;
            var targetController = GetControllerForGrid(targetGrid);
            if (targetController == null) return false;

            if (targetX < 0 || targetY < 0 || targetX >= targetController.Width || targetY >= targetController.Height)
                return false;

            int placedCount = targetController.TryPlaceItem(item, targetX, targetY);
            if (placedCount > 0)
            {
                _draggedFromEquipmentSlot.SetEquippedItem(null);
                return true;
            }
            return false;
        }

        public bool TryEquipItemFromSlot(K_EquipmentSlotUI sourceSlot, K_EquipmentSlotUI targetSlot)
        {
            if (sourceSlot?.EquippedItem == null || targetSlot == null || sourceSlot == targetSlot) return false;
            var item = sourceSlot.EquippedItem;
            if (!ValidateEquipItem(item, targetSlot)) return false;

            if (targetSlot.IsOccupied)
            {
                targetSlot.Unequip();
                if (targetSlot.IsOccupied) return false;
            }
            sourceSlot.Unequip();
            targetSlot.OnDropItem(item);
            return true;
        }

        public void ForceEndDrag(UI_Item item)
        {
            if (item == null) return;
            var eventData = EventSystem.current != null ? new PointerEventData(EventSystem.current) : new PointerEventData(null);
            item.OnEndDrag(eventData);
            EndDragComplete();
        }

        public void EndDragComplete()
        {
            _isDragging = false;
            _draggedItem = null;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            if (_dragGhost != null) _dragGhost.SetActive(false);
            MarkForRefresh();
        }

        public void EndDragFromEquipmentSlot()
        {
            _isDragging = false;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedItem = null;
            if (_dragGhost != null) _dragGhost.SetActive(false);
            MarkForRefresh();
        }

        private bool ValidateEquipItem(InventoryItem item, K_EquipmentSlotUI slot)
        {
            if (item?.Data == null) return false;
            return slot.SlotType switch
            {
                EquipmentSlotType.Primary => item.Type == ItemType.Weapon && !item.Data.IsPistol,
                EquipmentSlotType.Pistol => item.Type == ItemType.Weapon && item.Data.IsPistol,
                EquipmentSlotType.Backpack => item.Data.IsBackpack,
                _ => false
            };
        }
        #endregion

        #region Quick Move & Utilities
        public void QuickMoveItem(InventoryItem item, int sourceGridType)
        {
            if (item == null) return;
            var sourceGrid = (GridType)sourceGridType;
            if (sourceGrid == GridType.Pockets || sourceGrid == GridType.Backpack)
            {
                if (_activeContainerController != null && _activeContainerController.TryPlaceItemInFirstFreeSlot(item))
                {
                    _playerController.RemoveItem(item);
                    MarkForRefresh();
                }
            }
            else if (sourceGrid == GridType.Container && _activeContainerController != null)
            {
                if (_playerController.TryPlaceItemInFirstFreeSlot(item))
                {
                    _activeContainerController.RemoveItem(item);
                    MarkForRefresh();
                }
            }
        }

        private void MarkForRefresh()
        {
            if (!_pendingRefresh)
            {
                _pendingRefresh = true;
                StartCoroutine(RefreshNextFrame());
            }
        }
        #endregion

        #region Event Handling
        private void SubscribeToEvents()
        {
            if (_playerController == null) return;
            _onInventoryChangedHandler = RefreshAll;
            _onWeightChangedHandler = UpdateWeightDisplay;
            _onItemPlacedHandler = (item, x, y) => RefreshAll();
            _onItemChangedHandler = _ => RefreshAll();

            _playerController.OnInventoryChanged += _onInventoryChangedHandler;
            _playerController.OnWeightChanged += _onWeightChangedHandler;
            _playerController.OnItemPlaced += _onItemPlacedHandler;
            _playerController.OnItemRemoved += _onItemChangedHandler;
            _playerController.OnItemRotated += _onItemChangedHandler;
            _playerController.OnItemQuantityChanged += _onItemChangedHandler;
        }

        private void UnsubscribeFromEvents()
        {
            if (_playerController == null) return;
            _playerController.OnInventoryChanged -= _onInventoryChangedHandler;
            _playerController.OnWeightChanged -= _onWeightChangedHandler;
            _playerController.OnItemPlaced -= _onItemPlacedHandler;
            _playerController.OnItemRemoved -= _onItemChangedHandler;
            _playerController.OnItemRotated -= _onItemChangedHandler;
            _playerController.OnItemQuantityChanged -= _onItemChangedHandler;
        }

        private void UpdateWeightDisplay(float kg)
        {
            if (_weightText == null || _playerController == null) return;
            float ratio = _playerController.WeightRatio;
            Color textColor = ratio > WEIGHT_CRITICAL_RATIO ? _textCriticalColor : ratio > WEIGHT_WARNING_RATIO ? _textWarningColor : _textNormalColor;
            float maxKg = _playerController.MaxCapacityGrams / 1000f;
            _weightText.text = $"<color=#{ColorUtility.ToHtmlStringRGB(textColor)}>{kg:F1} / {maxKg:F0} kg</color>";
        }
        #endregion

        #region Pool Management
        private UI_Item GetPooledItem()
        {
            if (_itemPool.Count > 0) return _itemPool.Dequeue();
            return CreateNewPooledItem();
        }

        private void ReturnToPool(UI_Item item)
        {
            if (item == null) return;
            item.ResetState();
            item.gameObject.SetActive(false);
            item.transform.SetParent(transform, false);
            _itemPool.Enqueue(item);
        }

        private void ReturnAllItemsToPool()
        {
            foreach (var kvp in _activeItems)
            {
                if (_isDragging && _draggedItem != null && kvp.Value == _draggedItem)
                {
                    continue;
                }
                ReturnToPool(kvp.Value);
            }
            _activeItems.Clear();

            if (_isDragging && _draggedItem != null)
            {
                string key = GetCellKey(_draggedItem.GridType, _draggedItem.X, _draggedItem.Y);
                _activeItems[key] = _draggedItem;
            }
        }

        private void ClearPooledItems()
        {
            foreach (var item in _itemPool) if (item != null) Destroy(item.gameObject);
            _itemPool.Clear();
            _activeItems.Clear();
        }
        #endregion

        #region Public API
        public InventoryController GetControllerForGrid(GridType gridType) =>
            gridType == GridType.Container ? _activeContainerController : _playerController;

        public int GetGridWidth(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_COLUMNS;
            var c = GetControllerForGrid(gridType);
            return c?.Width ?? 0;
        }

        public int GetGridHeight(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_ROWS;
            var c = GetControllerForGrid(gridType);
            return c?.Height ?? 0;
        }

        public void OnEquipmentSlotDrop(K_EquipmentSlotUI slot, PointerEventData eventData)
        {
            if (slot == null || eventData?.pointerDrag == null) return;
            var draggedUI = eventData.pointerDrag.GetComponent<UI_Item>();

            if (draggedUI?.Item != null)
            {
                var sourceController = GetControllerForGrid(draggedUI.GridType);
                if (sourceController == null) return;

                if (ValidateEquipItem(draggedUI.Item, slot) && sourceController.RemoveItem(draggedUI.Item))
                {
                    slot.OnDropItem(draggedUI.Item);
                    draggedUI.gameObject.SetActive(false);
                    ReturnToPool(draggedUI);
                    EndDragComplete();
                    MarkForRefresh();
                }
                return;
            }

            if (_draggedFromEquipmentSlot != null && _draggedFromSlotItem != null)
            {
                if (ValidateEquipItem(_draggedFromSlotItem, slot))
                    TryEquipItemFromSlot(_draggedFromEquipmentSlot, slot);
            }
        }
        #endregion

        #region Pixel Snapping
        private void SnapGridsToPixels()
        {
            SnapTransformToPixels(_pocketsGrid);
            if (_backpackGrid != null) SnapTransformToPixels(_backpackGrid);
            if (_surroundingsGrid != null) SnapTransformToPixels(_surroundingsGrid);
        }

        private void SnapTransformToPixels(Transform target)
        {
            if (target == null) return;
            var rect = target.GetComponent<RectTransform>();
            if (rect != null)
            {
                Vector3 pos = rect.position;
                rect.position = new Vector3(Mathf.Round(pos.x), Mathf.Round(pos.y), pos.z);
            }
            foreach (Transform child in target)
            {
                var childRect = child.GetComponent<RectTransform>();
                if (childRect != null)
                {
                    Vector3 pos = childRect.position;
                    childRect.position = new Vector3(Mathf.Round(pos.x), Mathf.Round(pos.y), pos.z);
                }
            }
        }
        #endregion

        #region Debug Helpers
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs) UnityEngine.Debug.Log(message);
        }
        #endregion
    }
}