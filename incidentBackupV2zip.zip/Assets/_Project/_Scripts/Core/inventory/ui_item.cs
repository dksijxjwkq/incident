﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Inventory
{
    public class UI_Item : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
    {
        #region Inspector Fields
        [Header("References")]
        [SerializeField] private Image _icon;
        [SerializeField] private TextMeshProUGUI _quantityText;
        [SerializeField] private GameObject _quantityGroup;
        [Header("Debug")]
        [SerializeField] private bool _debugLogs = true;
        #endregion

        #region Fields
        private InventoryItem _item;
        private K_InventoryUI _inventoryUI;
        private GridType _gridType;
        private int _gridX, _gridY;
        private bool _isDragging;
        private CanvasGroup _canvasGroup;
        #endregion

        #region Properties
        public InventoryItem Item => _item;
        public GridType GridType => _gridType;
        public int X => _gridX;
        public int Y => _gridY;
        public bool IsDragging => _isDragging;
        #endregion

        #region Initialization
        private void Awake()
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null)
                _canvasGroup = gameObject.AddComponent<CanvasGroup>();

            if (_icon != null)
            {
                _icon.raycastTarget = true;
            }
        }

        public void Setup(InventoryItem item, K_InventoryUI inventoryUI, GridType gridType, int x, int y)
        {
            _item = item;
            _inventoryUI = inventoryUI;
            _gridType = gridType;
            _gridX = x;
            _gridY = y;

            if (_canvasGroup != null)
            {
                _canvasGroup.interactable = true;
                _canvasGroup.blocksRaycasts = true;
                _canvasGroup.alpha = 1f;
            }
            gameObject.SetActive(true);
            UpdateVisuals();
            LogDebug($"[UI_Item] Setup: {item.Data.DisplayName} at [{x},{y}] GridType={gridType}");
        }
        #endregion

        #region Visual Updates
        public void UpdateVisuals()
        {
            if (_item == null || _item.Data == null) return;

            if (_icon != null && _item.Data.Icon != null)
            {
                _icon.sprite = _item.Data.Icon;
                _icon.enabled = true;

                // FIX: Корректное отображение иконки при вращении предмета.
                // Мы вращаем только саму картинку вокруг её центра, а не весь контейнер предмета.
                if (_icon.rectTransform != null)
                {
                    _icon.rectTransform.localRotation = _item.IsRotated ? Quaternion.Euler(0, 0, -90f) : Quaternion.identity;

                    // Растягиваем иконку на весь доступный размер предмета с сохранением пропорций
                    _icon.rectTransform.anchorMin = Vector2.zero;
                    _icon.rectTransform.anchorMax = Vector2.one;
                    _icon.rectTransform.pivot = new Vector2(0.5f, 0.5f);
                    _icon.rectTransform.sizeDelta = Vector2.zero;
                    _icon.preserveAspect = true;
                }
            }
            else if (_icon != null)
            {
                _icon.enabled = false;
            }

            if (_quantityText != null && _quantityGroup != null)
            {
                if (_item.Quantity > 1)
                {
                    _quantityGroup.SetActive(true);
                    _quantityText.text = _item.Quantity.ToString();
                }
                else
                {
                    _quantityGroup.SetActive(false);
                }
            }
        }

        public void UpdateData(InventoryItem item)
        {
            _item = item;
            UpdateVisuals();
        }
        #endregion

        #region Pool Management
        public void ResetState()
        {
            _item = null;
            _inventoryUI = null;
            _gridType = GridType.Pockets;
            _gridX = 0;
            _gridY = 0;
            _isDragging = false;

            if (_icon != null)
            {
                _icon.sprite = null;
                _icon.enabled = false;
                if (_icon.rectTransform != null)
                {
                    _icon.rectTransform.localRotation = Quaternion.identity;
                }
            }
            if (_quantityGroup != null)
                _quantityGroup.SetActive(false);
            if (_canvasGroup != null)
            {
                _canvasGroup.interactable = false;
                _canvasGroup.blocksRaycasts = false;
                _canvasGroup.alpha = 1f;
            }
        }
        #endregion

        #region Drag & Drop
        public void OnBeginDrag(PointerEventData eventData)
        {
            if (_item == null || _inventoryUI == null) return;
            _isDragging = true;
            if (_canvasGroup != null) _canvasGroup.alpha = 0.5f;
            _inventoryUI.StartDrag(this, eventData);
            LogDebug($"[UI_Item] BeginDrag: {_item.Data.DisplayName}");
        }

        public void OnDrag(PointerEventData eventData)
        {
            _inventoryUI?.UpdateDragGhostPosition(eventData);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            _isDragging = false;
            if (_canvasGroup != null) _canvasGroup.alpha = 1f;
            _inventoryUI?.EndDragComplete();
            LogDebug($"[UI_Item] EndDrag: {_item?.Data.DisplayName ?? "NULL"}");
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            LogDebug($"[UI_Item] Click: {eventData.button}");
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            LogDebug($"[UI_Item] Hover: {_item?.Data.DisplayName}");
        }

        public void OnPointerExit(PointerEventData eventData) { }
        #endregion

        #region Debug Helpers
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs)
                Debug.Log(message);
        }
        #endregion
    }
}