﻿using UnityEngine;
using TMPro;
using System.Collections;
using K_Incident.Core.Inventory;

namespace K_Incident.Core
{
    /// <summary>
    /// Система взаимодействия с миром.
    /// Оптимизировано согласно ТЗ: "Минимум логики в Update", "Троттлинг 0.2-0.5с".
    /// </summary>
    public class K_InteractionSystem : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Interaction Settings")]
        [SerializeField, Tooltip("Радиус поиска интерактивных объектов от игрока (м)")]
        private float _interactionRange = 2.0f;

        [SerializeField, Tooltip("Клавиша взаимодействия")]
        private KeyCode _interactKey = KeyCode.E;

        [SerializeField, Tooltip("Слой, на котором находятся интерактивные объекты")]
        private LayerMask _interactableLayer;

        [Header("UI References")]
        [SerializeField] private TextMeshProUGUI _interactionPrompt;
        [SerializeField] private TextMeshProUGUI _holdProgressText;
        [SerializeField] private UnityEngine.Camera _playerCamera;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false; // ✅ По умолчанию выключено, чтобы не спамить
        [SerializeField] private bool _debugGizmos = true;

        #endregion

        #region Constants (ТЗ: "Никаких магических чисел")

        private const float SCAN_INTERVAL = 0.2f;
        private const float HOLD_PROGRESS_UPDATE_RATE = 0.05f;

        #endregion

        #region Fields

        private IInteractable _currentInteractable;
        private Transform _currentInteractableTransform;
        private Transform _playerTransform;
        private K_InventoryUI _cachedInventoryUI;

        private bool _isHolding;
        private float _holdTimer;
        private Coroutine _holdCoroutine;
        private bool _isDestroyed;
        private bool _ignoreInteractionUntilRelease = false;

        // Троттлинг сканирования (ТЗ: "Минимум логики в Update")
        private float _nextScanTime;
        private float _lastProgressUpdateTime;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _playerTransform = transform;
            _isDestroyed = false;
            _cachedInventoryUI = FindFirstObjectByType<K_InventoryUI>();
            _nextScanTime = 0f;
            _lastProgressUpdateTime = 0f;

            if (_playerCamera == null)
                _playerCamera = UnityEngine.Camera.main;

            if (_interactionPrompt != null)
                _interactionPrompt.gameObject.SetActive(false);

            if (_holdProgressText != null)
                _holdProgressText.gameObject.SetActive(false);

            LogDebug($"[InteractionSystem] Initialized. Range: {_interactionRange}m, Layer: {LayerMask.LayerToName(_interactableLayer.value)}");
        }

        private void Update()
        {
            if (IsInventoryOpen())
            {
                CancelHoldInteraction();
                HidePrompt();

                if (Input.GetKeyDown(_interactKey))
                {
                    _cachedInventoryUI?.CloseAll();
                    ResetTarget();
                    _ignoreInteractionUntilRelease = true;
                }
                return;
            }

            if (_ignoreInteractionUntilRelease)
            {
                if (Input.GetKeyUp(_interactKey))
                {
                    _ignoreInteractionUntilRelease = false;
                }
                return;
            }

            // ✅ ТРОТТЛИНГ: Проверка радиуса не каждый кадр, а раз в 0.2с
            if (Time.time >= _nextScanTime)
            {
                _nextScanTime = Time.time + SCAN_INTERVAL;
                CheckForNearbyInteractables();
            }

            HandleHoldInput();
        }

        private void OnDestroy()
        {
            _isDestroyed = true;
            if (_holdCoroutine != null)
            {
                StopCoroutine(_holdCoroutine);
                _holdCoroutine = null;
            }
        }

        #endregion

        #region Core Logic

        private bool IsInventoryOpen()
        {
            if (_cachedInventoryUI == null)
                _cachedInventoryUI = FindFirstObjectByType<K_InventoryUI>();

            return _cachedInventoryUI != null && _cachedInventoryUI.IsOpen;
        }

        private void CheckForNearbyInteractables()
        {
            Collider[] hits = Physics.OverlapSphere(
                _playerTransform.position,
                _interactionRange,
                _interactableLayer
            );

            if (hits.Length == 0)
            {
                if (_currentInteractable != null)
                    ResetTarget();
                return;
            }

            IInteractable bestTarget = null;
            Transform bestTransform = null;
            float closestSqrDist = float.MaxValue;

            foreach (var hit in hits)
            {
                if (hit.TryGetComponent(out IInteractable interactable))
                {
                    float dist = Vector3.Distance(_playerTransform.position, hit.transform.position);
                    if (dist > _interactionRange) continue;

                    float sqrDist = dist * dist;
                    if (sqrDist < closestSqrDist)
                    {
                        closestSqrDist = sqrDist;
                        bestTarget = interactable;
                        bestTransform = hit.transform;
                    }
                }
            }

            if (bestTarget != null)
            {
                if (_currentInteractable != bestTarget)
                {
                    LogDebug($"[InteractionSystem] Target CHANGED: {bestTransform?.gameObject.name}");
                    _currentInteractable = bestTarget;
                    _currentInteractableTransform = bestTransform;
                    ShowPrompt(_currentInteractable.GetHoldPrompt());
                }
            }
            else
            {
                if (_currentInteractable != null)
                    ResetTarget();
            }
        }

        private void HandleHoldInput()
        {
            if (_currentInteractable == null) return;

            float requiredHold = _currentInteractable.GetHoldDuration();

            if (Input.GetKey(_interactKey) && !_isHolding && _holdCoroutine == null)
            {
                if (requiredHold <= 0f)
                {
                    CompleteHoldInteraction();
                }
                else
                {
                    _holdCoroutine = StartCoroutine(HoldRoutine(requiredHold));
                }
            }
            else if (!Input.GetKey(_interactKey) && _isHolding)
            {
                CancelHoldInteraction();
            }
        }

        private IEnumerator HoldRoutine(float duration)
        {
            _isHolding = true;
            _holdTimer = 0f;
            _lastProgressUpdateTime = Time.time;
            HidePrompt();
            ShowHoldProgress(0f);

            while (_holdTimer < duration)
            {
                if (_isDestroyed || _currentInteractable == null || _currentInteractableTransform == null)
                {
                    CancelHoldInteraction();
                    yield break;
                }

                float currentSqrDist = Vector3.SqrMagnitude(_playerTransform.position - _currentInteractableTransform.position);
                if (currentSqrDist > _interactionRange * _interactionRange)
                {
                    CancelHoldInteraction();
                    yield break;
                }

                _holdTimer += Time.deltaTime;

                // ✅ Троттлинг обновления UI прогресса
                if (Time.time - _lastProgressUpdateTime >= HOLD_PROGRESS_UPDATE_RATE)
                {
                    ShowHoldProgress(_holdTimer / duration);
                    _lastProgressUpdateTime = Time.time;
                }

                yield return null;
            }

            CompleteHoldInteraction();
        }

        private void CompleteHoldInteraction()
        {
            _isHolding = false;
            _holdTimer = 0f;
            _holdCoroutine = null;
            HideHoldProgress();
            HidePrompt();

            if (_currentInteractable != null)
            {
                LogDebug($"[InteractionSystem] Interaction COMPLETED: {_currentInteractableTransform?.gameObject.name}");
                _currentInteractable.OnInteract();
            }

            ResetTarget();
        }

        private void CancelHoldInteraction()
        {
            _isHolding = false;
            _holdTimer = 0f;
            if (_holdCoroutine != null)
            {
                StopCoroutine(_holdCoroutine);
                _holdCoroutine = null;
            }
            HideHoldProgress();
            if (_currentInteractable != null)
                ShowPrompt(_currentInteractable.GetHoldPrompt());
        }

        private void ResetTarget()
        {
            if (_currentInteractable != null)
            {
                CancelHoldInteraction();
                _currentInteractable = null;
                _currentInteractableTransform = null;
                HidePrompt();
            }
        }

        #endregion

        #region UI Helpers

        private void ShowPrompt(string text)
        {
            if (_interactionPrompt != null && !string.IsNullOrEmpty(text))
            {
                _interactionPrompt.text = text;
                _interactionPrompt.gameObject.SetActive(true);
            }
        }

        private void HidePrompt()
        {
            if (_interactionPrompt != null && _interactionPrompt.gameObject.activeSelf)
                _interactionPrompt.gameObject.SetActive(false);
        }

        private void ShowHoldProgress(float normalizedValue)
        {
            if (_holdProgressText != null)
            {
                _holdProgressText.text = $"{Mathf.RoundToInt(normalizedValue * 100)}%";
                if (!_holdProgressText.gameObject.activeSelf)
                    _holdProgressText.gameObject.SetActive(true);
            }
        }

        private void HideHoldProgress()
        {
            if (_holdProgressText != null && _holdProgressText.gameObject.activeSelf)
                _holdProgressText.gameObject.SetActive(false);
        }

        #endregion

        #region Debug & Gizmos

        private void OnDrawGizmosSelected()
        {
            if (_debugGizmos)
            {
                Gizmos.color = new Color(1f, 0.84f, 0f, 0.4f);
                Gizmos.DrawWireSphere(transform.position, _interactionRange);

                if (_currentInteractableTransform != null)
                {
                    Gizmos.color = Color.green;
                    Gizmos.DrawLine(transform.position, _currentInteractableTransform.position);
                }
            }
        }

        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs)
                UnityEngine.Debug.Log(message);
        }

        #endregion
    }

    public interface IInteractable
    {
        void OnInteract();
        string GetInteractionPrompt();
        string GetHoldPrompt();
        float GetHoldDuration();
    }
}