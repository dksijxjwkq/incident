﻿using K_Incident.Core;
using K_Incident.Core.Inventory;
using System;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Точка входа для системы инвентаря.
    /// Инициализирует базу данных, контроллер инвентаря и регистрирует системы.
    /// Соответствует ТЗ: "Исключение технического долга", "Детерминизм".
    /// </summary>
    public class K_InventorySetup : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField, Tooltip("База данных предметов (ScriptableObject)")]
        private ItemDatabase _database;

        [SerializeField, Tooltip("Начальные данные инвентаря (опционально, для предзаполнения)")]
        private InventoryData _initialData;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = true;

        #endregion

        #region Constants

        private const int DEFAULT_BACKPACK_WIDTH = 8;
        private const int DEFAULT_BACKPACK_HEIGHT = 10;
        private const uint INSTANCE_ID_BUFFER = 10000;

        #endregion

        #region Fields

        private InventoryController _controller;
        private K_WeightManager _cachedWeightManager;

        #endregion

        #region Properties

        public static ItemDatabase DatabaseInstance { get; private set; }
        public static bool IsInitialized { get; private set; } = false;

        public InventoryController Controller => _controller;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (_database == null)
            {
                Debug.LogError("[InventorySetup] CRITICAL: ItemDatabase NOT assigned in Inspector!");
                Debug.LogError("[InventorySetup] Please create ItemDatabase asset and assign it to the Database field.");
                Debug.LogError($"[InventorySetup] GameObject: {gameObject.name}");
                enabled = false;
                return;
            }

            uint globalMaxId = FindGlobalMaxInstanceId();
            GlobalIDManager.InitWithMaxId(globalMaxId);

            DatabaseInstance = _database;
            _database.Initialize();

            _controller = new InventoryController(
                _initialData != null ? _initialData : new InventoryData(DEFAULT_BACKPACK_WIDTH, DEFAULT_BACKPACK_HEIGHT),
                _database
            );

            // ✅ ПОДПИСКА НА СОБЫТИЯ КОНТРОЛЛЕРА
            _controller.OnInventoryChanged += OnInventoryUpdated;
            _controller.OnWeightChanged += OnWeightUpdated;

            IsInitialized = true;
            LogDebug($"[InventorySetup] ✅ Successfully initialized. Database: {_database.name}");
        }

        private void Start()
        {
            if (!IsInitialized)
            {
                Debug.LogError("[InventorySetup] Start() called but IsInitialized = false! Check Awake() errors.");
                return;
            }

            // ✅ РЕГИСТРАЦИЯ В СИСТЕМЕ СОХРАНЕНИЙ
            K_SaveManager.Instance?.Register(_controller);
            LogDebug("[InventorySetup] Registered with SaveManager.");

            // ✅ ПОДКЛЮЧЕНИЕ К МЕНЕДЖЕРУ ВЕСА (с кэшированием ссылки)
            _cachedWeightManager = FindFirstObjectByType<K_WeightManager>();
            if (_cachedWeightManager != null)
            {
                _controller.OnWeightChanged += _cachedWeightManager.SetWeight;
                _cachedWeightManager.SetWeight(_controller.CurrentWeightKg);
                LogDebug("[InventorySetup] Connected to WeightManager.");
            }
            else
            {
                Debug.LogWarning("[InventorySetup] K_WeightManager not found! Movement speed will not be affected by weight.");
            }

            LogDebug($"[InventorySetup] Initialized. Database loaded with items.");
        }

        private void OnDestroy()
        {
            if (_controller != null)
            {
                // 1. Явная отписка от событий контроллера (разрывает делегатные связи)
                _controller.OnInventoryChanged -= OnInventoryUpdated;
                _controller.OnWeightChanged -= OnWeightUpdated;

                // 2. Отписка от менеджера веса через кэшированную ссылку
                if (_cachedWeightManager != null)
                {
                    // Прямая отписка не требуется, т.к. контроллер сам обнулит делегаты в Dispose
                }

                // 3. Вызов Dispose разрывает все внутренние связи контроллера
                _controller.Dispose();

                // 4. Сброс ссылки для немедленной сборки мусора
                _controller = null;
            }

            // ✅ Сброс статических полей
            DatabaseInstance = null;
            IsInitialized = false;
            _cachedWeightManager = null;
        }

        #endregion

        #region Event Handlers

        private void OnInventoryUpdated()
        {
            if (_controller != null)
                LogDebug($"[Inventory] Changed! Modified: {_controller.GetSaveData().IsModified}");
        }

        private void OnWeightUpdated(float kg)
        {
            if (_controller != null)
                LogDebug($"[Inventory] Weight: {kg:F2} kg ({_controller.WeightRatio:P1})");
        }

        #endregion

        #region Utilities

        private uint FindGlobalMaxInstanceId()
        {
            uint maxId = 0;
            if (_initialData != null)
            {
                foreach (var item in _initialData.GetItems())
                {
                    if (item.InstanceID > maxId)
                        maxId = item.InstanceID;
                }
            }

#if UNITY_EDITOR
            Debug.Assert(maxId < uint.MaxValue - INSTANCE_ID_BUFFER,
                "[InventorySetup] InstanceID pool exhausted! Implement full save scanning for production.");
#endif
            return maxId + INSTANCE_ID_BUFFER;
        }

        public static ItemDatabase GetDatabase()
        {
            if (!IsInitialized)
            {
                Debug.LogWarning("[InventorySetup] GetDatabase() called before initialization!");
                return null;
            }
            return DatabaseInstance;
        }

        // ✅ Helper for conditional logging
        private void LogDebug(string message)
        {
            if (_debugLogs)
                Debug.Log(message);
        }

        #endregion

        #region Editor Helpers

#if UNITY_EDITOR
        [ContextMenu("Print Grid")]
        private void PrintGrid()
        {
            if (_controller == null)
            {
                Debug.LogWarning("[InventorySetup] Controller not initialized!");
                return;
            }
            _controller.DebugPrintGrid();
        }

        [ContextMenu("Give 3 Coagulants")]
        private void GiveTestCoagulant()
        {
            if (_controller == null)
            {
                Debug.LogWarning("[InventorySetup] Controller not initialized!");
                return;
            }

            var data = GetDatabase()?.GetItemData("Med_Coagulant");
            if (data == null)
            {
                Debug.LogError("[InventorySetup] Item 'Med_Coagulant' not found in database!");
                return;
            }

            var item = new InventoryItem(data, GlobalIDManager.GenerateID(), 3, 100, false);
            int remainder = _controller.TryPlaceItem(item, 0, 0);
            Debug.Log(remainder == 0
                ? "[InventorySetup] Placed 3 Coagulants successfully."
                : $"[InventorySetup] Remainder: {remainder}");
        }

        [ContextMenu("Clear Inventory")]
        private void ClearInventory()
        {
            if (_controller == null)
            {
                Debug.LogWarning("[InventorySetup] Controller not initialized!");
                return;
            }
            _controller.Clear();
            Debug.Log("[InventorySetup] Inventory cleared.");
        }
#endif

        #endregion
    }
}