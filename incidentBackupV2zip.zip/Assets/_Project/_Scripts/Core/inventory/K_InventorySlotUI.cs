﻿using UnityEngine;
using UnityEngine.EventSystems;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Слот сетки инвентаря.
    /// Хранит координаты, тип сетки и обрабатывает завершение перетаскивания (Drop).
    /// Не содержит визуальной логики — только данные и событийный мост.
    /// </summary>
    public class K_InventorySlotUI : MonoBehaviour, IDropHandler
    {
        #region Fields
        private K_InventoryUI _inventoryUI;
        #endregion

        #region Properties
        public int X { get; private set; }
        public int Y { get; private set; }
        public GridType GridType { get; private set; }
        #endregion

        #region Initialization
        public void Setup(int x, int y, GridType gridType, K_InventoryUI inventoryUI)
        {
            X = x;
            Y = y;
            GridType = gridType;
            _inventoryUI = inventoryUI;
        }
        #endregion

        #region Event Handlers (Unity UI)
        /// <summary>
        /// IDropHandler — вызывается Unity EventSystem, когда пользователь отпускает
        /// перетаскиваемый объект над этим слотом.
        /// ✅ ИСПРАВЛЕНО: Добавлена поддержка дропа предмета из слота экипировки.
        /// </summary>
        public void OnDrop(PointerEventData eventData)
        {
            // 1. Игнорируем, если ничего не перетаскивали
            if (eventData.pointerDrag == null) return;

            // 2. Получаем компонент UI_Item с перетаскиваемого объекта
            var draggedUI = eventData.pointerDrag.GetComponent<UI_Item>();

            // 3. Проверяем, перетаскивается ли предмет из слота экипировки
            var inventoryUI = _inventoryUI;
            if (inventoryUI == null) return;

            // Случай A: Предмет из инвентаря (UI_Item)
            if (draggedUI != null && draggedUI.Item != null)
            {
                bool success = inventoryUI.TryPlaceItem(draggedUI, GridType, X, Y);
                if (!success)
                    Debug.Log($"[SlotUI] Placement rejected at [{X},{Y}] GridType={GridType}");
                return;
            }

            // Случай B: Предмет из слота экипировки
            if (inventoryUI.IsDraggingFromEquipmentSlot)
            {
                bool success = inventoryUI.TryPlaceItemFromEquipmentSlot(GridType, X, Y);
                if (success)
                {
                    inventoryUI.EndDragFromEquipmentSlot();
                }
                else
                {
                    Debug.Log($"[SlotUI] Equipment slot placement rejected at [{X},{Y}] GridType={GridType}");
                }
                return;
            }

            Debug.LogWarning($"[SlotUI] Drop failed: pointerDrag has no valid UI_Item and not dragging from equipment slot.");
        }
        #endregion
    }
}