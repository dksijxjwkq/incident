using System;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public enum ClothingSlotKind { Hat, Jacket, Pants, Footwear }

    public enum ClothingRegion
    {
        Head, Torso, LeftArm, RightArm, Pelvis, LeftLeg, RightLeg, LeftFoot, RightFoot
    }

    [Serializable]
    public sealed class ClothingDefinition
    {
        [Tooltip("Слот, в который надевается эта вещь.")]
        public ClothingSlotKind Slot;

        [Min(0f), Tooltip("Запас утепления закрытых областей. При пороге комфорта +5 и погоде −20 для полной защиты требуется 25. Повреждения уменьшают утепление только своей области.")]
        public float Insulation = 25f;

        [Tooltip("Шапку можно носить вместе со шлемом. Для объёмных головных уборов отключите.")]
        public bool AllowsHelmet = true;

        [Tooltip("Куртка совместима с бронежилетом, надетым под ней. Для несовместимой одежды отключите.")]
        public bool AllowsBodyArmor = true;

        [Min(0.01f), Tooltip("Суммарный физический урон, разрушающий одну целую область ткани. Применяется после множителя источника повреждения. Нулевая сохранность оставляет вещь в слоте.")]
        public float DamageCapacity = 100f;

        public bool Covers(ClothingRegion region)
        {
            switch (Slot)
            {
                case ClothingSlotKind.Hat: return region == ClothingRegion.Head;
                case ClothingSlotKind.Jacket:
                    return region == ClothingRegion.Torso || region == ClothingRegion.LeftArm || region == ClothingRegion.RightArm;
                case ClothingSlotKind.Pants:
                    return region == ClothingRegion.Pelvis || region == ClothingRegion.LeftLeg || region == ClothingRegion.RightLeg;
                case ClothingSlotKind.Footwear:
                    return region == ClothingRegion.LeftFoot || region == ClothingRegion.RightFoot;
                default: return false;
            }
        }
    }
}
