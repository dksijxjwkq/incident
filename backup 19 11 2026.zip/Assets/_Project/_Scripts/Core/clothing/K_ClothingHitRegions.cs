using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Coarse body regions for the temporary capsule. Explicit anatomical hitboxes take priority.</summary>
    [DisallowMultipleComponent]
    [AddComponentMenu("INCIDENT/Области попаданий капсулы персонажа")]
    public sealed class K_ClothingHitRegions : MonoBehaviour
    {
        [SerializeField, Range(0f, 1f), Tooltip("Верхняя граница стоп по высоте капсулы. Левая и правая стороны различаются в локальных координатах персонажа.")]
        float _feetEnd = .12f;
        [SerializeField, Range(0f, 1f), Tooltip("Верхняя граница голеней по высоте капсулы.")]
        float _shinEnd = .29f;
        [SerializeField, Range(0f, 1f), Tooltip("Верхняя граница коленей по высоте капсулы.")]
        float _kneeEnd = .36f;
        [SerializeField, Range(0f, 1f), Tooltip("Верхняя граница бёдер по высоте капсулы.")]
        float _thighEnd = .50f;
        [SerializeField, Range(0f, 1f), Tooltip("Верхняя граница таза по высоте капсулы.")]
        float _pelvisEnd = .60f;
        [SerializeField, Range(0f, 1f), Tooltip("Верхняя граница живота по высоте капсулы.")]
        float _stomachEnd = .73f;
        [SerializeField, Range(0f, 1f), Tooltip("Нижняя граница головы по высоте капсулы.")]
        float _headStart = .86f;
        [SerializeField, Range(0f, 1f), Tooltip("Боковая часть верхней половины капсулы, относимая к руке. Это приближение для временного персонажа без модели; сегментные K_DamageHitbox имеют приоритет.")]
        float _armSide = .70f;

        public BodyPart Resolve(Collider collider, Vector3 point)
        {
            if (collider == null) return BodyPart.Chest;
            var capsule = collider as CapsuleCollider;
            var controller = collider as CharacterController;
            Vector3 local = transform.InverseTransformPoint(point);
            float height, center, radius;
            if (capsule != null && capsule.transform == transform && capsule.direction == 1)
            { height = capsule.height; center = capsule.center.y; radius = capsule.radius; }
            else if (controller != null && controller.transform == transform)
            { height = controller.height; center = controller.center.y; radius = controller.radius; }
            else
            {
                float scale = Mathf.Max(.0001f, Mathf.Abs(transform.lossyScale.y));
                height = collider.bounds.size.y / scale;
                center = transform.InverseTransformPoint(collider.bounds.center).y;
                radius = height * .25f;
            }
            float y = Mathf.Clamp01((local.y - center + height * .5f) / Mathf.Max(.0001f, height));
            bool left = local.x < 0f;
            if (y < _feetEnd) return left ? BodyPart.LeftFoot : BodyPart.RightFoot;
            if (y < _shinEnd) return left ? BodyPart.LeftShin : BodyPart.RightShin;
            if (y < _kneeEnd) return left ? BodyPart.LeftKnee : BodyPart.RightKnee;
            if (y < _thighEnd) return left ? BodyPart.LeftQuadriceps : BodyPart.RightQuadriceps;
            if (y >= _headStart) return BodyPart.Head;
            if (y >= _pelvisEnd && Mathf.Abs(local.x) >= radius * _armSide)
            {
                if (y >= .78f) return left ? BodyPart.LeftShoulder : BodyPart.RightShoulder;
                if (y >= .69f) return left ? BodyPart.LeftBiceps : BodyPart.RightBiceps;
                return left ? BodyPart.LeftForearm : BodyPart.RightForearm;
            }
            if (y < _pelvisEnd) return BodyPart.Pelvis;
            if (y < _stomachEnd) return BodyPart.Stomach;
            return BodyPart.Chest;
        }
    }
}
