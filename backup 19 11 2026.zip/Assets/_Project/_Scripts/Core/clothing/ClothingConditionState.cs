using System;

namespace K_Incident.Core.Inventory
{
    [Serializable]
    public sealed class ClothingConditionRecord
    {
        public uint InstanceID;
        public string ItemID;
        public float[] Regions;
    }

    public sealed class ClothingConditionState
    {
        public const int RegionCount = 9;
        readonly float[] _regions;

        public uint InstanceID { get; }
        public string ItemID { get; }

        public ClothingConditionState(uint instanceID, string itemID)
        {
            ValidateIdentity(instanceID, itemID);
            InstanceID = instanceID;
            ItemID = itemID;
            _regions = new float[RegionCount];
            for (int i = 0; i < _regions.Length; i++) _regions[i] = 1f;
        }

        public ClothingConditionState(ClothingConditionRecord record)
        {
            ValidateRecord(record);
            InstanceID = record.InstanceID;
            ItemID = record.ItemID;
            _regions = (float[])record.Regions.Clone();
        }

        public float Get(ClothingRegion region) => _regions[RegionIndex(region)];

        public bool ApplyDamage(ClothingRegion region, float normalizedDamage)
        {
            if (!Finite(normalizedDamage) || normalizedDamage < 0f)
                throw new ArgumentOutOfRangeException(nameof(normalizedDamage));
            int index = RegionIndex(region);
            float next = Math.Max(0f, _regions[index] - normalizedDamage);
            if (next == _regions[index]) return false;
            _regions[index] = next;
            return true;
        }

        public ClothingConditionRecord Export() => new ClothingConditionRecord
        {
            InstanceID = InstanceID, ItemID = ItemID, Regions = (float[])_regions.Clone()
        };

        public static void ValidateRecord(ClothingConditionRecord record)
        {
            if (record == null) throw new ArgumentNullException(nameof(record));
            ValidateIdentity(record.InstanceID, record.ItemID);
            if (record.Regions == null || record.Regions.Length != RegionCount)
                throw new ArgumentException("Clothing condition requires nine regions.", nameof(record));
            foreach (float condition in record.Regions)
                if (!Finite(condition) || condition < 0f || condition > 1f)
                    throw new ArgumentException("Clothing condition must be finite and between zero and one.", nameof(record));
        }

        static void ValidateIdentity(uint instanceID, string itemID)
        {
            if (instanceID == 0 || instanceID == uint.MaxValue) throw new ArgumentOutOfRangeException(nameof(instanceID));
            if (string.IsNullOrWhiteSpace(itemID)) throw new ArgumentException("A clothing item ID is required.", nameof(itemID));
        }

        public static int RegionIndex(ClothingRegion region)
        {
            int index = (int)region;
            if (index < 0 || index >= RegionCount) throw new ArgumentOutOfRangeException(nameof(region));
            return index;
        }

        public static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }

    public static class ClothingThermalModel
    {
        public static float TemperatureDemand(float comfortTemperature, float ambientTemperature, float thresholdOffset = 0f)
        {
            if (!ClothingConditionState.Finite(comfortTemperature) || !ClothingConditionState.Finite(ambientTemperature) ||
                !ClothingConditionState.Finite(thresholdOffset))
                throw new ArgumentOutOfRangeException(nameof(ambientTemperature));
            return (float)Math.Min(float.MaxValue, Math.Max(0d, (double)comfortTemperature - thresholdOffset - ambientTemperature));
        }

        public static float RegionDeficit(float demand, float insulation, float condition)
        {
            if (!ClothingConditionState.Finite(demand) || demand < 0f ||
                !ClothingConditionState.Finite(insulation) || insulation < 0f ||
                !ClothingConditionState.Finite(condition) || condition < 0f || condition > 1f)
                throw new ArgumentOutOfRangeException(nameof(condition));
            return Math.Max(0f, demand - insulation * condition);
        }

        public static float Protection(float demand, float deficit)
        {
            if (!ClothingConditionState.Finite(demand) || demand < 0f ||
                !ClothingConditionState.Finite(deficit) || deficit < 0f)
                throw new ArgumentOutOfRangeException(nameof(deficit));
            return demand <= 0f ? 1f : Math.Max(0f, Math.Min(1f, 1f - deficit / demand));
        }
    }
}
