using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using BodyPart = K_Incident.Core.BodyPart;

namespace K_Incident.Core.Inventory
{
    [DisallowMultipleComponent]
    [AddComponentMenu("INCIDENT/Одежда и теплозащита")]
    public sealed class K_ClothingSystem : MonoBehaviour
    {
        [SerializeField, Tooltip("Инвентарь с четырьмя слотами одежды. Система работает на персонаже независимо от открытой вкладки.")]
        K_InventoryUI _inventory;
        [SerializeField, Tooltip("Система здоровья, передающая принятые физические повреждения.")]
        K_HealthSystem _health;
        [SerializeField, Tooltip("Показатели персонажа и текущая температура окружающей среды.")]
        K_VitalitySystem _vitality;
        [SerializeField, Tooltip("Температура, при которой персонажу без одежды достаточно тепло. Ниже неё одежда перекрывает недостаток утеплением.")]
        float _bareComfortTemperature = 5f;
        [SerializeField, Min(0f), Tooltip("Относительный вклад головы в общие потери тепла.")]
        float _headWeight = .12f;
        [SerializeField, Min(0f), Tooltip("Относительный вклад торса и рук в общие потери тепла.")]
        float _jacketWeight = .48f;
        [SerializeField, Min(0f), Tooltip("Относительный вклад таза и ног в общие потери тепла.")]
        float _pantsWeight = .25f;
        [SerializeField, Min(0f), Tooltip("Относительный вклад стоп в общие потери тепла.")]
        float _footwearWeight = .15f;
        [SerializeField, Min(0f), Tooltip("Множитель износа ткани от попадания. Куртка поверх бронежилета повреждается до снижения урона бронёй; шапка под шлемом — по прошедшему урону.")]
        float _firearmWearMultiplier = 1f;
        [SerializeField, Min(0f), Tooltip("Множитель износа ткани от обычного физического повреждения по этой области.")]
        float _physicalWearMultiplier = .4f;
        [SerializeField, Min(0f), Tooltip("Множитель износа ткани от повреждения при падении по этой области.")]
        float _fallWearMultiplier = .25f;

        readonly Dictionary<uint, ClothingConditionState> _conditions = new Dictionary<uint, ClothingConditionState>();
        readonly List<K_EquipmentSlotUI> _subscribedSlots = new List<K_EquipmentSlotUI>(4);
        readonly InventoryItem[] _equipped = new InventoryItem[4];
        readonly Stack<ProjectileImpactScope> _projectileImpacts = new Stack<ProjectileImpactScope>();
        K_HealthSystem _subscribedHealth;
        float _lastProtection = -1f;
        float _nextReferenceSearch;

        readonly struct ProjectileImpactScope
        {
            public readonly BodyPart Part;
            public readonly bool UsesRawDamage;
            public ProjectileImpactScope(BodyPart part, bool usesRawDamage)
            {
                Part = part;
                UsesRawDamage = usesRawDamage;
            }
        }

        public event Action OnChanged;
        public float BareComfortTemperature => SafeFinite(_bareComfortTemperature, 5f);
        public float Protection01
        {
            get
            {
                float temperature = _vitality != null ? _vitality.CurrentTemperature : BareComfortTemperature;
                float demand = ClothingThermalModel.TemperatureDemand(BareComfortTemperature, SafeFinite(temperature, BareComfortTemperature));
                return ClothingThermalModel.Protection(demand, GetTemperatureDeficit(temperature));
            }
        }

        void Awake() => EnsureReferences();
        void OnEnable()
        {
            EnsureReferences();
            RefreshEquipment();
            PublishProtection(true);
        }

        void Update()
        {
            EnsureReferences();
            bool equipmentChanged = RefreshEquipment();
            PublishProtection(equipmentChanged);
        }

        void OnDisable()
        {
            if (_subscribedHealth != null) _subscribedHealth.OnSegmentDamageApplied -= OnPhysicalDamage;
            _subscribedHealth = null;
            foreach (var slot in _subscribedSlots)
                if (slot != null) slot.OnEquipmentChanged -= OnEquipmentChanged;
            _subscribedSlots.Clear();
            if (_health != null && _health.Illnesses != null) _health.Illnesses.SetColdProtection01(0f);
        }

        void EnsureReferences()
        {
            if (_health == null) _health = GetComponent<K_HealthSystem>();
            if (_vitality == null) _vitality = GetComponent<K_VitalitySystem>();
            if (_inventory == null && Time.unscaledTime >= _nextReferenceSearch)
            {
                _nextReferenceSearch = Time.unscaledTime + .25f;
                _inventory = UnityEngine.Object.FindFirstObjectByType<K_InventoryUI>(FindObjectsInactive.Include);
            }
            if (!isActiveAndEnabled || _subscribedHealth == _health) return;
            if (_subscribedHealth != null) _subscribedHealth.OnSegmentDamageApplied -= OnPhysicalDamage;
            _subscribedHealth = _health;
            if (_subscribedHealth != null && isActiveAndEnabled)
                _subscribedHealth.OnSegmentDamageApplied += OnPhysicalDamage;
        }

        bool RefreshEquipment()
        {
            bool changed = false;
            for (int i = 0; i < _equipped.Length; i++)
            {
                var kind = (ClothingSlotKind)i;
                var item = _inventory != null ? _inventory.GetClothingItem(kind) : null;
                if (!ReferenceEquals(_equipped[i], item)) { _equipped[i] = item; changed = true; }
                var slot = _inventory != null ? _inventory.GetClothingSlot(kind) : null;
                if (slot != null && !_subscribedSlots.Contains(slot))
                {
                    slot.OnEquipmentChanged += OnEquipmentChanged;
                    _subscribedSlots.Add(slot);
                }
            }
            for (int i = _subscribedSlots.Count - 1; i >= 0; i--)
            {
                var slot = _subscribedSlots[i];
                if (slot != null && _inventory != null && _inventory.ClothingSlots.Contains(slot)) continue;
                if (slot != null) slot.OnEquipmentChanged -= OnEquipmentChanged;
                _subscribedSlots.RemoveAt(i);
            }
            return changed;
        }

        void OnEquipmentChanged(K_EquipmentSlotUI slot, InventoryItem previous, InventoryItem current)
        {
            RefreshEquipment();
            PublishProtection(true);
        }

        void PublishProtection(bool force)
        {
            float protection = Protection01;
            if (_health != null && _health.Illnesses != null) _health.Illnesses.SetColdProtection01(protection);
            if (!force && Mathf.Abs(protection - _lastProtection) < .0001f) return;
            _lastProtection = protection;
            OnChanged?.Invoke();
        }

        public float GetTemperatureDeficit(float ambientTemperature, float thresholdOffset = 0f)
        {
            float demand = ClothingThermalModel.TemperatureDemand(BareComfortTemperature,
                SafeFinite(ambientTemperature, BareComfortTemperature), SafeFinite(thresholdOffset, 0f));
            if (demand <= 0f) return 0f;
            float head = Weight(_headWeight), jacket = Weight(_jacketWeight);
            float pants = Weight(_pantsWeight), footwear = Weight(_footwearWeight);
            float total = head + jacket + pants + footwear;
            if (total <= 0f) { head = .12f; jacket = .48f; pants = .25f; footwear = .15f; total = 1f; }
            return (head * RegionDeficit(ClothingRegion.Head, demand) +
                jacket * (.5f * RegionDeficit(ClothingRegion.Torso, demand) +
                    .25f * RegionDeficit(ClothingRegion.LeftArm, demand) + .25f * RegionDeficit(ClothingRegion.RightArm, demand)) +
                pants * (.2f * RegionDeficit(ClothingRegion.Pelvis, demand) +
                    .4f * RegionDeficit(ClothingRegion.LeftLeg, demand) + .4f * RegionDeficit(ClothingRegion.RightLeg, demand)) +
                footwear * (.5f * RegionDeficit(ClothingRegion.LeftFoot, demand) +
                    .5f * RegionDeficit(ClothingRegion.RightFoot, demand))) / total;
        }

        float RegionDeficit(ClothingRegion region, float demand)
        {
            var item = EquippedItem(SlotForRegion(region));
            float insulation = IsClothing(item) ? Weight(item.Data.Clothing.Insulation) : 0f;
            return ClothingThermalModel.RegionDeficit(demand, insulation, GetRegionCondition(item, region));
        }

        public float GetRegionInsulation(ClothingRegion region)
        {
            var item = EquippedItem(SlotForRegion(region));
            return IsClothing(item) ? Weight(item.Data.Clothing.Insulation) * GetRegionCondition(item, region) : 0f;
        }

        InventoryItem EquippedItem(ClothingSlotKind kind)
        {
            var item = _inventory != null ? _inventory.GetClothingItem(kind) : null;
            return IsClothing(item) && item.Data.Clothing.Slot == kind ? item : null;
        }

        public float GetRegionCondition(InventoryItem item, ClothingRegion region)
        {
            ClothingConditionState.RegionIndex(region);
            if (!IsClothing(item) || !item.Data.Clothing.Covers(region)) return 0f;
            if (_conditions.TryGetValue(item.InstanceID, out var state) &&
                string.Equals(state.ItemID, item.Data.ItemID, StringComparison.Ordinal)) return state.Get(region);
            return 1f;
        }

        public float GetItemCondition01(InventoryItem item)
        {
            if (!IsClothing(item)) return 0f;
            float total = 0f;
            int count = 0;
            for (int i = 0; i < ClothingConditionState.RegionCount; i++)
            {
                var region = (ClothingRegion)i;
                if (!item.Data.Clothing.Covers(region)) continue;
                total += GetRegionCondition(item, region);
                count++;
            }
            return count > 0 ? total / count : 0f;
        }

        ClothingConditionState GetOrCreateCondition(InventoryItem item)
        {
            if (_conditions.TryGetValue(item.InstanceID, out var state))
            {
                if (!string.Equals(state.ItemID, item.Data.ItemID, StringComparison.Ordinal))
                    throw new InvalidOperationException("A clothing InstanceID belongs to another item definition.");
                return state;
            }
            state = new ClothingConditionState(item.InstanceID, item.Data.ItemID);
            _conditions.Add(item.InstanceID, state);
            return state;
        }

        void OnPhysicalDamage(BodyPart part, float damage, DamageType source)
        {
            if (source == DamageType.Firearm && _projectileImpacts.Count > 0)
            {
                var impact = _projectileImpacts.Peek();
                if (impact.Part == part && impact.UsesRawDamage) return;
            }
            float multiplier;
            switch (source)
            {
                case DamageType.Firearm: multiplier = Weight(_firearmWearMultiplier); break;
                case DamageType.Generic: multiplier = Weight(_physicalWearMultiplier); break;
                case DamageType.Fall: multiplier = Weight(_fallWearMultiplier); break;
                default: return;
            }
            ApplyClothingDamage(part, damage, multiplier);
        }

        public void BeginProjectileImpact(BodyPart part, float rawDamage, bool clothingOutsideArmor = true)
        {
            if ((int)part < 0 || (int)part >= 20) throw new ArgumentOutOfRangeException(nameof(part));
            if (!ClothingConditionState.Finite(rawDamage) || rawDamage < 0f)
                throw new ArgumentOutOfRangeException(nameof(rawDamage));
            _projectileImpacts.Push(new ProjectileImpactScope(part, clothingOutsideArmor));
            try
            {
                if (clothingOutsideArmor && isActiveAndEnabled)
                    ApplyClothingDamage(part, rawDamage, Weight(_firearmWearMultiplier));
            }
            catch
            {
                _projectileImpacts.Pop();
                throw;
            }
        }

        public void EndProjectileImpact()
        {
            if (_projectileImpacts.Count == 0) throw new InvalidOperationException("No clothing projectile impact is active.");
            _projectileImpacts.Pop();
        }

        void ApplyClothingDamage(BodyPart part, float damage, float multiplier)
        {
            if (!ClothingConditionState.Finite(damage) || damage <= 0f || multiplier <= 0f ||
                part == BodyPart.LeftHand || part == BodyPart.RightHand || !TryGetRegion(part, out var region)) return;
            var item = EquippedItem(SlotForRegion(region));
            if (!IsClothing(item)) return;
            float capacity = item.Data.Clothing.DamageCapacity;
            if (!ClothingConditionState.Finite(capacity) || capacity <= 0f) capacity = 100f;
            float normalizedDamage = (float)Math.Min(1d, (double)damage * multiplier / capacity);
            if (GetOrCreateCondition(item).ApplyDamage(region, normalizedDamage)) PublishProtection(true);
        }

        public float GetColdDamageWeightMultiplier(BodyPart part)
        {
            if (!TryGetRegion(part, out var region)) return 1f;
            float temperature = _vitality != null ? _vitality.CurrentTemperature : BareComfortTemperature;
            float demand = ClothingThermalModel.TemperatureDemand(BareComfortTemperature, SafeFinite(temperature, BareComfortTemperature));
            return demand <= 0f ? 0f : Mathf.Clamp01(RegionDeficit(region, demand) / demand);
        }

        public bool TryGetConditionRecord(uint instanceID, out ClothingConditionRecord record)
        {
            if (_conditions.TryGetValue(instanceID, out var state)) { record = state.Export(); return true; }
            record = null;
            return false;
        }

        public bool TryGetCondition(uint instanceID, out ClothingConditionRecord record)
            => TryGetConditionRecord(instanceID, out record);

        public ClothingConditionRecord[] ExportConditionRecords()
            => _conditions.OrderBy(pair => pair.Key).Select(pair => pair.Value.Export()).ToArray();

        public static void ValidateConditionRecords(IEnumerable<ClothingConditionRecord> records)
        {
            if (records == null) throw new ArgumentNullException(nameof(records));
            var identities = new HashSet<uint>();
            foreach (var record in records)
            {
                ClothingConditionState.ValidateRecord(record);
                if (!identities.Add(record.InstanceID)) throw new ArgumentException("Duplicate clothing InstanceID.", nameof(records));
            }
        }

        public void ImportConditionRecords(IEnumerable<ClothingConditionRecord> records)
        {
            if (records == null) throw new ArgumentNullException(nameof(records));
            var incoming = records.ToArray();
            ValidateConditionRecords(incoming);
            var replacement = incoming.ToDictionary(record => record.InstanceID, record => new ClothingConditionState(record));
            _conditions.Clear();
            foreach (var pair in replacement) _conditions.Add(pair.Key, pair.Value);
            PublishProtection(true);
        }

        public void ClearConditionRecords()
        {
            _conditions.Clear();
            PublishProtection(true);
        }

        public static ClothingSlotKind SlotForRegion(ClothingRegion region)
        {
            ClothingConditionState.RegionIndex(region);
            if (region == ClothingRegion.Head) return ClothingSlotKind.Hat;
            if ((int)region <= (int)ClothingRegion.RightArm) return ClothingSlotKind.Jacket;
            if ((int)region <= (int)ClothingRegion.RightLeg) return ClothingSlotKind.Pants;
            return ClothingSlotKind.Footwear;
        }

        public static bool TryGetRegion(BodyPart part, out ClothingRegion region)
        {
            switch (part)
            {
                case BodyPart.Head: region = ClothingRegion.Head; return true;
                case BodyPart.Chest:
                case BodyPart.Stomach: region = ClothingRegion.Torso; return true;
                case BodyPart.LeftShoulder:
                case BodyPart.LeftBiceps:
                case BodyPart.LeftForearm:
                case BodyPart.LeftHand: region = ClothingRegion.LeftArm; return true;
                case BodyPart.RightShoulder:
                case BodyPart.RightBiceps:
                case BodyPart.RightForearm:
                case BodyPart.RightHand: region = ClothingRegion.RightArm; return true;
                case BodyPart.Pelvis: region = ClothingRegion.Pelvis; return true;
                case BodyPart.LeftQuadriceps:
                case BodyPart.LeftKnee:
                case BodyPart.LeftShin: region = ClothingRegion.LeftLeg; return true;
                case BodyPart.RightQuadriceps:
                case BodyPart.RightKnee:
                case BodyPart.RightShin: region = ClothingRegion.RightLeg; return true;
                case BodyPart.LeftFoot: region = ClothingRegion.LeftFoot; return true;
                case BodyPart.RightFoot: region = ClothingRegion.RightFoot; return true;
                default: region = default; return false;
            }
        }

        static bool IsClothing(InventoryItem item) => item?.Data != null && item.Type == ItemType.Clothing && item.Data.Clothing != null;
        static float Weight(float value) => ClothingConditionState.Finite(value) ? Mathf.Max(0f, value) : 0f;
        static float SafeFinite(float value, float fallback) => ClothingConditionState.Finite(value) ? value : fallback;
    }
}
