namespace K_Incident.Core.Combat
{
    public interface IShotWorld
    {
        /// <summary>Returns the first non-shooter collider along the normalized ray.</summary>
        bool Raycast(ShotRay ray, float maxDistance, out ShotHit hit);
    }

    /// <summary>Optional cosmetic projection from an authored segment hitbox into its front-view rectangle.</summary>
    public readonly struct ShotAnatomyLocation
    {
        public readonly float X01;
        public readonly float Y01;
        public readonly bool IsBack;
        public readonly bool HasExactPosition;

        public ShotAnatomyLocation(float x01, float y01, bool isBack)
        {
            DamageValidation.Probability(x01, nameof(x01));
            DamageValidation.Probability(y01, nameof(y01));
            X01 = x01;
            Y01 = y01;
            IsBack = isBack;
            HasExactPosition = true;
        }
    }

    /// <summary>Optional presentation data receiver. Recording an impact never changes its damage or treatment.</summary>
    public interface IAnatomicalWoundReceiver
    {
        void RecordGunshotImpact(BodyPart part, ShotAnatomyLocation location);
    }

    public readonly struct ShotHit
    {
        public readonly ShotVector Point;
        public readonly float Distance;
        public readonly object CollisionIdentity;
        public readonly IDamageReceiver Receiver;
        public readonly BodyPart Part;
        public readonly ArmorState Armor;
        public readonly bool BlocksBarrel;
        public readonly ShotAnatomyLocation AnatomyLocation;

        public ShotHit(ShotVector point, float distance, object collisionIdentity,
            IDamageReceiver receiver = null, BodyPart part = BodyPart.Chest, ArmorState armor = null,
            bool blocksBarrel = true, ShotAnatomyLocation anatomyLocation = default)
        {
            DamageValidation.NonNegative(distance, nameof(distance));
            DamageValidation.PartIndex(part);
            Point = point; Distance = distance; CollisionIdentity = collisionIdentity;
            Receiver = receiver; Part = part; Armor = armor; BlocksBarrel = blocksBarrel;
            AnatomyLocation = anatomyLocation;
        }
    }

    public enum ShotBlockReason { None = 0, WallAvoidance = 1, MuzzleObstructed = 2 }

    public readonly struct ShotAimResult
    {
        public readonly ShotBlockReason BlockReason;
        public readonly ShotRay MuzzleRay;
        public readonly ShotVector TargetPoint;
        public bool IsBlocked => BlockReason != ShotBlockReason.None;
        public ShotAimResult(ShotBlockReason reason, ShotRay muzzleRay, ShotVector targetPoint)
        { BlockReason = reason; MuzzleRay = muzzleRay; TargetPoint = targetPoint; }
    }

    public enum ShotOutcome { None = 0, Fired = 1, DryClick = 2, Safe = 3, AimBlocked = 4, Cooldown = 5 }

    public readonly struct ShotResult
    {
        public readonly ShotOutcome Outcome;
        public readonly AmmoRound Round;
        public readonly int PelletCount;
        public readonly int HitCount;
        public readonly ShotBlockReason BlockReason;
        public bool Fired => Outcome == ShotOutcome.Fired;
        public float NoiseRadius => Outcome == ShotOutcome.DryClick ? 3f : 0f;
        public ShotResult(ShotOutcome outcome, AmmoRound round = null, int pelletCount = 0,
            int hitCount = 0, ShotBlockReason blockReason = ShotBlockReason.None)
        { Outcome = outcome; Round = round; PelletCount = pelletCount; HitCount = hitCount; BlockReason = blockReason; }
    }
}
