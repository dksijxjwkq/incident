using System;
using UnityEngine;

namespace K_Incident.Core.Combat
{
    /// <summary>Authorable collider segment marker. A future NPC owner can bind its plain receiver.</summary>
    public sealed class K_DamageHitbox : MonoBehaviour
    {
        [SerializeField, Tooltip("Участок тела, которому принадлежит этот коллайдер попаданий.")]
        private BodyPart _part = BodyPart.Chest;
        [SerializeField, Tooltip("Сохранять точку ранения для анатомической схемы. Локальные оси объекта должны соответствовать телу: X — вправо персонажа, Y — вверх, Z — вперёд. Координаты нормализуются по границам коллайдера.")]
        private bool _projectAnatomicalImpacts = true;
        private Func<BodyPart, ArmorState> _armor;
        public BodyPart Part => _part;
        public IDamageReceiver Receiver { get; private set; }

        public void Bind(IDamageReceiver receiver, Func<BodyPart, ArmorState> armor = null)
        {
            if (Receiver != null) Receiver.OnDeath -= RevealArmor;
            Receiver = receiver;
            _armor = armor;
            if (Receiver != null)
            {
                Receiver.OnDeath += RevealArmor;
                if (Receiver.IsDead) RevealArmor();
            }
        }

        public ArmorState GetArmor() => _armor?.Invoke(_part);

        public bool TryProjectAnatomicalPoint(Collider collider, Vector3 worldPoint, out ShotAnatomyLocation location)
        {
            location = default;
            if (!_projectAnatomicalImpacts || collider == null || !TryLocalBounds(collider, out Bounds colliderBounds))
                return false;
            // Collider axes may differ from the authored body-facing marker axes.
            Vector3 minimum = colliderBounds.min;
            Vector3 maximum = colliderBounds.max;
            var projected = new Bounds();
            for (int corner = 0; corner < 8; corner++)
            {
                var localCorner = new Vector3((corner & 1) == 0 ? minimum.x : maximum.x,
                    (corner & 2) == 0 ? minimum.y : maximum.y,
                    (corner & 4) == 0 ? minimum.z : maximum.z);
                Vector3 point = transform.InverseTransformPoint(collider.transform.TransformPoint(localCorner));
                if (corner == 0) projected = new Bounds(point, Vector3.zero);
                else projected.Encapsulate(point);
            }
            Vector3 size = projected.size;
            if (size.x <= .00001f || size.y <= .00001f || size.z <= .00001f) return false;
            Vector3 localPoint = transform.InverseTransformPoint(worldPoint);
            // The character's anatomical right is on the left of a front-view drawing.
            float x = 1f - Mathf.InverseLerp(projected.min.x, projected.max.x, localPoint.x);
            float y = Mathf.InverseLerp(projected.min.y, projected.max.y, localPoint.y);
            location = new ShotAnatomyLocation(x, y, localPoint.z < projected.center.z);
            return true;
        }

        private static bool TryLocalBounds(Collider collider, out Bounds bounds)
        {
            switch (collider)
            {
                case BoxCollider box:
                    bounds = new Bounds(box.center, box.size);
                    return true;
                case CapsuleCollider capsule:
                    var size = Vector3.one * (2f * capsule.radius);
                    size[capsule.direction] = Mathf.Max(capsule.height, 2f * capsule.radius);
                    bounds = new Bounds(capsule.center, size);
                    return true;
                case SphereCollider sphere:
                    bounds = new Bounds(sphere.center, Vector3.one * (2f * sphere.radius));
                    return true;
                case CharacterController character:
                    bounds = new Bounds(character.center,
                        new Vector3(character.radius * 2f, Mathf.Max(character.height, character.radius * 2f), character.radius * 2f));
                    return true;
                case MeshCollider mesh when mesh.sharedMesh != null:
                    bounds = mesh.sharedMesh.bounds;
                    return true;
                default:
                    bounds = default;
                    return false;
            }
        }

        private void RevealArmor()
        {
            _armor?.Invoke(BodyPart.Head)?.RevealCondition();
            _armor?.Invoke(BodyPart.Chest)?.RevealCondition();
            _armor?.Invoke(BodyPart.Stomach)?.RevealCondition();
        }

        private void OnDestroy()
        {
            if (Receiver != null) Receiver.OnDeath -= RevealArmor;
        }
    }
}
