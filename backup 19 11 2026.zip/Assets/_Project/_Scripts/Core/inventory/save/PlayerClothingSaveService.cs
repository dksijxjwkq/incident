using System;
using System.Collections.Generic;
using System.IO;
using K_Incident.Core.Inventory;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>Optional V10 section for worn clothing and local fabric condition.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(K_ClothingSystem))]
    public sealed class PlayerClothingSaveService : MonoBehaviour, ISaveable, IPreSave, IPreLoad,
        IPostLoad, ISavePayloadValidator
    {
        [SerializeField, Tooltip("Инвентарь персонажа с четырьмя слотами одежды.")]
        private K_InventoryUI _inventoryUI;
        [SerializeField, Tooltip("Система одежды, хранящая независимое состояние участков вещей.")]
        private K_ClothingSystem _clothingSystem;

        private K_SaveManager _registeredSaveManager;
        private InventoryItem[] _pendingEquipment;

        public string SaveID => "Player_Clothing";
        public bool IsDirty { get; set; } = true;

        private void OnEnable()
        {
            ResolveBindings();
            if (_clothingSystem != null)
            {
                _clothingSystem.OnChanged -= MarkDirty;
                _clothingSystem.OnChanged += MarkDirty;
            }
            EnsureSaveRegistration();
        }

        private void Start()
        {
            ResolveBindings();
            if (_clothingSystem != null)
            {
                _clothingSystem.OnChanged -= MarkDirty;
                _clothingSystem.OnChanged += MarkDirty;
            }
            EnsureSaveRegistration();
        }

        public void EnsureSaveRegistration()
        {
            var manager = K_SaveManager.Instance;
            if (ReferenceEquals(manager, _registeredSaveManager)) return;
            _registeredSaveManager?.Unregister(this);
            _registeredSaveManager = manager;
            _registeredSaveManager?.Register(this);
        }

        private void ResolveBindings()
        {
            if (_clothingSystem == null) _clothingSystem = GetComponent<K_ClothingSystem>();
            if (_inventoryUI == null)
                _inventoryUI = FindFirstObjectByType<K_InventoryUI>(FindObjectsInactive.Include);
        }

        private void MarkDirty() => IsDirty = true;

        public void OnBeforeSave()
        {
            if (_inventoryUI != null && _inventoryUI.IsDragging)
                _inventoryUI.EndDragComplete(true);
        }

        // Preload runs for every registered owner, including a missing optional section.
        public void OnBeforeLoad()
        {
            ResolveBindings();
            _pendingEquipment = null;
            _inventoryUI?.PrepareForLoad();
            ClearSlots();
            _clothingSystem?.ClearConditionRecords();
            IsDirty = true;
        }

        public void Save(BinaryWriter writer)
        {
            RequireBindings();
            var slots = new SavedItem?[InventoryLoadReader.ClothingSlotCount];
            for (int index = 0; index < slots.Length; index++)
            {
                var item = _inventoryUI.GetClothingItem((ClothingSlotKind)index);
                if (item == null) continue;
                ValidateSlotTemplate(item.Data, index);
                if (item.Quantity != 1)
                    throw new InvalidDataException("A clothing slot requires one item.");
                slots[index] = item.ToSaveData(0, 0);
            }
            var records = new List<ClothingConditionRecord>(_clothingSystem.ExportConditionRecords());
            InventoryLoadReader.WriteClothing(writer, slots, records);
        }

        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context)
        {
            if (context == null) throw new ArgumentNullException(nameof(context));
            RequireBindings();
            var pending = InventoryLoadReader.ReadClothing(reader);
            ValidatePayload(pending, context);
        }

        public void Load(BinaryReader reader)
        {
            RequireBindings();
            var pending = InventoryLoadReader.ReadClothing(reader);
            using (var validation = new SaveLoadValidationContext())
            {
                ValidatePayload(pending, validation);
                validation.Validate();
            }

            var items = new InventoryItem[pending.Slots.Length];
            var database = K_InventorySetup.DatabaseInstance;
            for (int index = 0; index < items.Length; index++)
                if (pending.Slots[index].HasValue)
                {
                    var saved = pending.Slots[index].Value;
                    items[index] = InventoryItem.FromSaveData(saved, database.GetItemData(saved.ItemID));
                    if (items[index] == null)
                        throw new InvalidDataException("A clothing item could not be reconstructed.");
                }

            // Apply layers after Player_Equipment has reconstructed the saved armour.
            // The same post-load ordering also restores clothing after rollback.
            ClearSlots();
            _clothingSystem.ImportConditionRecords(pending.Conditions);
            foreach (var record in pending.Conditions) GlobalIDManager.ObserveID(record.InstanceID);
            _pendingEquipment = items;
            IsDirty = false;
        }

        public void OnAfterLoad()
        {
            if (_pendingEquipment != null)
            {
                for (int index = 0; index < _pendingEquipment.Length; index++)
                    _inventoryUI.GetClothingSlot((ClothingSlotKind)index)?.SetEquippedItem(_pendingEquipment[index]);
                _pendingEquipment = null;
            }
            _inventoryUI?.ForceRefresh();
            IsDirty = false;
        }

        private void ValidatePayload(InventoryLoadReader.ClothingDto pending, SaveLoadValidationContext context)
        {
            var database = K_InventorySetup.DatabaseInstance;
            if (database == null)
                throw new InvalidDataException("Clothing load requires the item database.");
            var slotItems = new Dictionary<uint, string>();
            for (int index = 0; index < pending.Slots.Length; index++)
            {
                if (!pending.Slots[index].HasValue) continue;
                if (_inventoryUI.GetClothingSlot((ClothingSlotKind)index) == null)
                    throw new InvalidDataException("The saved clothing slot is missing in this scene.");
                var saved = pending.Slots[index].Value;
                var template = InventoryLoadReader.ValidateItemTree(saved, database, context, SaveID + "/" + index);
                ValidateSlotTemplate(template, index);
                if (saved.Quantity != 1 || saved.IsFolded)
                    throw new InvalidDataException("A clothing slot requires one unfolded item.");
                slotItems.Add(saved.InstanceID, saved.ItemID);
                if (index == (int)ClothingSlotKind.Hat)
                    context.RecordHatCompatibility(template.Clothing.AllowsHelmet);
                if (index == (int)ClothingSlotKind.Jacket)
                    context.RecordJacketCompatibility(template.Clothing.AllowsBodyArmor);
            }
            K_ClothingSystem.ValidateConditionRecords(pending.Conditions);
            foreach (var record in pending.Conditions)
            {
                var template = database.GetItemData(record.ItemID);
                if (template == null || template.Type != ItemType.Clothing || template.Clothing == null)
                    throw new InvalidDataException("A clothing condition references a missing clothing template.");
                if (slotItems.TryGetValue(record.InstanceID, out string itemID) &&
                    !string.Equals(itemID, record.ItemID, StringComparison.Ordinal))
                    throw new InvalidDataException("A clothing condition does not match its equipped item.");
            }
        }

        private static void ValidateSlotTemplate(ItemStaticData template, int index)
        {
            if (template == null || template.Type != ItemType.Clothing || template.Clothing == null ||
                (int)template.Clothing.Slot != index || template.IsBackpack)
                throw new InvalidDataException("The item does not match its clothing slot.");
        }

        private void RequireBindings()
        {
            ResolveBindings();
            if (_inventoryUI == null || _clothingSystem == null)
                throw new InvalidDataException("Clothing save requires inventory and clothing systems.");
        }

        private void ClearSlots()
        {
            if (_inventoryUI == null) return;
            foreach (var slot in _inventoryUI.ClothingSlots)
                if (slot != null && slot.EquippedItem != null) slot.SetEquippedItem(null);
        }

        private void OnDestroy()
        {
            if (_clothingSystem != null) _clothingSystem.OnChanged -= MarkDirty;
            _registeredSaveManager?.Unregister(this);
        }
    }
}
