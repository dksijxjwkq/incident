using System;
using System.Collections.Generic;
using System.IO;

namespace K_Incident.Core.Inventory
{
    public static partial class InventoryLoadReader
    {
        public const int ClothingPayloadVersion = 1;
        public const int ClothingSlotCount = 4;
        private const int ClothingRegionCount = 9;
        private const int MinimumClothingConditionBytes = sizeof(uint) + 2 + ClothingRegionCount * sizeof(float);

        public sealed class ClothingDto
        {
            public readonly SavedItem?[] Slots;
            public readonly List<ClothingConditionRecord> Conditions;

            internal ClothingDto(SavedItem?[] slots, List<ClothingConditionRecord> conditions)
            {
                Slots = slots;
                Conditions = conditions;
            }
        }

        /// <summary>Reads the optional clothing payload without allocating item identities.</summary>
        public static ClothingDto ReadClothing(BinaryReader reader)
        {
            RequireReader(reader);
            if (reader.ReadInt32() != ClothingPayloadVersion)
                throw new InvalidDataException("Unsupported clothing payload version.");

            var slots = new SavedItem?[ClothingSlotCount];
            var ids = new HashSet<uint>();
            int remaining = MaximumItems;
            for (int index = 0; index < slots.Length; index++)
            {
                int present = reader.ReadInt32();
                if (present == 0) continue;
                if (present != 1)
                    throw new InvalidDataException("Clothing slot marker must be 0 or 1.");
                slots[index] = ReadEquipmentItem(reader, 0, true, true, ref remaining, ids);
            }

            int count = reader.ReadInt32();
            if (count < 0 || count > MaximumItems)
                throw new InvalidDataException("Clothing condition count exceeds its limit.");
            if (reader.BaseStream.CanSeek && count >
                (reader.BaseStream.Length - reader.BaseStream.Position) / MinimumClothingConditionBytes)
                throw new InvalidDataException("Clothing condition count exceeds the remaining payload.");

            var records = new List<ClothingConditionRecord>(count);
            var conditionIds = new HashSet<uint>();
            for (int index = 0; index < count; index++)
            {
                uint instanceID = reader.ReadUInt32();
                if (instanceID == 0 || instanceID == uint.MaxValue || !conditionIds.Add(instanceID))
                    throw new InvalidDataException("Clothing conditions have an invalid or duplicate identity.");
                string itemID = ReadIdentifier(reader);
                var values = new float[ClothingRegionCount];
                for (int region = 0; region < values.Length; region++)
                {
                    float value = SaveLoadValidationContext.ReadFinite(reader);
                    if (value < 0f || value > 1f)
                        throw new InvalidDataException("Clothing condition is outside 0..1.");
                    values[region] = value;
                }
                records.Add(new ClothingConditionRecord
                {
                    InstanceID = instanceID,
                    ItemID = itemID,
                    Regions = values
                });
            }
            return new ClothingDto(slots, records);
        }

        public static void WriteClothing(BinaryWriter writer, SavedItem?[] slots,
            IReadOnlyList<ClothingConditionRecord> conditions)
        {
            if (writer == null) throw new ArgumentNullException(nameof(writer));
            if (slots == null || slots.Length != ClothingSlotCount)
                throw new ArgumentException("Clothing requires four slots.", nameof(slots));
            if (conditions == null || conditions.Count > MaximumItems)
                throw new InvalidDataException("Clothing condition count exceeds its limit.");
            K_ClothingSystem.ValidateConditionRecords(conditions);

            writer.Write(ClothingPayloadVersion);
            var identities = new HashSet<uint>();
            foreach (var slot in slots)
            {
                writer.Write(slot.HasValue ? 1 : 0);
                if (!slot.HasValue) continue;
                var item = slot.Value;
                if (item.InstanceID == 0 || item.InstanceID == uint.MaxValue || !identities.Add(item.InstanceID))
                    throw new InvalidDataException("Clothing slots have an invalid or duplicate identity.");
                RequireClothingIdentifier(item.ItemID);
                if (item.BackpackContents != null && item.BackpackContents.Count > 0)
                    throw new InvalidDataException("A clothing slot cannot own a backpack inventory.");
                writer.Write(item.ItemID);
                writer.Write(item.InstanceID);
                writer.Write(item.X);
                writer.Write(item.Y);
                writer.Write(item.Quantity);
                writer.Write(item.Durability);
                writer.Write(item.IsRotated);
                writer.Write(item.IsFolded);
                writer.Write(item.ChargePercent);
                writer.Write(item.RemainingChargeSeconds);
                writer.Write(0);
            }
            writer.Write(conditions.Count);
            foreach (var record in conditions)
            {
                RequireClothingIdentifier(record.ItemID);
                writer.Write(record.InstanceID);
                writer.Write(record.ItemID);
                for (int region = 0; region < ClothingRegionCount; region++)
                    writer.Write(record.Regions[region]);
            }
        }

        private static void RequireClothingIdentifier(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || StrictUtf8.GetByteCount(value) > MaximumIdentifierBytes)
                throw new InvalidDataException("Clothing identifier length exceeds its limit.");
        }
    }
}
