using System;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public partial class K_UIConnector
    {
        private const float JointEpsilon = 0.0001f;
        private FrameJointPair[] _frameJointOwners = Array.Empty<FrameJointPair>();

        private struct FrameJointOwner
        {
            public RectTransform Marker;
            public K_InventoryFrameImage Frame;
        }

        private struct FrameJointPair
        {
            public FrameJointOwner From, To;
        }

        private struct FrameJointGeometry
        {
            public RectTransform Transform;
            public Rect Outer, Center;
            public Vector2 Point;
            public Rect AxisCenter;
            public int VerticalEdge;
            public bool AxisParallel;
        }

        private void CacheFrameJoints()
        {
            int count = _alignFrameJoints && _pairs != null ? _pairs.Length : 0;
            _frameJointOwners = new FrameJointPair[count];
            for (int i = 0; i < count; i++)
                _frameJointOwners[i] = new FrameJointPair
                {
                    From = FindFrameJoint(_pairs[i].from),
                    To = FindFrameJoint(_pairs[i].to)
                };
        }

        private static FrameJointOwner FindFrameJoint(RectTransform marker)
        {
            var owner = new FrameJointOwner { Marker = marker };
            for (Transform current = marker; current != null; current = current.parent)
            {
                var frame = current.GetComponent<K_InventoryFrameImage>();
                if (frame != null && frame.enabled && frame.DrawFrame) { owner.Frame = frame; break; }
                Transform header = current.Find("HeaderFrame");
                frame = header != null ? header.GetComponent<K_InventoryFrameImage>() : null;
                if (frame != null && frame.enabled && frame.DrawFrame) { owner.Frame = frame; break; }
            }
            return owner;
        }

        private bool TryAlignFrameJoints(int index, ConnectorPair pair, float requested,
            ref Vector2 from, ref Vector2 to, out float thickness)
        {
            thickness = requested;
            if (!Finite(from) || !Finite(to)) return false;
            if (_frameJointOwners.Length != _pairs.Length) CacheFrameJoints();
            var owners = _frameJointOwners[index];
            if (owners.From.Marker != pair.from) owners.From = FindFrameJoint(pair.from);
            if (owners.To.Marker != pair.to) owners.To = FindFrameJoint(pair.to);
            _frameJointOwners[index] = owners;
            Transform axis = _rootCanvas != null ? _rootCanvas.transform : _rt;
            Vector2 rawFromAxis = PointInAxis(axis, _rt, from);
            Vector2 rawToAxis = PointInAxis(axis, _rt, to);
            bool hasFrom = TryReadFrameJoint(owners.From, axis, out var fromFrame);
            bool hasTo = TryReadFrameJoint(owners.To, axis, out var toFrame);
            Vector2 desiredFrom = hasFrom ? PointInConnector(fromFrame.Transform, fromFrame.Point) : from;
            Vector2 desiredTo = hasTo ? PointInConnector(toFrame.Transform, toFrame.Point) : to;
            from = desiredFrom;
            to = desiredTo;

            float tolerance = Finite(_axisSnapTolerance) ? Mathf.Max(0f, _axisSnapTolerance) : 0f;
            Vector2 rawDelta = rawToAxis - rawFromAxis;
            // Rotated/sheared frames retain their authored corner connections. The cap fit
            // below still uses their real transforms; only the optional axis snap is skipped.
            bool horizontal = hasFrom && hasTo && fromFrame.AxisParallel && toFrame.AxisParallel &&
                Mathf.Abs(rawDelta.y) <= tolerance && Mathf.Abs(rawDelta.x) > MinLength &&
                Mathf.Abs(rawDelta.x) >= Mathf.Abs(rawDelta.y);
            float desiredY = 0f;
            if (horizontal)
            {
                desiredY = fromFrame.VerticalEdge == 1 && toFrame.VerticalEdge == 1
                    ? Mathf.Min(fromFrame.AxisCenter.yMax, toFrame.AxisCenter.yMax)
                    : fromFrame.VerticalEdge == -1 && toFrame.VerticalEdge == -1
                        ? Mathf.Max(fromFrame.AxisCenter.yMin, toFrame.AxisCenter.yMin)
                        : (PointInAxis(axis, _rt, desiredFrom).y + PointInAxis(axis, _rt, desiredTo).y) * .5f;
            }

            for (int iteration = 0; iteration < 8; iteration++)
            {
                Vector2 delta = to - from;
                float length = delta.magnitude;
                if (!Finite(length) || length <= MinLength) return false;
                thickness = ResolveScreenThickness(requested, from, to);
                if (!Finite(thickness) || thickness <= 0f) return false;
                Vector2 halfWidth = new Vector2(-delta.y, delta.x) * (thickness * .5f / length);
                Rect fromFit = default, toFit = default;
                if (hasFrom && !TryCapRect(fromFrame, halfWidth, out fromFit)) return false;
                if (hasTo && !TryCapRect(toFrame, halfWidth, out toFit)) return false;
                Vector2 previousFrom = from, previousTo = to;
                if (horizontal)
                {
                    if (!TryIntersect(fromFrame.Center, fromFit, out var fromSafe) ||
                        !TryIntersect(toFrame.Center, toFit, out var toSafe)) return false;
                    Rect fromBounds = BoundsInAxis(axis, fromFrame.Transform, fromSafe);
                    Rect toBounds = BoundsInAxis(axis, toFrame.Transform, toSafe);
                    float lowY = Mathf.Max(fromBounds.yMin, toBounds.yMin);
                    float highY = Mathf.Min(fromBounds.yMax, toBounds.yMax);
                    if (lowY > highY) return false;
                    float y = Mathf.Clamp(desiredY, lowY, highY);
                    bool rightward = toFrame.AxisCenter.center.x >= fromFrame.AxisCenter.center.x;
                    float fromX = rightward ? fromBounds.xMax : fromBounds.xMin;
                    float toX = rightward ? toBounds.xMin : toBounds.xMax;
                    // A connector is the free gap between the frames, not a stroke through
                    // their contents when the facing sides overlap or meet already.
                    if ((rightward ? toX - fromX : fromX - toX) <= MinLength) return false;
                    from = PointInConnector(axis, new Vector2(fromX, y));
                    to = PointInConnector(axis, new Vector2(toX, y));
                }
                else
                {
                    if (hasFrom) from = PointInConnector(fromFrame.Transform, Clamp(fromFrame.Point, fromFit));
                    if (hasTo) to = PointInConnector(toFrame.Transform, Clamp(toFrame.Point, toFit));
                }
                if (!Finite(from) || !Finite(to)) return false;
                if ((from - previousFrom).sqrMagnitude + (to - previousTo).sqrMagnitude < 0.0000000001f) break;
            }

            Vector2 finalDelta = to - from;
            float finalLength = finalDelta.magnitude;
            if (!Finite(finalLength) || finalLength <= MinLength) return false;
            thickness = ResolveScreenThickness(requested, from, to);
            if (!Finite(thickness) || thickness <= 0f) return false;
            Vector2 finalHalf = new Vector2(-finalDelta.y, finalDelta.x) * (thickness * .5f / finalLength);
            // Check the final direction/actual thickness, rather than trusting the earlier
            // centerline snap. Each butt cap has two vertices p +/- perpendicular halfwidth.
            return (!hasFrom || CapInside(fromFrame, from, finalHalf)) &&
                   (!hasTo || CapInside(toFrame, to, finalHalf));
        }

        private bool TryReadFrameJoint(FrameJointOwner owner, Transform axis, out FrameJointGeometry joint)
        {
            joint = default;
            if (owner.Marker == null || owner.Frame == null || !owner.Frame.enabled || !owner.Frame.DrawFrame) return false;
            RectTransform transform = owner.Frame.rectTransform;
            Rect outer = transform.rect, center = owner.Frame.GetBorderCenterRect();
            if (!Finite(outer) || !Finite(center) || outer.width <= 0f || outer.height <= 0f ||
                center.width < 0f || center.height < 0f) return false;
            Vector3 raw = transform.InverseTransformPoint(owner.Marker.position);
            if (!Finite(raw.x) || !Finite(raw.y)) return false;
            Vector2 point = Clamp(new Vector2(raw.x, raw.y), center);
            Vector3 basisX = axis.InverseTransformVector(transform.TransformVector(Vector3.right));
            Vector3 basisY = axis.InverseTransformVector(transform.TransformVector(Vector3.up));
            if (!Finite(basisX.x) || !Finite(basisX.y) || !Finite(basisY.x) || !Finite(basisY.y) ||
                basisX.sqrMagnitude <= 0.000000000001f || basisY.sqrMagnitude <= 0.000000000001f) return false;
            if (raw.x > center.xMin && raw.x < center.xMax && raw.y > center.yMin && raw.y < center.yMax)
            {
                float left = (point.x - center.xMin) * basisX.magnitude;
                float right = (center.xMax - point.x) * basisX.magnitude;
                float bottom = (point.y - center.yMin) * basisY.magnitude;
                float top = (center.yMax - point.y) * basisY.magnitude;
                float nearest = Mathf.Min(left, right, bottom, top);
                if (nearest == left) point.x = center.xMin;
                else if (nearest == right) point.x = center.xMax;
                else if (nearest == bottom) point.y = center.yMin;
                else point.y = center.yMax;
            }
            joint = new FrameJointGeometry
            {
                Transform = transform, Outer = outer, Center = center, Point = point,
                AxisCenter = BoundsInAxis(axis, transform, center),
                VerticalEdge = Mathf.Abs(point.y - center.yMax) <= JointEpsilon ? 1 :
                    Mathf.Abs(point.y - center.yMin) <= JointEpsilon ? -1 : 0,
                AxisParallel = Mathf.Abs(basisX.y) <= JointEpsilon * basisX.magnitude &&
                    Mathf.Abs(basisY.x) <= JointEpsilon * basisY.magnitude
            };
            return Finite(joint.AxisCenter);
        }

        private bool TryCapRect(FrameJointGeometry joint, Vector2 halfWidth, out Rect fit)
        {
            Vector3 local = joint.Transform.InverseTransformVector(_rt.TransformVector(new Vector3(halfWidth.x, halfWidth.y, 0f)));
            float x = Mathf.Abs(local.x), y = Mathf.Abs(local.y);
            fit = Rect.MinMaxRect(joint.Outer.xMin + x, joint.Outer.yMin + y, joint.Outer.xMax - x, joint.Outer.yMax - y);
            return Finite(fit) && fit.width >= 0f && fit.height >= 0f;
        }

        private bool CapInside(FrameJointGeometry joint, Vector2 endpoint, Vector2 halfWidth)
        {
            if (!TryCapRect(joint, halfWidth, out Rect fit)) return false;
            Vector3 point = joint.Transform.InverseTransformPoint(_rt.TransformPoint(new Vector3(endpoint.x, endpoint.y, 0f)));
            return point.x >= fit.xMin - JointEpsilon && point.x <= fit.xMax + JointEpsilon &&
                point.y >= fit.yMin - JointEpsilon && point.y <= fit.yMax + JointEpsilon;
        }

        private Vector2 PointInConnector(Transform source, Vector2 point)
        {
            Vector3 local = _rt.InverseTransformPoint(source.TransformPoint(new Vector3(point.x, point.y, 0f)));
            return new Vector2(local.x, local.y);
        }

        private static Vector2 PointInAxis(Transform axis, Transform source, Vector2 point)
        {
            Vector3 local = axis.InverseTransformPoint(source.TransformPoint(new Vector3(point.x, point.y, 0f)));
            return new Vector2(local.x, local.y);
        }

        private static Rect BoundsInAxis(Transform axis, Transform source, Rect rect)
        {
            Vector2 a = PointInAxis(axis, source, new Vector2(rect.xMin, rect.yMin));
            Vector2 b = PointInAxis(axis, source, new Vector2(rect.xMin, rect.yMax));
            Vector2 c = PointInAxis(axis, source, new Vector2(rect.xMax, rect.yMin));
            Vector2 d = PointInAxis(axis, source, new Vector2(rect.xMax, rect.yMax));
            Vector2 min = Vector2.Min(Vector2.Min(a, b), Vector2.Min(c, d));
            Vector2 max = Vector2.Max(Vector2.Max(a, b), Vector2.Max(c, d));
            return Rect.MinMaxRect(min.x, min.y, max.x, max.y);
        }

        private static bool TryIntersect(Rect a, Rect b, out Rect intersection)
        {
            intersection = Rect.MinMaxRect(Mathf.Max(a.xMin, b.xMin), Mathf.Max(a.yMin, b.yMin),
                Mathf.Min(a.xMax, b.xMax), Mathf.Min(a.yMax, b.yMax));
            return Finite(intersection) && intersection.width >= 0f && intersection.height >= 0f;
        }

        private static Vector2 Clamp(Vector2 point, Rect rect)
            => new Vector2(Mathf.Clamp(point.x, rect.xMin, rect.xMax), Mathf.Clamp(point.y, rect.yMin, rect.yMax));
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
        private static bool Finite(Vector2 value) => Finite(value.x) && Finite(value.y);
        private static bool Finite(Rect value) => Finite(value.xMin) && Finite(value.yMin) && Finite(value.xMax) && Finite(value.yMax);
    }
}
