using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Пара «откуда → куда» для одной декоративной линии-коннектора.
    /// from / to — это RectTransform-маркеры (пустые дети слотов, расставленные по углам).
    /// </summary>
    [Serializable]
    public struct ConnectorPair
    {
        public RectTransform from;
        public RectTransform to;

        [Tooltip("0 = использовать default thickness")]
        public float thickness;

        [Tooltip("alpha == 0 = использовать default color")]
        public Color color;
    }

    /// <summary>
    /// Рисует тонкие декоративные Image-линии между парами RectTransform-маркеров.
    ///
    /// <para><b>Инструкция пользователю:</b></para>
    /// <list type="number">
    /// <item>У каждого слота создай N пустых RectTransform-детей
    ///       ("Point_TL", "Point_TR", "Point_BL", "Point_BR").
    ///       Позиционируй их по углам слота через anchorMin/Max
    ///       (например, для левого-нижнего: anchorMin = anchorMax = (0,0), anchoredPosition = (0,0)).</item>
    /// <item>Помести K_UIConnector на общий родитель (EquipmentGroup или LeftPane).
    ///       Anchor/pivot/sizeDelta компонент выставит сам в Awake/OnValidate.</item>
    /// <item>В инспекторе K_UIConnector → Pairs → Add.
    ///       В поле <c>from</c> перетащи маркер, в <c>to</c> — парный маркер.</item>
    /// <item>Линия появится автоматически. Двигаешь слот или маркер — линия перестроится.</item>
    /// <item>Толщина 0 = default thickness. Цвет с alpha=0 = default color.</item>
    /// </list>
    ///
    /// <para><b>Почему не LineRenderer:</b> это 3D-компонент, не работает корректно
    /// в Screen Space Overlay Canvas без костылей. Используем плоский Image.</para>
    /// </summary>
    [AddComponentMenu("UI/K_UIConnector")]
    [RequireComponent(typeof(RectTransform))]
    [DefaultExecutionOrder(1100)]
    public partial class K_UIConnector : MonoBehaviour
    {
        // ─────────────────────────────────────────────────────────────────────
        // Inspector
        // ─────────────────────────────────────────────────────────────────────

        [Header("Defaults")]
        [SerializeField] private float _defaultThickness = 2f;
        [SerializeField] private Color _defaultColor = new Color(0.45f, 0.47f, 0.52f, 1f);
        [SerializeField, Min(0f), Tooltip("Минимальная толщина линии в пикселях экрана при уменьшении UI. 0 — без ограничения; цвет и заданная толщина более крупных линий сохраняются.")]
        private float _minimumPixelThickness = 1f;

        [SerializeField, Tooltip("Одинаковая экранная толщина всех соединителей. При включении Thickness у отдельных пар и Default Thickness не влияют на толщину.")]
        private bool _uniformScreenThickness = true;
        [SerializeField, Min(1f), Tooltip("Единая толщина соединителей в пикселях экрана. 1 — тонкие линии; толщина сохраняется при изменении разрешения и масштаба UI.")]
        private float _screenThicknessPixels = 1f;

        [Header("Pairs")]
        [SerializeField] private ConnectorPair[] _pairs = new ConnectorPair[0];

        [Header("Update")]
        [SerializeField, Tooltip("Пересчитывать линии каждый кадр в LateUpdate. " +
            "Если false — только при Start/OnValidate/через Rebuild().")]
        private bool _liveUpdate = true;

        [Header("Debug")]
        [SerializeField] private bool _drawGizmos = true;

        [Header("Стыки рамок")]
        [SerializeField, Tooltip("Подгонять концы линий к середине рамок слотов и заголовков, учитывая полную толщину соединителя. Исходные маркеры и пары остаются на своих местах.")]
        private bool _alignFrameJoints = false;
        [SerializeField, Min(0f), Tooltip("Допустимая разница высот исходных маркеров в единицах Canvas, при которой соединение рамок выравнивается строго по горизонтали.")]
        private float _axisSnapTolerance = 1f;

        // ─────────────────────────────────────────────────────────────────────
        // Runtime state
        // ─────────────────────────────────────────────────────────────────────

        private RectTransform _rt;
        private Canvas _rootCanvas;
        private readonly List<Image> _lines = new List<Image>();

        private const string LinePrefix = "Line_";
        private const string RetiredLinePrefix = "RetiredConnectorLine_";
        private const float MinLength = 0.01f;

        public Color LineColor
        {
            get
            {
                if (_pairs != null)
                    foreach (var pair in _pairs)
                        if (pair.color.a > 0f) return pair.color;
                return _defaultColor;
            }
        }

#if UNITY_EDITOR
        /// <summary>
        /// Защита от множественных delayCall-запросов, прилетающих пачкой
        /// из OnValidate при массовом изменении полей в инспекторе.
        /// </summary>
        private bool _delayedRebuildQueued;
        [NonSerialized] private bool _insideEnable;
#endif

        // ─────────────────────────────────────────────────────────────────────
        // Unity lifecycle
        // ─────────────────────────────────────────────────────────────────────

        private void Awake()
        {
            EnsureRect();
            CacheCanvas();
            if (_rt == null) return;
            NormalizeSelf(logWarning: true);
        }

        private void OnEnable()
        {
            EnsureRect();
            CacheCanvas();
            if (_rt == null) return;

            NormalizeSelf(logWarning: false);
#if UNITY_EDITOR
            _insideEnable = true;
            try { Rebuild(); }
            finally { _insideEnable = false; }
#else
            Rebuild();
#endif
        }

        private void Start()
        {
            // Если liveUpdate выключен — гарантируем корректный первый расчёт.
            if (!_liveUpdate) UpdateLines();
        }

        private void OnTransformParentChanged()
        {
            CacheCanvas();
        }

        private void LateUpdate()
        {
            if (!_liveUpdate) return;
            UpdateLines();
        }

        private void OnValidate()
        {
            // OnValidate может вызываться до Awake / до OnEnable — не падаем.
            EnsureRect();
            if (_rt == null) return;

            NormalizeSelf(logWarning: false);

#if UNITY_EDITOR
            // Rebuild/UpdateLines нельзя вызывать синхронно из OnValidate —
            // Unity блокирует DestroyImmediate и создание/репарентинг GameObject
            // (SendMessage cannot be called during Awake/CheckConsistency/OnValidate).
            // Откладываем на delayCall и схлопываем повторные запросы.
            if (_delayedRebuildQueued) return;
            _delayedRebuildQueued = true;
            UnityEditor.EditorApplication.delayCall += DelayedRebuildFromValidate;
#else
            // В билде OnValidate не дёргается, ветка чисто для симметрии чтения.
            int target = _pairs != null ? _pairs.Length : 0;
            if (CountLineChildren() != target || _lines.Count != target)
                Rebuild();
            else
                UpdateLines();
#endif
        }

        // ─────────────────────────────────────────────────────────────────────
        // Public API
        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Подхватить существующие линии, добавить недостающие и удалить лишние.
        /// Повторный вызов сохраняет объекты и не создаёт наложенных копий.
        /// </summary>
        [ContextMenu("Rebuild")]
        public void Rebuild()
        {
            EnsureRect();
            if (_rt == null) return;
            if (_rootCanvas == null) CacheCanvas();

            int target = _pairs != null ? _pairs.Length : 0;
            var retained = new K_UIConnectorLine[target];
            // The objects themselves may survive a domain reload while the private
            // runtime list does not. Recover them before deciding what to create.
            for (int i = 0; i < _rt.childCount; i++)
            {
                var child = _rt.GetChild(i);
                if (!child.name.StartsWith(LinePrefix, StringComparison.Ordinal)) continue;
                if (!int.TryParse(child.name.Substring(LinePrefix.Length), out int index) ||
                    index < 0 || index >= target || child.name != LinePrefix + index) continue;
                var line = child.GetComponent<K_UIConnectorLine>();
                if (line != null && retained[index] == null) retained[index] = line;
            }

            _lines.Clear();
            for (int i = _rt.childCount - 1; i >= 0; i--)
            {
                var child = _rt.GetChild(i);
                bool generated = child.name.StartsWith(LinePrefix, StringComparison.Ordinal);
                bool retired = child.name.StartsWith(RetiredLinePrefix, StringComparison.Ordinal);
                if (!generated && !retired) continue;
                var line = child.GetComponent<K_UIConnectorLine>();
                bool keep = false;
                if (generated && line != null)
                    for (int j = 0; j < retained.Length; j++)
                        if (retained[j] == line) { keep = true; break; }
                if (keep) continue;
                DestroySafe(child.gameObject);
            }

            for (int i = 0; i < target; i++)
            {
                var img = retained[i];
                if (img == null)
                {
                    var go = new GameObject(LinePrefix + i, typeof(RectTransform), typeof(K_UIConnectorLine));
                    go.transform.SetParent(_rt, false);
                    img = go.GetComponent<K_UIConnectorLine>();
                }

                img.enabled = true;
                img.sprite = null;
                img.type = Image.Type.Simple;
                img.raycastTarget = false;
                img.color = _defaultColor;

                var lrt = img.rectTransform;
                lrt.anchorMin = new Vector2(0f, 1f);
                lrt.anchorMax = new Vector2(0f, 1f);
                lrt.pivot = new Vector2(0f, 0.5f);

                _lines.Add(img);
            }

            // 3) Считаем позиции/углы.
            CacheFrameJoints();
            UpdateLines();
        }

        /// <summary>
        /// Пересчитать позиции / размеры / повороты всех линий.
        /// Безопасно вызывать каждый кадр.
        /// </summary>
        public void UpdateLines()
        {
            EnsureRect();
            if (_rt == null) return;
            if (_pairs == null) return;
            if (_rootCanvas == null) CacheCanvas();

            // Если по какой-то причине список линий разошёлся с количеством пар — восстановить.
            if (_lines.Count != _pairs.Length)
            {
                Rebuild();
                return;
            }

            for (int i = 0; i < _pairs.Length; i++)
            {
                var pair = _pairs[i];
                var img = _lines[i];
                if (img == null) continue;

                var lineGO = img.gameObject;

                // Пара невалидна — просто прячем линию.
                if (pair.from == null || pair.to == null)
                {
                    if (lineGO.activeSelf) lineGO.SetActive(false);
                    continue;
                }

                // Локальные координаты (world → local коннектора).
                Vector3 localFrom = _rt.InverseTransformPoint(pair.from.position);
                Vector3 localTo = _rt.InverseTransformPoint(pair.to.position);

                // В top-left-фрейме Unity UI (anchor (0,1), pivot (0,1))
                // локальная +y и anchoredPosition +y согласованы.
                Vector2 anchoredFrom = new Vector2(localFrom.x, localFrom.y);
                Vector2 anchoredTo = new Vector2(localTo.x, localTo.y);

                float thickness = (pair.thickness > 0f) ? pair.thickness : _defaultThickness;
                bool valid = !_alignFrameJoints || TryAlignFrameJoints(i, pair, thickness,
                    ref anchoredFrom, ref anchoredTo, out thickness);
                if (!_alignFrameJoints) thickness = ResolveScreenThickness(thickness, anchoredFrom, anchoredTo);
                Vector2 delta = anchoredTo - anchoredFrom;
                float length = delta.magnitude;
                if (!valid || !Finite(anchoredFrom) || !Finite(anchoredTo) || !Finite(length) ||
                    !Finite(thickness) || thickness <= 0f)
                {
                    if (lineGO.activeSelf) lineGO.SetActive(false);
                    continue;
                }
                float angle = Mathf.Atan2(delta.y, delta.x) * Mathf.Rad2Deg;
                Color color = (pair.color.a > 0f) ? pair.color : _defaultColor;

                var lineRT = img.rectTransform;
                lineRT.anchorMin = new Vector2(0f, 1f);
                lineRT.anchorMax = new Vector2(0f, 1f);
                lineRT.pivot = new Vector2(0f, 0.5f);
                lineRT.anchoredPosition = anchoredFrom;
                lineRT.sizeDelta = new Vector2(length, thickness);
                lineRT.localEulerAngles = new Vector3(0f, 0f, angle);

                img.color = color;

                // Слишком короткая — прячем (иначе виден «квадрат» из-за округления).
                bool visible = length > MinLength;
                if (lineGO.activeSelf != visible) lineGO.SetActive(visible);
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // Helpers
        // ─────────────────────────────────────────────────────────────────────

#if UNITY_EDITOR
        private void DelayedRebuildFromValidate()
        {
            // delayCall может прилететь после удаления/выключения объекта — защищаемся.
            if (this == null) return;

            _delayedRebuildQueued = false;

            if (!isActiveAndEnabled) return;
            if (_rt == null) return;

            Rebuild();
        }
#endif

        private void EnsureRect()
        {
            if (_rt == null) _rt = GetComponent<RectTransform>();
        }

        private void CacheCanvas()
        {
            var canvas = GetComponentInParent<Canvas>();
            _rootCanvas = canvas != null ? canvas.rootCanvas : null;
        }

        private float ResolveScreenThickness(float requested, Vector2 from, Vector2 to)
        {
            float minimum = !float.IsNaN(_minimumPixelThickness) && !float.IsInfinity(_minimumPixelThickness)
                ? Mathf.Max(0f, _minimumPixelThickness) : 0f;
            float screenThickness = !float.IsNaN(_screenThicknessPixels) && !float.IsInfinity(_screenThicknessPixels)
                ? Mathf.Max(1f, _screenThicknessPixels) : 1f;
            float targetPixels = _uniformScreenThickness ? Mathf.Max(screenThickness, minimum) : minimum;
            if (_rootCanvas == null || targetPixels <= 0f) return requested;
            Vector2 delta = to - from;
            float length = delta.magnitude;
            if (length <= MinLength) return requested;
            UnityEngine.Camera camera = _rootCanvas.renderMode == RenderMode.ScreenSpaceOverlay ? null : _rootCanvas.worldCamera;
            if (_rootCanvas.renderMode != RenderMode.ScreenSpaceOverlay && camera == null) return requested;

            Vector3 worldFrom = _rt.TransformPoint(new Vector3(from.x, from.y, 0f));
            Vector3 worldTo = _rt.TransformPoint(new Vector3(to.x, to.y, 0f));
            if (camera != null && (camera.WorldToScreenPoint(worldFrom).z <= 0f ||
                camera.WorldToScreenPoint(worldTo).z <= 0f)) return requested;
            Vector2 screenFrom = RectTransformUtility.WorldToScreenPoint(camera, worldFrom);
            Vector2 screenTo = RectTransformUtility.WorldToScreenPoint(camera, worldTo);
            Vector2 screenDelta = screenTo - screenFrom;
            float screenLength = screenDelta.magnitude;
            if (screenLength <= 0.0001f) return requested;

            // Measure the perpendicular screen width, not just Canvas.scaleFactor:
            // nested scale, rotated parents and camera projection all affect it.
            Vector2 normal = new Vector2(-delta.y, delta.x) / length;
            Vector2 fromOffset = RectTransformUtility.WorldToScreenPoint(camera,
                _rt.TransformPoint(new Vector3(from.x + normal.x, from.y + normal.y, 0f))) - screenFrom;
            Vector2 toOffset = RectTransformUtility.WorldToScreenPoint(camera,
                _rt.TransformPoint(new Vector3(to.x + normal.x, to.y + normal.y, 0f))) - screenTo;
            float fromPixels = Mathf.Abs(screenDelta.x * fromOffset.y - screenDelta.y * fromOffset.x) / screenLength;
            float toPixels = Mathf.Abs(screenDelta.x * toOffset.y - screenDelta.y * toOffset.x) / screenLength;
            float pixelsPerUnit = Mathf.Min(fromPixels, toPixels);
            if (float.IsNaN(pixelsPerUnit) || float.IsInfinity(pixelsPerUnit) || pixelsPerUnit <= 0.0001f)
                return requested;
            return _uniformScreenThickness ? targetPixels / pixelsPerUnit :
                Mathf.Max(requested, minimum / pixelsPerUnit);
        }

        /// <summary>
        /// Приводит RectTransform коннектора к top-left-фрейму родителя:
        /// anchorMin = anchorMax = (0,1), pivot = (0,1), anchoredPosition = (0,0), sizeDelta = (0,0).
        /// Не ломает объект — просто нормализует.
        /// </summary>
        private void NormalizeSelf(bool logWarning)
        {
            if (_rt == null) return;

            var anchorTL = new Vector2(0f, 1f);
            var pivotTL = new Vector2(0f, 1f);

            bool changed = false;

            if (_rt.anchorMin != anchorTL) { _rt.anchorMin = anchorTL; changed = true; }
            if (_rt.anchorMax != anchorTL) { _rt.anchorMax = anchorTL; changed = true; }
            if (_rt.pivot != pivotTL) { _rt.pivot = pivotTL; changed = true; }
            if (_rt.anchoredPosition != Vector2.zero) { _rt.anchoredPosition = Vector2.zero; changed = true; }
            if (_rt.sizeDelta != Vector2.zero) { _rt.sizeDelta = Vector2.zero; changed = true; }

            if (changed && logWarning)
            {
                Debug.LogWarning(
                    $"[{nameof(K_UIConnector)}] RectTransform '{name}' нормализован: " +
                    "anchorMin=anchorMax=(0,1), pivot=(0,1), anchoredPosition=(0,0), sizeDelta=(0,0). " +
                    "Линии рисуются в системе координат top-left родителя.",
                    this);
            }
        }

        private int CountLineChildren()
        {
            if (_rt == null) return 0;
            int count = 0;
            for (int i = 0; i < _rt.childCount; i++)
            {
                var c = _rt.GetChild(i);
                if (c == null) continue;
                if (c.name.StartsWith(LinePrefix, StringComparison.Ordinal)) count++;
            }
            return count;
        }

        private void DestroySafe(GameObject go)
        {
            if (go == null) return;
            // Deferred Unity destruction must not leave a visible old stroke or
            // another transform called Line_i that a later lookup can select.
            go.SetActive(false);
            go.name = RetiredLinePrefix + go.GetInstanceID();

#if UNITY_EDITOR
            if (!Application.isPlaying)
            {
                if (!_insideEnable)
                {
                    UnityEngine.Object.DestroyImmediate(go);
                    return;
                }
                // OnValidate already queues Rebuild outside its callback. OnEnable
                // can still run during scene loading, where immediate destruction
                // is forbidden. A later safe Rebuild also collects retired children.
                UnityEditor.EditorApplication.delayCall += () =>
                {
                    if (go != null) UnityEngine.Object.DestroyImmediate(go);
                };
                return;
            }
#endif

            UnityEngine.Object.Destroy(go);
        }

        // ─────────────────────────────────────────────────────────────────────
        // Gizmos (Scene view)
        // ─────────────────────────────────────────────────────────────────────

#if UNITY_EDITOR
        private void OnDrawGizmosSelected()
        {
            if (!_drawGizmos) return;
            if (_pairs == null) return;

            for (int i = 0; i < _pairs.Length; i++)
            {
                var pair = _pairs[i];
                if (pair.from == null || pair.to == null) continue;

                Vector3 fromPos = pair.from.position;
                Vector3 toPos = pair.to.position;

                // from — жёлтая сфера
                Gizmos.color = new Color(1f, 0.85f, 0f, 1f);
                Gizmos.DrawWireSphere(fromPos, 0.05f);
                Gizmos.DrawSphere(fromPos, 0.015f);

                // to — голубая сфера
                Gizmos.color = new Color(0.4f, 0.8f, 1f, 1f);
                Gizmos.DrawWireSphere(toPos, 0.05f);
                Gizmos.DrawSphere(toPos, 0.015f);

                // соединительная линия — белая полупрозрачная
                Gizmos.color = new Color(1f, 1f, 1f, 0.5f);
                Gizmos.DrawLine(fromPos, toPos);
            }
        }
#endif
    }
}
