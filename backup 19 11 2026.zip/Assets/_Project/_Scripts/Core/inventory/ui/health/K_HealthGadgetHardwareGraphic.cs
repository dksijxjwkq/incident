using System;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Vector hardware of the field monitors: painted case with a recessed screen frame, screws,
    /// nameplate, vent grille, toggle, lamp and the rounded edge of the picture tube.
    /// One mesh per part, the shared grain texture only, no material instances.
    /// </summary>
    [RequireComponent(typeof(CanvasRenderer))]
    public sealed class K_HealthGadgetHardwareGraphic : MaskableGraphic
    {
        public enum Shape { Case, Power, Led, Body, Toggle, GlassEdge }
        public Shape Mode { get; set; }

        // Body layout in Canvas units of this rect. X runs from the left edge, Y from the top edge.
        [NonSerialized] public Vector4 ScreenInset = new Vector4(18f, 20f, 18f, 46f);
        [NonSerialized] public float BezelWidth = 10f, BezelRadius = 12f, GlassRadius = 8f, Chamfer = 14f, ScrewRadius = 3.4f;
        [NonSerialized] public Rect Nameplate, Grille, KeyCap;
        [NonSerialized] public int GrilleSlots;
        [NonSerialized] public float Grain = .05f;

        private static readonly Color Black = new Color(.016f, .016f, .016f, 1f);
        private static readonly Color Frame = new Color(.05f, .05f, .05f, 1f);
        private static readonly float[] ScrewTurn = { 24f, -38f, 71f, 8f };
        private VertexHelper _mesh;

        public override Texture mainTexture => K_HealthGadgetNoise.Texture;

        /// <summary>The owner calls this after changing any layout value above.</summary>
        public void Refresh() => SetVerticesDirty();

        protected override void OnPopulateMesh(VertexHelper mesh)
        {
            mesh.Clear();
            _mesh = mesh;
            Rect r = GetPixelAdjustedRect();
            if (r.width <= 0f || r.height <= 0f) return;
            switch (Mode)
            {
                case Shape.Body: DrawBody(r); break;
                case Shape.Toggle: DrawToggle(r); break;
                case Shape.GlassEdge: DrawGlassEdge(r); break;
                case Shape.Led: DrawLed(r); break;
                case Shape.Power: DrawPower(r); break;
                default: DrawLegacyCase(r); break;
            }
        }

        // ------------------------------------------------------------------ case with a recessed screen

        private void DrawBody(Rect r)
        {
            float cut = Mathf.Min(Chamfer, Mathf.Min(r.width, r.height) * .25f);
            Color top = Scale(color, 1.12f), bottom = Scale(color, .56f);
            Plate(r, cut, Black, Black);
            Plate(Inset(r, .9f), cut - .4f, top, bottom);
            // Light catches the upper edge of the painted shell; the lower edge stays in shadow.
            Color rim = Color.Lerp(color, Color.white, .34f);
            Segment(new Vector2(r.xMin + cut, r.yMax - 1.2f), new Vector2(r.xMax - cut, r.yMax - 1.2f), 1f, WithAlpha(rim, .72f));
            Segment(new Vector2(r.xMax - cut, r.yMax - 1.2f), new Vector2(r.xMax - 1.2f, r.yMax - cut), 1f, WithAlpha(rim, .5f));
            Segment(new Vector2(r.xMin + 1.2f, r.yMin + cut), new Vector2(r.xMin + 1.2f, r.yMax - cut), 1f, WithAlpha(rim, .32f));
            Segment(new Vector2(r.xMin + cut, r.yMin + 1.2f), new Vector2(r.xMax - cut, r.yMin + 1.2f), 1.4f, new Color(0f, 0f, 0f, .7f));
            if (Grain > 0f) GrainQuad(Inset(r, cut * .5f), Grain);

            Rect glass = GlassRect(r);
            if (glass.width > 4f && glass.height > 4f)
            {
                Rect frame = Inset(glass, -BezelWidth);
                RoundedPlate(Inset(frame, -1f), BezelRadius + 1f, Black, Black);
                RoundedPlate(frame, BezelRadius, Scale(Frame, 1.25f), Scale(Frame, .62f));
                RoundedStroke(Inset(frame, .5f), BezelRadius - .5f, 1f,
                    WithAlpha(Color.Lerp(color, Color.white, .28f), .8f), new Color(0f, 0f, 0f, .85f));
                RoundedStroke(Inset(frame, BezelWidth * .62f), Mathf.Max(1f, BezelRadius - BezelWidth * .62f), .9f,
                    new Color(.13f, .13f, .13f, 1f), new Color(.09f, .09f, .09f, 1f));
                if (ScrewRadius > 0f)
                {
                    float offset = BezelWidth * .5f;
                    Screw(new Vector2(glass.xMin - offset, glass.yMax + offset), ScrewTurn[0]);
                    Screw(new Vector2(glass.xMax + offset, glass.yMax + offset), ScrewTurn[1]);
                    Screw(new Vector2(glass.xMin - offset, glass.yMin - offset), ScrewTurn[2]);
                    Screw(new Vector2(glass.xMax + offset, glass.yMin - offset), ScrewTurn[3]);
                }
            }

            if (Nameplate.width > 1f && Nameplate.height > 1f)
            {
                Rect plate = FromTop(r, Nameplate);
                Color face = Color.Lerp(color, new Color(.2f, .2f, .2f, 1f), .45f);
                Quad(Inset(plate, -.9f), Black);
                Quad(plate, face);
                Segment(new Vector2(plate.xMin + .6f, plate.yMax - .5f), new Vector2(plate.xMax - .6f, plate.yMax - .5f), .8f,
                    WithAlpha(Color.Lerp(face, Color.white, .30f), .8f));
                float rivet = Mathf.Min(1.7f, plate.height * .1f);
                Disc(new Vector2(plate.xMin + 5.5f, plate.center.y), rivet, Scale(face, .4f), Scale(face, .4f), 8);
                Disc(new Vector2(plate.xMax - 5.5f, plate.center.y), rivet, Scale(face, .4f), Scale(face, .4f), 8);
            }

            if (GrilleSlots > 0 && Grille.width > 1f && Grille.height > 1f)
            {
                Rect grille = FromTop(r, Grille);
                float pitch = grille.width / GrilleSlots, slot = Mathf.Min(pitch * .46f, 3.6f);
                for (int i = 0; i < GrilleSlots; i++)
                {
                    float x = grille.xMin + i * pitch;
                    Quad(new Rect(x, grille.yMin, slot, grille.height), new Color(.02f, .02f, .02f, 1f));
                    Segment(new Vector2(x + slot + .3f, grille.yMin + 1f), new Vector2(x + slot + .3f, grille.yMax - 1f), .7f,
                        WithAlpha(Color.Lerp(color, Color.white, .16f), .75f));
                }
            }

            if (KeyCap.width > 1f && KeyCap.height > 1f)
            {
                Rect cap = FromTop(r, KeyCap);
                Quad(Inset(cap, -.8f), WithAlpha(Color.Lerp(color, Color.white, .22f), .85f));
                Quad(cap, new Color(.05f, .05f, .05f, 1f));
            }
        }

        private Rect GlassRect(Rect r) => Rect.MinMaxRect(r.xMin + ScreenInset.x, r.yMin + ScreenInset.w,
            r.xMax - ScreenInset.z, r.yMax - ScreenInset.y);

        private static Rect FromTop(Rect r, Rect local)
            => new Rect(r.xMin + local.x, r.yMax - local.y - local.height, local.width, local.height);

        private void Screw(Vector2 center, float degrees)
        {
            Color face = Color.Lerp(color, new Color(.3f, .3f, .3f, 1f), .5f);
            Disc(center, ScrewRadius + .8f, Black, Black, 14);
            Disc(center, ScrewRadius, Scale(face, 1.12f), Scale(face, .8f), 14);
            float angle = degrees * Mathf.Deg2Rad;
            Vector2 along = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * (ScrewRadius * .86f);
            Segment(center - along, center + along, Mathf.Max(.8f, ScrewRadius * .34f), new Color(.03f, .03f, .03f, 1f));
        }

        // ------------------------------------------------------------------ toggle switch

        private void DrawToggle(Rect r)
        {
            Vector2 c = r.center;
            float radius = Mathf.Min(r.width, r.height) * .40f;
            // Hexagonal nut of the switch bushing.
            int start = _mesh.currentVertCount;
            Add(c, new Color(.17f, .17f, .17f, 1f));
            for (int i = 0; i < 6; i++)
            {
                float angle = (i * 60f + 30f) * Mathf.Deg2Rad;
                Add(c + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * radius, Scale(new Color(.2f, .2f, .2f, 1f), i < 3 ? 1.15f : .8f));
            }
            for (int i = 0; i < 6; i++) _mesh.AddTriangle(start, start + 1 + i, start + 1 + (i + 1) % 6);
            Disc(c, radius * .56f, new Color(.03f, .03f, .03f, 1f), new Color(.06f, .06f, .06f, 1f), 14);
            Vector2 tip = c + new Vector2(-radius * .66f, radius * .86f);
            Segment(c, tip, radius * .36f, Scale(color, .82f));
            Disc(tip, radius * .25f, Color.Lerp(color, Color.white, .35f), color, 12);
        }

        // ------------------------------------------------------------------ edge of the picture tube

        private void DrawGlassEdge(Rect r)
        {
            float radius = Mathf.Min(GlassRadius, Mathf.Min(r.width, r.height) * .25f);
            // Rounded corners: the frame colour fills what a square panel would leave outside the tube.
            Corner(new Vector2(r.xMin, r.yMin), new Vector2(1f, 1f), radius);
            Corner(new Vector2(r.xMax, r.yMin), new Vector2(-1f, 1f), radius);
            Corner(new Vector2(r.xMax, r.yMax), new Vector2(-1f, -1f), radius);
            Corner(new Vector2(r.xMin, r.yMax), new Vector2(1f, -1f), radius);
            // The glass sits below the frame: a narrow shadow runs along its edge.
            float depth = Mathf.Min(5f, Mathf.Min(r.width, r.height) * .03f);
            Color shade = new Color(0f, 0f, 0f, .62f), clear = new Color(0f, 0f, 0f, 0f);
            Gradient(new Vector2(r.xMin, r.yMax), new Vector2(r.xMax, r.yMax), new Vector2(0f, -depth), shade, clear);
            Gradient(new Vector2(r.xMin, r.yMin), new Vector2(r.xMax, r.yMin), new Vector2(0f, depth), shade, clear);
            Gradient(new Vector2(r.xMin, r.yMin), new Vector2(r.xMin, r.yMax), new Vector2(depth, 0f), shade, clear);
            Gradient(new Vector2(r.xMax, r.yMin), new Vector2(r.xMax, r.yMax), new Vector2(-depth, 0f), shade, clear);
            // A faint reflection in the upper left corner; it never reaches the readable middle.
            // The project blends in linear space, where even one percent of white is clearly visible.
            int start = _mesh.currentVertCount;
            Add(new Vector2(r.xMin, r.yMax), WithAlpha(color, .008f));
            Add(new Vector2(r.xMin + r.width * .40f, r.yMax), WithAlpha(color, 0f));
            Add(new Vector2(r.xMin, r.yMax - r.height * .24f), WithAlpha(color, 0f));
            _mesh.AddTriangle(start, start + 1, start + 2);
        }

        private void Corner(Vector2 corner, Vector2 inward, float radius)
        {
            Vector2 centre = corner + inward * radius;
            const int steps = 6;
            int start = _mesh.currentVertCount;
            Add(corner, Frame);
            for (int i = 0; i <= steps; i++)
            {
                float angle = i * Mathf.PI * .5f / steps;
                Add(centre - new Vector2(Mathf.Cos(angle) * inward.x, Mathf.Sin(angle) * inward.y) * radius, Frame);
            }
            for (int i = 0; i < steps; i++) _mesh.AddTriangle(start, start + 1 + i, start + 2 + i);
        }

        private void Gradient(Vector2 from, Vector2 to, Vector2 depth, Color near, Color far)
        {
            int i = _mesh.currentVertCount;
            Add(from, near); Add(to, near); Add(to + depth, far); Add(from + depth, far);
            _mesh.AddTriangle(i, i + 1, i + 2); _mesh.AddTriangle(i, i + 2, i + 3);
        }

        // ------------------------------------------------------------------ lamp and the earlier parts

        private void DrawLed(Rect r)
        {
            Vector2 c = r.center;
            float radius = Mathf.Min(r.width, r.height) * .5f;
            Disc(c, radius, WithAlpha(color, color.a * .015f), WithAlpha(color, 0f));
            Disc(c, radius * .75f, WithAlpha(color, color.a * .16f), WithAlpha(color, 0f));
            Disc(c, radius * .36f, WithAlpha(color, color.a * .95f), WithAlpha(color, color.a * .35f));
            Disc(c + new Vector2(-.6f, .7f), radius * .14f, new Color(.95f, .95f, .95f, color.a), WithAlpha(color, color.a * .8f));
        }

        private void DrawPower(Rect r)
        {
            Vector2 c = r.center;
            float radius = Mathf.Min(r.width, r.height) * .46f;
            Disc(c, radius, new Color(.03f, .03f, .03f, 1f), new Color(.3f, .3f, .3f, 1f));
            Disc(c, radius - 1.5f, new Color(.1f, .1f, .1f, 1f), new Color(.13f, .13f, .13f, 1f));
            float glyph = radius * .48f;
            for (int i = 0; i < 24; i++)
            {
                float a = (40f + i * 280f / 24f) * Mathf.Deg2Rad, b = (40f + (i + 1) * 280f / 24f) * Mathf.Deg2Rad;
                Segment(c + new Vector2(Mathf.Sin(a), Mathf.Cos(a)) * glyph, c + new Vector2(Mathf.Sin(b), Mathf.Cos(b)) * glyph, 1.3f, color);
            }
            Segment(c + Vector2.up * glyph * 1.18f, c + Vector2.up * glyph * .1f, 1.5f, color);
        }

        private void DrawLegacyCase(Rect r)
        {
            Plate(r, 10f, new Color(.04f, .04f, .04f, 1f), new Color(.018f, .018f, .018f, 1f));
            Plate(Inset(r, 1.5f), 9f, new Color(.4f, .4f, .4f, 1f), new Color(.11f, .11f, .11f, 1f));
            Plate(Inset(r, 3.5f), 7f, new Color(.23f, .23f, .23f, 1f), new Color(.075f, .075f, .075f, 1f));
            Plate(Inset(r, 7f), 4f, color * 1.12f, color * .74f);
        }

        // ------------------------------------------------------------------ mesh helpers

        private static Color WithAlpha(Color c, float a) { c.a = a; return c; }
        private static Color Scale(Color c, float k) => new Color(Mathf.Clamp01(c.r * k), Mathf.Clamp01(c.g * k), Mathf.Clamp01(c.b * k), c.a);
        private static Rect Inset(Rect r, float n) => new Rect(r.x + n, r.y + n, r.width - n * 2f, r.height - n * 2f);

        private void Add(Vector2 position, Color tint) => _mesh.AddVert(position, tint, K_HealthGadgetNoise.SolidUV);

        private void Plate(Rect r, float cut, Color upper, Color lower)
        {
            cut = Mathf.Clamp(cut, 0f, Mathf.Min(r.width, r.height) * .25f);
            int start = _mesh.currentVertCount;
            Add(r.center, Color.Lerp(lower, upper, .5f));
            PlateVertex(r, r.xMin + cut, r.yMin, upper, lower);
            PlateVertex(r, r.xMin, r.yMin + cut, upper, lower);
            PlateVertex(r, r.xMin, r.yMax - cut, upper, lower);
            PlateVertex(r, r.xMin + cut, r.yMax, upper, lower);
            PlateVertex(r, r.xMax - cut, r.yMax, upper, lower);
            PlateVertex(r, r.xMax, r.yMax - cut, upper, lower);
            PlateVertex(r, r.xMax, r.yMin + cut, upper, lower);
            PlateVertex(r, r.xMax - cut, r.yMin, upper, lower);
            for (int i = 0; i < 8; i++) _mesh.AddTriangle(start, start + 1 + i, start + 1 + (i + 1) % 8);
        }

        private void PlateVertex(Rect r, float x, float y, Color upper, Color lower)
            => Add(new Vector2(x, y), Color.Lerp(lower, upper, Mathf.InverseLerp(r.yMin, r.yMax, y)));

        private void RoundedPlate(Rect r, float radius, Color upper, Color lower)
        {
            radius = Mathf.Clamp(radius, 0f, Mathf.Min(r.width, r.height) * .5f);
            const int steps = 5;
            int start = _mesh.currentVertCount;
            Add(r.center, Color.Lerp(lower, upper, .5f));
            int count = 0;
            for (int corner = 0; corner < 4; corner++)
            for (int i = 0; i <= steps; i++)
            {
                Vector2 point = RoundedPoint(r, radius, corner, i / (float)steps);
                Add(point, Color.Lerp(lower, upper, Mathf.InverseLerp(r.yMin, r.yMax, point.y)));
                count++;
            }
            for (int i = 0; i < count; i++) _mesh.AddTriangle(start, start + 1 + i, start + 1 + (i + 1) % count);
        }

        /// <summary>Outline of a rounded rectangle, lit from the upper left like a raised or recessed lip.</summary>
        private void RoundedStroke(Rect r, float radius, float width, Color lit, Color shaded)
        {
            radius = Mathf.Clamp(radius, 0f, Mathf.Min(r.width, r.height) * .5f);
            const int steps = 5;
            int start = _mesh.currentVertCount, count = 0;
            for (int corner = 0; corner < 4; corner++)
            for (int i = 0; i <= steps; i++)
            {
                Vector2 point = RoundedPoint(r, radius, corner, i / (float)steps);
                Vector2 outward = RoundedNormal(corner, i / (float)steps);
                Color tint = Color.Lerp(shaded, lit, Mathf.Clamp01(.5f + .9f * Vector2.Dot(outward, new Vector2(-.5f, .86f))));
                Add(point, tint);
                Add(point - outward * width, tint);
                count++;
            }
            for (int i = 0; i < count; i++)
            {
                int a = start + i * 2, b = start + ((i + 1) % count) * 2;
                _mesh.AddTriangle(a, b, b + 1);
                _mesh.AddTriangle(b + 1, a + 1, a);
            }
        }

        // Corners run counter-clockwise from the lower left; t sweeps each quarter arc.
        private static Vector2 RoundedPoint(Rect r, float radius, int corner, float t)
        {
            Vector2 centre = corner == 0 ? new Vector2(r.xMin + radius, r.yMin + radius)
                : corner == 1 ? new Vector2(r.xMax - radius, r.yMin + radius)
                : corner == 2 ? new Vector2(r.xMax - radius, r.yMax - radius)
                : new Vector2(r.xMin + radius, r.yMax - radius);
            return centre + RoundedNormal(corner, t) * radius;
        }

        private static Vector2 RoundedNormal(int corner, float t)
        {
            float angle = (180f + corner * 90f + t * 90f) * Mathf.Deg2Rad;
            return new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
        }

        private void Disc(Vector2 center, float radius, Color inner, Color outer, int segments = 32)
        {
            int start = _mesh.currentVertCount;
            Add(center, inner);
            for (int i = 0; i < segments; i++)
            {
                float angle = i * Mathf.PI * 2f / segments;
                Add(center + new Vector2(Mathf.Cos(angle), Mathf.Sin(angle)) * radius, outer);
            }
            for (int i = 0; i < segments; i++) _mesh.AddTriangle(start, start + 1 + i, start + 1 + (i + 1) % segments);
        }

        private void Segment(Vector2 a, Vector2 b, float width, Color tint)
        {
            Vector2 d = (b - a).normalized;
            Vector2 n = new Vector2(-d.y, d.x) * width * .5f;
            int i = _mesh.currentVertCount;
            Add(a - n, tint); Add(a + n, tint); Add(b + n, tint); Add(b - n, tint);
            _mesh.AddTriangle(i, i + 1, i + 2); _mesh.AddTriangle(i, i + 2, i + 3);
        }

        private void Quad(Rect r, Color tint)
        {
            if (r.width <= 0f || r.height <= 0f) return;
            int i = _mesh.currentVertCount;
            Add(new Vector2(r.xMin, r.yMin), tint); Add(new Vector2(r.xMin, r.yMax), tint);
            Add(new Vector2(r.xMax, r.yMax), tint); Add(new Vector2(r.xMax, r.yMin), tint);
            _mesh.AddTriangle(i, i + 1, i + 2); _mesh.AddTriangle(i, i + 2, i + 3);
        }

        /// <summary>
        /// Fine grain of the paint: the shared noise at about one screen pixel per speck. The specks are
        /// tinted with the case colour itself, so they only lighten or darken the paint by a few percent
        /// whatever colour is chosen, instead of sprinkling white dots over a dark case.
        /// </summary>
        private void GrainQuad(Rect r, float opacity)
        {
            if (r.width <= 0f || r.height <= 0f) return;
            float scale = canvas != null ? canvas.rootCanvas.scaleFactor : 1f;
            float texels = Mathf.Max(.01f, scale / 1.1f);
            Vector2 size = new Vector2(r.width * texels / K_HealthGadgetNoise.Size, r.height * texels / K_HealthGadgetNoise.Size);
            Color tint = Scale(color, 2f);
            tint.a = Mathf.Clamp01(opacity * 2f);
            int i = _mesh.currentVertCount;
            _mesh.AddVert(new Vector2(r.xMin, r.yMin), tint, new Vector2(.13f, .29f));
            _mesh.AddVert(new Vector2(r.xMin, r.yMax), tint, new Vector2(.13f, .29f + size.y));
            _mesh.AddVert(new Vector2(r.xMax, r.yMax), tint, new Vector2(.13f + size.x, .29f + size.y));
            _mesh.AddVert(new Vector2(r.xMax, r.yMin), tint, new Vector2(.13f + size.x, .29f));
            _mesh.AddTriangle(i, i + 1, i + 2); _mesh.AddTriangle(i, i + 2, i + 3);
        }
    }
}
