using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;

namespace K_Incident.Core.Inventory
{
    /// <summary>Short tap stows the device; a held wheel chord pages it without a cursor.</summary>
    [DisallowMultipleComponent]
    public sealed class K_HealthHudInput : MonoBehaviour
    {
        [SerializeField] private K_CompactHealthHud _hud;
        [SerializeField] private K_InventoryUI _inventory;
        [SerializeField, Tooltip("Короткое нажатие убирает или возвращает прибор. Прокрутка при удержании отменяет это действие. None отключает кнопку.")]
        private Key _toggleKey = Key.H;
        [SerializeField, Min(.05f), Tooltip("Максимальная длительность короткого нажатия в секундах. Долгое удержание не убирает прибор.")]
        private float _tapMaxSeconds = .35f;
        [SerializeField, Tooltip("Удерживайте эту клавишу и вращайте колесо для страниц эффектов. H свободна; Alt уже управляет приближением камеры. None отключает сочетание.")]
        private Key _modifier = Key.H;
        [SerializeField, Tooltip("Предыдущая страница без удержания клавиши HUD. None отключает эту кнопку.")]
        private Key _previousPageKey = Key.PageUp;
        [SerializeField, Tooltip("Следующая страница без удержания клавиши HUD. None отключает эту кнопку.")]
        private Key _nextPageKey = Key.PageDown;
        [SerializeField, Min(.01f), Tooltip("Единиц прокрутки на страницу: обычное колесо Windows — 120. Малые движения точного колеса накапливаются до этого порога.")]
        private float _wheelUnitsPerPage = 120f;

        private static readonly List<K_HealthHudInput> Active = new List<K_HealthHudInput>(1);
        private readonly HealthHudWheelAccumulator _wheel = new HealthHudWheelAccumulator();
        private string _controlHint;
        private string _toggleHint;
        private bool _tapPending, _tapUsedForPaging;
        private double _tapStartedAt;
        public string ControlHint => _controlHint ?? string.Empty;
        public string ToggleHint => _toggleHint ?? string.Empty;

        /// <summary>Computed from current device state, so camera/combat do not depend on MonoBehaviour Update order.</summary>
        public static bool ReservesScroll
        {
            get
            {
                var keyboard = Keyboard.current;
                if (keyboard == null || TextInputHasFocus()) return false;
                for (int i = Active.Count - 1; i >= 0; i--)
                {
                    var owner = Active[i];
                    if (owner == null) { Active.RemoveAt(i); continue; }
                    if (owner.CanUseDevice && (IsPressed(keyboard, owner._modifier) || IsPressed(keyboard, owner._toggleKey))) return true;
                }
                return false;
            }
        }

        private bool CanUseDevice => isActiveAndEnabled && _hud != null && _hud.CanTogglePower &&
            (_inventory == null || (!_inventory.IsOpen && !_inventory.IsDragging));

        private void OnEnable()
        {
            if (!Active.Contains(this)) Active.Add(this);
            ResetGesture();
            RefreshControlHint();
        }
        private void OnDisable() { Active.Remove(this); ResetGesture(); }
        private void OnDestroy() { Active.Remove(this); ResetGesture(); }
        private void OnValidate() { ResetGesture(); RefreshControlHint(); }
        private void OnApplicationFocus(bool focused) { if (!focused) ResetGesture(); }
        private void OnApplicationPause(bool paused) { if (paused) ResetGesture(); }

        private void ResetGesture()
        {
            _wheel.Reset();
            _tapPending = _tapUsedForPaging = false;
        }

        private void Update()
        {
            var keyboard = Keyboard.current;
            if (!CanUseDevice || keyboard == null || TextInputHasFocus()) { ResetGesture(); return; }

            if (WasPressed(keyboard, _toggleKey))
            {
                _tapPending = true;
                _tapUsedForPaging = false;
                _tapStartedAt = Time.unscaledTimeAsDouble;
            }

            float scroll = Mouse.current != null ? Mouse.current.scroll.ReadValue().y : 0f;
            // Even a partial notch or a one-page display makes this a wheel gesture, not a tap.
            if (_tapPending && scroll != 0f) _tapUsedForPaging = true;
            bool previous = WasPressed(keyboard, _previousPageKey), next = WasPressed(keyboard, _nextPageKey);
            if (previous || next)
            {
                if (_tapPending) _tapUsedForPaging = true;
                if (_hud.IsVisible) ChangePage(previous ? -1 : 1);
            }

            if (_hud.IsVisible && IsPressed(keyboard, _modifier) && Mouse.current != null)
            {
                int turns = _wheel.Consume(scroll, _wheelUnitsPerPage);
                int direction = turns < 0 ? 1 : -1;
                int count = turns < 0 ? -turns : turns;
                for (int i = 0; i < count; i++) ChangePage(direction);
            }
            else _wheel.Reset();

            if (WasReleased(keyboard, _toggleKey))
            {
                double elapsed = Time.unscaledTimeAsDouble - _tapStartedAt;
                float max = !float.IsNaN(_tapMaxSeconds) && !float.IsInfinity(_tapMaxSeconds) ? System.Math.Max(.05f, System.Math.Min(2f, _tapMaxSeconds)) : .35f;
                bool toggle = _tapPending && !_tapUsedForPaging && elapsed >= 0d && elapsed <= max + 1e-9d;
                _tapPending = _tapUsedForPaging = false;
                if (toggle) _hud.TogglePower();
            }
            else if (_tapPending && !IsPressed(keyboard, _toggleKey))
                _tapPending = _tapUsedForPaging = false; // A device reset is not a release gesture.
        }

        private void ChangePage(int direction)
        {
            // Still reserve the chord on one page: it must never unexpectedly switch the weapon instead.
            if (_hud.CanPage) _hud.ChangePage(direction);
        }

        private static bool ValidKey(Key key) => key > Key.None && key <= Key.MediaForward &&
            (int)key != (int)Key.OEM5 + 1; // The obsolete IME-selected dummy slot is not a physical key.
        private static bool IsPressed(Keyboard keyboard, Key key) => ValidKey(key) && keyboard[key].isPressed;
        private static bool WasPressed(Keyboard keyboard, Key key) => ValidKey(key) && keyboard[key].wasPressedThisFrame;
        private static bool WasReleased(Keyboard keyboard, Key key) => ValidKey(key) && keyboard[key].wasReleasedThisFrame;

        private static bool TextInputHasFocus()
        {
            var selected = EventSystem.current != null ? EventSystem.current.currentSelectedGameObject : null;
            if (selected == null) return false;
            var tmp = selected.GetComponentInParent<TMPro.TMP_InputField>();
            if (tmp != null && tmp.isFocused) return true;
            var legacy = selected.GetComponentInParent<UnityEngine.UI.InputField>();
            return legacy != null && legacy.isFocused;
        }

        private void RefreshControlHint()
        {
            _toggleHint = ValidKey(_toggleKey) ? KeyName(_toggleKey) : string.Empty;
            if (ValidKey(_modifier)) _controlHint = KeyName(_modifier) + " + колесо";
            else if (ValidKey(_previousPageKey) && ValidKey(_nextPageKey))
                _controlHint = KeyName(_previousPageKey) + " / " + KeyName(_nextPageKey);
            else if (ValidKey(_previousPageKey)) _controlHint = KeyName(_previousPageKey);
            else if (ValidKey(_nextPageKey)) _controlHint = KeyName(_nextPageKey);
            else _controlHint = string.Empty;
        }
        private static string KeyName(Key key)
        {
            switch (key)
            {
                case Key.LeftAlt: return "LAlt";
                case Key.RightAlt: return "RAlt";
                case Key.LeftCtrl: return "LCtrl";
                case Key.RightCtrl: return "RCtrl";
                case Key.LeftShift: return "LShift";
                case Key.RightShift: return "RShift";
                case Key.PageUp: return "PgUp";
                case Key.PageDown: return "PgDn";
                default: return key.ToString();
            }
        }
    }
}
