using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// One small grain texture shared by both health gadgets: television "snow" while a screen warms up
    /// and the fine grain of the painted case. It is generated once from a fixed hash, so it never
    /// touches UnityEngine.Random and looks the same in every session.
    /// </summary>
    internal static class K_HealthGadgetNoise
    {
        public const int Size = 128;
        private static Texture2D _texture;

        /// <summary>Centre of the single white texel: plain coloured geometry samples it and stays untextured.</summary>
        public static Vector2 SolidUV => new Vector2(.5f / Size, .5f / Size);

        public static Texture2D Texture
        {
            get
            {
                if (_texture == null) Build();
                return _texture;
            }
        }

        private static void Build()
        {
            _texture = new Texture2D(Size, Size, TextureFormat.RGBA32, false)
            {
                name = "Health gadget grain",
                filterMode = FilterMode.Point,
                wrapMode = TextureWrapMode.Repeat,
                // Not saved with scenes or builds, yet still released once nothing refers to it.
                hideFlags = HideFlags.HideInHierarchy | HideFlags.DontSaveInEditor | HideFlags.DontSaveInBuild
            };
            var pixels = new Color32[Size * Size];
            byte held = 0;
            for (int i = 0; i < pixels.Length; i++)
            {
                // An occasional doubled speck keeps the grain from reading as digital dither.
                if (i % Size == 0 || Hash(i * 7 + 3) > .14f) held = (byte)(Mathf.Pow(Hash(i * 13 + 1), 1.35f) * 255f);
                pixels[i] = new Color32(held, held, held, 255);
            }
            pixels[0] = new Color32(255, 255, 255, 255);
            _texture.SetPixels32(pixels);
            _texture.Apply(false, true);
        }

        public static float Hash(int seed)
        {
            unchecked
            {
                uint bits = (uint)(seed + 1) * 747796405u + 2891336453u;
                bits = ((bits >> (int)((bits >> 28) + 4)) ^ bits) * 277803737u;
                bits = (bits >> 22) ^ bits;
                return (bits & 0x00ffffffu) / 16777215f;
            }
        }
    }
}
