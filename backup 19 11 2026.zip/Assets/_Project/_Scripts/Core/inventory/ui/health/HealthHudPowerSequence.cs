using System;

namespace K_Incident.Core.Inventory
{
    /// <summary>Reversible screen power and case travel, advanced only by its owner.</summary>
    public sealed class HealthHudPowerSequence
    {
        private double _extension = 1d;
        private double _screenPower = 1d;

        public float Extension => (float)_extension;
        public float ScreenPower => (float)_screenPower;
        public bool RequestedExpanded { get; private set; } = true;
        public bool IsReady => RequestedExpanded && _extension == 1d && _screenPower == 1d;
        public bool IsStowed => !RequestedExpanded && _extension == 0d && _screenPower == 0d;

        public void Toggle() => SetExpanded(!RequestedExpanded);
        public void SetExpanded(bool expanded) => RequestedExpanded = expanded;

        public void Tick(float delta, float offSeconds, float travelSeconds, float bootSeconds)
        {
            if (!Finite(delta) || delta <= 0f) return;
            double remaining = delta;
            if (RequestedExpanded)
            {
                Move(ref _extension, 1d, Duration(travelSeconds), ref remaining);
                if (_extension == 1d)
                    Move(ref _screenPower, 1d, Duration(bootSeconds), ref remaining);
            }
            else
            {
                Move(ref _screenPower, 0d, Duration(offSeconds), ref remaining);
                if (_screenPower == 0d)
                    Move(ref _extension, 0d, Duration(travelSeconds), ref remaining);
            }
        }

        private static void Move(ref double value, double target, double seconds, ref double remaining)
        {
            if (remaining <= 0d || value == target) return;
            double needed = Math.Abs(target - value) * seconds;
            if (remaining >= needed)
            {
                value = target;
                remaining -= needed;
                return;
            }
            value += (target > value ? 1d : -1d) * remaining / seconds;
            remaining = 0d;
        }

        private static double Duration(float seconds) => Finite(seconds) ? Math.Max(.01d, seconds) : .01d;
        private static bool Finite(float value) => !float.IsNaN(value) && !float.IsInfinity(value);
    }
}
