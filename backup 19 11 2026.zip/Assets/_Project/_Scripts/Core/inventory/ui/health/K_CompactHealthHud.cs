using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Fixed-size, read-only field display. Player systems own all values and timers.</summary>
    [DisallowMultipleComponent]
    [RequireComponent(typeof(RectTransform))]
    [AddComponentMenu("INCIDENT/UI/Compact Health HUD")]
    public sealed class K_CompactHealthHud : MonoBehaviour
    {
        [Header("Источники состояния")]
        [SerializeField] private K_HealthSystem _health;
        [SerializeField] private K_VitalitySystem _vitality;
        [SerializeField] private K_DebuffSystem _debuffs;
        [SerializeField] private K_BloodSystem _blood;
        [SerializeField] private K_WeightManager _weight;
        [SerializeField, Tooltip("Инвентарь скрывает малый экран, пока открыт большой интерфейс.")]
        private K_InventoryUI _inventory;
        [SerializeField] private K_HealthVisualStyle _visualStyle;
        [SerializeField] private TMP_FontAsset _font;
        [SerializeField, Tooltip("Те же назначенные иконки, что на большом гаджете. Source позволяет позже назначить новый спрайт один раз.")]
        private K_HealthStatusGadget.IconBinding[] _icons = Array.Empty<K_HealthStatusGadget.IconBinding>();
        [SerializeField, Tooltip("Нормализованная кукла из 20 сегментов. Цветами по-прежнему управляет существующий K_HealthWidget.")]
        private RectTransform _dollRoot;

        [Header("Постоянный размер и положение")]
        [SerializeField, Min(360f), Tooltip("Ширина корпуса в единицах Canvas. Количество эффектов её не меняет.")]
        private float _width = 380f;
        [SerializeField, Min(420f), Tooltip("Высота корпуса в единицах Canvas. Две строки эффектов остаются на месте при любом их количестве.")]
        private float _height = 450f;
        [SerializeField, Min(0f), Tooltip("Отступ от правого края Canvas.")]
        private float _rightMargin = 18f;
        [SerializeField, Min(0f), Tooltip("Отступ от нижнего края Canvas.")]
        private float _bottomMargin = 18f;
        [SerializeField, Range(.38f, .52f), Tooltip("Доля ширины верхней области под куклу. Остальное занимают шесть индикаторов.")]
        private float _dollWidthFraction = .46f;
        [SerializeField, Range(28f, 40f), Tooltip("Размер иконки эффекта. При уменьшении корпуса ограничивается размером ячейки.")]
        private float _effectIconSize = 36f;
        [SerializeField, Range(11f, 17f), Tooltip("Основной размер чисел. Заголовки и короткие подписи чуть меньше.")]
        private float _fontSize = 14f;
        [SerializeField, Range(.1f, .5f), Tooltip("Как часто читать состояние персонажа. Таймеры принадлежат игровым системам и не зависят от видимости экрана.")]
        private float _refreshInterval = .15f;

        [Header("Корпус и стекло")]
        [SerializeField] private Color _foreground = new Color(159f / 255f, 159f / 255f, 159f / 255f, 1f);
        [SerializeField] private Color _caseColor = new Color(.075f, .075f, .075f, 1f);
        [SerializeField, Range(0f, .03f), Tooltip("Очень слабая фактура экрана. 0 полностью убирает линии. Помехи поверх показаний во время игры не включаются.")]
        private float _screenTexture = .008f;
        [SerializeField, Range(0f, 40f), Tooltip("Высота нижней планки корпуса с шильдиком и лампой. Она добавляется к высоте корпуса снизу, экран остаётся прежнего размера. 0 убирает планку.")]
        private float _controlStrip = 24f;
        [SerializeField, Tooltip("Надпись на шильдике малого прибора. Пустая строка убирает шильдик.")]
        private string _nameplateText = "ПКС-3К «ПУЛЬС»";
        [SerializeField, Range(0f, .12f), Tooltip("Зерно окраски корпуса. 0 — гладкая краска.")]
        private float _caseGrain = .05f;

        [Header("Убрать и включить прибор")]
        [SerializeField, Range(.05f, .5f), Tooltip("Время гашения экрана перед тем, как убрать корпус.")]
        private float _powerOffSeconds = .18f;
        [SerializeField, Range(.1f, .8f), Tooltip("Время перемещения корпуса за край экрана и обратно.")]
        private float _travelSeconds = .28f;
        [SerializeField, Range(.2f, 1.5f), Tooltip("Длительность включения с помехами после возвращения корпуса.")]
        private float _bootSeconds = .5f;

        private sealed class IndicatorView
        {
            public RectTransform Rect;
            public UnityEngine.UI.Image Icon, Fill;
            public TMP_Text Title, Value;
        }

        private sealed class EffectView
        {
            public RectTransform Rect;
            public UnityEngine.UI.Image Icon;
            public TMP_Text Fallback, Value;
        }

        private readonly List<HealthGadgetEntry> _effects = new List<HealthGadgetEntry>(32);
        private readonly List<HealthGadgetEntry> _indicators = new List<HealthGadgetEntry>(6);
        private readonly K_CompactHealthHudModel _model = new K_CompactHealthHudModel();
        private readonly HealthHudPowerSequence _power = new HealthHudPowerSequence();
        private readonly K_HealthColorAnimator _indicatorColors = new K_HealthColorAnimator();
        private readonly IndicatorView[] _indicatorViews = new IndicatorView[6];
        private readonly EffectView[] _effectViews = new EffectView[K_CompactHealthHudModel.PageSize];
        private RectTransform _rect, _visualRoot, _screen, _dollHost, _indicatorArea, _effectsArea;
        private UnityEngine.UI.Image _bodyDivider, _effectsDivider;
        private TMP_Text _heading, _effectsHeading, _empty, _pageText, _controlHint, _previousLabel, _nextLabel, _stowedHint;
        private TMP_Text _nameplateLabel, _mainsLabel, _keyLabel;
        private UnityEngine.UI.Button _previous, _next;
        private K_HealthGadgetHardwareGraphic _led, _shell, _glassEdge;
        private K_HealthGadgetScreenFX _glass;
        private K_HealthGadgetScreenFX _powerFx;
        private UnityEngine.UI.Image _blackout;
        private CanvasGroup _screenGroup;
        private K_HealthHudInput _input;
        private CanvasGroup[] _parentGroups;
        private bool _built, _layoutDirty = true;
        private float _nextRefresh, _flashUntil;
        private int _flashDirection;
        private Vector2 _authoredDollSize;

        public int PageCount => _model.PageCount;
        public int CurrentPage => _model.CurrentPage;
        public int EffectCount => _model.EffectCount;
        public bool CanPage => IsVisible && PageCount > 1;
        public bool IsExpanded => _power.RequestedExpanded;
        public bool IsStowed => _power.IsStowed;
        public RectTransform DollHost { get { EnsureBuilt(); return _dollHost; } }
        public bool IsVisible => CanTogglePower && _power.IsReady;
        public bool CanTogglePower
        {
            get
            {
                if (!_built || !isActiveAndEnabled || _visualRoot == null || !_visualRoot.gameObject.activeInHierarchy || (_inventory != null && _inventory.IsOpen)) return false;
                if (_parentGroups != null)
                    for (int i = 0; i < _parentGroups.Length; i++)
                        if (_parentGroups[i] != null && _parentGroups[i].alpha <= .01f) return false;
                return true;
            }
        }

        private void Awake() => EnsureBuilt();
        private void Start() => RefreshNow();
        private void OnValidate() => _layoutDirty = true;
        private void OnEnable() { _nextRefresh = 0f; }
        private void OnDisable()
        {
            if (_visualRoot != null) _visualRoot.gameObject.SetActive(false);
            if (_stowedHint != null) _stowedHint.gameObject.SetActive(false);
        }

        private void Update()
        {
            EnsureBuilt();
            bool visible = _inventory == null || !_inventory.IsOpen;
            if (_visualRoot.gameObject.activeSelf != visible) _visualRoot.gameObject.SetActive(visible);
            if (_layoutDirty) ApplyLayout();
            if (visible) _power.Tick(Time.unscaledDeltaTime, _powerOffSeconds, _travelSeconds, _bootSeconds);
            ApplyPowerVisuals(visible);
            if (Time.unscaledTime >= _nextRefresh)
            {
                _nextRefresh = Time.unscaledTime + Mathf.Clamp(Safe(_refreshInterval, .15f), .1f, .5f);
                RefreshNow();
            }
        }

        private void LateUpdate()
        {
            if (!CanTogglePower) return;
            _indicatorColors.Tick(Time.unscaledDeltaTime);
            float alpha = (.68f + Mathf.Sin(Time.unscaledTime * 1.4f) * .12f) * _power.ScreenPower;
            _led.color = new Color(_foreground.r, _foreground.g, _foreground.b, alpha);
            bool flashing = Time.unscaledTime < _flashUntil;
            SetArrowColor(_previous, flashing && _flashDirection < 0);
            SetArrowColor(_next, flashing && _flashDirection > 0);
        }

        public void TogglePower()
        {
            if (!CanTogglePower) return;
            _power.Toggle();
            if (_power.RequestedExpanded) RefreshNow();
            ApplyPowerVisuals(true);
        }

        private void ApplyPowerVisuals(bool available)
        {
            float tucked = 1f - Mathf.SmoothStep(0f, 1f, _power.Extension);
            // Include authored margins so the remaining corner meets the actual Canvas edge.
            Vector2 offset = new Vector2((_rect.rect.width - _rect.anchoredPosition.x - 62f) * tucked,
                -(_rect.rect.height + _rect.anchoredPosition.y - 14f) * tucked);
            if (_visualRoot.anchoredPosition != offset) _visualRoot.anchoredPosition = offset;
            float power = _power.ScreenPower;
            bool transient = power > 0f && power < 1f;
            // Hold the readings black through the noisy part, then let the signal settle.
            float reveal = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(.48f, .84f, power));
            _blackout.enabled = !_power.IsReady;
            _blackout.color = new Color(.004f, .004f, .004f, 1f - reveal);
            _powerFx.enabled = transient;
            if (transient)
            {
                // Coming back: the tube warms up through snow. Putting away: the picture folds into a line.
                if (_power.RequestedExpanded) _powerFx.SetPhase(power, 1f, 0f, _foreground);
                else _powerFx.SetPowerOff(power, _foreground);
            }
            _screenGroup.interactable = _screenGroup.blocksRaycasts = available && _power.IsReady;
            _stowedHint.gameObject.SetActive(available && _power.IsStowed);
            SetText(_stowedHint, _input != null ? _input.ToggleHint : string.Empty);
        }

        private void SetArrowColor(UnityEngine.UI.Button button, bool highlighted)
        {
            if (button == null || button.targetGraphic == null) return;
            button.targetGraphic.color = highlighted ? new Color(.28f, .28f, .28f, 1f) : new Color(.095f, .095f, .095f, 1f);
        }

        public bool ChangePage(int direction)
        {
            if (!CanPage || direction == 0 || !_model.ChangePage(direction)) return false;
            _flashDirection = direction < 0 ? -1 : 1;
            _flashUntil = Time.unscaledTime + .25f;
            PresentEffects();
            return true;
        }

        public void RefreshNow()
        {
            EnsureBuilt();
            if (!_built) return;
            K_HealthGadgetContent.Collect(_effects, _indicators, _health, _vitality, _debuffs, _blood, _weight);
            _model.Refresh(_effects);
            for (int i = 0; i < _indicatorViews.Length; i++) PresentIndicator(_indicatorViews[i], i < _indicators.Count ? _indicators[i] : null);
            PresentEffects();
        }

        private void PresentIndicator(IndicatorView view, HealthGadgetEntry entry)
        {
            bool hasEntry = entry != null;
            SetText(view.Title, hasEntry ? entry.Title : "—");
            SetText(view.Value, hasEntry ? entry.CompactValue ?? entry.Value : "—");
            var sprite = hasEntry ? ResolveSprite(entry.Kind) : null;
            view.Icon.sprite = sprite;
            view.Icon.enabled = sprite != null;
            float value = hasEntry ? Mathf.Clamp01(entry.NormalizedValue) : 0f;
            view.Fill.rectTransform.anchorMax = new Vector2(value, 1f);
            float healthy = value;
            if (hasEntry && (entry.Kind == HealthGadgetKind.Cold || entry.Kind == HealthGadgetKind.Radiation)) healthy = 1f - value;
            if (hasEntry && entry.Kind == HealthGadgetKind.Overload) healthy = _weight != null ? Mathf.Clamp01(_weight.GetSpeedMultiplier()) : 1f - value;
            Color color = _visualStyle != null ? _visualStyle.Evaluate(healthy) : _foreground;
            float seconds = _visualStyle != null ? _visualStyle.TransitionSeconds : .35f;
            _indicatorColors.SetTarget(view.Icon, color, seconds);
            _indicatorColors.SetTarget(view.Fill, color, seconds);
        }

        private void PresentEffects()
        {
            SetText(_effectsHeading, "ЭФФЕКТЫ · " + _model.EffectCount);
            for (int i = 0; i < _effectViews.Length; i++)
            {
                var view = _effectViews[i];
                var entry = _model.GetVisible(i);
                bool visible = entry != null;
                if (view.Rect.gameObject.activeSelf != visible) view.Rect.gameObject.SetActive(visible);
                if (!visible) continue;
                var sprite = ResolveSprite(entry.Kind);
                view.Icon.sprite = sprite;
                view.Icon.enabled = sprite != null;
                view.Fallback.gameObject.SetActive(sprite == null);
                SetText(view.Fallback, entry.CompactTitle ?? entry.Title);
                SetText(view.Value, entry.CompactValue ?? entry.Value);
            }
            _empty.gameObject.SetActive(_model.EffectCount == 0);
            SetText(_pageText, (_model.CurrentPage + 1) + " / " + _model.PageCount);
            _previous.interactable = _model.PageCount > 1 && _model.CurrentPage > 0;
            _next.interactable = _model.PageCount > 1 && _model.CurrentPage + 1 < _model.PageCount;
            _previousLabel.color = new Color(_foreground.r, _foreground.g, _foreground.b, _previous.interactable ? 1f : .3f);
            _nextLabel.color = new Color(_foreground.r, _foreground.g, _foreground.b, _next.interactable ? 1f : .3f);
            if (_input == null) _input = GetComponent<K_HealthHudInput>();
            string hide = _input != null && !string.IsNullOrEmpty(_input.ToggleHint) ? _input.ToggleHint + " · убрать" : string.Empty;
            SetText(_keyLabel, _input != null ? _input.ToggleHint : string.Empty);
            SetText(_controlHint, _model.PageCount > 1 && _input != null ? hide + " / " + _input.ControlHint : hide);
        }

        private Sprite ResolveSprite(HealthGadgetKind kind)
        {
            for (int i = 0; _icons != null && i < _icons.Length; i++)
            {
                var binding = _icons[i];
                if (binding == null || binding.Kind != kind) continue;
                return binding.Source != null && binding.Source.sprite != null ? binding.Source.sprite : binding.Sprite;
            }
            return null;
        }

        public void EnsureBuilt()
        {
            // Runtime hierarchy is deliberately absent from the saved scene.
            if (_built || !Application.isPlaying) return;
            _built = true;
            _rect = (RectTransform)transform;
            _parentGroups = GetComponentsInParent<CanvasGroup>(true);
            _input = GetComponent<K_HealthHudInput>();
            _visualRoot = Rect("FieldDisplay", transform);
            _shell = _visualRoot.gameObject.AddComponent<K_HealthGadgetHardwareGraphic>();
            _shell.Mode = K_HealthGadgetHardwareGraphic.Shape.Body;
            _shell.color = _caseColor; _shell.raycastTarget = false;
            _screen = Rect("Screen", _visualRoot);
            var screenImage = _screen.gameObject.AddComponent<UnityEngine.UI.Image>();
            screenImage.color = new Color(.008f, .009f, .01f, 1f); screenImage.raycastTarget = false;
            _screen.gameObject.AddComponent<UnityEngine.UI.RectMask2D>();
            _screenGroup = _screen.gameObject.AddComponent<CanvasGroup>();
            _heading = Text("Heading", _screen, "СОСТОЯНИЕ", _fontSize);
            _led = Rect("PowerLight", _screen).gameObject.AddComponent<K_HealthGadgetHardwareGraphic>();
            _led.Mode = K_HealthGadgetHardwareGraphic.Shape.Led; _led.color = _foreground; _led.raycastTarget = false;
            _dollHost = Rect("DollHost", _screen);
            _bodyDivider = Image("BodyDivider", _screen, new Color(_foreground.r, _foreground.g, _foreground.b, .28f));
            _indicatorArea = Rect("Indicators", _screen);
            for (int i = 0; i < _indicatorViews.Length; i++) _indicatorViews[i] = BuildIndicator(i);
            _effectsDivider = Image("EffectsDivider", _screen, new Color(_foreground.r, _foreground.g, _foreground.b, .32f));
            _effectsHeading = Text("EffectsHeading", _screen, "ЭФФЕКТЫ · 0", 11f);
            _effectsArea = Rect("Effects", _screen);
            for (int i = 0; i < _effectViews.Length; i++) _effectViews[i] = BuildEffect(i);
            _empty = Text("NoEffects", _effectsArea, "Активных эффектов нет", 13f);
            _empty.alignment = TextAlignmentOptions.Center;
            _previous = BuildArrow("PreviousPage", "‹", -1);
            _next = BuildArrow("NextPage", "›", 1);
            _pageText = Text("Page", _screen, "1 / 1", 12f); _pageText.alignment = TextAlignmentOptions.Center;
            _controlHint = Text("ControlHint", _screen, string.Empty, 10f);
            _controlHint.color = new Color(_foreground.r, _foreground.g, _foreground.b, .65f);
            var glassRect = Rect("Glass", _screen);
            Stretch(glassRect);
            _glass = glassRect.gameObject.AddComponent<K_HealthGadgetScreenFX>();
            _glass.SetPhase(1f, 0f, Mathf.Clamp(_screenTexture, 0f, .03f), _foreground);
            // Glass texture belongs behind the readings: scanlines must not cut up fine sprites.
            glassRect.SetAsFirstSibling();
            // Only startup/shutdown cover the readings; the resting glass stays behind them.
            _blackout = Image("PoweredOff", _screen, new Color(.004f, .004f, .004f, 1f));
            Stretch(_blackout.rectTransform);
            _powerFx = Rect("PowerTransition", _screen).gameObject.AddComponent<K_HealthGadgetScreenFX>();
            Stretch(_powerFx.rectTransform);
            _powerFx.raycastTarget = false;
            // Rounded edge of the tube stays above everything the screen shows.
            _glassEdge = Rect("GlassEdge", _screen).gameObject.AddComponent<K_HealthGadgetHardwareGraphic>();
            _glassEdge.Mode = K_HealthGadgetHardwareGraphic.Shape.GlassEdge;
            _glassEdge.color = Color.white; _glassEdge.raycastTarget = false; _glassEdge.GlassRadius = 6f;
            Stretch(_glassEdge.rectTransform);
            // Stamped lettering of the control strip.
            _nameplateLabel = Text("Nameplate", _visualRoot, _nameplateText ?? string.Empty, 10.5f);
            _nameplateLabel.alignment = TextAlignmentOptions.Center;
            _nameplateLabel.characterSpacing = 12f;
            _nameplateLabel.overflowMode = TextOverflowModes.Overflow;
            _nameplateLabel.color = new Color(.6f, .6f, .6f, 1f);
            _mainsLabel = Text("MainsLabel", _visualRoot, "СЕТЬ", 9f);
            _mainsLabel.alignment = TextAlignmentOptions.MidlineRight;
            _mainsLabel.characterSpacing = 10f;
            _mainsLabel.overflowMode = TextOverflowModes.Overflow;
            _mainsLabel.color = new Color(.42f, .42f, .42f, 1f);
            _keyLabel = Text("KeyLabel", _visualRoot, string.Empty, 8.6f);
            _keyLabel.alignment = TextAlignmentOptions.Center;
            _keyLabel.overflowMode = TextOverflowModes.Overflow;
            _keyLabel.color = new Color(.54f, .54f, .54f, 1f);
            _stowedHint = Text("StowedKey", transform, string.Empty, 11f);
            _stowedHint.alignment = TextAlignmentOptions.Center;
            _stowedHint.color = new Color(_foreground.r, _foreground.g, _foreground.b, .65f);
            for (int i = 0; i < 3; i++)
            {
                var grip = Image("Grip_" + i, _visualRoot, new Color(.27f, .27f, .27f, 1f));
                SetRect(grip.rectTransform, 18f + i * 7f, 1f, 2f, 3f);
            }
            if (_dollRoot != null)
            {
                _authoredDollSize = _dollRoot.rect.size;
                _dollRoot.SetParent(_dollHost, false);
                _dollRoot.anchorMin = _dollRoot.anchorMax = new Vector2(.5f, .5f);
                _dollRoot.pivot = new Vector2(.5f, .5f);
                _dollRoot.anchoredPosition = Vector2.zero;
                _dollRoot.sizeDelta = _authoredDollSize;
                _dollRoot.gameObject.SetActive(true);
            }
            ApplyLayout();
            ApplyPowerVisuals(_inventory == null || !_inventory.IsOpen);
        }

        private IndicatorView BuildIndicator(int i)
        {
            var view = new IndicatorView { Rect = Rect("Indicator_" + i, _indicatorArea) };
            view.Icon = Image("Icon", view.Rect, _foreground); view.Icon.preserveAspect = true;
            view.Title = Text("Name", view.Rect, string.Empty, 11f);
            view.Value = Text("Value", view.Rect, "—", _fontSize);
            view.Value.alignment = TextAlignmentOptions.MidlineRight;
            var track = Image("Track", view.Rect, new Color(_foreground.r, _foreground.g, _foreground.b, .13f));
            view.Fill = Image("Fill", track.transform, _foreground);
            Stretch(view.Fill.rectTransform);
            view.Fill.rectTransform.anchorMax = new Vector2(0f, 1f);
            return view;
        }

        private EffectView BuildEffect(int i)
        {
            var view = new EffectView { Rect = Rect("Effect_" + i, _effectsArea) };
            var background = view.Rect.gameObject.AddComponent<UnityEngine.UI.Image>();
            background.color = new Color(.032f, .032f, .032f, 1f);
            background.raycastTarget = false;
            view.Icon = Image("Icon", view.Rect, _foreground); view.Icon.preserveAspect = true;
            view.Fallback = Text("UnassignedIconName", view.Rect, string.Empty, 11f);
            view.Fallback.alignment = TextAlignmentOptions.Center;
            view.Fallback.textWrappingMode = TextWrappingModes.Normal;
            view.Value = Text("Value", view.Rect, string.Empty, 12f);
            view.Value.alignment = TextAlignmentOptions.Center;
            view.Value.enableAutoSizing = true;
            view.Value.fontSizeMin = 10f;
            view.Value.fontSizeMax = 12f;
            return view;
        }

        private UnityEngine.UI.Button BuildArrow(string name, string glyph, int direction)
        {
            var image = Image(name, _screen, new Color(.095f, .095f, .095f, 1f)); image.raycastTarget = true;
            var button = image.gameObject.AddComponent<UnityEngine.UI.Button>(); button.targetGraphic = image;
            button.transition = UnityEngine.UI.Selectable.Transition.None;
            var navigation = button.navigation; navigation.mode = UnityEngine.UI.Navigation.Mode.None; button.navigation = navigation;
            button.onClick.AddListener(() => ChangePage(direction));
            var label = Text("Arrow", image.transform, glyph, 17f); label.alignment = TextAlignmentOptions.Center; Stretch(label.rectTransform);
            if (direction < 0) _previousLabel = label; else _nextLabel = label;
            return button;
        }

        private void ApplyLayout()
        {
            _layoutDirty = false;
            float width = Mathf.Clamp(Safe(_width, 380f), 360f, 700f);
            float height = Mathf.Clamp(Safe(_height, 450f), 420f, 700f);
            _rect.anchorMin = _rect.anchorMax = new Vector2(1f, 0f);
            _rect.pivot = new Vector2(1f, 0f);
            _rect.anchoredPosition = new Vector2(-Mathf.Max(0f, Safe(_rightMargin, 18f)), Mathf.Max(0f, Safe(_bottomMargin, 18f)));
            // The control strip is added under the screen; the screen keeps the size set above.
            float strip = Mathf.Clamp(Safe(_controlStrip, 24f), 0f, 40f);
            if (strip < 14f) strip = 0f;
            float caseHeight = height + strip;
            _rect.sizeDelta = new Vector2(width, caseHeight);
            SetRect(_visualRoot, 0f, 0f, width, caseHeight);
            SetRect(_screen, 10f, 10f, width - 20f, height - 20f);
            float sw = width - 20f, sh = height - 20f;
            SetRect(_heading.rectTransform, 12f, 10f, sw - 50f, 21f);
            var lamp = (RectTransform)_led.transform;
            if (strip > 0f)
            {
                if (lamp.parent != _visualRoot) lamp.SetParent(_visualRoot, false);
                SetRect(lamp, width - 50f, height - 4f + (strip - 15f) * .5f, 15f, 15f);
            }
            else
            {
                if (lamp.parent != _screen) { lamp.SetParent(_screen, false); lamp.SetSiblingIndex(1); }
                SetRect(lamp, sw - 29f, 13f, 15f, 15f);
            }
            float innerWidth = sw - 24f;
            const int columns = 4;
            const float columnGap = 10f, rowGap = 8f;
            float cellWidth = (innerWidth - columnGap * (columns - 1)) / columns;
            float effectIcon = Mathf.Min(Mathf.Clamp(Safe(_effectIconSize, 36f), 28f, 40f), cellWidth - 8f);
            float effectRowHeight = effectIcon + 20f;
            float effectAreaHeight = effectRowHeight * 2f + rowGap;
            float effectsTop = sh - effectAreaHeight - 50f;
            float bodyTop = 40f, bodyHeight = effectsTop - bodyTop - 12f;
            float dollWidth = innerWidth * Mathf.Clamp(Safe(_dollWidthFraction, .46f), .38f, .52f);
            // Give the silhouette the spare vertical margins without moving the indicator rows.
            float dollHeight = bodyHeight + 16f;
            SetRect(_dollHost, 12f, bodyTop - 8f, dollWidth, dollHeight);
            SetRect(_bodyDivider.rectTransform, dollWidth + 19f, bodyTop + 2f, 1f, bodyHeight - 4f);
            float indicatorWidth = innerWidth - dollWidth - 16f;
            SetRect(_indicatorArea, dollWidth + 28f, bodyTop, indicatorWidth, bodyHeight);
            if (_dollRoot != null && _authoredDollSize.x > 0f && _authoredDollSize.y > 0f)
            {
                float scale = Mathf.Min(dollWidth / _authoredDollSize.x, dollHeight / _authoredDollSize.y);
                _dollRoot.localScale = new Vector3(scale, scale, 1f);
            }
            float rowHeight = bodyHeight / 6f;
            for (int i = 0; i < _indicatorViews.Length; i++)
            {
                var view = _indicatorViews[i];
                SetRect(view.Rect, 0f, i * rowHeight, indicatorWidth, rowHeight);
                float icon = Mathf.Min(32f, rowHeight - 6f);
                SetRect(view.Icon.rectTransform, 0f, 1f, icon, icon);
                float textLeft = icon + 7f, textWidth = Mathf.Max(50f, indicatorWidth - textLeft);
                SetRect(view.Title.rectTransform, textLeft, 0f, textWidth, 14f);
                SetRect(view.Value.rectTransform, textLeft, 13f, textWidth, Mathf.Max(17f, rowHeight - 17f));
                SetRect((RectTransform)view.Fill.transform.parent, textLeft, rowHeight - 3f, textWidth, 2f);
                view.Value.fontSize = Mathf.Clamp(Mathf.Min(Safe(_fontSize, 14f), rowHeight - 18f), 11f, 17f);
            }
            SetRect(_effectsDivider.rectTransform, 12f, effectsTop, innerWidth, 1f);
            SetRect(_effectsHeading.rectTransform, 12f, effectsTop + 5f, innerWidth, 16f);
            SetRect(_effectsArea, 12f, effectsTop + 25f, innerWidth, effectAreaHeight);
            for (int i = 0; i < _effectViews.Length; i++)
            {
                var view = _effectViews[i];
                SetRect(view.Rect, i % columns * (cellWidth + columnGap), i / columns * (effectRowHeight + rowGap), cellWidth, effectRowHeight);
                SetRect(view.Icon.rectTransform, (cellWidth - effectIcon) * .5f, 2f, effectIcon, effectIcon);
                SetRect(view.Fallback.rectTransform, 5f, 2f, cellWidth - 10f, effectIcon);
                SetRect(view.Value.rectTransform, 5f, effectIcon + 3f, cellWidth - 10f, 16f);
            }
            SetRect(_empty.rectTransform, 0f, 0f, innerWidth, effectAreaHeight);
            SetRect(_controlHint.rectTransform, 12f, sh - 21f, Mathf.Max(60f, innerWidth - 112f), 16f);
            SetRect((RectTransform)_previous.transform, sw - 106f, sh - 23f, 25f, 20f);
            SetRect(_pageText.rectTransform, sw - 79f, sh - 23f, 40f, 20f);
            SetRect((RectTransform)_next.transform, sw - 37f, sh - 23f, 25f, 20f);
            _glass.SetPhase(1f, 0f, Mathf.Clamp(_screenTexture, 0f, .03f), _foreground);
            SetRect(_stowedHint.rectTransform, width - _rect.anchoredPosition.x - 62f,
                caseHeight + _rect.anchoredPosition.y - 31f, 44f, 15f);
            LayoutHardware(width, height, strip);
            ApplyPowerVisuals(_inventory == null || !_inventory.IsOpen);
        }

        // Case, frame of the tube and the control strip: nameplate, grille, mains lamp label and the key cap.
        private void LayoutHardware(float width, float height, float strip)
        {
            bool hasStrip = strip > 0f;
            bool plate = hasStrip && !string.IsNullOrWhiteSpace(_nameplateText);
            float middle = height - 4f + strip * .5f;
            float plateWidth = Mathf.Min(150f, width * .4f);
            _shell.ScreenInset = new Vector4(10f, 10f, 10f, 10f + strip);
            _shell.BezelWidth = 5.5f;
            _shell.BezelRadius = 8f;
            _shell.Chamfer = 10f;
            _shell.ScrewRadius = 2.7f;
            _shell.Nameplate = plate ? new UnityEngine.Rect(14f, middle - 8f, plateWidth, 16f) : UnityEngine.Rect.zero;
            _shell.Grille = hasStrip ? new UnityEngine.Rect(width * .535f, middle - 7f, 40f, 14f) : UnityEngine.Rect.zero;
            _shell.GrilleSlots = hasStrip ? 6 : 0;
            _shell.KeyCap = hasStrip ? new UnityEngine.Rect(width - 27f, middle - 5.5f, 14f, 11f) : UnityEngine.Rect.zero;
            _shell.Grain = Mathf.Clamp(Safe(_caseGrain, .05f), 0f, .12f);
            _shell.Refresh();
            _glassEdge.Refresh();
            _nameplateLabel.gameObject.SetActive(plate);
            SetText(_nameplateLabel, _nameplateText ?? string.Empty);
            SetRect(_nameplateLabel.rectTransform, 14f, middle - 8f, plateWidth, 16f);
            _mainsLabel.gameObject.SetActive(hasStrip);
            SetRect(_mainsLabel.rectTransform, width - 110f, middle - 6f, 56f, 12f);
            _keyLabel.gameObject.SetActive(hasStrip);
            SetRect(_keyLabel.rectTransform, width - 27f, middle - 5.5f, 14f, 11f);
        }

        private static float Safe(float value, float fallback) => float.IsNaN(value) || float.IsInfinity(value) ? fallback : value;
        private static void SetText(TMP_Text view, string value) { if (view.text != value) view.text = value; }
        private static RectTransform Rect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            return (RectTransform)go.transform;
        }
        private UnityEngine.UI.Image Image(string name, Transform parent, Color color)
        {
            var rect = Rect(name, parent); var image = rect.gameObject.AddComponent<UnityEngine.UI.Image>();
            image.color = color; image.raycastTarget = false; return image;
        }
        private TMP_Text Text(string name, Transform parent, string value, float size)
        {
            var rect = Rect(name, parent); var text = rect.gameObject.AddComponent<TextMeshProUGUI>();
            if (_font != null) text.font = _font;
            text.text = value; text.fontSize = size; text.color = _foreground; text.raycastTarget = false;
            text.alignment = TextAlignmentOptions.MidlineLeft;
            text.textWrappingMode = TextWrappingModes.NoWrap; text.overflowMode = TextOverflowModes.Truncate;
            return text;
        }
        private static void Stretch(RectTransform rect)
        {
            rect.anchorMin = Vector2.zero; rect.anchorMax = Vector2.one;
            rect.offsetMin = rect.offsetMax = Vector2.zero; rect.localScale = Vector3.one;
        }
        private static void SetRect(RectTransform rect, float x, float y, float width, float height)
        {
            rect.anchorMin = rect.anchorMax = new Vector2(0f, 1f); rect.pivot = new Vector2(0f, 1f);
            rect.anchoredPosition = new Vector2(x, -y); rect.sizeDelta = new Vector2(Mathf.Max(0f, width), Mathf.Max(0f, height));
        }
    }
}
