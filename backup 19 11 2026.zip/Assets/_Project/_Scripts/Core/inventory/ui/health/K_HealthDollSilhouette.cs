using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Visible, connected sprite silhouette and its horizontal cross-sections.</summary>
    internal sealed class K_HealthDollSilhouette
    {
        private static readonly Dictionary<Sprite, K_HealthDollSilhouette> Cache =
            new Dictionary<Sprite, K_HealthDollSilhouette>();
        private static readonly K_HealthDollSilhouette Unit =
            new K_HealthDollSilhouette(new Rect(0f, 0f, 1f, 1f), new[] { .5f }, new[] { 1f });

        public readonly Rect Bounds;
        private readonly float[] _centers;
        private readonly float[] _widths;
        private readonly int[][] _opaqueRuns;
        private readonly int _pixelWidth;

        private K_HealthDollSilhouette(Rect bounds, float[] centers, float[] widths, int[][] opaqueRuns = null, int pixelWidth = 0)
        {
            Bounds = bounds;
            _centers = centers;
            _widths = widths;
            _opaqueRuns = opaqueRuns;
            _pixelWidth = pixelWidth;
        }

        public Vector2 CenterAt(float y01)
            => new Vector2(Sample(_centers, y01), Mathf.Clamp01(y01));

        public float WidthAt(float y01) => Sample(_widths, y01);

        public Vector2 SnapInside(Vector2 normalized, float insetX)
        {
            if (_opaqueRuns == null || _pixelWidth < 1) return normalized;
            int row = Mathf.Clamp(Mathf.RoundToInt(normalized.y * (_opaqueRuns.Length - 1)), 0, _opaqueRuns.Length - 1);
            int[] runs = _opaqueRuns[row];
            if (runs == null || runs.Length == 0) return normalized;
            float wanted = normalized.x * _pixelWidth, inset = insetX * _pixelWidth;
            float best = wanted, distance = float.PositiveInfinity;
            for (int i = 0; i + 1 < runs.Length; i += 2)
            {
                float left = runs[i], right = runs[i + 1];
                float padding = Mathf.Min(inset, (right - left) * .44f);
                float candidate = Mathf.Clamp(wanted, left + padding, right - padding);
                float difference = Mathf.Abs(candidate - wanted);
                if (difference >= distance) continue;
                distance = difference; best = candidate;
            }
            normalized.x = best / _pixelWidth;
            return normalized;
        }

        public static K_HealthDollSilhouette Get(Sprite sprite)
        {
            if (sprite == null) return Unit;
            if (Cache.TryGetValue(sprite, out var silhouette)) return silhouette;
            silhouette = sprite.packed ? FromSpriteMesh(sprite) : FromPixels(sprite);
            Cache[sprite] = silhouette;
            return silhouette;
        }

        private static float Sample(float[] values, float y01)
        {
            float position = Mathf.Clamp01(y01) * (values.Length - 1);
            int lower = Mathf.FloorToInt(position);
            int upper = Mathf.Min(lower + 1, values.Length - 1);
            return Mathf.Lerp(values[lower], values[upper], position - lower);
        }

        private static K_HealthDollSilhouette FromPixels(Sprite sprite)
        {
            Texture2D readable = null;
            RenderTexture temporary = null;
            RenderTexture previous = RenderTexture.active;
            try
            {
                Texture2D texture = sprite.texture;
                if (texture.isReadable) readable = texture;
                else
                {
                    temporary = RenderTexture.GetTemporary(texture.width, texture.height, 0, RenderTextureFormat.ARGB32);
                    Graphics.Blit(texture, temporary);
                    RenderTexture.active = temporary;
                    readable = new Texture2D(texture.width, texture.height, TextureFormat.RGBA32, false);
                    readable.ReadPixels(new Rect(0f, 0f, texture.width, texture.height), 0, 0);
                    readable.Apply(false, false);
                }
                return FromConnectedPixels(readable.GetPixels32(), readable.width, sprite.rect);
            }
            finally
            {
                RenderTexture.active = previous;
                if (temporary != null) RenderTexture.ReleaseTemporary(temporary);
                if (readable != null && readable != sprite.texture)
                {
                    if (Application.isPlaying) Object.Destroy(readable);
                    else Object.DestroyImmediate(readable);
                }
            }
        }

        private static K_HealthDollSilhouette FromConnectedPixels(Color32[] pixels, int textureWidth, Rect region)
        {
            int width = Mathf.RoundToInt(region.width), height = Mathf.RoundToInt(region.height);
            int originX = Mathf.RoundToInt(region.x), originY = Mathf.RoundToInt(region.y);
            if (width <= 0 || height <= 0) return Unit;
            int[] labels = new int[width * height];
            int[] queue = new int[labels.Length];
            int component = 0, largest = 0, largestCount = 0;
            for (int seed = 0; seed < labels.Length; seed++)
            {
                if (labels[seed] != 0 || !Opaque(pixels, textureWidth, originX, originY, width, seed)) continue;
                component++;
                int read = 0, write = 1;
                labels[seed] = component;
                queue[0] = seed;
                while (read < write)
                {
                    int index = queue[read++];
                    int x = index % width, y = index / width;
                    int left = Mathf.Max(0, x - 1), right = Mathf.Min(width - 1, x + 1);
                    int bottom = Mathf.Max(0, y - 1), top = Mathf.Min(height - 1, y + 1);
                    for (int nextY = bottom; nextY <= top; nextY++)
                    for (int nextX = left; nextX <= right; nextX++)
                    {
                        int next = nextY * width + nextX;
                        if (labels[next] != 0 || !Opaque(pixels, textureWidth, originX, originY, width, next)) continue;
                        labels[next] = component;
                        queue[write++] = next;
                    }
                }
                if (write > largestCount) { largest = component; largestCount = write; }
            }
            if (largestCount == 0) return Unit;

            int minX = width, maxX = -1, minY = height, maxY = -1;
            int[] rowMin = new int[height], rowMax = new int[height];
            for (int y = 0; y < height; y++) { rowMin[y] = width; rowMax[y] = -1; }
            for (int index = 0; index < labels.Length; index++)
            {
                if (labels[index] != largest) continue;
                int x = index % width, y = index / width;
                minX = Mathf.Min(minX, x); maxX = Mathf.Max(maxX, x);
                minY = Mathf.Min(minY, y); maxY = Mathf.Max(maxY, y);
                rowMin[y] = Mathf.Min(rowMin[y], x);
                rowMax[y] = Mathf.Max(rowMax[y], x);
            }
            int bodyWidth = maxX - minX + 1, bodyHeight = maxY - minY + 1;
            float[] centers = new float[bodyHeight], widths = new float[bodyHeight];
            for (int row = 0; row < bodyHeight; row++)
            {
                int sourceRow = minY + row;
                float left = 0f, right = 0f;
                int samples = 0;
                for (int y = Mathf.Max(minY, sourceRow - 2); y <= Mathf.Min(maxY, sourceRow + 2); y++)
                {
                    if (rowMax[y] < rowMin[y]) continue;
                    left += rowMin[y]; right += rowMax[y] + 1;
                    samples++;
                }
                if (samples == 0)
                {
                    int nearest = NearestRow(sourceRow, rowMin, rowMax, minY, maxY);
                    left = rowMin[nearest]; right = rowMax[nearest] + 1;
                    samples = 1;
                }
                left /= samples; right /= samples;
                centers[row] = ((left + right) * .5f - minX) / bodyWidth;
                widths[row] = (right - left) / bodyWidth;
            }
            Rect bounds = new Rect(minX / (float)width, minY / (float)height,
                bodyWidth / (float)width, bodyHeight / (float)height);
            var runs = new int[bodyHeight][];
            for (int row = 0; row < bodyHeight; row++)
            {
                var spans = new List<int>();
                int x = minX, offset = (minY + row) * width;
                while (x <= maxX)
                {
                    while (x <= maxX && labels[offset + x] != largest) x++;
                    if (x > maxX) break;
                    spans.Add(x - minX);
                    while (x <= maxX && labels[offset + x] == largest) x++;
                    spans.Add(x - minX);
                }
                runs[row] = spans.ToArray();
            }
            return new K_HealthDollSilhouette(bounds, centers, widths, runs, bodyWidth);
        }

        private static bool Opaque(Color32[] pixels, int textureWidth, int originX, int originY, int width, int index)
            => pixels[(originY + index / width) * textureWidth + originX + index % width].a >= 24;

        private static int NearestRow(int row, int[] minimum, int[] maximum, int bottom, int top)
        {
            for (int distance = 1; distance <= top - bottom; distance++)
            {
                int below = row - distance, above = row + distance;
                if (below >= bottom && maximum[below] >= minimum[below]) return below;
                if (above <= top && maximum[above] >= minimum[above]) return above;
            }
            return bottom;
        }

        private static K_HealthDollSilhouette FromSpriteMesh(Sprite sprite)
        {
            // Packed textures may be rotated or trimmed. Sprite vertices retain original-space coordinates.
            Vector2[] vertices = sprite.vertices;
            ushort[] triangles = sprite.triangles;
            if (vertices.Length == 0) return Unit;
            Vector2 minimum = new Vector2(float.MaxValue, float.MaxValue);
            Vector2 maximum = new Vector2(float.MinValue, float.MinValue);
            for (int i = 0; i < vertices.Length; i++)
            {
                vertices[i] = vertices[i] * sprite.pixelsPerUnit + sprite.pivot;
                minimum = Vector2.Min(minimum, vertices[i]);
                maximum = Vector2.Max(maximum, vertices[i]);
            }
            Vector2 size = maximum - minimum;
            if (size.x <= 0f || size.y <= 0f) return Unit;
            const int rows = 64;
            float[] centers = new float[rows], widths = new float[rows];
            for (int row = 0; row < rows; row++)
            {
                float y = Mathf.Lerp(minimum.y, maximum.y, (row + .5f) / rows);
                float left = float.MaxValue, right = float.MinValue;
                for (int triangle = 0; triangle + 2 < triangles.Length; triangle += 3)
                for (int edge = 0; edge < 3; edge++)
                {
                    Vector2 a = vertices[triangles[triangle + edge]];
                    Vector2 b = vertices[triangles[triangle + (edge + 1) % 3]];
                    if (Mathf.Abs(a.y - b.y) < .00001f || y < Mathf.Min(a.y, b.y) || y > Mathf.Max(a.y, b.y)) continue;
                    float x = Mathf.LerpUnclamped(a.x, b.x, (y - a.y) / (b.y - a.y));
                    left = Mathf.Min(left, x); right = Mathf.Max(right, x);
                }
                centers[row] = left <= right ? ((left + right) * .5f - minimum.x) / size.x : .5f;
                widths[row] = left <= right ? (right - left) / size.x : 1f;
            }
            Rect bounds = new Rect(minimum.x / sprite.rect.width, minimum.y / sprite.rect.height,
                size.x / sprite.rect.width, size.y / sprite.rect.height);
            return new K_HealthDollSilhouette(bounds, centers, widths);
        }
    }
}
