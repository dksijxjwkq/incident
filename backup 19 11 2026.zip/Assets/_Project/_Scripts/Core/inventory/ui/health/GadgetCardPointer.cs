using System;
using UnityEngine;
using UnityEngine.EventSystems;

namespace K_Incident.Core.Inventory
{
    /// <summary>Adds a right-click action without changing the card's existing left-click Button.</summary>
    [DisallowMultipleComponent]
    public sealed class GadgetCardPointer : MonoBehaviour, IPointerClickHandler
    {
        public Action RightClick { get; set; }

        public void OnPointerClick(PointerEventData eventData)
        {
            if (!isActiveAndEnabled || eventData == null || eventData.button != PointerEventData.InputButton.Right) return;
            RightClick?.Invoke();
            eventData.Use();
        }
    }
}
