using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Visible state of one anatomical region, read from the gameplay owners.</summary>
    public struct K_HealthDollAnatomyPart
    {
        public float Health01;
        public float BleedingLevel;
        public bool Fractured;
        public bool Splinted;
        public bool Gunshot;
        public bool Infected;
        public bool InfectionRecovering;
        public bool InternalBleedingRevealed;
        public bool HealBoost;
        public bool HaemostasisPrepared;
        public LacerationType Laceration;
        public bool Tourniquet;
        public bool ElasticTourniquet;
        public bool Jett;
        public float RecoverySeconds;
        public float HealBoostSeconds;
        public float CoagulantSeconds;
        public float InfectionRecoverySeconds;
    }

    /// <summary>
    /// Reuses presentation entries between refreshes. It never advances timers or changes treatment.
    /// Entries reuse the existing gadget taxonomy and titles. Detailed text remains in that gadget.
    /// </summary>
    public sealed class K_HealthDollAnatomyState
    {
        private const int KindCount = (int)HealthGadgetKind.AntibioticTreatment + 1;
        private readonly bool[] _present = new bool[KindCount];
        private readonly float[] _values = new float[KindCount];
        private readonly HealthGadgetEntry[] _entries = new HealthGadgetEntry[KindCount];

        public readonly K_HealthDollAnatomyPart[] Parts = new K_HealthDollAnatomyPart[20];
        public readonly List<HealthGadgetEntry> Effects = new List<HealthGadgetEntry>(KindCount);
        public bool IsDead;
        public float Blood01 = 1f;
        public float PulseBpm;
        public bool ChestSeal;
        public bool PelvisStabilized;
        public bool IsResting;
        public bool PainkillerPending;
        public float PainRelief01;
        public bool TbiRecovering;
        public float TbiRecoverySeconds;

        public K_HealthDollAnatomyState()
        {
            for (int i = 0; i < KindCount; i++)
            {
                var kind = (HealthGadgetKind)i;
                _values[i] = -1f;
                _entries[i] = new HealthGadgetEntry
                {
                    Kind = kind,
                    Title = K_HealthGadgetContent.GetTitle(kind),
                    IsIndicator = kind <= HealthGadgetKind.Blood
                };
            }
        }

        public bool Has(HealthGadgetKind kind)
        {
            int index = (int)kind;
            return index >= 0 && index < KindCount && _present[index];
        }

        public float Value(HealthGadgetKind kind)
        {
            int index = (int)kind;
            return index >= 0 && index < KindCount ? _values[index] : -1f;
        }

        public void Refresh(K_HealthSystem health, K_VitalitySystem vitality, K_DebuffSystem debuffs,
            K_BloodSystem blood, K_WeightManager weight, K_IllnessSystem illness)
        {
            Array.Clear(_present, 0, KindCount);
            for (int i = 0; i < KindCount; i++) _values[i] = -1f;
            Effects.Clear();

            IsDead = health != null && health.IsDead;
            Blood01 = blood != null ? Mathf.Clamp01(blood.BloodPercent) : 1f;
            PulseBpm = !IsDead && vitality != null ? vitality.CurrentBpm : 0f;
            ChestSeal = health != null && health.HasChestSeal;
            PelvisStabilized = health != null && health.IsPelvisStabilized;
            IsResting = health != null && health.IsRestingForRecovery;
            PainkillerPending = debuffs != null && debuffs.HasPendingPainkiller && !debuffs.IsUnderPainkiller;
            PainRelief01 = debuffs != null ? Mathf.Clamp01(debuffs.PainReliefFraction) : 0f;
            TbiRecovering = debuffs != null && debuffs.HasTBI && debuffs.IsTbiRecovering;
            TbiRecoverySeconds = TbiRecovering ? debuffs.TbiRecoverySecondsRemaining : 0f;
            if (illness == null && health != null) illness = health.Illnesses;

            for (int i = 0; i < Parts.Length; i++)
            {
                var part = (BodyPart)i;
                var state = new K_HealthDollAnatomyPart { Health01 = 1f };
                if (health != null)
                {
                    state.Health01 = Mathf.Clamp01(health.GetHPPercent(part));
                    state.BleedingLevel = health.GetBleedingLevel(part);
                    state.Fractured = health.IsFractured(part);
                    state.Splinted = health.IsSplinted(part);
                    state.Gunshot = health.IsGunshot(part);
                    state.Laceration = health.GetLacerationType(part);
                    // Hidden bleeding must not affect geometry, appearance, or effect presence.
                    state.InternalBleedingRevealed = health.IsInternalBleedingRevealed(part);
                    state.HaemostasisPrepared = state.InternalBleedingRevealed && health.IsSurgicalHemostatPrepared(part);
                    state.CoagulantSeconds = health.GetRevealedCoagulantSecondsRemaining(part);
                    state.HealBoostSeconds = health.GetHealBoostSecondsRemaining(part);
                    state.HealBoost = state.HealBoostSeconds > 0f;
                    state.RecoverySeconds = state.Fractured ? health.GetSplintRecoverySecondsRemaining(part) : 0f;
                    ReadDevice(health.AppliedMedical, part, ref state);
                }
                if (illness != null)
                {
                    state.Infected = illness.IsWoundInfected(part);
                    state.InfectionRecovering = illness.IsWoundInfectionRecovering(part);
                    state.InfectionRecoverySeconds = illness.GetWoundInfectionRecoverySeconds(part);
                }
                Parts[i] = state;
                MarkPartEffects(state);
            }

            if (vitality != null)
            {
                Show(HealthGadgetKind.Hunger, vitality.Hunger / 100f);
                Show(HealthGadgetKind.Thirst, vitality.Thirst / 100f);
                Show(HealthGadgetKind.Radiation, vitality.Radiation / 100f);
                Show(HealthGadgetKind.Cold, vitality.ColdExposure);
                if (vitality.IsStimOn) Show(HealthGadgetKind.StimOn, Fraction(vitality.StimulatorSecondsRemaining, vitality.StimulatorFullDuration));
                if (vitality.IsStimOff) Show(HealthGadgetKind.StimCooldown, Fraction(vitality.StimCooldownSecondsRemaining, vitality.StimCooldownFullDuration));
                if (vitality.IsFatigued) Show(HealthGadgetKind.Fatigue, Fraction(vitality.FatigueSecondsRemaining, vitality.FatigueFullDuration));
                if (vitality.IsDrunk) Show(HealthGadgetKind.Drunk);
                if (vitality.IsHangover) Show(HealthGadgetKind.Hangover);
            }
            if (blood != null) Show(HealthGadgetKind.Blood, Blood01);
            if (weight != null) Show(HealthGadgetKind.Overload, weight.GetCurrentWeightRatio());
            if (debuffs != null)
            {
                if (debuffs.HasConcussion) Show(HealthGadgetKind.Concussion);
                if (debuffs.HasTBI) Show(HealthGadgetKind.Tbi);
                if (debuffs.HasBreathingDifficulty) Show(HealthGadgetKind.BreathingDifficulty);
                if (debuffs.HasImmobilized) Show(HealthGadgetKind.Immobilized);
                if (debuffs.IsUnderPainkiller || debuffs.HasPendingPainkiller)
                    Show(HealthGadgetKind.Painkiller, PainkillerPending ? -1f : Fraction(debuffs.PainkillerSecondsRemaining, debuffs.PainkillerFullDuration));
            }
            if (health != null)
            {
                if (health.IsShocked) Show(HealthGadgetKind.Shock);
                if (health.TxaSecondsRemaining > 0f) Show(HealthGadgetKind.Txa, Fraction(health.TxaSecondsRemaining, health.TxaFullDuration));
            }
            if (ChestSeal) Show(HealthGadgetKind.ChestSeal);
            if (PelvisStabilized) Show(HealthGadgetKind.PelvicBinder);
            if (illness != null)
            {
                if (illness.HasCold) Show(HealthGadgetKind.ColdIllness, Fraction(illness.ColdSecondsRemaining, illness.ColdFullDuration));
                if (illness.AntibioticSecondsRemaining > 0f)
                    Show(HealthGadgetKind.AntibioticTreatment, Fraction(illness.AntibioticSecondsRemaining, illness.AntibioticFullDuration));
            }

            for (int i = 0; i < KindCount; i++)
            {
                if (!_present[i]) continue;
                _entries[i].NormalizedValue = _values[i];
                Effects.Add(_entries[i]);
            }
        }

        private void MarkPartEffects(K_HealthDollAnatomyPart state)
        {
            if (state.BleedingLevel > 0f) Show(HealthGadgetKind.Bleeding);
            if (state.Fractured) Show(HealthGadgetKind.Fracture);
            if (state.Gunshot) Show(HealthGadgetKind.Gunshot);
            if (state.Laceration != LacerationType.None) Show(HealthGadgetKind.Laceration);
            if (state.InternalBleedingRevealed) Show(HealthGadgetKind.InternalBleeding);
            if (state.Infected) Show(HealthGadgetKind.WoundInfection);
            if (state.HealBoost) Show(HealthGadgetKind.HealBoost);
            if (state.HaemostasisPrepared || state.CoagulantSeconds > 0f) Show(HealthGadgetKind.Coagulant);
            if (state.RecoverySeconds > 0f) Show(HealthGadgetKind.Recovery);
            if (state.Tourniquet) Show(HealthGadgetKind.Tourniquet);
            if (state.Jett) Show(HealthGadgetKind.Jett);
        }

        private static void ReadDevice(K_AppliedMedicalManager manager, BodyPart part, ref K_HealthDollAnatomyPart state)
        {
            var record = manager != null ? manager.GetRecordForPart(part) : null;
            if (record == null || record.AppliedTo != part || (!record.IsPersistent && record.RemainingSeconds <= 0f)) return;
            state.Tourniquet = record.Kind == AppliedGhostKind.Tourniquet;
            state.ElasticTourniquet = state.Tourniquet && record.VirtualItemID == "tourniquet_elastic";
            state.Jett = record.Kind == AppliedGhostKind.JETT;
        }

        private void Show(HealthGadgetKind kind, float value = -1f)
        {
            int index = (int)kind;
            _present[index] = true;
            _values[index] = value < 0f ? -1f : Mathf.Clamp01(value);
        }

        private static float Fraction(float remaining, float duration)
            => duration > 0f ? Mathf.Clamp01(remaining / duration) : -1f;
    }
}
