using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Glass shading and the warm-up of the picture tube: a line of light opens into television "snow",
    /// a dark bar rolls down, the snow thins and the readings stay. Switching off folds the picture
    /// into a line and a dot. Mesh only, one shared grain texture; it never intercepts clicks and
    /// the readings themselves are never altered.
    /// </summary>
    [RequireComponent(typeof(CanvasRenderer))]
    public sealed class K_HealthGadgetScreenFX : MaskableGraphic
    {
        private float _progress = 1f, _strength, _scanline;
        private Color _tint;
        private bool _closing;
        private int _frame;

        public override Texture mainTexture => K_HealthGadgetNoise.Texture;

        /// <summary>Warm-up: progress 0 is a dark tube, 1 is the settled picture.</summary>
        public void SetPhase(float progress, float strength, float scanline, Color tint)
            => Apply(progress, strength, scanline, tint, false);

        /// <summary>Switch-off: remaining 1 is the full picture, 0 is a dark tube.</summary>
        public void SetPowerOff(float remaining, Color tint) => Apply(remaining, 1f, 0f, tint, true);

        private void Apply(float progress, float strength, float scanline, Color tint, bool closing)
        {
            progress = Mathf.Clamp01(progress);
            strength = Mathf.Clamp01(strength);
            scanline = Mathf.Clamp(scanline, 0f, 0.1f);
            bool moving = progress < 1f && strength > 0f;
            if (!moving && _progress == progress && _strength == strength && _scanline == scanline && _tint == tint && _closing == closing) return;
            _progress = progress;
            _strength = strength;
            _scanline = scanline;
            _tint = tint;
            _closing = closing;
            // A new frame number moves the grain, so the snow is alive for as long as it is visible.
            _frame = Time.frameCount;
            raycastTarget = false;
            SetVerticesDirty();
        }

        protected override void OnPopulateMesh(VertexHelper mesh)
        {
            mesh.Clear();
            Rect rect = GetPixelAdjustedRect();
            if (rect.width <= 0f || rect.height <= 0f) return;
            Color line = WithAlpha(_tint, _scanline);
            float step = Mathf.Max(4f, rect.height / 150f);
            if (_scanline > 0f)
                for (float y = rect.yMin; y < rect.yMax; y += step)
                    Quad(mesh, new Rect(rect.xMin, y, rect.width, 0.5f), line);

            // A narrow, stepped vignette makes the display feel recessed in its frame.
            // It remains completely static once the warm-up has finished.
            float edge = Mathf.Min(16f, Mathf.Min(rect.width, rect.height) * 0.06f);
            for (int i = 0; i < 8; i++)
            {
                float inset = edge * i / 8f;
                float thickness = edge / 8f;
                Color shadow = new Color(0f, 0f, 0f, 0.19f * (1f - i / 8f));
                Quad(mesh, new Rect(rect.xMin + inset, rect.yMin + inset, rect.width - 2f * inset, thickness), shadow);
                Quad(mesh, new Rect(rect.xMin + inset, rect.yMax - inset - thickness, rect.width - 2f * inset, thickness), shadow);
                Quad(mesh, new Rect(rect.xMin + inset, rect.yMin + inset + thickness, thickness, rect.height - 2f * inset - 2f * thickness), shadow);
                Quad(mesh, new Rect(rect.xMax - inset - thickness, rect.yMin + inset + thickness, thickness, rect.height - 2f * inset - 2f * thickness), shadow);
            }
            if (_progress >= 1f || _strength <= 0f) return;
            if (_closing) PowerOff(mesh, rect);
            else WarmUp(mesh, rect);
        }

        private void WarmUp(VertexHelper mesh, Rect rect)
        {
            float p = _progress, centre = rect.center.y;
            // The tube opens from a line in the middle; outside the opening it is still dark.
            float opening = Mathf.Max(1.5f, rect.height * Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(.09f, .24f, p)));
            float lower = centre - opening * .5f, upper = centre + opening * .5f;
            // A cold tube is simply dark: the strength setting scales the snow, not how black "off" is.
            float darkness = Mathf.Clamp01(_strength * 4f);
            Color dark = new Color(.004f, .004f, .004f, darkness);
            Quad(mesh, new Rect(rect.xMin, rect.yMin, rect.width, lower - rect.yMin), dark);
            Quad(mesh, new Rect(rect.xMin, upper, rect.width, rect.yMax - upper), dark);

            // Until the picture locks, the opened part shows nothing but snow over a dark tube.
            float cover = darkness * (1f - Ramp(.24f, .52f, p));
            Quad(mesh, new Rect(rect.xMin, lower, rect.width, upper - lower), new Color(.004f, .004f, .004f, cover));
            float snow = _strength * (1f - Ramp(.30f, .90f, p));
            if (p > .09f && snow > .003f)
            {
                Color grain = Color.Lerp(_tint, Color.white, .35f);
                grain.a = snow;
                Snow(mesh, new Rect(rect.xMin, lower, rect.width, upper - lower), grain);
                // The rolling bar of a picture that has not locked yet.
                float travel = Mathf.Repeat(p * 1.9f + .2f, 1f);
                float barHeight = rect.height * .13f, barTop = rect.yMax - travel * (rect.height + barHeight);
                float barLow = Mathf.Max(lower, barTop - barHeight), barHigh = Mathf.Min(upper, barTop);
                if (barHigh > barLow)
                {
                    Color bar = new Color(0f, 0f, 0f, snow * .62f), clear = new Color(0f, 0f, 0f, 0f);
                    float middle = (barLow + barHigh) * .5f;
                    Band(mesh, rect.xMin, rect.xMax, barLow, middle, clear, bar);
                    Band(mesh, rect.xMin, rect.xMax, middle, barHigh, bar, clear);
                }
            }

            // The first line of light, widening before the picture opens.
            float beam = _strength * (1f - Ramp(.14f, .34f, p));
            if (beam > .003f)
            {
                float width = rect.width * Mathf.Lerp(.06f, 1f, Mathf.SmoothStep(0f, 1f, p / .10f));
                float x = rect.center.x - width * .5f;
                Color glow = Color.Lerp(_tint, Color.white, .5f), clear = glow;
                glow.a = beam * .34f;
                clear.a = 0f;
                Band(mesh, x, x + width, centre - 7f, centre, clear, glow);
                Band(mesh, x, x + width, centre, centre + 7f, glow, clear);
                Quad(mesh, new Rect(x, centre - 1f, width, 2f), WithAlpha(Color.Lerp(_tint, Color.white, .8f), beam));
            }
        }

        private void PowerOff(VertexHelper mesh, Rect rect)
        {
            float r = _progress, centre = rect.center.y;
            // The picture folds to a line, the line shrinks to a dot, the dot fades.
            float opening = rect.height * Mathf.Pow(Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(.42f, 1f, r)), 1.6f);
            float lower = centre - opening * .5f, upper = centre + opening * .5f;
            Color dark = new Color(.004f, .004f, .004f, 1f);
            Quad(mesh, new Rect(rect.xMin, rect.yMin, rect.width, lower - rect.yMin), dark);
            Quad(mesh, new Rect(rect.xMin, upper, rect.width, rect.yMax - upper), dark);
            float width = rect.width * Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(.14f, .46f, r));
            float light = Mathf.Clamp01(r / .14f) * (1f - Ramp(.62f, .95f, r));
            if (light <= .003f) return;
            width = Mathf.Max(3f, width);
            float x = rect.center.x - width * .5f;
            Color glow = Color.Lerp(_tint, Color.white, .5f), clear = glow;
            glow.a = light * .34f;
            clear.a = 0f;
            Band(mesh, x, x + width, centre - 6f, centre, clear, glow);
            Band(mesh, x, x + width, centre, centre + 6f, glow, clear);
            Quad(mesh, new Rect(x, centre - 1f, width, 2f), WithAlpha(Color.Lerp(_tint, Color.white, .8f), light));
        }

        // 0 below the first edge, 1 above the second, smooth in between.
        // (Mathf.SmoothStep itself interpolates between its first two arguments instead.)
        private static float Ramp(float from, float to, float value)
            => Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(from, to, value));

        /// <summary>Grain of about one and a half screen pixels per speck; a new offset every frame makes it boil.</summary>
        private void Snow(VertexHelper mesh, Rect r, Color tint)
        {
            if (r.width <= 0f || r.height <= 0f) return;
            float scale = canvas != null ? canvas.rootCanvas.scaleFactor : 1f;
            float texels = Mathf.Max(.01f, scale / 1.5f) / K_HealthGadgetNoise.Size;
            Vector2 offset = new Vector2(K_HealthGadgetNoise.Hash(_frame * 2 + 1), K_HealthGadgetNoise.Hash(_frame * 2 + 2));
            Vector2 size = new Vector2(r.width * texels, r.height * texels);
            int i = mesh.currentVertCount;
            mesh.AddVert(new Vector3(r.xMin, r.yMin), tint, offset);
            mesh.AddVert(new Vector3(r.xMin, r.yMax), tint, new Vector2(offset.x, offset.y + size.y));
            mesh.AddVert(new Vector3(r.xMax, r.yMax), tint, offset + size);
            mesh.AddVert(new Vector3(r.xMax, r.yMin), tint, new Vector2(offset.x + size.x, offset.y));
            mesh.AddTriangle(i, i + 1, i + 2);
            mesh.AddTriangle(i, i + 2, i + 3);
        }

        private static Color WithAlpha(Color value, float alpha)
        {
            value.a = alpha;
            return value;
        }

        private static void Band(VertexHelper mesh, float left, float right, float bottom, float top, Color low, Color high)
        {
            if (right <= left || top <= bottom) return;
            Vector2 uv = K_HealthGadgetNoise.SolidUV;
            int i = mesh.currentVertCount;
            mesh.AddVert(new Vector3(left, bottom), low, uv);
            mesh.AddVert(new Vector3(left, top), high, uv);
            mesh.AddVert(new Vector3(right, top), high, uv);
            mesh.AddVert(new Vector3(right, bottom), low, uv);
            mesh.AddTriangle(i, i + 1, i + 2);
            mesh.AddTriangle(i, i + 2, i + 3);
        }

        private static void Quad(VertexHelper mesh, Rect r, Color tint)
        {
            if (r.width <= 0f || r.height <= 0f || tint.a <= 0f) return;
            Vector2 uv = K_HealthGadgetNoise.SolidUV;
            int i = mesh.currentVertCount;
            mesh.AddVert(new Vector3(r.xMin, r.yMin), tint, uv);
            mesh.AddVert(new Vector3(r.xMin, r.yMax), tint, uv);
            mesh.AddVert(new Vector3(r.xMax, r.yMax), tint, uv);
            mesh.AddVert(new Vector3(r.xMax, r.yMin), tint, uv);
            mesh.AddTriangle(i, i + 1, i + 2);
            mesh.AddTriangle(i, i + 2, i + 3);
        }
    }
}
