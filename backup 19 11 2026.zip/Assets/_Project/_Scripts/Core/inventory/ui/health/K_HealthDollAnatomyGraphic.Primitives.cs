using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public sealed partial class K_HealthDollAnatomyGraphic
    {
        // Shared drawing tools of the anatomical layers: smooth contours through knots, continuous
        // feathered ribbons and softly edged fills. Everything stays one mesh, with no textures.
        private readonly Vector2[] _knots = new Vector2[128];
        private readonly Vector2[] _center = new Vector2[128];
        private int _knotCount;

        // Torso design frame: the proportions were authored on the reference doll, where one design
        // unit equals one Canvas unit; the mapping follows the fitted landmarks of any other size.
        private float _cx, _yHip, _kx, _ky, _u;

        private void Knots() => _knotCount = 0;

        private void K(Vector2 point)
        {
            if (_knotCount < _knots.Length) _knots[_knotCount++] = point;
        }

        // Centripetal Catmull-Rom: passes through every knot and does not loop on uneven spacing.
        private static Vector2 Spline(Vector2 p0, Vector2 p1, Vector2 p2, Vector2 p3, float t)
        {
            float d01 = Mathf.Sqrt(Vector2.Distance(p0, p1)), d12 = Mathf.Sqrt(Vector2.Distance(p1, p2));
            float d23 = Mathf.Sqrt(Vector2.Distance(p2, p3));
            if (d12 < .0001f) return p1;
            if (d01 < .0001f) d01 = d12;
            if (d23 < .0001f) d23 = d12;
            float t1 = d01, t2 = t1 + d12, t3 = t2 + d23;
            float u = t1 + (t2 - t1) * t;
            Vector2 a1 = (t1 - u) / t1 * p0 + u / t1 * p1;
            Vector2 a2 = (t2 - u) / (t2 - t1) * p1 + (u - t1) / (t2 - t1) * p2;
            Vector2 a3 = (t3 - u) / (t3 - t2) * p2 + (u - t2) / (t3 - t2) * p3;
            Vector2 b1 = (t2 - u) / t2 * a1 + u / t2 * a2;
            Vector2 b2 = (t3 - u) / (t3 - t1) * a2 + (u - t1) / (t3 - t1) * a3;
            return (t2 - u) / (t2 - t1) * b1 + (u - t1) / (t2 - t1) * b2;
        }

        // Curves are sampled about every three screen pixels, but never finer than the doll itself needs:
        // a 4K screen costs about a third more vertices than 1080p, not twice as many.
        private float SampleLength => Mathf.Max(3.2f * _unitsPerPixel, 2.4f * _u) * _sampleScale;

        // Long gentle curves (nerves, organ outlines) need fewer points than small bones.
        private float _sampleScale = 1f;

        private int SplineSamples(Vector2 a, Vector2 b)
            => Mathf.Clamp(Mathf.CeilToInt(Vector2.Distance(a, b) / SampleLength), 1, 10);

        /// <summary>Smooth closed contour through the knots; the result is left in the shape buffer.</summary>
        private void SplineClosed()
        {
            _shapeCount = 0;
            int n = _knotCount;
            if (n < 3) return;
            for (int i = 0; i < n; i++)
            {
                Vector2 p0 = _knots[(i + n - 1) % n], p1 = _knots[i], p2 = _knots[(i + 1) % n], p3 = _knots[(i + 2) % n];
                if ((p2 - p1).sqrMagnitude < .000001f) continue;
                int samples = SplineSamples(p1, p2);
                for (int s = 0; s < samples && _shapeCount < _shape.Length; s++)
                    _shape[_shapeCount++] = Spline(p0, p1, p2, p3, s / (float)samples);
            }
        }

        /// <summary>Smooth open curve through the knots; the result is left in the shape buffer.</summary>
        private void SplineOpen()
        {
            _shapeCount = 0;
            int n = _knotCount;
            if (n < 2) return;
            for (int i = 0; i < n - 1; i++)
            {
                Vector2 p0 = _knots[Mathf.Max(0, i - 1)], p1 = _knots[i], p2 = _knots[i + 1], p3 = _knots[Mathf.Min(n - 1, i + 2)];
                if ((p2 - p1).sqrMagnitude < .000001f) continue;
                int samples = SplineSamples(p1, p2);
                for (int s = 0; s < samples && _shapeCount < _shape.Length - 1; s++)
                    _shape[_shapeCount++] = Spline(p0, p1, p2, p3, s / (float)samples);
            }
            _shape[_shapeCount++] = _knots[n - 1];
        }

        private void BezierShape(Vector2 start, Vector2 controlA, Vector2 controlB, Vector2 end)
        {
            float estimate = Vector2.Distance(start, controlA) + Vector2.Distance(controlA, controlB) + Vector2.Distance(controlB, end);
            int segments = Mathf.Clamp(Mathf.CeilToInt(estimate / SampleLength), 4, 40);
            _shapeCount = 0;
            for (int i = 0; i <= segments; i++)
            {
                float t = i / (float)segments, inverse = 1f - t;
                _shape[_shapeCount++] = inverse * inverse * inverse * start + 3f * inverse * inverse * t * controlA +
                    3f * inverse * t * t * controlB + t * t * t * end;
            }
        }

        /// <summary>
        /// One continuous feathered ribbon along the shape buffer. Shared joint vertices keep translucent
        /// strokes even: there are no doubled dots where segments meet. Widths are in Canvas units.
        /// </summary>
        private void Ribbon(bool closed, Color startTint, Color endTint, float widthStart, float widthEnd)
        {
            int n = _shapeCount;
            if (closed && n > 2 && (_shape[0] - _shape[n - 1]).sqrMagnitude < .000001f) n--;
            if (n < 2 || (startTint.a <= .001f && endTint.a <= .001f)) return;
            float feather = _featherLines ? .7f * _unitsPerPixel : 0f;
            int first = _mesh.currentVertCount;
            int columns = _featherLines ? 4 : 2;
            for (int i = 0; i < n; i++)
            {
                Vector2 point = _shape[i];
                Vector2 previous = closed ? _shape[(i + n - 1) % n] : _shape[Mathf.Max(0, i - 1)];
                Vector2 next = closed ? _shape[(i + 1) % n] : _shape[Mathf.Min(n - 1, i + 1)];
                Vector2 before = point - previous, after = next - point;
                if (before.sqrMagnitude < .0000001f) before = after;
                if (after.sqrMagnitude < .0000001f) after = before;
                before.Normalize();
                after.Normalize();
                Vector2 normalBefore = new Vector2(-before.y, before.x), normalAfter = new Vector2(-after.y, after.x);
                Vector2 miter = normalBefore + normalAfter;
                float length = miter.magnitude;
                miter = length < .0001f ? normalBefore : miter / length;
                float stretch = 1f / Mathf.Max(.5f, Vector2.Dot(miter, normalBefore));
                float along = n > 1 ? i / (float)(n - 1) : 0f;
                float width = Mathf.Lerp(widthStart, widthEnd, along);
                Color tint = Color.Lerp(startTint, endTint, along);
                if (!_featherLines)
                {
                    Vector2 half = miter * (Mathf.Max(width, .6f * _unitsPerPixel) * .5f * stretch);
                    _mesh.AddVert(point - half, tint, Vector2.zero);
                    _mesh.AddVert(point + half, tint, Vector2.zero);
                    continue;
                }
                float core = Mathf.Max(.1f * _unitsPerPixel, width - feather);
                tint.a *= Mathf.Min(1f, width / (core + feather));
                Color clear = new Color(tint.r, tint.g, tint.b, 0f);
                Vector2 inner = miter * (core * .5f * stretch), outer = miter * ((core * .5f + feather) * stretch);
                _mesh.AddVert(point - outer, clear, Vector2.zero);
                _mesh.AddVert(point - inner, tint, Vector2.zero);
                _mesh.AddVert(point + inner, tint, Vector2.zero);
                _mesh.AddVert(point + outer, clear, Vector2.zero);
            }
            int segments = closed ? n : n - 1;
            for (int i = 0; i < segments; i++)
            {
                int a = first + i * columns, b = first + ((i + 1) % n) * columns;
                for (int strip = 0; strip < columns - 1; strip++)
                {
                    _mesh.AddTriangle(a + strip, a + strip + 1, b + strip + 1);
                    _mesh.AddTriangle(b + strip + 1, b + strip, a + strip);
                }
            }
        }

        private void Ribbon(bool closed, Color tint, float width) => Ribbon(closed, tint, tint, width, width);

        /// <summary>Filled contour with a one-pixel soft skirt, so unlined shapes do not alias.</summary>
        private void FillSoft(Color tint)
        {
            int count = _shapeCount;
            if (count > 1 && (_shape[0] - _shape[count - 1]).sqrMagnitude < .000001f) count--;
            if (count < 3 || tint.a <= .001f) return;
            FillContour(tint);
            if (!_featherLines) return;
            float area = 0f;
            for (int i = 0; i < count; i++)
            {
                Vector2 a = _shape[i], b = _shape[(i + 1) % count];
                area += a.x * b.y - b.x * a.y;
            }
            float outward = area > 0f ? 1f : -1f;
            float feather = .75f * _unitsPerPixel;
            Color clear = new Color(tint.r, tint.g, tint.b, 0f);
            int first = _mesh.currentVertCount;
            for (int i = 0; i < count; i++)
            {
                Vector2 point = _shape[i], previous = _shape[(i + count - 1) % count], next = _shape[(i + 1) % count];
                Vector2 before = point - previous, after = next - point;
                if (before.sqrMagnitude < .0000001f) before = after;
                if (after.sqrMagnitude < .0000001f) after = before;
                before.Normalize();
                after.Normalize();
                Vector2 normalBefore = new Vector2(before.y, -before.x) * outward, normalAfter = new Vector2(after.y, -after.x) * outward;
                Vector2 miter = normalBefore + normalAfter;
                float length = miter.magnitude;
                miter = length < .0001f ? normalBefore : miter / length;
                float stretch = 1f / Mathf.Max(.5f, Vector2.Dot(miter, normalBefore));
                _mesh.AddVert(point, tint, Vector2.zero);
                _mesh.AddVert(point + miter * (feather * stretch), clear, Vector2.zero);
            }
            for (int i = 0; i < count; i++)
            {
                int a = first + i * 2, b = first + ((i + 1) % count) * 2;
                _mesh.AddTriangle(a, a + 1, b + 1);
                _mesh.AddTriangle(b + 1, b, a);
            }
        }

        /// <summary>Dark separation under a shape that lies in front of another one.</summary>
        private void Halo(float opacity, float pixels = 2.4f)
            => Ribbon(true, new Color(_dark.r, _dark.g, _dark.b, opacity), Mathf.Max(pixels * _unitsPerPixel, 1.1f * _u));

        private void Disc(Vector2 center, float radiusX, float radiusY, Color tint, float rotation = 0f)
        {
            float pixels = Mathf.Max(radiusX, radiusY) / Mathf.Max(.0001f, _unitsPerPixel);
            int segments = Mathf.Clamp(Mathf.CeilToInt(pixels * 1.6f), 8, 28);
            float cosine = Mathf.Cos(rotation), sine = Mathf.Sin(rotation);
            _shapeCount = 0;
            for (int i = 0; i < segments; i++)
            {
                float angle = i * Mathf.PI * 2f / segments;
                float x = Mathf.Cos(angle) * radiusX, y = Mathf.Sin(angle) * radiusY;
                _shape[_shapeCount++] = center + new Vector2(x * cosine - y * sine, x * sine + y * cosine);
            }
            FillSoft(tint);
        }

        /// <summary>Stroke width that follows the doll size and the Inspector line setting.</summary>
        private float Stroke(float units) => Mathf.Max(.25f * _unitsPerPixel, units * _u * (LineWidth / 1.1f));

        private Color Tone(float value, float opacity)
            => new Color(Mathf.Clamp01(_bone.r * value), Mathf.Clamp01(_bone.g * value), Mathf.Clamp01(_bone.b * value), _bone.a * opacity);

        private static Color Tone(Color tint, float value, float opacity)
            => new Color(Mathf.Clamp01(tint.r * value), Mathf.Clamp01(tint.g * value), Mathf.Clamp01(tint.b * value), tint.a * opacity);

        private Color Shade(float opacity) => new Color(_dark.r, _dark.g, _dark.b, _bone.a * opacity);

        private void SetupDesignFrame()
        {
            Rect chest = AnatomicalFrame(ThoraxRect, R(BodyPart.Chest));
            Rect skull = AnatomicalFrame(CraniumRect, Sub(R(BodyPart.Head), .18f, .29f, .64f, .70f));
            _cx = chest.center.x;
            _yHip = (BonePoint(BodyPart.LeftQuadriceps, 0f).y + BonePoint(BodyPart.RightQuadriceps, 0f).y) * .5f;
            _kx = chest.width / 128.6f;
            _ky = Mathf.Max(.01f, (chest.yMax - _yHip) / 204.1f);
            _u = skull.height / 98.7f;
        }

        /// <summary>Torso design point: dx from the midline and height in reference units.</summary>
        private Vector2 D(float dx, float y) => new Vector2(_cx + dx * _kx, _yHip + (y + 208.7f) * _ky);

        private Color PartBone(BodyPart part, float value = 1f, float opacity = .86f)
        {
            Color tone = Tone(value, opacity);
            if (State == null || !State.Parts[(int)part].Fractured) return tone;
            Color tint = VisualStyle != null ? VisualStyle.Evaluate(State.Parts[(int)part].Health01) : _injury;
            return Color.Lerp(tone, new Color(tint.r, tint.g, tint.b, tone.a), .28f);
        }
    }
}
