using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>One small owner per panel; targets change on data refresh, colors advance on UI frames.</summary>
    public sealed class K_HealthColorAnimator
    {
        private sealed class Track
        {
            public UnityEngine.UI.Graphic View;
            public Color Target;
            public float Seconds;
            public bool Suspended;
        }
        private readonly List<Track> _tracks = new List<Track>(24);
        public void SetTarget(UnityEngine.UI.Graphic view, Color target, float seconds)
        {
            if(view == null) return;
            foreach(var track in _tracks)
                if(track.View == view){track.Target=target;track.Seconds=seconds;return;}
            _tracks.Add(new Track{View=view,Target=target,Seconds=seconds});
        }
        public void Suspend(UnityEngine.UI.Graphic view,bool suspended)
        {
            foreach(var track in _tracks)if(track.View==view){track.Suspended=suspended;return;}
            if(view!=null)_tracks.Add(new Track{View=view,Target=view.color,Seconds=.35f,Suspended=suspended});
        }
        public void Tick(float deltaTime)
        {
            if(float.IsNaN(deltaTime)||float.IsInfinity(deltaTime)||deltaTime<=0f)return;
            foreach(var track in _tracks)
            {
                if(track.View==null||!track.View.isActiveAndEnabled||track.Suspended)continue;
                Color current=track.View.color;
                if(current==track.Target)continue;
                float seconds=float.IsNaN(track.Seconds)||float.IsInfinity(track.Seconds)? .35f:Mathf.Max(.01f,track.Seconds);
                track.View.color=Color.Lerp(current,track.Target,1f-Mathf.Exp(-deltaTime/seconds));
            }
        }
    }
}
