using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public sealed partial class K_HealthDollAnatomyGraphic
    {
        private Color OrganFillTone(float red, float green, float blue, float strength)
            => new Color(Mathf.Clamp01(OrganTint.r * red), Mathf.Clamp01(OrganTint.g * green), Mathf.Clamp01(OrganTint.b * blue),
                Mathf.Clamp01(_organFill.a * strength));

        private Color OrganLine(Color fill, float opacity)
        {
            Color line = Color.Lerp(new Color(fill.r, fill.g, fill.b, 1f), new Color(.88f, .80f, .76f, 1f), .42f);
            line.a = _organ.a * opacity;
            return line;
        }

        private Color OrganDark(Color fill, float opacity)
        {
            Color shade = Color.Lerp(new Color(fill.r, fill.g, fill.b, 1f), new Color(.10f, .09f, .095f, 1f), .55f);
            shade.a = _organ.a * opacity;
            return shade;
        }

        /// <summary>Fills the contour in the shape buffer and gives it a thin lighter edge.</summary>
        private void Organ(Color fill, float outline = .78f, float width = .9f)
        {
            FillSoft(fill);
            Ribbon(true, OrganLine(fill, outline), Stroke(width));
        }

        private void OrganContour(float[] x, float[] y)
        {
            Knots();
            for (int i = 0; i < x.Length; i++) K(D(x[i], y[i]));
            SplineClosed();
        }

        private void OrganCurve(Color tint, float width, params float[] xy)
        {
            Knots();
            for (int i = 0; i + 1 < xy.Length; i += 2) K(D(xy[i], xy[i + 1]));
            SplineOpen();
            Ribbon(false, tint, Stroke(width));
        }

        private void DrawOrgans()
        {
            Rect head = AnatomicalFrame(CraniumRect, Sub(R(BodyPart.Head), .18f, .29f, .64f, .70f));
            DrawKidneysAndBladder();
            DrawLungs();
            DrawHeart();
            DrawUpperAbdomen();
            DrawBowel();
            DrawBrain(head);
        }

        private void DrawKidneysAndBladder()
        {
            // Posterior organs stay faint: the digestive tract lies in front of them.
            Color kidney = OrganFillTone(.92f, .78f, .80f, .78f);
            for (int side = -1; side <= 1; side += 2)
            {
                float lower = side < 0 ? -3.5f : 0f;
                float[] kx = { 27f, 33f, 35f, 33.5f, 28f, 22f, 19.5f, 22.5f, 21.5f, 19.5f, 22f };
                float[] ky = { -114f, -118f, -128f, -140f, -147f, -145f, -138f, -131f, -127f, -121f, -115.5f };
                Knots();
                for (int i = 0; i < kx.Length; i++) K(D(side * kx[i], ky[i] + lower));
                SplineClosed();
                Organ(kidney, .5f, .8f);
                // Ureter toward the bladder.
                OrganCurve(OrganLine(kidney, .34f), 1.1f, side * 21.5f, -130f + lower, side * 15f, -160f, side * 11f, -196f, side * 5f, -221f);
            }
            float[] bx = { -8.5f, -5f, 0f, 5f, 8.5f, 6f, 0f, -6f };
            float[] by = { -224f, -218.5f, -216.5f, -218.5f, -224f, -229.5f, -231f, -229.5f };
            OrganContour(bx, by);
            Organ(OrganFillTone(1.04f, 1.0f, .92f, .85f), .55f, .8f);
        }

        private void DrawLungs()
        {
            Color lung = OrganFillTone(1.06f, 1.15f, 1.19f, 1.12f);
            Color airway = OrganFillTone(1.20f, 1.26f, 1.30f, .92f);
            // Trachea and the two main bronchi.
            OrganCurve(airway, 7.2f, 0f, 17f, 0f, -8f, .4f, -34f);
            for (int ring = 0; ring < 6; ring++)
            {
                float y = 12f - ring * 7.2f;
                OrganCurve(OrganDark(airway, .34f), .8f, -3.3f, y, 0f, y - .9f, 3.3f, y);
            }
            for (int side = -1; side <= 1; side += 2)
            {
                Knots();
                K(D(.4f, -33f)); K(D(side * 8f, -40f)); K(D(side * 15f, -47f + (side < 0 ? 1.5f : 0f)));
                SplineOpen();
                Ribbon(false, airway, airway, Stroke(5.6f), Stroke(4.2f));
            }

            // Right lung (on the viewer's left): three lobes over the dome of the liver.
            float[] rx = { -16f, -30f, -41f, -47.5f, -50f, -50.5f, -49f, -45f, -38f, -27f, -15f, -7.5f, -6f, -8.5f, -7f, -7f, -10f };
            float[] ry = { -4f, -14f, -30f, -50f, -72f, -90f, -102f, -88f, -78.5f, -72.5f, -73.5f, -77f, -66f, -46f, -30f, -14f, -6.5f };
            OrganContour(rx, ry);
            Organ(lung);
            OrganCurve(OrganDark(lung, .50f), .9f, -49f, -52f, -30f, -51f, -9f, -47.5f);
            OrganCurve(OrganDark(lung, .50f), .9f, -50f, -75f, -34f, -83f, -17f, -76.5f);
            // Left lung: two lobes and the notch that makes room for the heart.
            float[] lx = { 16f, 30f, 41f, 47.5f, 50f, 50.5f, 49f, 44f, 37f, 30f, 26.5f, 27f, 22f, 12.5f, 8f, 7f, 10f };
            float[] ly = { -4f, -14f, -30f, -50f, -72f, -90f, -102f, -90f, -82.5f, -80f, -80.5f, -70f, -56f, -42f, -30f, -14f, -6.5f };
            OrganContour(lx, ly);
            Organ(lung);
            OrganCurve(OrganDark(lung, .50f), .9f, 49.5f, -58f, 40f, -72f, 28.5f, -80f);
            // Lobar bronchi fade into the lung tissue.
            for (int side = -1; side <= 1; side += 2)
            {
                Vector2 hilum = D(side * 15f, -47f);
                for (int branch = 0; branch < 3; branch++)
                {
                    Vector2 end = D(side * (30f + branch * 4.5f), -24f - branch * 23f);
                    BezierShape(hilum, Vector2.Lerp(hilum, end, .35f) + new Vector2(0f, (1 - branch) * 3f * _ky),
                        Vector2.Lerp(hilum, end, .7f), end);
                    Ribbon(false, OrganLine(lung, .62f), OrganLine(lung, .0f), Stroke(2.3f), Stroke(.9f));
                }
            }
        }

        private void DrawHeart()
        {
            Color heart = OrganFillTone(1.15f, .84f, .86f, 1.62f);
            Color vessel = OrganFillTone(1.16f, .90f, .90f, 1.42f);
            // Superior vena cava, aortic arch and pulmonary trunk leave the base.
            OrganCurve(Tone(vessel, .9f, .85f), 5f, -9.5f, -42f, -9.5f, -30f, -9f, -19f);
            Knots();
            K(D(1.5f, -41f)); K(D(-1.5f, -31f)); K(D(3.5f, -23.5f)); K(D(11.5f, -24.5f)); K(D(15.5f, -32f)); K(D(15f, -41f));
            SplineOpen();
            Ribbon(false, vessel, Tone(vessel, .9f, .8f), Stroke(7.4f), Stroke(6f));
            OrganCurve(vessel, 6.2f, 8f, -43f, 12.5f, -37f, 19.5f, -34.5f);

            float[] hx = { -9f, -13.5f, -14f, -10f, 0f, 14f, 27f, 34f, 35.5f, 32f, 26f, 19f, 12f, 3f, -4f };
            float[] hy = { -40f, -50f, -62f, -72f, -78f, -82f, -83.5f, -80f, -72f, -60f, -50f, -42.5f, -38f, -37f, -38f };
            OrganContour(hx, hy);
            Organ(heart, .85f, 1f);
            // Coronary groove and the anterior interventricular groove.
            OrganCurve(OrganDark(heart, .55f), 1f, -12.5f, -56f, 2f, -50f, 18f, -45f);
            OrganCurve(OrganDark(heart, .55f), 1f, 16.5f, -45f, 21f, -60f, 28f, -79f);
            OrganCurve(OrganLine(heart, .38f), .9f, -3f, -74f, 10f, -70f, 22f, -62f);
        }

        private void DrawUpperAbdomen()
        {
            // Diaphragm: the line that separates the chest from the abdomen.
            Color dome = OrganLine(OrganFillTone(1f, 1f, 1f, 1f), .36f);
            OrganCurve(dome, 1f, -51f, -106f, -46.5f, -89f, -39.5f, -79.5f, -27.5f, -73.5f, -14f, -75f, 0f, -79.5f,
                14f, -81f, 28f, -81f, 38f, -84f, 45f, -91.5f, 50.5f, -105f);

            Color liver = OrganFillTone(.88f, .80f, .80f, 1.52f);
            float[] vx = { -50.5f, -47f, -40f, -28f, -14f, 0f, 13f, 23.5f, 20f, 6f, -8f, -22f, -36f, -46f, -51f, -52f };
            float[] vy = { -104f, -91f, -81.5f, -75.5f, -77f, -82f, -86f, -90f, -95.5f, -101f, -108.5f, -117.5f, -126f, -130f, -121f, -110f };
            OrganContour(vx, vy);
            Organ(liver, .8f, 1f);
            OrganCurve(OrganDark(liver, .50f), 1f, -2.5f, -82.5f, -4.5f, -93f, -7f, -107f);
            OrganCurve(OrganLine(liver, .30f), .9f, -46f, -97f, -30f, -84f, -14f, -84f);
            // Gallbladder shows under the edge of the liver.
            Color gall = OrganFillTone(.86f, .92f, .70f, 1.3f);
            float[] gx = { -26f, -22.5f, -21.5f, -24f, -27.5f, -28.5f };
            float[] gy = { -114f, -117f, -122.5f, -126.5f, -124f, -118f };
            OrganContour(gx, gy);
            Organ(gall, .6f, .8f);

            // Spleen behind the stomach.
            Color spleen = OrganFillTone(.98f, .72f, .78f, 1.3f);
            float[] px = { 44.5f, 48.5f, 50.5f, 49.5f, 46.5f, 43.5f, 43f };
            float[] py = { -91f, -93f, -100f, -108.5f, -112.5f, -108f, -98f };
            OrganContour(px, py);
            Organ(spleen, .55f, .8f);

            Color stomach = OrganFillTone(1.08f, 1.02f, .98f, 1.34f);
            float[] sx = { 10f, 16f, 26f, 36f, 42f, 43.5f, 39f, 30f, 19f, 8f, 0f, -6f, -7.5f, -2f, 5f, 12f, 17f, 18f, 15f, 11f };
            float[] sy = { -86f, -83f, -82f, -86f, -94f, -104f, -116f, -125f, -129.5f, -128f, -123f, -118.5f, -114.5f, -113f, -116f,
                -117.5f, -112f, -102f, -93f, -89f };
            OrganContour(sx, sy);
            Organ(stomach, .8f, 1f);
            OrganCurve(OrganDark(stomach, .36f), .9f, 24f, -90f, 31f, -102f, 27f, -117f, 15f, -123.5f);
            OrganCurve(OrganDark(stomach, .28f), .9f, 31f, -89f, 37.5f, -102f, 33f, -117f);
        }

        private void DrawBowel()
        {
            // Small intestine: one tube laid in loops inside the frame of the colon.
            Color small = OrganFillTone(1.10f, 1.02f, .95f, 1.22f);
            float[] rowY = { -146.5f, -155.5f, -164.5f, -173.5f, -182f };
            float[] rowHalf = { 27f, 28f, 27f, 23f, 15f };
            Knots();
            for (int row = 0; row < rowY.Length; row++)
            {
                int steps = 6;
                for (int step = 0; step <= steps; step++)
                {
                    float t = step / (float)steps;
                    float x = Mathf.Lerp(-rowHalf[row], rowHalf[row], row % 2 == 0 ? t : 1f - t);
                    float wobble = Mathf.Sin((step + row * .5f) * 2.2f) * 2.3f;
                    K(D(x, rowY[row] + wobble));
                }
            }
            SplineOpen();
            Ribbon(false, OrganLine(small, .50f), Stroke(8.6f));
            Ribbon(false, small, Stroke(6.8f));

            // Large intestine: caecum, ascending, transverse and descending colon, sigmoid loop, rectum.
            Color colon = OrganFillTone(1.10f, 1.10f, 1.02f, 1.40f);
            float[] cx = { -35f, -40f, -42f, -41.5f, -38.5f, -28f, -14f, 0f, 14f, 28f, 39f, 43.5f, 43f, 42f, 39f, 33f, 24f, 14.5f, 8f, 3f, 0f, 0f };
            float[] cy = { -187f, -177f, -161f, -146f, -134.5f, -131f, -136f, -139f, -136.5f, -130f, -125f, -134.5f, -150f, -165f, -178f,
                -187f, -191.5f, -189f, -193.5f, -201f, -210f, -218f };
            Knots();
            for (int i = 0; i < cx.Length; i++) K(D(cx[i], cy[i]));
            SplineOpen();
            Ribbon(false, OrganLine(colon, .62f), Stroke(13.6f));
            Ribbon(false, colon, colon, Stroke(11.8f), Stroke(8.4f));
            // Haustra: alternating pouches along the colon wall.
            int points = Mathf.Min(_shapeCount, _center.Length);
            for (int i = 0; i < points; i++) _center[i] = _shape[i];
            float spacing = 6.4f * _u, travelled = 0f;
            int pouch = 0;
            Color fold = OrganDark(colon, .46f);
            for (int i = 1; i < points - 1; i++)
            {
                travelled += Vector2.Distance(_center[i], _center[i - 1]);
                if (travelled < spacing) continue;
                travelled = 0f;
                Vector2 tangent = (_center[i + 1] - _center[i - 1]).normalized;
                Vector2 normal = new Vector2(-tangent.y, tangent.x) * (pouch++ % 2 == 0 ? 1f : -1f);
                float half = Mathf.Lerp(5.7f, 4f, i / (float)points) * _u;
                _shapeCount = 2;
                _shape[0] = _center[i] + normal * half;
                _shape[1] = _center[i] + normal * half * .12f;
                Ribbon(false, fold, Alpha(fold, .2f), Stroke(1.1f), Stroke(.8f));
            }
            // Appendix.
            OrganCurve(OrganLine(colon, .7f), 1.6f, -35.5f, -191.5f, -32.5f, -195.5f, -31.5f, -200.5f);
        }

        private void DrawBrain(Rect head)
        {
            Color brain = OrganFillTone(1.12f, 1.20f, 1.24f, 1.30f);
            float[] bx = { 0f, .125f, .245f, .33f, .372f, .378f, .368f, .345f, .315f, .30f, .20f, .10f, .035f, 0f };
            float[] by = { .925f, .918f, .882f, .812f, .735f, .665f, .60f, .552f, .575f, .615f, .628f, .622f, .612f, .618f };
            Knots();
            for (int i = 0; i < bx.Length; i++) K(P(head, .5f + bx[i], by[i]));
            for (int i = bx.Length - 2; i >= 1; i--) K(P(head, .5f - bx[i], by[i]));
            SplineClosed();
            Organ(brain, .8f, 1f);
            // Longitudinal fissure and a few gyri on each hemisphere.
            _shapeCount = 2;
            _shape[0] = P(head, .5f, .922f);
            _shape[1] = P(head, .5f, .62f);
            Ribbon(false, OrganDark(brain, .62f), Stroke(1.1f));
            float[][] gyri =
            {
                new[] { .045f, .86f, .12f, .875f, .17f, .845f, .25f, .85f },
                new[] { .04f, .79f, .11f, .81f, .16f, .775f, .235f, .795f, .30f, .765f },
                new[] { .045f, .72f, .10f, .74f, .17f, .705f, .245f, .725f, .33f, .695f },
                new[] { .05f, .66f, .12f, .675f, .19f, .65f, .27f, .665f, .345f, .64f },
                new[] { .20f, .905f, .23f, .87f, .29f, .84f },
                new[] { .315f, .60f, .34f, .585f, .355f, .60f }
            };
            Color fold = OrganDark(brain, .42f);
            for (int side = -1; side <= 1; side += 2)
            for (int gyrus = 0; gyrus < gyri.Length; gyrus++)
            {
                Knots();
                for (int i = 0; i + 1 < gyri[gyrus].Length; i += 2) K(P(head, .5f + side * gyri[gyrus][i], gyri[gyrus][i + 1]));
                SplineOpen();
                Ribbon(false, fold, Stroke(.9f));
            }
        }
    }
}
