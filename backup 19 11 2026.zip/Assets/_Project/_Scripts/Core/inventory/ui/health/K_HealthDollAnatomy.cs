using System;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Procedural anatomy presentation. Health and wound ownership stays with the character.</summary>
    [DisallowMultipleComponent]
    [DefaultExecutionOrder(1200)]
    public sealed class K_HealthDollAnatomy : MonoBehaviour
    {
        [Serializable]
        public sealed class Settings
        {
            [Tooltip("Показывать программную анатомию и признаки состояний на кукле инвентаря.")]
            public bool Enabled = true;
            [Range(0f, 1f), Tooltip("Прозрачность исходного силуэта при включённой анатомии. Цвета и размеры исходных картинок сохраняются.")]
            public float SurfaceOpacity = .22f;
            [Range(0f, 1f), Tooltip("Видимость программного скелета.")]
            public float SkeletonOpacity = .82f;
            [Range(0f, 1f), Tooltip("Видимость программных органов.")]
            public float OrganOpacity = .65f;
            [Tooltip("Оттенок мягких тканей органов на анатомической схеме.")]
            public Color OrganTint = new Color(.54f, .40f, .36f, 1f);
            [Range(0f, 1f), Tooltip("Плотность заливки органов. Помогает различать органы и контуры костей.")]
            public float OrganFillStrength = .65f;
            [Range(0f, 1f), Tooltip("Видимость нервной системы: сплетений и основных ветвей к конечностям.")]
            public float NerveOpacity = .75f;
            [Tooltip("Базовый оттенок нервных путей. Состояния персонажа дополнительно меняют их выраженность.")]
            public Color NerveTint = Color.white;
            [Range(.5f, 3f), Tooltip("Толщина анатомических контуров в единицах Canvas.")]
            public float LineWidth = 1.1f;
        }

        private readonly K_HealthDollAnatomyState _state = new K_HealthDollAnatomyState();
        private readonly float[] _sourceAlpha = new float[20];
        private readonly bool[] _alphaCaptured = new bool[20];
        private readonly Sprite[] _cachedSprites = new Sprite[20];
        private readonly Rect[] _spriteBounds = new Rect[20];
        private readonly K_HealthDollSilhouette[] _profiles = new K_HealthDollSilhouette[20];
        private K_InventoryHealthWidget _owner;
        private UnityEngine.UI.Image[] _segments;
        private K_HealthSystem _health;
        private K_VitalitySystem _vitality;
        private K_DebuffSystem _debuffs;
        private K_BloodSystem _blood;
        private K_WeightManager _weight;
        private K_IllnessSystem _illness;
        private K_HealthVisualStyle _visualStyle;
        private Settings _settings;
        private K_HealthDollAnatomyGraphic _graphic;
        private float _nextRefresh;

        public K_HealthDollAnatomyState State => _state;
        public K_HealthDollAnatomyGraphic Graphic => _graphic;

        public static K_HealthDollAnatomy Ensure(K_InventoryHealthWidget owner, UnityEngine.UI.Image[] segments,
            Settings settings, K_HealthSystem health, K_VitalitySystem vitality, K_DebuffSystem debuffs,
            K_BloodSystem blood, K_WeightManager weight, K_HealthVisualStyle visualStyle)
        {
            if (owner == null) return null;
            var anatomy = owner.GetComponent<K_HealthDollAnatomy>();
            if (anatomy == null) anatomy = owner.gameObject.AddComponent<K_HealthDollAnatomy>();
            anatomy._owner = owner;
            anatomy._segments = segments;
            anatomy._settings = settings;
            anatomy._health = health;
            anatomy._vitality = vitality;
            anatomy._debuffs = debuffs;
            anatomy._blood = blood;
            anatomy._weight = weight;
            anatomy._visualStyle = visualStyle;
            anatomy._illness = health != null ? health.GetComponent<K_IllnessSystem>() : null;
            anatomy.RefreshNow();
            return anatomy;
        }

        private void LateUpdate()
        {
            if (!CanShow()) { Hide(); return; }
            EnsureVisuals();
            FitSegments();
            ApplySurfaceOpacity();
            if (Time.unscaledTime >= _nextRefresh) RefreshNow();
        }

        public void RefreshNow()
        {
            if (!CanShow()) { Hide(); return; }
            EnsureVisuals();
            FitSegments();
            ApplySurfaceOpacity();
            _state.Refresh(_health, _vitality, _debuffs, _blood, _weight, _illness);
            _graphic.State = _state;
            _graphic.Wounds = _health != null ? _health.AnatomicalWounds : null;
            _graphic.SkeletonOpacity = Mathf.Clamp01(_settings.SkeletonOpacity);
            _graphic.OrganOpacity = Mathf.Clamp01(_settings.OrganOpacity);
            _graphic.OrganTint = _settings.OrganTint;
            _graphic.OrganFillStrength = Mathf.Clamp01(_settings.OrganFillStrength);
            _graphic.NerveOpacity = Mathf.Clamp01(_settings.NerveOpacity);
            _graphic.NerveTint = _settings.NerveTint;
            _graphic.LineWidth = Mathf.Clamp(_settings.LineWidth, .5f, 3f);
            _graphic.VisualStyle = _visualStyle;
            _graphic.SetVerticesDirty();
            _nextRefresh = Time.unscaledTime + .2f;
        }

        private bool CanShow() => isActiveAndEnabled && _owner != null && _owner.isActiveAndEnabled &&
            _segments != null && _settings != null && _settings.Enabled;

        private void EnsureVisuals()
        {
            if (_graphic == null)
            {
                var go = new GameObject("AnatomyOverlay", typeof(RectTransform), typeof(CanvasRenderer), typeof(K_HealthDollAnatomyGraphic));
                go.layer = gameObject.layer;
                go.transform.SetParent(_owner.transform.parent, false);
                _graphic = go.GetComponent<K_HealthDollAnatomyGraphic>();
                var rect = _graphic.rectTransform;
                rect.anchorMin = rect.anchorMax = rect.pivot = new Vector2(.5f, .5f);
                rect.anchoredPosition = Vector2.zero;
                rect.sizeDelta = new Vector2(600f, 1000f);
                rect.localScale = Vector3.one;
                _graphic.raycastTarget = false;
                _graphic.maskable = true;
                _graphic.color = Color.white;
                _graphic.transform.SetSiblingIndex(_owner.transform.GetSiblingIndex() + 1);
            }
            _graphic.gameObject.SetActive(true);
        }

        private void FitSegments()
        {
            bool changed = false;
            int count = Mathf.Min(20, _segments.Length);
            for (int i = 0; i < 20; i++)
            {
                var image = i < count ? _segments[i] : null;
                if (image == null || image.sprite == null)
                {
                    if (_graphic.PartRects[i] != Rect.zero) { _graphic.PartRects[i] = Rect.zero; changed = true; }
                    continue;
                }
                if (_cachedSprites[i] != image.sprite)
                {
                    _cachedSprites[i] = image.sprite;
                    _profiles[i] = K_HealthDollSilhouette.Get(image.sprite);
                    _graphic.SilhouetteProfiles[i] = _profiles[i];
                    _spriteBounds[i] = _profiles[i].Bounds;
                    for (int row = 0; row < K_HealthDollAnatomyGraphic.SurfaceSectionCount; row++)
                    {
                        float y = row / (float)(K_HealthDollAnatomyGraphic.SurfaceSectionCount - 1);
                        _graphic.SurfaceSections[i * K_HealthDollAnatomyGraphic.SurfaceSectionCount + row] =
                            new Vector2(_profiles[i].CenterAt(y).x, _profiles[i].WidthAt(y));
                    }
                }
                var drawRect = image.GetPixelAdjustedRect();
                if (image.preserveAspect && image.sprite != null)
                {
                    float aspect = image.sprite.rect.width / image.sprite.rect.height;
                    if (drawRect.width / drawRect.height > aspect)
                    {
                        float width = drawRect.height * aspect;
                        drawRect.x += (drawRect.width - width) * image.rectTransform.pivot.x;
                        drawRect.width = width;
                    }
                    else
                    {
                        float height = drawRect.width / aspect;
                        drawRect.y += (drawRect.height - height) * image.rectTransform.pivot.y;
                        drawRect.height = height;
                    }
                }
                Rect uv = _spriteBounds[i];
                Vector2 a = ToOverlay(image.rectTransform.TransformPoint(new Vector3(drawRect.x + uv.xMin * drawRect.width, drawRect.y + uv.yMin * drawRect.height, 0f)));
                Vector2 b = ToOverlay(image.rectTransform.TransformPoint(new Vector3(drawRect.x + uv.xMax * drawRect.width, drawRect.y + uv.yMax * drawRect.height, 0f)));
                Rect part = Rect.MinMaxRect(Mathf.Min(a.x, b.x), Mathf.Min(a.y, b.y), Mathf.Max(a.x, b.x), Mathf.Max(a.y, b.y));
                if (_graphic.PartRects[i] != part) { _graphic.PartRects[i] = part; changed = true; }
            }
            FitAnatomicalLandmarks();
            if (changed) _graphic.SetVerticesDirty();
        }

        private void FitAnatomicalLandmarks()
        {
            Rect head = _graphic.PartRects[(int)BodyPart.Head];
            Rect chest = _graphic.PartRects[(int)BodyPart.Chest];
            Rect stomach = _graphic.PartRects[(int)BodyPart.Stomach];
            Rect pelvis = _graphic.PartRects[(int)BodyPart.Pelvis];
            _graphic.CraniumRect = new Rect(head.xMin + head.width * .18f, head.yMin + head.height * .29f,
                head.width * .64f, head.height * .70f);
            float centerX = (head.center.x + pelvis.center.x) * .5f;
            float thoraxWidth = Mathf.Min(chest.width * .91f, stomach.width * 1.22f);
            _graphic.ThoraxRect = Rect.MinMaxRect(centerX - thoraxWidth * .5f, stomach.yMax - stomach.height * .50f,
                centerX + thoraxWidth * .5f, chest.yMax - chest.height * .035f);
            _graphic.AbdomenRect = Rect.MinMaxRect(centerX - stomach.width * .44f, pelvis.yMin + pelvis.height * .35f,
                centerX + stomach.width * .44f, chest.yMin + chest.height * .36f);

            for (int i = 0; i < 20; i++) _graphic.TissueCenters[i] = SectionCenter((BodyPart)i, .52f);
            _graphic.TissueCenters[(int)BodyPart.Head] = Point(_graphic.CraniumRect, .55f, .54f);

            SetBone(BodyPart.Head, Point(_graphic.CraniumRect, .18f, .70f), Point(_graphic.CraniumRect, .17f, .36f));
            SetBone(BodyPart.Chest, Point(_graphic.ThoraxRect, .5f, .84f), Point(_graphic.ThoraxRect, .5f, .24f));
            SetBone(BodyPart.Stomach, stomach.center, stomach.center);
            SetBone(BodyPart.Pelvis, Point(pelvis, .16f, .74f), Point(pelvis, .29f, .35f));
            for (int side = 0; side < 2; side++)
            {
                float direction = side == 0 ? 1f : -1f;
                var shoulderPart = (BodyPart)(4 + side);
                var upperPart = (BodyPart)(6 + side);
                var forearmPart = (BodyPart)(8 + side);
                var handPart = (BodyPart)(10 + side);
                var thighPart = (BodyPart)(12 + side);
                var kneePart = (BodyPart)(14 + side);
                var shinPart = (BodyPart)(16 + side);
                var footPart = (BodyPart)(18 + side);
                Vector2 shoulder = SectionCenter(shoulderPart, .54f);
                Vector2 elbow = (SectionCenter(upperPart, .10f) + SectionCenter(forearmPart, .84f)) * .5f;
                Vector2 wrist = (SectionCenter(forearmPart, .08f) + SectionCenter(handPart, .90f)) * .5f;
                Vector2 hip = new Vector2(centerX + direction * pelvis.width * .32f, pelvis.yMin + pelvis.height * .59f);
                Vector2 knee = SectionCenter(kneePart, .50f);
                Vector2 ankle = (SectionCenter(shinPart, .06f) + SectionCenter(footPart, .88f)) * .5f;
                SetBone(shoulderPart, Point(_graphic.ThoraxRect, .5f + direction * .07f, .95f), shoulder);
                SetBone(upperPart, shoulder, elbow);
                SetBone(forearmPart, elbow, wrist);
                SetBone(handPart, wrist, SectionCenter(handPart, .42f));
                SetBone(thighPart, hip, knee);
                SetBone(kneePart, knee + Vector2.up * _graphic.PartRects[(int)kneePart].height * .16f,
                    knee - Vector2.up * _graphic.PartRects[(int)kneePart].height * .16f);
                SetBone(shinPart, knee, ankle);
                SetBone(footPart, ankle, SectionCenter(footPart, .25f));
            }
        }

        private Vector2 SectionCenter(BodyPart part, float y)
        {
            int index = (int)part;
            Vector2 normalized = _profiles[index] != null ? _profiles[index].CenterAt(y) : new Vector2(.5f, y);
            return Point(_graphic.PartRects[index], normalized.x, normalized.y);
        }

        private void SetBone(BodyPart part, Vector2 start, Vector2 end)
        {
            _graphic.BoneStarts[(int)part] = start;
            _graphic.BoneEnds[(int)part] = end;
        }

        private static Vector2 Point(Rect rect, float x, float y)
            => new Vector2(rect.xMin + rect.width * x, rect.yMin + rect.height * y);

        // Old authored doll roots can have Z scale zero. Invert the usable UI plane explicitly.
        private Vector2 ToOverlay(Vector3 world)
            => ToLocalPlane(_graphic.transform, world);

        private static Vector2 ToLocalPlane(Transform space, Vector3 world)
        {
            Matrix4x4 m = space.localToWorldMatrix;
            float determinant = m.m00 * m.m11 - m.m01 * m.m10;
            if (Mathf.Abs(determinant) < .000001f) return Vector2.zero;
            float x = world.x - m.m03, y = world.y - m.m13;
            return new Vector2((x * m.m11 - y * m.m01) / determinant, (y * m.m00 - x * m.m10) / determinant);
        }

        private void ApplySurfaceOpacity()
        {
            for (int i = 0; i < Mathf.Min(20, _segments.Length); i++)
            {
                var image = _segments[i];
                if (image == null) continue;
                if (!_alphaCaptured[i])
                {
                    _sourceAlpha[i] = image.canvasRenderer.GetAlpha();
                    _alphaCaptured[i] = true;
                    _owner.RefreshAppliedOverlay((BodyPart)i);
                }
                image.canvasRenderer.SetAlpha(_sourceAlpha[i] * Mathf.Clamp01(_settings.SurfaceOpacity));
            }
        }

        private void Hide()
        {
            if (_graphic != null) _graphic.gameObject.SetActive(false);
            if (_segments == null) return;
            for (int i = 0; i < Mathf.Min(20, _segments.Length); i++)
            {
                if (_segments[i] != null && _alphaCaptured[i])
                {
                    _segments[i].canvasRenderer.SetAlpha(_sourceAlpha[i]);
                    if (_owner != null) _owner.RefreshAppliedOverlay((BodyPart)i);
                }
                _alphaCaptured[i] = false;
            }
        }

        private void OnDisable() => Hide();
        private void OnDestroy()
        {
            Hide();
            if (_graphic != null) Destroy(_graphic.gameObject);
        }

    }
}
