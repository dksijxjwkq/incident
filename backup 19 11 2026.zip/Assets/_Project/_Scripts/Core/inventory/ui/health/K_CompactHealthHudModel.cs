using System;
using System.Collections.Generic;

namespace K_Incident.Core.Inventory
{
    /// <summary>Fixed-capacity, manually paged view of existing presentation snapshots.</summary>
    public sealed class K_CompactHealthHudModel
    {
        public const int PageSize = 8;
        private readonly List<HealthGadgetEntry> _ordered = new List<HealthGadgetEntry>(32);
        private static readonly IComparer<HealthGadgetEntry> Order = new EntryComparer();
        public int Count => _ordered.Count;
        public int EffectCount => _ordered.Count;
        public int CurrentPage { get; private set; }
        public int PageCount => Math.Max(1, (_ordered.Count + PageSize - 1) / PageSize);
        public int VisibleCount => Math.Min(PageSize, _ordered.Count - CurrentPage * PageSize);
        public IReadOnlyList<HealthGadgetEntry> OrderedEffects => _ordered;

        public void Refresh(IReadOnlyList<HealthGadgetEntry> effects)
        {
            _ordered.Clear();
            if (effects != null)
                for (int i = 0; i < effects.Count; i++)
                    if (effects[i] != null && !effects[i].IsIndicator) _ordered.Add(effects[i]);
            _ordered.Sort(Order);
            // A refresh never chooses another page unless the current page ceased to exist.
            CurrentPage = Math.Min(CurrentPage, PageCount - 1);
        }

        public bool ChangePage(int delta)
        {
            long requested = (long)CurrentPage + delta;
            int next = (int)Math.Max(0L, Math.Min(PageCount - 1L, requested));
            if (next == CurrentPage) return false;
            CurrentPage = next;
            return true;
        }

        public HealthGadgetEntry GetVisible(int slot)
        {
            if (slot < 0 || slot >= VisibleCount) return null;
            return _ordered[CurrentPage * PageSize + slot];
        }

        public static int GetPriority(HealthGadgetKind kind)
        {
            // Fixed type priorities avoid timer ticks or changing severity shuffling the HUD.
            switch (kind)
            {
                case HealthGadgetKind.InternalBleeding: return 0;
                case HealthGadgetKind.Bleeding: return 1;
                case HealthGadgetKind.BreathingDifficulty: return 2;
                case HealthGadgetKind.Tbi: return 3;
                case HealthGadgetKind.Shock: return 4;
                case HealthGadgetKind.Immobilized: return 5;
                case HealthGadgetKind.Gunshot: return 6;
                case HealthGadgetKind.Fracture: return 7;
                case HealthGadgetKind.Laceration: return 8;
                case HealthGadgetKind.WoundInfection: return 9;
                case HealthGadgetKind.Concussion: return 10;
                case HealthGadgetKind.ColdIllness: return 11;
                case HealthGadgetKind.Drunk: return 12;
                case HealthGadgetKind.Hangover: return 13;
                case HealthGadgetKind.Fatigue: return 14;
                case HealthGadgetKind.Tourniquet: return 100;
                case HealthGadgetKind.Jett: return 101;
                case HealthGadgetKind.ChestSeal: return 102;
                case HealthGadgetKind.PelvicBinder: return 103;
                case HealthGadgetKind.Coagulant: return 104;
                case HealthGadgetKind.Txa: return 105;
                case HealthGadgetKind.Painkiller: return 106;
                case HealthGadgetKind.AntibioticTreatment: return 107;
                case HealthGadgetKind.Recovery: return 108;
                case HealthGadgetKind.HealBoost: return 109;
                case HealthGadgetKind.StimOn: return 110;
                case HealthGadgetKind.StimCooldown: return 111;
                default: return 50;
            }
        }

        private sealed class EntryComparer : IComparer<HealthGadgetEntry>
        {
            public int Compare(HealthGadgetEntry x, HealthGadgetEntry y)
            {
                int priority = GetPriority(x.Kind).CompareTo(GetPriority(y.Kind));
                return priority != 0 ? priority : ((int)x.Kind).CompareTo((int)y.Kind);
            }
        }
    }
}
