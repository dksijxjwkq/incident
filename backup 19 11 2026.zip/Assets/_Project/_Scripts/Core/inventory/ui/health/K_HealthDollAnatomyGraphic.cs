using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>Procedural anatomy and read-only medical marks in the existing doll's coordinate space.</summary>
    [AddComponentMenu("INCIDENT/UI/Anatomical Doll Graphic")]
    [RequireComponent(typeof(CanvasRenderer))]
    public sealed partial class K_HealthDollAnatomyGraphic : UnityEngine.UI.MaskableGraphic
    {
        [NonSerialized] public Rect[] PartRects = new Rect[20];
        [NonSerialized] public Vector2[] BoneStarts = new Vector2[20];
        [NonSerialized] public Vector2[] BoneEnds = new Vector2[20];
        [NonSerialized] public Vector2[] TissueCenters = new Vector2[20];
        internal const int SurfaceSectionCount = 65;
        [NonSerialized] public Vector2[] SurfaceSections = new Vector2[20 * SurfaceSectionCount];
        [NonSerialized] internal K_HealthDollSilhouette[] SilhouetteProfiles = new K_HealthDollSilhouette[20];
        [NonSerialized] public Rect CraniumRect;
        [NonSerialized] public Rect ThoraxRect;
        [NonSerialized] public Rect AbdomenRect;
        [NonSerialized] public K_HealthDollAnatomyState State;
        [NonSerialized] public IReadOnlyList<K_AnatomicalWound> Wounds;
        [Range(0f, 1f), Tooltip("Прозрачность костей и суставов анатомической схемы.")]
        public float SkeletonOpacity = .8f;
        [Range(0f, 1f), Tooltip("Прозрачность контуров и мягкой заливки органов.")]
        public float OrganOpacity = .65f;
        [Tooltip("Основной оттенок мягких тканей органов.")]
        public Color OrganTint = new Color(.54f, .40f, .36f, 1f);
        [Range(0f, 1f), Tooltip("Плотность заливки органов, которая отделяет их силуэт от костей.")]
        public float OrganFillStrength = .65f;
        [Range(0f, 1f), Tooltip("Видимость головного и спинного мозга, сплетений и основных ветвей нервной системы.")]
        public float NerveOpacity = .75f;
        [Tooltip("Оттенок нервных путей в спокойном состоянии. Известные неврологические эффекты дополнительно меняют их рисунок.")]
        public Color NerveTint = Color.white;
        [Min(.25f), Tooltip("Базовая толщина анатомических контуров в единицах Canvas.")]
        public float LineWidth = 1.1f;
        [Tooltip("Общая гамма состояния здоровья. Медицинские признаки дополнительно различаются формой.")]
        public K_HealthVisualStyle VisualStyle;

        private readonly Vector2[] _shape = new Vector2[384];
        private readonly int[] _fillPolygon = new int[384];
        private readonly int[] _fillTriangles = new int[1152];
        private readonly bool[] _exactOnSide = new bool[20];
        private readonly bool[] _hasLocatedWound = new bool[20];
        private UnityEngine.UI.VertexHelper _mesh;
        private Rect _pathRect;
        private int _shapeCount;
        private Color _bone, _organ, _organFill, _injury, _care, _dark;
        private float _unit;
        private float _unitsPerPixel;
        private bool _featherLines;

        public int RejectedFillContours { get; private set; }
        public bool UsedCompactGeometry { get; private set; }

        protected override void Awake()
        {
            base.Awake();
            raycastTarget = false;
        }

        protected override void OnPopulateMesh(UnityEngine.UI.VertexHelper mesh)
        {
            PopulateAnatomyMesh(mesh, false);
            if (mesh.currentVertCount > 64000) PopulateAnatomyMesh(mesh, true);
        }

        private void PopulateAnatomyMesh(UnityEngine.UI.VertexHelper mesh, bool compact)
        {
            mesh.Clear();
            RejectedFillContours = 0;
            UsedCompactGeometry = compact;
            if (PartRects == null || PartRects.Length < 20) return;
            _mesh = mesh;
            Rect head = R(BodyPart.Head);
            if (head.width <= 0f || head.height <= 0f) return;
            _unit = Mathf.Max(.45f, (CraniumRect.height > 0f ? CraniumRect.height : head.height * .7f) / 80f);
            float alive = State != null && State.IsDead ? .45f : 1f;
            const float neutral = 159f / 255f;
            _bone = new Color(neutral, neutral, neutral, SkeletonOpacity * alive);
            _organ = Color.Lerp(OrganTint, new Color(.85f, .75f, .69f, 1f), .45f);
            _organ.a = OrganOpacity * OrganTint.a * alive;
            _organFill = new Color(OrganTint.r, OrganTint.g, OrganTint.b,
                OrganOpacity * OrganFillStrength * OrganTint.a * alive);
            _injury = new Color(.48f, .27f, .29f, .84f * alive);
            _care = new Color(.57f, .60f, .55f, .78f * alive);
            _dark = new Color(.09f, .09f, .10f, .94f);
            _unitsPerPixel = UnitsPerScreenPixel();
            // Keep every injury at the cosmetic record limit within uGUI's 16-bit vertex budget.
            // Dense wound views retain the same anatomy using the compact solid strokes.
            _featherLines = !compact && VisibleExactWoundCount() <= 80;
            Array.Clear(_exactOnSide, 0, _exactOnSide.Length);
            Array.Clear(_hasLocatedWound, 0, _hasLocatedWound.Length);
            SetupDesignFrame();

            // Long gentle curves need fewer points than small bones.
            _sampleScale = 1.9f;
            DrawNervousHeadUnderlay();
            _sampleScale = 1.15f;
            if (SkeletonOpacity > .001f) { DrawAxialSkeleton(); DrawLimbs(); }
            _sampleScale = 1.5f;
            if (OrganOpacity > .001f) DrawOrgans();
            _sampleScale = 1.9f;
            DrawNervousSystem();
            _sampleScale = 1f;
            _featherLines = false;
            if (State == null) return;
            DrawWounds();
            for (int i = 0; i < 20; i++) DrawLocalState((BodyPart)i);
            DrawSystemicState();
        }

        private Rect R(BodyPart part)
        {
            // The controller fits each region to the main connected source silhouette.
            return PartRects[(int)part];
        }

        private static Vector2 P(Rect rect, float x, float y)
            => new Vector2(rect.xMin + rect.width * x, rect.yMin + rect.height * y);

        private Vector2 SurfacePoint(BodyPart part, float across, float y, float insetPixels = 1.8f)
        {
            Rect rect = R(part);
            float row = Mathf.Clamp01(y) * (SurfaceSectionCount - 1);
            int lower = Mathf.FloorToInt(row), upper = Mathf.Min(lower + 1, SurfaceSectionCount - 1);
            int offset = (int)part * SurfaceSectionCount;
            Vector2 section = SurfaceSections != null && SurfaceSections.Length >= offset + SurfaceSectionCount
                ? Vector2.Lerp(SurfaceSections[offset + lower], SurfaceSections[offset + upper], row - lower)
                : new Vector2(.5f, 1f);
            if (section.y <= .0001f) section = new Vector2(.5f, 1f);
            float halfWidth = Mathf.Max(0f, rect.width * section.y * .5f - insetPixels * _unitsPerPixel);
            Vector2 point = new Vector2(rect.xMin + rect.width * section.x + (Mathf.Clamp01(across) * 2f - 1f) * halfWidth,
                Mathf.Clamp(rect.yMin + rect.height * y, rect.yMin + insetPixels * _unitsPerPixel,
                    rect.yMax - insetPixels * _unitsPerPixel));
            return SnapSurfacePixel(part, point, insetPixels);
        }

        private Vector2 ConstrainToSurface(BodyPart part, Vector2 point, float insetPixels = 1.8f)
        {
            Rect rect = R(part);
            float y = rect.height > .001f ? (point.y - rect.yMin) / rect.height : .5f;
            Vector2 left = SurfacePoint(part, 0f, y, insetPixels), right = SurfacePoint(part, 1f, y, insetPixels);
            return SnapSurfacePixel(part, new Vector2(Mathf.Clamp(point.x, left.x, right.x), left.y), insetPixels);
        }

        private Vector2 SnapSurfacePixel(BodyPart part, Vector2 point, float insetPixels)
        {
            int index = (int)part;
            Rect rect = R(part);
            if (SilhouetteProfiles == null || index >= SilhouetteProfiles.Length || SilhouetteProfiles[index] == null ||
                rect.width <= .001f || rect.height <= .001f) return point;
            Vector2 normalized = new Vector2((point.x - rect.xMin) / rect.width, (point.y - rect.yMin) / rect.height);
            normalized = SilhouetteProfiles[index].SnapInside(normalized, insetPixels * _unitsPerPixel / rect.width);
            return P(rect, normalized.x, normalized.y);
        }

        public void CopySurfaceFitFrom(K_HealthDollAnatomyGraphic source)
        {
            SurfaceSections = (Vector2[])source.SurfaceSections.Clone();
            SilhouetteProfiles = (K_HealthDollSilhouette[])source.SilhouetteProfiles.Clone();
        }

        private void BeginContour(Vector2 point)
        {
            _shapeCount = 1;
            _shape[0] = point;
        }

        private void ContourCurve(Vector2 controlA, Vector2 controlB, Vector2 end)
        {
            Vector2 start = _shape[_shapeCount - 1];
            const int segments = 10;
            for (int i = 1; i <= segments && _shapeCount < _shape.Length; i++)
            {
                float t = i / (float)segments, inverse = 1f - t;
                _shape[_shapeCount++] = inverse * inverse * inverse * start +
                    3f * inverse * inverse * t * controlA + 3f * inverse * t * t * controlB + t * t * t * end;
            }
        }

        private void BezierStroke(Vector2 start, Vector2 controlA, Vector2 controlB, Vector2 end, Color tint, float width)
        {
            Vector2 previous = start;
            const int segments = 16;
            for (int i = 1; i <= segments; i++)
            {
                float t = i / (float)segments, inverse = 1f - t;
                Vector2 next = inverse * inverse * inverse * start + 3f * inverse * inverse * t * controlA +
                    3f * inverse * t * t * controlB + t * t * t * end;
                Line(previous, next, tint, width);
                previous = next;
            }
        }

        private static Rect Sub(Rect rect, float x, float y, float width, float height)
            => new Rect(rect.xMin + x * rect.width, rect.yMin + y * rect.height, rect.width * width, rect.height * height);

        private static Color Alpha(Color tint, float multiplier)
        {
            tint.a *= multiplier;
            return tint;
        }

        private void BeginPath(Rect rect, float x, float y)
        {
            _pathRect = rect;
            _shapeCount = 1;
            _shape[0] = P(rect, x, y);
        }

        private void To(float x, float y)
        {
            if (_shapeCount < _shape.Length) _shape[_shapeCount++] = P(_pathRect, x, y);
        }

        private void Curve(float x1, float y1, float x2, float y2, float x3, float y3)
        {
            if (_shapeCount == 0) return;
            Vector2 from = _shape[_shapeCount - 1], control1 = P(_pathRect, x1, y1);
            Vector2 control2 = P(_pathRect, x2, y2), end = P(_pathRect, x3, y3);
            const int subdivisions = 9;
            for (int step = 1; step <= subdivisions && _shapeCount < _shape.Length; step++)
            {
                float t = step / (float)subdivisions, inverse = 1f - t;
                _shape[_shapeCount++] = inverse * inverse * inverse * from + 3f * inverse * inverse * t * control1 +
                    3f * inverse * t * t * control2 + t * t * t * end;
            }
        }

        private void Shape(Color fill, Color outline, float width)
        {
            if (_shapeCount < 3) return;
            if (fill.a > .001f)
                FillContour(fill);
            if (outline.a > .001f && width > 0f)
            {
                Open(outline, width);
                Line(_shape[_shapeCount - 1], _shape[0], outline, width);
            }
        }

        private void FillContour(Color tint)
        {
            int count = _shapeCount;
            if ((_shape[0] - _shape[count - 1]).sqrMagnitude < .000001f) count--;
            if (count < 3) return;
            float area = 0f;
            Vector2 origin = _shape[0];
            for (int i = 0; i < count; i++)
            {
                Vector2 a = _shape[i] - origin, b = _shape[(i + 1) % count] - origin;
                area += a.x * b.y - b.x * a.y;
            }
            if (Mathf.Abs(area) < .000001f) return;
            for (int i = 0; i < count; i++) _fillPolygon[i] = area > 0f ? i : count - 1 - i;

            int remaining = count, triangleCount = 0;
            while (remaining > 3)
            {
                bool clipped = false;
                for (int i = 0; i < remaining; i++)
                {
                    int previous = _fillPolygon[(i + remaining - 1) % remaining];
                    int current = _fillPolygon[i];
                    int next = _fillPolygon[(i + 1) % remaining];
                    float cross = ContourCross(_shape[previous], _shape[current], _shape[next]);
                    if (Mathf.Abs(cross) < .000001f)
                    {
                        for (int j = i; j < remaining - 1; j++) _fillPolygon[j] = _fillPolygon[j + 1];
                        remaining--;
                        clipped = true;
                        break;
                    }
                    if (cross < 0f) continue;
                    bool occupied = false;
                    for (int j = 0; j < remaining; j++)
                    {
                        int point = _fillPolygon[j];
                        if (point == previous || point == current || point == next) continue;
                        Vector2 p = _shape[point];
                        if (ContourCross(_shape[previous], _shape[current], p) >= -.000001f &&
                            ContourCross(_shape[current], _shape[next], p) >= -.000001f &&
                            ContourCross(_shape[next], _shape[previous], p) >= -.000001f)
                        { occupied = true; break; }
                    }
                    if (occupied) continue;
                    _fillTriangles[triangleCount++] = previous;
                    _fillTriangles[triangleCount++] = current;
                    _fillTriangles[triangleCount++] = next;
                    for (int j = i; j < remaining - 1; j++) _fillPolygon[j] = _fillPolygon[j + 1];
                    remaining--;
                    clipped = true;
                    break;
                }
                if (!clipped) { RejectedFillContours++; return; }
            }
            if (remaining == 3)
            {
                _fillTriangles[triangleCount++] = _fillPolygon[0];
                _fillTriangles[triangleCount++] = _fillPolygon[1];
                _fillTriangles[triangleCount++] = _fillPolygon[2];
            }
            int first = _mesh.currentVertCount;
            for (int i = 0; i < count; i++) _mesh.AddVert(_shape[i], tint, Vector2.zero);
            for (int i = 0; i < triangleCount; i += 3)
                _mesh.AddTriangle(first + _fillTriangles[i], first + _fillTriangles[i + 1], first + _fillTriangles[i + 2]);
        }

        private static float ContourCross(Vector2 a, Vector2 b, Vector2 c)
            => (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x);

        private void Open(Color tint, float width)
        {
            for (int i = 1; i < _shapeCount; i++) Line(_shape[i - 1], _shape[i], tint, width);
        }

        private void CurveLine(Rect rect, float x0, float y0, float x1, float y1, float x2, float y2,
            float x3, float y3, Color tint, float width)
        {
            BeginPath(rect, x0, y0);
            Curve(x1, y1, x2, y2, x3, y3);
            Open(tint, width);
        }

        private void Ellipse(Vector2 center, float radiusX, float radiusY, Color fill, Color outline, float width, int segments = 24)
        {
            Vector2 previous = center + new Vector2(radiusX, 0f);
            for (int i = 1; i <= segments; i++)
            {
                float angle = i * Mathf.PI * 2f / segments;
                Vector2 next = center + new Vector2(Mathf.Cos(angle) * radiusX, Mathf.Sin(angle) * radiusY);
                if (fill.a > .001f) Triangle(center, previous, next, fill);
                if (outline.a > .001f && width > 0f) Line(previous, next, outline, width);
                previous = next;
            }
        }

        private void Arc(Vector2 center, float radiusX, float radiusY, float first, float last, Color tint, float width, int segments = 18)
        {
            Vector2 previous = center + new Vector2(Mathf.Cos(first) * radiusX, Mathf.Sin(first) * radiusY);
            for (int i = 1; i <= segments; i++)
            {
                float angle = Mathf.Lerp(first, last, i / (float)segments);
                Vector2 next = center + new Vector2(Mathf.Cos(angle) * radiusX, Mathf.Sin(angle) * radiusY);
                Line(previous, next, tint, width);
                previous = next;
            }
        }

        private void Irregular(Vector2 center, float radiusX, float radiusY, Color fill, Color outline, float width)
        {
            const int count = 13;
            Vector2 first = Vector2.zero, previous = Vector2.zero;
            for (int i = 0; i <= count; i++)
            {
                float angle = i * Mathf.PI * 2f / count;
                float radius = 1f + .13f * Mathf.Sin(angle * 5f) + .07f * Mathf.Cos(angle * 3f);
                Vector2 next = center + new Vector2(Mathf.Cos(angle) * radiusX, Mathf.Sin(angle) * radiusY) * radius;
                if (i == 0) first = next;
                else
                {
                    if (i == count) next = first;
                    if (fill.a > .001f) Triangle(center, previous, next, fill);
                    if (outline.a > .001f) Line(previous, next, outline, width);
                }
                previous = next;
            }
        }

        private void Box(Rect rect, Color fill, Color outline, float width)
        {
            if (fill.a > .001f) Quad(new Vector2(rect.xMin, rect.yMin), new Vector2(rect.xMin, rect.yMax),
                new Vector2(rect.xMax, rect.yMax), new Vector2(rect.xMax, rect.yMin), fill);
            if (outline.a <= .001f) return;
            Line(new Vector2(rect.xMin, rect.yMin), new Vector2(rect.xMin, rect.yMax), outline, width);
            Line(new Vector2(rect.xMin, rect.yMax), new Vector2(rect.xMax, rect.yMax), outline, width);
            Line(new Vector2(rect.xMax, rect.yMax), new Vector2(rect.xMax, rect.yMin), outline, width);
            Line(new Vector2(rect.xMax, rect.yMin), new Vector2(rect.xMin, rect.yMin), outline, width);
        }

        private void Line(Vector2 from, Vector2 to, Color tint, float width)
        {
            if (tint.a <= .001f || width <= 0f || (to - from).sqrMagnitude < .00001f) return;
            Vector2 direction = (to - from).normalized;
            float strokeWidth = Mathf.Max(.25f, width * LineWidth * _unit);
            Vector2 normal = new Vector2(-direction.y, direction.x);
            if (!_featherLines)
            {
                normal *= strokeWidth * .5f;
                Quad(from - normal, from + normal, to + normal, to - normal, tint);
                return;
            }

            float feather = _unitsPerPixel * .65f;
            float coreWidth = Mathf.Max(_unitsPerPixel * .1f, strokeWidth - feather);
            tint.a *= Mathf.Min(1f, strokeWidth / (coreWidth + feather));
            Vector2 core = normal * (coreWidth * .5f);
            Vector2 outer = normal * (coreWidth * .5f + feather);
            Color transparent = new Color(tint.r, tint.g, tint.b, 0f);
            int index = _mesh.currentVertCount;
            _mesh.AddVert(from - outer, transparent, Vector2.zero);
            _mesh.AddVert(from - core, tint, Vector2.zero);
            _mesh.AddVert(from + core, tint, Vector2.zero);
            _mesh.AddVert(from + outer, transparent, Vector2.zero);
            _mesh.AddVert(to - outer, transparent, Vector2.zero);
            _mesh.AddVert(to - core, tint, Vector2.zero);
            _mesh.AddVert(to + core, tint, Vector2.zero);
            _mesh.AddVert(to + outer, transparent, Vector2.zero);
            _mesh.AddTriangle(index, index + 1, index + 5);
            _mesh.AddTriangle(index + 5, index + 4, index);
            _mesh.AddTriangle(index + 1, index + 2, index + 6);
            _mesh.AddTriangle(index + 6, index + 5, index + 1);
            _mesh.AddTriangle(index + 2, index + 3, index + 7);
            _mesh.AddTriangle(index + 7, index + 6, index + 2);
        }

        private int VisibleExactWoundCount()
        {
            if (Wounds == null) return 0;
            int count = 0;
            for (int i = 0; i < Wounds.Count; i++)
                if (Wounds[i].HasExactPosition && !Wounds[i].IsBack) count++;
            return count;
        }

        private float UnitsPerScreenPixel()
        {
            Canvas currentCanvas = canvas;
            UnityEngine.Camera currentCamera = currentCanvas != null && currentCanvas.renderMode != RenderMode.ScreenSpaceOverlay
                ? currentCanvas.worldCamera : null;
            Vector2 origin = RectTransformUtility.WorldToScreenPoint(currentCamera, transform.TransformPoint(Vector3.zero));
            Vector2 right = RectTransformUtility.WorldToScreenPoint(currentCamera, transform.TransformPoint(Vector3.right));
            Vector2 up = RectTransformUtility.WorldToScreenPoint(currentCamera, transform.TransformPoint(Vector3.up));
            float pixelsPerUnit = Mathf.Sqrt(Vector2.Distance(origin, right) * Vector2.Distance(origin, up));
            return pixelsPerUnit > .001f && !float.IsNaN(pixelsPerUnit) && !float.IsInfinity(pixelsPerUnit)
                ? 1f / pixelsPerUnit : 1f;
        }

        private void Triangle(Vector2 a, Vector2 b, Vector2 c, Color tint)
        {
            int index = _mesh.currentVertCount;
            _mesh.AddVert(a, tint, Vector2.zero);
            _mesh.AddVert(b, tint, Vector2.zero);
            _mesh.AddVert(c, tint, Vector2.zero);
            _mesh.AddTriangle(index, index + 1, index + 2);
        }

        private void Quad(Vector2 a, Vector2 b, Vector2 c, Vector2 d, Color tint)
        {
            int index = _mesh.currentVertCount;
            _mesh.AddVert(a, tint, Vector2.zero);
            _mesh.AddVert(b, tint, Vector2.zero);
            _mesh.AddVert(c, tint, Vector2.zero);
            _mesh.AddVert(d, tint, Vector2.zero);
            _mesh.AddTriangle(index, index + 1, index + 2);
            _mesh.AddTriangle(index + 2, index + 3, index);
        }
    }
}
