using System;

namespace K_Incident.Core.Inventory
{
    /// <summary>Converts a wheel gesture into whole page steps, including high-resolution wheel deltas.</summary>
    public sealed class HealthHudWheelAccumulator
    {
        private double _remainder;
        public void Reset() => _remainder = 0d;

        public int Consume(float delta, float unitsPerPage)
        {
            if (float.IsNaN(delta) || float.IsInfinity(delta) ||
                float.IsNaN(unitsPerPage) || float.IsInfinity(unitsPerPage) || unitsPerPage <= 0f)
            { Reset(); return 0; }
            if (delta == 0f) return 0;
            // A deliberate reverse notch should not first pay off the previous direction's partial gesture.
            if ((_remainder > 0d && delta < 0f) || (_remainder < 0d && delta > 0f)) _remainder = 0d;
            double total = _remainder + delta;
            double whole = Math.Truncate(total / unitsPerPage);
            _remainder = total - whole * unitsPerPage;
            // A malformed device event cannot cause an unbounded loop; discard excess complete turns.
            return (int)Math.Max(-16d, Math.Min(16d, whole));
        }
    }
}
