using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public sealed partial class K_HealthDollAnatomyGraphic
    {
        private Color _nerve;
        private float _nerveScale = 1f;
        private bool _nerveStimulating, _nerveCooldown, _nerveRelieved;
        private readonly Vector2[] _twigOrigin = new Vector2[12];
        private readonly Vector2[] _twigTangent = new Vector2[12];

        /// <summary>Colour and width follow the same known states as before: stimulant, its cooldown, pain relief.</summary>
        private bool SetupNerveStyle()
        {
            if (NerveOpacity <= 0f || NerveTint.a <= 0f) return false;
            float alive = State != null && State.IsDead ? .45f : 1f;
            _nerve = NerveTint;
            _nerve.a *= Mathf.Clamp01(NerveOpacity) * alive;
            _nerveScale = 1f;
            bool stimulating = State != null && State.Has(HealthGadgetKind.StimOn);
            bool cooldown = State != null && State.Has(HealthGadgetKind.StimCooldown);
            bool relieved = State != null && State.Has(HealthGadgetKind.Painkiller) && !State.PainkillerPending && State.PainRelief01 > 0f;
            if (stimulating)
            {
                Color active = Color.Lerp(_nerve, new Color(.64f, .76f, .63f, _nerve.a), .45f);
                active.a = _nerve.a;
                _nerve = active;
                _nerveScale = 1.18f;
            }
            else if (cooldown)
            {
                _nerve.a *= .68f;
                _nerveScale = .88f;
            }
            if (relieved)
            {
                _nerve.a *= Mathf.Lerp(1f, .65f, State.PainRelief01);
                _nerveScale *= Mathf.Lerp(1f, .84f, State.PainRelief01);
            }
            _nerveStimulating = stimulating;
            _nerveCooldown = cooldown;
            _nerveRelieved = relieved;
            return true;
        }

        private float NerveWidth(float units) => Mathf.Max(.8f * _unitsPerPixel, units * _u * _nerveScale);

        /// <summary>Strokes the collected knots as one smooth, tapering nerve.</summary>
        private void Nerve(float widthStart, float widthEnd, float opacityStart = 1f, float opacityEnd = 1f)
        {
            SplineOpen();
            Ribbon(false, Alpha(_nerve, opacityStart), Alpha(_nerve, opacityEnd), NerveWidth(widthStart), NerveWidth(widthEnd));
        }

        private void NerveBezier(Vector2 from, Vector2 controlA, Vector2 controlB, Vector2 to, float widthStart, float widthEnd,
            float opacityStart = 1f, float opacityEnd = 1f)
        {
            BezierShape(from, controlA, controlB, to);
            Ribbon(false, Alpha(_nerve, opacityStart), Alpha(_nerve, opacityEnd), NerveWidth(widthStart), NerveWidth(widthEnd));
        }

        /// <summary>Remembers points of the trunk that is still in the shape buffer, for the branches drawn next.</summary>
        private void MarkTwigs(params float[] along)
        {
            for (int i = 0; i < along.Length && i < _twigOrigin.Length; i++)
            {
                int index = Mathf.Clamp(Mathf.RoundToInt(along[i] * (_shapeCount - 1)), 1, Mathf.Max(1, _shapeCount - 2));
                _twigOrigin[i] = _shape[index];
                _twigTangent[i] = (_shape[Mathf.Min(_shapeCount - 1, index + 1)] - _shape[index - 1]).normalized;
            }
        }

        /// <summary>A long thin branch that leaves its trunk at an acute angle, as cutaneous nerves do.</summary>
        private void Twig(int mark, float turn, float length, float spread, BodyPart part, float width = .78f, float opacity = .62f)
        {
            Vector2 origin = _twigOrigin[mark], tangent = _twigTangent[mark];
            Vector2 normal = new Vector2(-tangent.y, tangent.x) * turn;
            length *= _u;
            Vector2 end = origin + tangent * length + normal * length * spread;
            Rect rect = R(part);
            if (end.y > rect.yMin && end.y < rect.yMax) end = ConstrainToSurface(part, end, 2.4f);
            NerveBezier(origin, origin + tangent * length * .36f, origin + tangent * length * .70f + normal * length * spread * .42f, end,
                width, width * .7f, opacity, opacity * .35f);
        }

        private void DrawNervousHeadUnderlay()
        {
            if (!SetupNerveStyle()) return;
            Rect head = AnatomicalFrame(CraniumRect, Sub(R(BodyPart.Head), .18f, .29f, .64f, .70f));
            // The cervical cord shows below the jaw; behind the face it would only streak the skull.
            Knots();
            K(P(head, .5f, .035f)); K(Vector2.Lerp(P(head, .5f, .035f), D(0f, 12f), .5f)); K(D(0f, 12f));
            Nerve(2.7f, 3f);
        }

        private void DrawNervousSystem()
        {
            if (!SetupNerveStyle()) return;
            Rect head = AnatomicalFrame(CraniumRect, Sub(R(BodyPart.Head), .18f, .29f, .64f, .70f));

            // Spinal cord: cervical and lumbar enlargements, ending in the conus at the first lumbar level.
            Knots();
            K(D(0f, 12f)); K(D(0f, -40f)); K(D(0f, -96f)); K(D(0f, -118f)); K(D(0f, -131f));
            Nerve(3f, 1.7f);
            // Cauda equina: the lumbar and sacral roots continue to their openings.
            for (int strand = 0; strand < 6; strand++)
            {
                float spread = (strand - 2.5f) / 2.5f, reach = 1f - Mathf.Abs(spread);
                NerveBezier(D(spread * 1.1f, -129f), D(spread * 2.2f, -150f), D(spread * 6.5f, -170f),
                    D(spread * 10.4f, -186f - reach * 24f), .7f, .7f, .55f, .28f);
            }

            for (int index = 0; index < 2; index++)
            {
                float side = index == 0 ? 1f : -1f;
                DrawTrunkNerves(head, side);
                DrawArmNerves(index, side);
                DrawLegNerves(index, side);
            }
            // Known states of the brain keep their previous marks: concussion, brain injury and its
            // recovery, stimulant, pain relief. They describe a physiological state, not a nerve lesion.
            bool feather = _featherLines;
            _featherLines = false;
            DrawNerveCorticalResponse(head, _nerve, _nerveStimulating, _nerveCooldown, _nerveRelieved);
            _featherLines = feather;
        }

        private void DrawTrunkNerves(Rect head, float side)
        {
            // Supraclavicular nerve of the cervical plexus.
            Knots();
            K(D(side * 1.6f, 22f)); K(D(side * 11f, 13f)); K(D(side * 21f, 2f)); K(D(side * 31f, -8f));
            Nerve(.8f, .7f, .5f, .12f);

            // Intercostal nerves follow the lower border of each rib.
            for (int rib = 1; rib < 10; rib++)
            {
                float top = RibVertebralY(rib), lateral = RibLateralY(rib), reach = RibHalfWidth[rib];
                Knots();
                K(D(side * 1.6f, top - 3f));
                K(D(side * reach * .55f, top - 1.6f));
                K(D(side * (reach - 2.2f), lateral - 2.8f));
                K(D(side * Mathf.Lerp(RibJointX[rib], reach, .5f), Mathf.Lerp(lateral, RibJointY[rib], .78f) - 3.2f));
                K(D(side * (RibJointX[rib] + 4f), RibJointY[rib] - 3.4f));
                Nerve(.75f, .7f, .36f, .10f);
            }
            Knots();
            K(D(side * 1.6f, RibVertebralY(11) - 3.4f)); K(D(side * 22f, -127f)); K(D(side * 40f, -141f)); K(D(side * 47f, -156f));
            Nerve(.75f, .7f, .36f, .08f);
        }

        private void DrawArmNerves(int index, float side)
        {
            BodyPart upperPart = (BodyPart)(6 + index), forearmPart = (BodyPart)(8 + index), handPart = (BodyPart)(10 + index);
            Vector2 shoulder = BonePoint(upperPart, 0f), elbow = BonePoint(upperPart, 1f), wrist = BonePoint(forearmPart, 1f);
            Vector2 palm = BonePoint(handPart, 1f);
            float u = _u;
            bool left = index == 0;
            float direction = left ? 1f : -1f;
            Rect hand = R(handPart);
            // Brachial plexus. Five roots (C5-T1) leave the lower neck and join into three trunks; the trunks
            // dip behind the middle of the clavicle, regroup into three cords and reach the armpit, where
            // the nerves of the arm part. It is a curved braid, never a set of straight rays.
            Vector2 sternalEnd = BonePoint((BodyPart)(4 + index), 0f) + new Vector2(-side * 1.2f, -2.4f) * u;
            Vector2 acromialEnd = shoulder + new Vector2(-side * 8.6f, 15.6f) * u;
            Vector2 behindClavicle = Vector2.Lerp(sternalEnd, acromialEnd, .53f) + new Vector2(0f, 2.8f) * u;
            Vector2 upperTrunk = D(side * 17.5f, 8.5f), middleTrunk = D(side * 18.5f, 4f), lowerTrunk = D(side * 17f, -1.5f);
            Vector2 upperCross = behindClavicle + new Vector2(side * 1.5f, 2f) * u;
            Vector2 middleCross = behindClavicle + new Vector2(0f, .5f) * u;
            Vector2 lowerCross = behindClavicle + new Vector2(-side * 1.5f, -1f) * u;
            Vector2 lateralCord = shoulder + new Vector2(-side * 15.7f, -3.4f) * u;
            Vector2 posteriorCord = shoulder + new Vector2(-side * 18.7f, -6.4f) * u;
            Vector2 medialCord = shoulder + new Vector2(-side * 20.2f, -8.9f) * u;

            for (int root = 0; root < 5; root++)
            {
                float y = 23f - root * 5.5f;
                Vector2 target = root < 2 ? upperTrunk : root == 2 ? middleTrunk : lowerTrunk;
                Vector2 foramen = D(side * 5.4f, y - .4f);
                float sag = root == 0 || root == 3 ? 1.2f : root == 1 || root == 4 ? -1f : 0f;
                Knots();
                K(D(side * 1.6f, y)); K(foramen); K(Vector2.Lerp(foramen, target, .55f) + new Vector2(0f, sag * _ky)); K(target);
                Nerve(.9f, 1.15f, .8f, 1f);
            }
            for (int trunk = 0; trunk < 3; trunk++)
            {
                Vector2 start = trunk == 0 ? upperTrunk : trunk == 1 ? middleTrunk : lowerTrunk;
                Vector2 cross = trunk == 0 ? upperCross : trunk == 1 ? middleCross : lowerCross;
                Vector2 cord = trunk == 0 ? lateralCord : trunk == 1 ? posteriorCord : medialCord;
                // Above the clavicle the trunk sags toward the first rib; it dims where the bone covers it.
                Knots();
                K(start); K(Vector2.Lerp(start, cross, .42f) + new Vector2(-side * .6f, -.7f) * u);
                K(Vector2.Lerp(start, cross, .78f) + new Vector2(-side * .2f, -1.1f) * u); K(cross);
                Nerve(1.2f, 1.3f, 1f, .45f);
                Knots();
                K(cross); K(Vector2.Lerp(cross, cord, .35f) + new Vector2(-side * .5f, 2.1f) * u);
                K(Vector2.Lerp(cross, cord, .72f) + new Vector2(-side * .9f, 2.7f) * u); K(cord);
                Nerve(1.3f, 1.35f, .45f, 1f);
            }
            // Divisions cross between the bundles under the clavicle and braid the three cords.
            NerveBezier(Vector2.Lerp(upperCross, lateralCord, .14f), Vector2.Lerp(upperCross, lateralCord, .28f),
                Vector2.Lerp(middleCross, posteriorCord, .40f), Vector2.Lerp(middleCross, posteriorCord, .56f), .9f, .9f, .6f, .9f);
            NerveBezier(Vector2.Lerp(lowerCross, medialCord, .14f), Vector2.Lerp(lowerCross, medialCord, .28f),
                Vector2.Lerp(middleCross, posteriorCord, .44f), Vector2.Lerp(middleCross, posteriorCord, .60f), .9f, .9f, .6f, .9f);
            NerveBezier(Vector2.Lerp(middleCross, posteriorCord, .12f), Vector2.Lerp(middleCross, posteriorCord, .26f),
                Vector2.Lerp(upperCross, lateralCord, .46f), Vector2.Lerp(upperCross, lateralCord, .62f), .9f, .9f, .6f, .9f);

            // Side branches of the plexus: suprascapular, long thoracic and the two pectoral nerves.
            Knots();
            K(Vector2.Lerp(upperTrunk, upperCross, .28f)); K(D(side * 34f, -1f)); K(D(side * 45f, -4.5f)); K(D(side * 55f, -9.5f));
            Nerve(.85f, .7f, .7f, .12f);
            Knots();
            K(D(side * 12f, 13f)); K(D(side * 25f, -8f)); K(D(side * 38f, -31f)); K(D(side * 47f, -58f));
            K(D(side * 49.5f, -84f)); K(D(side * 48f, -104f));
            Nerve(.8f, .7f, .5f, .08f);
            Knots();
            K(Vector2.Lerp(upperCross, lateralCord, .30f)); K(D(side * 40f, -27f)); K(D(side * 31f, -37f));
            Nerve(.75f, .7f, .55f, .06f);
            Knots();
            K(Vector2.Lerp(lowerCross, medialCord, .36f)); K(D(side * 41f, -32f)); K(D(side * 36f, -46f));
            Nerve(.75f, .7f, .55f, .06f);

            // Median nerve: its two roots clasp the artery in an "M", then it runs down the front of the arm into the palm.
            Vector2 palmPoint = Vector2.Lerp(wrist, palm, .42f);
            Vector2 medianStart = Along(shoulder, elbow, side, .15f, -11.5f * u);
            NerveBezier(lateralCord, Vector2.Lerp(lateralCord, medianStart, .4f) + new Vector2(side * 1.4f, 0f) * u,
                Vector2.Lerp(lateralCord, medianStart, .8f) + new Vector2(side * .8f, 0f) * u, medianStart, 1.2f, 1.3f);
            NerveBezier(medialCord, Vector2.Lerp(medialCord, medianStart, .4f) + new Vector2(-side * 1.2f, -.6f) * u,
                Vector2.Lerp(medialCord, medianStart, .8f) + new Vector2(-side * .6f, 0f) * u, medianStart, 1.2f, 1.3f);
            Knots();
            K(medianStart); K(Along(shoulder, elbow, side, .26f, -6.6f * u)); K(Along(shoulder, elbow, side, .50f, -5.2f * u));
            K(Along(shoulder, elbow, side, .86f, -3.4f * u)); K(Along(elbow, wrist, side, 0f, -2.2f * u));
            K(Along(elbow, wrist, side, .30f, .4f * u)); K(Along(elbow, wrist, side, .70f, -2.2f * u));
            K(Along(elbow, wrist, side, 1f, -2.6f * u)); K(palmPoint);
            Nerve(1.7f, 1.35f);
            MarkTwigs(.20f, .46f, .66f);
            Twig(0, -side, 20f, .26f, upperPart);
            Twig(1, side, 17f, .24f, forearmPart);
            Twig(2, -side, 15f, .22f, forearmPart);

            // Ulnar nerve: behind the medial epicondyle, then along the ulna to the little finger.
            Vector2 ulnarEnd = Vector2.Lerp(wrist, palm, .34f) + Vector2.right * direction * 5.6f * u;
            Knots();
            K(medialCord); K(Along(shoulder, elbow, side, .17f, -13.2f * u)); K(Along(shoulder, elbow, side, .32f, -9.6f * u));
            K(Along(shoulder, elbow, side, .62f, -9.4f * u)); K(Along(shoulder, elbow, side, .93f, -13f * u));
            K(Along(elbow, wrist, side, .07f, -10.6f * u)); K(Along(elbow, wrist, side, .36f, -4.8f * u));
            K(Along(elbow, wrist, side, .70f, 2.6f * u)); K(Along(elbow, wrist, side, .98f, 6f * u)); K(ulnarEnd);
            Nerve(1.3f, 1.05f);
            MarkTwigs(.74f);
            Twig(0, side, 14f, .22f, forearmPart);

            // Radial nerve: winds behind the humerus, then follows the radius to the back of the thumb.
            Knots();
            K(posteriorCord); K(Along(shoulder, elbow, side, .13f, -8f * u)); K(Along(shoulder, elbow, side, .23f, -3f * u));
            K(Along(shoulder, elbow, side, .36f, 1.5f * u)); K(Along(shoulder, elbow, side, .62f, 7.2f * u));
            K(Along(shoulder, elbow, side, .90f, 9.6f * u)); K(Along(elbow, wrist, side, .04f, 9.4f * u));
            K(Along(elbow, wrist, side, .30f, 6.6f * u)); K(Along(elbow, wrist, side, .62f, .6f * u));
            K(Along(elbow, wrist, side, .90f, -7.2f * u)); K(Along(elbow, wrist, side, 1.03f, -9.2f * u));
            Nerve(1.3f, .95f, 1f, .8f);
            MarkTwigs(.34f, .60f);
            Twig(0, side, 19f, .30f, upperPart);
            Twig(1, side, 16f, .20f, forearmPart);

            // Musculocutaneous and axillary nerves.
            Knots();
            K(lateralCord); K(Along(shoulder, elbow, side, .14f, -1.5f * u)); K(Along(shoulder, elbow, side, .28f, 1.6f * u));
            K(Along(shoulder, elbow, side, .48f, 3.2f * u)); K(Along(shoulder, elbow, side, .82f, 6.6f * u));
            K(Along(elbow, wrist, side, .10f, 11f * u)); K(Along(elbow, wrist, side, .40f, 9.4f * u));
            Nerve(1.05f, .7f, .9f, .25f);
            Knots();
            K(posteriorCord); K(Along(shoulder, elbow, side, .06f, -8f * u)); K(Along(shoulder, elbow, side, .085f, 1.5f * u));
            K(Along(shoulder, elbow, side, .12f, 10f * u));
            Nerve(1f, .7f, .85f, .2f);

            // Digital nerves: median to the thumb, index and middle fingers; ulnar to the ring and little fingers.
            for (int finger = 0; finger < 4; finger++)
            {
                float x = .40f + finger * .17f;
                float tipY = finger == 0 ? .12f : finger == 1 ? .035f : finger == 2 ? .09f : .23f;
                Vector2 knuckle = ConstrainToSurface(handPart, HandPoint(hand, left, x + .02f, .49f + (finger == 3 ? .025f : 0f)));
                Vector2 tip = ConstrainToSurface(handPart, HandPoint(hand, left, x - .05f, tipY + .035f), 2.4f);
                Knots();
                K(finger < 2 ? palmPoint : ulnarEnd); K(knuckle); K(tip);
                Nerve(.9f, .7f, .85f, .55f);
            }
            Knots();
            K(palmPoint); K(ConstrainToSurface(handPart, HandPoint(hand, left, .27f, .62f)));
            K(ConstrainToSurface(handPart, HandPoint(hand, left, .09f, .39f), 2.4f));
            Nerve(.9f, .7f, .85f, .55f);
        }

        private void DrawLegNerves(int index, float side)
        {
            BodyPart thighPart = (BodyPart)(12 + index), shinPart = (BodyPart)(16 + index), footPart = (BodyPart)(18 + index);
            Vector2 hip = BonePoint(thighPart, 0f), knee = BonePoint(thighPart, 1f), ankle = BonePoint(shinPart, 1f);
            float u = _u;
            bool left = index == 0;

            // Lumbar plexus: cutaneous nerves of the flank and the lateral thigh.
            Knots();
            K(D(side * 1.6f, -124.5f)); K(D(side * 28f, -141f)); K(D(side * 47f, -160f)); K(D(side * 50f, -176f));
            Nerve(.8f, .7f, .55f, .12f);
            Knots();
            K(D(side * 1.6f, -136.5f)); K(D(side * 30f, -166f)); K(D(side * 49f, -189f)); K(Along(hip, knee, side, .10f, 21f * u));
            K(Along(hip, knee, side, .36f, 19f * u)); K(Along(hip, knee, side, .58f, 15f * u));
            Nerve(.9f, .7f, .7f, .15f);

            // Femoral nerve: three lumbar roots, one trunk under the inguinal ligament, a fan over the thigh.
            Vector2 junction = D(side * 18f, -176f);
            for (int root = 0; root < 3; root++)
            {
                float y = -136.5f - root * 12f;
                NerveBezier(D(side * 1.6f, y), D(side * 6f, y - 5f), D(side * 12f, Mathf.Lerp(y, -176f, .6f)), junction, .9f, 1.2f, .85f, .95f);
            }
            Vector2 fan = Along(hip, knee, side, .085f, -3.5f * u);
            Knots();
            K(junction); K(D(side * 27f, -196f)); K(D(side * 35f, -213f)); K(fan);
            Nerve(1.7f, 1.6f);
            float[] fanAlong = { .34f, .52f, .62f, .42f };
            float[] fanSide = { 13f, 6f, -2f, -9f };
            for (int branch = 0; branch < fanAlong.Length; branch++)
            {
                Vector2 end = Along(hip, knee, side, fanAlong[branch], fanSide[branch] * u);
                NerveBezier(fan, Vector2.Lerp(fan, end, .3f) + new Vector2(side * fanSide[branch] * .08f, 0f) * u,
                    Vector2.Lerp(fan, end, .7f), end, 1.05f, .7f, .9f, .3f);
            }
            // Saphenous nerve continues down the inner side of the leg.
            Knots();
            K(fan); K(Along(hip, knee, side, .40f, -8.5f * u)); K(Along(hip, knee, side, .80f, -12.5f * u));
            K(Along(hip, knee, side, .98f, -15.2f * u)); K(Along(knee, ankle, side, .12f, -13.2f * u));
            K(Along(knee, ankle, side, .50f, -9.4f * u)); K(Along(knee, ankle, side, .93f, -8.4f * u));
            Nerve(1f, .7f, .9f, .4f);

            // Obturator nerve passes through its foramen to the inner thigh.
            Knots();
            K(D(side * 1.6f, -148.5f)); K(D(side * 10f, -186f)); K(D(side * 19f, -226f)); K(D(side * 21.5f, -239f));
            K(Along(hip, knee, side, .16f, -15f * u)); K(Along(hip, knee, side, .30f, -13f * u));
            Nerve(.95f, .7f, .8f, .2f);

            // Sacral plexus: L4 to S3 join into the sciatic nerve, the thickest in the body.
            Vector2 notch = D(side * 25f, -213.5f);
            float[] rootX = { 1.6f, 11.4f, 9.4f, 7.4f };
            float[] rootY = { -166.5f, -186f, -194.4f, -202.8f };
            for (int root = 0; root < rootX.Length; root++)
            {
                Vector2 origin = D(side * rootX[root], rootY[root]);
                NerveBezier(origin, origin + new Vector2(side * 6f * _kx, -5f * _ky),
                    Vector2.Lerp(origin, notch, .6f) + new Vector2(side * 2f * _kx, 0f), notch, .8f, 1.2f, .7f, .95f);
            }
            Vector2 popliteal = Along(hip, knee, side, .84f, 1.2f * u);
            Knots();
            K(notch); K(D(side * 33f, -228f)); K(D(side * 43f, -243f)); K(Along(hip, knee, side, .24f, 7.5f * u));
            K(Along(hip, knee, side, .50f, 4f * u)); K(popliteal);
            Nerve(2.3f, 1.95f);
            MarkTwigs(.52f, .72f);
            Twig(0, -side, 26f, .22f, thighPart);
            Twig(1, side, 24f, .20f, thighPart);

            // Tibial nerve: straight down the calf and behind the medial malleolus.
            Rect foot = R(footPart);
            Vector2 sole = SurfacePoint(footPart, left ? .40f : .60f, .66f, 2.4f);
            Knots();
            K(popliteal); K(Along(knee, ankle, side, -.02f, .5f * u)); K(Along(knee, ankle, side, .25f, -1.5f * u));
            K(Along(knee, ankle, side, .60f, -3.5f * u)); K(Along(knee, ankle, side, .93f, -6.4f * u)); K(sole);
            Nerve(1.75f, 1.25f);
            MarkTwigs(.22f, .44f);
            Twig(0, -side, 22f, .22f, shinPart);
            Twig(1, -side, 18f, .18f, shinPart);
            // Sural nerve on the outer back of the calf.
            Knots();
            K(Along(knee, ankle, side, .04f, 2f * u)); K(Along(knee, ankle, side, .35f, 7f * u));
            K(Along(knee, ankle, side, .75f, 9.2f * u)); K(Along(knee, ankle, side, .99f, 9.8f * u));
            Nerve(.8f, .7f, .7f, .25f);

            // Common fibular nerve winds round the neck of the fibula and divides.
            Vector2 fibularNeck = Along(knee, ankle, side, .085f, 17f * u);
            Knots();
            K(popliteal); K(Along(hip, knee, side, .95f, 9f * u)); K(fibularNeck);
            Nerve(1.4f, 1.25f);
            Vector2 dorsum = SurfacePoint(footPart, left ? .62f : .38f, .70f, 2.4f);
            Knots();
            K(fibularNeck); K(Along(knee, ankle, side, .30f, 15f * u)); K(Along(knee, ankle, side, .62f, 11.6f * u));
            K(Along(knee, ankle, side, .90f, 6f * u)); K(dorsum);
            Nerve(1.2f, .9f);
            Knots();
            K(fibularNeck); K(Along(knee, ankle, side, .22f, 9.5f * u)); K(Along(knee, ankle, side, .55f, 6.2f * u));
            K(Along(knee, ankle, side, .92f, 1.5f * u)); K(SurfacePoint(footPart, left ? .34f : .66f, .58f, 2.4f));
            Nerve(.9f, .7f, .85f, .5f);

            // Digital nerves of the toes.
            for (int toe = 0; toe < 5; toe++)
            {
                float x = .12f + toe * .19f;
                if (!left) x = 1f - x;
                Knots();
                K(toe < 2 ? sole : dorsum);
                K(SurfacePoint(footPart, Mathf.Lerp(.5f, x, .66f), .47f, 2.4f));
                K(SurfacePoint(footPart, x, .15f + toe * .037f, 2.4f));
                Nerve(.85f, .7f, .8f, .5f);
            }
        }

        private void DrawNerveCorticalResponse(Rect head, Color nerve, bool stimulating, bool cooldown, bool relieved)
        {
            if (State == null) return;
            bool concussion = State.Has(HealthGadgetKind.Concussion);
            bool tbi = State.Has(HealthGadgetKind.Tbi);
            if (!concussion && !tbi && !stimulating && !cooldown && !relieved && !State.PainkillerPending) return;
            Color response = nerve;
            float width = .85f;
            if (tbi)
            {
                response = State.TbiRecovering ? new Color(.68f, .75f, .59f, nerve.a) : new Color(.75f, .39f, .43f, nerve.a);
                width = State.TbiRecovering ? .95f : 1.15f;
                TissuePatch(P(head, .50f, .80f), head.width * .28f, head.height * .12f,
                    Alpha(response, State.TbiRecovering ? .18f : .30f));
            }
            else if (concussion)
            {
                response = Color.Lerp(nerve, new Color(.72f, .57f, .42f, nerve.a), .62f);
                response.a = nerve.a;
                TissuePatch(P(head, .50f, .80f), head.width * .27f, head.height * .12f, Alpha(response, .16f));
            }
            else if (relieved || State.PainkillerPending)
            {
                response = new Color(.59f, .72f, .67f, nerve.a * (State.PainkillerPending ? .48f : .90f));
            }
            for (int side = -1; side <= 1; side += 2)
            {
                NerveCurve(P(head, .5f + side * .07f, .81f), P(head, .5f + side * .16f, .87f),
                    P(head, .5f + side * .14f, .71f), P(head, .5f + side * .27f, .75f), response, width);
                NerveCurve(P(head, .5f + side * .05f, .74f), P(head, .5f + side * .16f, .81f),
                    P(head, .5f + side * .13f, .68f), P(head, .5f + side * .25f, .72f), Alpha(response, .80f), width * .86f);
            }
        }

        private void NerveCurve(Vector2 from, Vector2 controlA, Vector2 controlB, Vector2 to, Color tint, float pixels)
        {
            if (tint.a <= .001f) return;
            float estimate = Vector2.Distance(from, controlA) + Vector2.Distance(controlA, controlB) + Vector2.Distance(controlB, to);
            int segments = Mathf.Clamp(Mathf.CeilToInt(estimate / Mathf.Max(.001f, _unitsPerPixel * 5f)), 12, 36);
            float halfWidth = Mathf.Max(.85f, pixels) * _unitsPerPixel * .5f;
            float feather = .75f * _unitsPerPixel;
            Color transparent = new Color(tint.r, tint.g, tint.b, 0f);
            int first = _mesh.currentVertCount;
            for (int i = 0; i <= segments; i++)
            {
                float t = i / (float)segments, inverse = 1f - t;
                Vector2 point = inverse * inverse * inverse * from + 3f * inverse * inverse * t * controlA +
                    3f * inverse * t * t * controlB + t * t * t * to;
                Vector2 tangent = 3f * inverse * inverse * (controlA - from) +
                    6f * inverse * t * (controlB - controlA) + 3f * t * t * (to - controlB);
                if (tangent.sqrMagnitude < .000001f) tangent = to - from;
                Vector2 normal = new Vector2(-tangent.y, tangent.x).normalized;
                _mesh.AddVert(point - normal * (halfWidth + feather), transparent, Vector2.zero);
                _mesh.AddVert(point - normal * halfWidth, tint, Vector2.zero);
                _mesh.AddVert(point + normal * halfWidth, tint, Vector2.zero);
                _mesh.AddVert(point + normal * (halfWidth + feather), transparent, Vector2.zero);
                if (i == 0) continue;
                int previous = first + (i - 1) * 4, current = first + i * 4;
                for (int strip = 0; strip < 3; strip++)
                {
                    _mesh.AddTriangle(previous + strip, previous + strip + 1, current + strip + 1);
                    _mesh.AddTriangle(current + strip + 1, current + strip, previous + strip);
                }
            }
        }
    }
}
