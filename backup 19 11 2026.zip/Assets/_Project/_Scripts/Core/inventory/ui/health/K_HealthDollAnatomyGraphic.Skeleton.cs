using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public sealed partial class K_HealthDollAnatomyGraphic
    {
        // Original procedural shapes guided by anatomical landmarks, not a traced plate.
        private static Rect AnatomicalFrame(Rect authored, Rect fallback)
            => authored.width > .01f && authored.height > .01f ? authored : fallback;

        private static readonly float[] RibHalfWidth = { 22f, 32f, 40f, 46f, 50f, 53f, 54.5f, 55f, 54f, 51f };
        private static readonly float[] RibJointX = { 12.5f, 15f, 18.5f, 22.5f, 27f, 32f, 37f, 41.5f, 45.5f, 48f };
        private static readonly float[] RibJointY = { -20f, -35f, -47.5f, -60f, -72f, -84f, -96f, -108f, -119f, -129f };
        private static readonly float[] RibSternalX = { 8.2f, 7.4f, 8.2f, 8.6f, 8.7f, 8.4f, 6.6f, 20f, 31f, 39f };
        private static readonly float[] RibSternalY = { -19f, -34f, -45f, -55f, -64.5f, -73f, -80.5f, -92f, -104f, -115f };

        private void DrawAxialSkeleton()
        {
            Rect head = AnatomicalFrame(CraniumRect, Sub(R(BodyPart.Head), .18f, .29f, .64f, .70f));
            DrawBackOfThorax();
            DrawSpine(head);
            DrawFrontOfThorax();
            DrawShoulderGirdle();
            DrawPelvis();
            DrawSkull(head);
        }

        private static float RibVertebralY(int rib) => 4.25f - rib * 10.5f;

        private static float RibLateralY(int rib) => Mathf.Lerp(RibVertebralY(rib), RibJointY[rib], .52f);

        private void DrawBackOfThorax()
        {
            for (int index = 0; index < 2; index++)
            {
                float side = index == 0 ? 1f : -1f;
                // Scapula: a thin plate behind the cage, from the glenoid to the inferior angle.
                Knots();
                K(D(side * 64.5f, -26.5f)); K(D(side * 52f, -17f)); K(D(side * 40f, -10.5f)); K(D(side * 31.5f, -11f));
                K(D(side * 29.5f, -17f)); K(D(side * 30.5f, -45f)); K(D(side * 35.5f, -72f)); K(D(side * 39.5f, -81f));
                K(D(side * 44f, -78f)); K(D(side * 56f, -55f)); K(D(side * 65.5f, -40.5f)); K(D(side * 68.5f, -33.5f));
                SplineClosed();
                FillSoft(Tone(.78f, .26f));
                Knots();
                K(D(side * 33f, -16f)); K(D(side * 44f, -22f)); K(D(side * 57f, -27f)); K(D(side * 66f, -29f));
                SplineOpen();
                Ribbon(false, Tone(.95f, .22f), Stroke(1.5f));

                // Posterior halves of the ribs descend from the vertebrae to the side of the cage.
                // They lie behind everything else, so they stay dim and only close the cage visually.
                for (int rib = 1; rib < 10; rib++)
                {
                    float top = RibVertebralY(rib), lateral = RibLateralY(rib), reach = RibHalfWidth[rib];
                    BezierShape(D(side * 5.5f, top), D(side * (5.5f + (reach - 5.5f) * .55f), top + 2.2f),
                        D(side * reach, Mathf.Lerp(lateral, top, .62f)), D(side * reach, lateral));
                    Ribbon(false, Tone(.66f, .17f), Tone(.80f, .40f), Stroke(3.6f), Stroke(4.4f));
                }
                // Floating ribs end free in the flank.
                BezierShape(D(side * 5.5f, RibVertebralY(10)), D(side * 26f, RibVertebralY(10) + 1f),
                    D(side * 41f, -118f), D(side * 45f, -131f));
                Ribbon(false, Tone(.66f, .17f), Tone(.80f, .32f), Stroke(3.4f), Stroke(2.2f));
                BezierShape(D(side * 5.5f, RibVertebralY(11)), D(side * 17f, RibVertebralY(11) + .5f),
                    D(side * 27f, -121f), D(side * 30f, -131f));
                Ribbon(false, Tone(.66f, .17f), Tone(.80f, .28f), Stroke(3.2f), Stroke(2f));
            }
        }

        private void DrawSpine(Rect head)
        {
            // Seven cervical bodies run from the skull base, mostly hidden by the jaw, to the first thoracic.
            for (int vertebra = 0; vertebra < 7; vertebra++)
            {
                Vector2 center = Vector2.Lerp(P(head, .5f, .296f), D(0f, 11.25f), vertebra / 6f);
                // The upper ones are behind the face; drawing them through the jaw only muddies the skull.
                if (center.y > head.yMin + head.height * .055f) continue;
                VertebralBody(center, (5.2f + vertebra * .22f) * _kx, 2.5f * _ky, Tone(.86f, .58f), 1.9f);
            }
            for (int vertebra = 0; vertebra < 12; vertebra++)
                VertebralBody(D(0f, 2.75f - vertebra * 10.5f), (6f + vertebra * .23f) * _kx, 3.8f * _ky, Tone(.80f, .40f), 0f);
            for (int vertebra = 0; vertebra < 5; vertebra++)
            {
                Vector2 center = D(0f, -124.5f - vertebra * 12f);
                float half = (9.4f + vertebra * .3f) * _kx;
                for (int side = -1; side <= 1; side += 2)
                {
                    Knots();
                    K(center + new Vector2(side * half * .92f, 1.4f * _ky));
                    K(center + new Vector2(side * (half + 3.4f * _kx), 2.3f * _ky));
                    K(center + new Vector2(side * (half + 7.4f * _kx), 1.4f * _ky));
                    SplineOpen();
                    Ribbon(false, Tone(.9f, .62f), Tone(.9f, .5f), Stroke(3.3f), Stroke(1.9f));
                }
                VertebralBody(center, half, 4.6f * _ky, Tone(.98f, .80f), 0f);
            }
        }

        private void VertebralBody(Vector2 center, float halfWidth, float halfHeight, Color tint, float process)
        {
            Knots();
            K(center + new Vector2(-halfWidth, halfHeight)); K(center + new Vector2(0f, halfHeight * .86f));
            K(center + new Vector2(halfWidth, halfHeight)); K(center + new Vector2(halfWidth * .86f, 0f));
            K(center + new Vector2(halfWidth, -halfHeight)); K(center + new Vector2(0f, -halfHeight * .86f));
            K(center + new Vector2(-halfWidth, -halfHeight)); K(center + new Vector2(-halfWidth * .86f, 0f));
            SplineClosed();
            FillSoft(tint);
            if (process <= 0f) return;
            for (int side = -1; side <= 1; side += 2)
            {
                _shapeCount = 2;
                _shape[0] = center + new Vector2(side * halfWidth * .9f, 0f);
                _shape[1] = center + new Vector2(side * (halfWidth + process * _kx), -.4f * _ky);
                Ribbon(false, tint, Alpha(tint, .7f), Stroke(2.2f), Stroke(1.4f));
            }
        }

        private void DrawFrontOfThorax()
        {
            Color cartilage = Tone(.80f, .62f);
            for (int index = 0; index < 2; index++)
            {
                float side = index == 0 ? 1f : -1f;
                for (int rib = 0; rib < 10; rib++)
                {
                    float lateral = RibLateralY(rib), reach = RibHalfWidth[rib];
                    float jointX = RibJointX[rib], jointY = RibJointY[rib];
                    // Costal cartilage rises from the bony rib to the sternum or to the cartilage above.
                    BezierShape(D(side * jointX, jointY),
                        D(side * Mathf.Lerp(jointX, RibSternalX[rib], .45f), jointY - 1.2f),
                        D(side * Mathf.Lerp(jointX, RibSternalX[rib], .78f), RibSternalY[rib] - 2.4f),
                        D(side * RibSternalX[rib], RibSternalY[rib]));
                    Ribbon(false, cartilage, cartilage, Stroke(4.6f), Stroke(rib < 7 ? 4.2f : 3.6f));
                    // Anterior half: from the side of the cage down and forward to the cartilage.
                    BezierShape(D(side * reach, lateral), D(side * reach, Mathf.Lerp(lateral, jointY, .55f)),
                        D(side * Mathf.Lerp(jointX, reach, .58f), jointY - 1.6f), D(side * jointX, jointY));
                    Ribbon(false, Tone(.90f, .58f), Tone(1.02f, .88f), Stroke(4.7f), Stroke(5.1f));
                }
            }

            // Manubrium, body and xiphoid process.
            Knots();
            float[] sx = { 0f, 4f, 8.3f, 10.4f, 9.4f, 8f, 7.5f, 8.6f, 9.1f, 8.9f, 7.4f, 4.6f, 3.2f, 2.2f, 0f };
            float[] sy = { -13.8f, -12.4f, -12.8f, -16f, -20.5f, -27f, -33.6f, -40f, -55f, -70f, -79f, -82.4f, -86f, -91f, -94.5f };
            for (int i = 0; i < sx.Length; i++) K(D(sx[i], sy[i]));
            for (int i = sx.Length - 2; i >= 1; i--) K(D(-sx[i], sy[i]));
            SplineClosed();
            Halo(.42f);
            FillSoft(Tone(1.03f, .90f));
            SternalLine(-33.7f, 7.2f, .50f);
            SternalLine(-82.2f, 4.4f, .50f);
            SternalLine(-45f, 7.6f, .16f);
            SternalLine(-55f, 8f, .16f);
            SternalLine(-64.5f, 8f, .16f);
            SternalLine(-73f, 7.6f, .16f);
        }

        private void SternalLine(float y, float half, float opacity)
        {
            _shapeCount = 2;
            _shape[0] = D(-half, y);
            _shape[1] = D(half, y);
            Ribbon(false, Shade(opacity), Stroke(.9f));
        }

        private void DrawShoulderGirdle()
        {
            for (int index = 0; index < 2; index++)
            {
                float side = index == 0 ? 1f : -1f;
                Vector2 joint = BonePoint((BodyPart)(4 + index), 1f);
                Vector2 sternal = BonePoint((BodyPart)(4 + index), 0f);
                Vector2 acromial = joint + new Vector2(-side * 8.6f * _u, 15.6f * _u);
                // Glenoid edge of the scapula, coracoid process and acromion frame the shoulder joint.
                Disc(joint + new Vector2(-side * 9.6f * _u, -.6f * _u), 2.3f * _u, 7.6f * _u, Tone(.86f, .44f), -side * .12f);
                Disc(joint + new Vector2(-side * 15.8f * _u, 8.8f * _u), 3.9f * _u, 2.5f * _u, Tone(.90f, .50f), side * .5f);
                _shapeCount = 3;
                _shape[0] = acromial + new Vector2(side * 2.2f, -.4f) * _u;
                _shape[1] = acromial + new Vector2(side * 7.4f, -1.2f) * _u;
                _shape[2] = acromial + new Vector2(side * 12f, -3.6f) * _u;
                TubeFromShape(2.2f * _u, 2.5f * _u, 2.6f * _u, 2.3f * _u);
                FillSoft(Tone(.97f, .80f));

                // Clavicle: bulbous sternal end, gentle double curve, flattened acromial end.
                Vector2 start = new Vector2(sternal.x - side * 1.2f * _u, sternal.y - 2.4f * _u);
                Vector2 span = acromial - start;
                Knots();
                K(start);
                K(start + span * .30f + new Vector2(0f, 3.4f * _u));
                K(start + span * .62f + new Vector2(0f, 2.9f * _u));
                K(start + span * .86f + new Vector2(0f, .8f * _u));
                K(acromial);
                SplineOpen();
                TubeFromShape(3.5f * _u, 2.45f * _u, 2.2f * _u, 2.7f * _u);
                Halo(.46f);
                FillSoft(Tone(1.04f, .92f));
            }
        }

        /// <summary>Turns the open centre line in the shape buffer into a closed tube outline with rounded ends.</summary>
        private void TubeFromShape(float halfStart, float halfQuarter, float halfThreeQuarter, float halfEnd)
        {
            int n = Mathf.Min(_shapeCount, _center.Length);
            if (n < 2) { _shapeCount = 0; return; }
            for (int i = 0; i < n; i++) _center[i] = _shape[i];
            _shapeCount = 0;
            for (int pass = 0; pass < 2; pass++)
            {
                for (int step = 0; step < n; step++)
                {
                    int i = pass == 0 ? step : n - 1 - step;
                    Vector2 before = _center[i] - _center[Mathf.Max(0, i - 1)], after = _center[Mathf.Min(n - 1, i + 1)] - _center[i];
                    Vector2 tangent = before + after;
                    if (tangent.sqrMagnitude < .0000001f) tangent = Vector2.right;
                    tangent.Normalize();
                    Vector2 normal = new Vector2(-tangent.y, tangent.x) * (pass == 0 ? 1f : -1f);
                    float t = i / (float)(n - 1);
                    float half = t < .25f ? Mathf.Lerp(halfStart, halfQuarter, t / .25f)
                        : t < .75f ? Mathf.Lerp(halfQuarter, halfThreeQuarter, (t - .25f) / .5f)
                        : Mathf.Lerp(halfThreeQuarter, halfEnd, (t - .75f) / .25f);
                    if (_shapeCount < _shape.Length) _shape[_shapeCount++] = _center[i] + normal * half;
                }
                // Rounded cap at the end just reached.
                int end = pass == 0 ? n - 1 : 0, inner = pass == 0 ? n - 2 : 1;
                Vector2 axis = (_center[end] - _center[inner]).normalized;
                float capHalf = pass == 0 ? halfEnd : halfStart;
                // The outward axis already flips between the two ends, so the cap starts on the side just drawn.
                Vector2 capNormal = new Vector2(-axis.y, axis.x);
                for (int step = 1; step <= 3; step++)
                {
                    float angle = step * Mathf.PI / 4f;
                    if (_shapeCount < _shape.Length)
                        _shape[_shapeCount++] = _center[end] + capNormal * (Mathf.Cos(angle) * capHalf) + axis * (Mathf.Sin(angle) * capHalf * .8f);
                }
            }
        }

        private void DrawPelvis()
        {
            // Sacrum and coccyx close the ring behind the two hip bones.
            Knots();
            float[] sx = { 0f, 9f, 17f, 22f, 20f, 14.5f, 9f, 4.5f, 0f };
            float[] sy = { -177.8f, -177.2f, -178.6f, -182.4f, -192f, -204f, -214f, -221.5f, -223.4f };
            for (int i = 0; i < sx.Length; i++) K(D(sx[i], sy[i]));
            for (int i = sx.Length - 2; i >= 1; i--) K(D(-sx[i], sy[i]));
            SplineClosed();
            FillSoft(Tone(.90f, .66f));
            for (int level = 0; level < 4; level++)
            {
                float y = -186f - level * 8.4f, x = 11.4f - level * 2f;
                for (int side = -1; side <= 1; side += 2)
                    Disc(D(side * x, y), 1.7f * _kx, 1.25f * _ky, Shade(.62f));
                if (level > 0)
                {
                    _shapeCount = 2;
                    _shape[0] = D(-x - 1.5f, y + 4.3f);
                    _shape[1] = D(x + 1.5f, y + 4.3f);
                    Ribbon(false, Shade(.22f), Stroke(.8f));
                }
            }
            Knots();
            K(D(0f, -223f)); K(D(0f, -228f)); K(D(0f, -233.5f));
            SplineOpen();
            Ribbon(false, Tone(.9f, .66f), Tone(.9f, .5f), Stroke(4.6f), Stroke(1.8f));

            for (int index = 0; index < 2; index++)
            {
                float side = index == 0 ? 1f : -1f;
                Vector2 socket = BonePoint((BodyPart)(12 + index), 0f);
                // Hip bone: iliac wing, acetabular region, ischium and both pubic rami in one outline.
                float[] hx = { 16f, 24f, 36f, 47f, 54.5f, 56f, 53.4f, 50.8f, 52.4f, 55.2f, 54.6f, 50f, 42.4f, 36.4f, 30f, 23f,
                    16f, 8.4f, 3.6f, 2.2f, 2.6f, 8f, 20f, 29.6f, 31f, 27.6f, 20.4f };
                float[] hy = { -178f, -170.6f, -166.2f, -168.6f, -175.6f, -183f, -190f, -196f, -200f, -206f, -214f, -222.4f, -236f,
                    -250f, -257.6f, -256.2f, -248.4f, -241.4f, -239.6f, -233f, -226.6f, -224.4f, -219.6f, -213f, -203f, -193f, -185f };
                Knots();
                for (int i = 0; i < hx.Length; i++) K(D(side * hx[i], hy[i]));
                SplineClosed();
                Halo(.34f);
                FillSoft(PartBone(BodyPart.Pelvis, 1f, .86f));

                // Obturator foramen.
                float[] fx = { 13f, 21f, 29f, 33f, 29.6f, 22f, 15f, 11.4f };
                float[] fy = { -230.6f, -228.2f, -230f, -237f, -244.6f, -246.6f, -242f, -236f };
                Knots();
                for (int i = 0; i < fx.Length; i++) K(D(side * fx[i], fy[i]));
                SplineClosed();
                FillSoft(Shade(.86f));

                // Arcuate line of the pelvic brim.
                Knots();
                K(D(side * 21f, -186f)); K(D(side * 27.4f, -194f)); K(D(side * 30f, -203f)); K(D(side * 28.4f, -212f));
                K(D(side * 19.4f, -218.6f)); K(D(side * 8.4f, -223.4f));
                SplineOpen();
                Ribbon(false, Tone(1.3f, .55f), Stroke(1.05f));

                // Acetabulum: the socket is darker than the femoral head that sits in it.
                Disc(socket, 11.6f * _u, 11.6f * _u, Shade(.58f));
            }
        }

        private void DrawSkull(Rect head)
        {
            Color bone = PartBone(BodyPart.Head, 1.02f, .90f);
            // Mandible: body, angles and ascending rami; the tops of the rami hide behind the cheekbones.
            float[] mx = { 0f, .10f, .205f, .285f, .318f, .333f, .336f, .292f, .268f, .242f, .212f, .172f, 0f };
            float[] my = { .032f, .048f, .088f, .165f, .235f, .32f, .372f, .372f, .31f, .255f, .212f, .198f, .196f };
            Knots();
            for (int i = 0; i < mx.Length; i++) K(P(head, .5f + mx[i], my[i]));
            for (int i = mx.Length - 2; i >= 1; i--) K(P(head, .5f - mx[i], my[i]));
            SplineClosed();
            Halo(.40f);
            FillSoft(Tone(bone, .97f, 1f));

            // Cranial vault and the facial skeleton down to the upper alveolar margin.
            float[] cx = { 0f, .17f, .31f, .395f, .432f, .408f, .386f, .398f, .372f, .31f, .245f, .20f, .172f, 0f };
            float[] cy = { .965f, .95f, .885f, .775f, .665f, .575f, .50f, .435f, .39f, .36f, .325f, .285f, .268f, .262f };
            Knots();
            for (int i = 0; i < cx.Length; i++) K(P(head, .5f + cx[i], cy[i]));
            for (int i = cx.Length - 2; i >= 1; i--) K(P(head, .5f - cx[i], cy[i]));
            SplineClosed();
            Halo(.40f);
            FillSoft(bone);

            // Coronal suture.
            Knots();
            K(P(head, .5f - .345f, .79f)); K(P(head, .5f - .19f, .872f)); K(P(head, .5f, .902f));
            K(P(head, .5f + .19f, .872f)); K(P(head, .5f + .345f, .79f));
            SplineOpen();
            Ribbon(false, Shade(.20f), Stroke(.8f));

            for (int side = -1; side <= 1; side += 2)
            {
                // Temporal fossa behind the lateral orbital rim.
                float[] tx = { .348f, .386f, .402f, .386f, .357f, .346f };
                float[] ty = { .60f, .585f, .52f, .462f, .476f, .53f };
                Knots();
                for (int i = 0; i < tx.Length; i++) K(P(head, .5f + side * tx[i], ty[i]));
                SplineClosed();
                FillSoft(Shade(.30f));

                // Orbit: squared superior rim, sloping lateral margin.
                float[] ex = { .082f, .118f, .20f, .275f, .306f, .296f, .243f, .16f, .098f, .078f };
                float[] ey = { .548f, .578f, .588f, .572f, .532f, .478f, .444f, .436f, .462f, .505f };
                Knots();
                for (int i = 0; i < ex.Length; i++) K(P(head, .5f + side * ex[i], ey[i]));
                SplineClosed();
                FillSoft(Shade(.93f));
                Ribbon(true, Tone(1.22f, .40f), Stroke(.8f));
                // Brow ridge above the orbit.
                Knots();
                K(P(head, .5f + side * .07f, .588f)); K(P(head, .5f + side * .15f, .614f));
                K(P(head, .5f + side * .255f, .608f)); K(P(head, .5f + side * .325f, .572f));
                SplineOpen();
                Ribbon(false, Tone(1.3f, .0f), Tone(1.3f, .30f), Stroke(1.2f), Stroke(1.2f));
                // Lower edge of the cheekbone.
                Knots();
                K(P(head, .5f + side * .355f, .405f)); K(P(head, .5f + side * .30f, .378f)); K(P(head, .5f + side * .245f, .352f));
                SplineOpen();
                Ribbon(false, Tone(1.3f, .26f), Tone(1.3f, .0f), Stroke(1.1f), Stroke(1.1f));
            }

            // Piriform aperture with the septum.
            float[] nx = { 0f, .045f, .076f, .07f, .03f, 0f };
            float[] ny = { .456f, .43f, .375f, .336f, .318f, .332f };
            Knots();
            for (int i = 0; i < nx.Length; i++) K(P(head, .5f + nx[i], ny[i]));
            for (int i = nx.Length - 2; i >= 1; i--) K(P(head, .5f - nx[i], ny[i]));
            SplineClosed();
            FillSoft(Shade(.93f));
            Ribbon(true, Tone(1.28f, .50f), Stroke(.8f));
            _shapeCount = 2;
            _shape[0] = P(head, .5f, .446f);
            _shape[1] = P(head, .5f, .34f);
            Ribbon(false, Tone(1.2f, .50f), Stroke(.8f));

            // Dental arcade: upper and lower crowns with the occlusal line between them.
            float[] ax = { -.172f, -.12f, 0f, .12f, .172f, .168f, .12f, 0f, -.12f, -.168f };
            float[] ay = { .272f, .268f, .264f, .268f, .272f, .206f, .202f, .199f, .202f, .206f };
            Knots();
            for (int i = 0; i < ax.Length; i++) K(P(head, .5f + ax[i], ay[i]));
            SplineClosed();
            FillSoft(Tone(1.36f, 1f));
            for (int tooth = -5; tooth <= 5; tooth++)
            {
                float x = Mathf.Sin(tooth * 13f * Mathf.Deg2Rad) * .19f;
                _shapeCount = 2;
                _shape[0] = P(head, .5f + x, .268f);
                _shape[1] = P(head, .5f + x, .204f);
                Ribbon(false, Shade(.46f), Stroke(.7f));
            }
            Knots();
            K(P(head, .5f - .172f, .242f)); K(P(head, .5f, .234f)); K(P(head, .5f + .172f, .242f));
            SplineOpen();
            Ribbon(false, Shade(.70f), Stroke(.95f));
            // Mental protuberance.
            Knots();
            K(P(head, .5f - .085f, .092f)); K(P(head, .5f, .074f)); K(P(head, .5f + .085f, .092f));
            SplineOpen();
            Ribbon(false, Tone(1.3f, .36f), Stroke(1.2f));
        }

        private void DrawLimbs()
        {
            for (int index = 0; index < 2; index++)
            {
                float side = index == 0 ? 1f : -1f;
                DrawArmBones(index, side);
                DrawLegBones(index, side);
            }
        }

        /// <summary>Point of a long bone: fraction along the axis, lateral offset positive away from the midline.</summary>
        private static Vector2 Along(Vector2 a, Vector2 b, float side, float fraction, float lateral)
        {
            Vector2 axis = (b - a).normalized;
            Vector2 normal = new Vector2(-axis.y, axis.x);
            if (normal.x * side < 0f) normal = -normal;
            return Vector2.LerpUnclamped(a, b, fraction) + normal * lateral;
        }

        private void DrawArmBones(int index, float side)
        {
            BodyPart upperPart = (BodyPart)(6 + index), forearmPart = (BodyPart)(8 + index), handPart = (BodyPart)(10 + index);
            Vector2 shoulder = BonePoint(upperPart, 0f), elbow = BonePoint(upperPart, 1f), wrist = BonePoint(forearmPart, 1f);
            float u = _u;

            // Ulna: stout at the elbow, slender toward the little-finger side of the wrist.
            float[] ut = { -.01f, -.02f, -.005f, .05f, .12f, .30f, .60f, .85f, .95f, .985f, .99f, .965f, .90f, .60f, .30f, .12f, .05f };
            float[] ul = { -9.2f, -4.5f, .5f, 1.4f, -.6f, .2f, 3.6f, 6.3f, 7.4f, 7f, 4.4f, 2.6f, 2f, -.6f, -4.6f, -7.4f, -9.4f };
            Knots();
            for (int i = 0; i < ut.Length; i++) K(Along(elbow, wrist, side, ut[i], ul[i] * u));
            SplineClosed();
            FillSoft(PartBone(forearmPart, .96f, .84f));

            // Humerus.
            float[] ht = { -.075f, -.062f, -.03f, .02f, .075f, .14f, .30f, .42f, .60f, .80f, .885f, .935f, .965f, .995f, 1.002f, .992f,
                1.012f, 1.008f, .975f, .94f, .905f, .86f, .70f, .40f, .16f, .085f, .045f, 0f, -.045f };
            float[] hl = { -2f, 3.5f, 8.3f, 9.6f, 8.2f, 6.3f, 4.7f, 5.1f, 3.9f, 4.5f, 7.2f, 9.4f, 9.2f, 7.4f, 3f, 0f,
                -3.5f, -8f, -10.4f, -11.2f, -8.8f, -6.2f, -3.9f, -4.1f, -5.4f, -7.2f, -9.6f, -10.6f, -8.2f };
            Knots();
            for (int i = 0; i < ht.Length; i++) K(Along(shoulder, elbow, side, ht[i], hl[i] * u));
            SplineClosed();
            Halo(.36f);
            FillSoft(PartBone(upperPart));
            // Anatomical neck, shaft highlight and the fossa above the trochlea.
            Knots();
            K(Along(shoulder, elbow, side, -.055f, 3.2f * u)); K(Along(shoulder, elbow, side, .0f, 1.6f * u));
            K(Along(shoulder, elbow, side, .05f, -6.4f * u));
            SplineOpen();
            Ribbon(false, Shade(.26f), Stroke(.9f));
            Knots();
            K(Along(shoulder, elbow, side, .14f, 3.4f * u)); K(Along(shoulder, elbow, side, .45f, 3f * u));
            K(Along(shoulder, elbow, side, .80f, 2.4f * u));
            SplineOpen();
            Ribbon(false, Tone(1.3f, .0f), Tone(1.3f, .34f), Stroke(1.2f), Stroke(1.2f));
            Disc(Along(shoulder, elbow, side, .928f, -1.2f * u), 3.3f * u, 2.3f * u, Shade(.42f));

            // Radius: crosses in front of the ulna because the palm faces back.
            float[] rt = { .005f, -.002f, .006f, .035f, .055f, .10f, .20f, .40f, .60f, .80f, .90f, .955f, .985f, .992f, 1.01f, 1.03f,
                .985f, .94f, .88f, .75f, .60f, .40f, .20f, .13f, .085f, .05f, .03f };
            float[] rl = { 2.6f, 6f, 9.4f, 9.8f, 8.4f, 7.2f, 6.4f, 3.6f, .2f, -1.2f, .2f, 1.6f, 1.4f, -3f, -8f, -10.2f,
                -10.9f, -9.8f, -7.6f, -6.2f, -4.6f, -1.2f, 1.6f, 1.9f, 3.4f, 3.6f, 2.6f };
            Knots();
            for (int i = 0; i < rt.Length; i++) K(Along(elbow, wrist, side, rt[i], rl[i] * u));
            SplineClosed();
            Halo(.40f);
            FillSoft(PartBone(forearmPart));
            Knots();
            K(Along(elbow, wrist, side, .14f, 4.6f * u)); K(Along(elbow, wrist, side, .50f, .4f * u));
            K(Along(elbow, wrist, side, .86f, -4.6f * u));
            SplineOpen();
            Ribbon(false, Tone(1.3f, .0f), Tone(1.3f, .32f), Stroke(1f), Stroke(1f));

            DrawHand(R(handPart), index == 0);
        }

        private void DrawLegBones(int index, float side)
        {
            BodyPart thighPart = (BodyPart)(12 + index), kneePart = (BodyPart)(14 + index);
            BodyPart shinPart = (BodyPart)(16 + index), footPart = (BodyPart)(18 + index);
            Vector2 hip = BonePoint(thighPart, 0f), knee = BonePoint(thighPart, 1f), ankle = BonePoint(shinPart, 1f);
            float u = _u;

            // Femur: head, neck, both trochanters, bowed shaft and the two condyles.
            Knots();
            K(hip + new Vector2(0f, 9.6f) * u);
            K(hip + new Vector2(side * 6.9f, 6.9f) * u);
            K(hip + new Vector2(side * 13.4f, 2.2f) * u);
            K(hip + new Vector2(side * 18.9f, 3.2f) * u);
            K(hip + new Vector2(side * 23.4f, 2.2f) * u);
            K(hip + new Vector2(side * 27.4f, -2.3f) * u);
            K(hip + new Vector2(side * 28.4f, -9.3f) * u);
            K(hip + new Vector2(side * 26.6f, -19.3f) * u);
            // The shaft runs obliquely from the trochanters to the knee and is narrowest just below its middle.
            Vector2 lateralTop = Along(hip, knee, side, .17f, 24.2f * u), lateralBottom = Along(hip, knee, side, .849f, 10.6f * u);
            Vector2 medialTop = Along(hip, knee, side, .21f, 11.1f * u), medialBottom = Along(hip, knee, side, .849f, -7.9f * u);
            K(lateralTop);
            K(Along(hip, knee, side, .466f, 19f * u));
            K(Along(hip, knee, side, .72f, 12.5f * u));
            K(lateralBottom);
            K(knee + new Vector2(side * 13f, 14.7f) * u);
            K(knee + new Vector2(side * 15.8f, 6.2f) * u);
            K(knee + new Vector2(side * 15f, -.8f) * u);
            K(knee + new Vector2(side * 10.5f, -5.8f) * u);
            K(knee + new Vector2(side * 3.5f, -4.8f) * u);
            K(knee + new Vector2(side * .3f, -1.8f) * u);
            K(knee + new Vector2(-side * 3f, -4.8f) * u);
            K(knee + new Vector2(-side * 10f, -6.1f) * u);
            K(knee + new Vector2(-side * 14.7f, -.8f) * u);
            K(knee + new Vector2(-side * 15.7f, 6.7f) * u);
            K(knee + new Vector2(-side * 13f, 15.7f) * u);
            K(medialBottom);
            K(Along(hip, knee, side, .72f, .1f * u));
            K(Along(hip, knee, side, .466f, 6.1f * u));
            K(medialTop);
            K(hip + new Vector2(side * 10.9f, -29.3f) * u);
            K(hip + new Vector2(side * 6.9f, -24.3f) * u);
            K(hip + new Vector2(side * 8.4f, -17.3f) * u);
            K(hip + new Vector2(side * 5.4f, -10.3f) * u);
            K(hip + new Vector2(-side * .6f, -8.9f) * u);
            K(hip + new Vector2(-side * 6.1f, -7.5f) * u);
            K(hip + new Vector2(-side * 9.4f, -.3f) * u);
            K(hip + new Vector2(-side * 6.6f, 6.7f) * u);
            SplineClosed();
            Halo(.36f);
            FillSoft(PartBone(thighPart));
            // Shaft highlight.
            Knots();
            K(Vector2.Lerp(lateralTop, lateralBottom, .04f) - new Vector2(side * 3.2f, 0f) * u);
            K(Vector2.Lerp(lateralTop, lateralBottom, .5f) - new Vector2(side * 2.6f, 0f) * u);
            K(Vector2.Lerp(lateralTop, lateralBottom, .96f) - new Vector2(side * 3.4f, 0f) * u);
            SplineOpen();
            Ribbon(false, Tone(1.3f, .0f), Tone(1.3f, .34f), Stroke(1.4f), Stroke(1.4f));

            // Fibula first: its head tucks behind the lateral tibial condyle.
            float[] fx = { 15.5f, 18.5f, 18.8f, 17.1f, 16.1f, 8.7f, 8.9f, 10.2f, 10.6f, 9.1f, 6.9f, 6.6f, 5.6f, 5.2f, 12.7f, 13.3f, 12.8f, 13.3f };
            float[] fy = { -11.8f, -14.8f, -19.8f, -26.3f, -55.3f, 46.9f, 16.9f, 6.9f, -.1f, -6.6f, -4.1f, 5.9f, 16.9f, 46.9f, -55.3f, -26.3f, -19.3f, -14.3f };
            bool[] fromKnee = { true, true, true, true, true, false, false, false, false, false, false, false, false, false, true, true, true, true };
            Knots();
            for (int i = 0; i < fx.Length; i++)
                K((fromKnee[i] ? knee : ankle) + new Vector2(side * fx[i], fy[i]) * u);
            SplineClosed();
            FillSoft(PartBone(shinPart, .96f, .82f));

            // Tibia: broad plateau, triangular shaft, medial malleolus.
            float[] tx = { -15.3f, -7.5f, 0f, 7.5f, 15.3f, 15.8f, 13f, 9.3f, 8.1f, 1.6f, 3.9f, 5.5f, 5.7f, -.2f, -4.2f, -6.2f, -8.1f, -8.1f,
                -7.4f, -.9f, -4.3f, -9.5f, -14.5f, -15.9f };
            float[] ty = { -8.5f, -7.5f, -6.1f, -7.5f, -8.5f, -13.8f, -20.3f, -30.3f, -55.3f, 46.9f, 16.9f, 5.9f, -.4f, -1.4f, -1.9f, -6.6f,
                -2.6f, 6.9f, 26.9f, -75.3f, -45.3f, -27.3f, -18.3f, -13.3f };
            bool[] tibiaFromKnee = { true, true, true, true, true, true, true, true, true, false, false, false, false, false, false, false,
                false, false, false, true, true, true, true, true };
            Knots();
            for (int i = 0; i < tx.Length; i++)
                K((tibiaFromKnee[i] ? knee : ankle) + new Vector2(side * tx[i], ty[i]) * u);
            SplineClosed();
            Halo(.36f);
            FillSoft(PartBone(shinPart));
            // Anterior crest of the tibia.
            Knots();
            K(knee + new Vector2(side * .8f, -21f) * u); K(Vector2.Lerp(knee, ankle, .5f) + new Vector2(side * 1.6f, 0f) * u);
            K(ankle + new Vector2(-side * 1.6f, 14f) * u);
            SplineOpen();
            Ribbon(false, Tone(1.3f, .28f), Tone(1.3f, .0f), Stroke(1.3f), Stroke(1.3f));

            // Patella in front of the joint.
            Vector2 patella = BonePoint(kneePart, .5f) + new Vector2(0f, 5.2f) * u;
            Knots();
            K(patella + new Vector2(0f, 8.2f) * u); K(patella + new Vector2(5.5f, 7f) * u); K(patella + new Vector2(8f, 2.5f) * u);
            K(patella + new Vector2(6.8f, -3.5f) * u); K(patella + new Vector2(3f, -8f) * u); K(patella + new Vector2(0f, -9.2f) * u);
            K(patella + new Vector2(-3f, -8f) * u); K(patella + new Vector2(-6.8f, -3.5f) * u); K(patella + new Vector2(-8f, 2.5f) * u);
            K(patella + new Vector2(-5.5f, 7f) * u);
            SplineClosed();
            Halo(.42f);
            FillSoft(PartBone(kneePart, 1.06f, .92f));

            DrawFoot(R(footPart), index == 0);
        }

        private static Vector2 HandPoint(Rect rect, bool left, float x, float y)
            => P(rect, left ? x : 1f - x, y);

        private void DrawHand(Rect rect, bool left)
        {
            BodyPart part = left ? BodyPart.LeftHand : BodyPart.RightHand;
            Vector2 wrist = BonePoint(part, 0f), palm = BonePoint(part, 1f);
            Color tint = PartBone(part, 1f, .88f);
            float direction = left ? 1f : -1f;
            // Carpus: scaphoid, lunate and triquetrum above; trapezium, trapezoid, capitate and hamate below.
            float[] carpalAcross = { -4.3f, -.3f, 3.6f, -5.7f, -2.5f, 1f, 4.7f };
            float[] carpalAlong = { .075f, .068f, .085f, .205f, .215f, .20f, .205f };
            float[] carpalWide = { 2.5f, 2.05f, 1.95f, 1.95f, 1.55f, 1.95f, 2.15f };
            float[] carpalTall = { 1.95f, 2.0f, 1.85f, 1.85f, 1.7f, 2.65f, 2.15f };
            float[] carpalTurn = { -.5f, 0f, .4f, -.3f, 0f, 0f, .3f };
            for (int i = 0; i < carpalAcross.Length; i++)
            {
                Vector2 carpal = ConstrainToSurface(part, Vector2.Lerp(wrist, palm, carpalAlong[i]) +
                    Vector2.right * direction * carpalAcross[i] * _u);
                Disc(carpal, carpalWide[i] * _u, carpalTall[i] * _u, Tone(tint, .97f, .92f), direction * carpalTurn[i]);
            }
            for (int finger = 0; finger < 4; finger++)
            {
                float x = .40f + finger * .17f;
                Vector2 knuckle = ConstrainToSurface(part, HandPoint(rect, left, x, .49f + (finger == 3 ? .025f : 0f)));
                Vector2 basePoint = Vector2.Lerp(wrist, palm, .33f) + Vector2.right * direction * (finger - 1.5f) * 3.3f * _u;
                SmallBone(basePoint, knuckle, 1.55f * _u, tint, 1.25f);
                float tipY = finger == 0 ? .12f : finger == 1 ? .035f : finger == 2 ? .09f : .23f;
                Vector2 middle = ConstrainToSurface(part, HandPoint(rect, left, x - .035f, Mathf.Lerp(.49f, tipY, .45f)));
                Vector2 distal = ConstrainToSurface(part, HandPoint(rect, left, x - .060f, Mathf.Lerp(.49f, tipY, .77f)));
                Vector2 tip = ConstrainToSurface(part, HandPoint(rect, left, x - .070f, tipY));
                FingerBone(knuckle, middle, 1.4f, tint); FingerBone(middle, distal, 1.25f, tint); FingerBone(distal, tip, 1.1f, tint);
            }
            Vector2 thumbBase = ConstrainToSurface(part, HandPoint(rect, left, .29f, .66f));
            Vector2 thumbJoint = ConstrainToSurface(part, HandPoint(rect, left, .14f, .48f));
            Vector2 thumbTip = ConstrainToSurface(part, HandPoint(rect, left, .06f, .35f));
            FingerBone(Vector2.Lerp(wrist, palm, .24f) - Vector2.right * direction * 5.4f * _u, thumbBase, 1.6f, tint);
            FingerBone(thumbBase, thumbJoint, 1.45f, tint); FingerBone(thumbJoint, thumbTip, 1.25f, tint);
        }

        private void DrawFoot(Rect rect, bool left)
        {
            BodyPart part = left ? BodyPart.LeftFoot : BodyPart.RightFoot;
            Color tint = PartBone(part, 1f, .88f);
            // Talus under the ankle mortise, then the midfoot row.
            Vector2 talus = SurfacePoint(part, .5f, .83f, 3f);
            Disc(talus, 5.2f * _u, 3.6f * _u, Tone(tint, .97f, .92f));
            // Navicular and cuboid, then the three cuneiforms toward the great toe.
            float[] tarsalAcross = { .37f, .69f, .22f, .37f, .51f };
            float[] tarsalHeight = { .735f, .70f, .645f, .64f, .635f };
            float[] tarsalWide = { 3.5f, 3.1f, 2.2f, 1.9f, 1.9f };
            float[] tarsalTall = { 2.3f, 3.0f, 2.3f, 2.2f, 2.2f };
            for (int i = 0; i < tarsalAcross.Length; i++)
            {
                float across = left ? tarsalAcross[i] : 1f - tarsalAcross[i];
                Disc(SurfacePoint(part, across, tarsalHeight[i], 2.5f), tarsalWide[i] * _u, tarsalTall[i] * _u, Tone(tint, .97f, .92f));
            }
            for (int toe = 0; toe < 5; toe++)
            {
                float x = .12f + toe * .19f;
                if (!left) x = 1f - x;
                Vector2 basePoint = SurfacePoint(part, Mathf.Lerp(.5f, x, .62f), .60f, 2.2f);
                Vector2 knuckle = SurfacePoint(part, x, .31f + toe * .025f, 2.2f);
                Vector2 tip = SurfacePoint(part, x, .09f + toe * .039f, 2.2f);
                SmallBone(basePoint, knuckle, (toe == 0 ? 2.1f : 1.45f) * _u, tint, 1.25f);
                Vector2 joint = Vector2.Lerp(knuckle, tip, .55f);
                FingerBone(knuckle, joint, toe == 0 ? 1.9f : 1.25f, tint); FingerBone(joint, tip, toe == 0 ? 1.7f : 1.1f, tint);
            }
        }

        private void FingerBone(Vector2 from, Vector2 to, float halfWidth, Color tint)
        {
            Vector2 direction = to - from;
            float gap = Mathf.Min(.75f * _u, direction.magnitude * .10f);
            direction = direction.normalized * gap;
            SmallBone(from + direction, to - direction, halfWidth * _u, tint, .86f);
        }

        /// <summary>Metacarpal, metatarsal or phalanx: flared base, waisted shaft, rounded head.</summary>
        private void SmallBone(Vector2 a, Vector2 b, float halfWidth, Color tint, float headScale)
        {
            if ((a - b).sqrMagnitude < .01f) return;
            Vector2 axis = (b - a).normalized, normal = new Vector2(-axis.y, axis.x);
            float length = Vector2.Distance(a, b), head = halfWidth * headScale;
            Knots();
            K(a - normal * halfWidth); K(a - axis * halfWidth * .35f); K(a + normal * halfWidth);
            K(a + axis * length * .30f + normal * halfWidth * .62f); K(a + axis * length * .72f + normal * head * .62f);
            K(b + normal * head); K(b + axis * head * .40f); K(b - normal * head);
            K(a + axis * length * .72f - normal * head * .62f); K(a + axis * length * .30f - normal * halfWidth * .62f);
            SplineClosed();
            FillSoft(tint);
        }
    }
}
