using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public sealed partial class K_HealthDollAnatomyGraphic
    {
        private void DrawWounds()
        {
            if (Wounds == null) return;
            for (int i = 0; i < Wounds.Count; i++)
            {
                K_AnatomicalWound wound = Wounds[i];
                int index = (int)wound.Part;
                if (index < 0 || index >= 20 || !wound.HasExactPosition) continue;
                _hasLocatedWound[index] = true;
                if (wound.IsBack) continue;
                _exactOnSide[index] = true;
            }
        }

        private void DrawPartWounds(BodyPart part, LacerationType closure)
        {
            if (Wounds == null || !_exactOnSide[(int)part]) return;
            bool dense = VisibleExactWoundCount() > 64;
            for (int i = 0; i < Wounds.Count; i++)
            {
                K_AnatomicalWound wound = Wounds[i];
                if (wound.Part != part || !wound.HasExactPosition || wound.IsBack) continue;
                Rect rect = R(wound.Part);
                if (rect.width <= 0f || rect.height <= 0f) continue;
                Vector2 point = P(rect, wound.X01, wound.Y01);
                float radius = Mathf.Clamp(rect.width * .09f, 3.6f * _unitsPerPixel, 4.3f * _unitsPerPixel);
                if (closure == LacerationType.Glued || closure == LacerationType.Sealed)
                {
                    DrawLaceration(point, radius * 2.2f, closure);
                    continue;
                }
                Color rim = new Color(.93f, .57f, .44f, .98f);
                if (!dense) TissuePatch(point, radius * 2.9f, radius * 2.3f, new Color(.56f, .17f, .21f, .69f));
                Irregular(point, radius * 1.12f, radius, new Color(.58f, .12f, .16f, .98f),
                    dense ? Color.clear : rim, dense ? 0f : InjuryStroke(1.1f));
                Irregular(point + new Vector2(.16f, -.10f) * radius, radius * .72f, radius * .64f,
                    new Color(.025f, .018f, .023f, 1f), Color.clear, 0f);
                if (dense) continue;
                for (int nick = 0; nick < 2; nick++)
                {
                    float angle = .65f + nick * 2.3f;
                    Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
                    InjuryLine(point + direction * radius * .96f, point + direction * radius * 1.6f,
                        new Color(.74f, .30f, .29f, .98f), 1.05f);
                }
            }
        }

        private void DrawLocalState(BodyPart part)
        {
            int index = (int)part;
            K_HealthDollAnatomyPart state = State.Parts[index];
            Rect rect = R(part);
            if (rect.width <= 0f || rect.height <= 0f) return;
            Vector2 woundPoint = TissuePoint(part);
            TryWoundPoint(part, ref woundPoint);
            if (state.InternalBleedingRevealed)
                DrawRevealedBleeding(part, rect);
            if (state.Infected)
                DrawInflammation(rect, woundPoint, state.InfectionRecovering);
            if (state.HealBoost)
            {
                float gelWidth = Mathf.Min(rect.width * .35f, 11f * _unitsPerPixel);
                float gelHeight = Mathf.Min(rect.height * .16f, 8f * _unitsPerPixel);
                TissuePatch(woundPoint, gelWidth, gelHeight, new Color(.59f, .65f, .48f, .45f));
                InjuryLine(woundPoint + new Vector2(-gelWidth * .55f, gelHeight * .35f),
                    woundPoint + new Vector2(gelWidth * .35f, gelHeight * .45f),
                    new Color(.84f, .87f, .69f, .80f), 1.0f);
            }
            if (state.Gunshot && !_exactOnSide[index])
            {
                // A diffuse tissue change carries regional knowledge without inventing a puncture point.
                float extent = Mathf.Min(rect.width * .42f, 13f * _unitsPerPixel);
                TissuePatch(woundPoint, extent, Mathf.Min(rect.height * .23f, extent * 1.30f),
                    new Color(.62f, .17f, .24f, _hasLocatedWound[index] ? .35f : .76f));
                TissuePatch(woundPoint + new Vector2(-extent * .13f, extent * .22f),
                    extent * .67f, extent * .79f,
                    new Color(.27f, .065f, .12f, _hasLocatedWound[index] ? .22f : .69f));
            }
            if (state.Laceration != LacerationType.None &&
                (!state.Gunshot || (!_exactOnSide[index] && state.Laceration != LacerationType.Open)))
                DrawLaceration(woundPoint, Mathf.Clamp(rect.width * .36f, 10f * _unitsPerPixel, 14f * _unitsPerPixel), state.Laceration);
            DrawPartWounds(part, state.Laceration);
            if (state.BleedingLevel > 0f)
                DrawBloodTrace(rect, woundPoint, state.BleedingLevel);
            if (state.Fractured)
            {
                DrawBoneFracture(part, rect, state.Splinted || state.RecoverySeconds > 0f);
                if (state.Splinted) DrawSplint(part, rect);
            }
            if (state.HaemostasisPrepared || state.CoagulantSeconds > 0f)
                DrawHaemostaticPacking(woundPoint, rect);
            if (state.Tourniquet) DrawTourniquet(part, rect, state.ElasticTourniquet);
            if (state.Jett) DrawCompressionDevice(part, rect);
            if (part == BodyPart.Chest && State.ChestSeal)
            {
                Vector2 center = P(rect, .68f, .55f);
                TryWoundPoint(part, ref center);
                DrawChestSeal(center, rect);
            }
            if (part == BodyPart.Pelvis && State.PelvisStabilized)
            {
                DrawPelvicBinder(rect);
            }
        }

        private bool TryWoundPoint(BodyPart part, ref Vector2 point)
        {
            if (Wounds == null) return false;
            for (int i = 0; i < Wounds.Count; i++)
            {
                K_AnatomicalWound wound = Wounds[i];
                if (wound.Part != part || !wound.HasExactPosition || wound.IsBack) continue;
                point = P(R(part), wound.X01, wound.Y01);
                return true;
            }
            return false;
        }

        private Vector2 BonePoint(BodyPart part, float fraction)
        {
            int index = (int)part;
            if (BoneStarts != null && BoneEnds != null && index < BoneStarts.Length && index < BoneEnds.Length &&
                (BoneEnds[index] - BoneStarts[index]).sqrMagnitude > .001f)
                return Vector2.Lerp(BoneStarts[index], BoneEnds[index], fraction);
            return P(R(part), .5f, 1f - fraction);
        }

        private Vector2 BoneDirection(BodyPart part)
        {
            Vector2 direction = BonePoint(part, .9f) - BonePoint(part, .1f);
            return direction.sqrMagnitude > .001f ? direction.normalized : Vector2.down;
        }

        private Vector2 TissuePoint(BodyPart part)
        {
            int index = (int)part;
            if (TissueCenters != null && index >= 0 && index < TissueCenters.Length && R(part).Contains(TissueCenters[index]))
                return TissueCenters[index];
            Rect rect = R(part);
            if (part == BodyPart.Head)
            {
                Rect cranium = CraniumRect.width > 0f ? CraniumRect : Sub(rect, .20f, .28f, .60f, .70f);
                return P(cranium, .62f, .50f);
            }
            return P(rect, .5f, .52f);
        }

        private void TissuePatch(Vector2 center, float radiusX, float radiusY, Color tint)
        {
            const int segments = 12;
            int first = _mesh.currentVertCount;
            _mesh.AddVert(center, tint, Vector2.zero);
            for (int ring = 0; ring < 2; ring++)
            {
                float extent = ring == 0 ? .43f : 1f;
                Color ringColor = Alpha(tint, ring == 0 ? .52f : 0f);
                for (int i = 0; i < segments; i++)
                {
                    float angle = i * Mathf.PI * 2f / segments;
                    float contour = 1f + .09f * Mathf.Sin(angle * 3f) + .05f * Mathf.Cos(angle * 5f);
                    Vector2 offset = new Vector2(Mathf.Cos(angle) * radiusX, Mathf.Sin(angle) * radiusY) * extent * contour;
                    _mesh.AddVert(center + offset, ringColor, Vector2.zero);
                }
            }
            for (int i = 0; i < segments; i++)
            {
                int next = (i + 1) % segments;
                int inner = first + 1 + i, innerNext = first + 1 + next;
                int outer = inner + segments, outerNext = innerNext + segments;
                _mesh.AddTriangle(first, inner, innerNext);
                _mesh.AddTriangle(inner, outer, outerNext);
                _mesh.AddTriangle(inner, outerNext, innerNext);
            }
        }

        private void DrawBloodTrace(Rect rect, Vector2 wound, float level)
        {
            level = Mathf.Clamp(level, 1f, 3f);
            float length = Mathf.Min((10f + level * 6f) * _unitsPerPixel, rect.height * .47f);
            float bottom = Mathf.Min(wound.y, Mathf.Max(rect.yMin + rect.height * .035f, wound.y - length));
            Vector2 middle = new Vector2(wound.x + .7f * _unitsPerPixel, Mathf.Lerp(wound.y, bottom, .46f));
            Vector2 end = new Vector2(wound.x - .45f * _unitsPerPixel, bottom);
            Color blood = new Color(.67f, .12f, .17f, .99f);
            float width = 1.2f + level * .65f;
            TissuePatch(Vector2.Lerp(wound, end, .35f), (2f + level * .5f) * _unitsPerPixel,
                length * .60f, new Color(.42f, .045f, .10f, .48f));
            InjuryLine(wound, middle, blood, width);
            InjuryLine(middle, end, Alpha(blood, .96f), width * .70f);
            InjuryLine(wound + Vector2.right * .55f * _unitsPerPixel,
                middle + Vector2.right * .45f * _unitsPerPixel, new Color(.96f, .36f, .31f, .85f), .90f);
            if (level > 1f)
                Ellipse(end, (.55f + level * .22f) * _unitsPerPixel, (.90f + level * .30f) * _unitsPerPixel,
                    blood, Color.clear, 0f, 10);
            if (level > 2f)
            {
                Vector2 branch = Vector2.Lerp(wound, middle, .62f);
                Vector2 branchEnd = new Vector2(wound.x - 2.25f * _unitsPerPixel, Mathf.Lerp(middle.y, bottom, .65f));
                InjuryLine(branch, branchEnd, Alpha(blood, .90f), 1.1f);
            }
        }

        private void DrawInflammation(Rect rect, Vector2 center, bool recovering)
        {
            float radiusX = Mathf.Min(rect.width * .38f, 11f * _unitsPerPixel);
            float radiusY = Mathf.Min(rect.height * .23f, radiusX * 1.15f);
            Color edge = recovering ? new Color(.69f, .65f, .43f, .84f) : new Color(.89f, .50f, .25f, .96f);
            TissuePatch(center, radiusX * 1.35f, radiusY * 1.40f,
                recovering ? new Color(.57f, .51f, .29f, .38f) : new Color(.79f, .30f, .14f, .69f));
            TissuePatch(center + new Vector2(-radiusX * .14f, radiusY * .16f), radiusX * .85f, radiusY * .75f,
                recovering ? new Color(.63f, .58f, .36f, .34f) : new Color(.75f, .43f, .16f, .58f));
            Vector2 upper = center + new Vector2(-radiusX * .42f, radiusY * .53f);
            Vector2 lower = center + new Vector2(radiusX * .49f, -radiusY * .46f);
            InjuryLine(upper + new Vector2(-radiusX * .16f, -radiusY * .08f),
                upper + new Vector2(radiusX * .20f, radiusY * .09f), edge, 1.1f);
            InjuryLine(lower + new Vector2(-radiusX * .12f, -radiusY * .05f),
                lower + new Vector2(radiusX * .14f, radiusY * .11f), Alpha(edge, .8f), 1.0f);
        }

        private void DrawRevealedBleeding(BodyPart part, Rect rect)
        {
            Vector2 center = TissuePoint(part);
            float radiusX = Mathf.Min(rect.width * .40f, 13f * _unitsPerPixel);
            float radiusY = Mathf.Min(rect.height * .29f, radiusX * 1.45f);
            TissuePatch(center, radiusX, radiusY, new Color(.49f, .22f, .60f, .77f));
            TissuePatch(center + new Vector2(-radiusX * .22f, radiusY * .27f),
                radiusX * .65f, radiusY * .61f, new Color(.27f, .075f, .37f, .72f));
            InjuryLine(center + new Vector2(-radiusX * .41f, radiusY * .19f),
                center + new Vector2(radiusX * .17f, -radiusY * .32f), new Color(.69f, .36f, .70f, .65f), 1.0f);
        }

        private float InjuryStroke(float pixels)
            => pixels * _unitsPerPixel / Mathf.Max(.01f, LineWidth * _unit);

        private void InjuryLine(Vector2 from, Vector2 to, Color tint, float pixels)
        {
            bool feather = _featherLines;
            _featherLines = true;
            Line(from, to, tint, InjuryStroke(pixels));
            _featherLines = feather;
        }

        private void DrawBoneFracture(BodyPart part, Rect rect, bool supported)
        {
            Vector2 center = BonePoint(part, .52f);
            Vector2 tangent = BoneDirection(part);
            float metric = CraniumRect.height > 0f ? CraniumRect.height : R(BodyPart.Head).height * .7f;
            float halfWidth = Mathf.Clamp(rect.width * .10f, 1.1f * _unit, 3.2f * _unit);
            if (part == BodyPart.Head)
            {
                Rect cranium = CraniumRect.width > 0f ? CraniumRect : Sub(rect, .20f, .28f, .60f, .70f);
                center = P(cranium, .75f, .74f);
                tangent = new Vector2(.25f, .97f);
            }
            else if (part == BodyPart.Pelvis)
            {
                center = P(rect, .28f, .66f);
                tangent = new Vector2(-.45f, -.89f);
            }
            else if (part == BodyPart.LeftShoulder || part == BodyPart.RightShoulder)
            {
                BodyPart upperArm = part == BodyPart.LeftShoulder ? BodyPart.LeftBiceps : BodyPart.RightBiceps;
                center = BonePoint(part, 1f);
                tangent = BoneDirection(upperArm);
                halfWidth = metric * .08f;
            }
            else if (part == BodyPart.LeftBiceps || part == BodyPart.RightBiceps)
                halfWidth = metric * .046f;
            else if (part == BodyPart.LeftQuadriceps || part == BodyPart.RightQuadriceps)
            {
                // The femoral shaft runs obliquely from the trochanters to the knee.
                float outward = part == BodyPart.LeftQuadriceps ? 1f : -1f;
                Vector2 hip = BonePoint(part, 0f), knee = BonePoint(part, 1f);
                center = Along(hip, knee, outward, .52f, 11.2f * _u);
                tangent = (Along(hip, knee, outward, .72f, 6.3f * _u) - Along(hip, knee, outward, .466f, 12.55f * _u)).normalized;
                halfWidth = metric * .065f;
            }
            else if (part == BodyPart.LeftForearm || part == BodyPart.RightForearm)
            {
                // Radius and ulna cross near the middle of the forearm: one break spans both.
                Vector2 elbow = BonePoint(part, 0f), wrist = BonePoint(part, 1f);
                center = Vector2.Lerp(elbow, wrist, .52f);
                tangent = (wrist - elbow).normalized;
                halfWidth = metric * .034f;
            }
            else if (part == BodyPart.LeftShin || part == BodyPart.RightShin)
            {
                Vector2 knee = BonePoint(part, 0f), ankle = BonePoint(part, 1f);
                center = Vector2.Lerp(knee, ankle, .52f);
                tangent = (ankle - knee).normalized;
                halfWidth = metric * .05f;
            }
            Vector2 normal = new Vector2(-tangent.y, tangent.x);
            halfWidth = Mathf.Max(halfWidth + _unitsPerPixel, 2.0f * _unitsPerPixel);
            Vector2 a = center - normal * halfWidth - tangent * .80f * _unitsPerPixel;
            Vector2 b = center - normal * halfWidth * .16f + tangent * 1.10f * _unitsPerPixel;
            Vector2 c = center + normal * halfWidth * .22f - tangent * .95f * _unitsPerPixel;
            Vector2 d = center + normal * halfWidth + tangent * .65f * _unitsPerPixel;
            Color edge = supported ? new Color(.78f, .84f, .65f, .97f) : new Color(.98f, .90f, .72f, 1f);
            float gap = supported ? 2.25f : 3.25f;
            Color interior = new Color(.035f, .033f, .039f, 1f);
            InjuryLine(a, b, interior, gap); InjuryLine(b, c, interior, gap); InjuryLine(c, d, interior, gap);
            Vector2 edgeOffset = tangent * (supported ? .95f : 1.42f) * _unitsPerPixel;
            InjuryLine(a + edgeOffset, b + edgeOffset, edge, 1.1f);
            InjuryLine(b + edgeOffset, c + edgeOffset, edge, 1.1f);
            InjuryLine(c - edgeOffset, d - edgeOffset, edge, 1.05f);
            if (!supported)
            {
                Color fissure = new Color(.14f, .11f, .11f, .96f);
                InjuryLine(b, b + tangent * 5f * _unitsPerPixel + normal * .55f * _unitsPerPixel,
                    fissure, 1.2f);
                InjuryLine(c, c - tangent * 3.8f * _unitsPerPixel - normal * .45f * _unitsPerPixel,
                    fissure, 1.05f);
            }
        }

        private void DrawSystemicState()
        {
            Rect head = CraniumRect.width > 0f ? CraniumRect : Sub(R(BodyPart.Head), .20f, .28f, .60f, .70f);
            Rect chest = ThoraxRect.width > 0f ? ThoraxRect : R(BodyPart.Chest);
            Rect abdomen = AbdomenRect.width > 0f ? AbdomenRect : R(BodyPart.Stomach);
            Rect pelvis = R(BodyPart.Pelvis);
            if (State.Has(HealthGadgetKind.BreathingDifficulty))
            {
                for (int side = -1; side <= 1; side += 2)
                {
                    TissuePatch(P(chest, .5f + side * .22f, .55f), chest.width * .16f, chest.height * .30f,
                        new Color(.56f, .16f, .23f, .56f));
                    CurveLine(chest, .5f + side * .12f, .74f, .5f + side * .29f, .78f,
                        .5f + side * .34f, .48f, .5f + side * .28f, .34f,
                        new Color(.86f, .40f, .38f, .82f), InjuryStroke(1.2f));
                }
            }
            if (State.Has(HealthGadgetKind.Immobilized))
                TissuePatch(P(pelvis, .5f, .35f), pelvis.width * .23f, pelvis.height * .14f, Alpha(_injury, .12f));
            for (int kindIndex = 0; kindIndex <= (int)HealthGadgetKind.AntibioticTreatment; kindIndex++)
            {
                HealthGadgetKind kind = (HealthGadgetKind)kindIndex;
                if (!SystemicVisible(kind)) continue;
                DrawSystemicTissue(kind, head, chest, abdomen);
            }
        }

        private bool SystemicVisible(HealthGadgetKind kind)
        {
            if (!State.Has(kind)) return false;
            switch (kind)
            {
                case HealthGadgetKind.Hunger:
                case HealthGadgetKind.Thirst: return State.Value(kind) >= 0f && State.Value(kind) < .35f;
                case HealthGadgetKind.Radiation:
                case HealthGadgetKind.Cold: return State.Value(kind) > .015f;
                case HealthGadgetKind.Overload: return State.Value(kind) > .5f;
                case HealthGadgetKind.Blood: return State.Blood01 < .9f;
                case HealthGadgetKind.Fatigue:
                case HealthGadgetKind.Drunk:
                case HealthGadgetKind.Hangover:
                case HealthGadgetKind.Shock:
                case HealthGadgetKind.Txa:
                case HealthGadgetKind.ColdIllness:
                case HealthGadgetKind.AntibioticTreatment: return true;
                default: return false;
            }
        }

        private void DrawSystemicTissue(HealthGadgetKind kind, Rect head, Rect chest, Rect abdomen)
        {
            switch (kind)
            {
                case HealthGadgetKind.Hunger:
                    CurveLine(abdomen, .68f, .86f, .62f, .69f, .84f, .71f, .74f, .58f, Alpha(_bone, .45f), .5f);
                    CurveLine(abdomen, .68f, .82f, .69f, .70f, .78f, .72f, .74f, .61f, Alpha(_dark, .6f), .7f);
                    break;
                case HealthGadgetKind.Thirst:
                    for (int side = 0; side < 2; side++)
                    {
                        Rect forearm = R((BodyPart)(8 + side));
                        Vector2 center = TissuePoint((BodyPart)(8 + side));
                        for (int line = 0; line < 3; line++)
                        {
                            Vector2 start = center + new Vector2((line - 1) * 2f * _unit, forearm.height * .05f);
                            Line(start, start + new Vector2(.7f, -3.5f) * _unit, Alpha(_bone, .23f), .4f);
                        }
                    }
                    break;
                case HealthGadgetKind.Radiation:
                    for (int i = 0; i < 8; i++)
                    {
                        float x = .27f + (i % 3) * .19f;
                        float y = .25f + i / 3 * .20f;
                        Ellipse(P(abdomen, x, y), .55f * _unit, .8f * _unit,
                            Alpha(_injury, .16f + State.Value(kind) * .16f), Color.clear, 0f, 6);
                    }
                    break;
                case HealthGadgetKind.Cold:
                    for (int side = 0; side < 2; side++)
                    {
                        DrawColdTissue((BodyPart)(8 + side));
                        DrawColdTissue((BodyPart)(16 + side));
                    }
                    break;
                case HealthGadgetKind.Overload:
                    for (int i = 0; i < 4; i++)
                    {
                        Vector2 center = P(chest, .5f, .68f - i * .13f);
                        Line(center + Vector2.left * 2.4f * _unit, center + Vector2.right * 2.4f * _unit,
                            Alpha(_injury, .4f), .55f);
                    }
                    break;
                case HealthGadgetKind.Blood:
                    DrawVessels(Mathf.Clamp01(State.Blood01));
                    break;
                case HealthGadgetKind.Fatigue:
                    for (int side = 0; side < 2; side++)
                    {
                        TissuePatch(BonePoint((BodyPart)(14 + side), .5f), 3.6f * _unit, 4.4f * _unit, Alpha(_dark, .18f));
                        TissuePatch(BonePoint((BodyPart)(6 + side), .90f), 3f * _unit, 3.6f * _unit, Alpha(_dark, .18f));
                    }
                    break;
                case HealthGadgetKind.Drunk:
                    CurveLine(head, .43f, .32f, .48f, .41f, .56f, .22f, .53f, .13f, Alpha(_organ, .45f), .55f);
                    CurveLine(head, .47f, .32f, .52f, .41f, .60f, .22f, .57f, .13f, Alpha(_organ, .25f), .45f);
                    break;
                case HealthGadgetKind.Hangover:
                    CurveLine(head, .26f, .79f, .36f, .83f, .42f, .79f, .47f, .83f, Alpha(_injury, .45f), .5f);
                    CurveLine(head, .54f, .83f, .61f, .79f, .68f, .84f, .75f, .79f, Alpha(_injury, .45f), .5f);
                    break;
                case HealthGadgetKind.Shock:
                    TissuePatch(P(chest, .54f, .54f), chest.width * .12f, chest.height * .12f, Alpha(_dark, .21f));
                    Line(P(chest, .53f, .66f), P(chest, .52f, .59f), Alpha(_injury, .5f), .7f);
                    Line(P(chest, .52f, .54f), P(chest, .51f, .42f), Alpha(_injury, .5f), .7f);
                    break;
                case HealthGadgetKind.Txa:
                    CurveLine(chest, .53f, .57f, .56f, .38f, .50f, .20f, .50f, .04f, Alpha(_care, .34f), .65f);
                    Line(P(abdomen, .5f, .96f), P(abdomen, .50f, .23f), Alpha(_care, .27f), .55f);
                    break;
                case HealthGadgetKind.ColdIllness:
                    Vector2 throat = P(chest, .5f, .96f);
                    Line(throat + new Vector2(-1f, 4f) * _unit, throat + new Vector2(-.7f, -3f) * _unit, Alpha(_injury, .4f), .7f);
                    Line(throat + new Vector2(1f, 4f) * _unit, throat + new Vector2(.7f, -3f) * _unit, Alpha(_injury, .4f), .7f);
                    break;
                case HealthGadgetKind.AntibioticTreatment:
                    for (int i = 0; i < State.Parts.Length; i++)
                    {
                        if (!State.Parts[i].Infected) continue;
                        Rect region = R((BodyPart)i);
                        TissuePatch(TissuePoint((BodyPart)i), region.width * .18f, Mathf.Min(region.height * .13f, region.width * .22f),
                            Alpha(_care, .09f));
                    }
                    break;
            }
        }

        private void DrawColdTissue(BodyPart part)
        {
            Rect rect = R(part);
            Vector2 direction = BoneDirection(part);
            Vector2 normal = new Vector2(-direction.y, direction.x);
            Color cold = new Color(.57f, .61f, .63f, .16f + State.Value(HealthGadgetKind.Cold) * .15f);
            for (int i = 0; i < 3; i++)
            {
                Vector2 center = BonePoint(part, .68f + i * .07f) + normal * rect.width * .28f;
                Line(center - direction * 1.5f * _unit, center + direction * 1.7f * _unit + normal * .5f * _unit, cold, .5f);
            }
        }

        private void DrawVessels(float blood)
        {
            Rect chest = ThoraxRect.width > 0f ? ThoraxRect : R(BodyPart.Chest);
            Rect pelvis = R(BodyPart.Pelvis);
            Color vessel = new Color(.51f, .37f, .37f, .27f + .30f * blood);
            Vector2 origin = P(chest, .54f, .57f);
            Vector2 lower = P(pelvis, .50f, .60f);
            Line(origin, Vector2.Lerp(origin, lower, blood), vessel, 1.4f);
            for (int side = 0; side < 2; side++)
            {
                Vector2 shoulder = P(R((BodyPart)(4 + side)), .5f, .61f);
                Vector2 wrist = P(R((BodyPart)(8 + side)), .5f, .13f);
                Line(origin, Vector2.Lerp(origin, shoulder, blood), vessel, .9f);
                Line(shoulder, Vector2.Lerp(shoulder, wrist, blood), vessel, .85f);
                Vector2 thigh = P(R((BodyPart)(12 + side)), .5f, .84f);
                Vector2 ankle = P(R((BodyPart)(16 + side)), .5f, .1f);
                Line(lower, Vector2.Lerp(lower, thigh, blood), vessel, 1f);
                Line(thigh, Vector2.Lerp(thigh, ankle, blood), vessel, .9f);
            }
        }

        private void DrawSplint(BodyPart part, Rect rect)
        {
            Vector2 axis = BoneDirection(part);
            Vector2 start = BonePoint(part, .14f), end = BonePoint(part, .87f);
            if (part == BodyPart.LeftShoulder || part == BodyPart.RightShoulder)
            {
                BodyPart upperArm = part == BodyPart.LeftShoulder ? BodyPart.LeftBiceps : BodyPart.RightBiceps;
                axis = BoneDirection(upperArm);
                Vector2 shoulderCenter = TissuePoint(part);
                start = shoulderCenter - axis * rect.height * .25f;
                end = shoulderCenter + axis * rect.height * .30f;
            }
            Vector2 normal = new Vector2(-axis.y, axis.x);
            float halfWidth = rect.width * .32f;
            float plateWidth = Mathf.Min(rect.width * .17f, 4.2f * _unitsPerPixel);
            Vector2 center = (start + end) * .5f + normal * halfWidth * .55f;
            float halfLength = Vector2.Distance(start, end) * .50f;
            DevicePanel(center, axis, plateWidth, halfLength,
                new Color(.28f, .43f, .44f, .92f), new Color(.67f, .77f, .73f, .98f), 1.1f);
            InjuryLine(center - axis * halfLength - normal * plateWidth * .78f,
                center + axis * halfLength - normal * plateWidth * .78f,
                new Color(.87f, .59f, .33f, .94f), 1.6f);
            Vector2 upperStrap = Vector2.Lerp(start, end, .25f), lowerStrap = Vector2.Lerp(start, end, .75f);
            DrawSplintStrap(upperStrap, axis, halfWidth);
            DrawSplintStrap(lowerStrap, axis, halfWidth);
        }

        private void DrawSplintStrap(Vector2 center, Vector2 axis, float halfWidth)
        {
            DevicePanel(center, axis, halfWidth, 2.0f * _unitsPerPixel,
                new Color(.67f, .67f, .55f, .95f), new Color(.88f, .87f, .74f, .99f), .85f);
            Vector2 normal = new Vector2(-axis.y, axis.x);
            InjuryLine(center - normal * halfWidth * .9f + axis * .9f * _unitsPerPixel,
                center + normal * halfWidth * .9f + axis * .9f * _unitsPerPixel,
                new Color(.30f, .35f, .31f, .70f), .75f);
        }

        private Vector2 DeviceAxis(BodyPart part)
        {
            if (part == BodyPart.LeftShoulder) return BoneDirection(BodyPart.LeftBiceps);
            if (part == BodyPart.RightShoulder) return BoneDirection(BodyPart.RightBiceps);
            return BoneDirection(part);
        }

        private void DrawTourniquet(BodyPart part, Rect rect, bool elastic)
        {
            Vector2 axis = DeviceAxis(part), normal = new Vector2(-axis.y, axis.x);
            Vector2 center = TissuePoint(part) - axis * rect.height * .16f;
            float halfWidth = rect.width * .43f;
            if (part == BodyPart.LeftShoulder || part == BodyPart.RightShoulder)
            {
                BodyPart upperArm = part == BodyPart.LeftShoulder ? BodyPart.LeftBiceps : BodyPart.RightBiceps;
                center = BonePoint(upperArm, .28f);
                halfWidth = R(upperArm).width * .34f;
            }
            float halfHeight = 3.6f * _unitsPerPixel;
            Color strap = elastic ? new Color(.55f, .48f, .32f, .98f) : new Color(.10f, .13f, .14f, .99f);
            Color edge = elastic ? new Color(.87f, .78f, .53f, .97f) : new Color(.66f, .72f, .69f, .98f);
            DevicePanel(center, axis, halfWidth, halfHeight, strap, edge, 1.1f);
            if (elastic)
            {
                for (int fold = 0; fold < 2; fold++)
                {
                    Vector2 offset = normal * halfWidth * (fold == 0 ? -.28f : .27f);
                    InjuryLine(center + offset - normal * halfWidth * .22f - axis * halfHeight * .7f,
                        center + offset + normal * halfWidth * .22f + axis * halfHeight * .7f,
                        new Color(.76f, .67f, .43f, .95f), 1.4f);
                }
                DevicePanel(center + normal * halfWidth * .45f + axis * halfHeight * .9f,
                    (normal + axis * .6f).normalized, 2f * _unitsPerPixel, 3.6f * _unitsPerPixel,
                    strap, edge, .8f);
            }
            else
            {
                DevicePanel(center, axis, 4f * _unitsPerPixel, 4.8f * _unitsPerPixel,
                    new Color(.23f, .28f, .28f, 1f), edge, 1.0f);
                Vector2 rod = (normal + axis * .34f).normalized;
                DevicePanel(center - axis * 1f * _unitsPerPixel, rod,
                    1.25f * _unitsPerPixel, 7.0f * _unitsPerPixel,
                    new Color(.81f, .82f, .71f, 1f), new Color(.16f, .20f, .20f, 1f), .85f);
                InjuryLine(center - axis * 3.4f * _unitsPerPixel - normal * 2f * _unitsPerPixel,
                    center - axis * 3.4f * _unitsPerPixel + normal * 2f * _unitsPerPixel,
                    new Color(.78f, .36f, .25f, .98f), 1.7f);
            }
        }

        private void DrawCompressionDevice(BodyPart part, Rect rect)
        {
            Vector2 axis = DeviceAxis(part), normal = new Vector2(-axis.y, axis.x);
            Vector2 center = TissuePoint(part) - axis * rect.height * .24f;
            DevicePanel(center, axis, rect.width * .46f, 4.5f * _unitsPerPixel,
                new Color(.16f, .22f, .22f, .98f), new Color(.66f, .73f, .68f, .98f), 1.1f);
            DevicePanel(center, axis, 5f * _unitsPerPixel, 6f * _unitsPerPixel,
                new Color(.35f, .40f, .34f, 1f), new Color(.80f, .82f, .67f, 1f), 1.1f);
            Ellipse(center, 3.0f * _unitsPerPixel, 3.0f * _unitsPerPixel,
                new Color(.12f, .17f, .17f, 1f), new Color(.79f, .81f, .70f, 1f), InjuryStroke(1f), 12);
            InjuryLine(center - normal * 4.5f * _unitsPerPixel, center + normal * 4.5f * _unitsPerPixel,
                new Color(.88f, .85f, .67f, 1f), 1.7f);
            InjuryLine(center, center - axis * 6f * _unitsPerPixel,
                new Color(.79f, .80f, .68f, 1f), 1.8f);
        }

        private void DrawHaemostaticPacking(Vector2 center, Rect rect)
        {
            float halfWidth = Mathf.Min(rect.width * .24f, 6.5f * _unitsPerPixel);
            float halfHeight = Mathf.Min(rect.height * .12f, 5f * _unitsPerPixel);
            Vector2 axis = new Vector2(.23f, -.97f);
            Vector2 normal = new Vector2(-axis.y, axis.x);
            DevicePanel(center, axis, halfWidth, halfHeight,
                new Color(.70f, .66f, .49f, .97f), new Color(.92f, .88f, .68f, .99f), 1.0f);
            for (int fold = -1; fold <= 1; fold++)
            {
                Vector2 point = center + axis * halfHeight * fold * .45f;
                InjuryLine(point - normal * halfWidth * .7f, point + normal * halfWidth * .7f,
                    new Color(.38f, .34f, .24f, .75f), .85f);
            }
        }

        private void DrawChestSeal(Vector2 center, Rect rect)
        {
            float halfWidth = Mathf.Min(rect.width * .20f, 14f * _unitsPerPixel);
            float halfHeight = Mathf.Min(rect.height * .19f, 15f * _unitsPerPixel);
            DevicePanel(center, Vector2.down, halfWidth, halfHeight,
                new Color(.51f, .65f, .61f, .30f), new Color(.87f, .91f, .79f, .94f), 1.2f);
            DevicePanel(center + new Vector2(halfWidth * .70f, halfHeight * .93f), Vector2.down,
                3.1f * _unitsPerPixel, 2.5f * _unitsPerPixel,
                new Color(.72f, .25f, .20f, .98f), new Color(.94f, .55f, .38f, .98f), .85f);
            Ellipse(center, 3.2f * _unitsPerPixel, 3.2f * _unitsPerPixel,
                new Color(.15f, .19f, .19f, .95f), new Color(.86f, .89f, .76f, 1f), InjuryStroke(1f), 12);
            for (int vent = 0; vent < 3; vent++)
            {
                float angle = -.5f + vent * Mathf.PI * 2f / 3f;
                Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
                InjuryLine(center + direction * 3.5f * _unitsPerPixel,
                    center + direction * 7.0f * _unitsPerPixel,
                    new Color(.82f, .89f, .79f, .89f), 1.4f);
            }
        }

        private void DrawPelvicBinder(Rect rect)
        {
            Vector2 center = P(rect, .5f, .43f);
            float halfWidth = rect.width * .43f;
            float halfHeight = Mathf.Min(rect.height * .12f, 7f * _unitsPerPixel);
            DevicePanel(center, Vector2.down, halfWidth, halfHeight,
                new Color(.28f, .36f, .32f, .98f), new Color(.74f, .78f, .65f, 1f), 1.1f);
            InjuryLine(center + new Vector2(-halfWidth * .94f, halfHeight * .45f),
                center + new Vector2(halfWidth * .94f, halfHeight * .45f),
                new Color(.60f, .66f, .53f, .87f), 1.3f);
            DevicePanel(center, Vector2.down, 5.2f * _unitsPerPixel, halfHeight * 1.13f,
                new Color(.12f, .19f, .18f, 1f), new Color(.86f, .87f, .71f, 1f), 1.2f);
            InjuryLine(center + Vector2.left * 2.8f * _unitsPerPixel,
                center + Vector2.right * 2.8f * _unitsPerPixel,
                new Color(.84f, .85f, .71f, 1f), 1.4f);
        }

        private void DevicePanel(Vector2 center, Vector2 axis, float halfWidth, float halfHeight,
            Color fill, Color edge, float stroke)
        {
            Vector2 normal = new Vector2(-axis.y, axis.x);
            float corner = Mathf.Min(halfWidth, halfHeight) * .30f;
            BeginContour(center - normal * (halfWidth - corner) - axis * halfHeight);
            _shape[_shapeCount++] = center + normal * (halfWidth - corner) - axis * halfHeight;
            _shape[_shapeCount++] = center + normal * halfWidth - axis * (halfHeight - corner);
            _shape[_shapeCount++] = center + normal * halfWidth + axis * (halfHeight - corner);
            _shape[_shapeCount++] = center + normal * (halfWidth - corner) + axis * halfHeight;
            _shape[_shapeCount++] = center - normal * (halfWidth - corner) + axis * halfHeight;
            _shape[_shapeCount++] = center - normal * halfWidth + axis * (halfHeight - corner);
            _shape[_shapeCount++] = center - normal * halfWidth - axis * (halfHeight - corner);
            Shape(fill, edge, InjuryStroke(stroke));
        }

        private void DrawLaceration(Vector2 center, float length, LacerationType type)
        {
            Vector2 start = center + new Vector2(-length * .78f, length * .45f);
            Vector2 end = center + new Vector2(length * .78f, -length * .45f);
            Vector2 direction = (end - start).normalized, normal = new Vector2(-direction.y, direction.x);
            if (type == LacerationType.Open)
            {
                float halfWidth = 2.2f * _unitsPerPixel;
                TissuePatch(center, length * 1.05f, 6f * _unitsPerPixel, new Color(.63f, .15f, .18f, .64f));
                BeginContour(start);
                _shape[_shapeCount++] = Vector2.Lerp(start, end, .18f) + normal * halfWidth * .65f;
                _shape[_shapeCount++] = Vector2.Lerp(start, end, .34f) + normal * halfWidth * 1.10f;
                _shape[_shapeCount++] = Vector2.Lerp(start, end, .53f) + normal * halfWidth * .74f;
                _shape[_shapeCount++] = Vector2.Lerp(start, end, .74f) + normal * halfWidth * .90f;
                _shape[_shapeCount++] = end;
                _shape[_shapeCount++] = Vector2.Lerp(start, end, .79f) - normal * halfWidth * .75f;
                _shape[_shapeCount++] = Vector2.Lerp(start, end, .58f) - normal * halfWidth * 1.20f;
                _shape[_shapeCount++] = Vector2.Lerp(start, end, .39f) - normal * halfWidth * .68f;
                _shape[_shapeCount++] = Vector2.Lerp(start, end, .20f) - normal * halfWidth * .84f;
                Shape(new Color(.39f, .055f, .10f, .99f), new Color(.93f, .54f, .42f, .98f), InjuryStroke(1.15f));
                InjuryLine(Vector2.Lerp(start, end, .16f), center - normal * .3f * _unitsPerPixel,
                    new Color(.055f, .018f, .029f, 1f), 1.8f);
                InjuryLine(center - normal * .3f * _unitsPerPixel, Vector2.Lerp(start, end, .84f),
                    new Color(.055f, .018f, .029f, 1f), 1.8f);
                InjuryLine(Vector2.Lerp(start, end, .22f) + normal * halfWidth * .68f,
                    Vector2.Lerp(start, end, .43f) + normal * halfWidth * .84f,
                    new Color(.99f, .72f, .57f, .93f), .95f);
            }
            else
            {
                TissuePatch(center, length, 3.6f * _unitsPerPixel, new Color(.55f, .23f, .24f, .47f));
                InjuryLine(start, end, new Color(.49f, .12f, .16f, .98f), 1.6f);
                if (type == LacerationType.Glued)
                {
                    InjuryLine(start + normal * .65f * _unitsPerPixel, end + normal * .65f * _unitsPerPixel,
                        new Color(.66f, .77f, .70f, .55f), 3.8f);
                    InjuryLine(start + normal * 1.9f * _unitsPerPixel, end + normal * 1.9f * _unitsPerPixel,
                        new Color(.87f, .94f, .82f, .89f), 1.0f);
                    return;
                }
                for (int i = 1; i <= 4; i++)
                {
                    Vector2 stitch = Vector2.Lerp(start, end, i / 5f);
                    Vector2 a = stitch - normal * 2.4f * _unitsPerPixel - direction * .5f * _unitsPerPixel;
                    Vector2 b = stitch + normal * 2.4f * _unitsPerPixel + direction * .5f * _unitsPerPixel;
                    InjuryLine(a, b, new Color(.10f, .23f, .24f, 1f), 1.8f);
                    InjuryLine(a + direction * .4f * _unitsPerPixel, b + direction * .4f * _unitsPerPixel,
                        new Color(.77f, .89f, .80f, .98f), .85f);
                }
            }
        }

    }
}
