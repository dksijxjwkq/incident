using UnityEngine;

namespace K_Incident.Core.Inventory
{
    [CreateAssetMenu(fileName = "HealthVisualStyle", menuName = "Incident/UI/Health Visual Style")]
    public sealed class K_HealthVisualStyle : ScriptableObject
    {
        [SerializeField, Tooltip("Общая гамма обеих кукол и индикаторов. 0 — критическое состояние, 1 — здоровое.")]
        private Gradient _conditionColors = CreateDefaultGradient();
        [SerializeField, Min(.01f), Tooltip("Время плавного перехода после изменения состояния. Используется время интерфейса.")]
        private float _transitionSeconds = .35f;
        public float TransitionSeconds => float.IsNaN(_transitionSeconds) || float.IsInfinity(_transitionSeconds) ? .35f : Mathf.Max(.01f, _transitionSeconds);
        public Color Evaluate(float healthyFraction)
        {
            if (float.IsNaN(healthyFraction) || float.IsInfinity(healthyFraction)) healthyFraction = 1f;
            Color result = (_conditionColors ?? (_conditionColors = CreateDefaultGradient())).Evaluate(Mathf.Clamp01(healthyFraction));
            result.a = 1f;
            return result;
        }
        public static Gradient CreateDefaultGradient()
        {
            var result = new Gradient();
            result.SetKeys(new[] {
                new GradientColorKey(Rgb(0x30252A),0f),new GradientColorKey(Rgb(0x542F36),.25f),
                new GradientColorKey(Rgb(0x765149),.5f),new GradientColorKey(Rgb(0x918271),.75f),
                new GradientColorKey(Rgb(0x969A95),1f)
            },new[]{new GradientAlphaKey(1f,0f),new GradientAlphaKey(1f,1f)});
            result.mode = GradientMode.Blend;
            return result;
        }
        private static Color Rgb(int value) => new Color(((value>>16)&255)/255f,((value>>8)&255)/255f,(value&255)/255f,1f);
    }
}
