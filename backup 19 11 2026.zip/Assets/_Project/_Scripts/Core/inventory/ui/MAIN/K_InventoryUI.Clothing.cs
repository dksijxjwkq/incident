using System.Collections.Generic;
using UnityEngine;
using TMPro;

namespace K_Incident.Core.Inventory
{
    public partial class K_InventoryUI
    {
        [Header("Одежда")]
        [SerializeField, Tooltip("Слот шапки. Работает независимо от открытия вкладки снаряжения.")]
        private K_EquipmentSlotUI _hatSlot;
        [SerializeField, Tooltip("Слот куртки. Куртка и бронежилет занимают отдельные места.")]
        private K_EquipmentSlotUI _jacketSlot;
        [SerializeField, Tooltip("Слот штанов.")]
        private K_EquipmentSlotUI _pantsSlot;
        [SerializeField, Tooltip("Слот пары обуви. Состояние левой и правой ступни хранится раздельно.")]
        private K_EquipmentSlotUI _footwearSlot;
        [SerializeField, Tooltip("Отдельная строка уведомлений в колонке одежды: несовместимость слоёв или нехватка места. Старые панели не изменяются.")]
        private TextMeshProUGUI _clothingFeedbackText;
        private float _clothingFeedbackUntil;

        [System.NonSerialized] private K_EquipmentSlotUI[] _clothingSlotCache;

        public IEnumerable<K_EquipmentSlotUI> ClothingSlots
        {
            get
            {
                if (_clothingSlotCache == null || _clothingSlotCache.Length != 4 || _clothingSlotCache[0] != _hatSlot ||
                    _clothingSlotCache[1] != _jacketSlot || _clothingSlotCache[2] != _pantsSlot ||
                    _clothingSlotCache[3] != _footwearSlot)
                    _clothingSlotCache = new[] { _hatSlot, _jacketSlot, _pantsSlot, _footwearSlot };
                return _clothingSlotCache;
            }
        }

        public K_EquipmentSlotUI GetClothingSlot(ClothingSlotKind kind)
        {
            switch (kind)
            {
                case ClothingSlotKind.Hat: return _hatSlot;
                case ClothingSlotKind.Jacket: return _jacketSlot;
                case ClothingSlotKind.Pants: return _pantsSlot;
                case ClothingSlotKind.Footwear: return _footwearSlot;
                default: return null;
            }
        }

        public InventoryItem GetClothingItem(ClothingSlotKind kind) => GetClothingSlot(kind)?.EquippedItem;

        internal K_EquipmentSlotUI[] GetAuthoredEquipmentSlots() => new[]
        {
            _primarySlot1, _primarySlot2, _pistolSlot, _meleeSlot, _backpackSlot,
            _armorSlot, _headgearSlot, _hatSlot, _jacketSlot, _pantsSlot, _footwearSlot
        };

        private void SetupClothingSlots()
        {
            _hatSlot?.Initialize(this, EquipmentSlotType.Hat);
            _jacketSlot?.Initialize(this, EquipmentSlotType.Jacket);
            _pantsSlot?.Initialize(this, EquipmentSlotType.Pants);
            _footwearSlot?.Initialize(this, EquipmentSlotType.Footwear);
        }

        /// <summary>Validates only the affected pair, without moving or discarding either item.</summary>
        public bool CanEquipItemWithClothing(InventoryItem candidate, EquipmentSlotType destination, out string reason)
        {
            reason = string.Empty;
            if (candidate == null) return true;
            if (destination == EquipmentSlotType.Hat || destination == EquipmentSlotType.HeadGear)
            {
                var hat = destination == EquipmentSlotType.Hat ? candidate : GetClothingItem(ClothingSlotKind.Hat);
                var helmet = destination == EquipmentSlotType.HeadGear ? candidate : _headgearSlot?.EquippedItem;
                if (helmet != null && hat?.Data?.Clothing != null && !hat.Data.Clothing.AllowsHelmet)
                {
                    reason = "Эта шапка не помещается под шлемом. Сначала снимите шапку или шлем.";
                    return false;
                }
            }
            if (destination == EquipmentSlotType.Jacket || destination == EquipmentSlotType.BodyArmor)
            {
                var jacket = destination == EquipmentSlotType.Jacket ? candidate : GetClothingItem(ClothingSlotKind.Jacket);
                var armor = destination == EquipmentSlotType.BodyArmor ? candidate : _armorSlot?.EquippedItem;
                if (armor != null && jacket?.Data?.Clothing != null && !jacket.Data.Clothing.AllowsBodyArmor)
                {
                    reason = "Эта куртка не помещается поверх бронежилета. Сначала снимите куртку или бронежилет.";
                    return false;
                }
            }
            return true;
        }

        public bool CanEquipFromContextWithClothing(InventoryItem item, out string reason)
        {
            reason = string.Empty;
            if (!InventoryValidationService.TryDetermineEquipSlotType(item, out var type))
            {
                reason = "Для этого предмета нет подходящего слота.";
                return false;
            }
            return CanEquipItemWithClothing(item, type, out reason);
        }

        public void ShowClothingEquipRefusal(string reason)
        {
            if (string.IsNullOrEmpty(reason)) return;
            if (_clothingFeedbackText != null)
            {
                _clothingFeedbackText.text = reason;
                _clothingFeedbackText.gameObject.SetActive(true);
                _clothingFeedbackUntil = Time.unscaledTime + 3.5f;
            }
            Debug.LogWarning("[Clothing] " + reason);
        }

        private void TickClothingFeedback()
        {
            if (_clothingFeedbackText != null && _clothingFeedbackText.gameObject.activeSelf &&
                Time.unscaledTime >= _clothingFeedbackUntil)
                _clothingFeedbackText.gameObject.SetActive(false);
        }

        public static bool IsClothingRelatedItem(InventoryItem item) => item?.Data != null &&
            (item.Type == ItemType.Clothing || item.Type == ItemType.Armor);

        public static string EquipmentRefusalText(string reason)
        {
            if (string.IsNullOrEmpty(reason)) return "Не удалось переместить предмет.";
            string lower = reason.ToLowerInvariant();
            if (lower.Contains("space") || lower.Contains("placement") || lower.Contains("no room") || lower.Contains("full"))
                return "Не хватает места для снятого предмета. Освободите место в инвентаре.";
            if (lower.Contains("lock") || lower.Contains("busy") || lower.Contains("transaction"))
                return "Предмет сейчас используется. Дождитесь окончания действия.";
            return "Не удалось переместить предмет в этот слот.";
        }
    }
}
