using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

namespace K_Incident.Core.Inventory
{
    [DisallowMultipleComponent]
    [AddComponentMenu("INCIDENT/UI/Защита одежды от холода")]
    public sealed class K_ClothingProtectionIndicator : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        [SerializeField, Tooltip("Реальная теплозащита персонажа при текущей температуре.")]
        private K_ClothingSystem _clothing;
        [SerializeField, Tooltip("Заполнение шкалы защиты от холода от 0 до 100 процентов.")]
        private UnityEngine.UI.Image _fill;
        [SerializeField, Tooltip("Числовое значение защиты от холода.")]
        private TextMeshProUGUI _value;
        [SerializeField, Tooltip("Необязательная подпись общей шкалы одежды.")]
        private TextMeshProUGUI _caption;
        [SerializeField, Tooltip("Необязательная готовая панель пояснения при наведении.")]
        private RectTransform _tooltipRoot;
        [SerializeField, Tooltip("Защита от холода при текущей температуре. 100% — холод перекрыт; меньшее значение само по себе не означает немедленную опасность.")]
        private TextMeshProUGUI _tooltipText;
        private K_ClothingSystem _subscribed;
        private float _nextRefresh;

        private void OnEnable() { Connect(); Refresh(); }
        private void OnDisable()
        {
            if (_subscribed != null) _subscribed.OnChanged -= Refresh;
            _subscribed = null;
            if (_tooltipRoot != null) _tooltipRoot.gameObject.SetActive(false);
        }
        private void Update()
        {
            if (Time.unscaledTime < _nextRefresh) return;
            _nextRefresh = Time.unscaledTime + .25f;
            Connect(); Refresh();
        }
        private void Connect()
        {
            if (_clothing == null) _clothing = FindFirstObjectByType<K_ClothingSystem>(FindObjectsInactive.Include);
            if (_subscribed == _clothing) return;
            if (_subscribed != null) _subscribed.OnChanged -= Refresh;
            _subscribed = _clothing;
            if (_subscribed != null) _subscribed.OnChanged += Refresh;
        }
        public void Refresh()
        {
            bool available = _clothing != null && _clothing.isActiveAndEnabled;
            float protection = available ? Mathf.Clamp01(_clothing.Protection01) : 0f;
            if (_fill != null) _fill.fillAmount = protection;
            if (_value != null) _value.text = available ? ClothingPresentation.Percent(protection) + "%" : "—";
            if (_caption != null) _caption.text = "Защита от холода";
        }
        public void OnPointerEnter(PointerEventData eventData)
        {
            if (_tooltipText != null)
                _tooltipText.text = "Защита от холода при нынешней температуре.\nПри 100% холод не накапливается. " +
                    "Меньшее значение показывает неполную защиту; скорость охлаждения зависит от температуры.";
            if (_tooltipRoot != null) _tooltipRoot.gameObject.SetActive(true);
        }
        public void OnPointerExit(PointerEventData eventData)
        {
            if (_tooltipRoot != null) _tooltipRoot.gameObject.SetActive(false);
        }
    }
}
