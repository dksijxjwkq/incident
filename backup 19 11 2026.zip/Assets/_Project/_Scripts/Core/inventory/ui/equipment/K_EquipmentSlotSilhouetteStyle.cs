using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>Appearance controls for the separate empty-slot image only.</summary>
    [ExecuteAlways]
    [DisallowMultipleComponent]
    [RequireComponent(typeof(Image))]
    [AddComponentMenu("INCIDENT/UI/Настройки силуэта слота")]
    public sealed class K_EquipmentSlotSilhouetteStyle : MonoBehaviour
    {
        [SerializeField, InspectorName("Цвет и прозрачность"), Tooltip("Оттенок новой картинки. Белый сохраняет исходный цвет PNG; канал A задаёт прозрачность. Старые Empty Slot Color/Brightness не используются.")]
        private Color _color = new Color(1f, 1f, 1f, .55f);

        [SerializeField, InspectorName("Размер до поворота"), Tooltip("Ширина и высота Image в единицах Canvas до его поворота. У вертикальной винтовки с поворотом −90° X отвечает за длину по высоте. Пропорции самого рисунка сохраняет Image → Preserve Aspect.")]
        private Vector2 _size = new Vector2(100f, 100f);

        [System.NonSerialized] private Image _image;
        [System.NonSerialized] private RectTransform _rect;

        public Color TintColor
        {
            get => _color;
            set { _color = SafeColor(value); ApplyNow(); }
        }

        public Vector2 Size
        {
            get => _size;
            set { _size = SafeSize(value); ApplyNow(); }
        }

        private void OnEnable() => ApplyNow();
        private void LateUpdate() => ApplyNow();

        private void OnValidate()
        {
            // Canvas/RectTransform changes wait for LateUpdate, outside validation.
            _color = SafeColor(_color);
            _size = SafeSize(_size);
        }

        private void Reset()
        {
            Cache();
            if (_image != null) _color = SafeColor(_image.color);
            if (_rect != null) _size = SafeSize(_rect.rect.size);
        }

        public void ApplyNow()
        {
            Cache();
            // The clothing variants inherit this component but have no silhouette.
            if (_image == null || _rect == null || _image.sprite == null) return;
            _color = SafeColor(_color);
            _size = SafeSize(_size);
            if (_image.color != _color) _image.color = _color;
            Rect bounds = _rect.rect;
            if (!Mathf.Approximately(bounds.width, _size.x))
                _rect.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, _size.x);
            if (!Mathf.Approximately(bounds.height, _size.y))
                _rect.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, _size.y);
        }

        private void Cache()
        {
            if (_image == null) _image = GetComponent<Image>();
            if (_rect == null) _rect = transform as RectTransform;
        }

        private static float Channel(float value, float fallback)
            => float.IsNaN(value) || float.IsInfinity(value) ? fallback : Mathf.Clamp01(value);
        private static Color SafeColor(Color value)
            => new Color(Channel(value.r, 1f), Channel(value.g, 1f), Channel(value.b, 1f), Channel(value.a, .55f));
        private static float Dimension(float value)
            => float.IsNaN(value) || float.IsInfinity(value) ? 100f : Mathf.Max(1f, value);
        private static Vector2 SafeSize(Vector2 value)
            => new Vector2(Dimension(value.x), Dimension(value.y));
    }
}
