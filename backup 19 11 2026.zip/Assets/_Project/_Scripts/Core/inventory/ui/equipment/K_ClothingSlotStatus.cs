using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;

namespace K_Incident.Core.Inventory
{
    [DisallowMultipleComponent]
    [AddComponentMenu("INCIDENT/UI/Состояние одежды")]
    public sealed class K_ClothingSlotStatus : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
    {
        [SerializeField, Tooltip("Слот, состояние одежды которого показано этой шкалой.")]
        private K_EquipmentSlotUI _slot;
        [SerializeField, Tooltip("Настоящее состояние ткани и теплозащиты персонажа. При пустой ссылке находится один раз после появления системы.")]
        private K_ClothingSystem _clothing;
        [SerializeField, Tooltip("Категория одежды. Для обуви показываются две независимые шкалы ступней.")]
        private ClothingSlotKind _kind;
        [SerializeField, Tooltip("Общая шкала состояния шапки, куртки или штанов. У обуви используются отдельные шкалы Л/П.")]
        private UnityEngine.UI.Image _fill;
        [SerializeField, Tooltip("Общий процент состояния ткани от 0 до 100.")]
        private TextMeshProUGUI _value;
        [SerializeField, Tooltip("Шкала состояния левой обуви.")]
        private UnityEngine.UI.Image _leftFill;
        [SerializeField, Tooltip("Процент состояния левой обуви.")]
        private TextMeshProUGUI _leftValue;
        [SerializeField, Tooltip("Шкала состояния правой обуви.")]
        private UnityEngine.UI.Image _rightFill;
        [SerializeField, Tooltip("Процент состояния правой обуви.")]
        private TextMeshProUGUI _rightValue;
        [SerializeField, Tooltip("Необязательная готовая панель подробностей при наведении. Компонент не создаёт UI в старых группах.")]
        private RectTransform _tooltipRoot;
        [SerializeField, Tooltip("Локальное состояние ткани и утепление предмета в панели подробностей.")]
        private TextMeshProUGUI _tooltipText;

        private K_ClothingSystem _subscribed;
        private K_EquipmentSlotUI _subscribedSlot;
        private float _nextRefresh;
        private bool _hovered;

        private void OnEnable() { Connect(); Refresh(); }
        private void OnDisable()
        {
            Disconnect();
            _hovered = false;
            if (_tooltipRoot != null) _tooltipRoot.gameObject.SetActive(false);
        }
        private void Update()
        {
            if (Time.unscaledTime < _nextRefresh) return;
            _nextRefresh = Time.unscaledTime + .25f;
            Connect();
            Refresh();
        }
        private void Connect()
        {
            if (_slot == null) _slot = GetComponent<K_EquipmentSlotUI>();
            if (_clothing == null) _clothing = FindFirstObjectByType<K_ClothingSystem>(FindObjectsInactive.Include);
            if (_subscribed != _clothing)
            {
                if (_subscribed != null) _subscribed.OnChanged -= Refresh;
                _subscribed = _clothing;
                if (_subscribed != null) _subscribed.OnChanged += Refresh;
            }
            if (_subscribedSlot != _slot)
            {
                if (_subscribedSlot != null) _subscribedSlot.OnEquipmentChanged -= EquipmentChanged;
                _subscribedSlot = _slot;
                if (_subscribedSlot != null) _subscribedSlot.OnEquipmentChanged += EquipmentChanged;
            }
        }
        private void Disconnect()
        {
            if (_subscribed != null) _subscribed.OnChanged -= Refresh;
            if (_subscribedSlot != null) _subscribedSlot.OnEquipmentChanged -= EquipmentChanged;
            _subscribed = null;
            _subscribedSlot = null;
        }
        private void EquipmentChanged(K_EquipmentSlotUI slot, InventoryItem oldItem, InventoryItem newItem) => Refresh();

        public void Refresh()
        {
            var item = _slot != null ? _slot.EquippedItem : null;
            bool valid = item?.Type == ItemType.Clothing && item.Data.Clothing != null && _clothing != null;
            bool footwear = _kind == ClothingSlotKind.Footwear;
            Show(_fill, valid && !footwear); Show(_value, valid && !footwear);
            Show(_leftFill, valid && footwear); Show(_leftValue, valid && footwear);
            Show(_rightFill, valid && footwear); Show(_rightValue, valid && footwear);
            Set(_fill, _value, valid ? _clothing.GetItemCondition01(item) : 0f, valid, string.Empty);
            Set(_leftFill, _leftValue, valid ? _clothing.GetRegionCondition(item, ClothingRegion.LeftFoot) : 0f, valid, "Л ");
            Set(_rightFill, _rightValue, valid ? _clothing.GetRegionCondition(item, ClothingRegion.RightFoot) : 0f, valid, "П ");
            if (_tooltipRoot != null) _tooltipRoot.gameObject.SetActive(_hovered && valid);
            if (_hovered && valid && _tooltipText != null)
                _tooltipText.text = ClothingPresentation.Detail(item, _clothing);
        }
        private static void Set(UnityEngine.UI.Image fill, TextMeshProUGUI label, float condition, bool valid, string prefix)
        {
            float value = Mathf.Clamp01(condition);
            if (fill != null) fill.fillAmount = valid ? value : 0f;
            if (label != null) label.text = prefix + (valid ? ClothingPresentation.Percent(value) + "%" : "—");
        }
        private static void Show(Component target, bool visible)
        {
            if (target != null && target.gameObject.activeSelf != visible) target.gameObject.SetActive(visible);
        }
        public void OnPointerEnter(PointerEventData eventData) { _hovered = true; Refresh(); }
        public void OnPointerExit(PointerEventData eventData)
        {
            _hovered = false;
            if (_tooltipRoot != null) _tooltipRoot.gameObject.SetActive(false);
        }
    }

    public static class ClothingPresentation
    {
        private static readonly ClothingRegion[] Hat = { ClothingRegion.Head };
        private static readonly ClothingRegion[] Jacket = { ClothingRegion.Torso, ClothingRegion.LeftArm, ClothingRegion.RightArm };
        private static readonly ClothingRegion[] Pants = { ClothingRegion.Pelvis, ClothingRegion.LeftLeg, ClothingRegion.RightLeg };
        private static readonly ClothingRegion[] Footwear = { ClothingRegion.LeftFoot, ClothingRegion.RightFoot };
        public static int Percent(float value) => Mathf.RoundToInt(Mathf.Clamp01(value) * 100f);
        public static string Compact(InventoryItem item, K_ClothingSystem system)
        {
            if (item?.Data?.Clothing == null || system == null) return string.Empty;
            if (item.Data.Clothing.Slot == ClothingSlotKind.Footwear)
                return "Л " + Percent(system.GetRegionCondition(item, ClothingRegion.LeftFoot)) + "% · П " +
                    Percent(system.GetRegionCondition(item, ClothingRegion.RightFoot)) + "%";
            return "Ткань " + Percent(system.GetItemCondition01(item)) + "%";
        }
        public static string Detail(InventoryItem item, K_ClothingSystem system)
        {
            if (item?.Data?.Clothing == null || system == null) return string.Empty;
            var text = new StringBuilder(item.Data.DisplayName);
            text.Append("\nУтепление: ").Append(item.Data.Clothing.Insulation.ToString("0.#"))
                .Append("\nПовреждения снижают защиту соответствующего участка.\nСостояние ткани:");
            var regions = Regions(item.Data.Clothing.Slot);
            for (int i = 0; i < regions.Length; i++)
                text.Append('\n').Append(RegionName(regions[i])).Append(": ")
                    .Append(Percent(system.GetRegionCondition(item, regions[i]))).Append('%');
            return text.ToString();
        }
        private static ClothingRegion[] Regions(ClothingSlotKind kind)
        {
            switch (kind)
            {
                case ClothingSlotKind.Hat: return Hat;
                case ClothingSlotKind.Jacket: return Jacket;
                case ClothingSlotKind.Pants: return Pants;
                default: return Footwear;
            }
        }
        private static string RegionName(ClothingRegion region)
        {
            switch (region)
            {
                case ClothingRegion.Head: return "Голова";
                case ClothingRegion.Torso: return "Туловище";
                case ClothingRegion.LeftArm: return "Левый рукав";
                case ClothingRegion.RightArm: return "Правый рукав";
                case ClothingRegion.Pelvis: return "Таз";
                case ClothingRegion.LeftLeg: return "Левая штанина";
                case ClothingRegion.RightLeg: return "Правая штанина";
                case ClothingRegion.LeftFoot: return "Левая обувь";
                default: return "Правая обувь";
            }
        }
    }
}
