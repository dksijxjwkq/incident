using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    [AddComponentMenu("INCIDENT/UI/Контур пустого слота одежды")]
    [RequireComponent(typeof(RectTransform), typeof(CanvasRenderer))]
    public sealed class ClothingSlotSilhouetteGraphic : Graphic
    {
        [SerializeField, Tooltip("Контур вещи, которую принимает пустой слот.")]
        private ClothingSlotKind _kind;
        [SerializeField, Tooltip("Занятый слот скрывает контур. Иконка надетого предмета остаётся обычным Image слота.")]
        private K_EquipmentSlotUI _slot;
        [SerializeField, Min(.5f), Tooltip("Толщина контурной линии в единицах Canvas.")]
        private float _lineWidth = 1.2f;
        private bool _occupied;

        protected override void OnEnable()
        {
            base.OnEnable();
            raycastTarget = false;
            _occupied = _slot != null && _slot.IsOccupied;
            SetVerticesDirty();
        }
        private void Update()
        {
            bool occupied = _slot != null && _slot.IsOccupied;
            if (_occupied == occupied) return;
            _occupied = occupied;
            SetVerticesDirty();
        }
        protected override void OnPopulateMesh(VertexHelper vh)
        {
            vh.Clear();
            if (_slot != null && _slot.IsOccupied) return;
            switch (_kind)
            {
                case ClothingSlotKind.Hat:
                    Path(vh, true, new Vector2(.18f,.27f), new Vector2(.82f,.27f), new Vector2(.82f,.4f), new Vector2(.18f,.4f));
                    Path(vh, false, new Vector2(.23f,.4f), new Vector2(.25f,.64f), new Vector2(.32f,.78f), new Vector2(.43f,.84f),
                        new Vector2(.57f,.84f), new Vector2(.68f,.78f), new Vector2(.75f,.64f), new Vector2(.77f,.4f));
                    break;
                case ClothingSlotKind.Jacket:
                    Path(vh, true, new Vector2(.4f,.86f), new Vector2(.29f,.81f), new Vector2(.16f,.69f), new Vector2(.1f,.41f),
                        new Vector2(.25f,.36f), new Vector2(.32f,.6f), new Vector2(.32f,.18f), new Vector2(.68f,.18f),
                        new Vector2(.68f,.6f), new Vector2(.75f,.36f), new Vector2(.9f,.41f), new Vector2(.84f,.69f),
                        new Vector2(.71f,.81f), new Vector2(.6f,.86f), new Vector2(.5f,.76f));
                    Path(vh, false, new Vector2(.5f,.76f), new Vector2(.5f,.18f));
                    break;
                case ClothingSlotKind.Pants:
                    Path(vh, true, new Vector2(.3f,.86f), new Vector2(.7f,.86f), new Vector2(.75f,.16f), new Vector2(.55f,.16f),
                        new Vector2(.5f,.56f), new Vector2(.45f,.16f), new Vector2(.25f,.16f));
                    Path(vh, false, new Vector2(.3f,.77f), new Vector2(.7f,.77f));
                    break;
                case ClothingSlotKind.Footwear:
                    Boot(vh, .05f); Boot(vh, .48f);
                    break;
            }
        }
        private void Boot(VertexHelper vh, float x)
        {
            Path(vh, true, new Vector2(x+.08f,.8f), new Vector2(x+.28f,.8f), new Vector2(x+.28f,.42f),
                new Vector2(x+.38f,.34f), new Vector2(x+.39f,.21f), new Vector2(x+.06f,.21f), new Vector2(x+.06f,.36f));
            Path(vh, false, new Vector2(x+.07f,.28f), new Vector2(x+.39f,.28f));
        }
        private void Path(VertexHelper vh, bool closed, params Vector2[] points)
        {
            Rect rect = GetPixelAdjustedRect();
            int segments = closed ? points.Length : points.Length - 1;
            for (int i = 0; i < segments; i++)
            {
                Vector2 a = new Vector2(rect.x + points[i].x * rect.width, rect.y + points[i].y * rect.height);
                Vector2 p = points[(i+1)%points.Length];
                Vector2 b = new Vector2(rect.x + p.x * rect.width, rect.y + p.y * rect.height);
                Vector2 direction = b - a;
                if (direction.sqrMagnitude < .0001f) continue;
                Vector2 normal = new Vector2(-direction.y, direction.x).normalized * Mathf.Max(.5f, _lineWidth) * .5f;
                int index = vh.currentVertCount;
                vh.AddVert(a-normal, color, Vector2.zero); vh.AddVert(a+normal, color, Vector2.zero);
                vh.AddVert(b+normal, color, Vector2.zero); vh.AddVert(b-normal, color, Vector2.zero);
                vh.AddTriangle(index,index+1,index+2); vh.AddTriangle(index,index+2,index+3);
            }
        }
    }
}
