using System.Globalization;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>A read-only, nonmodal view of an existing inventory item.</summary>
    [DisallowMultipleComponent]
    public sealed class K_ItemDescriptionWindow : MonoBehaviour
    {
        [Header("Окно")]
        [SerializeField, Tooltip("Название предмета в неподвижной шапке окна.")]
        private TMP_Text _title;
        [SerializeField, Tooltip("Кнопка закрывает только это окно и не меняет состояние инвентаря.")]
        private Button _closeButton;
        [SerializeField, Tooltip("Прокрутка изображения и четырёх разделов колёсиком и правым ползунком.")]
        private ScrollRect _scroll;
        [SerializeField, Tooltip("Существующий компонент перемещения окна; перетаскивать можно только шапку.")]
        private K_DraggablePanel _drag;
        [SerializeField, Tooltip("Шапка, за которую можно передвинуть окно.")]
        private RectTransform _header;

        [Header("Крупный просмотр")]
        [SerializeField, Tooltip("Крупная иконка предмета. Игровой prefab предмета не создаётся.")]
        private Image _preview;
        [SerializeField, Tooltip("Подпись для предметов без изображения.")]
        private GameObject _noPreview;

        [Header("Разделы")]
        [SerializeField, Tooltip("Описание из ItemStaticData → Описание предмета.")]
        private TMP_Text _description;
        [SerializeField, Tooltip("Авторский текст из ItemStaticData → Цели.")]
        private TMP_Text _goals;
        [SerializeField, Tooltip("Базовые данные экземпляра и авторский текст дополнительных характеристик.")]
        private TMP_Text _characteristics;
        [SerializeField, Tooltip("Авторский текст из ItemStaticData → Смысл.")]
        private TMP_Text _meaning;
        [SerializeField, Tooltip("Обозначение незаполненного раздела. Тексты предметов вводятся в их ItemStaticData.")]
        private string _emptySection = "—";
        [SerializeField, Min(.05f), Tooltip("Период обновления данных открытого предмета в секундах. Работает независимо от паузы игрового времени.")]
        private float _refreshInterval = .2f;

        private InventoryItem _item;
        private K_InventoryUI _owner;
        private bool _hasOwner;
        private float _nextRefresh;
        private readonly StringBuilder _stats = new StringBuilder(256);

        public InventoryItem Item => _item;
        public K_InventoryUI Owner => _owner;
        public bool IsOpen => gameObject.activeSelf && _item != null;

        private void Awake()
        {
            if (_closeButton != null) _closeButton.onClick.AddListener(Close);
            ConfigureDrag();
        }

        private void OnDestroy()
        {
            if (_closeButton != null) _closeButton.onClick.RemoveListener(Close);
        }

        private void OnDisable()
        {
            // Closing the inventory during a header drag must end that drag too.
            if (_drag != null) _drag.OnEndDrag(null);
        }

        public void Open(InventoryItem item, K_InventoryUI owner)
        {
            if (item?.Data == null) return;
            _item = item;
            _owner = owner;
            _hasOwner = owner != null;
            gameObject.SetActive(true);
            ConfigureDrag();
            transform.SetAsLastSibling();
            RefreshContent();
            if (_scroll != null && _scroll.content != null)
            {
                Canvas.ForceUpdateCanvases();
                LayoutRebuilder.ForceRebuildLayoutImmediate(_scroll.content);
                Canvas.ForceUpdateCanvases();
                _scroll.StopMovement();
                _scroll.verticalNormalizedPosition = 1f;
            }
            _nextRefresh = Time.unscaledTime + RefreshInterval;
        }

        public void Close()
        {
            if (_drag != null) _drag.OnEndDrag(null);
            _item = null;
            _owner = null;
            _hasOwner = false;
            gameObject.SetActive(false);
        }

        private void Update()
        {
            if (_item?.Data == null || (_hasOwner && (_owner == null || !_owner.IsOpen || !_owner.isActiveAndEnabled)))
            {
                Close();
                return;
            }
            if (Time.unscaledTime < _nextRefresh) return;
            _nextRefresh = Time.unscaledTime + RefreshInterval;
            RefreshContent();
        }

        private float RefreshInterval => float.IsNaN(_refreshInterval) || float.IsInfinity(_refreshInterval)
            ? .2f : Mathf.Max(.05f, _refreshInterval);

        private void ConfigureDrag()
        {
            if (_drag == null) return;
            _drag.ConfigureDragBehavior(false, false);
            _drag.SetDragZone(_header);
        }

        public void RefreshContent()
        {
            if (_item?.Data == null) return;
            var data = _item.Data;
            SetText(_title, string.IsNullOrWhiteSpace(data.DisplayName) ? "Предмет" : data.DisplayName);
            SetText(_description, Section(data.Description));
            SetText(_goals, Section(data.DescriptionGoals));
            SetText(_meaning, Section(data.DescriptionMeaning));
            if (_preview != null)
            {
                var sprite = _item.CurrentIcon;
                if (_preview.sprite != sprite) _preview.sprite = sprite;
                _preview.enabled = sprite != null;
                if (_noPreview != null) _noPreview.SetActive(sprite == null);
            }

            _stats.Clear();
            _stats.Append("Категория: ").Append(Category(data.Type));
            _stats.Append("\nМасса предмета: ").Append(Mathf.Max(0, data.WeightGrams).ToString(CultureInfo.InvariantCulture)).Append(" г");
            if (data.IsBackpack) _stats.Append(" (без содержимого)");
            var size = _item.CurrentSize;
            _stats.Append("\nРазмер в инвентаре: ").Append(size.x).Append(" × ").Append(size.y);
            _stats.Append("\nКоличество: ").Append(_item.Quantity);
            if (!string.IsNullOrWhiteSpace(data.DescriptionCharacteristics))
                _stats.Append("\n\n").Append(data.DescriptionCharacteristics.Trim());
            SetText(_characteristics, _stats.ToString());
        }

        private string Section(string text) => string.IsNullOrWhiteSpace(text) ? _emptySection : text.Trim();
        private static void SetText(TMP_Text target, string text)
        {
            if (target != null && target.text != text) target.text = text;
        }

        private static string Category(ItemType type)
        {
            switch (type)
            {
                case ItemType.Weapon: return "Оружие";
                case ItemType.Ammo: return "Боеприпасы";
                case ItemType.Medical: return "Медицинские средства";
                case ItemType.Consumable: return "Припасы";
                case ItemType.Clothing: return "Одежда";
                case ItemType.Backpack: return "Рюкзак";
                case ItemType.Currency: return "Ценности";
                case ItemType.Tool: return "Инструменты";
                case ItemType.KeyItem: return "Особый предмет";
                case ItemType.Armor: return "Защитное снаряжение";
                case ItemType.Magazine: return "Магазин";
                default: return "Разное";
            }
        }
    }
}
