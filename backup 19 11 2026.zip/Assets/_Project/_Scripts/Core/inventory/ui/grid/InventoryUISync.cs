﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Извлечено из K_InventoryUI (Задача 4).
    /// Отвечает за:
    ///   - Pool management (UI_Item и border hiders)
    ///   - Рендеринг и синхронизацию UI с моделью данных
    ///   - INCREMENTAL refresh (без ReturnAllItemsToPool при каждом обновлении)
    ///   - Tinting занятых ячеек и border hiders
    /// 
    /// КРИТИЧЕСКОЕ ТРЕБОВАНИЕ: RefreshGrid инкрементальный — обновляет только
    /// изменившиеся предметы, не уничтожает и не пересоздаёт всё подряд.
    /// </summary>
    public sealed class InventoryUISync
    {
        // ═══════════════════════════════════════════════════════════
        //  КОНФИГУРАЦИЯ (из K_InventoryUI)
        // ═══════════════════════════════════════════════════════════
        private readonly float _slotSize;
        private readonly float _slotSpacing;
        private readonly Color _occupiedCellTint;
        private readonly bool _hideBordersUnderItems;
        private readonly Color _borderHiderColor;
        private readonly float _borderHiderThickness;
        private readonly float _bhInsetTop, _bhInsetBottom, _bhInsetLeft, _bhInsetRight;
        private readonly GameObject _uiItemPrefab;
        private readonly int _poolPrewarmCount;

        // ═══════════════════════════════════════════════════════════
        //  ЗАВИСИМОСТИ (инжектируются через Initialize)
        // ═══════════════════════════════════════════════════════════
        private K_InventoryUI _inventoryUI;
        private InventoryGridBuilder _gridBuilder;
        private Transform _pocketsGrid, _pocket2Grid, _backpackGrid, _surroundingsGrid;
        private Transform _pocketsItemsContainer, _pocket2ItemsContainer;
        private Transform _backpackItemsContainer, _surroundingsItemsContainer;

        private readonly MonoBehaviour _coroutineRunner;

        private readonly Queue<UI_Item> _itemPool;
        private readonly Dictionary<string, UI_Item> _activeItems = new Dictionary<string, UI_Item>(200);

        private readonly Queue<GameObject> _borderHiderPool = new Queue<GameObject>();
        private readonly List<GameObject> _activeBorderHiders = new List<GameObject>();

        private Transform _poolParent;
        private bool _isReturningAllItemsToPool;
        private bool _isExecutingRefresh;
         private bool _isRefreshPending; 
        private Coroutine _textRebuildCoroutine;

        /// <summary>
        /// Публичный read-only доступ к флагу пулинга. 
        /// Используется в K_InventoryUI для защиты от реентерабельности.
        /// </summary>
        public bool IsReturningAllItemsToPool => _isReturningAllItemsToPool;
               
        public IReadOnlyDictionary<string, UI_Item> ActiveItems => _activeItems;

        public InventoryUISync(
            MonoBehaviour coroutineRunner,
            float slotSize,
            float slotSpacing,
            Color occupiedCellTint,
            bool hideBordersUnderItems,
            Color borderHiderColor,
            float borderHiderThickness,
            float bhInsetTop, float bhInsetBottom, float bhInsetLeft, float bhInsetRight,
            GameObject uiItemPrefab,
            int poolPrewarmCount)
        {
            _coroutineRunner = coroutineRunner;
            _slotSize = slotSize;
            _slotSpacing = slotSpacing;
            _occupiedCellTint = occupiedCellTint;
            _hideBordersUnderItems = hideBordersUnderItems;
            _borderHiderColor = borderHiderColor;
            _borderHiderThickness = borderHiderThickness;
            _bhInsetTop = bhInsetTop;
            _bhInsetBottom = bhInsetBottom;
            _bhInsetLeft = bhInsetLeft;
            _bhInsetRight = bhInsetRight;
            _uiItemPrefab = uiItemPrefab;
            _poolPrewarmCount = poolPrewarmCount;

            _itemPool = new Queue<UI_Item>(poolPrewarmCount);
        }

        public void Initialize(
            K_InventoryUI inventoryUI,
            InventoryGridBuilder gridBuilder,
            Transform pocketsGrid, Transform pocket2Grid,
            Transform backpackGrid, Transform surroundingsGrid,
            Transform pocketsItemsContainer, Transform pocket2ItemsContainer,
            Transform backpackItemsContainer, Transform surroundingsItemsContainer)
        {
            _inventoryUI = inventoryUI;
            _gridBuilder = gridBuilder;
            _pocketsGrid = pocketsGrid;
            _pocket2Grid = pocket2Grid;
            _backpackGrid = backpackGrid;
            _surroundingsGrid = surroundingsGrid;
            _pocketsItemsContainer = pocketsItemsContainer;
            _pocket2ItemsContainer = pocket2ItemsContainer;
            _backpackItemsContainer = backpackItemsContainer;
            _surroundingsItemsContainer = surroundingsItemsContainer;
        }

        public void PreWarmPool()
        {
            if (_uiItemPrefab == null) return;
            for (int i = 0; i < _poolPrewarmCount; i++)
            {
                var item = CreateNewPooledItem();
                if (item != null) _itemPool.Enqueue(item);
            }
        }

        public void ClearPooledItems()
        {
            foreach (var item in _itemPool) if (item != null) Object.Destroy(item.gameObject);
            _itemPool.Clear();
            _activeItems.Clear();
            foreach (var hider in _borderHiderPool) if (hider != null) Object.Destroy(hider);
            _borderHiderPool.Clear();
            foreach (var hider in _activeBorderHiders) if (hider != null) Object.Destroy(hider);
            _activeBorderHiders.Clear();
        }

        private Transform GetPoolParent()
        {
            if (_poolParent != null) return _poolParent;
            var go = new GameObject("__K_InventoryUI_Pool__", typeof(RectTransform));
            go.transform.SetParent(_inventoryUI.transform, false);
            go.SetActive(false);
            _poolParent = go.transform;
            return _poolParent;
        }

        private UI_Item CreateNewPooledItem()
        {
            if (_uiItemPrefab == null) return null;
            var newItem = Object.Instantiate(_uiItemPrefab, GetPoolParent()).GetComponent<UI_Item>();
            if (newItem == null) return null;
            newItem.gameObject.SetActive(false);
            var cg = newItem.GetComponent<CanvasGroup>();
            if (cg == null) cg = newItem.gameObject.AddComponent<CanvasGroup>();
            cg.alpha = 1f;
            cg.interactable = true;
            cg.blocksRaycasts = true;
            return newItem;
        }

        private UI_Item GetPooledItem()
        {
            if (_itemPool.Count > 0) return _itemPool.Dequeue();
            return CreateNewPooledItem();
        }

        // ═══ БАГ 3 ФИКС: вспомогательный поиск существующего UI_Item по InstanceID.
        // Используется для дедупликации перед созданием нового UI_Item. ═══
        private UI_Item FindActiveUIItemByItem(InventoryItem item)
        {
            if (item == null) return null;
            foreach (var kvp in _activeItems)
            {
                if (kvp.Value != null && kvp.Value.Item == item)
                    return kvp.Value;
            }
            return null;
        }

        // ═══════════════════════════════════════════════════════════
        //  POOL API (вызывается из DragDropController и других)
        // ═══════════════════════════════════════════════════════════
        public void ReturnToPool(UI_Item item)
        {
            if (item == null || item.gameObject == null) return;
            if (item == _inventoryUI.DraggedUIItem && _inventoryUI.IsDragging) return;

            Transform poolParent = GetPoolParent();
            if (!item.gameObject.activeSelf && item.transform.parent == poolParent)
            {
                RemoveAllReferencesFromActiveItems(item);
                return;
            }
            if (_itemPool.Contains(item)) return;

            // ═══ БАГ 3 ФИКС: гарантированно удалить ВСЕ ссылки на этот UI_Item
            // из _activeItems (могут быть дублирующие ключи после drag). ═══
            RemoveAllReferencesFromActiveItems(item);

            var cg = item.GetComponent<CanvasGroup>();
            if (cg != null)
            {
                cg.alpha = 1f;
                cg.blocksRaycasts = true;
                cg.interactable = true;
            }
            item.ResetState();

            if (item.gameObject.activeSelf)
            {
                _isReturningAllItemsToPool = true;
                try { item.gameObject.SetActive(false); }
                finally { _isReturningAllItemsToPool = false; }
            }
            if (item.transform.parent != poolParent)
            {
                try { item.transform.SetParent(poolParent, false); }
                catch { return; }
            }
            _itemPool.Enqueue(item);
        }

        // ═══ БАГ 3 ФИКС: удаляет ВСЕ entries, указывающие на item
        // (защита от дублирующих ключей после drag-сессии). ═══
        private void RemoveAllReferencesFromActiveItems(UI_Item item)
        {
            if (item == null) return;
            var keysToRemove = new List<string>(1);
            foreach (var kvp in _activeItems)
                if (kvp.Value == item) keysToRemove.Add(kvp.Key);
            for (int i = 0; i < keysToRemove.Count; i++)
                _activeItems.Remove(keysToRemove[i]);
        }

        // ═══ БАГ 3 ФИКС: пулим все UI_Item с тем же InventoryItem, КРОМЕ keep.
        // Вызывается из K_InventoryUI.EndDragComplete после сброса IsBeingDragged. ═══
        public void ReturnDuplicatesByItem(InventoryItem item, UI_Item keep)
        {
            if (item == null) return;
            var toPool = new List<UI_Item>(1);
            foreach (var kvp in _activeItems)
            {
                var ui = kvp.Value;
                if (ui == null || ui == keep) continue;
                if (ui.Item == item) toPool.Add(ui);
            }
            for (int i = 0; i < toPool.Count; i++)
                ReturnToPool(toPool[i]);
        }

        public void ReturnAllItemsToPool()
        {
            if (_isReturningAllItemsToPool) return;
            _isReturningAllItemsToPool = true;
            try
            {
                UI_Item protectedItem = _inventoryUI.DraggedUIItem;
                var keysToRemove = new List<string>();
                foreach (var kvp in _activeItems)
                {
                    var item = kvp.Value;
                    if (item == protectedItem) continue;
                    if (item == null) { keysToRemove.Add(kvp.Key); continue; }
                    ReturnToPoolOnly(item);
                }
                foreach (var key in keysToRemove) _activeItems.Remove(key);
                _activeItems.Clear();

                if (protectedItem != null && protectedItem.Item != null)
                {
                    string key = GetCellKey(protectedItem.GridType, protectedItem.X, protectedItem.Y);
                    _activeItems[key] = protectedItem;
                }
            }
            finally { _isReturningAllItemsToPool = false; }
        }

        private void ReturnToPoolOnly(UI_Item item)
        {
            if (item == null || item.gameObject == null) return;
            if (_itemPool.Contains(item)) return;
            item.ResetState();
            if (item.gameObject.activeSelf)
            {
                _isReturningAllItemsToPool = true;
                try { item.gameObject.SetActive(false); }
                finally { _isReturningAllItemsToPool = false; }
            }
            Transform poolParent = GetPoolParent();
            if (item.transform.parent != poolParent)
            {
                try { item.transform.SetParent(poolParent, false); }
                catch { return; }
            }
            _itemPool.Enqueue(item);
        }

        /// <summary>
        /// Единая точка завершения drag и возврата UI_Item в пул.
        /// Порядок: 1) _isDragging=false, 2) _draggedItem=null, 3) MarkDragFinished, 4) ReturnToPool.
        /// </summary>
        public void FinishDragAndPool(UI_Item ui)
        {
            _inventoryUI.ClearDraggedItem();
            if (ui == null) return;
            ui.MarkDragFinished();
            ReturnToPool(ui);
        }

        // ═══════════════════════════════════════════════════════════
        //  INCREMENTAL REFRESH (КРИТИЧЕСКИ ВАЖНО)
        // ═══════════════════════════════════════════════════════════
        /// <summary>
        /// ПОЛНЫЙ СИНХРОННЫЙ REFRESH всех сеток.
        /// INCREMENTAL: НЕ уничтожает все UI_Items — только обновляет изменившиеся,
        /// удаляет отсутствующие, создаёт новые.
        /// </summary>
        
        public void ExecuteRefreshImmediate()
{
    // Reentrant callbacks request one following pass instead of nesting refresh stacks.
    if (_isExecutingRefresh) { _isRefreshPending = true; return; }
    const int MaxConsecutivePasses = 4;

    for (int pass = 0; pass < MaxConsecutivePasses; pass++)
    {
        _isRefreshPending = false;
        _isExecutingRefresh = true;
        try
        {
            SyncItemsContainerPositions();

            RefreshGrid(GridType.Pockets, _inventoryUI.GetGridWidth(GridType.Pockets), _inventoryUI.GetGridHeight(GridType.Pockets), _pocketsItemsContainer);
            RefreshGrid(GridType.Pocket2, _inventoryUI.GetGridWidth(GridType.Pocket2), _inventoryUI.GetGridHeight(GridType.Pocket2), _pocket2ItemsContainer);

            if (_backpackGrid != null)
                RefreshGrid(GridType.Backpack, _inventoryUI.GetGridWidth(GridType.Backpack), _inventoryUI.GetGridHeight(GridType.Backpack), _backpackItemsContainer);

            if (_inventoryUI.IsLooting && _surroundingsItemsContainer != null)
            {
                var ctrl = _inventoryUI.GetControllerForGrid(GridType.Container);
                if (ctrl != null)
                    RefreshGrid(GridType.Container, ctrl.Width, ctrl.Height, _surroundingsItemsContainer);
            }

            _inventoryUI.RefreshEquipmentSlots();
            UpdateOccupiedCellTints();
            UpdateInternalBorders();
            RefreshAllWindows();

            if (_textRebuildCoroutine != null)
                _coroutineRunner.StopCoroutine(_textRebuildCoroutine);
            if (_coroutineRunner.gameObject.activeInHierarchy)
                _textRebuildCoroutine = _coroutineRunner.StartCoroutine(DeferredTextRebuild());
        }
        finally
        {
            _isExecutingRefresh = false;
        }

        if (!_isRefreshPending) return;
    }

    Debug.LogWarning("[InventoryUISync] Refresh не устаканился за 4 прохода — кто-то мутирует инвентарь во время refresh.");
}
        
       // Assets/_Project/_Scripts/Core/inventory/InventoryUISync.cs
// Assets/_Project/_Scripts/Core/inventory/InventoryUISync.cs
public void RefreshGrid(GridType type, int cols, int rows, Transform container)
{
    var controller = _inventoryUI.GetControllerForGrid(type);
    if (controller == null || container == null) return;

    if (_inventoryUI.IsGroundLootController(controller))
    {
        RefreshGroundLootGrid(controller, container);
        return;
    }

    UI_Item draggedItem = _inventoryUI.DraggedUIItem;

    var toPool = new List<UI_Item>();
    var toUpdate = new List<string>();
    var deadKeys = new List<string>();

    foreach (var kvp in _activeItems)
    {
        string key = kvp.Key;
        if (!KeyBelongsToGrid(key, type)) continue;

        UI_Item uiItem = kvp.Value;
        if (uiItem == null) { deadKeys.Add(key); continue; }

        // --- Исправление: stale UI_Item даже при IsBeingDragged, но не пулим _draggedItem ---
        if (uiItem.IsBeingDragged)
        {
            var (dragGx, dragGy) = ParseCoordinatesFromKey(key);
            var dragModelItem = controller.GetItemAt(dragGx, dragGy);
            bool isStale = dragModelItem == null ||
                           !controller.IsRootCell(dragModelItem.InstanceID, dragGx, dragGy) ||
                           uiItem.Item != dragModelItem ||
                           uiItem.X != dragGx ||
                           uiItem.Y != dragGy;
            if (isStale)
            {
                // Не пулим _draggedItem здесь — его пулит EndDragComplete
                if (uiItem != draggedItem)
                    toPool.Add(uiItem);
                else
                    Debug.LogWarning($"[RefreshGrid] Stale _draggedItem detected at ({dragGx},{dragGy}). " +
                                     $"Will be pooled by EndDragComplete.");
            }
            continue;
        }

        if (uiItem == draggedItem) continue;

        var (gx, gy) = ParseCoordinatesFromKey(key);
        var modelItem = controller.GetItemAt(gx, gy);

        bool stale = modelItem == null ||
                     !controller.IsRootCell(modelItem.InstanceID, gx, gy) ||
                     uiItem.Item != modelItem ||
                     uiItem.X != gx ||
                     uiItem.Y != gy;

        if (stale) toPool.Add(uiItem);
        else toUpdate.Add(key);
    }

    // Пулим stale UI_Item
    for (int i = 0; i < toPool.Count; i++) ReturnToPool(toPool[i]);
    for (int i = 0; i < deadKeys.Count; i++) _activeItems.Remove(deadKeys[i]);

    // Обновляем существующие
    for (int i = 0; i < toUpdate.Count; i++)
    {
        if (_activeItems.TryGetValue(toUpdate[i], out var uiItem) && uiItem != null)
        {
            uiItem.gameObject.SetActive(true);
            uiItem.UpdateData(uiItem.Item);
            var cg = uiItem.GetComponent<CanvasGroup>();
            if (cg != null) { cg.alpha = 1f; cg.blocksRaycasts = true; cg.interactable = true; }
        }
    }

    // Создаём новые UI_Item для предметов без UI
    for (int y = 0; y < rows; y++)
    {
        for (int x = 0; x < cols; x++)
        {
            var item = controller.GetItemAt(x, y);
            if (item == null || !controller.IsRootCell(item.InstanceID, x, y)) continue;

            string key = GetCellKey(type, x, y);
            if (_activeItems.ContainsKey(key)) continue;

            CreateUIItem(item, x, y, type, container);
        }
    }
}
       private void RefreshGroundLootGrid(InventoryController controller, Transform container)
       {
           var stale = new List<UI_Item>();
           var deadKeys = new List<string>();
           foreach (var pair in _activeItems)
           {
               if (KeyBelongsToGrid(pair.Key, GridType.Container) && pair.Value == null)
               { deadKeys.Add(pair.Key); continue; }
               if (KeyBelongsToGrid(pair.Key, GridType.Container) && pair.Value != _inventoryUI.DraggedUIItem &&
                   (pair.Value == null || pair.Value.BoundController != controller ||
                    controller.GetItemByInstanceID(pair.Value.Item.InstanceID) != pair.Value.Item))
                   stale.Add(pair.Value);
           }
           foreach (var key in deadKeys) _activeItems.Remove(key);
           foreach (var item in stale) if (item != null) ReturnToPool(item);

           // Repacking can move the drag source and put another item in its old
           // cell. Keep the same dragged view, but release its obsolete key.
           var dragged = _inventoryUI.DraggedUIItem;
           if (dragged != null && ReferenceEquals(dragged.BoundController, controller) &&
               controller.TryGetItemPosition(dragged.Item.InstanceID, out int dragX, out int dragY))
           {
               RemoveAllReferencesFromActiveItems(dragged);
               _activeItems[GetCellKey(GridType.Container, dragX, dragY)] = dragged;
           }

           foreach (var item in _inventoryUI.GroundLootItems)
           {
               if (ReferenceEquals(item, _inventoryUI.DraggedUIItem?.Item)) continue;
               if (!controller.TryGetItemPosition(item.InstanceID, out int x, out int y)) continue;
               string key = GetCellKey(GridType.Container, x, y);
               if (!_activeItems.ContainsKey(key)) CreateUIItem(item, x, y, GridType.Container, container);
               if (_activeItems.TryGetValue(key, out var ui) && ui != null && ui != _inventoryUI.DraggedUIItem)
               {
                   ui.UpdateData(item);
                   var rect = ui.GetComponent<RectTransform>();
                   var padding = _gridBuilder.GetPaddingForGrid(GridType.Container);
                   rect.anchoredPosition = new Vector2(padding.x + x * (_slotSize + _slotSpacing),
                       -padding.y - y * (_slotSize + _slotSpacing));
               }
           }
       }

       private bool KeyBelongsToGrid(string key, GridType type)
{
    if (type == GridType.Container)
        // ═══ БАГ 3 ФИКС: ключи Win_ принадлежат окнам рюкзаков и
        // обрабатываются ТОЛЬКО в RefreshAllWindows. При луте
        // RefreshGrid для Container использует контроллер лута —
        // ключи Win_ здесь дают предметы не из того окна. ═══
        return key.StartsWith("Container_") || key.StartsWith("Loot_");

    string prefix = type.ToString() + "_";
    return key.StartsWith(prefix);
}
        private (int x, int y) ParseCoordinatesFromKey(string key)
        {
            string[] parts = key.Split('_');
            if (parts.Length >= 3)
            {
                if (int.TryParse(parts[parts.Length - 2], out int x) &&
                    int.TryParse(parts[parts.Length - 1], out int y))
                    return (x, y);
            }
            return (0, 0);
        }

        private void CreateUIItem(InventoryItem item, int x, int y, GridType type, Transform container)
        {
            string key = GetCellKey(type, x, y);
            if (_activeItems.ContainsKey(key)) return;

            // ═══ БАГ 3 ФИКС (дедупликация по InstanceID): если в _activeItems уже
            // есть UI_Item с тем же InstanceID (stale duplicate после drag) — пулим его. ═══
            UI_Item stale = FindActiveUIItemByItem(item);
            if (stale != null) ReturnToPool(stale);

            if (container == null || _uiItemPrefab == null || item == null) return;

            var uiItem = GetPooledItem();
            if (uiItem == null) return;

            uiItem.transform.SetParent(container, false);
            uiItem.transform.SetAsLastSibling();

            var rect = uiItem.GetComponent<RectTransform>();
            if (rect != null)
            {
                Vector2Int currentSize = item.CurrentSize;
                float widthPx = currentSize.x * _slotSize + (currentSize.x - 1) * _slotSpacing;
                float heightPx = currentSize.y * _slotSize + (currentSize.y - 1) * _slotSpacing;
                Vector2 padding = _gridBuilder.GetPaddingForGrid(type);

                rect.anchorMin = new Vector2(0f, 1f);
                rect.anchorMax = new Vector2(0f, 1f);
                rect.pivot = new Vector2(0f, 1f);
                rect.sizeDelta = new Vector2(widthPx, heightPx);
                rect.anchoredPosition = new Vector2(
                    padding.x + x * (_slotSize + _slotSpacing),
                    -padding.y - y * (_slotSize + _slotSpacing));
                rect.localScale = Vector3.one;
                rect.localRotation = Quaternion.identity;
            }

            uiItem.gameObject.SetActive(true);
            uiItem.Setup(item, _inventoryUI, type, x, y);

            // ═══ БАГ 2/4 ФИКС: BindController для ВСЕХ типов grid-ов, не только Container.
            // Без этого UI_Item в Pockets/Pocket2/Backpack имеют BoundController == null,
            // иконка-дроп на рюкзак в экипированной сетке и swap через иконку падают
            // в null-guard UI_Item.OnDrop. ═══
            var boundCtrl = _inventoryUI.GetControllerForGrid(type);
            if (boundCtrl != null)
                uiItem.BindController(boundCtrl);

            _activeItems[key] = uiItem;
        }

        private string GetCellKey(GridType type, int x, int y)
        {
            if (type == GridType.Container)
                return $"Container_{x}_{y}";
            return $"{type}_{x}_{y}";
        }

        /// <summary>
        /// Refresh для multi-window (открытые рюкзаки как контейнеры).
        /// </summary>
        public void RefreshAllWindows()
        {
            var windows = _inventoryUI.GetOpenContainerWindows();
            if (windows == null) return;
            foreach (var window in windows)
            {
                if (window == null || window.Controller == null || window.ItemsContainer == null) continue;
                RefreshWindowItems(window);
            }
        }
        /// <summary>
/// Удаляет UI-записи окна из ЕДИНСТВЕННОГО реестра _activeItems.
/// Вызывается ДО разрушения GO окна: предметы корректно возвращаются в пул,
/// ключи не протекают. Заменяет мёртвый делегат в K_InventoryUI.
/// </summary>
public void CleanupWindowItems(string backpackInstanceId)
{
    if (string.IsNullOrEmpty(backpackInstanceId)) return;
    string prefix = "Win_" + backpackInstanceId + "_";

    List<string> keysToRemove = null;
    foreach (var kvp in _activeItems)
    {
        if (kvp.Key.StartsWith(prefix))
            (keysToRemove ??= new List<string>()).Add(kvp.Key);
    }
    if (keysToRemove == null) return;

    for (int i = 0; i < keysToRemove.Count; i++)
    {
        if (_activeItems.TryGetValue(keysToRemove[i], out var uiItem) && uiItem != null)
            ReturnToPool(uiItem);
        _activeItems.Remove(keysToRemove[i]);
    }
}

    private void RefreshWindowItems(K_ContainerWindow window)
{
    int cols = window.GridWidth;
    int rows = window.GridHeight;
    var controller = window.Controller;
    UI_Item draggedItem = _inventoryUI.DraggedUIItem;

    for (int y = 0; y < rows; y++)
    {
        for (int x = 0; x < cols; x++)
        {
            string key = $"Win_{window.BackpackInstanceID}_{x}_{y}";
            var item = controller.GetItemAt(x, y);

            if (_activeItems.TryGetValue(key, out var uiItem))
            {
                if (uiItem == null)
                {
                    _activeItems.Remove(key);
                    if (item != null && controller.IsRootCell(item.InstanceID, x, y))
                    {
                        // ═══ ДОБАВЬ ЭТОТ ЛОГ ═══
                        Debug.Log($"[RefreshWindowItems] Creating UI_Item (uiItem was null) for '{item.Data.DisplayName}' " +
                                  $"at ({x},{y}) in window '{window.BackpackInstanceID}'");
                        CreateWindowItem(window, item, x, y, key);
                    }
                    continue;
                }
                if (uiItem == draggedItem) continue;
                if (item == null)
                {
                    ReturnToPool(uiItem);
                    _activeItems.Remove(key);
                }
                else if (!controller.IsRootCell(item.InstanceID, x, y) || uiItem.Item != item)
                {
                    // ═══ ДОБАВЬ ЭТОТ ЛОГ ═══
                    Debug.Log($"[RefreshWindowItems] Creating UI_Item (mismatch) for '{item.Data.DisplayName}' " +
                              $"at ({x},{y}) in window '{window.BackpackInstanceID}', " +
                              $"oldUI.Item={uiItem.Item?.Data?.DisplayName ?? "null"}, " +
                              $"isRootCell={controller.IsRootCell(item.InstanceID, x, y)}");
                    ReturnToPool(uiItem);
                    _activeItems.Remove(key);
                    if (controller.IsRootCell(item.InstanceID, x, y))
                    CreateWindowItem(window, item, x, y, key);
                }
                else
                {
                    uiItem.gameObject.SetActive(true);
                    uiItem.UpdateData(item);
                }
            }
            else if (item != null && controller.IsRootCell(item.InstanceID, x, y))
            {
                if (draggedItem != null && draggedItem.Item == item) continue;
                // ═══ ДОБАВЬ ЭТОТ ЛОГ ═══
                Debug.Log($"[RefreshWindowItems] Creating UI_Item (new) for '{item.Data.DisplayName}' " +
                          $"at ({x},{y}) in window '{window.BackpackInstanceID}'");
                CreateWindowItem(window, item, x, y, key);
            }
        }
    }
}

        private void CreateWindowItem(K_ContainerWindow window, InventoryItem item, int x, int y, string key)
        {
            if (window.ItemsContainer == null || _uiItemPrefab == null) return;

            // ═══ БАГ 3 ФИКС: дедупликация по InstanceID. ═══
            UI_Item stale = FindActiveUIItemByItem(item);
            if (stale != null) ReturnToPool(stale);

            var newUiItem = GetPooledItem();
            if (newUiItem == null) return;

            newUiItem.transform.SetParent(window.ItemsContainer, false);
            newUiItem.transform.SetAsLastSibling();
            var rect = newUiItem.GetComponent<RectTransform>();
            if (rect != null)
            {
                Vector2Int currentSize = item.CurrentSize;
                float widthPx = currentSize.x * _slotSize + Mathf.Max(0, currentSize.x - 1) * _slotSpacing;
                float heightPx = currentSize.y * _slotSize + Mathf.Max(0, currentSize.y - 1) * _slotSpacing;
                rect.anchorMin = new Vector2(0f, 1f);
                rect.anchorMax = new Vector2(0f, 1f);
                rect.pivot = new Vector2(0f, 1f);
                rect.sizeDelta = new Vector2(widthPx, heightPx);
                rect.anchoredPosition = new Vector2(
                    x * (_slotSize + _slotSpacing),
                    -y * (_slotSize + _slotSpacing));
                rect.localScale = Vector3.one;
                rect.localRotation = Quaternion.identity;
            }
            newUiItem.gameObject.SetActive(true);
            newUiItem.Setup(item, _inventoryUI, GridType.Container, x, y);
            newUiItem.BindController(window.Controller);
            _activeItems[key] = newUiItem;
        }

        // ═══════════════════════════════════════════════════════════
        //  POSITION SYNC
        // ═══════════════════════════════════════════════════════════
        public void SyncItemsContainerPositions()
        {
            SyncContainer(_pocketsGrid, _pocketsItemsContainer);
            SyncContainer(_pocket2Grid, _pocket2ItemsContainer);
            SyncContainer(_backpackGrid, _backpackItemsContainer);
            SyncContainer(_surroundingsGrid, _surroundingsItemsContainer);
        }

        private void SyncContainer(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;
            RectTransform gridRect = grid.GetComponent<RectTransform>();
            RectTransform itemsRect = itemsContainer.GetComponent<RectTransform>();
            if (gridRect == null || itemsRect == null) return;

            if (itemsContainer.parent == grid)
            {
                itemsRect.anchorMin = new Vector2(0f, 1f);
                itemsRect.anchorMax = new Vector2(0f, 1f);
                itemsRect.pivot = new Vector2(0f, 1f);
                itemsRect.sizeDelta = gridRect.sizeDelta;
                itemsRect.anchoredPosition = Vector2.zero;
                itemsRect.localScale = Vector3.one;
                return;
            }

            Vector3[] gridCorners = new Vector3[4];
            gridRect.GetWorldCorners(gridCorners);
            Vector3 worldTopLeft = gridCorners[1];
            Vector2 worldSize = gridCorners[2] - gridCorners[0];
            Vector2 localTopLeft;
            Vector2 parentScale = Vector2.one;

            if (itemsRect.parent != null)
            {
                localTopLeft = itemsRect.parent.InverseTransformPoint(worldTopLeft);
                parentScale = new Vector2(
                    Mathf.Abs(itemsRect.parent.lossyScale.x),
                    Mathf.Abs(itemsRect.parent.lossyScale.y));
            }
            else { localTopLeft = worldTopLeft; }

            Vector2 localSize = new Vector2(worldSize.x / parentScale.x, worldSize.y / parentScale.y);
            RectTransform parentRect = itemsRect.parent as RectTransform;
            if (parentRect != null)
                localTopLeft -= new Vector2(parentRect.rect.xMin, parentRect.rect.yMax);

            itemsRect.anchorMin = new Vector2(0f, 1f);
            itemsRect.anchorMax = new Vector2(0f, 1f);
            itemsRect.pivot = new Vector2(0f, 1f);
            itemsRect.sizeDelta = localSize;
            itemsRect.anchoredPosition = localTopLeft;
            itemsRect.localScale = gridRect.localScale;
        }

        // ═══════════════════════════════════════════════════════════
        //  OCCUPIED CELL TINTING
        // ═══════════════════════════════════════════════════════════
        public void UpdateOccupiedCellTints()
        {
            if (_occupiedCellTint.a <= 0f) return;
            ResetAllSlotColors();
            TintOccupiedCells(GridType.Pockets, _pocketsGrid);
            TintOccupiedCells(GridType.Pocket2, _pocket2Grid);
            TintOccupiedCells(GridType.Backpack, _backpackGrid);
            if (_inventoryUI.IsLooting)
                TintOccupiedCells(GridType.Container, _surroundingsGrid);
        }

        private void ResetAllSlotColors()
        {
            ResetGridSlotColors(_pocketsGrid);
            ResetGridSlotColors(_pocket2Grid);
            ResetGridSlotColors(_backpackGrid);
            ResetGridSlotColors(_surroundingsGrid);
        }

        private void ResetGridSlotColors(Transform grid)
        {
            if (grid == null) return;
            for (int i = 0; i < grid.childCount; i++)
            {
                var slot = grid.GetChild(i).GetComponent<K_InventorySlotUI>();
                slot?.ResetCellColor();
            }
        }

        private void TintOccupiedCells(GridType gridType, Transform grid)
        {
            if (grid == null) return;
            var controller = _inventoryUI.GetControllerForGrid(gridType);
            if (controller == null) return;
            for (int y = 0; y < controller.Height; y++)
            {
                for (int x = 0; x < controller.Width; x++)
                {
                    if (controller.GetItemAt(x, y) != null)
                    {
                        var slot = GetSlotAt(grid, x, y, controller.Width);
                        slot?.TintOccupied(_occupiedCellTint);
                    }
                }
            }
        }

        public K_InventorySlotUI GetSlotAt(Transform grid, int x, int y, int columns)
        {
            if (grid == null) return null;
            int index = y * columns + x;
            if (index < 0 || index >= grid.childCount) return null;
            return grid.GetChild(index).GetComponent<K_InventorySlotUI>();
        }

        // ═══════════════════════════════════════════════════════════
        //  BORDER HIDERS
        // ═══════════════════════════════════════════════════════════
        public void UpdateInternalBorders()
        {
            if (!_hideBordersUnderItems)
            {
                ReturnAllBorderHidersToPool();
                return;
            }
            try
            {
                foreach (var hider in _activeBorderHiders)
                {
                    if (hider == null) continue;
                    hider.SetActive(false);
                    hider.transform.SetParent(GetPoolParent(), false);
                    _borderHiderPool.Enqueue(hider);
                }
                _activeBorderHiders.Clear();

                CreateBorderHidersForGrid(_inventoryUI.GetControllerForGrid(GridType.Pockets),
                    _pocketsGrid, _gridBuilder.GetPaddingForGrid(GridType.Pockets));
                CreateBorderHidersForGrid(_inventoryUI.GetControllerForGrid(GridType.Pocket2),
                    _pocket2Grid, _gridBuilder.GetPaddingForGrid(GridType.Pocket2));
                CreateBorderHidersForGrid(_inventoryUI.GetControllerForGrid(GridType.Backpack),
                    _backpackGrid, _gridBuilder.GetPaddingForGrid(GridType.Backpack));
                if (_inventoryUI.IsLooting)
                    CreateBorderHidersForGrid(_inventoryUI.GetControllerForGrid(GridType.Container),
                        _surroundingsGrid, _gridBuilder.GetPaddingForGrid(GridType.Container));
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[UpdateInternalBorders] Skipped: {ex.Message}");
            }
        }

        private void CreateBorderHidersForGrid(InventoryController controller, Transform grid, Vector2 padding)
        {
            if (controller == null || grid == null) return;
            Transform overlay = GetOrCreateBorderOverlay(grid);
            if (overlay == null) return;

            var gridRect = grid.GetComponent<RectTransform>();
            var overlayRect = overlay.GetComponent<RectTransform>();
            if (gridRect != null && overlayRect != null)
                overlayRect.sizeDelta = gridRect.sizeDelta;

            float step = _slotSize + _slotSpacing;
            for (int y = 0; y < controller.Height; y++)
            {
                for (int x = 0; x < controller.Width; x++)
                {
                    var item = controller.GetItemAt(x, y);
                    if (item == null || !controller.IsRootCell(item.InstanceID, x, y)) continue;
                    Vector2Int size = item.CurrentSize;

                    for (int dy = 0; dy < size.y; dy++)
                        for (int dx = 0; dx < size.x - 1; dx++)
                        {
                            float posX = padding.x + (x + dx + 1) * step - _borderHiderThickness / 2f;
                            float posY = -(padding.y + (y + dy) * step) - _bhInsetTop;
                            float h = _slotSize - _bhInsetTop - _bhInsetBottom;
                            if (h > 0f) SpawnBorderHider(overlay, posX, posY, _borderHiderThickness, h);
                        }

                    for (int dx = 0; dx < size.x; dx++)
                        for (int dy = 0; dy < size.y - 1; dy++)
                        {
                            float posX = padding.x + (x + dx) * step + _bhInsetLeft;
                            float posY = -(padding.y + (y + dy + 1) * step) + _borderHiderThickness / 2f;
                            float w = _slotSize - _bhInsetLeft - _bhInsetRight;
                            if (w > 0f) SpawnBorderHider(overlay, posX, posY, w, _borderHiderThickness);
                        }
                }
            }
        }

        private Transform GetOrCreateBorderOverlay(Transform grid)
        {
            if (grid == null) return null;
            Transform overlay = grid.Find("BorderOverlay");
            if (overlay != null) return overlay;

            var obj = new GameObject("BorderOverlay", typeof(RectTransform));
            obj.transform.SetParent(grid, false);
            var le = obj.AddComponent<LayoutElement>();
            le.ignoreLayout = true;
            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = Vector2.zero;
            rt.localScale = Vector3.one;
            var gridRect = grid.GetComponent<RectTransform>();
            if (gridRect != null) rt.sizeDelta = gridRect.sizeDelta;

            if (_surroundingsItemsContainer != null && _surroundingsItemsContainer.parent == grid)
                obj.transform.SetSiblingIndex(_surroundingsItemsContainer.GetSiblingIndex());
            return obj.transform;
        }

        private void SpawnBorderHider(Transform parent, float posX, float posY, float width, float height)
        {
            while (_borderHiderPool.Count > 0 && _borderHiderPool.Peek() == null) _borderHiderPool.Dequeue();
            GameObject hider;
            if (_borderHiderPool.Count > 0) hider = _borderHiderPool.Dequeue();
            else hider = new GameObject("BorderHider", typeof(RectTransform), typeof(Image));

            hider.transform.SetParent(parent, false);
            var img = hider.GetComponent<Image>();
            if (img == null) img = hider.AddComponent<Image>();
            img.color = _borderHiderColor;
            img.raycastTarget = false;
            img.maskable = true;
            img.sprite = null;
            img.type = Image.Type.Simple;

            var rt = hider.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(posX, posY);
            rt.sizeDelta = new Vector2(width, height);
            rt.localScale = Vector3.one;
            rt.localRotation = Quaternion.identity;
            hider.SetActive(true);
            _activeBorderHiders.Add(hider);
        }

        public void ReturnAllBorderHidersToPool()
        {
            foreach (var hider in _activeBorderHiders)
            {
                if (hider == null) continue;
                if (hider != null) hider.SetActive(false);
                hider.transform.SetParent(GetPoolParent(), false);
                _borderHiderPool.Enqueue(hider);
            }
            _activeBorderHiders.Clear();
        }

        public void PoolBorderHidersBeforeGridDestroy(Transform grid)
        {
            if (grid == null) return;
            for (int i = _activeBorderHiders.Count - 1; i >= 0; i--)
            {
                var hider = _activeBorderHiders[i];
                if (hider == null) { _activeBorderHiders.RemoveAt(i); continue; }
                if (!hider.transform.IsChildOf(grid)) continue;
                hider.SetActive(false);
                hider.transform.SetParent(GetPoolParent(), false);
                _borderHiderPool.Enqueue(hider);
                _activeBorderHiders.RemoveAt(i);
            }
            // Also repair hiders queued by a previous refresh while still
            // parented below this grid; drop stale Unity destroyed references.
            int queued = _borderHiderPool.Count;
            for (int i = 0; i < queued; i++)
            {
                var hider = _borderHiderPool.Dequeue();
                if (hider == null) continue;
                if (hider.transform.IsChildOf(grid)) hider.transform.SetParent(GetPoolParent(), false);
                _borderHiderPool.Enqueue(hider);
            }
        }

        // ═══════════════════════════════════════════════════════════
        //  DEFERRED TEXT REBUILD
        // ═══════════════════════════════════════════════════════════
        private IEnumerator DeferredTextRebuild()
        {
            for (int pass = 0; pass < 2; pass++)
            {
                yield return null;
                Canvas.ForceUpdateCanvases();

                // ИСПРАВЛЕНО: Итерация по слепку значений, чтобы избежать InvalidOperationException,
                // если ForceTextRefresh() случайно триггерит событие, меняющее словарь.
                var itemsSnapshot = new List<UI_Item>(_activeItems.Values);
                foreach (var item in itemsSnapshot)
                {
                    if (item != null) item.ForceTextRefresh();
                }
            }
            _textRebuildCoroutine = null;
        }

        public void StopTextRebuildCoroutine()
        {
            if (_textRebuildCoroutine != null)
            {
                _coroutineRunner.StopCoroutine(_textRebuildCoroutine);
                _textRebuildCoroutine = null;
            }
        }
    }
}
