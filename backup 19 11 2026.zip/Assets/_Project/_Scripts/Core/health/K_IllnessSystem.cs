using System;
using System.IO;
using System.Text;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>Two source-owned illnesses. Symptoms are not independent debuffs.</summary>
    [DisallowMultipleComponent]
    public sealed class K_IllnessSystem : MonoBehaviour, ISaveable, IPreLoad, IPostLoad, ISavePayloadValidator
    {
        private const int PartCount = 20;
        private const int PayloadMarker = 0x314E4C49; // ILN1
        private const int RiskPayloadMarker = 0x31524C49; // ILR1, optional risk tail
        private const float DurationLimit = 10000000f;
        private const int MaximumRollsPerTick = 256;
        private const int MaximumSourceIDLength = 128;
        private static readonly UTF8Encoding StrictUtf8 = new UTF8Encoding(false, true);

        [Header("Системы персонажа")]
        [SerializeField] private K_HealthSystem _health;
        private K_VitalitySystem _vitality;

        [Header("Простуда — игровой баланс")]
        [SerializeField, Min(0.1f), Tooltip("Игровое время болезни. Это сокращённая длительность для игры, не медицинский срок.")]
        private float _coldDuration = 600f;
        [SerializeField, Min(0.1f), Tooltip("Время контакта с дополнительным явно заданным вирусным источником. Основной риск простуды на морозе настраивается ниже.")]
        private float _viralExposureThreshold = 30f;
        [Header("Риск простуды на морозе")]
        [SerializeField, Tooltip("При этой температуре и ниже начинается накопление времени на морозе.")]
        private float _coldRiskTemperature = 0f;
        [SerializeField, Min(1f), Tooltip("Минимальное время на морозе без защиты перед первым броском вероятности.")]
        private float _coldRiskDelay = 120f;
        [SerializeField, Min(1f), Tooltip("Интервал следующих бросков вероятности на морозе. Бросок выполняется по времени, а не каждый кадр.")]
        private float _coldRiskRollInterval = 60f;
        [SerializeField, Range(0f, 1f), Tooltip("Вероятность одного броска у порога мороза: 0.15 означает 15%.")]
        private float _coldRiskChance = .15f;
        [SerializeField, Tooltip("При этой температуре и ниже действует повышенная вероятность простуды.")]
        private float _severeColdTemperature = -15f;
        [SerializeField, Range(0f, 1f), Tooltip("Вероятность одного броска при сильном морозе: 0.30 означает 30%.")]
        private float _severeColdRiskChance = .30f;
        [SerializeField, Min(0f), Tooltip("Сколько накопленных секунд мороза снимается за секунду в тепле.")]
        private float _coldRiskWarmRecovery = 2f;
        [SerializeField, Range(0f, 1f), Tooltip("Защита одежды от простуды: 0 — без защиты, 1 — полная. До появления одежды оставьте 0. Будущая экипировка может менять её через SetColdProtection01.")]
        private float _coldProtection01;
        [Header("Простуда — восстановление")]
        [SerializeField, Min(1f), Tooltip("Во сколько раз быстрее уменьшается остаток простуды в покое.")]
        private float _coldRestRecoveryMultiplier = 1.5f;
        [SerializeField, Range(0.1f, 1f), Tooltip("Скорость действий при простуде: 0.9 означает 90% обычной скорости.")]
        private float _coldActionSpeedMultiplier = 0.9f;
        [SerializeField, Range(0.1f, 1f), Tooltip("Восстановление выносливости при простуде: 0.9 означает 90% обычной скорости.")]
        private float _coldStaminaRegenMultiplier = 0.9f;

        [Header("Инфекция раны — игровой баланс")]
        [SerializeField, Min(0.1f), Tooltip("Время открытой раны или необработанного огнестрела до первого броска вероятности инфекции. Кровотечение не требуется; обработка до заражения сбрасывает накопление.")]
        private float _woundInfectionDelay = 180f;
        [SerializeField, Min(1f), Tooltip("Интервал повторных бросков вероятности, пока рана остаётся открытой или огнестрел не обработан.")]
        private float _woundInfectionRollInterval = 60f;
        [SerializeField, Range(0f, 1f), Tooltip("Вероятность инфекции при одном броске: 0.25 означает 25%. Таймер сам по себе не гарантирует заражение.")]
        private float _woundInfectionChance = .25f;
        [SerializeField, Min(0.1f), Tooltip("Время восстановления заражённого участка при обработанной ране и действующем курсе антибиотика.")]
        private float _infectionRecoveryDuration = 180f;
        [SerializeField, Min(0.1f), Tooltip("Длительность игрового этапа лечения после применения антибиотика. Расход доз и число применений задаются у самого предмета.")]
        private float _antibioticDuration = 240f;

        private float _coldRemaining, _coldFullDuration, _viralExposure;
        private float _antibioticRemaining, _antibioticFullDuration;
        private string _antibioticSourceItemID = string.Empty;
        private readonly float[] _woundExposure = new float[PartCount];
        private readonly bool[] _infected = new bool[PartCount];
        private readonly float[] _infectionRecovery = new float[PartCount];
        private float _coldRiskExposure, _coldNextRiskRoll;
        private uint _coldRandomState = FreshRandomState();
        private readonly float[] _woundNextRiskRoll = new float[PartCount];
        private readonly uint[] _woundRandomStates = CreateRandomStates();

        public event Action OnIllnessesChanged;
        public string SaveID => "PlayerIllness";
        public bool IsDirty { get; set; } = true;
        public bool HasCold => _coldRemaining > 0f;
        public float ColdSecondsRemaining => Mathf.Max(0f, _coldRemaining);
        public float ColdFullDuration => _coldFullDuration;
        public float ColdActionSpeedMultiplier => HasCold ? SafeMultiplier(_coldActionSpeedMultiplier) : 1f;
        public float ColdStaminaRegenMultiplier => HasCold ? SafeMultiplier(_coldStaminaRegenMultiplier) : 1f;
        public bool HasWoundInfection => WoundInfectionCount > 0;
        public int WoundInfectionCount
        {
            get { int count = 0; for (int i = 0; i < PartCount; i++) if (_infected[i]) count++; return count; }
        }
        public float AntibioticSecondsRemaining => Mathf.Max(0f, _antibioticRemaining);
        public float AntibioticFullDuration => _antibioticFullDuration;
        public string AntibioticSourceItemID => _antibioticRemaining > 0f ? _antibioticSourceItemID : string.Empty;
        public bool CanStartAntibioticCourse => IsAlive && HasWoundInfection && _antibioticRemaining <= 0f;
        public float ColdRiskExposureSeconds => Mathf.Max(0f, _coldRiskExposure);
        public float ColdProtection01 => SafeChance(_coldProtection01);
        public float GetWoundRiskExposureSeconds(BodyPart part) => ValidPart(part) ? Mathf.Max(0f, _woundExposure[(int)part]) : 0f;
        private bool IsAlive => _health != null && !_health.IsDead;

        public void Initialize(K_HealthSystem health)
        {
            if (health != null) _health = health;
            _vitality = _health != null ? _health.GetComponent<K_VitalitySystem>() : null;
        }
        private void Awake() { if (_health == null) Initialize(GetComponent<K_HealthSystem>()); }
        private void Start() => K_SaveManager.Instance?.Register(this);
        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
            OnIllnessesChanged = null;
        }
        private void Update() => Tick(Time.deltaTime);
        public void SetColdProtection01(float protection) => _coldProtection01 = SafeChance(protection);

        public bool IsWoundInfected(BodyPart part) => ValidPart(part) && _infected[(int)part];
        public bool IsWoundAtRiskOfInfection(BodyPart part)
            => ValidPart(part) && _health != null &&
               (_health.GetLacerationType(part) == LacerationType.Open || _health.IsGunshot(part));
        public float GetWoundInfectionRecoverySeconds(BodyPart part)
            => IsWoundInfected(part) ? Mathf.Max(0f, _infectionRecovery[(int)part]) : 0f;
        public bool IsWoundInfectionRecovering(BodyPart part)
            => IsAlive && IsWoundInfected(part) && _antibioticRemaining > 0f && IsWoundPrepared(part);

        /// <summary>Optional explicit viral exposure; freezing risk has its own time-and-chance schedule.</summary>
        public bool ReportViralExposure(float exposureSeconds)
        {
            if (!IsAlive || HasCold || !FinitePositive(exposureSeconds)) return false;
            _viralExposure = Mathf.Min(DurationLimit, _viralExposure + exposureSeconds);
            IsDirty = true;
            if (_viralExposure >= SafeDuration(_viralExposureThreshold, 30f)) return ApplyCold();
            return true;
        }

        public bool ApplyCold(float duration = -1f)
        {
            if (!IsAlive || float.IsNaN(duration) || float.IsInfinity(duration)) return false;
            float accepted = duration < 0f ? SafeDuration(_coldDuration, 600f) : duration;
            if (!FinitePositive(accepted) || accepted > DurationLimit || HasCold) return false;
            _coldRemaining = _coldFullDuration = accepted;
            _viralExposure = 0f;
            _coldRiskExposure = _coldNextRiskRoll = 0f;
            Changed();
            return true;
        }

        /// <summary>Applies a real local illness; intact skin is not a wound source.</summary>
        public bool ApplyWoundInfection(BodyPart part)
        {
            if (!IsAlive || !ValidPart(part) || _infected[(int)part] ||
                (_health.GetLacerationType(part) == LacerationType.None && !_health.IsGunshot(part))) return false;
            int index = (int)part;
            _infected[index] = true;
            _infectionRecovery[index] = SafeDuration(_infectionRecoveryDuration, 180f);
            _woundExposure[index] = 0f;
            _woundNextRiskRoll[index] = 0f;
            Changed();
            return true;
        }

        public bool StartAntibioticCourse(float duration = -1f, string sourceItemID = "amoxiclav")
        {
            if (!CanStartAntibioticCourse || float.IsNaN(duration) || float.IsInfinity(duration) || !ValidSourceID(sourceItemID)) return false;
            float accepted = duration < 0f ? SafeDuration(_antibioticDuration, 240f) : duration;
            if (!FinitePositive(accepted) || accepted > DurationLimit) return false;
            _antibioticRemaining = _antibioticFullDuration = accepted;
            _antibioticSourceItemID = sourceItemID;
            Changed();
            return true;
        }

        public void ClearCold()
        {
            _coldRemaining = _coldFullDuration = _viralExposure = 0f;
            _coldRiskExposure = _coldNextRiskRoll = 0f;
            Changed();
        }
        public bool ClearWoundInfection(BodyPart part)
        {
            if (!ValidPart(part)) return false;
            int index = (int)part;
            bool changed = _infected[index] || _woundExposure[index] > 0f;
            _infected[index] = false;
            _woundExposure[index] = _infectionRecovery[index] = 0f;
            _woundNextRiskRoll[index] = 0f;
            if (changed) Changed();
            return changed;
        }
        public bool SetColdRemainingSeconds(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds < 0f || seconds > DurationLimit) return false;
            if (seconds == 0f) { ClearCold(); return true; }
            if (!IsAlive) return false;
            _coldRemaining = seconds;
            _coldFullDuration = Mathf.Max(_coldFullDuration, seconds);
            _viralExposure = 0f;
            _coldRiskExposure = _coldNextRiskRoll = 0f;
            Changed();
            return true;
        }
        public bool SetAntibioticRemainingSeconds(float seconds)
        {
            if (float.IsNaN(seconds) || float.IsInfinity(seconds) || seconds < 0f || seconds > DurationLimit) return false;
            if (seconds > 0f && (!IsAlive || (_antibioticRemaining <= 0f && !HasWoundInfection))) return false;
            _antibioticRemaining = seconds;
            _antibioticFullDuration = seconds > 0f ? Mathf.Max(_antibioticFullDuration, seconds) : 0f;
            _antibioticSourceItemID = seconds <= 0f ? string.Empty : ValidSourceID(_antibioticSourceItemID) ? _antibioticSourceItemID : "amoxiclav";
            Changed();
            return true;
        }

        /// <summary>Game-time tick. Closing the inventory has no effect on this owner.</summary>
        public void Tick(float deltaTime)
        {
            if (!IsAlive || !FinitePositive(deltaTime)) return;
            deltaTime = Mathf.Min(deltaTime, DurationLimit);
            bool transition = false;
            bool hadCold = HasCold;
            float antibioticWindow = Mathf.Min(deltaTime, _antibioticRemaining);
            if (_coldRemaining > 0f)
            {
                float rate = _health.IsRestingForRecovery ? SafeDuration(_coldRestRecoveryMultiplier, 1.5f) : 1f;
                _coldRemaining = Mathf.Max(0f, _coldRemaining - deltaTime * Mathf.Max(1f, rate));
                IsDirty = true;
                if (_coldRemaining <= 0f) { _coldFullDuration = 0f; transition = true; }
            }
            if (!hadCold) transition |= AdvanceColdRisk(deltaTime);
            if (_antibioticRemaining > 0f)
            {
                _antibioticRemaining = Mathf.Max(0f, _antibioticRemaining - deltaTime);
                IsDirty = true;
                if (_antibioticRemaining <= 0f) { _antibioticFullDuration = 0f; _antibioticSourceItemID = string.Empty; transition = true; }
            }
            for (int i = 0; i < PartCount; i++)
            {
                var part = (BodyPart)i;
                if (!_infected[i])
                {
                    if (IsWoundAtRiskOfInfection(part))
                    {
                        _woundExposure[i] = Mathf.Min(DurationLimit, _woundExposure[i] + deltaTime);
                        IsDirty = true;
                        float interval = SafeInterval(_woundInfectionRollInterval, 60f);
                        if (_woundNextRiskRoll[i] <= 0f) _woundNextRiskRoll[i] = SafeDuration(_woundInfectionDelay, 180f);
                        float chance = SafeChance(_woundInfectionChance);
                        if (chance <= 0f)
                            SkipFailedRolls(_woundExposure[i], interval, ref _woundNextRiskRoll[i]);
                        int rolls = 0;
                        while (_woundExposure[i] >= _woundNextRiskRoll[i] && rolls++ < MaximumRollsPerTick)
                        {
                            _woundNextRiskRoll[i] = Mathf.Min(DurationLimit, _woundNextRiskRoll[i] + interval);
                            if (!Roll(chance, ref _woundRandomStates[i])) continue;
                            _infected[i] = true;
                            _infectionRecovery[i] = SafeDuration(_infectionRecoveryDuration, 180f);
                            _woundExposure[i] = _woundNextRiskRoll[i] = 0f;
                            transition = true;
                            break;
                        }
                    }
                    else if (_woundExposure[i] > 0f || _woundNextRiskRoll[i] > 0f)
                    { _woundExposure[i] = _woundNextRiskRoll[i] = 0f; IsDirty = true; }
                    continue;
                }
                if (antibioticWindow <= 0f || !IsWoundPrepared(part)) continue;
                _infectionRecovery[i] = Mathf.Max(0f, _infectionRecovery[i] - antibioticWindow);
                IsDirty = true;
                if (_infectionRecovery[i] <= 0f) { _infected[i] = false; transition = true; }
            }
            if (transition) OnIllnessesChanged?.Invoke();
        }

        private bool AdvanceColdRisk(float deltaTime)
        {
            if (_vitality == null) _vitality = _health.GetComponent<K_VitalitySystem>();
            if (_vitality == null) return false;
            float temperature = _vitality.CurrentTemperature;
            if (float.IsNaN(temperature) || float.IsInfinity(temperature)) return false;
            float threshold = SafeTemperature(_coldRiskTemperature, 0f);
            float protection = ColdProtection01;
            if (temperature > threshold || protection >= 1f)
            {
                float recovery = float.IsNaN(_coldRiskWarmRecovery) || float.IsInfinity(_coldRiskWarmRecovery)
                    ? 2f : Mathf.Max(0f, _coldRiskWarmRecovery);
                if (_coldRiskExposure > 0f)
                {
                    _coldRiskExposure = Mathf.Max(0f, _coldRiskExposure - deltaTime * recovery);
                    if (_coldRiskExposure <= 0f) _coldNextRiskRoll = 0f;
                    IsDirty = true;
                }
                return false;
            }
            float exposureRate = 1f - protection;
            float previousExposure = _coldRiskExposure;
            _coldRiskExposure = Mathf.Min(DurationLimit, _coldRiskExposure + deltaTime * exposureRate);
            if (_coldNextRiskRoll <= 0f) _coldNextRiskRoll = SafeDuration(_coldRiskDelay, 120f);
            float severe = Mathf.Min(threshold - .1f, SafeTemperature(_severeColdTemperature, -15f));
            float chance = Mathf.Lerp(SafeChance(_coldRiskChance), SafeChance(_severeColdRiskChance),
                Mathf.InverseLerp(threshold, severe, temperature)) * exposureRate;
            float interval = SafeInterval(_coldRiskRollInterval, 60f);
            IsDirty = true;
            if (chance <= 0f) { SkipFailedRolls(_coldRiskExposure, interval, ref _coldNextRiskRoll); return false; }
            int rolls = 0;
            while (_coldRiskExposure >= _coldNextRiskRoll && rolls++ < MaximumRollsPerTick)
            {
                float rollAt = _coldNextRiskRoll;
                _coldNextRiskRoll = Mathf.Min(DurationLimit, _coldNextRiskRoll + interval);
                if (!Roll(chance, ref _coldRandomState)) continue;
                float elapsedToRoll = Mathf.Max(0f, (rollAt - previousExposure) / exposureRate);
                float afterAcquisition = Mathf.Max(0f, deltaTime - elapsedToRoll);
                _coldRemaining = _coldFullDuration = SafeDuration(_coldDuration, 600f);
                _viralExposure = _coldRiskExposure = _coldNextRiskRoll = 0f;
                float recoveryRate = _health.IsRestingForRecovery ? Mathf.Max(1f, SafeDuration(_coldRestRecoveryMultiplier, 1.5f)) : 1f;
                _coldRemaining = Mathf.Max(0f, _coldRemaining - afterAcquisition * recoveryRate);
                if (_coldRemaining <= 0f) _coldFullDuration = 0f;
                return true;
            }
            return false;
        }

        private static void SkipFailedRolls(float exposure, float interval, ref float nextRoll)
        {
            if (exposure < nextRoll) return;
            double skipped = Math.Floor(((double)exposure - nextRoll) / interval) + 1d;
            nextRoll = (float)Math.Min(DurationLimit, nextRoll + skipped * interval);
        }
        private static float SafeTemperature(float value, float fallback)
            => float.IsNaN(value) || float.IsInfinity(value) ? fallback : Mathf.Clamp(value, -100f, 100f);
        private static float SafeInterval(float value, float fallback) => Mathf.Max(1f, SafeDuration(value, fallback));
        private static float SafeChance(float value) => float.IsNaN(value) || float.IsInfinity(value) ? 0f : Mathf.Clamp01(value);
        private static uint FreshRandomState()
        { uint seed = unchecked((uint)Guid.NewGuid().GetHashCode()); return seed == 0 ? 0x6D2B79F5u : seed; }
        private static uint[] CreateRandomStates()
        {
            var states = new uint[PartCount];
            for (int i = 0; i < states.Length; i++) states[i] = FreshRandomState();
            return states;
        }
        private static bool Roll(float chance, ref uint state)
        {
            if (chance <= 0f) return false;
            if (chance >= 1f) return true;
            if (state == 0) state = 0x6D2B79F5u;
            state ^= state << 13; state ^= state >> 17; state ^= state << 5;
            return (state >> 8) * (1f / 16777216f) < chance;
        }

        private bool IsWoundPrepared(BodyPart part)
            => _health.GetLacerationType(part) != LacerationType.Open &&
               _health.GetBleedingLevel(part) <= 0 && !_health.IsGunshot(part);

        public void ClearIllnesses()
        {
            ResetState();
            Changed();
        }
        private void ResetState()
        {
            _coldRemaining = _coldFullDuration = _viralExposure = 0f;
            _antibioticRemaining = _antibioticFullDuration = 0f;
            _antibioticSourceItemID = string.Empty;
            _coldRiskExposure = _coldNextRiskRoll = 0f;
            Array.Clear(_woundExposure, 0, PartCount);
            Array.Clear(_infected, 0, PartCount);
            Array.Clear(_infectionRecovery, 0, PartCount);
            Array.Clear(_woundNextRiskRoll, 0, PartCount);
        }
        private void Changed() { IsDirty = true; OnIllnessesChanged?.Invoke(); }
        private static bool ValidPart(BodyPart part) => (int)part >= 0 && (int)part < PartCount;
        private static bool FinitePositive(float value) => !float.IsNaN(value) && !float.IsInfinity(value) && value > 0f;
        private static float SafeDuration(float value, float fallback)
            => FinitePositive(value) ? Mathf.Min(value, DurationLimit) : fallback;
        private static float SafeMultiplier(float value)
            => float.IsNaN(value) || float.IsInfinity(value) ? 1f : Mathf.Clamp(value, .1f, 1f);

        public void Save(BinaryWriter writer)
        {
            writer.Write(PayloadMarker);
            writer.Write(_coldRemaining); writer.Write(_coldFullDuration); writer.Write(_viralExposure);
            writer.Write(_antibioticRemaining); writer.Write(_antibioticFullDuration);
            writer.Write(PartCount);
            for (int i = 0; i < PartCount; i++)
            {
                writer.Write(_woundExposure[i]); writer.Write(_infected[i]); writer.Write(_infectionRecovery[i]);
            }
            writer.Write(RiskPayloadMarker);
            writer.Write(_coldRiskExposure); writer.Write(_coldNextRiskRoll); writer.Write(_coldRandomState);
            for (int i = 0; i < PartCount; i++)
            { writer.Write(_woundNextRiskRoll[i]); writer.Write(_woundRandomStates[i]); }
            byte[] sourceBytes = StrictUtf8.GetBytes(_antibioticSourceItemID);
            writer.Write(sourceBytes.Length); writer.Write(sourceBytes);
        }

        public void Load(BinaryReader reader)
        {
            var state = ReadState(reader);
            _coldRemaining = state.Cold; _coldFullDuration = state.ColdFull; _viralExposure = state.Exposure;
            _antibioticRemaining = state.Antibiotic; _antibioticFullDuration = state.AntibioticFull;
            _antibioticSourceItemID = state.AntibioticSourceID;
            Array.Copy(state.WoundExposure, _woundExposure, PartCount);
            Array.Copy(state.Infected, _infected, PartCount);
            Array.Copy(state.Recovery, _infectionRecovery, PartCount);
            _coldRiskExposure = state.ColdExposure; _coldNextRiskRoll = state.ColdNextRoll;
            Array.Copy(state.WoundNextRoll, _woundNextRiskRoll, PartCount);
            if (state.HasRiskTail)
            {
                _coldRandomState = state.ColdRandomState;
                Array.Copy(state.WoundRandomStates, _woundRandomStates, PartCount);
            }
            IsDirty = false;
        }
        public void ValidateLoad(BinaryReader reader, SaveLoadValidationContext context) => ReadState(reader);
        public void OnBeforeLoad() { ResetState(); IsDirty = false; }
        public void OnAfterLoad() => OnIllnessesChanged?.Invoke();

        private sealed class State
        {
            public float Cold, ColdFull, Exposure, Antibiotic, AntibioticFull;
            public readonly float[] WoundExposure = new float[PartCount];
            public readonly bool[] Infected = new bool[PartCount];
            public readonly float[] Recovery = new float[PartCount];
            public bool HasRiskTail;
            public float ColdExposure, ColdNextRoll;
            public uint ColdRandomState;
            public string AntibioticSourceID = string.Empty;
            public readonly float[] WoundNextRoll = new float[PartCount];
            public readonly uint[] WoundRandomStates = new uint[PartCount];
        }
        private static State ReadState(BinaryReader reader)
        {
            if (reader.ReadInt32() != PayloadMarker) throw new InvalidDataException("Invalid illness payload marker.");
            var state = new State
            {
                Cold = ReadTime(reader), ColdFull = ReadTime(reader), Exposure = ReadTime(reader),
                Antibiotic = ReadTime(reader), AntibioticFull = ReadTime(reader)
            };
            if (state.Cold > state.ColdFull || (state.Cold <= 0f && state.ColdFull != 0f) ||
                (state.Cold > 0f && state.Exposure != 0f) ||
                state.Antibiotic > state.AntibioticFull || (state.Antibiotic <= 0f && state.AntibioticFull != 0f))
                throw new InvalidDataException("Inconsistent saved illness timer.");
            state.AntibioticSourceID = state.Antibiotic > 0f ? "amoxiclav" : string.Empty;
            if (reader.ReadInt32() != PartCount) throw new InvalidDataException("Invalid illness part count.");
            for (int i = 0; i < PartCount; i++)
            {
                state.WoundExposure[i] = ReadTime(reader);
                byte infected = reader.ReadByte();
                if (infected > 1) throw new InvalidDataException("Invalid infection flag.");
                state.Infected[i] = infected == 1;
                state.Recovery[i] = ReadTime(reader);
                if (state.Infected[i] != (state.Recovery[i] > 0f) ||
                    (state.Infected[i] && state.WoundExposure[i] != 0f))
                    throw new InvalidDataException("Inconsistent saved wound infection.");
            }
            if (reader.BaseStream.Position < reader.BaseStream.Length)
            {
                if (reader.ReadInt32() != RiskPayloadMarker) throw new InvalidDataException("Invalid illness risk marker.");
                state.HasRiskTail = true;
                state.ColdExposure = ReadTime(reader); state.ColdNextRoll = ReadTime(reader);
                state.ColdRandomState = reader.ReadUInt32();
                if (state.ColdRandomState == 0 ||
                    (state.Cold > 0f && (state.ColdExposure != 0f || state.ColdNextRoll != 0f)) ||
                    (state.ColdExposure == 0f && state.ColdNextRoll != 0f) ||
                    (state.ColdExposure > 0f && state.ColdNextRoll <= 0f))
                    throw new InvalidDataException("Inconsistent saved cold risk.");
                for (int i = 0; i < PartCount; i++)
                {
                    state.WoundNextRoll[i] = ReadTime(reader);
                    state.WoundRandomStates[i] = reader.ReadUInt32();
                    if (state.WoundRandomStates[i] == 0 ||
                        (state.Infected[i] && state.WoundNextRoll[i] != 0f) ||
                        (state.WoundExposure[i] == 0f && state.WoundNextRoll[i] != 0f) ||
                        (state.WoundExposure[i] > 0f && state.WoundNextRoll[i] <= 0f))
                        throw new InvalidDataException("Inconsistent saved wound risk.");
                }
                if (reader.BaseStream.Position < reader.BaseStream.Length)
                {
                    int sourceLength = reader.ReadInt32();
                    if (sourceLength < 0 || sourceLength > MaximumSourceIDLength * 4)
                        throw new InvalidDataException("Invalid antibiotic source length.");
                    byte[] bytes = reader.ReadBytes(sourceLength);
                    if (bytes.Length != sourceLength) throw new EndOfStreamException("Truncated antibiotic source.");
                    state.AntibioticSourceID = StrictUtf8.GetString(bytes);
                    if ((state.Antibiotic > 0f && !ValidSourceID(state.AntibioticSourceID)) ||
                        (state.Antibiotic <= 0f && state.AntibioticSourceID.Length != 0))
                        throw new InvalidDataException("Inconsistent antibiotic source.");
                }
            }
            if (reader.BaseStream.Position != reader.BaseStream.Length)
                throw new InvalidDataException("Unexpected illness payload bytes.");
            return state;
        }
        private static float ReadTime(BinaryReader reader)
        {
            float value = SaveLoadValidationContext.ReadFinite(reader, true);
            if (value > DurationLimit) throw new InvalidDataException("Saved illness time exceeds its limit.");
            return value;
        }
        private static bool ValidSourceID(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || value.Length > MaximumSourceIDLength) return false;
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                if (char.IsControl(c)) return false;
                if (!char.IsSurrogate(c)) continue;
                if (!char.IsHighSurrogate(c) || i + 1 >= value.Length || !char.IsLowSurrogate(value[i + 1])) return false;
                i++;
            }
            return true;
        }
    }
}
