
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Одна запись матрицы совместимости:
    /// какой ItemID к каким зонам применим, что лечит, сколько применяется,
    /// прерывается ли уроном.
    ///
    /// 6.4.2: добавлены 3 опциональных поля — HPRestoreAmount, BloodRestoreMl,
    /// EffectDuration. В конструктор не вынесены (defaults из SerializeField).
    /// </summary>
    [System.Serializable]
    public class MedicalEntry
    {
        [SerializeField] private string _itemID;
        [SerializeField] private string _displayName;

        [SerializeField] private BodyPartMask _validParts = BodyPartMask.None;
        [SerializeField] private MedicalEffect _effects = MedicalEffect.None;

        [SerializeField, Min(0f)] private float _useDuration = 1f;
        [SerializeField] private bool _cancelableByDamage = true;

        // ═══ Этап 6.4: параметры эффектов ═══
        [SerializeField, Min(0f), Tooltip("Сколько HP восстановить при HPRestore (за один apply).")]
        private float _hpRestoreAmount = 20f;

        [SerializeField, Min(0f), Tooltip("Сколько мл крови восстановить при BloodRestore.")]
        private float _bloodRestoreMl = 500f;

        [SerializeField, Min(0f), Tooltip("Длительность временного действия средства (секунды игрового времени).")]
        private float _effectDuration = 120f;

        [SerializeField, Tooltip("Использовать выбранные эффекты и зоны этой записи без старых правил по ItemID. Включайте для новых вариантов и при перенастройке прежнего средства.")]
        private bool _useConfiguredEffects;
        [SerializeField, Tooltip("Задать силу, задержки и дополнительные сроки именно этого средства. Выключено — прежние настройки систем персонажа.")]
        private bool _useCustomParameters;
        [SerializeField] private MedicalEffectParameters _parameters = new MedicalEffectParameters();

        public string ItemID => _itemID;
        public string DisplayName => _displayName;
        // Compatibility rules are resolved on read, so existing scene/asset data
        // and every consumer of the entry agree without rewriting serialized fields.
        public BodyPartMask ValidParts => MedicalDatabase.ResolveValidParts(_useConfiguredEffects ? null : _itemID, Effects, _validParts);
        public MedicalEffect Effects => _useConfiguredEffects ? _effects : MedicalDatabase.ResolveEffects(_itemID, _effects);
        public float UseDuration => _useDuration;
        public bool CancelableByDamage => _cancelableByDamage;

        // ═══ Этап 6.4: геттеры параметров эффектов ═══
        public float HPRestoreAmount => _hpRestoreAmount;
        public float BloodRestoreMl => _bloodRestoreMl;
        public float EffectDuration => _effectDuration;
        public bool UseConfiguredEffects => _useConfiguredEffects;
        public bool UseCustomParameters => _useCustomParameters;
        public MedicalEffectParameters Parameters => _parameters;
        public bool HasValidParameters => !_useCustomParameters || (_parameters != null && _parameters.IsValid);
        public bool HasValidSourceItemID => IsValidSourceItemID(_itemID);

        /// <summary>Identity limits shared by authoring, admission and bounded medical save tails.</summary>
        public static bool IsValidSourceItemID(string value)
        {
            if (string.IsNullOrWhiteSpace(value) || value.Length > 128) return false;
            for (int i = 0; i < value.Length; i++)
            {
                char c = value[i];
                if (char.IsControl(c)) return false;
                if (!char.IsSurrogate(c)) continue;
                if (!char.IsHighSurrogate(c) || i + 1 >= value.Length || !char.IsLowSurrogate(value[i + 1])) return false;
                i++;
            }
            return true;
        }

        // Only the freshly generated template is repaired; configured assets are not migrated here.
        internal void ConfigureTransamachaTemplate()
        {
            if (_displayName == "Трансамача" || _displayName == "Транексам (TXA)") _effects = MedicalEffect.Transamacha;
        }

        // Stage 4: narrow asset repair preserves every unrelated serialized field.
        internal bool ConfigureMechanicalJETT()
        {
            var parents = BodyPartMask.LeftShoulder | BodyPartMask.RightShoulder |
                BodyPartMask.LeftQuadriceps | BodyPartMask.RightQuadriceps;
            var effects = (_effects & ~MedicalEffect.InternalBleeding) | MedicalEffect.JETT;
            if (_validParts == parents && _effects == effects) return false;
            _validParts = parents;
            _effects = effects;
            return true;
        }

        public MedicalEntry() { }

        public MedicalEntry(
            string itemID,
            string displayName,
            BodyPartMask validParts,
            MedicalEffect effects,
            float useDuration,
            bool cancelableByDamage,
            float effectDuration = 120f)
        {
            _itemID = itemID;
            _displayName = displayName;
            _validParts = validParts;
            _effects = effects;
            _useDuration = Mathf.Max(0f, useDuration);
            _cancelableByDamage = cancelableByDamage;
            _effectDuration = Mathf.Max(0f, effectDuration);
        }
    }

    /// <summary>Per-item tuning for existing medical mechanics; no ItemID branches are needed.</summary>
    [System.Serializable]
    public sealed class MedicalEffectParameters
    {
        [Header("Обезболивание")]
        [SerializeField, Range(0f,1f), Tooltip("Доля ослабления болевой составляющей: 0.35 = 35%.")]
        private float _painReliefFraction = .35f;
        [SerializeField, Min(0f), Tooltip("Задержка перед началом обезболивания, секунды. Длительность самого действия задаётся Effect Duration записи.")]
        private float _painkillerOnsetSeconds = 15f;
        [SerializeField, Min(.01f), Tooltip("Скорость действий под обезболиванием: 1 — обычная, 0.9 — 90%.")]
        private float _painkillerActionSpeedMultiplier = 1f;
        [Header("Стимулятор")]
        [SerializeField, Min(0f)] private float _stimCooldownSeconds = 200f;
        [SerializeField, Min(0f)] private float _stimFatigueSeconds = 30f;
        [SerializeField, Min(.01f)] private float _stimActionSpeedMultiplier = 1.1f;
        [SerializeField, Min(.01f)] private float _stimStaminaMultiplier = 1.5f;
        [SerializeField, Range(0f,140f)] private float _stimPulseBonus = 10f;
        [SerializeField, Min(.01f)] private float _stimFatigueActionSpeedMultiplier = .85f;
        [SerializeField, Min(.01f)] private float _stimFatigueStaminaMultiplier = .75f;
        [Header("Кровопотеря и восстановление")]
        [SerializeField, Range(0f,1f), Tooltip("Остаток кровопотери во время TXA: 0.5 означает вдвое меньше фактических мл/с.")]
        private float _bloodLossMultiplier = .5f;
        [SerializeField, Min(.01f), Tooltip("Восстановление зафиксированного перелома в покое. Для средства от ЧМТ используется Effect Duration записи.")]
        private float _fractureRecoverySeconds = 240f;
        [SerializeField, Min(1f), Tooltip("Множитель восстановления обработанных мягких тканей под гидрогелем.")]
        private float _healingMultiplier = 5f;

        public float PainReliefFraction => _painReliefFraction;
        public float PainkillerOnsetSeconds => _painkillerOnsetSeconds;
        public float PainkillerActionSpeedMultiplier => _painkillerActionSpeedMultiplier;
        public float StimCooldownSeconds => _stimCooldownSeconds;
        public float StimFatigueSeconds => _stimFatigueSeconds;
        public float StimActionSpeedMultiplier => _stimActionSpeedMultiplier;
        public float StimStaminaMultiplier => _stimStaminaMultiplier;
        public float StimPulseBonus => _stimPulseBonus;
        public float StimFatigueActionSpeedMultiplier => _stimFatigueActionSpeedMultiplier;
        public float StimFatigueStaminaMultiplier => _stimFatigueStaminaMultiplier;
        public float BloodLossMultiplier => _bloodLossMultiplier;
        public float FractureRecoverySeconds => _fractureRecoverySeconds;
        public float HealingMultiplier => _healingMultiplier;
        private static bool Range(float v,float min,float max) => !float.IsNaN(v)&&!float.IsInfinity(v)&&v>=min&&v<=max;
        public bool IsValid => Range(_painReliefFraction,0f,1f)&&Range(_painkillerOnsetSeconds,0f,86400f)&&
            Range(_painkillerActionSpeedMultiplier,.01f,100f)&&Range(_stimCooldownSeconds,0f,86400f)&&
            Range(_stimFatigueSeconds,0f,86400f)&&Range(_stimActionSpeedMultiplier,.01f,100f)&&
            Range(_stimStaminaMultiplier,.01f,100f)&&Range(_stimPulseBonus,0f,140f)&&
            Range(_stimFatigueActionSpeedMultiplier,.01f,100f)&&Range(_stimFatigueStaminaMultiplier,.01f,100f)&&
            Range(_bloodLossMultiplier,0f,1f)&&Range(_fractureRecoverySeconds,.01f,86400f)&&Range(_healingMultiplier,1f,100f);
    }
}
