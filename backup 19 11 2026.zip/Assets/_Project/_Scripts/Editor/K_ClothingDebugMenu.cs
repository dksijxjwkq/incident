using System;
using System.Linq;
using UnityEditor;
using UnityEngine;
using K_Incident.Core;
using K_Incident.Core.Inventory;

namespace K_Incident.EditorTools
{
    public static class K_ClothingDebugMenu
    {
        const string Menu = "Incident/Тесты/Одежда/Выдать и надеть базовый комплект (Play)";
        static readonly string[] IDs = { "clothing_hat_wool", "clothing_jacket_insulated", "clothing_pants_insulated", "clothing_boots_winter" };

        [MenuItem(Menu)]
        public static void GiveBasicOutfit()
        {
            if (!Application.isPlaying) return;
            var inventory = UnityEngine.Object.FindFirstObjectByType<K_InventoryUI>(FindObjectsInactive.Include);
            var database = K_InventorySetup.DatabaseInstance;
            var slots = Enumerable.Range(0, 4).Select(i => inventory?.GetClothingSlot((ClothingSlotKind)i)).ToArray();
            if (database == null || slots.Any(s => s == null || s.IsOccupied))
            {
                Debug.LogWarning("[Одежда] Для тестового комплекта нужны четыре свободных слота одежды.");
                return;
            }
            var data = IDs.Select(database.GetItemData).ToArray();
            if (data.Any(d => d == null)) { Debug.LogWarning("[Одежда] Базовые предметы не найдены в каталоге."); return; }
            var items = data.Select(d => new InventoryItem(d, GlobalIDManager.GenerateID(), 1, d.MaxDurability, false)).ToArray();
            try
            {
                for (int i = 0; i < slots.Length; i++) slots[i].SetEquippedItem(items[i]);
                inventory.ForceRefresh();
                Debug.Log("[Одежда] Базовый комплект надет. Это тестовая выдача; автоматического сохранения нет.");
            }
            catch
            {
                for (int i = 0; i < slots.Length; i++)
                    if (ReferenceEquals(slots[i].EquippedItem, items[i])) slots[i].SetEquippedItem(null);
                throw;
            }
        }

        [MenuItem(Menu, true)]
        public static bool CanGiveBasicOutfit() => Application.isPlaying;
    }
}
