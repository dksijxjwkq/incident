using System;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using K_Incident.Core;
using K_Incident.Core.Inventory;

namespace K_Incident.EditorTools
{
    [CustomEditor(typeof(MedicalDatabase))]
    public sealed class MedicalDatabaseEditor : Editor
    {
        public override VisualElement CreateInspectorGUI()
        {
            var root=new VisualElement();
            root.Add(new HelpBox("Каждая запись связывается с Item Static Data по Item ID. Физические свойства, иконка, стак и число применений находятся в предмете; лечебные свойства — ниже. Известные механики можно сочетать без добавления ID в код.",HelpBoxMessageType.Info));
            root.Add(new PropertyField(serializedObject.FindProperty("_entries"),"Лечебные средства"));
            var create=new Foldout{text="Создать или подключить предмет",value=false};root.Add(create);
            var items=new ObjectField("База предметов"){objectType=typeof(ItemDatabase),allowSceneObjects=false};create.Add(items);
            var chosen=new ObjectField("Готовый Item Static Data"){objectType=typeof(ItemStaticData),allowSceneObjects=false};create.Add(chosen);
            var ids=AssetDatabase.FindAssets("t:ItemDatabase");if(ids.Length==1)items.value=AssetDatabase.LoadAssetAtPath<ItemDatabase>(AssetDatabase.GUIDToAssetPath(ids[0]));
            var message=new HelpBox("Подключение не меняет уже настроенную медицинскую запись.",HelpBoxMessageType.Info);create.Add(message);
            create.Add(new Button(()=>
            {
                try{MedicalAuthoring.Register((MedicalDatabase)target,items.value as ItemDatabase,chosen.value as ItemStaticData);serializedObject.Update();message.text="Предмет подключён. Раскройте его запись и задайте эффекты.";}
                catch(Exception ex){message.text=ex.Message;}
            }){text="Подключить выбранный предмет"});
            var id=new TextField("Новый Item ID");var title=new TextField("Название");create.Add(id);create.Add(title);
            create.Add(new Button(()=>
            {
                try
                {
                    string path=EditorUtility.SaveFilePanelInProject("Новый медикамент","NewMedicine","asset","Выберите папку для Item Static Data.");
                    if(string.IsNullOrEmpty(path))return;
                    chosen.value=MedicalAuthoring.Create((MedicalDatabase)target,items.value as ItemDatabase,id.value,title.value,path);
                    serializedObject.Update();message.text="Созданы предмет и лечебная запись. У предмета настройте упаковку, иконку и размеры; в записи — лечебные характеристики.";
                }
                catch(Exception ex){message.text=ex.Message;}
            }){text="Создать предмет и лечебную запись"});
            create.Add(new Button(()=>{if(chosen.value!=null)Selection.activeObject=chosen.value;}){text="Открыть физические свойства предмета"});
            return root;
        }
    }

    [CustomPropertyDrawer(typeof(MedicalEntry))]
    public sealed class MedicalEntryDrawer : PropertyDrawer
    {
        public override VisualElement CreatePropertyGUI(SerializedProperty property)
        {
            var fold=new Foldout{text=property.FindPropertyRelative("_displayName").stringValue,value=false};
            void Field(string name,string label)=>fold.Add(new PropertyField(property.FindPropertyRelative(name),label));
            Field("_itemID","Item ID предмета");Field("_displayName","Название для панели здоровья");
            Field("_useConfiguredEffects","Использовать выбранные эффекты без правил по ID");
            Field("_effects","Лечебные эффекты");Field("_validParts","Допустимые участки");
            Field("_useDuration","Время применения, с");Field("_cancelableByDamage","Прерывать применение при уроне");
            Field("_effectDuration","Время действия / восстановление ЧМТ, с");
            Field("_hpRestoreAmount","Разовое восстановление HP");Field("_bloodRestoreMl","Объём переливания, мл");
            Field("_useCustomParameters","Индивидуальные параметры действия");
            var parameters=new Foldout{text="Сила, задержки и дополнительные сроки",value=false};fold.Add(parameters);
            var p=property.FindPropertyRelative("_parameters");
            void Parameter(string name,string label)=>parameters.Add(new PropertyField(p.FindPropertyRelative(name),label));
            Parameter("_painReliefFraction","Ослабление боли, 0–1");Parameter("_painkillerOnsetSeconds","Начало обезболивания через, с");
            Parameter("_painkillerActionSpeedMultiplier","Скорость действий под обезболиванием, ×");
            Parameter("_stimCooldownSeconds","Откат стимулятора, с");Parameter("_stimFatigueSeconds","Усталость после отката, с");
            Parameter("_stimActionSpeedMultiplier","Скорость действий под стимулятором, ×");Parameter("_stimStaminaMultiplier","Выносливость под стимулятором, ×");
            Parameter("_stimPulseBonus","Прибавка пульса, BPM");Parameter("_stimFatigueActionSpeedMultiplier","Скорость действий при усталости, ×");
            Parameter("_stimFatigueStaminaMultiplier","Выносливость при усталости, ×");
            Parameter("_bloodLossMultiplier","Остаток кровопотери под TXA, 0–1");Parameter("_fractureRecoverySeconds","Восстановление фиксированной кости, с");
            Parameter("_healingMultiplier","Заживление под гидрогелем, ×");
            parameters.Add(new HelpBox("Используются только параметры выбранных эффектов. Время действия относится к обезболиванию, стимулятору, TXA, гидрогелю и антибиотику. Фиксация требует отдельного времени восстановления; наклейки и турникеты остаются установленными. Глобальное действие и анатомические ограничения определяются видом лечебного эффекта.",HelpBoxMessageType.Info));
            void Refresh(){parameters.SetEnabled(property.FindPropertyRelative("_useCustomParameters").boolValue);fold.text=property.FindPropertyRelative("_displayName").stringValue;}
            fold.TrackPropertyValue(property.FindPropertyRelative("_useCustomParameters"),_=>Refresh());
            fold.TrackPropertyValue(property.FindPropertyRelative("_displayName"),_=>Refresh());Refresh();
            return fold;
        }
    }

    public static class MedicalAuthoring
    {
        public static void Register(MedicalDatabase medical,ItemDatabase items,ItemStaticData item)
        {
            if(EditorApplication.isPlayingOrWillChangePlaymode)throw new InvalidOperationException("Остановите Play Mode перед изменением каталога.");
            if(medical==null||items==null||item==null)throw new InvalidOperationException("Выберите обе базы и предмет.");
            if(!MedicalEntry.IsValidSourceItemID(item.ItemID)||item.PrefabID==0||item.Type!=ItemType.Medical)
                throw new InvalidOperationException("Нужен медицинский предмет с Item ID до 128 символов без управляющих знаков и Prefab ID > 0.");
            var data=new SerializedObject(items);var list=data.FindProperty("_items");
            bool found=false;
            for(int i=0;i<list.arraySize;i++)
            {
                var other=list.GetArrayElementAtIndex(i).objectReferenceValue as ItemStaticData;
                if(other==item){found=true;continue;}
                if(other!=null&&(other.ItemID==item.ItemID||other.PrefabID==item.PrefabID))throw new InvalidOperationException("Item ID или Prefab ID уже занят другим предметом.");
            }
            Undo.RecordObject(items,"Register medical item");Undo.RecordObject(medical,"Register medical treatment");
            if(!found){int i=list.arraySize;list.InsertArrayElementAtIndex(i);list.GetArrayElementAtIndex(i).objectReferenceValue=item;data.ApplyModifiedProperties();}
            if(medical.GetEntry(item.ItemID)==null)
            {
                medical.RegisterOrUpdate(new MedicalEntry(item.ItemID,item.DisplayName,BodyPartMask.All,MedicalEffect.None,2f,true,180f));
                var serialized=new SerializedObject(medical);var entries=serialized.FindProperty("_entries");
                for(int i=0;i<entries.arraySize;i++)if(entries.GetArrayElementAtIndex(i).FindPropertyRelative("_itemID").stringValue==item.ItemID)
                    entries.GetArrayElementAtIndex(i).FindPropertyRelative("_useConfiguredEffects").boolValue=true;
                serialized.ApplyModifiedProperties();
            }
            typeof(ItemDatabase).GetField("_isInitialized",System.Reflection.BindingFlags.Instance|System.Reflection.BindingFlags.NonPublic).SetValue(items,false);
            EditorUtility.SetDirty(items);EditorUtility.SetDirty(medical);AssetDatabase.SaveAssets();
        }
        public static ItemStaticData Create(MedicalDatabase medical,ItemDatabase items,string id,string title,string assetPath)
        {
            if(EditorApplication.isPlayingOrWillChangePlaymode)throw new InvalidOperationException("Остановите Play Mode перед созданием предмета.");
            if(medical==null||items==null||!MedicalEntry.IsValidSourceItemID(id)||string.IsNullOrWhiteSpace(title))
                throw new InvalidOperationException("Заполните обе базы, название и уникальный Item ID до 128 символов без управляющих знаков.");
            if(!assetPath.StartsWith("Assets/",StringComparison.Ordinal)||!assetPath.EndsWith(".asset",StringComparison.OrdinalIgnoreCase)||AssetDatabase.LoadMainAssetAtPath(assetPath)!=null)
                throw new InvalidOperationException("Нужен новый путь .asset внутри Assets.");
            var definitions=AssetDatabase.FindAssets("t:ItemStaticData").Select(AssetDatabase.GUIDToAssetPath).Select(AssetDatabase.LoadAssetAtPath<ItemStaticData>).Where(x=>x!=null).ToArray();
            if(definitions.Any(x=>x.ItemID==id)||medical.GetEntry(id)!=null)throw new InvalidOperationException("Такой Item ID уже существует.");
            var used=new System.Collections.Generic.HashSet<ushort>(definitions.Select(x=>x.PrefabID));
            ushort prefab=1;while(prefab<ushort.MaxValue&&used.Contains(prefab))prefab++;
            if(used.Contains(prefab))throw new InvalidOperationException("Нет свободного Prefab ID.");
            var item=ScriptableObject.CreateInstance<ItemStaticData>();var data=new SerializedObject(item);
            data.FindProperty("_itemID").stringValue=id;data.FindProperty("_displayName").stringValue=title;
            data.FindProperty("_prefabID").intValue=prefab;data.FindProperty("_type").intValue=(int)ItemType.Medical;
            data.FindProperty("_weightGrams").intValue=100;data.FindProperty("_maxDurability").intValue=0;data.ApplyModifiedPropertiesWithoutUndo();
            AssetDatabase.CreateAsset(item,assetPath);Undo.RegisterCreatedObjectUndo(item,"Create medical item");
            Register(medical,items,item);return item;
        }
    }
}
