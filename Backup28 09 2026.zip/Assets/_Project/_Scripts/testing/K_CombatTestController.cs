﻿using System;
using UnityEngine;
using UnityEngine.InputSystem;

namespace K_Incident.Core
{
    public class K_CombatTestController : MonoBehaviour
    {
        // =====================================================================
        // КОНСТАНТЫ БАЛАНСА
        // =====================================================================
        private const float PISTOL_DAMAGE = 30f;
        private const float ASSAULT_DAMAGE = 35f;
        private const float SHOTGUN_DAMAGE = 50f;
        private const float RIFLE_DAMAGE = 50f;

        private const float PISTOL_FRACTURE_CHANCE = 0.4f;
        private const float ASSAULT_FRACTURE_CHANCE = 0.6f;
        private const float SHOTGUN_FRACTURE_CHANCE = 0.8f;
        private const float RIFLE_FRACTURE_CHANCE = 0.8f;

        private const int PISTOL_BLEEDING_LEVEL = 1;
        private const int ASSAULT_BLEEDING_LEVEL = 2;
        private const int SHOTGUN_BLEEDING_LEVEL = 3;
        private const int RIFLE_BLEEDING_LEVEL = 3;

        // =====================================================================
        // ССЫЛКИ
        // =====================================================================
        [Header("System References")]
        [SerializeField] private K_HealthSystem _healthSystem;
        [SerializeField] private K_VitalitySystem _vitalitySystem;
        [SerializeField] private K_CoagulantItem _coagulantItem;

       
        
        
        private void Awake()
        {
            if (_healthSystem == null) _healthSystem = GetComponent<K_HealthSystem>();
            if (_vitalitySystem == null) _vitalitySystem = GetComponent<K_VitalitySystem>();
            if (_coagulantItem == null) _coagulantItem = GetComponent<K_CoagulantItem>();

            if (_healthSystem == null) Debug.LogError("[CombatTest] K_HealthSystem NOT FOUND!");
            if (_vitalitySystem == null) Debug.LogError("[CombatTest] K_VitalitySystem NOT FOUND!");
            if (_coagulantItem == null) Debug.LogWarning("[CombatTest] K_CoagulantItem NOT FOUND!");
        }

               private void Update()
        {
            HandleTestInput();
        }

        // =====================================================================
        // ВВОД (КЛАВИШИ 1-0, =)
        // =====================================================================
       private void HandleTestInput()
{
    if (Keyboard.current == null) return;

    if (Keyboard.current.digit1Key.wasPressedThisFrame)
        TestFirearmHit("Pistol", PISTOL_DAMAGE, PISTOL_BLEEDING_LEVEL, PISTOL_FRACTURE_CHANCE,
                       ResolveTarget(BodyPart.LeftBiceps));

    if (Keyboard.current.digit2Key.wasPressedThisFrame)
        TestFirearmHit("Assault Rifle", ASSAULT_DAMAGE, ASSAULT_BLEEDING_LEVEL, ASSAULT_FRACTURE_CHANCE,
                       ResolveTarget(BodyPart.LeftQuadriceps));

    if (Keyboard.current.digit3Key.wasPressedThisFrame)
        TestFirearmHit("Shotgun", SHOTGUN_DAMAGE, SHOTGUN_BLEEDING_LEVEL, SHOTGUN_FRACTURE_CHANCE,
                       ResolveTarget(BodyPart.RightBiceps));

    if (Keyboard.current.digit4Key.wasPressedThisFrame)
        TestFirearmHit("Rifle", RIFLE_DAMAGE, RIFLE_BLEEDING_LEVEL, RIFLE_FRACTURE_CHANCE,
                       ResolveTarget(BodyPart.RightQuadriceps));

    if (Keyboard.current.digit5Key.wasPressedThisFrame) UseBandage();
    if (Keyboard.current.digit6Key.wasPressedThisFrame) UseSplint();
    if (Keyboard.current.digit7Key.wasPressedThisFrame) UseSutureKit();
    if (Keyboard.current.digit8Key.wasPressedThisFrame) UseCoagulant();
    if (Keyboard.current.digit9Key.wasPressedThisFrame) UseStimulatorEnhanced();
    if (Keyboard.current.digit0Key.wasPressedThisFrame) TestColdExposure();

    if (Keyboard.current.tKey.wasPressedThisFrame)
        ClearTargetPart();

    if (Keyboard.current.equalsKey.wasPressedThisFrame) UseVodka();
}
               private void TestFirearmHit(string weaponName, float damage, int bleedingLevel, float fractureChance, BodyPart targetPart)
        {
            if (_healthSystem == null || _healthSystem.IsDead)
            {
                Debug.LogWarning("[CombatTest] HealthSystem not found or player is dead!");
                return;
            }

            Debug.Log($"[CombatTest] ============================================");
            Debug.Log($"[CombatTest] FIREARM HIT: {weaponName}");
            Debug.Log($"[CombatTest] Damage: {damage} HP | Bleeding: {bleedingLevel} | Fracture Chance: {fractureChance * 100:F0}%");
            Debug.Log($"[CombatTest] Target: {targetPart}");
            Debug.Log($"[CombatTest] ============================================");

            _healthSystem.TakeDamage(damage, targetPart, DamageType.Firearm, bleedingLevel);

            PrintHealthStatus();
        }

        // =====================================================================
        // МЕДИЦИНА
        // =====================================================================
        private void UseBandage()
        {
            if (_healthSystem == null) return;

            int maxBleedingLevel = _healthSystem.GetMaxBleedingLevel();
            if (maxBleedingLevel == 0)
            {
                Debug.Log("[CombatTest] No bleeding to stop!");
                return;
            }

            bool success = _healthSystem.UseBandage();
            if (success) Debug.Log($"[CombatTest] BANDAGE USED! Max bleeding level reduced by 1");

            PrintHealthStatus();
        }

        private void UseSplint()
        {
            if (_healthSystem == null) return;

            BodyPart[] limbs = {
                BodyPart.LeftShoulder, BodyPart.RightShoulder,
                BodyPart.LeftBiceps, BodyPart.RightBiceps,
                BodyPart.LeftForearm, BodyPart.RightForearm,
                BodyPart.LeftQuadriceps, BodyPart.RightQuadriceps,
                BodyPart.LeftKnee, BodyPart.RightKnee,
                BodyPart.LeftShin, BodyPart.RightShin,
                BodyPart.Pelvis, BodyPart.Chest
            };

            bool foundFracture = false;
            foreach (var limb in limbs)
            {
                if (_healthSystem.IsFractured(limb) && !_healthSystem.IsSplinted(limb))
                {
                    _healthSystem.ApplySplint(limb);
                    Debug.Log($"[CombatTest] SPLINT APPLIED to {limb}!");
                    foundFracture = true;
                    break;
                }
            }

            if (!foundFracture) Debug.Log("[CombatTest] No fractures to splint!");

            PrintHealthStatus();
        }

        private void UseSutureKit()
        {
            if (_healthSystem == null) return;

            if (!_healthSystem.HasAnyLaceration())
            {
                Debug.Log("[CombatTest] No laceration to treat!");
                return;
            }

            _healthSystem.UseSutureKit();
            Debug.Log("[CombatTest] SUTURE KIT USED! All lacerations removed.");
            PrintHealthStatus();
        }

               private void UseCoagulant()
        {
            if (_coagulantItem == null)
            {
                Debug.Log("[CombatTest] CoagulantItem not found!");
                return;
            }

            bool success = _coagulantItem.UseCoagulant();
            if (success) Debug.Log("[CombatTest] COAGULANT APPLIED. Bleeding reduced on target part. Icon will show for 60s.");
            else Debug.Log("[CombatTest] COAGULANT FAILED - no bleeding / disabled / config missing.");
        }

        private void UseStimulatorEnhanced()
        {
            if (_vitalitySystem == null)
            {
                Debug.Log("[CombatTest] VitalitySystem not found!");
                return;
            }

            _vitalitySystem.UseStimulatorEnhanced();
            Debug.Log("[CombatTest] STIMULATOR USED! 85s ON + 200s OFF (Side Effects + Cooldown)");
        }

        private void TestColdExposure()
        {
            if (_vitalitySystem == null)
            {
                Debug.Log("[CombatTest] VitalitySystem not found!");
                return;
            }

            float current = _vitalitySystem.ColdExposure;
            float next = current >= 1.0f ? 0f : (current >= 0.5f ? 1.0f : 0.5f);
            _vitalitySystem.SetColdExposure(next);
            Debug.Log($"[CombatTest] Cold Exposure: {current:F2} → {next:F2}");
        }

        private void UseVodka()
        {
            if (_vitalitySystem == null)
            {
                Debug.Log("[CombatTest] VitalitySystem not found!");
                return;
            }

            _vitalitySystem.ConsumeVodka(100f);
            Debug.Log("[CombatTest] VODKA CONSUMED! 100ml | -5 Radiation | Drunk 120s");
        }

        // =====================================================================
        // СТАТУС
        // =====================================================================
       private void PrintHealthStatus()
{
    Debug.Log($"[CombatTest] Current target: {(CurrentTargetPart?.ToString() ?? "default per key")}");

    if (_healthSystem == null) return;

    Debug.Log($"[CombatTest] ========== HEALTH STATUS ==========");
    for (int i = 0; i < 20; i++)
    {
        var part = (BodyPart)i;
        Debug.Log($"[CombatTest] {part}: {_healthSystem.GetHP(part):F1}/{_healthSystem.GetMaxHP(part):F1}");
    }
    Debug.Log($"[CombatTest] -----------------------------------");
    Debug.Log($"[CombatTest] Max Bleeding Level: {_healthSystem.GetMaxBleedingLevel()}");
    Debug.Log($"[CombatTest] Bleeding Limbs Count: {_healthSystem.GetBleedingLimbsCount()}");
    Debug.Log($"[CombatTest] Has Any Laceration: {_healthSystem.HasAnyLaceration()}");
    Debug.Log($"[CombatTest] Fractures: {_healthSystem.FractureCount}");
    Debug.Log($"[CombatTest] Shock: {_healthSystem.IsShocked}");

    if (_vitalitySystem != null)
    {
        Debug.Log($"[CombatTest] -----------------------------------");
        Debug.Log($"[CombatTest] Stim ON: {_vitalitySystem.IsStimOn}");
        Debug.Log($"[CombatTest] Stim OFF: {_vitalitySystem.IsStimOff}");
        Debug.Log($"[CombatTest] Stim Ready: {_vitalitySystem.IsStimReady}");
        Debug.Log($"[CombatTest] Fatigue: {_vitalitySystem.IsFatigued}");
        Debug.Log($"[CombatTest] Hangover: {_vitalitySystem.IsHangover}");
        Debug.Log($"[CombatTest] Cold Exposure: {_vitalitySystem.ColdExposure:F2}");
        Debug.Log($"[CombatTest] Temperature: {_vitalitySystem.CurrentTemperature:F1}°C");
        Debug.Log($"[CombatTest] Overload: {_vitalitySystem.IsOverloaded}");
        Debug.Log($"[CombatTest] Hunger: {_vitalitySystem.Hunger:F1}");
        Debug.Log($"[CombatTest] Thirst: {_vitalitySystem.Thirst:F1}");
        Debug.Log($"[CombatTest] Radiation: {_vitalitySystem.Radiation:F1}%");
        Debug.Log($"[CombatTest] Alcohol: {_vitalitySystem.AlcoholConcentration:F2}");
        Debug.Log($"[CombatTest] Radiation Immunity: {_vitalitySystem.HasRadiationImmunity}");
    }
    Debug.Log($"[CombatTest] ===================================");
}
        // =====================================================================
        // DEBUG CONTEXT MENUS
        // =====================================================================
        [ContextMenu("Test: Pistol Shot (Left Biceps)")]
        public void DebugPistolShot()
            => TestFirearmHit("Pistol", PISTOL_DAMAGE, PISTOL_BLEEDING_LEVEL, PISTOL_FRACTURE_CHANCE, BodyPart.LeftBiceps);

        [ContextMenu("Test: Assault Shot (Left Quadriceps)")]
        public void DebugAssaultShot()
            => TestFirearmHit("Assault Rifle", ASSAULT_DAMAGE, ASSAULT_BLEEDING_LEVEL, ASSAULT_FRACTURE_CHANCE, BodyPart.LeftQuadriceps);

        [ContextMenu("Test: Shotgun Shot (Right Biceps)")]
        public void DebugShotgunShot()
            => TestFirearmHit("Shotgun", SHOTGUN_DAMAGE, SHOTGUN_BLEEDING_LEVEL, SHOTGUN_FRACTURE_CHANCE, BodyPart.RightBiceps);

        [ContextMenu("Test: Rifle Shot (Right Quadriceps)")]
        public void DebugRifleShot()
            => TestFirearmHit("Rifle", RIFLE_DAMAGE, RIFLE_BLEEDING_LEVEL, RIFLE_FRACTURE_CHANCE, BodyPart.RightQuadriceps);

        [ContextMenu("Test: Use Bandage")]
        public void DebugBandage() => UseBandage();

        [ContextMenu("Test: Use Splint")]
        public void DebugSplint() => UseSplint();

        [ContextMenu("Test: Use Suture Kit")]
        public void DebugSuture() => UseSutureKit();

        [ContextMenu("Test: Use Coagulant")]
        public void DebugCoagulant() => UseCoagulant();

        [ContextMenu("Test: Use Stimulator")]
        public void DebugStim() => UseStimulatorEnhanced();

        [ContextMenu("Test: Toggle Cold Exposure")]
        public void DebugCold() => TestColdExposure();

        [ContextMenu("Test: Consume Vodka (100ml)")]
        public void DebugVodka() => UseVodka();

        [ContextMenu("Test: Toggle Overload")]
        public void DebugOverload()
        {
            if (_vitalitySystem != null)
                _vitalitySystem.SetOverload(!_vitalitySystem.IsOverloaded);
        }

        [ContextMenu("Test: Print Status")]
        public void DebugPrintStatus() => PrintHealthStatus();

               [ContextMenu("Test: Reset All")]
        public void DebugResetAll()
        {
            if (_healthSystem != null)
            {
                _healthSystem.DebugStopBleeding();
                _healthSystem.DebugRemoveLaceration();

                for (int i = 0; i < 20; i++)
                    _healthSystem.RemoveSplint((BodyPart)i);
            }
            Debug.Log("[CombatTest] All statuses reset!");
        }
      
public static BodyPart? CurrentTargetPart { get; private set; }

/// <summary>Установить целевую часть тела для следующего выстрела.</summary>
public static void SetTargetPart(BodyPart part)
{
    CurrentTargetPart = part;
    Debug.Log($"[CombatTest] Target set: {part}");
}

/// <summary>Сбросить цель на дефолт.</summary>
public static void ClearTargetPart()
{
    CurrentTargetPart = null;
    Debug.Log("[CombatTest] Target cleared (default per key).");
}

private static BodyPart ResolveTarget(BodyPart fallback)
    => CurrentTargetPart ?? fallback;
    }
}