﻿using UnityEngine;

namespace K_Incident.Core
{
       /// <summary>
    /// Коагулянт — мгновенно останавливает кровотечение на выбранном сегменте.
    /// Level 1-2 → 0 (полная остановка при fullStopMaxLevel=2);
    /// Level 3 → level-1 (артериальное требует жгут/хирурга).
    /// НЕ восстанавливает кровь и не лечит HP.
    /// Таймер IconShowTimer = 60s — визуальное подтверждение применения
    /// для UI-иконки. НЕ означает активного игрового эффекта.
    /// Никакого ускорения лечения, восстановления крови или HP нет.
    /// </summary>
    public class K_CoagulantItem : MonoBehaviour
    {
        // =====================================================================
        // СВЯЗЬ С ИНВЕНТАРЕМ
        // =====================================================================
        public ushort RequiredPrefabID => 2001;

        // =====================================================================
        // ССЫЛКИ
        // =====================================================================
        [Header("System References")]
        [SerializeField] private K_HealthSystem _healthSystem;

              // =====================================================================
        // СОСТОЯНИЕ (для UI-иконки)
        // =====================================================================
        /// <summary>
        /// Флаг видимости UI-иконки коагулянта. Не игровой эффект.
        /// </summary>
        private bool _iconVisible = false;

        /// <summary>
        /// Таймер показа UI-иконки, 60s. Визуальный маркер, не эффект лечения.
        /// </summary>
        private float _iconShowTimer = 0f;

        public bool IsIconVisible => _iconVisible;
        public float IconShowTimer => _iconShowTimer;

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
        {
            if (_healthSystem == null) _healthSystem = GetComponent<K_HealthSystem>();
        }

               private void Update()
        {
            if (_iconVisible && _iconShowTimer > 0f)
            {
                _iconShowTimer -= Time.deltaTime;
                if (_iconShowTimer <= 0f)
                {
                    _iconShowTimer = 0f;
                    _iconVisible = false;
                }
            }
        }

        // =====================================================================
        // ИСПОЛЬЗОВАНИЕ
        // =====================================================================
        /// <summary>
        /// Применить коагулянт. Если targetPart == null — автоматически выбирается
        /// сегмент с максимальным уровнем кровотечения.
        /// Мгновенно снижает уровень: level 1-2 → 0; level 3 → 1 (если fullStopMaxLevel=2).
        /// Не восстанавливает кровь и не лечит HP.
        /// </summary>
               public bool UseCoagulant(BodyPart? targetPart = null)
        {
            if (_healthSystem == null)
            {
                Debug.LogWarning("[Coagulant] HealthSystem not assigned.");
                return false;
            }

            var config = K_HealthConfig.Instance;
            if (config == null)
            {
                Debug.LogWarning("[Coagulant] K_HealthConfig.Instance is null.");
                return false;
            }

            if (!config.Coagulant.enabled)
            {
                Debug.Log("[Coagulant] Disabled in config.");
                return false;
            }

            if (targetPart == null)
            {
                targetPart = _healthSystem.GetPartWithMaxBleeding();
                if (targetPart == null)
                {
                    Debug.Log("[Coagulant] No bleeding anywhere.");
                    return false;
                }
            }

            int currentLevel = _healthSystem.GetBleedingLevel(targetPart.Value);
            if (currentLevel <= 0)
            {
                Debug.Log($"[Coagulant] No bleeding on {targetPart.Value}.");
                return false;
            }

            int newLevel;
            if (currentLevel <= config.Coagulant.fullStopMaxLevel)
                newLevel = 0;
            else
                newLevel = currentLevel - 1;

            _healthSystem.SetBleedingLevelOnPart(targetPart.Value, newLevel);

            _iconVisible = true;
            _iconShowTimer = 60f;

            Debug.Log($"[Coagulant] Used on {targetPart.Value}: level {currentLevel} → {newLevel}.");
            return true;
        }

               public bool ShouldShowIcon() => _iconVisible && _iconShowTimer > 0f;
        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Test: Use Coagulant")]
        public void DebugUseCoagulant() => UseCoagulant(null);
    }
}