using K_Incident.Core;
using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

/// <summary>
/// Виджет здоровья для окна инвентаря.
/// Отличается от HUD-версии K_HealthWidget (нет fade, часов и т.д.),
/// но использует тот же API K_HealthSystem / K_VitalitySystem / K_WeightManager.
/// </summary>
public class K_InventoryHealthWidget : MonoBehaviour
{
    private const int SEGMENT_COUNT = 20;

    #region System References

    [Header("System References")]
    [SerializeField] private K_HealthSystem _healthSystem;
    [SerializeField] private K_VitalitySystem _vitalitySystem;
    [SerializeField] private K_CoagulantItem _coagulantItem;
    [SerializeField] private K_WeightManager _weightManager;
    [SerializeField] private K_BloodSystem _bloodSystem;

    [Header("Blood UI")]
    [SerializeField] private TextMeshProUGUI _bloodText;
    [SerializeField] private Gradient _bloodTextGradient;

    [Header("Debuff Icons (Iteration 4 — placeholders)")]
    [SerializeField] private Image _iconConcussion;
    [SerializeField] private Image _iconTBI;
    [SerializeField] private Image _iconBreathingDifficulty;
    [SerializeField] private Image _iconImmobilized;
    [SerializeField] private Image _iconInternalBleeding;
    [SerializeField] private K_DebuffSystem _debuffSystem;

    #endregion

    #region Health Doll

    [Header("Health Doll (Segments) — index = (int)BodyPart")]
    [SerializeField]
    private Image[] _segmentImages = new Image[20];

    [SerializeField] private Gradient _healthGradient;

    #endregion

    #region Status Icons

    [Header("Metabolism & Status Icons")]
    [SerializeField] private Gradient _statusGradient;
    [SerializeField] private Gradient _bleedingGradient;
    [SerializeField] private Gradient _hungerGradient;
    [SerializeField] private Gradient _thirstGradient;
    [SerializeField] private Gradient _radiationGradient;
    [SerializeField] private Gradient _overloadGradient;

    [Space]
    [SerializeField] private Image _iconHunger;
    [SerializeField] private Image _iconThirst;
    [SerializeField] private Image _iconRadiation;
    [SerializeField] private Image _iconCold;
    [SerializeField] private Image _iconOverload;
    [SerializeField] private Image _iconBleeding;
    [SerializeField] private Image _iconLaceration;
    [SerializeField] private Image _iconHangover;
    [SerializeField] private Image _iconDrunk;
    [SerializeField] private Image _iconStimOn;
    [SerializeField] private Image _iconStimOff;
    [SerializeField] private Image _iconCoagulant;
    [SerializeField, Tooltip("Цвет иконки коагулянта при показе.")]
    private Color _coagulantIconColor = Color.white;

    #endregion

    #region Fracture Icon

    [Header("Fracture Icon (Iteration 5)")]
    [SerializeField] private Image _iconFracture;
    [SerializeField] private TextMeshProUGUI _fractureCountText;

    #endregion

    #region Unity Lifecycle

    // ---------------------------------------------------------------------
    // ПРАВКА: авто-файнд перенесён из Start() в Awake(),
    //         добавлен первичный RefreshDebuffIcons().
    // ---------------------------------------------------------------------
    private void Awake()
    {
        if (_healthSystem == null) _healthSystem = FindAnyObjectByType<K_HealthSystem>();
        if (_vitalitySystem == null) _vitalitySystem = FindAnyObjectByType<K_VitalitySystem>();
        if (_coagulantItem == null) _coagulantItem = FindAnyObjectByType<K_CoagulantItem>();
        if (_weightManager == null) _weightManager = FindAnyObjectByType<K_WeightManager>();
        if (_bloodSystem == null) _bloodSystem = FindAnyObjectByType<K_BloodSystem>();
        if (_debuffSystem == null) _debuffSystem = FindAnyObjectByType<K_DebuffSystem>();

        if (_segmentImages == null || _segmentImages.Length != SEGMENT_COUNT)
            Debug.LogWarning($"[K_InventoryHealthWidget] _segmentImages должен быть размером {SEGMENT_COUNT}, сейчас {_segmentImages?.Length ?? 0}");

        SetupSegmentClickHandlers();

        // Первичная инициализация иконок дебафов сразу после авто-файнда,
        // не дожидаясь OnEnable (Unity: Awake → OnEnable → Start).
        RefreshDebuffIcons();
    }

    private void SetupSegmentClickHandlers()
    {
        if (_segmentImages == null || _segmentImages.Length == 0) return;

        int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
        for (int i = 0; i < count; i++)
        {
            var img = _segmentImages[i];
            if (img == null) continue;

            img.raycastTarget = true;

            var trigger = img.gameObject.GetComponent<EventTrigger>();
            if (trigger == null) trigger = img.gameObject.AddComponent<EventTrigger>();

            var entry = new EventTrigger.Entry { eventID = EventTriggerType.PointerClick };
            int capturedIndex = i;
            entry.callback.AddListener(_ =>
            {
                var part = (BodyPart)capturedIndex;
                K_CombatTestController.SetTargetPart(part);
            });
            trigger.triggers.Add(entry);
            img.alphaHitTestMinimumThreshold = 0.1f;
        }
    }

    // ---------------------------------------------------------------------
    // ПРАВКА: Start() больше не ищет ссылки. Оставлены:
    //         warning + RefreshAll() (страховка отложенного OnEnable).
    // ---------------------------------------------------------------------
    private void Start()
    {
        if (_healthSystem == null || _vitalitySystem == null)
        {
            Debug.LogWarning("[K_InventoryHealthWidget] Core systems missing even after auto-find. " +
                $"HealthSystem={_healthSystem != null}, VitalitySystem={_vitalitySystem != null}. " +
                "Assign them in Inspector or ensure they exist in scene.");
        }

        RefreshAll();
    }

    private void OnEnable()
    {
        if (_healthSystem != null) _healthSystem.OnHealthChanged += RefreshHealth;
        if (_vitalitySystem != null) { /* без изменений */ }
        if (_weightManager != null) _weightManager.OnWeightChanged += RefreshMetabolism;
        if (_bloodSystem != null) _bloodSystem.OnBloodChanged += RefreshBloodUI;

        if (_debuffSystem != null) _debuffSystem.OnDebuffsChanged += RefreshDebuffIcons;
        RefreshAll();
    }

    private void OnDisable()
    {
        if (_healthSystem != null) _healthSystem.OnHealthChanged -= RefreshHealth;
        if (_vitalitySystem != null) { /* без изменений */ }
        if (_weightManager != null) _weightManager.OnWeightChanged -= RefreshMetabolism;
        if (_bloodSystem != null) _bloodSystem.OnBloodChanged -= RefreshBloodUI;
        if (_debuffSystem != null) _debuffSystem.OnDebuffsChanged -= RefreshDebuffIcons;
    }

    #endregion

    #region Refresh

    public void RefreshAll()
    {
        RefreshHealth();
        RefreshMetabolism();
        RefreshBloodUI();
        RefreshDebuffIcons();
    }

    private void RefreshHealth()
    {
        UpdateHealthUI();
        UpdateFractureIcon();
        UpdateCoagulantIcon();
    }

    private void RefreshMetabolism()
    {
        UpdateMetabolismUI();
    }

    private void RefreshDebuffIcons()
    {
        if (_debuffSystem == null) return;

        SetIconActive(_iconConcussion,          _debuffSystem.HasConcussion);
        SetIconActive(_iconTBI,                 _debuffSystem.HasTBI);
        SetIconActive(_iconBreathingDifficulty, _debuffSystem.HasBreathingDifficulty);
        SetIconActive(_iconImmobilized,         _debuffSystem.HasImmobilized);
        SetIconActive(_iconInternalBleeding,    _debuffSystem.HasInternalBleeding);
    }

    private void SetIconActive(Image icon, bool active)
    {
        if (icon == null) return;
        if (icon.gameObject.activeSelf != active)
            icon.gameObject.SetActive(active);
    }

    #endregion

    private void RefreshBloodUI()
    {
        if (_bloodText == null || _bloodSystem == null) return;

        float p = _bloodSystem.BloodPercent;
        int percentInt = Mathf.RoundToInt(p * 100f);
        _bloodText.text = $"{percentInt}%";

        if (_bloodTextGradient != null)
        {
            Color c = _bloodTextGradient.Evaluate(p);
            _bloodText.color = c;
        }
    }

    #region Health Doll UI

    private void UpdateHealthUI()
    {
        if (_healthSystem == null) return;
        if (_healthGradient == null)
        {
            Debug.LogWarning("[K_InventoryHealthWidget] HealthGradient is null!");
            return;
        }

        if (_segmentImages == null) return;

        int count = Mathf.Min(_segmentImages.Length, SEGMENT_COUNT);
        for (int i = 0; i < count; i++)
        {
            var part = (BodyPart)i;
            UpdateSegmentColor(_segmentImages[i], part);
        }
    }

    private void UpdateSegmentColor(Image img, BodyPart part)
    {
        if (img == null || _healthSystem == null || _healthGradient == null) return;

        float cur = _healthSystem.GetHP(part);
        float max = _healthSystem.GetMaxHP(part);
        if (max <= 0f) return;

        float ratio = Mathf.Clamp01(cur / max);
        Color c = _healthGradient.Evaluate(ratio);
        img.enabled = true;
        img.color = new Color(c.r, c.g, c.b, 1f);
    }

    #endregion

    #region Fractures

    private void UpdateFractureIcon()
    {
        if (_healthSystem == null) return;

        int count = _healthSystem.FractureCount;

        if (_iconFracture != null)
            _iconFracture.gameObject.SetActive(count > 0);

        if (_fractureCountText != null)
        {
            _fractureCountText.gameObject.SetActive(count > 1);
            if (count > 1)
                _fractureCountText.text = count.ToString();
        }
    }

    #endregion

    #region Coagulant

    private void UpdateCoagulantIcon()
    {
        if (_coagulantItem == null || _iconCoagulant == null) return;
        bool shouldShow = _coagulantItem.ShouldShowIcon();
        _iconCoagulant.gameObject.SetActive(shouldShow);
        if (shouldShow)
            _iconCoagulant.color = _coagulantIconColor;
    }

    #endregion

    #region Metabolism UI

    private void UpdateMetabolismUI()
    {
        if (_vitalitySystem == null) return;

        SafeUpdateIcon(_iconHunger, _vitalitySystem.Icon_Hunger, _vitalitySystem.Hunger / 100f, _hungerGradient);
        SafeUpdateIcon(_iconThirst, _vitalitySystem.Icon_Thirst, _vitalitySystem.Thirst / 100f, _thirstGradient);
        SafeUpdateIcon(_iconRadiation, _vitalitySystem.Icon_Radiation, 1f - (_vitalitySystem.Radiation / 100f), _radiationGradient);
        if (_vitalitySystem.Icon_Bleeding > 0)
            SafeUpdateIcon(_iconBleeding, true, _vitalitySystem.Icon_Bleeding / 3f, _bleedingGradient);
        else
            SafeUpdateIcon(_iconBleeding, false);

        SafeUpdateIcon(_iconLaceration, _vitalitySystem.Icon_Laceration);
        SafeUpdateIcon(_iconStimOn, _vitalitySystem.Icon_StimOn);
        SafeUpdateIcon(_iconStimOff, _vitalitySystem.Icon_StimOff);
        SafeUpdateIcon(_iconHangover, _vitalitySystem.Icon_Hangover);
        SafeUpdateIcon(_iconCold, _vitalitySystem.Icon_Cold);

        if (_weightManager != null)
        {
            float ratio = _weightManager.GetCurrentWeightRatio();
            bool overloaded = ratio >= 0.9f;
            if (overloaded)
            {
                float norm = Mathf.Clamp01(Mathf.InverseLerp(0.9f, 1.1f, ratio));
                SafeUpdateIcon(_iconOverload, true, norm, _overloadGradient);
            }
            else
                SafeUpdateIcon(_iconOverload, false);
        }
        else
            SafeUpdateIcon(_iconOverload, _vitalitySystem.Icon_Overload);

        SafeUpdateIcon(_iconDrunk, _vitalitySystem.Icon_Drunk);
    }

    private void SafeUpdateIcon(Image img, bool isActive, float? colorT = null, Gradient customGradient = null)
    {
        if (img == null) return;
        if (img.gameObject.activeSelf != isActive)
            img.gameObject.SetActive(isActive);
        if (isActive && colorT.HasValue)
        {
            Gradient g = customGradient != null ? customGradient : _statusGradient;
            if (g != null)
                img.color = g.Evaluate(Mathf.Clamp01(colorT.Value));
        }
    }

    #endregion
}