using System;
using UnityEngine;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
public class K_CollapsiblePanel : MonoBehaviour
{
    [SerializeField] private GameObject _targetPanel;
    [SerializeField] private Button _toggleButton;
    [SerializeField] private bool _startExpanded = true;
    [SerializeField] private bool _useCanvasGroup = false;
    [SerializeField] private RectTransform _arrowIcon;
    [SerializeField] private float _expandedRotation = 0f;
    [SerializeField] private float _collapsedRotation = -90f;

    private CanvasGroup _targetCanvasGroup;
    private bool _isExpanded;

    public bool IsExpanded => _isExpanded;

    public event Action<bool> OnStateChanged;

    private void Awake()
    {
        if (_targetPanel == null)
        {
            Debug.LogWarning($"{nameof(K_CollapsiblePanel)} на объекте '{name}': не назначен _targetPanel. Компонент не будет работать.", this);
            return;
        }

        if (_useCanvasGroup)
        {
            _targetCanvasGroup = _targetPanel.GetComponent<CanvasGroup>();
            if (_targetCanvasGroup == null)
            {
                _targetCanvasGroup = _targetPanel.AddComponent<CanvasGroup>();
            }
        }

        if (_toggleButton != null)
        {
            _toggleButton.onClick.AddListener(Toggle);
        }

        ApplyState(_startExpanded, false);
    }

    private void OnDestroy()
    {
        if (_toggleButton != null)
        {
            _toggleButton.onClick.RemoveListener(Toggle);
        }
    }

    public void Toggle()
    {
        ApplyState(!_isExpanded);
    }

    public void Expand()
    {
        ApplyState(true);
    }

    public void Collapse()
    {
        ApplyState(false);
    }

    public void SetExpanded(bool expanded)
    {
        ApplyState(expanded);
    }

    private void ApplyState(bool expanded)
    {
        ApplyState(expanded, true);
    }

    private void ApplyState(bool expanded, bool invokeEvent)
    {
        if (_targetPanel == null)
        {
            return;
        }

        _isExpanded = expanded;

        if (_useCanvasGroup)
        {
            if (_targetCanvasGroup == null)
            {
                _targetCanvasGroup = _targetPanel.GetComponent<CanvasGroup>();
                if (_targetCanvasGroup == null)
                {
                    _targetCanvasGroup = _targetPanel.AddComponent<CanvasGroup>();
                }
            }

            _targetCanvasGroup.alpha = expanded ? 1f : 0f;
            _targetCanvasGroup.interactable = expanded;
            _targetCanvasGroup.blocksRaycasts = expanded;
        }
        else
        {
            if (_targetPanel.activeSelf != expanded)
            {
                _targetPanel.SetActive(expanded);
            }
        }

        if (_arrowIcon != null)
        {
            float zRotation = expanded ? _expandedRotation : _collapsedRotation;
            _arrowIcon.localRotation = Quaternion.Euler(0f, 0f, zRotation);
        }

        if (invokeEvent)
        {
            OnStateChanged?.Invoke(_isExpanded);
        }
    }
    }

}