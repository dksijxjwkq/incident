using System.Text;
using UnityEngine;
using UnityEngine.UI;

public class Debug_HealthDollInventory : MonoBehaviour
{
    [ContextMenu("Dump Health Doll Inventory Info")]
    public void Dump()
    {
        var sb = new StringBuilder(2048);

        // Найти куклу в инвентаре
        var seg = transform.Find("HealthContentPane/Health_Doll_Inventory/Seg_00_Head");
        if (seg == null)
        {
            // Попробуй напрямую от корня сцены
            var all = Resources.FindObjectsOfTypeAll<RectTransform>();
            foreach (var rt in all)
            {
                if (rt.name == "Seg_00_Head" && rt.gameObject.scene.IsValid())
                {
                    // Различаем HUD vs Inventory по родителю
                    if (rt.parent != null && rt.parent.name.Contains("Inventory"))
                    {
                        seg = rt;
                        break;
                    }
                }
            }
        }

        if (seg == null)
        {
            Debug.LogError("[Dump] Seg_00_Head (inventory) NOT FOUND");
            return;
        }

        sb.AppendLine("════════ SEG_00_HEAD (Inventory) DUMP ════════");
        sb.AppendLine($"activeSelf = {seg.gameObject.activeSelf}");
        sb.AppendLine($"activeInHierarchy = {seg.gameObject.activeInHierarchy}");
        sb.AppendLine($"layer = {LayerMask.LayerToName(seg.gameObject.layer)} ({seg.gameObject.layer})");
        sb.AppendLine($"worldPos = {seg.position}");

        var img = seg.GetComponent<Image>();
        if (img == null) sb.AppendLine("Image = NULL");
        else
        {
            sb.AppendLine($"Image.enabled = {img.enabled}");
            sb.AppendLine($"Image.sprite = {(img.sprite != null ? img.sprite.name : "NULL")}");
            sb.AppendLine($"Image.color = {img.color}");
            sb.AppendLine($"Image.material = {(img.material != null ? img.material.name : "NULL")}");
        }

        var rt2 = seg as RectTransform;
        sb.AppendLine($"RectTransform rect = {rt2.rect}");
        sb.AppendLine($"anchoredPos = {rt2.anchoredPosition}");
        sb.AppendLine($"localScale = {rt2.localScale}");
        sb.AppendLine($"lossyScale = {rt2.lossyScale}");

        sb.AppendLine();
        sb.AppendLine("════════ ANCESTORS (снизу вверх) ════════");

        var t = seg;
        int depth = 0;
        while (t != null && depth < 15)
        {
            var rt = t as RectTransform;
            var cg = t.GetComponent<CanvasGroup>();
            var canvas = t.GetComponent<Canvas>();
            var mask = t.GetComponent<Mask>();
            var rmask = t.GetComponent<RectMask2D>();
            var cvsRenderer = t.GetComponent<CanvasRenderer>();
            var img2 = t.GetComponent<Image>();

            sb.Append("[").Append(depth).Append("] ").Append(t.name);
            sb.Append(" | active=").Append(t.gameObject.activeSelf);
            sb.Append(" | layer=").Append(LayerMask.LayerToName(t.gameObject.layer));

            if (rt != null)
                sb.Append(" | rect=").Append(rt.rect);

            if (cg != null)
                sb.Append(" | CG{a=").Append(cg.alpha)
                  .Append(",i=").Append(cg.interactable)
                  .Append(",b=").Append(cg.blocksRaycasts).Append("}");

            if (canvas != null)
                sb.Append(" | CANVAS{mode=").Append(canvas.renderMode)
                  .Append(",override=").Append(canvas.overrideSorting)
                  .Append(",order=").Append(canvas.sortingOrder)
                  .Append(",cam=").Append(canvas.worldCamera != null ? canvas.worldCamera.name : "NULL").Append("}");

            if (mask != null) sb.Append(" | MASK");
            if (rmask != null) sb.Append(" | RECTMASK2D");
            if (cvsRenderer != null) sb.Append(" | CR{cull=").Append(cvsRenderer.cull).Append("}");
            if (img2 != null) sb.Append(" | Image{enabled=").Append(img2.enabled)
                                    .Append(",col=").Append(img2.color)
                                    .Append(",ray=").Append(img2.raycastTarget).Append("}");

            sb.AppendLine();
            t = t.parent;
            depth++;
        }

        Debug.Log(sb.ToString());
    }
}