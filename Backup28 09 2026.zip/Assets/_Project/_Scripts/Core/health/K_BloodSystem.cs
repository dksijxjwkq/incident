using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core
{
    public enum BloodState
    {
        Normal = 0,
        Warning = 1,
        Weakness = 2,
        Shock = 3,
        Dead = 4
    }

    public class K_BloodSystem : MonoBehaviour, ISaveable
    {
        // =====================================================================
        // КОНФИГУРАЦИЯ
        // =====================================================================
        [Header("Volume")]
        [SerializeField] private float _maxVolumeMl = 5000f;
        [SerializeField] private float _currentVolumeMl = 5000f;

        [Header("Bleeding Rates (ml/sec at level 1) — index = (int)BodyPart")]
        [SerializeField]
        private float[] _bleedingRateMlPerSec = new float[20]
        {
            6f,   // Head
            10f,  // Chest
            12f,  // Stomach
            20f,  // Pelvis
            4f,   // L Shoulder
            4f,   // R Shoulder
            5f,   // L Biceps
            5f,   // R Biceps
            3f,   // L Forearm
            3f,   // R Forearm
            2f,   // L Hand
            2f,   // R Hand
            15f,  // L Quadriceps
            15f,  // R Quadriceps
            3f,   // L Knee
            3f,   // R Knee
            8f,   // L Shin
            8f,   // R Shin
            2f,   // L Foot
            2f    // R Foot
        };

        [Header("Bleeding Level Multipliers")]
        [SerializeField] private float _level1Mult = 1f;
        [SerializeField] private float _level2Mult = 2f;
        [SerializeField] private float _level3Mult = 5f;

        [Header("Thresholds (percent 0..1)")]
        [SerializeField, Range(0f, 1f)] private float _warningThreshold = 0.70f;
        [SerializeField, Range(0f, 1f)] private float _weaknessThreshold = 0.40f;
        [SerializeField, Range(0f, 1f)] private float _shockThreshold = 0.15f;

        [Header("Shock HP Drain (per second, split across 20 segments)")]
        [SerializeField] private float _shockHpDrainPerSec = 1f;

        [Header("Debuff Multipliers")]
        [SerializeField] private float _weaknessSpeedMult = 0.8f;
        [SerializeField] private float _weaknessStaminaMult = 0.8f;
        [SerializeField] private float _shockSpeedMult = 0.4f;
        [SerializeField] private float _shockStaminaMult = 0.5f;

        [Header("References (auto-find if empty)")]
        [SerializeField] private K_HealthSystem _healthSystem;
        [SerializeField] private K_DebuffSystem _debuffSystem;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false;

        // =====================================================================
        // RUNTIME
        // =====================================================================
        public event Action OnBloodChanged;

        public string SaveID => "PlayerBlood";
        public bool IsDirty { get; set; } = true;

        public float CurrentVolumeMl => _currentVolumeMl;
        public float MaxVolumeMl => _maxVolumeMl;
        public float BloodPercent => _maxVolumeMl > 0f ? _currentVolumeMl / _maxVolumeMl : 0f;
        public BloodState State => EvaluateState(BloodPercent);
        public bool IsDeadFromBlood => _currentVolumeMl <= 0f;

        private bool _deathFired;
        private float _notifyTimer;

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
        private void Awake()
        {
            if (_healthSystem == null) _healthSystem = GetComponent<K_HealthSystem>();
            if (_healthSystem == null)
                Debug.LogError("[BloodSystem] K_HealthSystem not found on this GameObject!");
                if (_debuffSystem == null) _debuffSystem = GetComponent<K_DebuffSystem>();
        }

        private void Start()
        {
            K_SaveManager.Instance?.Register(this);
        }

        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
            OnBloodChanged = null;
        }

        private void Update()
        {
            if (_currentVolumeMl <= 0f) return;
            if (_healthSystem == null) return;
            if (_healthSystem.IsDead) return;

          float drainMlPerSec = CalculateDrainMlPerSec();
if (drainMlPerSec > 0f)
{
    float debuffMult = _debuffSystem != null ? _debuffSystem.GetBloodDrainMultiplier() : 1f;
    drainMlPerSec *= debuffMult;
    _currentVolumeMl = Mathf.Max(0f, _currentVolumeMl - drainMlPerSec * Time.deltaTime);
    IsDirty = true;
}

            // 2. HP-дрейн в состоянии Shock
            BloodState state = State;
            if (state == BloodState.Shock && _shockHpDrainPerSec > 0f)
            {
                _healthSystem.ApplyDistributedDamage(_shockHpDrainPerSec * Time.deltaTime);
            }

            // 3. Смерть
            if (_currentVolumeMl <= 0f && !_deathFired)
            {
                _deathFired = true;
                Debug.LogWarning("[BloodSystem] Exsanguination — player dead.");
                _healthSystem.ForceDeath();
            }

            // 4. Уведомление (троттлинг 0.5 сек)
            _notifyTimer += Time.deltaTime;
            if (_notifyTimer >= 0.5f)
            {
                _notifyTimer = 0f;
                OnBloodChanged?.Invoke();
            }
        }

        // =====================================================================
        // ВСПОМОГАТЕЛЬНЫЕ
        // =====================================================================
        private float CalculateDrainMlPerSec()
        {
            float sum = 0f;
            for (int i = 0; i < 20; i++)
            {
                int level = _healthSystem.GetBleedingLevel((BodyPart)i);
                if (level <= 0) continue;
                float mult = level switch
                {
                    1 => _level1Mult,
                    2 => _level2Mult,
                    3 => _level3Mult,
                    _ => 0f
                };
                sum += _bleedingRateMlPerSec[i] * mult;
            }
            return sum;
        }

        private BloodState EvaluateState(float p)
        {
            if (p <= 0f) return BloodState.Dead;
            if (p < _shockThreshold) return BloodState.Shock;
            if (p < _weaknessThreshold) return BloodState.Weakness;
            if (p < _warningThreshold) return BloodState.Warning;
            return BloodState.Normal;
        }

        public float GetSpeedMultiplier()
        {
            return State switch
            {
                BloodState.Weakness => _weaknessSpeedMult,
                BloodState.Shock => _shockSpeedMult,
                BloodState.Dead => 0f,
                _ => 1f
            };
        }

        public float GetStaminaRegenMultiplier()
        {
            return State switch
            {
                BloodState.Weakness => _weaknessStaminaMult,
                BloodState.Shock => _shockStaminaMult,
                _ => 1f
            };
        }

        // =====================================================================
        // ПУБЛИЧНОЕ API (для будущих медпредметов — Итерация 5)
        // =====================================================================
        public void AddBlood(float ml)
        {
            if (ml <= 0f) return;
            _currentVolumeMl = Mathf.Min(_currentVolumeMl + ml, _maxVolumeMl);
            IsDirty = true;
            OnBloodChanged?.Invoke();
        }

        public void RemoveBlood(float ml)
        {
            if (ml <= 0f) return;
            _currentVolumeMl = Mathf.Max(0f, _currentVolumeMl - ml);
            IsDirty = true;
            OnBloodChanged?.Invoke();
        }

        public void Transfuse(float ml) => AddBlood(ml);

        // =====================================================================
        // SAVE / LOAD
        // =====================================================================
        public void Save(BinaryWriter writer)
        {
            writer.Write(_currentVolumeMl);
        }

       public void Load(BinaryReader reader)
{
    _currentVolumeMl = reader.ReadSingle();

    if (_currentVolumeMl <= 0f)
    {
        _deathFired = true;
        if (_healthSystem != null && !_healthSystem.IsDead)
        {
            Debug.LogWarning("[BloodSystem] Loaded with 0 ml — forcing death.");
            _healthSystem.ForceDeath();
        }
    }
    else
    {
        _deathFired = false;
    }

    IsDirty = false;
    OnBloodChanged?.Invoke();
}

        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Debug: Drain 1000ml")]
        public void DebugDrain1000() => RemoveBlood(1000f);

        [ContextMenu("Debug: Fill 1000ml")]
        public void DebugFill1000() => AddBlood(1000f);

        [ContextMenu("Debug: Print State")]
        public void DebugPrintState()
        {
            Debug.Log($"[BloodSystem] Volume: {_currentVolumeMl:F0}/{_maxVolumeMl:F0} ml " +
                      $"({BloodPercent * 100f:F1}%) | State: {State}");
        }
    }
}