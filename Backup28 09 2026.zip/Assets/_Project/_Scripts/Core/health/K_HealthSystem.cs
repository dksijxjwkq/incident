﻿using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core
{
    public enum BodyPart
    {
        Head = 0,
        Chest = 1,
        Stomach = 2,
        Pelvis = 3,
        LeftShoulder = 4,
        RightShoulder = 5,
        LeftBiceps = 6,
        RightBiceps = 7,
        LeftForearm = 8,
        RightForearm = 9,
        LeftHand = 10,
        RightHand = 11,
        LeftQuadriceps = 12,
        RightQuadriceps = 13,
        LeftKnee = 14,
        RightKnee = 15,
        LeftShin = 16,
        RightShin = 17,
        LeftFoot = 18,
        RightFoot = 19
    }

    public enum DamageType { Generic, Firearm, Metabolism, Fall, Bleeding, Cold }

    public class K_HealthSystem : MonoBehaviour, ISaveable
    {
        public event Action OnHealthChanged;
        public event Action<BodyPart, float, DamageType> OnDamageTaken;
        public event Action OnDeath;

        public string SaveID => "PlayerHealth";
        public bool IsDirty { get; set; } = true;
        public bool IsDead { get; private set; }

        // =====================================================================
        // КОНСТАНТЫ БАЛАНСА
        // =====================================================================
        private const float PASSIVE_HEAL_RATE = 0.0004f;
     
        private const float FIREARM_SHOCK_DURATION = 10f;
        private const float FIREARM_FRACTURE_CHANCE = 0.4f;
        private const float UI_UPDATE_INTERVAL = 0.5f;
        private const float LACERATION_HEAL_PENALTY = 0.7f;
        private const float LIMB_HP_FLOOR = 0.1f;
        private const int SEGMENT_COUNT = 20;

        // =====================================================================
        // БАЗОВЫЕ HP (index = (int)BodyPart)
        // =====================================================================
        [Header("Base HP (per segment, index = (int)BodyPart)")]
        [SerializeField]
        private float[] _baseHP = new float[SEGMENT_COUNT]
        {
            30f, // Head
            60f, // Chest
            45f, // Stomach
            45f, // Pelvis
            25f, // L Shoulder
            25f, // R Shoulder
            30f, // L Biceps
            30f, // R Biceps
            25f, // L Forearm
            25f, // R Forearm
            15f, // L Hand
            15f, // R Hand
            35f, // L Quadriceps
            35f, // R Quadriceps
            25f, // L Knee
            25f, // R Knee
            30f, // L Shin
            30f, // R Shin
            20f, // L Foot
            20f  // R Foot
        };

        [Header("Can Fracture (per segment)")]
        [SerializeField]
        private bool[] _canFracture = new bool[SEGMENT_COUNT]
        {
            false, // Head — ЧМТ отдельной логикой
            true,  // Chest
            false, // Stomach
            true,  // Pelvis
            true, true,   // Shoulders
            true, true,   // Biceps
            true, true,   // Forearms
            false, false, // Hands
            true, true,   // Quadriceps
            true, true,   // Knees
            true, true,   // Shins
            false, false  // Feet
        };

        // =====================================================================
        // СЕГМЕНТЫ (runtime)
        // =====================================================================
        [Header("Segments (runtime)")]
        [SerializeField] private BodySegment[] _segments = new BodySegment[SEGMENT_COUNT];
        [SerializeField] private LimbStatus[] _limbStatuses = new LimbStatus[SEGMENT_COUNT];
        [SerializeField] private bool[] _fractured = new bool[SEGMENT_COUNT];
        [SerializeField] private bool[] _splinted = new bool[SEGMENT_COUNT];

        [SerializeField] private float _shockTimer = 0f;

        // =====================================================================
        // КЭШИРОВАННЫЕ ССЫЛКИ
        // =====================================================================
        private K_VitalitySystem _cachedVitality;
        private float _timeSinceLastUIUpdate = 0f;

  
       private bool _runtimeInitialized;
        private static readonly BodyPart[] ColdPrimaryTargets =
        {
            BodyPart.LeftShoulder, BodyPart.RightShoulder,
            BodyPart.LeftBiceps, BodyPart.RightBiceps,
            BodyPart.LeftForearm, BodyPart.RightForearm,
            BodyPart.LeftHand, BodyPart.RightHand,
            BodyPart.LeftQuadriceps, BodyPart.RightQuadriceps,
            BodyPart.LeftKnee, BodyPart.RightKnee,
            BodyPart.LeftShin, BodyPart.RightShin,
            BodyPart.LeftFoot, BodyPart.RightFoot,
            BodyPart.Pelvis, BodyPart.Stomach
        };

        private static readonly BodyPart[] ColdVitalTargets =
        {
            BodyPart.Chest, BodyPart.Head
        };

        // =====================================================================
        // ЛОКАЛИЗОВАННЫЕ СТАТУСЫ КОНЕЧНОСТЕЙ
        // =====================================================================
        [System.Serializable]
        public struct LimbStatus
        {
            public int bleedingLevel;
            public bool hasLaceration;
        }

        // =====================================================================
        // UNITY LIFECYCLE
        // =====================================================================
       private void OnValidate()
{
    // Unity вызывает OnValidate ДО Awake при входе в Play Mode.
    // В этот момент _segments содержит BodySegment с нулевыми полями
    // (Unity не вызывает конструктор при десериализации).
    // Runtime-логика (FixZeroHPWithoutFracture, CheckDeathConditions)
    // до инициализации даст ложное Die(). Защищаемся флагом.
    if (!Application.isPlaying) return;
    if (!_runtimeInitialized) return;

    FixZeroHPWithoutFracture();
    EnforceFractureHP();
    ClampAllSegments();
    CheckDeathConditions();
    NotifyChange();
}

      private void Awake()
{
    InitializeSegments();
    _runtimeInitialized = true;   // после InitializeSegments — сегменты уже валидны
    _cachedVitality = GetComponent<K_VitalitySystem>();

    if (_cachedVitality == null)
        Debug.LogWarning("[K_HealthSystem] K_VitalitySystem not found!");
    else
        Debug.Log("[K_HealthSystem] K_VitalitySystem cached successfully");
}

        private void Start()
        {
            K_SaveManager.Instance?.Register(this);
        }

        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
        }

      private void Update()
{
    if (IsDead) return;

    if (_shockTimer > 0f)
    {
        _shockTimer -= Time.deltaTime;
        if (_shockTimer <= 0f) NotifyChange();
    }

    // ВЕТКА if (GetMaxBleedingLevel() > 0 && !IsShocked) { ApplyBleedingDamage(); } — УДАЛЕНА.
    // HP-урон от кровотечения теперь идёт через K_BloodSystem (только в состоянии Shock).

    if (HandlePassiveHealing())
    {
        _timeSinceLastUIUpdate += Time.deltaTime;
        if (_timeSinceLastUIUpdate >= UI_UPDATE_INTERVAL)
        {
            NotifyChange();
            _timeSinceLastUIUpdate = 0f;
        }
    }
}

        // =====================================================================
        // ИНИЦИАЛИЗАЦИЯ
        // =====================================================================
       private void InitializeSegments()
{
    if (_segments == null || _segments.Length != SEGMENT_COUNT)
    {
        Debug.LogWarning($"[K_HealthSystem] _segments length mismatch: " +
                         $"{_segments?.Length ?? 0}, recreating.");
        _segments = new BodySegment[SEGMENT_COUNT];
    }

    if (_limbStatuses == null || _limbStatuses.Length != SEGMENT_COUNT)
        _limbStatuses = new LimbStatus[SEGMENT_COUNT];

    if (_fractured == null || _fractured.Length != SEGMENT_COUNT)
        _fractured = new bool[SEGMENT_COUNT];

    if (_splinted == null || _splinted.Length != SEGMENT_COUNT)
        _splinted = new bool[SEGMENT_COUNT];

    for (int i = 0; i < SEGMENT_COUNT; i++)
    {
        if (_segments[i] == null || _segments[i].OriginalMaxHP <= 0f)
            _segments[i] = new BodySegment(_baseHP[i]);
    }
}
        // =====================================================================
        // ЕДИНЫЙ API ГЕТТЕРОВ
        // =====================================================================
        public float GetHP(BodyPart part) => _segments[(int)part].CurrentHP;
        public float GetMaxHP(BodyPart part) => _segments[(int)part].OriginalMaxHP;

        public float GetHPPercent(BodyPart part)
        {
            var seg = _segments[(int)part];
            return seg.OriginalMaxHP > 0f ? seg.CurrentHP / seg.OriginalMaxHP : 0f;
        }

        // =====================================================================
        // FUNCTIONAL-СВОЙСТВА
        // =====================================================================
        private bool IsFractureBlocking(BodyPart part)
            => _fractured[(int)part] && !_splinted[(int)part];

        public bool IsLeftArmFunctional =>
            !IsFractureBlocking(BodyPart.LeftShoulder) &&
            !IsFractureBlocking(BodyPart.LeftBiceps) &&
            !IsFractureBlocking(BodyPart.LeftForearm);

        public bool IsRightArmFunctional =>
            !IsFractureBlocking(BodyPart.RightShoulder) &&
            !IsFractureBlocking(BodyPart.RightBiceps) &&
            !IsFractureBlocking(BodyPart.RightForearm);

        public bool IsLeftLegFunctional =>
            !IsFractureBlocking(BodyPart.LeftQuadriceps) &&
            !IsFractureBlocking(BodyPart.LeftKnee) &&
            !IsFractureBlocking(BodyPart.LeftShin);

        public bool IsRightLegFunctional =>
            !IsFractureBlocking(BodyPart.RightQuadriceps) &&
            !IsFractureBlocking(BodyPart.RightKnee) &&
            !IsFractureBlocking(BodyPart.RightShin);

        // Backwards-compat
        public bool HasLegFracture => !IsLeftLegFunctional || !IsRightLegFunctional;
        public bool HasArmFracture => !IsLeftArmFunctional || !IsRightArmFunctional;

        public bool HasFracture
        {
            get
            {
                for (int i = 0; i < SEGMENT_COUNT; i++)
                    if (_fractured[i] && !_splinted[i]) return true;
                return false;
            }
        }

        public int FractureCount
        {
            get
            {
                int c = 0;
                for (int i = 0; i < SEGMENT_COUNT; i++)
                    if (_fractured[i] && !_splinted[i]) c++;
                return c;
            }
        }

        public bool IsShocked => _shockTimer > 0f;

        // =====================================================================
        // ЛОКАЛИЗОВАННЫЕ ГЕТТЕРЫ СТАТУСОВ
        // =====================================================================
        public int GetBleedingLevel(BodyPart part) => GetLimbStatus(part).bleedingLevel;
        public bool HasLaceration(BodyPart part) => GetLimbStatus(part).hasLaceration;

        public int GetMaxBleedingLevel()
        {
            int maxLevel = 0;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                maxLevel = Mathf.Max(maxLevel, _limbStatuses[i].bleedingLevel);
            return maxLevel;
        }

        public bool HasAnyLaceration()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (_limbStatuses[i].hasLaceration) return true;
            return false;
        }

        public int GetBleedingLimbsCount()
        {
            int count = 0;
            for (int i = 0; i < SEGMENT_COUNT; i++)
                if (_limbStatuses[i].bleedingLevel > 0) count++;
            return count;
        }

        public BodyPart? GetPartWithMaxBleeding()
        {
            int maxLevel = 0;
            BodyPart? maxPart = null;
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                int level = _limbStatuses[i].bleedingLevel;
                if (level > maxLevel)
                {
                    maxLevel = level;
                    maxPart = (BodyPart)i;
                }
            }
            return maxPart;
        }

        private LimbStatus GetLimbStatus(BodyPart part) => _limbStatuses[(int)part];
        private void SetLimbStatus(BodyPart part, LimbStatus status) => _limbStatuses[(int)part] = status;

        // =====================================================================
        // ПРИНЯТИЕ УРОНА
        // =====================================================================
        public void TakeDamage(float damage, BodyPart part, DamageType type = DamageType.Generic, int weaponBleed = 0)
        {
            if (IsDead || damage <= 0f) return;

            var segment = _segments[(int)part];
            float overflow = segment.ApplyDamageWithOverflow(damage);

            // Каскад overflow: всё неголовное → Chest → Head.
            if (overflow > 0f)
            {
                if (part == BodyPart.Head)
                {
                    // overflow от головы никуда не идёт — она источник
                }
                else if (part == BodyPart.Chest)
                {
                    _segments[(int)BodyPart.Head].ApplyDamage(overflow);
                }
                else
                {
                    float chestOverflow = _segments[(int)BodyPart.Chest].ApplyDamageWithOverflow(overflow);
                    if (chestOverflow > 0f)
                        _segments[(int)BodyPart.Head].ApplyDamage(chestOverflow);
                }
            }

            if (type == DamageType.Firearm)
            {
                _shockTimer = FIREARM_SHOCK_DURATION;

                if (weaponBleed > 0)
                {
                    _limbStatuses[(int)part].bleedingLevel = Mathf.Max(
                        _limbStatuses[(int)part].bleedingLevel, weaponBleed);
                    _limbStatuses[(int)part].hasLaceration = true;
                }

                if (_canFracture[(int)part])
                {
                    float fractureMult = _cachedVitality != null ? _cachedVitality.FractureChanceMult : 1.0f;
                    float finalChance = FIREARM_FRACTURE_CHANCE * fractureMult;

                    if (segment.CurrentHP <= 0f)
                        ApplyFracture(part);
                    else if (UnityEngine.Random.value < finalChance)
                        ApplyFracture(part);
                }

                NotifyChange();
            }

            CheckDeathConditions();
            OnDamageTaken?.Invoke(part, damage, type);
            NotifyChange();
        }

        // =====================================================================
        // УРОН ОТ МЕТАБОЛИЗМА
        // =====================================================================
        public void TakeMetabolismDamage(float damage, BodyPart part)
        {
            if (IsDead || damage <= 0f) return;

            if (_segments[(int)BodyPart.Stomach].CurrentHP > 0f)
            {
                _segments[(int)BodyPart.Stomach].ApplyDamage(damage);
            }
            else
            {
                float damagePerSegment = damage / (float)SEGMENT_COUNT;
                for (int i = 0; i < SEGMENT_COUNT; i++)
                    _segments[i].ApplyDamage(damagePerSegment);
            }

            CheckDeathConditions();
            NotifyChange();
        }

        // =====================================================================
        // УРОН ОТ ХОЛОДА
        // =====================================================================
        public void ApplyColdDamage(float totalDamage)
        {
            if (IsDead) return;

            float remainingDamage = totalDamage;

            int activePrimaryTargets = 0;
            foreach (var part in ColdPrimaryTargets)
            {
                if (_segments[(int)part].CurrentHP > LIMB_HP_FLOOR)
                    activePrimaryTargets++;
            }

            if (activePrimaryTargets > 0)
            {
                float damagePerSegment = remainingDamage / activePrimaryTargets;

                foreach (var part in ColdPrimaryTargets)
                {
                    if (remainingDamage <= 0f) break;

                    var segment = _segments[(int)part];
                    if (segment.CurrentHP > LIMB_HP_FLOOR)
                    {
                        float damageToApply = Mathf.Min(damagePerSegment, segment.CurrentHP - LIMB_HP_FLOOR);
                        damageToApply = Mathf.Max(0f, damageToApply);

                        if (damageToApply > 0f)
                        {
                            segment.ApplyDamage(damageToApply);
                            remainingDamage -= damageToApply;
                        }
                    }
                }
            }

            if (remainingDamage > 0f)
            {
                int activeVitalTargets = 0;
                foreach (var part in ColdVitalTargets)
                {
                    if (_segments[(int)part].CurrentHP > 0f)
                        activeVitalTargets++;
                }

                if (activeVitalTargets > 0)
                {
                    float damagePerSegment = remainingDamage / activeVitalTargets;

                    foreach (var part in ColdVitalTargets)
                    {
                        if (remainingDamage <= 0f) break;

                        var segment = _segments[(int)part];
                        if (segment.CurrentHP > 0f)
                        {
                            float damageToApply = Mathf.Min(damagePerSegment, segment.CurrentHP);
                            if (damageToApply > 0f)
                            {
                                segment.ApplyDamage(damageToApply);
                                remainingDamage -= damageToApply;
                            }
                        }
                    }
                }
            }

            CheckDeathConditions();
            NotifyChange();
        }

        // =====================================================================
        // ПЕРЕЛОМЫ И ШИНЫ
        // =====================================================================
        private bool CanPartFracture(BodyPart part) => _canFracture[(int)part];

        public void ApplyFracture(BodyPart part)
        {
            if (!_canFracture[(int)part]) return;
            int i = (int)part;

            if (_fractured[i] && !_splinted[i]) return;

            if (_fractured[i] && _splinted[i])
                _fractured[i] = false;

            _splinted[i] = false;
            _fractured[i] = true;
            _segments[i].SetHP(0f);

            NotifyChange();
        }

        public void ApplySplint(BodyPart part)
        {
            int i = (int)part;
            if (!_fractured[i])
            {
                Debug.LogWarning($"[Health] Cannot apply splint to {part} — not fractured!");
                return;
            }

            _fractured[i] = false;
            _splinted[i] = true;
            if (_segments[i].CurrentHP <= 0f) _segments[i].SetHP(1f);

            NotifyChange();
        }

        public void RemoveSplint(BodyPart part)
        {
            _splinted[(int)part] = false;
            NotifyChange();
        }

        public bool IsFractured(BodyPart part) => _fractured[(int)part];
        public bool IsSplinted(BodyPart part) => _splinted[(int)part];

        // =====================================================================
        // ЛЕЧЕНИЕ
        // =====================================================================
        public void HealSegment(BodyPart part, float amount)
        {
            if (IsDead || amount <= 0f) return;
            if (HasAnyLaceration()) return;

            int i = (int)part;
            if (_fractured[i] && !_splinted[i])
            {
                Debug.Log($"[Health] Cannot heal {part} — fractured without splint!");
                return;
            }

            float segmentHealAmount = amount * LACERATION_HEAL_PENALTY;
            if (_segments[i].Heal(segmentHealAmount)) NotifyChange();
        }

        public void HealAll(float amount)
        {
            if (IsDead || amount <= 0f || HasAnyLaceration()) return;

            bool changed = false;
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                if (_fractured[i] && !_splinted[i]) continue;
                if (_segments[i].Heal(amount)) changed = true;
            }
            if (changed) NotifyChange();
        }

        private bool HandlePassiveHealing()
        {
            bool isLowVitality = _cachedVitality != null &&
                (_cachedVitality.Hunger <= 25f || _cachedVitality.Thirst <= 25f);
            bool isStarving = _cachedVitality != null &&
                (_cachedVitality.Hunger <= 0f || _cachedVitality.Thirst <= 0f);

            if (HasAnyLaceration() || GetMaxBleedingLevel() > 0 || isLowVitality || isStarving)
                return false;

            float passiveHealAmount = PASSIVE_HEAL_RATE * Time.deltaTime;
            bool changed = false;

            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                if (_segments[i].CurrentHP <= 0f) continue;
                if (_fractured[i] && !_splinted[i]) continue;
                if (_segments[i].Heal(passiveHealAmount)) changed = true;
            }

            return changed;
        }

        // =====================================================================
        // КРОВОТЕЧЕНИЕ
        // =====================================================================
       

     public void SetBleedingLevel(int level)
{
    for (int i = 0; i < SEGMENT_COUNT; i++)
        _limbStatuses[i].bleedingLevel = Mathf.Clamp(level, 0, 3);
    NotifyChange();
}
/// <summary>
/// Прямая установка уровня кровотечения на конкретном сегменте.
/// Используется коагулянтом. НЕ путать с SetBleedingLevel(int) —
/// тот ставит уровень на ВСЕ 20 сегментов (legacy).
/// </summary>
public void SetBleedingLevelOnPart(BodyPart part, int level)
{
    int i = (int)part;
    if (i < 0 || i >= SEGMENT_COUNT) return;
    _limbStatuses[i].bleedingLevel = Mathf.Clamp(level, 0, 3);
    if (level == 0)
        _limbStatuses[i].hasLaceration = false;
    NotifyChange();
}
public void StopBleeding()
{
    for (int i = 0; i < SEGMENT_COUNT; i++)
        _limbStatuses[i].bleedingLevel = 0;
    NotifyChange();
}

        // =====================================================================
        // БИНТЫ
        // =====================================================================
        public bool UseBandage(BodyPart? targetPart = null)
        {
            if (targetPart == null)
            {
                targetPart = GetPartWithMaxBleeding();
                if (targetPart == null)
                {
                    Debug.Log("[Health] No bleeding to stop!");
                    return false;
                }
            }

            LimbStatus status = GetLimbStatus(targetPart.Value);
            if (status.bleedingLevel == 0)
            {
                Debug.Log($"[Health] No bleeding on {targetPart}!");
                return false;
            }

            status.bleedingLevel = Mathf.Max(0, status.bleedingLevel - 1);
            SetLimbStatus(targetPart.Value, status);

            NotifyChange();
            return true;
        }

        // =====================================================================
        // ШОВНЫЙ НАБОР
        // =====================================================================
        public bool UseSutureKit(BodyPart? targetPart = null)
        {
            if (targetPart == null)
            {
                bool anyHealed = false;
                for (int i = 0; i < SEGMENT_COUNT; i++)
                {
                    var part = (BodyPart)i;
                    if (UseSutureKit(part)) anyHealed = true;
                }
                return anyHealed;
            }

            if (!HasLaceration(targetPart.Value))
            {
                Debug.Log($"[Health] No laceration on {targetPart}!");
                return false;
            }

            LimbStatus status = GetLimbStatus(targetPart.Value);
            status.hasLaceration = false;
            SetLimbStatus(targetPart.Value, status);

            NotifyChange();
            return true;
        }

        // =====================================================================
        // РАДИАЦИЯ
        // =====================================================================
        public void ApplyRadiationClamp(float radiationPercent)
        {
            if (radiationPercent >= 100f)
            {
                for (int i = 0; i < SEGMENT_COUNT; i++) _segments[i].SetHP(0f);
                Die();
                return;
            }

            float radiationFactor = Mathf.Clamp01(1.0f - radiationPercent / 100f);
            for (int i = 0; i < SEGMENT_COUNT; i++)
                _segments[i].SetMaxHP(_baseHP[i] * radiationFactor);

            ClampAllSegments();
            NotifyChange();
        }

        // =====================================================================
        // ВСПОМОГАТЕЛЬНЫЕ
        // =====================================================================
        private void ClampAllSegments()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++) _segments[i].ClampHP();
        }

        private void FixZeroHPWithoutFracture()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                if (!_canFracture[i]) continue;
                if (_segments[i].CurrentHP <= 0f && !_fractured[i])
                {
                    _fractured[i] = true;
                    _splinted[i] = false;
                }
            }
        }

        private void EnforceFractureHP()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                if (_fractured[i] && !_splinted[i] && _segments[i].CurrentHP > 0f)
                    _segments[i].SetHP(0f);
            }
        }

      private void CheckDeathConditions()
{
    if (IsDead) return;
    if (_segments == null || _segments.Length < SEGMENT_COUNT) return;
    if (_segments[(int)BodyPart.Head] == null) return;
    if (_segments[(int)BodyPart.Chest] == null) return;

    if (_segments[(int)BodyPart.Head].CurrentHP <= 0f ||
        _segments[(int)BodyPart.Chest].CurrentHP <= 0f)
        Die();
}
        private void Die()
        {
            if (!IsDead)
            {
                IsDead = true;
                OnDeath?.Invoke();
                Debug.Log("[K_HealthSystem] PLAYER DEAD");
            }
        }
/// <summary>
/// Принудительная смерть из внешней системы (например, обезвоживание кровью).
/// </summary>
public void ForceDeath()
{
    if (IsDead) return;
    Die();
}

/// <summary>
/// Распределённый урон по всем 20 сегментам (используется K_BloodSystem в состоянии Shock).
/// </summary>
public void ApplyDistributedDamage(float damage)
{
    if (IsDead || damage <= 0f) return;
    float perSegment = damage / (float)SEGMENT_COUNT;
    for (int i = 0; i < SEGMENT_COUNT; i++)
        _segments[i].ApplyDamage(perSegment);
    CheckDeathConditions();
}
        public bool HasBlockingDebuffs()
            => HasAnyLaceration() || GetMaxBleedingLevel() > 0 || HasFracture;

        public bool CanPassiveHeal()
        {
            bool isLowVitality = _cachedVitality != null &&
                (_cachedVitality.Hunger <= 25f || _cachedVitality.Thirst <= 25f);
            bool isStarving = _cachedVitality != null &&
                (_cachedVitality.Hunger <= 0f || _cachedVitality.Thirst <= 0f);
            return !HasBlockingDebuffs() && !isLowVitality && !isStarving;
        }

        private void NotifyChange()
        {
            IsDirty = true;
            OnHealthChanged?.Invoke();
        }

        // =====================================================================
        // СОХРАНЕНИЕ / ЗАГРУЗКА
        // =====================================================================
        public void Save(BinaryWriter writer)
        {
            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_segments[i].CurrentHP);
            writer.Write(_shockTimer);

            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                writer.Write(_limbStatuses[i].bleedingLevel);
                writer.Write(_limbStatuses[i].hasLaceration);
            }

            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_fractured[i]);
            for (int i = 0; i < SEGMENT_COUNT; i++) writer.Write(_splinted[i]);
        }

        public void Load(BinaryReader reader)
        {
            for (int i = 0; i < SEGMENT_COUNT; i++) _segments[i].SetHP(reader.ReadSingle());
            _shockTimer = reader.ReadSingle();

            for (int i = 0; i < SEGMENT_COUNT; i++)
            {
                _limbStatuses[i].bleedingLevel = reader.ReadInt32();
                _limbStatuses[i].hasLaceration = reader.ReadBoolean();
            }

            for (int i = 0; i < SEGMENT_COUNT; i++) _fractured[i] = reader.ReadBoolean();
            for (int i = 0; i < SEGMENT_COUNT; i++) _splinted[i] = reader.ReadBoolean();

            for (int i = 0; i < SEGMENT_COUNT; i++) _segments[i].ClampHP();
            EnforceFractureHP();
            NotifyChange();
        }

        // =====================================================================
        // BODY SEGMENT (внутренний класс — без изменений)
        // =====================================================================
        [Serializable]
        private class BodySegment
        {
            [SerializeField] private float _originalMaxHP;
            [SerializeField] private float _maxHP;
            [SerializeField] private float _currentHP;

            public float CurrentHP => _currentHP;
            public float MaxHP => _maxHP;
            public float OriginalMaxHP => _originalMaxHP;

            public BodySegment(float maxHP)
            {
                _originalMaxHP = maxHP;
                _maxHP = maxHP;
                _currentHP = maxHP;
            }

            public float ApplyDamageWithOverflow(float damage)
            {
                float actualDamage = Mathf.Min(_currentHP, damage);
                _currentHP = Mathf.Max(0f, _currentHP - actualDamage);
                return damage - actualDamage;
            }

            public void ApplyDamage(float damage)
            {
                _currentHP = Mathf.Max(0f, _currentHP - damage);
            }

            public bool Heal(float amount)
            {
                if (_currentHP <= 0f || _currentHP >= _maxHP) return false;
                float oldHP = _currentHP;
                _currentHP = Mathf.Min(_currentHP + amount, _maxHP);
                return _currentHP > oldHP;
            }

            public void SetHP(float value)
            {
                _currentHP = Mathf.Clamp(value, 0f, _maxHP);
            }

            public void SetMaxHP(float value)
            {
                _maxHP = Mathf.Max(1f, value);
                ClampHP();
            }

            public void ClampHP()
            {
                _currentHP = Mathf.Clamp(_currentHP, 0f, _maxHP);
            }
        }

        // =====================================================================
        // DEBUG
        // =====================================================================
        [ContextMenu("Debug: Set Bleeding Level 3 (Left Biceps)")]
        public void DebugSetBleeding()
        {
            _limbStatuses[(int)BodyPart.LeftBiceps].bleedingLevel = 3;
            _limbStatuses[(int)BodyPart.LeftBiceps].hasLaceration = true;
        }

        [ContextMenu("Debug: Stop All Bleeding")]
        public void DebugStopBleeding()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
                _limbStatuses[i].bleedingLevel = 0;
        }

        [ContextMenu("Debug: Remove All Lacerations")]
        public void DebugRemoveLaceration()
        {
            for (int i = 0; i < SEGMENT_COUNT; i++)
                _limbStatuses[i].hasLaceration = false;
        }

        [ContextMenu("Debug: Fracture Left Quadriceps")]
        public void DebugFractureLeftLeg() => ApplyFracture(BodyPart.LeftQuadriceps);

        [ContextMenu("Debug: Splint Left Quadriceps")]
        public void DebugSplintLeftLeg() => ApplySplint(BodyPart.LeftQuadriceps);

        [ContextMenu("Debug: Apply 50 Radiation")]
        public void DebugRadiation50() => ApplyRadiationClamp(50f);

        [ContextMenu("Debug: Apply 100 Radiation (Death)")]
        public void DebugRadiation100() => ApplyRadiationClamp(100f);
    }
}