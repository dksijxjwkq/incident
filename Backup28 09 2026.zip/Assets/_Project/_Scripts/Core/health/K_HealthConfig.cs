using UnityEngine;

namespace K_Incident.Core
{
    public enum DebuffKind
    {
        Concussion = 0,
        TBI = 1,
        BreathingDifficulty = 2,
        Immobilized = 3,
        InternalBleeding = 4
    }

    [System.Serializable]
    public struct DebuffConfig
    {
        [Tooltip("Имя дебафа для отладки (в логах).")]
        public string displayName;

        [Tooltip("Включён ли дебаф. Если false — не сработает, даже если триггер активен.")]
        public bool enabled;

        [Tooltip("Тип дебафа. НЕ МЕНЯТЬ — триггер зашит в логику K_DebuffSystem.")]
        public DebuffKind kind;

        [Tooltip("Длительность в секундах после срабатывания. " +
                 "0 = пока причина держится (перелом, HP сегмента). " +
                 ">0 = фиксированный таймер (Concussion).")]
        public float duration;

        [Tooltip("Множитель скорости движения. 1.0 = без штрафа.")]
        [Range(0f, 2f)] public float speedMultiplier;

        [Tooltip("Множитель восстановления стамины. 1.0 = без штрафа.")]
        [Range(0f, 2f)] public float staminaRegenMultiplier;

        [Tooltip("Множитель МАКСИМАЛЬНОЙ стамины. 1.0 = без изменений.")]
        [Range(0f, 2f)] public float staminaMaxMultiplier;

        [Tooltip("Множитель стабильности прицела. 1.0 = без штрафа. " +
                 "Меньше 1 = тряска прицела.")]
        [Range(0f, 2f)] public float aimStabilityMultiplier;

        [Tooltip("Запрещает спринт (бег). Ходьба работает.")]
        public bool blockSprint;

        [Tooltip("Множитель скорости потери крови. 1.0 = без изменений. " +
                 "2.0 = вдвое быстрее теряешь кровь.")]
        [Range(0f, 5f)] public float bloodDrainMultiplier;
    }

    [System.Serializable]
    public struct CoagulantConfig
    {
        [Tooltip("Включён ли коагулянт как предмет.")]
        public bool enabled;

        [Tooltip("Максимальный уровень кровотечения, который коагулянт останавливает ПОЛНОСТЬЮ. " +
                 "По умолчанию 2: level 1 и 2 → 0. Level 3 (артериальное) → снижается до 1, " +
                 "требуется жгут или хирург.")]
        [Range(1, 3)] public int fullStopMaxLevel;
    }

    [DefaultExecutionOrder(-1000)]
    public class K_HealthConfig : MonoBehaviour
    {
        public static K_HealthConfig Instance { get; private set; }

        [Header("══════ ПОРОГИ ТРИГГЕРОВ ДЕБАФОВ ══════")]

        [SerializeField, Tooltip("Минимальный урон выстрела в Голову для появления Сотрясения (Concussion). " +
            "Меньше порога — только HP-урон, дебаф не сработает.")]
        private float _concussionDamageThreshold = 15f;

        [SerializeField, Tooltip("Минимальный урон выстрела в Голову для появления ЧМТ (TBI). " +
            "Одновременно с TBI срабатывает и Сотрясение (если урон ≥ порога Сотрясения).")]
        private float _tbiDamageThreshold = 30f;

        [SerializeField, Range(0f, 1f), Tooltip("Порог HP живота (доля от максимума). " +
            "Если HP живота ниже — начинается Внутреннее кровотечение. 0.5 = ниже 50%.")]
        private float _internalBleedingHpThreshold = 0.5f;

        [Header("══════ ДЕБАФЫ (5 штук) ══════")]
        [SerializeField]
        private DebuffConfig[] _debuffs = new DebuffConfig[5]
        {
            new DebuffConfig {
                displayName = "Сотрясение",
                enabled = true,
                kind = DebuffKind.Concussion,
                duration = 60f,
                speedMultiplier = 0.85f,
                staminaRegenMultiplier = 1f,
                staminaMaxMultiplier = 1f,
                aimStabilityMultiplier = 0.7f,
                blockSprint = false,
                bloodDrainMultiplier = 1f
            },
            new DebuffConfig {
                displayName = "Тяжёлая ЧМТ",
                enabled = true,
                kind = DebuffKind.TBI,
                duration = 0f,
                speedMultiplier = 1f,
                staminaRegenMultiplier = 0.7f,
                staminaMaxMultiplier = 1f,
                aimStabilityMultiplier = 1f,
                blockSprint = false,
                bloodDrainMultiplier = 1f
            },
            new DebuffConfig {
                displayName = "Тяжело дышать",
                enabled = true,
                kind = DebuffKind.BreathingDifficulty,
                duration = 0f,
                speedMultiplier = 1f,
                staminaRegenMultiplier = 0.5f,
                staminaMaxMultiplier = 0.6f,
                aimStabilityMultiplier = 1f,
                blockSprint = true,
                bloodDrainMultiplier = 1f
            },
            new DebuffConfig {
                displayName = "Обездвижен",
                enabled = true,
                kind = DebuffKind.Immobilized,
                duration = 0f,
                speedMultiplier = 0.2f,
                staminaRegenMultiplier = 1f,
                staminaMaxMultiplier = 1f,
                aimStabilityMultiplier = 1f,
                blockSprint = true,
                bloodDrainMultiplier = 1f
            },
            new DebuffConfig {
                displayName = "Внутреннее кровотечение",
                enabled = true,
                kind = DebuffKind.InternalBleeding,
                duration = 0f,
                speedMultiplier = 1f,
                staminaRegenMultiplier = 1f,
                staminaMaxMultiplier = 1f,
                aimStabilityMultiplier = 1f,
                blockSprint = false,
                bloodDrainMultiplier = 2f
            }
        };

        [Header("══════ КОАГУЛЯНТ ══════")]
        [SerializeField] private CoagulantConfig _coagulant = new CoagulantConfig {
            enabled = true,
            fullStopMaxLevel = 2
        };

        public float ConcussionDamageThreshold => _concussionDamageThreshold;
        public float TbiDamageThreshold => _tbiDamageThreshold;
        public float InternalBleedingHpThreshold => _internalBleedingHpThreshold;
        public CoagulantConfig Coagulant => _coagulant;

        public DebuffConfig GetDebuff(DebuffKind kind)
        {
            for (int i = 0; i < _debuffs.Length; i++)
                if (_debuffs[i].kind == kind) return _debuffs[i];
            Debug.LogError($"[HealthConfig] DebuffKind.{kind} not found in config!");
            return default;
        }

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[HealthConfig] Duplicate instance — destroying.");
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void OnValidate()
        {
            if (_debuffs == null || _debuffs.Length != 5)
            {
                Debug.LogWarning("[HealthConfig] _debuffs должен быть массивом из 5 элементов. Автокоррекция.");
                var fixedArr = new DebuffConfig[5];
                if (_debuffs != null)
                    for (int i = 0; i < Mathf.Min(5, _debuffs.Length); i++)
                        fixedArr[i] = _debuffs[i];
                _debuffs = fixedArr;
            }
            for (int i = 0; i < _debuffs.Length; i++)
                for (int j = i + 1; j < _debuffs.Length; j++)
                    if (_debuffs[i].kind == _debuffs[j].kind)
                        Debug.LogError($"[HealthConfig] Duplicate DebuffKind.{_debuffs[i].kind} at indices {i} and {j}!");
        }
    }
}