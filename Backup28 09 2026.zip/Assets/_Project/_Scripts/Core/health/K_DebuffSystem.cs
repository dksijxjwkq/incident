using System;
using System.IO;
using UnityEngine;

namespace K_Incident.Core
{
    public class K_DebuffSystem : MonoBehaviour, ISaveable
    {
        [Header("References (auto-find)")]
        [SerializeField] private K_HealthSystem _healthSystem;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false;

        private const float DERIVED_CHECK_INTERVAL = 0.2f;
        private float _derivedCheckTimer;

        private float _concussionTimer;
        private bool _tbiActive;
        private bool _breathingActive;
        private bool _immobilizedActive;
        private bool _internalBleedingActive;

        private bool _lastConcussion, _lastTbi, _lastBreathing, _lastImmobilized, _lastInternalBleeding;

        public event Action OnDebuffsChanged;

        public bool HasConcussion => _concussionTimer > 0f;
        public bool HasTBI => _tbiActive;
        public bool HasBreathingDifficulty => _breathingActive;
        public bool HasImmobilized => _immobilizedActive;
        public bool HasInternalBleeding => _internalBleedingActive;

        public string SaveID => "PlayerDebuffs";
        public bool IsDirty { get; set; } = true;

        private void Awake()
        {
            if (_healthSystem == null) _healthSystem = GetComponent<K_HealthSystem>();
            if (_healthSystem == null)
                Debug.LogError("[DebuffSystem] K_HealthSystem not found!");
        }

        private void OnEnable()
        {
            if (_healthSystem != null)
                _healthSystem.OnDamageTaken += HandleDamageTaken;
        }

        private void OnDisable()
        {
            if (_healthSystem != null)
                _healthSystem.OnDamageTaken -= HandleDamageTaken;
        }

        private void Start()
        {
            K_SaveManager.Instance?.Register(this);
            RefreshDerivedDebuffs();
        }

        private void OnDestroy()
        {
            K_SaveManager.Instance?.Unregister(this);
            OnDebuffsChanged = null;
        }

        private void Update()
        {
            if (_concussionTimer > 0f)
            {
                _concussionTimer -= Time.deltaTime;
                if (_concussionTimer <= 0f)
                {
                    _concussionTimer = 0f;
                    if (_debugLogs) Debug.Log("[DebuffSystem] Concussion expired.");
                    FireChangedIfNeeded();
                }
            }

            _derivedCheckTimer += Time.deltaTime;
            if (_derivedCheckTimer >= DERIVED_CHECK_INTERVAL)
            {
                _derivedCheckTimer = 0f;
                RefreshDerivedDebuffs();
            }
        }

        private void HandleDamageTaken(BodyPart part, float damage, DamageType type)
        {
            if (part != BodyPart.Head) return;
            if (type != DamageType.Firearm) return;

            var config = K_HealthConfig.Instance;
            if (config == null)
            {
                Debug.LogWarning("[DebuffSystem] K_HealthConfig.Instance is null — cannot resolve debuff thresholds.");
                return;
            }

            if (!_tbiActive && damage >= config.TbiDamageThreshold)
            {
                var cfg = config.GetDebuff(DebuffKind.TBI);
                if (cfg.enabled)
                {
                    _tbiActive = true;
                    Debug.Log($"[DebuffSystem] TBI activated (damage {damage:F0} ≥ {config.TbiDamageThreshold:F0})");
                }
            }

            if (damage >= config.ConcussionDamageThreshold)
            {
                var cfg = config.GetDebuff(DebuffKind.Concussion);
                if (cfg.enabled)
                {
                    _concussionTimer = Mathf.Max(_concussionTimer, cfg.duration);
                    Debug.Log($"[DebuffSystem] Concussion activated/refreshed (damage {damage:F0}, timer {_concussionTimer:F0}s)");
                }
            }

            FireChangedIfNeeded();
        }

        private void RefreshDerivedDebuffs()
        {
            if (_healthSystem == null) return;

            bool breathing = _healthSystem.IsFractured(BodyPart.Chest) && !_healthSystem.IsSplinted(BodyPart.Chest);
            bool immobilized = _healthSystem.IsFractured(BodyPart.Pelvis) && !_healthSystem.IsSplinted(BodyPart.Pelvis);

            var config = K_HealthConfig.Instance;
            bool internalBleed = false;
            if (config != null)
            {
                float stomachMax = _healthSystem.GetMaxHP(BodyPart.Stomach);
                float stomachCur = _healthSystem.GetHP(BodyPart.Stomach);
                if (stomachMax > 0f)
                {
                    float ratio = stomachCur / stomachMax;
                    internalBleed = ratio < config.InternalBleedingHpThreshold;
                }
            }

            bool changed = false;
            if (_breathingActive != breathing) { _breathingActive = breathing; changed = true; }
            if (_immobilizedActive != immobilized) { _immobilizedActive = immobilized; changed = true; }
            if (_internalBleedingActive != internalBleed) { _internalBleedingActive = internalBleed; changed = true; }

            if (changed) FireChangedIfNeeded();
        }

        public float GetSpeedMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).speedMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).speedMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).speedMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).speedMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).speedMultiplier;
            return m;
        }

        public float GetStaminaRegenMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).staminaRegenMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).staminaRegenMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).staminaRegenMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).staminaRegenMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).staminaRegenMultiplier;
            return m;
        }

        public float GetStaminaMaxMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).staminaMaxMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).staminaMaxMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).staminaMaxMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).staminaMaxMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).staminaMaxMultiplier;
            return m;
        }

        public float GetAimStabilityMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).aimStabilityMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).aimStabilityMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).aimStabilityMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).aimStabilityMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).aimStabilityMultiplier;
            return m;
        }

        public bool IsSprintBlocked()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return false;

            if (HasConcussion && c.GetDebuff(DebuffKind.Concussion).blockSprint) return true;
            if (HasTBI && c.GetDebuff(DebuffKind.TBI).blockSprint) return true;
            if (HasBreathingDifficulty && c.GetDebuff(DebuffKind.BreathingDifficulty).blockSprint) return true;
            if (HasImmobilized && c.GetDebuff(DebuffKind.Immobilized).blockSprint) return true;
            if (HasInternalBleeding && c.GetDebuff(DebuffKind.InternalBleeding).blockSprint) return true;
            return false;
        }

        public float GetBloodDrainMultiplier()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return 1f;

            float m = 1f;
            if (HasConcussion)          m *= c.GetDebuff(DebuffKind.Concussion).bloodDrainMultiplier;
            if (HasTBI)                 m *= c.GetDebuff(DebuffKind.TBI).bloodDrainMultiplier;
            if (HasBreathingDifficulty) m *= c.GetDebuff(DebuffKind.BreathingDifficulty).bloodDrainMultiplier;
            if (HasImmobilized)         m *= c.GetDebuff(DebuffKind.Immobilized).bloodDrainMultiplier;
            if (HasInternalBleeding)    m *= c.GetDebuff(DebuffKind.InternalBleeding).bloodDrainMultiplier;
            return m;
        }

        private void FireChangedIfNeeded()
        {
            bool changed = false;
            if (_lastConcussion != HasConcussion) { _lastConcussion = HasConcussion; changed = true; }
            if (_lastTbi != HasTBI) { _lastTbi = HasTBI; changed = true; }
            if (_lastBreathing != HasBreathingDifficulty) { _lastBreathing = HasBreathingDifficulty; changed = true; }
            if (_lastImmobilized != HasImmobilized) { _lastImmobilized = HasImmobilized; changed = true; }
            if (_lastInternalBleeding != HasInternalBleeding) { _lastInternalBleeding = HasInternalBleeding; changed = true; }

            if (changed)
            {
                if (_debugLogs)
                {
                    Debug.Log($"[DebuffSystem] State: Concussion={HasConcussion} TBI={HasTBI} " +
                              $"Breathing={HasBreathingDifficulty} Immobilized={HasImmobilized} " +
                              $"InternalBleeding={HasInternalBleeding}");
                }
                IsDirty = true;
                OnDebuffsChanged?.Invoke();
            }
        }

        public void Save(BinaryWriter writer)
        {
            writer.Write(_concussionTimer);
            writer.Write(_tbiActive);
        }

        public void Load(BinaryReader reader)
        {
            _concussionTimer = reader.ReadSingle();
            _tbiActive = reader.ReadBoolean();
            RefreshDerivedDebuffs();
            FireChangedIfNeeded();
            IsDirty = false;
        }

        public void CureConcussion()
        {
            if (_concussionTimer <= 0f) return;
            _concussionTimer = 0f;
            Debug.Log("[DebuffSystem] Concussion cured.");
            FireChangedIfNeeded();
        }

        public void CureTBI()
        {
            if (!_tbiActive) return;
            _tbiActive = false;
            Debug.Log("[DebuffSystem] TBI cured.");
            FireChangedIfNeeded();
        }

        [ContextMenu("Debug: Apply Concussion (60s)")]
        public void DebugApplyConcussion()
        {
            var c = K_HealthConfig.Instance;
            if (c == null) return;
            _concussionTimer = c.GetDebuff(DebuffKind.Concussion).duration;
            FireChangedIfNeeded();
        }

        [ContextMenu("Debug: Apply TBI")]
        public void DebugApplyTBI()
        {
            _tbiActive = true;
            FireChangedIfNeeded();
        }

        [ContextMenu("Debug: Print State")]
        public void DebugPrintState()
        {
            Debug.Log($"[DebuffSystem] Concussion={HasConcussion} ({_concussionTimer:F1}s) " +
                      $"TBI={HasTBI} Breathing={HasBreathingDifficulty} " +
                      $"Immobilized={HasImmobilized} InternalBleeding={HasInternalBleeding}");
        }

        [ContextMenu("Debug: Cure All")]
        public void DebugCureAll()
        {
            _concussionTimer = 0f;
            _tbiActive = false;
            FireChangedIfNeeded();
        }
    }
}