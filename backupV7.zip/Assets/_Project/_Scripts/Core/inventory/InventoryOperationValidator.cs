using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
/// <summary>
/// ЕДИНСТВЕННАЯ read-only точка валидации операций swap и drop-into-backpack-icon.
/// Используется и DragHighlightController (обводка), и InventoryTransactionService
/// (pre-check перед исполнением). Расхождение highlight/транзакция исключено
/// конструктивно: оба вызывают одни и те же детерминированные методы.
///
/// Zero-alloc в hot-path: только static scratch-массив и struct'ы.
/// НЕ мутирует предметы (проверка поворота — через транспонирование размера).
/// </summary>
public static class InventoryOperationValidator
{
    private const int MaxGrid = 20; // совпадает с клампом InventoryData
    private static readonly bool[] _occ = new bool[MaxGrid * MaxGrid];

    private static bool IsUnfoldedBackpack(InventoryItem item) =>
        item != null && item.Data != null && item.Data.IsBackpack && !item.IsFolded;

   private static readonly List<InventoryItem> _footprintTargets = new List<InventoryItem>(8);
    

public static bool TryResolveSwap(
    InventoryItem dragged,
    InventoryItem target,
    InventoryController targetCtrl,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    List<InventoryController> relocationCtrls,
    out int swapX, out int swapY,
    out string reason)
{
    // ФИКС CS1061: Явно именуем элементы кортежа в fallback-ветке.
    // Без этого компилятор выводит тип (int, int) без имен полей,
    // и обращение к tRoot.x/tRoot.y ниже падает.
    var tRoot = targetCtrl != null && target != null
        ? targetCtrl.FindItemRootPosition(target.InstanceID)
        : (x: -1, y: -1);
        
    return TryResolveSwapPositions(dragged, target, targetCtrl, sourceCtrl,
        srcX, srcY, relocationCtrls, tRoot.x, tRoot.y,
        out swapX, out swapY, out _, out reason);
}

public static bool TryResolveSwapPositions(
    InventoryItem dragged,
    InventoryItem target,
    InventoryController targetCtrl,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    List<InventoryController> relocationCtrls,
    int anchorX, int anchorY,
    out int swapX, out int swapY,
    out int draggedRotation,
    out string reason)
{
    return TryResolveSwapPositions(
        dragged, target, targetCtrl, sourceCtrl, srcX, srcY,
        relocationCtrls, anchorX, anchorY,
        out swapX, out swapY, out draggedRotation, out reason,
        null);
}

// ═══ БАГ 2 ФИКС: перегрузка с BackpackContainerManager.
// Проверка развёрнутых рюкзаков теперь идентична транзакции. ═══
public static bool TryResolveSwapPositions(
    InventoryItem dragged,
    InventoryItem target,
    InventoryController targetCtrl,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    List<InventoryController> relocationCtrls,
    int anchorX, int anchorY,
    out int swapX, out int swapY,
    out int draggedRotation,
    out string reason,
    BackpackContainerManager backpackManager)
{
    swapX = swapY = -1;
    draggedRotation = dragged?.RotationAngle ?? 0;
    reason = string.Empty;

    if (dragged == null || target == null || targetCtrl == null || sourceCtrl == null)
    { reason = "null refs"; return false; }
    if (ReferenceEquals(dragged, target))
    { reason = "same item"; return false; }
    if (IsUnfoldedBackpack(dragged))
    { reason = "Unfolded backpack cannot be swapped (dragged)"; return false; }
    if (IsUnfoldedBackpack(target))
    { reason = "Unfolded backpack cannot be swapped (target)"; return false; }

    var tRoot = targetCtrl.FindItemRootPosition(target.InstanceID);
    if (tRoot.x == -1)
    { reason = "target not found in controller"; return false; }

    InventoryValidationService.PrepareSnapshotsForValidation(dragged, target);
    if (!InventoryValidationService.NestingCheckBidirectional(dragged, target))
    { reason = "Nesting cycle: cannot swap backpack with its descendant"; return false; }

    var s = dragged.CurrentSize;
    if (FindSwapPosition(targetCtrl, dragged, target, tRoot, s, sourceCtrl, srcX, srcY,
        relocationCtrls, anchorX, anchorY, backpackManager, out swapX, out swapY))
    {
        draggedRotation = dragged.RotationAngle;
        return true;
    }

    if (dragged.Data != null && dragged.Data.CanRotate && s.x != s.y)
    {
        var sRot = new Vector2Int(s.y, s.x);
        if (FindSwapPosition(targetCtrl, dragged, target, tRoot, sRot, sourceCtrl, srcX, srcY,
            relocationCtrls, anchorX, anchorY, backpackManager, out swapX, out swapY))
        {
            draggedRotation = (dragged.RotationAngle == 0) ? -90 : 0;
            return true;
        }
    }

    reason = "no feasible swap placement";
    return false;
}

private static bool FindSwapPosition(
    InventoryController targetCtrl,
    InventoryItem dragged,
    InventoryItem target,
    (int x, int y) tRoot,
    Vector2Int s,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    List<InventoryController> relocationCtrls,
    int anchorX, int anchorY,
    BackpackContainerManager backpackManager,
    out int swapX, out int swapY)
{
    swapX = swapY = -1;

    int minX = Mathf.Max(0, tRoot.x - s.x + 1);
    int maxX = Mathf.Min(targetCtrl.Width - s.x, tRoot.x + target.CurrentSize.x - 1);
    int minY = Mathf.Max(0, tRoot.y - s.y + 1);
    int maxY = Mathf.Min(targetCtrl.Height - s.y, tRoot.y + target.CurrentSize.y - 1);

    if (minX > maxX || minY > maxY) return false;

    // ═══ БАГ 1 ФИКС (parity): srcBlocked резервирует ИСХОДНЫЙ ФУТПРИНТ ТАЩИМОГО
    // (dragged.CurrentSize), а не футпринт primary target. Раньше размер был
    // target.CurrentSize — non-primary цели могли «встать» в клетки тащимого,
    // которые фактически зарезервированы для primary. ═══
    var draggedSize = dragged.CurrentSize;
    var srcBlocked = new RectInt(srcX, srcY, draggedSize.x, draggedSize.y);

    int bestDist = int.MaxValue;
    for (int y = minY; y <= maxY; y++)
    {
        for (int x = minX; x <= maxX; x++)
        {
            if (!CollectFootprintTargets(targetCtrl, x, y, s, dragged, target))
                continue;

            int d = Mathf.Abs(x - anchorX) + Mathf.Abs(y - anchorY);
            if (d >= bestDist) continue;

            if (!CanRelocateTargets(target, sourceCtrl, srcX, srcY,
                dragged, relocationCtrls, srcBlocked, backpackManager))
                continue;

            bestDist = d;
            swapX = x;
            swapY = y;
        }
    }
    return bestDist != int.MaxValue;
}
private static bool CollectFootprintTargets(
    InventoryController ctrl, int x, int y, Vector2Int size,
    InventoryItem dragged, InventoryItem primaryTarget)
{
    _footprintTargets.Clear();
    bool hasPrimary = false;
    for (int dy = 0; dy < size.y; dy++)
    for (int dx = 0; dx < size.x; dx++)
    {
        var occ = ctrl.GetItemAt(x + dx, y + dy);
        if (occ == null || ReferenceEquals(occ, dragged)) continue;
        if (IsUnfoldedBackpack(occ)) { _footprintTargets.Clear(); return false; }
        if (ReferenceEquals(occ, primaryTarget)) hasPrimary = true;
        if (!_footprintTargets.Contains(occ)) _footprintTargets.Add(occ);
    }
    if (!hasPrimary) { _footprintTargets.Clear(); return false; }
    return true;
}

// ═══ БАГ 1 ФИКС: строгая замена по разделу 3 — ВСЕ цели обязаны поместиться
// ВНУТРИ освобождённого исходного футпринта тащимого (srcBlocked),
// последовательно, с авто-поворотом каждой. Никакого FitAnywhereIgnoring,
// никакого поиска «другого места» в source/player grids. ═══
private static bool CanRelocateTargets(
    InventoryItem primaryTarget,
    InventoryController sourceCtrl, int srcX, int srcY,
    InventoryItem dragged,
    List<InventoryController> relocationCtrls,
    RectInt srcBlocked,
    BackpackContainerManager backpackManager)
{
    // Свободного футпринта нет — строгий swap невозможен.
    if (srcBlocked.width <= 0 || srcBlocked.height <= 0) return false;
    if (sourceCtrl == null) return false;

    int fw = srcBlocked.width;
    int fh = srcBlocked.height;

    // Локальная bitmap по статическому буферу _occ (Zero-alloc в hot-path).
    // true = ячейка в freed-footprint уже занята (ранее размещённой целью).
    if (fw * fh > _occ.Length) return false;
    System.Array.Clear(_occ, 0, fw * fh);

    for (int i = 0; i < _footprintTargets.Count; i++)
    {
        var t = _footprintTargets[i];
        if (t == null) return false;

        // Развёрнутый рюкзак — не цель свапа (единое правило).
        if (IsUnfoldedBackpack(t)) return false;

        if (!TryFitInsideFreedFootprint(sourceCtrl, t, dragged,
                srcBlocked, _footprintTargets, _occ, backpackManager,
                out int placeX, out int placeY))
            return false;

        // Пометить размещение в bitmap для следующих целей.
        var size = t.CurrentSize;
        for (int dy = 0; dy < size.y; dy++)
            for (int dx = 0; dx < size.x; dx++)
                _occ[(placeY - srcBlocked.y + dy) * fw + (placeX - srcBlocked.x + dx)] = true;
    }
    return true;
}

// ═══ БАГ 1 ФИКС: строгий fit ВНУТРИ freed-footprint (srcBlocked).
// Возвращает true и позицию, если предмет влезает целиком внутри freed-footprint,
// не пересекаясь с ранее размещёнными целями (tracked в occ) и не нарушая
// ограничений backpackManager. ═══
private static bool TryFitInsideFreedFootprint(
    InventoryController ctrl, InventoryItem item, InventoryItem dragged,
    RectInt freed, List<InventoryItem> ignore, bool[] occ,
    BackpackContainerManager backpackManager,
    out int placeX, out int placeY)
{
    placeX = placeY = -1;
    if (ctrl == null || item == null || item.Data == null) return false;
    if (freed.width <= 0 || freed.height <= 0) return false;

    // Текущая ориентация.
    var size = item.CurrentSize;
    if (TryFitOneOrientation(ctrl, item, dragged, ignore, freed, occ, size,
            out placeX, out placeY))
        return true;

    // Авто-поворот.
    if (item.Data.CanRotate && size.x != size.y)
    {
        var rot = new Vector2Int(size.y, size.x);
        if (TryFitOneOrientation(ctrl, item, dragged, ignore, freed, occ, rot,
                out placeX, out placeY))
            return true;
    }
    return false;
}

private static bool TryFitOneOrientation(
    InventoryController ctrl, InventoryItem item, InventoryItem dragged,
    List<InventoryItem> ignore, RectInt freed, bool[] occ, Vector2Int size,
    out int placeX, out int placeY)
{
    placeX = placeY = -1;
    if (size.x > freed.width || size.y > freed.height) return false;
    int fw = freed.width;

    for (int y = 0; y <= freed.height - size.y; y++)
    {
        for (int x = 0; x <= freed.width - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    int cx = freed.x + x + dx;
                    int cy = freed.y + y + dy;

                    // Вне границ контроллера — нельзя.
                    if (cx < 0 || cy < 0 ||
                        cx >= ctrl.Width || cy >= ctrl.Height)
                    { free = false; break; }

                    // Ячейка занята живой целью в ctrl (не ignored).
                    var occupant = ctrl.GetItemAt(cx, cy);
                    if (occupant != null
                        && !ReferenceEquals(occupant, dragged)
                        && !ReferenceEquals(occupant, item)
                        && (ignore == null || !ignore.Contains(occupant)))
                    { free = false; break; }

                    // Ячейка занята ранее размещённой целью из occ.
                    if (occ[(y + dy) * fw + (x + dx)])
                    { free = false; break; }
                }
            }
            if (free)
            {
                placeX = freed.x + x;
                placeY = freed.y + y;
                return true;
            }
        }
    }
    return false;
}


   private static bool FitIgnoring(
    InventoryController ctrl, InventoryItem item, int x, int y,
    InventoryItem dragged, List<InventoryItem> ignore, RectInt blocked)
{
    if (ctrl == null) return false;
    var size = item.CurrentSize;
    if (x < 0 || y < 0 || x + size.x > ctrl.Width || y + size.y > ctrl.Height)
        return false;
    // Inline RegionFree: нет локального RegionFree после удаления (БАГ 1 ФИКС).
    for (int dy = 0; dy < size.y; dy++)
    for (int dx = 0; dx < size.x; dx++)
    {
        int cx = x + dx, cy = y + dy;
        if (blocked.width > 0 && blocked.height > 0 &&
            cx >= blocked.x && cy >= blocked.y &&
            cx < blocked.x + blocked.width && cy < blocked.y + blocked.height)
            return false;
        var occ = ctrl.GetItemAt(cx, cy);
        if (occ == null) continue;
        if (dragged != null && ReferenceEquals(occ, dragged)) continue;
        if (ignore != null && ignore.Contains(occ)) continue;
        return false;
    }
    return true;
}

// InventoryOperationValidator.cs — ПОЛНАЯ ЗАМЕНА ValidateDropIntoBackpack()
// БАГ 3: цель с открытым окном (live-контроллер) НЕ отклоняется по глубине.
public static bool ValidateDropIntoBackpack(
    InventoryItem item,
    InventoryItem targetBackpack,
    BackpackContainerManager backpacks,
    out string reason)
{
    reason = string.Empty;
    if (item == null || targetBackpack == null ||
        targetBackpack.Data == null || !targetBackpack.Data.IsBackpack)
    { reason = "Invalid target"; return false; }
    if (ReferenceEquals(item, targetBackpack))
    { reason = "Self drop"; return false; }
    if (targetBackpack.IsFolded && !targetBackpack.Data.AlwaysShowGrid)
    { reason = "Cannot drop into folded backpack"; return false; }
    if (!targetBackpack.HasInternalGrid)
    { reason = "Invalid target"; return false; }

    InventoryController live = backpacks != null
        ? backpacks.GetLiveController(targetBackpack.InstanceID.ToString())
        : null;

    if (backpacks != null)
    {
        // Лимит матрёшки для РАЗВЁРНУТОГО тащимого — единая точка правды. НЕ ТРОГАЕМ.
        if (IsUnfoldedBackpack(item))
        {
            if (!backpacks.CanPlaceUnfoldedBackpack(targetBackpack, item, out reason))
                return false;
        }
        // БАГ 3 ФИКС: глубина режет ТОЛЬКО когда окно цели закрыто (live == null).
        // Открытое окно = сетка физически доступна, item упадёт в live-контроллер.
        if (live == null)
        {
            int targetDepth = backpacks.GetNestingDepth(targetBackpack);
            if (targetDepth >= BackpackContainerManager.MaxOpenFloatingWindows)
            {
                reason = $"Целевой рюкзак на глубине {targetDepth} — физически недоступен " +
                         $"(лимит {BackpackContainerManager.MaxOpenFloatingWindows} переносные сетки).";
                return false;
            }
        }
    }

    if (item.Data != null && item.Data.IsBackpack)
    {
        InventoryValidationService.PrepareSnapshotsForValidation(item, targetBackpack);
        if (item.ContainsDescendantStrict(targetBackpack.InstanceID))
        { reason = "Nesting cycle: cannot drop backpack into its descendant"; return false; }
    }

    if (live != null)
        return FitEmptyAnywhere(live, item);
    return FitEmptyInSnapshot(targetBackpack.GetBackpackSavedItems(), targetBackpack.Data, item);
}
    
    private static bool FitEmptyAnywhere(InventoryController ctrl, InventoryItem item)
    {
        if (ctrl == null || item.Data == null) return false;
        var size = item.CurrentSize;
        if (ScanEmpty(ctrl, size)) return true;
        if (item.Data.CanRotate && size.x != size.y)
            return ScanEmpty(ctrl, new Vector2Int(size.y, size.x));
        return false;
    }

    private static bool ScanEmpty(InventoryController ctrl, Vector2Int size)
    {
        for (int y = 0; y <= ctrl.Height - size.y; y++)
        {
            for (int x = 0; x <= ctrl.Width - size.x; x++)
            {
                bool free = true;
                for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    if (ctrl.GetItemAt(x + dx, y + dy) != null) { free = false; break; }
                }
                if (free) return true;
            }
        }
        return false;
    }

    private static bool FitEmptyInSnapshot(
        List<SavedItem> saved, ItemStaticData targetData, InventoryItem item)
    {
        int w = targetData.BackpackWidth;
        int h = targetData.BackpackHeight;
        if (w <= 0 || h <= 0 || w > MaxGrid || h > MaxGrid) return false;
        if (item.Data == null) return false;

        System.Array.Clear(_occ, 0, w * h);
        if (saved != null)
        {
            var db = K_InventorySetup.DatabaseInstance;
            for (int i = 0; i < saved.Count; i++)
            {
                var s = saved[i];
                var d = db != null ? db.GetItemData(s.ItemID) : null;
                if (d == null) continue;
                var sz = SavedItemFootprint(s, d);
                for (int dy = 0; dy < sz.y; dy++)
                for (int dx = 0; dx < sz.x; dx++)
                {
                    int cx = s.X + dx, cy = s.Y + dy;
                    if (cx >= 0 && cy >= 0 && cx < w && cy < h)
                        _occ[cy * w + cx] = true;
                }
            }
        }

        var size = item.CurrentSize;
        if (ScanEmptySnapshot(w, h, size)) return true;
        if (item.Data.CanRotate && size.x != size.y)
            return ScanEmptySnapshot(w, h, new Vector2Int(size.y, size.x));
        return false;
    }

    private static bool ScanEmptySnapshot(int w, int h, Vector2Int size)
    {
        for (int y = 0; y <= h - size.y; y++)
        {
            for (int x = 0; x <= w - size.x; x++)
            {
                bool free = true;
                for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    if (_occ[(y + dy) * w + (x + dx)]) { free = false; break; }
                }
                if (free) return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Футпринт SavedItem в сетке рюкзака — зеркалит InventoryItem.CacheSizes:
    /// folded→SizeFolded, рюкзак→UnfoldedIconSize/BackpackW×H, иначе Size;
    /// IsRotated транспонирует. Без аллокации InventoryItem.
    /// </summary>
    private static Vector2Int SavedItemFootprint(SavedItem s, ItemStaticData d)
    {
        Vector2Int n;
        if (s.IsFolded && d.CanFold)
            n = d.SizeFolded;
        else if (d.IsBackpack && d.UnfoldedIconSize.x > 0 && d.UnfoldedIconSize.y > 0)
            n = d.UnfoldedIconSize;
        else if (d.IsBackpack && d.BackpackWidth > 0 && d.BackpackHeight > 0)
            n = new Vector2Int(d.BackpackWidth, d.BackpackHeight);
        else
            n = d.Size;
        return (s.IsRotated && d.CanRotate) ? new Vector2Int(n.y, n.x) : n;
    }
    // ═══════════════════════════════════════════════════════════
//  EQUIP SWAP: рюкзак на занятый слот рюкзака
// ═══════════════════════════════════════════════════════════

/// <summary>
/// Валидация свапа рюкзака через слот экипировки.
/// Вызывается И из DragHighlightController.HighlightEquipmentSlot,
/// И из InventoryTransactionService.TryEquipFromDrag.
///
/// Правила:
///   1. Тащимый НЕ должен быть потомком экипированного.
///   2. Старый экипированный рюкзак (развёрнутый) должен помещаться
///      в ИСХОДНУЮ сетку тащимого: родная клетка → скан с авто-поворотом.
///   3. Если не помещается — свап запрещён.
///
/// out placeX/placeY — позиция размещения старого рюкзака.
/// </summary>
public static bool TryResolveEquipSwap(
    InventoryItem draggedBackpack,
    InventoryItem equippedBackpack,
    InventoryController sourceCtrl,
    int srcX, int srcY,
    out int placeX, out int placeY,
    out string reason)
{
    placeX = placeY = -1;
    reason = string.Empty;

    if (draggedBackpack == null || equippedBackpack == null || sourceCtrl == null)
    { reason = "null refs"; return false; }

    if (draggedBackpack.Data == null || !draggedBackpack.Data.IsBackpack)
    { reason = "dragged item is not a backpack"; return false; }

    if (equippedBackpack.Data == null || !equippedBackpack.Data.IsBackpack)
    { reason = "equipped item is not a backpack"; return false; }

    // УДАЛЕНА проверка IsUnfoldedBackpack(draggedBackpack)
    // Развёрнутый тащимый разрешён (спека п.4.4)

    // Цикл: тащимый не должен быть потомком экипированного и наоборот
    InventoryValidationService.PrepareSnapshotsForValidation(draggedBackpack, equippedBackpack);
    if (!InventoryValidationService.NestingCheckBidirectional(draggedBackpack, equippedBackpack))
    { reason = "Nesting cycle: dragged backpack is inside equipped backpack"; return false; }

    // Старый рюкзак будет размещён РАЗВЁРНУТЫМ. Его CurrentSize = развёрнутый.
    // Проверяем размещение в ИСХОДНОЙ сетке тащимого.

    // 1. Родная клетка тащимого (игнорируем тащимый — он будет удалён)
    var oldSize = equippedBackpack.CurrentSize;
    if (FitIgnoringExact(sourceCtrl, equippedBackpack, srcX, srcY, draggedBackpack))
    {
        placeX = srcX;
        placeY = srcY;
        return true;
    }

    // 2. Скан исходной сетки (текущая ориентация)
    if (ScanFreeIgnoringItem(sourceCtrl, oldSize, draggedBackpack, out placeX, out placeY))
        return true;

    // 3. Скан с авто-поворотом
    if (equippedBackpack.Data.CanRotate && oldSize.x != oldSize.y)
    {
        var rotSize = new Vector2Int(oldSize.y, oldSize.x);
        if (ScanFreeIgnoringItem(sourceCtrl, rotSize, draggedBackpack, out placeX, out placeY))
            return true;
    }

    reason = "No space for old equipped backpack in source grid";
    return false;
}
private static bool FitIgnoringExact(
    InventoryController ctrl, InventoryItem item, int x, int y, InventoryItem ignored)
{
    if (ctrl == null || item == null) return false;
    var size = item.CurrentSize;
    if (x < 0 || y < 0 || x + size.x > ctrl.Width || y + size.y > ctrl.Height)
        return false;
    for (int dy = 0; dy < size.y; dy++)
        for (int dx = 0; dx < size.x; dx++)
        {
            var occ = ctrl.GetItemAt(x + dx, y + dy);
            if (occ == null) continue;
            if (ReferenceEquals(occ, ignored)) continue;
            if (ReferenceEquals(occ, item)) continue;
            return false;
        }
    return true;
}

/// <summary>
/// Скан сетки на свободное место заданного размера, игнорируя один предмет.
/// Zero-alloc: только стеловые переменные.
/// </summary>
private static bool ScanFreeIgnoringItem(
    InventoryController ctrl, Vector2Int size, InventoryItem ignored,
    out int px, out int py)
{
    px = py = -1;
    if (ctrl == null || size.x <= 0 || size.y <= 0) return false;
    if (size.x > ctrl.Width || size.y > ctrl.Height) return false;

    for (int y = 0; y <= ctrl.Height - size.y; y++)
    {
        for (int x = 0; x <= ctrl.Width - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    var occ = ctrl.GetItemAt(x + dx, y + dy);
                    if (occ != null && !ReferenceEquals(occ, ignored))
                    { free = false; break; }
                }
            if (free) { px = x; py = y; return true; }
        }
    }
    return false;
}

// ═══════════════════════════════════════════════════════════
//  DROP INTO EQUIPPED BACKPACK: обычный предмет → сетка экипированного
// ═══════════════════════════════════════════════════════════

/// <summary>
/// Валидация дропа ОБЫЧНОГО предмета (не рюкзак) в сетку экипированного рюкзака.
/// Empty-only скан с авто-поворотом — зеркалирует логику размещения.
///
/// Вызывается И из DragHighlightController.HighlightEquipmentSlot,
/// И из InventoryTransactionService.TryDropIntoEquippedBackpack.
/// </summary>
public static bool ValidateDropIntoEquippedBackpack(
    InventoryItem item,
    InventoryController backpackCtrl,
    out int placeX, out int placeY,
    out string reason)
{
    placeX = placeY = -1;
    reason = string.Empty;

    if (item == null || backpackCtrl == null)
    { reason = "null refs"; return false; }

    if (item.Data == null)
    { reason = "invalid item"; return false; }

    // Рюкзаки не идут по этому пути — для них TryResolveEquipSwap
    if (item.Data.IsBackpack)
    { reason = "backpack items use equip swap path"; return false; }

    var size = item.CurrentSize;

    // Скан текущей ориентации
    if (ScanEmptyWithPosition(backpackCtrl, size, out placeX, out placeY))
        return true;

    // Авто-поворот
    if (item.Data.CanRotate && size.x != size.y)
    {
        if (ScanEmptyWithPosition(backpackCtrl, new Vector2Int(size.y, size.x), out placeX, out placeY))
            return true;
    }

    reason = "No free space in equipped backpack";
    return false;
}

/// <summary>
/// Empty-only скан с возвратом позиции. Zero-alloc.
/// </summary>
private static bool ScanEmptyWithPosition(
    InventoryController ctrl, Vector2Int size, out int px, out int py)
{
    px = py = -1;
    if (ctrl == null || size.x <= 0 || size.y <= 0) return false;
    if (size.x > ctrl.Width || size.y > ctrl.Height) return false;

    for (int y = 0; y <= ctrl.Height - size.y; y++)
    {
        for (int x = 0; x <= ctrl.Width - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    if (ctrl.GetItemAt(x + dx, y + dy) != null)
                    { free = false; break; }
                }
            if (free) { px = x; py = y; return true; }
        }
    }
    return false;
}
}
}
