﻿using K_Incident.Core.Inventory;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
public class InventoryTransactionService : MonoBehaviour
{
    // ═══ Singleton ═══
    private static InventoryTransactionService _instance;
    public static InventoryTransactionService Instance
    {
        get
        {
            if (_instance != null) return _instance;
            _instance = FindFirstObjectByType<InventoryTransactionService>();
            if (_instance == null)
            {
                var go = new GameObject(nameof(InventoryTransactionService));
                _instance = go.AddComponent<InventoryTransactionService>();
            }
            return _instance;
        }
    }

    private void Awake()
    {
        if (_instance != null && _instance != this) { Destroy(gameObject); return; }
        _instance = this;
    }

    private void OnDestroy()
    {
        if (_instance == this) _instance = null;
    }

    [Header("References (auto-found if empty)")]
    [SerializeField] private K_InventoryUI _inventoryUI;
    private readonly List<K_EquipmentSlotUI> _cachedSlots = new(8);
    private bool _slotsCached;

    private bool _isTransactionActive;
    private readonly List<ItemSnapshot> _snapshots = new(4);
    private readonly List<PlacementRecord> _placements = new(4);
    private readonly Dictionary<uint, InventoryItem> _inHandItems = new(4);
    private readonly List<InventoryController> _relocBuffer = new List<InventoryController>(8);
    private struct PlacementRecord
    {
        public readonly InventoryItem Item;
        public readonly InventoryController Controller;
        public readonly int X;
        public readonly int Y;
        public readonly K_EquipmentSlotUI Slot;
        public readonly bool InSlot;

        public PlacementRecord(InventoryItem item, InventoryController controller, int x, int y)
        { Item = item; Controller = controller; X = x; Y = y; Slot = null; InSlot = false; }

        public PlacementRecord(InventoryItem item, K_EquipmentSlotUI slot)
        { Item = item; Controller = null; X = 0; Y = 0; Slot = slot; InSlot = true; }
    }

    public bool IsTransactionActive => _isTransactionActive;

    // ═══════════════════════════════════════════════════════════════
    //  SWAP
    // ═══════════════════════════════════════════════════════════════
// ============================================================
//  TrySwapItems – исправленный (удалён CloseDraggedBackpackWindowIfCrossController)
// ============================================================
public bool TrySwapItems(UI_Item draggedUI, UI_Item targetUI, int anchorX, int anchorY, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || targetUI == null) { errorMessage = "Null UI references"; return false; }
    var itemA = draggedUI.Item;
    if (itemA == null) { errorMessage = "Invalid items"; return false; }
    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }
    var ctrlA = GetControllerForUI(draggedUI);
    var ctrlB = GetControllerForUI(targetUI);
    if (ctrlA == null || ctrlB == null) { errorMessage = "No controller for source or target"; return false; }
    var (ax, ay) = FindItemPositionInController(ctrlA, itemA);
    if (ax == -1) { errorMessage = "Item A not found in ctrlA (UI_Item desync)"; return false; }
    _inventoryUI.SyncBackpackForValidation(itemA);
    _inventoryUI.SyncBackpackForValidation(targetUI.Item);

    if (!InventoryOperationValidator.TryResolveSwapPositions(
        itemA, targetUI.Item, ctrlB, ctrlA, ax, ay,
        BuildRelocationControllers(ctrlB),
        anchorX, anchorY,
        out int bx, out int by, out int draggedRotation, out errorMessage,
        _inventoryUI.BackpackManager))
        return false;

    Vector2Int originalASize = itemA.CurrentSize;
    Vector2Int effectiveASize = itemA.CurrentSize;
    if (draggedRotation != itemA.RotationAngle)
    {
        effectiveASize = new Vector2Int(effectiveASize.y, effectiveASize.x);
    }
    var tRoot = ctrlB.FindItemRootPosition(targetUI.Item.InstanceID);
    var t = targetUI.Item.CurrentSize;
    var targets = new HashSet<InventoryItem>(4);
    for (int dy = 0; dy < effectiveASize.y; dy++)
        for (int dx = 0; dx < effectiveASize.x; dx++)
        {
            var occ = ctrlB.GetItemAt(bx + dx, by + dy);
            if (occ != null && !ReferenceEquals(occ, itemA) && !ReferenceEquals(occ, targetUI.Item))
                targets.Add(occ);
        }
    for (int dy = 0; dy < t.y; dy++)
        for (int dx = 0; dx < t.x; dx++)
        {
            var occ = ctrlB.GetItemAt(tRoot.x + dx, tRoot.y + dy);
            if (occ != null && !ReferenceEquals(occ, itemA) && !ReferenceEquals(occ, targetUI.Item))
                targets.Add(occ);
        }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(itemA, draggedUI.GridType, ax, ay, GetContainerOwnerId(draggedUI)));
        _snapshots.Add(ItemSnapshot.FromGrid(targetUI.Item, targetUI.GridType, tRoot.x, tRoot.y, GetContainerOwnerId(targetUI)));
        foreach (var tItem in targets)
        {
            var (tx, ty) = FindItemPositionInController(ctrlB, tItem);
            if (tx == -1) { errorMessage = "Target item not found in ctrlB"; Rollback(); return false; }
            _snapshots.Add(ItemSnapshot.FromGrid(tItem, targetUI.GridType, tx, ty, GetContainerOwnerId(targetUI)));
        }

        // ═══ УДАЛЁН CloseDraggedBackpackWindowIfCrossController — окно источника НЕ закрываем ═══

        if (!ctrlA.RemoveItem(itemA))
        { errorMessage = "Failed to remove item A from source controller"; Rollback(); return false; }
        _inHandItems[itemA.InstanceID] = itemA;

        if (!ctrlB.RemoveItem(targetUI.Item))
        { errorMessage = "Failed to remove primary target"; Rollback(); return false; }
        _inHandItems[targetUI.Item.InstanceID] = targetUI.Item;

        foreach (var tItem in targets)
        {
            if (!ctrlB.RemoveItem(tItem))
            { errorMessage = "Failed to remove target item"; Rollback(); return false; }
            _inHandItems[tItem.InstanceID] = tItem;
        }

        if (draggedRotation != itemA.RotationAngle)
        {
            itemA.Rotate();
        }

        if (!InventoryValidationService.GridSpaceCheck(ctrlB, itemA, bx, by)
            || !ctrlB.PlaceExistingItem(itemA, bx, by))
        {
            errorMessage = $"Item A: cannot place at validated swap position ({bx},{by})";
            Rollback();
            return false;
        }
        _placements.Add(new PlacementRecord(itemA, ctrlB, bx, by));
        _inHandItems.Remove(itemA.InstanceID);

        var freedFootprint = new RectInt(ax, ay, originalASize.x, originalASize.y);

        if (!TryPlaceTargetStrict(ctrlA, targetUI.Item, ax, ay, freedFootprint))
        {
            errorMessage = "Primary target does not fit in freed footprint (strict swap)";
            Rollback();
            return false;
        }
        foreach (var tItem in targets)
        {
            if (!TryPlaceTargetStrict(ctrlA, tItem, ax, ay, freedFootprint))
            {
                errorMessage = "Target does not fit in freed footprint (strict swap)";
                Rollback();
                return false;
            }
        }

        if (!ValidateSwapFinalGeometry(ctrlA, ctrlB))
        {
            errorMessage = "Final geometry validation failed (bounds/overlap)";
            Rollback();
            return false;
        }

        Commit();
        AssertGridIntegrity(ctrlA, ctrlB);
        Debug.Log($"[Swap] committed: '{itemA.Data?.DisplayName}' -> ({bx},{by}) rot={itemA.RotationAngle}; " +
                  $"'{targetUI.Item.Data?.DisplayName}' -> origin ({ax},{ay}); thirdParty={targets.Count}");
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}
private bool TryPlaceTargetStrict(
    InventoryController ctrl, InventoryItem item,
    int originX, int originY, RectInt freed)
{
    if (ctrl == null || item == null || item.Data == null) return false;

    int fw = freed.width;
    int fh = freed.height;
    if (fw <= 0 || fh <= 0) return false;

    // Создаём bitmap по текущему состоянию ctrl в пределах freed-footprint.
    // true = ячейка занята (живой целью, не являющейся этим item).
    var occupied = new bool[fw * fh];
    for (int dy = 0; dy < fh; dy++)
        for (int dx = 0; dx < fw; dx++)
        {
            var occ = ctrl.GetItemAt(freed.x + dx, freed.y + dy);
            if (occ != null) occupied[dy * fw + dx] = true;
        }

    // Пробуем текущую ориентацию, затем повёрнутую.
    if (TryPlaceOneOrientationStrict(ctrl, item, freed, occupied, out int px, out int py))
    {
        return ctrl.PlaceExistingItem(item, px, py);
    }
    if (item.Data.CanRotate)
    {
        var sz = item.CurrentSize;
        if (sz.x != sz.y)
        {
            item.Rotate();
            bool ok = TryPlaceOneOrientationStrict(ctrl, item, freed, occupied, out px, out py)
                      && ctrl.PlaceExistingItem(item, px, py);
            if (!ok) item.Rotate(); // откат поворота
            return ok;
        }
    }
    return false;
}

private bool TryPlaceOneOrientationStrict(
    InventoryController ctrl, InventoryItem item, RectInt freed, bool[] occupied,
    out int px, out int py)
{
    px = py = -1;
    var size = item.CurrentSize;
    int fw = freed.width;
    int fh = freed.height;
    if (size.x > fw || size.y > fh) return false;

    for (int y = 0; y <= fh - size.y; y++)
    {
        for (int x = 0; x <= fw - size.x; x++)
        {
            bool free = true;
            for (int dy = 0; dy < size.y && free; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    if (occupied[(y + dy) * fw + (x + dx)])
                    { free = false; break; }
            if (free)
            {
                px = freed.x + x;
                py = freed.y + y;
                // пометить занятым для следующих целей
                for (int dy = 0; dy < size.y; dy++)
                    for (int dx = 0; dx < size.x; dx++)
                        occupied[(y + dy) * fw + (x + dx)] = true;
                return true;
            }
        }
    }
    return false;
}

// ═══ БАГ 5 ФИКС: единый хелпер закрытия окна переносимого рюкзака
// ДО RemoveItem во всех транзакциях перемещения.
// Если targetCtrl == sourceCtrl (перемещение внутри той же сетки) — НЕ закрываем. ═══
private void CloseDraggedBackpackWindowIfCrossController(
    InventoryItem item, InventoryController sourceCtrl, InventoryController targetCtrl)
{
    if (item == null || item.Data == null || !item.Data.IsBackpack) return;
    if (sourceCtrl == targetCtrl) return;
    if (_inventoryUI == null || _inventoryUI.BackpackManager == null) return;
    if (!_inventoryUI.BackpackManager.IsBackpackWindowOpen(item)) return;
    _inventoryUI.CloseAllWindowsForBackpack(item);
}

 // ============================================================
//  ИСПРАВЛЕНИЕ БАГА 2: добавлены логи в TrySwapEquipmentSlots
// ============================================================
public bool TrySwapEquipmentSlots(K_EquipmentSlotUI sourceSlot, K_EquipmentSlotUI targetSlot, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (sourceSlot == null || targetSlot == null) { errorMessage = "Null slots"; return false; }

    var itemA = sourceSlot.EquippedItem;
    if (itemA == null) { errorMessage = "No item in source slot"; return false; }

    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

    Debug.Log($"[EQUIP-SWAP] attempt: {sourceSlot.SlotType}->{targetSlot.SlotType} " +
              $"'{itemA.Data?.DisplayName}' x '{targetSlot.EquippedItem?.Data?.DisplayName ?? "empty"}'");

    if (!InventoryValidationService.TypeMatchCheck(itemA, targetSlot.SlotType))
    {
        errorMessage = "Type mismatch A to B";
        Debug.Log($"[EQUIP-SWAP] failed: {errorMessage}");
        return false;
    }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromEquipmentSlot(itemA, sourceSlot.SlotType));
        var itemB = targetSlot.EquippedItem;
        if (itemB != null)
        {
            if (!InventoryValidationService.TypeMatchCheck(itemB, sourceSlot.SlotType))
            {
                errorMessage = "Type mismatch B to A";
                Debug.Log($"[EQUIP-SWAP] failed: {errorMessage}");
                Rollback();
                return false;
            }
            _snapshots.Add(ItemSnapshot.FromEquipmentSlot(itemB, targetSlot.SlotType));
        }

        sourceSlot.SetEquippedItem(null);
        _inHandItems[itemA.InstanceID] = itemA;

        if (itemB != null)
        {
            targetSlot.SetEquippedItem(null);
            _inHandItems[itemB.InstanceID] = itemB;
            sourceSlot.SetEquippedItem(itemB);
            _placements.Add(new PlacementRecord(itemB, sourceSlot));
            _inHandItems.Remove(itemB.InstanceID);
        }

        targetSlot.SetEquippedItem(itemA);
        _placements.Add(new PlacementRecord(itemA, targetSlot));
        _inHandItems.Remove(itemA.InstanceID);

        if (sourceSlot.SlotType == EquipmentSlotType.Backpack || targetSlot.SlotType == EquipmentSlotType.Backpack)
        {
            if (itemA.Data.IsBackpack && sourceSlot.SlotType == EquipmentSlotType.Backpack) _inventoryUI.OnBackpackUnequipped();
            if (itemB != null && itemB.Data.IsBackpack && targetSlot.SlotType == EquipmentSlotType.Backpack) _inventoryUI.OnBackpackUnequipped();
            if (itemA.Data.IsBackpack && targetSlot.SlotType == EquipmentSlotType.Backpack) _inventoryUI.OnBackpackEquipped(itemA);
            if (itemB != null && itemB.Data.IsBackpack && sourceSlot.SlotType == EquipmentSlotType.Backpack) _inventoryUI.OnBackpackEquipped(itemB);
        }

        Commit();
        _inventoryUI.ForceRefresh();

        Debug.Log($"[EQUIP-SWAP] committed: {sourceSlot.SlotType}->{targetSlot.SlotType} " +
                  $"'{itemA.Data?.DisplayName}' swapped with '{itemB?.Data?.DisplayName ?? "empty"}'");
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Debug.Log($"[EQUIP-SWAP] failed: {errorMessage}");
        Rollback();
        return false;
    }
}

public bool TryDropFromEquipmentIntoBackpack(InventoryItem item, InventoryItem targetBackpack, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (item == null || targetBackpack == null) { errorMessage = "Null references"; return false; }
    if (targetBackpack.Data == null || !targetBackpack.Data.IsBackpack) { errorMessage = "Target is not a backpack"; return false; }
    if (targetBackpack.IsFolded && !targetBackpack.Data.AlwaysShowGrid) { errorMessage = "Cannot drop into folded backpack"; return false; }
    if (!targetBackpack.HasInternalGrid || item == targetBackpack) { errorMessage = "Invalid target"; return false; }

    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

    _inventoryUI.SyncBackpackForValidation(item);
    _inventoryUI.SyncBackpackForValidation(targetBackpack);

    if (!InventoryOperationValidator.ValidateDropIntoBackpack(item, targetBackpack, _inventoryUI.BackpackManager, out errorMessage))
        return false;

    K_EquipmentSlotUI sourceSlot = FindSlotHoldingItem(item);
    if (sourceSlot == null) { errorMessage = "Item is not in any equipment slot"; return false; }
    if (sourceSlot.EquippedItem != item) { errorMessage = "Slot mismatch"; return false; }

    int w = targetBackpack.Data.BackpackWidth;
    int h = targetBackpack.Data.BackpackHeight;
    if (w <= 0 || h <= 0) { errorMessage = "Invalid backpack dimensions"; return false; }

    InventoryController liveCtrl = _inventoryUI.BackpackManager.GetLiveController(targetBackpack.InstanceID.ToString());
    InventoryController workCtrl;
    bool workIsTemp;
    if (liveCtrl != null)
    {
        workCtrl = liveCtrl;
        workIsTemp = false;
    }
    else
    {
        var data = new InventoryData(w, h);
        var savedItems = targetBackpack.GetBackpackSavedItems();
        if (savedItems != null)
            foreach (var s in savedItems) data.AddItem(s);
        workCtrl = new InventoryController(data, K_InventorySetup.DatabaseInstance, "TempDrop_" + targetBackpack.InstanceID);
        workIsTemp = true;
    }

    int origAngle = item.RotationAngle;
    if (!InventoryValidationService.FindFreeSpace(workCtrl, item, out int px, out int py))
    {
        item.RestoreRotationState(origAngle);
        if (workIsTemp) workCtrl.Dispose();
        errorMessage = "No free space in backpack";
        return false;
    }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromEquipmentSlot(item, sourceSlot.SlotType));

        sourceSlot.SetEquippedItem(null);
        _inHandItems[item.InstanceID] = item;

        if (!workCtrl.PlaceExistingItem(item, px, py))
        {
            item.Rotate();
            if (!workCtrl.PlaceExistingItem(item, px, py))
            {
                item.Rotate();
                errorMessage = "Failed to place item in backpack";
                Rollback();
                return false;
            }
        }
        _placements.Add(new PlacementRecord(item, workIsTemp ? null : workCtrl, px, py));
        _inHandItems.Remove(item.InstanceID);

        if (workIsTemp)
        {
            targetBackpack.ReplaceBackpackContents(workCtrl.GetSaveData().GetItems());
            workCtrl.Dispose();
        }

        Commit();
        _inventoryUI.ClearEquipmentDragState();
        _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        if (workIsTemp && workCtrl != null) workCtrl.Dispose();
        Rollback();
        return false;
    }
}
   public bool TrySwapEquipmentWithGridItem(UI_Item targetUI, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }
    if (!_inventoryUI.IsDraggingFromEquipmentSlot) { errorMessage = "Not dragging from equipment slot"; return false; }

    var itemA = _inventoryUI.DraggedFromSlotItem;
    if (itemA == null) { errorMessage = "No dragged slot item"; return false; }
    var itemB = targetUI != null ? targetUI.Item : null;
    if (itemB == null) { errorMessage = "No target item"; return false; }
    if (itemA == itemB) { errorMessage = "Same item"; return false; }

    if (itemB.Data != null && itemB.Data.IsBackpack && !itemB.IsFolded)
    { errorMessage = "Unfolded backpack cannot be swapped (target)"; return false; }

    K_EquipmentSlotUI sourceSlot = FindSlotHoldingItem(itemA);
    if (sourceSlot == null) { errorMessage = "Cannot find source equipment slot for dragged item"; return false; }

    var ctrlB = GetControllerForUI(targetUI);
    if (ctrlB == null) { errorMessage = "No controller for target"; return false; }

    int bx = targetUI.X, by = targetUI.Y;

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromEquipmentSlot(itemA, sourceSlot.SlotType));
        _snapshots.Add(ItemSnapshot.FromGrid(itemB, targetUI.GridType, bx, by, GetContainerOwnerId(targetUI)));

        InventoryValidationService.PrepareSnapshotsForValidation(itemA, itemB);
        if (!InventoryValidationService.NestingCheckBidirectional(itemA, itemB))
        { errorMessage = "Nesting cycle: cannot swap backpack with its descendant"; Rollback(); return false; }

        if (!ctrlB.RemoveItem(itemB))
        { errorMessage = "Failed to remove target item B from grid"; Rollback(); return false; }
        _inHandItems[itemB.InstanceID] = itemB;

        if (sourceSlot.EquippedItem == itemA)
            sourceSlot.SetEquippedItem(null);
        _inHandItems[itemA.InstanceID] = itemA;


        if (!TryPlaceItemInController(itemA, ctrlB, bx, by, out var errA))
        { errorMessage = "Item A (from slot): " + errA; Rollback(); return false; }

        if (sourceSlot.EquippedItem == itemA)
            sourceSlot.SetEquippedItem(null);

        sourceSlot.SetEquippedItem(itemB);
        _placements.Add(new PlacementRecord(itemB, sourceSlot));
        _inHandItems.Remove(itemB.InstanceID);

        if (sourceSlot.SlotType == EquipmentSlotType.Backpack)
        {
            if (itemA.Data != null && itemA.Data.IsBackpack) _inventoryUI.OnBackpackUnequipped();
            if (itemB.Data != null && itemB.Data.IsBackpack) _inventoryUI.OnBackpackEquipped(itemB);
        }

        Commit();
        _inventoryUI.FinalizeEquipSlotDrag();
        _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}
    public bool TryEquipFromContextMenu(InventoryItem item, out string errorMessage)
    {
        errorMessage = string.Empty;
        if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
        if (item == null || item.Data == null) { errorMessage = "Invalid item"; return false; }
        EnsureInitialized();
        if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

        if (!InventoryValidationService.TryDetermineEquipSlotType(item, out var slotType))
        { errorMessage = "Item cannot be equipped (no matching slot type)"; return false; }
        if (!InventoryValidationService.TypeMatchCheck(item, slotType))
        { errorMessage = $"Type mismatch: item '{item.Data.DisplayName}' cannot go to slot {slotType}"; return false; }

        var targetSlot = GetEquipSlot(slotType);
        if (targetSlot == null) { errorMessage = $"No slot of type {slotType} found in scene"; return false; }

        var (originGrid, ax, ay) = FindItemLocationInPlayerGrids(item);
        if (originGrid == null) { errorMessage = "Item not found in any player grid"; return false; }
        var originCtrl = _inventoryUI.GetControllerForGrid(originGrid.Value);
        if (originCtrl == null) { errorMessage = "No origin controller"; return false; }

        BeginTransaction();
        try
        {
            _snapshots.Add(ItemSnapshot.FromGrid(item, originGrid.Value, ax, ay));

            InventoryItem oldItemB = targetSlot.IsOccupied ? targetSlot.EquippedItem : null;
            if (oldItemB != null)
            {
                _snapshots.Add(ItemSnapshot.FromEquipmentSlot(oldItemB, targetSlot.SlotType));
                InventoryValidationService.PrepareSnapshotsForValidation(item, oldItemB);
                if (!InventoryValidationService.NestingCheckBidirectional(item, oldItemB))
                { errorMessage = "Nesting cycle: cannot swap backpack with its descendant"; Rollback(); return false; }
            }

            if (!originCtrl.RemoveItem(item))
            { errorMessage = "Failed to remove item A from origin grid"; Rollback(); return false; }
            _inHandItems[item.InstanceID] = item;

            if (oldItemB != null)
            {
              
                if (!TryPlaceItemInPlayerGrids(oldItemB, originCtrl, ax, ay, out var errB))
                { errorMessage = "Cannot place old equipped item: " + errB; Rollback(); return false; }
                if (targetSlot.EquippedItem == oldItemB) targetSlot.SetEquippedItem(null);
            }

            targetSlot.SetEquippedItem(item);
            _placements.Add(new PlacementRecord(item, targetSlot));
            _inHandItems.Remove(item.InstanceID);

            if (slotType == EquipmentSlotType.Backpack)
            {
                if (item.Data.IsBackpack) _inventoryUI.OnBackpackEquipped(item);
                if (oldItemB != null && oldItemB.Data != null && oldItemB.Data.IsBackpack) _inventoryUI.OnBackpackUnequipped();
            }

            Commit();
            _inventoryUI.ForceRefresh();
            return true;
        }
        catch (System.Exception ex)
        {
            Debug.LogException(ex);
            errorMessage = "Transaction exception: " + ex.Message;
            Rollback();
            return false;
        }
    }

 // ============================================================
//  TryEquipFromDrag – исправленный (обе ветки)
// ============================================================
public bool TryEquipFromDrag(UI_Item draggedUI, K_EquipmentSlotUI targetSlot, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || targetSlot == null) { errorMessage = "Null references (draggedUI or targetSlot)"; return false; }
    var itemA = draggedUI.Item;
    if (itemA == null || itemA.Data == null) { errorMessage = "Invalid dragged item"; return false; }
    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

    if (!InventoryValidationService.TypeMatchCheck(itemA, targetSlot.SlotType))
    { errorMessage = $"Type mismatch: '{itemA.Data.DisplayName}' cannot go to slot {targetSlot.SlotType}"; return false; }
    if (targetSlot.EquippedItem == itemA) { errorMessage = "Item is already in this slot"; return false; }

    var ctrlA = GetControllerForUI(draggedUI);
    GridType gridA = draggedUI.GridType;
    var (ax, ay) = FindItemPositionInController(ctrlA, itemA);
    if (ax == -1) { errorMessage = "Item A not found in source grid (UI_Item desync)"; return false; }

    InventoryItem oldItemB = targetSlot.IsOccupied ? targetSlot.EquippedItem : null;

    // ─── ВЕТКА: СЛОТ РЮКЗАКА ЗАНЯТ + ТАЩИМ РЮКЗАК (SWAP) ───
    if (oldItemB != null
        && targetSlot.SlotType == EquipmentSlotType.Backpack
        && itemA.Data.IsBackpack
        && oldItemB.Data != null && oldItemB.Data.IsBackpack)
    {
        _inventoryUI.SyncBackpackForValidation(itemA);
        _inventoryUI.SyncBackpackForValidation(oldItemB);

        if (!InventoryOperationValidator.TryResolveEquipSwap(
            itemA, oldItemB, ctrlA, ax, ay,
            out int placeX, out int placeY, out errorMessage))
            return false;

        BeginTransaction();
        try
        {
            _snapshots.Add(ItemSnapshot.FromGrid(itemA, gridA, ax, ay, GetContainerOwnerId(draggedUI)));
            _snapshots.Add(ItemSnapshot.FromEquipmentSlot(oldItemB, targetSlot.SlotType));

            // ═══ УДАЛЯЕМ CloseDraggedBackpackWindowIfCrossController (окно не закрываем) ═══

            // 1. Удаляем тащимый из исходной сетки
            if (!ctrlA.RemoveItem(itemA))
            { errorMessage = "Failed to remove A from source grid"; Rollback(); return false; }
            _inHandItems[itemA.InstanceID] = itemA;

            // 2. Снимаем старый рюкзак
            _inventoryUI.OnBackpackUnequipped();

            // 3. Очищаем слот
            targetSlot.SetEquippedItem(null);
            _inHandItems[oldItemB.InstanceID] = oldItemB;

            // 4. Размещаем старый рюкзак в исходной сетке
            if (!ctrlA.PlaceExistingItem(oldItemB, placeX, placeY))
            {
                oldItemB.Rotate();
                if (!ctrlA.PlaceExistingItem(oldItemB, placeX, placeY))
                {
                    oldItemB.Rotate();
                    targetSlot.SetEquippedItem(oldItemB);
                    _inventoryUI.OnBackpackEquipped(oldItemB);
                    errorMessage = "Failed to place old backpack at validated position";
                    Rollback();
                    return false;
                }
            }
            _placements.Add(new PlacementRecord(oldItemB, ctrlA, placeX, placeY));
            _inHandItems.Remove(oldItemB.InstanceID);

            // 5. Экипируем новый рюкзак
            targetSlot.SetEquippedItem(itemA);
            _placements.Add(new PlacementRecord(itemA, targetSlot));
            _inHandItems.Remove(itemA.InstanceID);

            _inventoryUI.OnBackpackEquipped(itemA);

            Commit();

            // ═══ После Commit окно источника НЕ закрываем, т.к. sourceCtrl используется для oldItemB ═══

            _inventoryUI.ForceRefresh();
            return true;
        }
        catch (System.Exception ex)
        {
            Debug.LogException(ex);
            errorMessage = "Transaction exception: " + ex.Message;
            Rollback();
            return false;
        }
    }

    // ─── СТАНДАРТНАЯ ВЕТКА: СЛОТ ПУСТ ИЛИ ЗАНЯТ НЕ-РЮКЗАКОМ ───
    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(itemA, gridA, ax, ay, GetContainerOwnerId(draggedUI)));

        if (oldItemB != null)
        {
            _snapshots.Add(ItemSnapshot.FromEquipmentSlot(oldItemB, targetSlot.SlotType));
            InventoryValidationService.PrepareSnapshotsForValidation(itemA, oldItemB);
            if (!InventoryValidationService.NestingCheckBidirectional(itemA, oldItemB))
            { errorMessage = "Nesting cycle: cannot swap backpack with its descendant"; Rollback(); return false; }
        }

        if (ctrlA != null)
        {
            // ═══ УДАЛЯЕМ CloseDraggedBackpackWindowIfCrossController ОТСЮДА ═══

            if (!ctrlA.RemoveItem(itemA))
            { errorMessage = "Failed to remove A from source grid"; Rollback(); return false; }
            _inHandItems[itemA.InstanceID] = itemA;
        }

        if (targetSlot.SlotType == EquipmentSlotType.Backpack
            && oldItemB != null && oldItemB.Data != null && oldItemB.Data.IsBackpack)
        {
            _inventoryUI.OnBackpackUnequipped();
        }

        if (targetSlot.EquippedItem == oldItemB)
            targetSlot.SetEquippedItem(null);

        if (oldItemB != null)
        {
            _inHandItems[oldItemB.InstanceID] = oldItemB;
            if (ctrlA != null)
            {
                if (!TryPlaceItemInPlayerGrids(oldItemB, ctrlA, ax, ay, out var errB))
                { errorMessage = "Cannot place old equipped item: " + errB; Rollback(); return false; }
            }
            else
            {
                if (!TryPlaceItemInAnyPlayerGrid(oldItemB, out var errB))
                { errorMessage = "Cannot place old equipped item (no origin controller): " + errB; Rollback(); return false; }
            }
        }

        targetSlot.SetEquippedItem(itemA);
        _placements.Add(new PlacementRecord(itemA, targetSlot));
        _inHandItems.Remove(itemA.InstanceID);

        if (targetSlot.SlotType == EquipmentSlotType.Backpack
            && itemA.Data != null && itemA.Data.IsBackpack)
        {
            _inventoryUI.OnBackpackEquipped(itemA);
        }

        Commit();

        // ═══ ПОСЛЕ Commit закрываем окно источника, если предмет был из сетки и это НЕ свап рюкзаков ═══
        if (ctrlA != null && oldItemB == null
            && itemA.Data != null && itemA.Data.IsBackpack)
        {
            _inventoryUI.CloseAllWindowsForBackpack(itemA);
        }

        _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}
// ============================================================
//  TryDropIntoEquippedBackpack – исправленный
// ============================================================
public bool TryDropIntoEquippedBackpack(
    UI_Item draggedUI,
    K_EquipmentSlotUI backpackSlot,
    out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || backpackSlot == null) { errorMessage = "Null references"; return false; }
    var itemA = draggedUI.Item;
    if (itemA == null || itemA.Data == null) { errorMessage = "Invalid dragged item"; return false; }
    if (itemA.Data.IsBackpack) { errorMessage = "Backpack items use equip swap path"; return false; }
    EnsureInitialized();
    if (_inventoryUI == null) { errorMessage = "No inventory UI"; return false; }

    var equippedBackpack = backpackSlot.EquippedItem;
    if (equippedBackpack == null || equippedBackpack.Data == null || !equippedBackpack.Data.IsBackpack)
    { errorMessage = "No backpack equipped in slot"; return false; }

    var bpCtrl = _inventoryUI.GetControllerForGrid(GridType.Backpack);
    if (bpCtrl == null) { errorMessage = "No backpack controller"; return false; }

    if (!InventoryOperationValidator.ValidateDropIntoEquippedBackpack(
        itemA, bpCtrl, out int px, out int py, out errorMessage))
        return false;

    var ctrlA = GetControllerForUI(draggedUI);
    GridType gridA = draggedUI.GridType;
    var (ax, ay) = FindItemPositionInController(ctrlA, itemA);
    if (ax == -1) { errorMessage = "Item not found in source controller"; return false; }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(itemA, gridA, ax, ay, GetContainerOwnerId(draggedUI)));

        // ═══ УДАЛЯЕМ CloseDraggedBackpackWindowIfCrossController ОТСЮДА ═══

        if (!ctrlA.RemoveItem(itemA))
        {
            errorMessage = "Failed to remove item from source";
            Rollback();
            return false;
        }
        _inHandItems[itemA.InstanceID] = itemA;

        if (!bpCtrl.PlaceExistingItem(itemA, px, py))
        {
            itemA.Rotate();
            if (!bpCtrl.PlaceExistingItem(itemA, px, py))
            {
                itemA.Rotate();
                errorMessage = "Failed to place item in equipped backpack";
                Rollback();
                return false;
            }
        }
        _placements.Add(new PlacementRecord(itemA, bpCtrl, px, py));
        _inHandItems.Remove(itemA.InstanceID);

        Commit();

        // ═══ ПОСЛЕ Commit закрываем окно источника, если источник ≠ цель ═══
        if (ctrlA != null && ctrlA != bpCtrl && itemA.Data != null && itemA.Data.IsBackpack)
        {
            _inventoryUI.CloseAllWindowsForBackpack(itemA);
        }

        _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}

// ============================================================
//  TryMoveItem – исправленный
// ============================================================
public bool TryMoveItem(
    UI_Item draggedUI,
    InventoryController targetController,
    int targetX,
    int targetY,
    out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || targetController == null) { errorMessage = "Null references"; return false; }

    var itemA = draggedUI.Item;
    if (itemA == null || itemA.Data == null) { errorMessage = "Invalid dragged item"; return false; }

    EnsureInitialized();

    var sourceController = GetControllerForUI(draggedUI);
    GridType gridA = draggedUI.GridType;
    var (ax, ay) = FindItemPositionInController(sourceController, itemA);

    if (ax == -1)
    {
        errorMessage = $"Item '{itemA.Data?.DisplayName}' not found in source controller (UI_Item desync)";
        return false;
    }

    // no-op
    if (sourceController == targetController
        && ax == targetX && ay == targetY
        && itemA.RotationAngle == draggedUI.Item.RotationAngle)
    {
        return true;
    }

    // ═══ НОВАЯ ПРОВЕРКА ГЛУБИНЫ ДЛЯ РАЗВЁРНУТОГО РЮКЗАКА ═══
    if (_inventoryUI != null && _inventoryUI.BackpackManager != null)
    {
        var backpackManager = _inventoryUI.BackpackManager;
        if (itemA.Data.IsBackpack && !itemA.IsFolded)
        {
            var targetWindow = backpackManager.FindWindowByController(targetController);
            if (targetWindow != null)
            {
                if (!backpackManager.CanPlaceUnfoldedBackpackIntoController(targetController, itemA, out string depthReason))
                {
                    errorMessage = depthReason;
                    return false;
                }
            }
        }
    }

    // Проверка циклов и вложенности (оригинальный код)
    if (itemA.Data != null && itemA.Data.IsBackpack)
    {
        _inventoryUI.SyncBackpackForValidation(itemA);
        if (sourceController != targetController)
        {
            var targetBackpack = _inventoryUI.BackpackManager?.FindBackpackItemByID(targetController.SaveID);
            if (targetBackpack != null && _inventoryUI.WouldCreateCircularReference(itemA, targetBackpack))
            {
                errorMessage = "Nesting cycle: cannot move backpack into its descendant";
                return false;
            }
        }
    }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(itemA, gridA, ax, ay, GetContainerOwnerId(draggedUI)));

        if (sourceController != targetController && itemA.Data != null && itemA.Data.IsBackpack)
        {
            var targetBackpack = _inventoryUI.BackpackManager?.FindBackpackItemByID(targetController.SaveID);
            if (targetBackpack != null && _inventoryUI.WouldCreateCircularReference(itemA, targetBackpack))
            {
                errorMessage = "Nesting cycle: cannot move backpack into its descendant";
                Rollback();
                return false;
            }
        }

        // ═══ УДАЛЯЕМ CloseDraggedBackpackWindowIfCrossController ОТСЮДА ═══

        if (sourceController == targetController)
        {
            if (!targetController.MoveItem(itemA, targetX, targetY))
            {
                errorMessage = $"Cannot move to ({targetX},{targetY}) — no space or occupied";
                Rollback();
                return false;
            }
            _placements.Add(new PlacementRecord(itemA, targetController, targetX, targetY));
        }
        else
        {
            if (sourceController != null)
            {
                if (!sourceController.RemoveItem(itemA))
                {
                    errorMessage = "Failed to remove item from source controller";
                    Rollback();
                    return false;
                }
                _inHandItems[itemA.InstanceID] = itemA;
            }
            if (!targetController.PlaceExistingItem(itemA, targetX, targetY))
            {
                errorMessage = "Failed to place item into target controller";
                Rollback();
                return false;
            }
            _placements.Add(new PlacementRecord(itemA, targetController, targetX, targetY));
            _inHandItems.Remove(itemA.InstanceID);
        }

        Commit();

        // ═══ ПОСЛЕ Commit закрываем окно источника, если перенос кросс-контроллерный ═══
        if (sourceController != null && sourceController != targetController
            && itemA.Data != null && itemA.Data.IsBackpack)
        {
            _inventoryUI.CloseAllWindowsForBackpack(itemA);
        }

        AssertGridIntegrity(sourceController, targetController);
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        Rollback();
        return false;
    }
}
private void AssertGridIntegrity(params InventoryController[] ctrls)
{
    foreach (var ctrl in ctrls)
    {
        if (ctrl == null || ctrl.IsDisposed) continue;
        for (int y = 0; y < ctrl.Height; y++)
        for (int x = 0; x < ctrl.Width; x++)
        {
            var it = ctrl.GetItemAt(x, y);
            if (it == null) continue;
            var (rx, ry) = ctrl.FindItemRootPosition(it.InstanceID);
            if (rx == -1)
            {
                Debug.LogError($"[Integrity] Cell ({x},{y}) references item {it.InstanceID} without root!");
                continue;
            }
            var sz = it.CurrentSize;
            if (rx + sz.x > ctrl.Width || ry + sz.y > ctrl.Height)
            {
                Debug.LogError($"[Integrity] Item {it.InstanceID} root ({rx},{ry}) size {sz.x}x{sz.y} exceeds grid {ctrl.Width}x{ctrl.Height}");
            }
            else if (x < rx || x >= rx + sz.x || y < ry || y >= ry + sz.y)
            {
                Debug.LogError($"[Integrity] Cell ({x},{y}) outside footprint of its own item {it.InstanceID} (root {rx},{ry})");
            }
        }
    }
}
// ============================================================
//  TryDropIntoBackpack – исправленный
// ============================================================
// Assets/_Project/_Scripts/Core/inventory/transactionsInvent/InventoryTransactionService.cs
public bool TryDropIntoBackpack(UI_Item draggedUI, InventoryItem targetBackpack, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_isTransactionActive) { errorMessage = "Transaction already active"; return false; }
    if (draggedUI == null || targetBackpack == null) { errorMessage = "Null references"; return false; }
    var itemA = draggedUI.Item;
    if (itemA == null || itemA.Data == null) { errorMessage = "Invalid dragged item"; return false; }
    if (targetBackpack.Data == null || !targetBackpack.Data.IsBackpack)
    { errorMessage = "Target is not a backpack"; return false; }
    if (targetBackpack.IsFolded && !targetBackpack.Data.AlwaysShowGrid)
    { errorMessage = "Cannot drop into folded backpack"; return false; }
    if (!targetBackpack.HasInternalGrid || itemA == targetBackpack)
    { errorMessage = "Invalid target"; return false; }

    EnsureInitialized();

    _inventoryUI.SyncBackpackForValidation(itemA);
    _inventoryUI.SyncBackpackForValidation(targetBackpack);
    if (!InventoryOperationValidator.ValidateDropIntoBackpack(
            itemA, targetBackpack, _inventoryUI.BackpackManager, out errorMessage))
        return false;

    int origAngle = itemA.RotationAngle;
    var db = K_InventorySetup.DatabaseInstance;
    if (db == null) { errorMessage = "Database not initialized"; return false; }

    int w = targetBackpack.Data.BackpackWidth;
    int h = targetBackpack.Data.BackpackHeight;
    if (w <= 0 || h <= 0) { errorMessage = "Invalid backpack dimensions"; return false; }

    string bpIdStr = targetBackpack.InstanceID.ToString();
    InventoryController liveCtrl = null;
    if (_inventoryUI != null && _inventoryUI.BackpackManager != null)
        liveCtrl = _inventoryUI.BackpackManager.GetLiveController(bpIdStr);

    InventoryController workCtrl;
    bool workIsTemp;
    if (liveCtrl != null)
    {
        workCtrl = liveCtrl;
        workIsTemp = false;
    }
    else
    {
        var data = new InventoryData(w, h);
        var savedItems = targetBackpack.GetBackpackSavedItems();
        if (savedItems != null)
            foreach (var s in savedItems) data.AddItem(s);
        workCtrl = new InventoryController(data, db, "TempDrop_" + targetBackpack.InstanceID);
        workIsTemp = true;
    }

    var sourceController = GetControllerForUI(draggedUI);
    int snapX, snapY;
    if (sourceController != null)
    {
        var (realX, realY) = FindItemPositionInController(sourceController, itemA);
        if (realX == -1)
        {
            errorMessage = "Item not found in source controller (UI_Item desync)";
            if (workIsTemp) workCtrl.Dispose();
            return false;
        }
        snapX = realX;
        snapY = realY;
    }
    else
    {
        snapX = draggedUI.X;
        snapY = draggedUI.Y;
    }

    BeginTransaction();
    try
    {
        _snapshots.Add(ItemSnapshot.FromGrid(itemA, draggedUI.GridType, snapX, snapY, GetContainerOwnerId(draggedUI)));

        if (!InventoryValidationService.FindFreeSpace(workCtrl, itemA, out int px, out int py))
        {
            itemA.RestoreRotationState(origAngle);
            if (workIsTemp) workCtrl.Dispose();
            errorMessage = "No free space in backpack";
            Rollback();
            return false;
        }

        if (sourceController != null)
        {
            if (!sourceController.RemoveItem(itemA))
            {
                if (workIsTemp) workCtrl.Dispose();
                errorMessage = "Failed to remove item from source controller";
                Rollback();
                return false;
            }
            _inHandItems[itemA.InstanceID] = itemA;
        }

        if (!workCtrl.PlaceExistingItem(itemA, px, py))
        {
            itemA.RestoreRotationState(origAngle);
            if (workIsTemp) workCtrl.Dispose();
            errorMessage = "Failed to place item in backpack";
            Rollback();
            return false;
        }
        _placements.Add(new PlacementRecord(itemA, workIsTemp ? null : workCtrl, px, py));
        _inHandItems.Remove(itemA.InstanceID);

        if (workIsTemp)
        {
            targetBackpack.ReplaceBackpackContents(workCtrl.GetSaveData().GetItems());
            workCtrl.Dispose();
            var parentCtrl = _inventoryUI != null
                ? _inventoryUI.FindControllerForItem(targetBackpack)
                : null;
            if (parentCtrl != null && parentCtrl.RefreshItemInData(targetBackpack))
            { }
            else if (_inventoryUI != null && _inventoryUI.BackpackManager != null)
            {
                _inventoryUI.BackpackManager.CommitBackpackContentsIntoChain(
                    targetBackpack.InstanceID,
                    targetBackpack.GetBackpackSavedItems());
            }
        }

        Commit();

        if (sourceController != null && sourceController != workCtrl
            && itemA.Data != null && itemA.Data.IsBackpack)
        {
            _inventoryUI.CloseAllWindowsForBackpack(itemA);
        }

        if (_inventoryUI != null) _inventoryUI.ForceRefresh();
        return true;
    }
    catch (System.Exception ex)
    {
        Debug.LogException(ex);
        errorMessage = "Transaction exception: " + ex.Message;
        if (workIsTemp && workCtrl != null) workCtrl.Dispose();
        Rollback();
        return false;
    }
}

private List<InventoryController> BuildRelocationControllers(InventoryController extra)
{
    _relocBuffer.Clear();
    if (_inventoryUI != null)
    {
        if (_inventoryUI.PocketsController != null) _relocBuffer.Add(_inventoryUI.PocketsController);
        if (_inventoryUI.Pocket2Controller != null) _relocBuffer.Add(_inventoryUI.Pocket2Controller);
        if (_inventoryUI.BackpackController != null) _relocBuffer.Add(_inventoryUI.BackpackController);
    }
    if (extra != null && !_relocBuffer.Contains(extra)) _relocBuffer.Add(extra);
    if (_inventoryUI != null && _inventoryUI.BackpackManager != null)
    {
        foreach (var w in _inventoryUI.BackpackManager.OpenWindows)
            if (w != null && w.Controller != null && !_relocBuffer.Contains(w.Controller))
                _relocBuffer.Add(w.Controller);
    }
    // ═══ БАГ 3c ФИКС (parity И2): loot/окружение в candidate-контроллерах
    // для relocation. Валидатор и транзакция должны видеть одинаковый список. ═══
    if (_inventoryUI != null && _inventoryUI.IsLooting && _inventoryUI.ActiveContainerController != null)
    {
        var lootCtrl = _inventoryUI.ActiveContainerController;
        if (!_relocBuffer.Contains(lootCtrl))
            _relocBuffer.Add(lootCtrl);
    }
    return _relocBuffer;
}
    private void BeginTransaction()
    {
        _isTransactionActive = true;
        _snapshots.Clear();
        _placements.Clear();
        _inHandItems.Clear();
    }

    private void Commit()
    {
        _snapshots.Clear();
        _placements.Clear();
        _inHandItems.Clear();
        _isTransactionActive = false;
    }

 private void Rollback()
{
    for (int i = _placements.Count - 1; i >= 0; i--)
    {
        var p = _placements[i];
        if (p.Item == null) continue;
        if (p.InSlot && p.Slot != null)
        {
            if (ReferenceEquals(p.Slot.EquippedItem, p.Item))
            {
                p.Slot.SetEquippedItem(null);
                _inHandItems[p.Item.InstanceID] = p.Item;
            }
        }
        else if (p.Controller != null)
        {
            try
            {
                if (p.Controller.IsRootCell(p.Item.InstanceID, p.X, p.Y) ||
                    IsItemAnywhereInController(p.Controller, p.Item))
                {
                    p.Controller.RemoveItem(p.Item);
                    _inHandItems[p.Item.InstanceID] = p.Item;
                }
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[Transaction.Rollback] Failed to remove item from placement: {ex.Message}");
            }
        }
    }

    for (int i = _snapshots.Count - 1; i >= 0; i--)
    {
        var snap = _snapshots[i];
        if (!snap.IsValid) continue;

        InventoryItem liveItem;
        if (!_inHandItems.TryGetValue(snap.InstanceID, out liveItem))
            liveItem = FindItemByInstanceId(snap.InstanceID);

        if (liveItem == null)
        {
            Debug.LogError(
                $"[Transaction.Rollback] ITEM-LOSS: InstanceID={snap.InstanceID} " +
                $"not found in hand or any controller. Snapshot was invalid.");
            continue;
        }

        _inHandItems.Remove(snap.InstanceID);

        try { liveItem.RestoreRotationState(snap.RotationAngle); }
        catch { }

        if (liveItem.Data != null && liveItem.Data.CanFold && liveItem.IsFolded != snap.IsFolded)
            liveItem.SetFolded(snap.IsFolded);

        if (snap.IsFromEquipmentSlot)
        {
            K_EquipmentSlotUI slot = FindEquipmentSlot(snap.EquipmentSlotType);
            if (slot == null)
            {
                RemoveItemFromEverywhere(liveItem);
                if (!TryPlaceItemInAnyPlayerGrid(liveItem, out _))
                {
                    Debug.LogError(
                        $"[Transaction.Rollback] ITEM-LOSS: equipment slot " +
                        $"{snap.EquipmentSlotType} not found, could not restore " +
                        $"'{liveItem.Data?.DisplayName}' (InstanceID={snap.InstanceID}).");
                }
                continue;
            }
            if (slot.EquippedItem != null && slot.EquippedItem != liveItem)
            {
                var orphan = slot.EquippedItem;
                slot.SetEquippedItem(null);
                TryPlaceItemInAnyPlayerGrid(orphan, out _);
            }
            slot.SetEquippedItem(liveItem);
        }
        else
        {
            InventoryController originCtrl = null;
            if (snap.OriginGrid == GridType.Container)
            {
                if (snap.OriginContainerOwnerId != 0 && _inventoryUI != null && _inventoryUI.BackpackManager != null)
                    originCtrl = _inventoryUI.BackpackManager.GetLiveController(snap.OriginContainerOwnerId.ToString());
            }
            else
            {
                originCtrl = _inventoryUI != null ? _inventoryUI.GetControllerForGrid(snap.OriginGrid) : null;
            }

            if (originCtrl != null)
            {
                var existing = originCtrl.GetItemAt(snap.OriginX, snap.OriginY);
                bool alreadyAtOrigin = existing != null && existing.InstanceID == liveItem.InstanceID;
                if (!alreadyAtOrigin)
                {
                    RemoveItemFromEverywhere(liveItem);
                    if (!originCtrl.PlaceExistingItem(liveItem, snap.OriginX, snap.OriginY))
                    {
                        if (!originCtrl.PlaceExistingItemInFirstFreeSlot(liveItem))
                        {
                            // Если не удалось разместить в контроллере, но это контейнер — пробуем восстановить в сериализованные данные
                            if (!RestoreItemToBackpackContents(liveItem, snap.OriginContainerOwnerId, snap.OriginX, snap.OriginY))
                            {
                                if (!TryPlaceItemInAnyPlayerGrid(liveItem, out _))
                                {
                                    Debug.LogError(
                                        $"[Transaction.Rollback] ITEM-LOSS: could not restore item " +
                                        $"'{liveItem.Data?.DisplayName}' (InstanceID={snap.InstanceID}) " +
                                        $"to origin container or any player grid!");
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                RemoveItemFromEverywhere(liveItem);

                // Контроллер недоступен – пробуем восстановить в сериализованные данные владельца
                if (!RestoreItemToBackpackContents(liveItem, snap.OriginContainerOwnerId, snap.OriginX, snap.OriginY))
                {
                    if (!TryPlaceItemInAnyPlayerGrid(liveItem, out _))
                    {
                        Debug.LogError(
                            $"[Transaction.Rollback] ITEM-LOSS (no origin controller): " +
                            $"could not restore item '{liveItem.Data?.DisplayName}' " +
                            $"(InstanceID={snap.InstanceID}) to any player grid!");
                    }
                }
            }
        }
    }

    _snapshots.Clear();
    _placements.Clear();
    _inHandItems.Clear();
    _isTransactionActive = false;

    if (_inventoryUI != null)
        _inventoryUI.ForceRefresh();
}

/// <summary>
/// Восстанавливает предмет в сериализованные данные рюкзака-владельца.
/// Если предмет уже присутствует в данных (рекурсивно), ничего не делает.
/// Иначе добавляет на позицию (x, y).
/// Возвращает true, если предмет успешно восстановлен или уже был в данных.
/// </summary>
private bool RestoreItemToBackpackContents(InventoryItem item, uint ownerId, int x, int y)
{
    if (item == null || ownerId == 0 || _inventoryUI == null)
        return false;

    // Используем публичный метод BackpackManager для поиска владельца в сериализованных данных (закрытые окна любой глубины)
    var owner = _inventoryUI.BackpackManager.FindBackpackItemByID(ownerId.ToString());
    if (owner == null)
        return false;

    var contents = owner.GetBackpackContentsRaw();
    if (contents != null && InventoryItem.ContainsDescendantRecursive(contents, item.InstanceID))
        return true;

    var saved = item.ToSaveData(x, y);
    if (contents == null)
    {
        contents = new List<SavedItem>();
        owner.ReplaceBackpackContents(contents);
    }

    for (int i = 0; i < contents.Count; i++)
    {
        if (contents[i].InstanceID == item.InstanceID)
        {
            contents[i] = saved;
            return true;
        }
    }

    contents.Add(saved);
    return true;
}
private bool ValidateSwapFinalGeometry(params InventoryController[] ctrls)
{
    foreach (var ctrl in ctrls)
    {
        if (ctrl == null || ctrl.IsDisposed) continue;
        for (int y = 0; y < ctrl.Height; y++)
            for (int x = 0; x < ctrl.Width; x++)
            {
                var it = ctrl.GetItemAt(x, y);
                if (it == null) continue;
                var (rx, ry) = ctrl.FindItemRootPosition(it.InstanceID);
                if (rx == -1)
                {
                    Debug.LogError($"[SwapGeometry] Cell ({x},{y}) references item {it.InstanceID} without root in '{ctrl.SaveID}'");
                    return false;
                }
                var sz = it.CurrentSize;
                if (rx + sz.x > ctrl.Width || ry + sz.y > ctrl.Height)
                {
                    Debug.LogError($"[SwapGeometry] Item {it.InstanceID} root ({rx},{ry}) size {sz.x}x{sz.y} exceeds grid {ctrl.Width}x{ctrl.Height} in '{ctrl.SaveID}'");
                    return false;
                }
                if (x < rx || x >= rx + sz.x || y < ry || y >= ry + sz.y)
                {
                    Debug.LogError($"[SwapGeometry] Cell ({x},{y}) outside footprint of item {it.InstanceID} (root {rx},{ry}) in '{ctrl.SaveID}'");
                    return false;
                }
            }
    }
    return true;
}
    private bool TryPlaceItemInController(
        InventoryItem item, InventoryController controller, int x, int y, out string errorMessage)
    {
        errorMessage = string.Empty;

        // Точная позиция.
        if (InventoryValidationService.GridSpaceCheck(controller, item, x, y))
        {
            if (controller.PlaceExistingItem(item, x, y))
            {
                _placements.Add(new PlacementRecord(item, controller, x, y));
                _inHandItems.Remove(item.InstanceID);
                return true;
            }
        }

        // ═══ ФИКС «no free space при пустых ячейках»: строгий перебор ПУСТЫХ
        // ячеек (PlaceExistingItem не стекует), с попыкой поворота. ═══
        int origAngle = item.RotationAngle;
        for (int attempt = 0; attempt < 2; attempt++)
        {
            if (controller.PlaceExistingItemInFirstFreeSlot(item))
            {
                var (fx, fy) = controller.FindItemRootPosition(item.InstanceID);
                _placements.Add(new PlacementRecord(item, controller, fx, fy));
                _inHandItems.Remove(item.InstanceID);
                return true;
            }
            if (item.Data == null || !item.Data.CanRotate) break;
            var sz = item.CurrentSize;
            if (sz.x == sz.y) break;
            item.Rotate();
        }
        item.RestoreRotationState(origAngle);

        errorMessage = $"no free space in controller '{controller.SaveID}'";
        return false;
    }

    private bool TryPlaceItemInPlayerGrids(
        InventoryItem item, InventoryController preferenceController,
        int preferredX, int preferredY, out string errorMessage)
    {
        errorMessage = string.Empty;

        if (preferenceController != null &&
            InventoryValidationService.GridSpaceCheck(preferenceController, item, preferredX, preferredY))
        {
            if (preferenceController.PlaceExistingItem(item, preferredX, preferredY))
            {
                _placements.Add(new PlacementRecord(item, preferenceController, preferredX, preferredY));
                _inHandItems.Remove(item.InstanceID);
                return true;
            }
        }

        if (preferenceController != null)
        {
            int origAngle = item.RotationAngle;
            if (InventoryValidationService.FindFreeSpace(preferenceController, item, out int fx, out int fy))
            {
                if (preferenceController.PlaceExistingItem(item, fx, fy))
                {
                    _placements.Add(new PlacementRecord(item, preferenceController, fx, fy));
                    _inHandItems.Remove(item.InstanceID);
                    return true;
                }
                item.RestoreRotationState(origAngle);
            }
        }

        return TryPlaceItemInAnyPlayerGrid(item, out errorMessage);
    }

 private bool TryPlaceItemInAnyPlayerGrid(InventoryItem item, out string errorMessage)
{
    errorMessage = string.Empty;
    if (_inventoryUI == null || item == null) return false;

    var grids = new List<(GridType, InventoryController)>
    {
        (GridType.Pockets, _inventoryUI.GetControllerForGrid(GridType.Pockets)),
        (GridType.Pocket2, _inventoryUI.GetControllerForGrid(GridType.Pocket2)),
        (GridType.Backpack, _inventoryUI.GetControllerForGrid(GridType.Backpack)),
    };

    if (_inventoryUI.BackpackManager != null)
    {
        foreach (var w in _inventoryUI.BackpackManager.OpenWindows)
        {
            if (w != null && w.Controller != null)
                grids.Add((GridType.Container, w.Controller));
        }
    }

    // ═══ БАГ 3c ФИКС: при активном луте включить контроллер окружения/лута
    // в candidates для relocation. Без этого свап в окружении отклоняется
    // с "no free space in any player grid" при наличии места в окружении. ═══
    if (_inventoryUI.IsLooting && _inventoryUI.ActiveContainerController != null)
    {
        var lootCtrl = _inventoryUI.ActiveContainerController;
        bool already = false;
        for (int i = 0; i < grids.Count; i++)
            if (grids[i].Item2 == lootCtrl) { already = true; break; }
        if (!already)
            grids.Add((GridType.Container, lootCtrl));
    }

    foreach (var (gridType, ctrl) in grids)
    {
        if (ctrl == null) continue;

        if (!_inventoryUI.BackpackManager.CanPlaceUnfoldedBackpackIntoController(ctrl, item, out _))
            continue;

        int origAngle = item.RotationAngle;
        if (InventoryValidationService.FindFreeSpace(ctrl, item, out int fx, out int fy))
        {
            if (ctrl.PlaceExistingItem(item, fx, fy))
            {
                _placements.Add(new PlacementRecord(item, ctrl, fx, fy));
                _inHandItems.Remove(item.InstanceID);
                return true;
            }
            item.RestoreRotationState(origAngle);
        }
    }

    errorMessage = "no free space in any player grid";
    return false;
}
    private uint GetContainerOwnerId(UI_Item uiItem)
    {
        if (uiItem == null || uiItem.GridType != GridType.Container) return 0u;
        var ctrl = uiItem.BoundController;
        if (ctrl == null || _inventoryUI == null || _inventoryUI.BackpackManager == null) return 0u;
        var win = _inventoryUI.BackpackManager.FindWindowByController(ctrl);
        if (win != null && uint.TryParse(win.BackpackInstanceID, out uint id)) return id;
        return 0u;
    }


    private InventoryController GetControllerForUI(UI_Item uiItem)
    {
        if (uiItem == null || _inventoryUI == null) return null;
        if (uiItem.GridType == GridType.Container && uiItem.BoundController != null)
            return uiItem.BoundController;
        return _inventoryUI.GetControllerForGrid(uiItem.GridType);
    }

    private (int x, int y) FindItemPositionInController(InventoryController ctrl, InventoryItem item)
    {
        if (ctrl == null || item == null) return (-1, -1);
        return ctrl.FindItemRootPosition(item.InstanceID);
    }

    private (GridType? grid, int x, int y) FindItemLocationInPlayerGrids(InventoryItem item)
    {
        if (item == null || _inventoryUI == null) return (null, 0, 0);
        uint id = item.InstanceID;
        var grids = new[]
        {
            (GridType.Pockets, _inventoryUI.GetControllerForGrid(GridType.Pockets)),
            (GridType.Pocket2, _inventoryUI.GetControllerForGrid(GridType.Pocket2)),
            (GridType.Backpack, _inventoryUI.GetControllerForGrid(GridType.Backpack)),
        };
        foreach (var (type, ctrl) in grids)
        {
            if (ctrl == null) continue;
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var at = ctrl.GetItemAt(x, y);
                    if (at != null && at.InstanceID == id)
                        return (type, x, y);
                }
        }
        return (null, 0, 0);
    }

    private bool IsItemAnywhereInController(InventoryController ctrl, InventoryItem item)
    {
        if (ctrl == null || item == null) return false;
        uint id = item.InstanceID;
        for (int y = 0; y < ctrl.Height; y++)
            for (int x = 0; x < ctrl.Width; x++)
            {
                var at = ctrl.GetItemAt(x, y);
                if (at != null && at.InstanceID == id) return true;
            }
        return false;
    }

    private void RemoveItemFromEverywhere(InventoryItem item)
    {
        if (item == null || _inventoryUI == null) return;
        uint id = item.InstanceID;

        var grids = new[]
        {
            _inventoryUI.GetControllerForGrid(GridType.Pockets),
            _inventoryUI.GetControllerForGrid(GridType.Pocket2),
            _inventoryUI.GetControllerForGrid(GridType.Backpack),
        };
        foreach (var ctrl in grids)
        {
            if (ctrl == null) continue;
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var at = ctrl.GetItemAt(x, y);
                    if (at != null && at.InstanceID == id)
                    {
                        ctrl.RemoveItem(item);
                        return;
                    }
                }
        }

        if (_inventoryUI.BackpackManager != null)
        {
            foreach (var w in _inventoryUI.BackpackManager.OpenWindows)
            {
                var ctrl = w != null ? w.Controller : null;
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var at = ctrl.GetItemAt(x, y);
                        if (at != null && at.InstanceID == id)
                        {
                            ctrl.RemoveItem(item);
                            return;
                        }
                    }
            }
        }

        foreach (var slot in _cachedSlots)
        {
            if (slot != null && slot.EquippedItem != null && slot.EquippedItem.InstanceID == id)
            {
                slot.SetEquippedItem(null);
                return;
            }
        }
    }

    private K_EquipmentSlotUI FindSlotHoldingItem(InventoryItem item)
    {
        if (item == null) return null;
        EnsureSlotsCached();
        foreach (var slot in _cachedSlots)
        {
            if (slot != null && slot.EquippedItem != null && slot.EquippedItem.InstanceID == item.InstanceID)
                return slot;
        }
        return null;
    }

    private InventoryItem FindItemByInstanceId(uint instanceId)
    {
        if (instanceId == 0 || _inventoryUI == null) return null;

        var grids = new[]
        {
            _inventoryUI.GetControllerForGrid(GridType.Pockets),
            _inventoryUI.GetControllerForGrid(GridType.Pocket2),
            _inventoryUI.GetControllerForGrid(GridType.Backpack),
        };
        foreach (var ctrl in grids)
        {
            if (ctrl == null) continue;
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var at = ctrl.GetItemAt(x, y);
                    if (at != null && at.InstanceID == instanceId) return at;
                }
        }

        if (_inventoryUI.BackpackManager != null)
        {
            foreach (var w in _inventoryUI.BackpackManager.OpenWindows)
            {
                var ctrl = w != null ? w.Controller : null;
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var at = ctrl.GetItemAt(x, y);
                        if (at != null && at.InstanceID == instanceId) return at;
                    }
            }
        }

        EnsureSlotsCached();
        foreach (var slot in _cachedSlots)
        {
            if (slot != null && slot.EquippedItem != null && slot.EquippedItem.InstanceID == instanceId)
                return slot.EquippedItem;
        }
        return null;
    }

    private K_EquipmentSlotUI FindEquipmentSlot(EquipmentSlotType slotType)
    {
        EnsureSlotsCached();
        foreach (var slot in _cachedSlots)
        {
            if (slot != null && slot.SlotType == slotType) return slot;
        }
        return null;
    }

    private K_EquipmentSlotUI GetEquipSlot(EquipmentSlotType slotType)
    {
        EnsureSlotsCached();
        K_EquipmentSlotUI fallback = null;
        foreach (var slot in _cachedSlots)
        {
            if (slot == null || slot.SlotType != slotType) continue;
            if (!slot.IsOccupied) return slot;
            if (fallback == null) fallback = slot;
        }
        return fallback;
    }

    private void EnsureInitialized()
    {
        if (_inventoryUI == null)
            _inventoryUI = FindFirstObjectByType<K_InventoryUI>();
        EnsureSlotsCached();
    }

    private void EnsureSlotsCached()
    {
        if (_slotsCached) return;
        _slotsCached = true;
        _cachedSlots.Clear();
        var slots = FindObjectsByType<K_EquipmentSlotUI>(FindObjectsSortMode.None);
        foreach (var slot in slots)
            if (slot != null) _cachedSlots.Add(slot);
    }
}
}
