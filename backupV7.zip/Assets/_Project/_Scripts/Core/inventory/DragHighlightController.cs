using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using System.Linq;

namespace K_Incident.Core.Inventory
{
    public sealed class DragHighlightController
    {
        public static DragHighlightController Instance { get; private set; }
        private K_InventoryUI _ui;
        private BackpackContainerManager _backpackManager;
        private DragGhostPresenter _ghostPresenter;
        
        private Color _dragOutlineValidColor = new Color(1f, 0.85f, 0f, 0.8f);
        private Color _dragOutlineInvalidColor = new Color(0.85f, 0.15f, 0.15f, 0.8f);
        private Color _dragOutlineSwapColor = new Color(0.2f, 0.6f, 1f, 0.85f);
        private float _dragOutlineThickness = 2f;
        
        private GameObject _dragOutlineFrame;
        private Image _outlineTop, _outlineBottom, _outlineLeft, _outlineRight;
        private Transform _outlineCurrentParent;
        private Color _outlineLastColor = Color.clear;
        private const float VisualContactEpsilon = 1f;
        
        private UI_Item _hoveredItem;
        private float _lastDragHighlightTime;
        private PointerEventData _cachedEventData;
        private EventSystem _cachedEventSystem;
        private readonly List<RaycastResult> _raycastBuffer = new List<RaycastResult>(8);
        private readonly List<InventoryController> _relocBuffer = new List<InventoryController>(8);
        private readonly List<InventoryItem> _visualScratch = new List<InventoryItem>(16);

        public UI_Item HoveredItem => _hoveredItem;

        public void Initialize(
            K_InventoryUI ui,
            BackpackContainerManager backpackManager,
            DragGhostPresenter ghostPresenter,
            Color validColor,
            Color invalidColor,
            Color swapColor,
            float thickness)
        {
            Instance = this;
            _ui = ui;
            _backpackManager = backpackManager;
            _ghostPresenter = ghostPresenter;
            _dragOutlineValidColor = validColor;
            _dragOutlineInvalidColor = invalidColor;
            _dragOutlineSwapColor = swapColor;
            _dragOutlineThickness = thickness;
        }

       

        
    
 public void UpdateCellHighlights()
{
    if (EventSystem.current == null) return;
    if (Time.unscaledTime - _lastDragHighlightTime < 0.033f) return;
    _lastDragHighlightTime = Time.unscaledTime;
    InventoryItem item = _ui?.DraggedUIItem?.Item ?? _ui?.DraggedFromSlotItem;
    if (item == null) { ClearHighlightsKeepGhostVisible(); return; }
    K_ContainerWindow topmostWindow = RaycastTopmostWindow(Input.mousePosition);
    if (_raycastBuffer.Count == 0) { ClearHighlightsKeepGhostVisible(); return; }
    UI_Item topBackpack = null;
    UI_Item topUIItem = null;
    K_InventorySlotUI topSlot = null;
    K_EquipmentSlotUI topEquip = null;
    var draggedUI = _ui?.DraggedUIItem;
    foreach (var result in _raycastBuffer)
    {
        var go = result.gameObject;
        if (topmostWindow != null && go.GetComponentInParent<K_ContainerWindow>() != topmostWindow)
            continue;
        if (topEquip == null)
        {
            var equip = go.GetComponentInParent<K_EquipmentSlotUI>();
            if (equip != null) { topEquip = equip; }
        }
        if (topUIItem == null)
        {
            var ui = go.GetComponentInParent<UI_Item>();
            if (ui != null && ui != draggedUI && ui.Item != null && ui.gameObject.activeInHierarchy)
            {
                topUIItem = ui;
                if (ui.Item.Data != null && ui.Item.Data.IsBackpack && (!ui.Item.IsFolded || ui.Item.Data.AlwaysShowGrid))
                    topBackpack = ui;
            }
        }
        if (topSlot == null)
        {
            var slot = go.GetComponentInParent<K_InventorySlotUI>();
            if (slot != null) topSlot = slot;
        }
        if (topEquip != null && topUIItem != null && topSlot != null) break;
    }
    if (topSlot == null && topUIItem != null)
    {
        if (topUIItem.GridType == GridType.Container && topUIItem.BoundController != null)
        {
            Transform grid = ResolveGridForController(topUIItem.BoundController, topUIItem);
            if (grid != null)
            {
                int cols = topUIItem.BoundController.Width;
                int idx = topUIItem.Y * cols + topUIItem.X;
                if (idx >= 0 && idx < grid.childCount)
                    topSlot = grid.GetChild(idx).GetComponent<K_InventorySlotUI>();
            }
        }
        else
        {
            topSlot = _ui?.GetSlotAt(topUIItem.GridType, topUIItem.X, topUIItem.Y);
        }
    }
    if (topEquip != null)
    {
        HighlightEquipmentSlot(topEquip, item);
        return;
    }
    if (topBackpack != null)
    {
        HandleBackpackIcon(topBackpack, item);
        return;
    }
    if (topSlot == null) { ClearHighlightsKeepGhostVisible(); return; }

    InventoryController controller;
    if (topSlot.GridType == GridType.Container && topSlot.BoundController != null) controller = topSlot.BoundController;
    else controller = _ui.GetControllerForGrid(topSlot.GridType);
    if (controller == null) { ClearHighlightsKeepGhostVisible(); return; }

    int gridW, gridH;
    if (topSlot.GridType == GridType.Container) { gridW = controller.Width; gridH = controller.Height; }
    else { gridW = _ui.GetGridWidth(topSlot.GridType); gridH = _ui.GetGridHeight(topSlot.GridType); }

    Vector2Int itemSize = item.CurrentSize;
    var (tx, ty) = K_InventoryUI.CalculateSnapPosition(topSlot.X, topSlot.Y, itemSize, gridW, gridH);

    ResolveSnapTargets(item, controller, tx, ty, out var swapTargetUI, out var backpackTargetUI);

    if (backpackTargetUI != null)
    {
        HandleBackpackIcon(backpackTargetUI, item);
        return;
    }
    if (swapTargetUI != null)
    {
        DrawVisualSwapOutline(swapTargetUI, item, tx, ty);
        return;
    }

    // ═══ ОСНОВНАЯ ПРОВЕРКА (ПРЯМАЯ ПОСТАНОВКА) ═══
    bool canPlace = controller.CanPlaceItem(item, tx, ty);

    // ═══ НОВАЯ ПРОВЕРКА ГЛУБИНЫ ДЛЯ РАЗВЁРНУТОГО РЮКЗАКА ═══
    if (canPlace && item.Data != null && item.Data.IsBackpack && !item.IsFolded)
    {
        var targetWindow = _backpackManager?.FindWindowByController(controller);
        if (targetWindow != null)
        {
            if (!_backpackManager.CanPlaceUnfoldedBackpackIntoController(controller, item, out _))
                canPlace = false;
        }
    }

    if (canPlace && topSlot.GridType == GridType.Backpack && item.Data?.IsBackpack == true)
    {
        var backpackSlot = _ui.BackpackEquipmentSlot;
        if (backpackSlot != null && backpackSlot.EquippedItem == item) canPlace = false;
    }
    if (canPlace && topSlot.GridType == GridType.Container
        && _backpackManager.OpenWindows.Any(w => w != null && w.Controller == controller && w.BackpackInstanceID == item.InstanceID.ToString()))
        canPlace = false;
    if (canPlace && topSlot.GridType == GridType.Container)
    {
        InventoryItem targetBackpack = null;
        var targetWindow = _backpackManager.OpenWindows.FirstOrDefault(w => w.Controller == controller);
        if (targetWindow != null && uint.TryParse(targetWindow.BackpackInstanceID, out uint targetId))
            targetBackpack = _ui.FindItemByInstanceId(targetId);
        if (targetBackpack != null && _ui.WouldCreateCircularReference(item, targetBackpack)) canPlace = false;
    }

    bool suppressOutline = false;
    if (item.Data != null && item.Data.IsBackpack && !item.IsFolded && !canPlace)
    {
        if (topSlot.GridType == GridType.Backpack)
        {
            var backpackSlot = _ui.BackpackEquipmentSlot;
            if (backpackSlot != null && backpackSlot.EquippedItem == item) suppressOutline = true;
        }
        if (!suppressOutline)
        {
            var ownerWin = _backpackManager.OpenWindows.FirstOrDefault(w => w != null && w.Controller == controller);
            if (ownerWin != null && uint.TryParse(ownerWin.BackpackInstanceID, out uint ownerId))
            {
                if (item.InstanceID == ownerId || _ui.DraggedContainsTarget(item, ownerId))
                    suppressOutline = true;
            }
        }
    }
    if (suppressOutline)
    {
        if (_hoveredItem != null) { _hoveredItem.SetSelected(false); _hoveredItem = null; }
        _ghostPresenter?.Show();
        HideAll();
        return;
    }

    Color outlineColor = canPlace ? _dragOutlineValidColor : _dragOutlineInvalidColor;
    // ═══ ИСПРАВЛЕНО: переименовали переменную во избежание конфликта имён ═══
    Transform outlineGrid = ResolveGridForController(controller, topSlot);
    GridType gridType = topSlot.GridType;
    if (outlineGrid == null) return;

    if (_hoveredItem != null) { _hoveredItem.SetSelected(false); _hoveredItem = null; }
    _ghostPresenter?.Show();
    ShowDragOutline(outlineGrid, gridType, tx, ty, itemSize, outlineColor);
}

private K_ContainerWindow RaycastTopmostWindow(Vector2 screenPos)
{
    if (_cachedEventData == null || _cachedEventSystem != EventSystem.current)
    {
        _cachedEventSystem = EventSystem.current;
        _cachedEventData = new PointerEventData(EventSystem.current);
    }
    _cachedEventData.position = screenPos;
    _raycastBuffer.Clear();
    EventSystem.current.RaycastAll(_cachedEventData, _raycastBuffer);
    if (_raycastBuffer.Count == 0) return null;
    return _raycastBuffer[0].gameObject.GetComponentInParent<K_ContainerWindow>();
}

public K_ContainerWindow GetTopmostWindow(PointerEventData eventData)
{
    if (EventSystem.current == null) return null;
    return RaycastTopmostWindow(eventData.position);
}
      
      private List<InventoryController> BuildRelocationControllers(InventoryController extra)
{
    _relocBuffer.Clear();
    if (_ui.PocketsController != null) _relocBuffer.Add(_ui.PocketsController);
    if (_ui.Pocket2Controller != null) _relocBuffer.Add(_ui.Pocket2Controller);
    if (_ui.BackpackController != null) _relocBuffer.Add(_ui.BackpackController);
    if (extra != null && !_relocBuffer.Contains(extra)) _relocBuffer.Add(extra);
    if (_backpackManager != null)
    {
        foreach (var w in _backpackManager.OpenWindows)
            if (w != null && w.Controller != null && !_relocBuffer.Contains(w.Controller))
                _relocBuffer.Add(w.Controller);
    }
    return _relocBuffer;
}
// ============================================================
//  ИСПРАВЛЕНИЕ БАГА 1: красная рамка рисуется по снап-футпринту тащимого
// ============================================================
private void DrawVisualSwapOutline(UI_Item targetUI, InventoryItem draggedItem, int anchorX, int anchorY)
{
    var swapTargetCtrl = _ui.FindControllerForItem(targetUI.Item);
    if (swapTargetCtrl == null) { ClearHighlightsKeepGhostVisible(); return; }
    var draggedUI = _ui.DraggedUIItem;
    if (draggedUI == null) { ClearHighlightsKeepGhostVisible(); return; }
    var sourceCtrl = (draggedUI.GridType == GridType.Container && draggedUI.BoundController != null)
        ? draggedUI.BoundController
        : _ui.GetControllerForGrid(draggedUI.GridType);
    if (sourceCtrl == null) { ClearHighlightsKeepGhostVisible(); return; }
    var (sx, sy) = sourceCtrl.FindItemRootPosition(draggedItem.InstanceID);
    if (sx == -1) { ClearHighlightsKeepGhostVisible(); return; }

    _ui.SyncBackpackForValidation(draggedItem);
    _ui.SyncBackpackForValidation(targetUI.Item);

    bool swapValid = InventoryOperationValidator.TryResolveSwapPositions(
        draggedItem, targetUI.Item, swapTargetCtrl, sourceCtrl, sx, sy,
        BuildRelocationControllers(swapTargetCtrl),
        anchorX, anchorY,
        out int swapX, out int swapY, out int draggedRotation, out _,
        _backpackManager);

    Transform grid = ResolveGridForController(swapTargetCtrl, targetUI);
    if (grid == null) { ClearHighlightsKeepGhostVisible(); return; }

    Vector2Int dragSize = draggedItem.CurrentSize;
    Vector2Int targetSize = targetUI.Item.CurrentSize;

    int outX, outY;
    Vector2Int outlineSize;

    // Same-size swap: рамка строго облегает футпринт цели
    if ((dragSize.x == targetSize.x && dragSize.y == targetSize.y) ||
        (dragSize.x == targetSize.y && dragSize.y == targetSize.x))
    {
        outX = targetUI.X;
        outY = targetUI.Y;
        outlineSize = targetSize;
    }
    else if (swapValid)
    {
        // Разные размеры: футпринт тащимого в выбранной валидатором позиции
        outX = swapX;
        outY = swapY;
        outlineSize = dragSize;
    }
    else
    {
        // ═══ БАГ 1 ФИКС: НЕВАЛИДНО → рисуем по СНАП-ФУТПРИНТУ тащимого (anchorX/anchorY),
        // а не по корню цели. Размер = dragSize. ═══
        outX = anchorX;
        outY = anchorY;
        outlineSize = dragSize;
    }

    // Страховочный кламп обводки в границы сетки во ВСЕХ ветках.
    outX = Mathf.Clamp(outX, 0, Mathf.Max(0, swapTargetCtrl.Width - outlineSize.x));
    outY = Mathf.Clamp(outY, 0, Mathf.Max(0, swapTargetCtrl.Height - outlineSize.y));

    _ghostPresenter?.Show();
    if (_hoveredItem != null) { _hoveredItem.SetSelected(false); _hoveredItem = null; }
    ShowDragOutline(grid, targetUI.GridType, outX, outY, outlineSize,
        swapValid ? _dragOutlineSwapColor : _dragOutlineInvalidColor);
}        private void HandleBackpackIcon(UI_Item backpackUI, InventoryItem item)
        {
            _ghostPresenter?.Show();
            if (_hoveredItem != null && _hoveredItem != backpackUI) _hoveredItem.SetSelected(false);

            if (CanPlaceItemInBackpackIcon(backpackUI.Item, item))
            {
                backpackUI.SetSelected(true);
                _hoveredItem = backpackUI;
                HideAll();
            }
            else
            {
                _hoveredItem = null;
                DrawBackpackInvalidOutline(backpackUI, item);
            }
        }

        public void HideAll() => HideDragOutline();

        public void ClearHover()
        {
            if (_hoveredItem != null) { _hoveredItem.SetSelected(false); _hoveredItem = null; }
        }

        public void ClearHoverIfMatches(UI_Item item)
        {
            if (item == null) return;
            if (_hoveredItem == item) { item.SetSelected(false); _hoveredItem = null; }
        }

        public void SetHoveredItem(UI_Item item)
        {
            if (_hoveredItem != null && _hoveredItem != item) _hoveredItem.SetSelected(false);
            item.SetSelected(true);
            _hoveredItem = item;
        }

        public void ClearHoverIfMatchesDragged(UI_Item draggedItem)
        {
            if (draggedItem == null) return;
            if (_hoveredItem == draggedItem) { _hoveredItem.SetSelected(false); _hoveredItem = null; }
        }

      

        private Transform ResolveGridForController(InventoryController controller, UI_Item fallbackUi)
        {
            if (fallbackUi != null && fallbackUi.GridType == GridType.Container)
            {
                var t = fallbackUi.transform.parent;
                while (t != null && t.GetComponent<GridLayoutGroup>() == null) t = t.parent;
                return t;
            }
            if (fallbackUi != null)
            {
                return fallbackUi.GridType switch
                {
                    GridType.Pockets => _ui?.PocketsGrid,
                    GridType.Pocket2 => _ui?.Pocket2Grid,
                    GridType.Backpack => _ui?.BackpackGrid,
                    _ => null
                };
            }
            return null;
        }
        /// <summary>
/// Единственный источник правды для свапа/дропа в рюкзак: снап-футпринт.
/// Свап — только если ячейки постановки заняты. Используется и подсветкой,
/// и OnDrop, поэтому обводка всегда равна результату транзакции.
/// </summary>
// DragHighlightController.cs — ПОЛНАЯ ЗАМЕНА метода ResolveSnapTargets()
// ШАГ 1 конвейера: цель выбирается ТОЛЬКО по визуальному пересечению
// ghost∩иконка (макс. площадь → центр ghost внутри → меньшая дистанция центров).
// Снап-футпринт в выборе цели НЕ участвует (корень багов 1 и 4).
/// <summary>
/// ЕДИНАЯ точка резолва целей swap/drop-into (И2: highlight и drop).
/// Пайплайн:
///   2) CanPlace(snap) → целей нет (вызывающий рисует белую/move; жёлтая НЕ возникает,
///      пока снап-футпринт свободен).
///   3) Снап занят: кандидаты берутся ПО ОККУПАНТАМ СНАП-ФУТПРИНТА, визуальный контакт
///      НЕ требуется.
///   3а) Развёрнутый рюкзак среди оккупантов = цель «дроп ВНУТРЬ» ТОЛЬКО при визуальном
///       контакте его иконки с ghost (best overlap). Без контакта он игнорируется.
///   3б) Оставшиеся свёрнутые оккупанты = цели свапа. primary = оккупант с максимальным
///       клеточным перекрытием снап-футпринта (детерминировано). Валидация и якорь —
///       у вызывающих (DrawVisualSwapOutline / TrySwapItems), единый валидатор.
///   3в) Только развёрнутые без контакта → null (вызывающий: красная, drop отклонён).
/// Визуальный контакт больше НЕ условие свапа — это убирает красную полосу между
/// белой и жёлтой (баг итерации, фото 2).
/// </summary>
public void ResolveSnapTargets(
    InventoryItem draggedItem,
    InventoryController controller,
    int snapX, int snapY,
    out UI_Item swapTarget,
    out UI_Item backpackTarget)
{
    swapTarget = null;
    backpackTarget = null;
    if (draggedItem == null || controller == null) return;
    Vector2Int size = draggedItem.CurrentSize;
    if (snapX < 0 || snapY < 0 || snapX + size.x > controller.Width || snapY + size.y > controller.Height) return;

    if (_ui != null && _ui.IsDraggingFromEquipmentSlot) return; // intentionally left for other logic? No, we removed this line.
    // Actually we removed this early return, so the method continues.

    _visualScratch.Clear();
    for (int dy = 0; dy < size.y; dy++)
    for (int dx = 0; dx < size.x; dx++)
    {
        var occ = controller.GetItemAt(snapX + dx, snapY + dy);
        if (occ == null || occ.InstanceID == draggedItem.InstanceID) continue;
        if (!_visualScratch.Contains(occ)) _visualScratch.Add(occ);
    }
    if (_visualScratch.Count == 0) return;

    bool dragIsUnfoldedBackpack = draggedItem.Data != null && draggedItem.Data.IsBackpack && !draggedItem.IsFolded;

    if (_ghostPresenter != null &&
        _ghostPresenter.TryGetVisualScreenBounds(out Vector2 gMin, out Vector2 gMax))
    {
        var cam = _ui != null ? _ui.RootCanvasCamera : null;
        float bestOverlap = 0f;
        UI_Item bestBackpackUI = null;
        for (int i = 0; i < _visualScratch.Count; i++)
        {
            var cand = _visualScratch[i];
            if (cand.Data == null) continue;
            if (!(cand.Data.IsBackpack && (!cand.IsFolded || cand.Data.AlwaysShowGrid))) continue;
            var ui = _ui.FindUIItemForItem(cand);
            if (ui == null || !ui.gameObject.activeInHierarchy) continue;
            if (!ui.TryGetVisualScreenBounds(cam, out Vector2 bMin, out Vector2 bMax)) continue;
            float ix = Mathf.Min(gMax.x, bMax.x) - Mathf.Max(gMin.x, bMin.x);
            float iy = Mathf.Min(gMax.y, bMax.y) - Mathf.Max(gMin.y, bMin.y);
            if (ix <= VisualContactEpsilon || iy <= VisualContactEpsilon) continue;
            float overlap = ix * iy;
            if (overlap > bestOverlap + 0.01f) { bestOverlap = overlap; bestBackpackUI = ui; }
        }
        if (bestBackpackUI != null)
        {
            backpackTarget = bestBackpackUI;
            return;
        }
    }

    InventoryItem primary = null;
    int primaryOverlap = 0;
    for (int i = 0; i < _visualScratch.Count; i++)
    {
        var cand = _visualScratch[i];
        if (cand.Data == null) continue;
        if (cand.Data.IsBackpack && (!cand.IsFolded || cand.Data.AlwaysShowGrid)) continue;
        if (dragIsUnfoldedBackpack) continue;
        int overlap = 0;
        for (int dy = 0; dy < size.y; dy++)
        for (int dx = 0; dx < size.x; dx++)
        {
            var occ = controller.GetItemAt(snapX + dx, snapY + dy);
            if (occ != null && occ.InstanceID == cand.InstanceID) overlap++;
        }
        if (overlap > primaryOverlap) { primaryOverlap = overlap; primary = cand; }
    }
    if (primary == null) return;
    swapTarget = _ui.FindUIItemForItem(primary);
}

        private Transform ResolveGridForController(InventoryController controller, K_InventorySlotUI fallbackSlot)
        {
            if (fallbackSlot == null) return null;
            if (fallbackSlot.GridType == GridType.Container)
            {
                var t = fallbackSlot.transform.parent;
                while (t != null && t.GetComponent<GridLayoutGroup>() == null) t = t.parent;
                return t;
            }
            return fallbackSlot.GridType switch
            {
                GridType.Pockets => _ui?.PocketsGrid,
                GridType.Pocket2 => _ui?.Pocket2Grid,
                GridType.Backpack => _ui?.BackpackGrid,
                _ => null
            };
        }

        private void ShowDragOutline(Transform grid, GridType gridType, int tx, int ty, Vector2Int itemSize, Color color)
        {
            EnsureDragOutlineFrame();
            if (_outlineCurrentParent != grid)
            {
                _dragOutlineFrame.transform.SetParent(grid, false);
                _outlineCurrentParent = grid;
            }

            var frameRT = _dragOutlineFrame.GetComponent<RectTransform>();
            frameRT.anchorMin = new Vector2(0f, 1f);
            frameRT.anchorMax = new Vector2(0f, 1f);
            frameRT.pivot = new Vector2(0f, 1f);
            frameRT.offsetMin = Vector2.zero;
            frameRT.offsetMax = Vector2.zero;
            frameRT.localScale = Vector3.one;

            float slotSize = _ui?.SlotSize ?? 70f;
            float slotSpacing = _ui?.SlotSpacing ?? 0f;
            float cellStep = slotSize + slotSpacing;
            Vector2 padding = _ui.GetPaddingForGrid(gridType);
            float t = _dragOutlineThickness;

            float frameX = padding.x + tx * cellStep;
            float frameY = -(padding.y + ty * cellStep);
            float frameW = itemSize.x * cellStep - slotSpacing;
            float frameH = itemSize.y * cellStep - slotSpacing;

            var gridRT = grid.GetComponent<RectTransform>();
            float gridRight = gridRT.rect.width;
            float gridBottom = -gridRT.rect.height;

            float clampedLeft = Mathf.Max(frameX, 0f);
            float clampedTop = Mathf.Min(frameY, 0f);
            float clampedRight = Mathf.Min(frameX + frameW, gridRight);
            float clampedBottom = Mathf.Max(frameY - frameH, gridBottom);

            float clampedW = clampedRight - clampedLeft;
            float clampedH = clampedTop - clampedBottom;

            if (clampedW <= 0 || clampedH <= 0) { _dragOutlineFrame.SetActive(false); return; }

            frameRT.anchoredPosition = new Vector2(clampedLeft, clampedTop);
            frameRT.sizeDelta = new Vector2(clampedW, clampedH);

            SetEdgeRect(_outlineTop, 0, 0, clampedW, t);
            SetEdgeRect(_outlineBottom, 0, -clampedH + t, clampedW, t);
            SetEdgeRect(_outlineLeft, 0, -t, t, clampedH - 2 * t);
            SetEdgeRect(_outlineRight, clampedW - t, -t, t, clampedH - 2 * t);

            if (_outlineLastColor != color)
            {
                _outlineTop.color = color;
                _outlineBottom.color = color;
                _outlineLeft.color = color;
                _outlineRight.color = color;
                _outlineLastColor = color;
            }
            _dragOutlineFrame.SetActive(true);
        }

    // ============================================================
//  ИСПРАВЛЕНИЕ БАГА 2: логирование решения обводки для не-рюкзачных слотов
//  (только при смене значения, без спама каждый кадр)
// ============================================================
// Словарь для кэширования последнего состояния swapPossible для каждого слота (чтобы логировать только при изменении)
private readonly Dictionary<K_EquipmentSlotUI, bool> _lastSwapPossibleCache = new Dictionary<K_EquipmentSlotUI, bool>();

private void HighlightEquipmentSlot(K_EquipmentSlotUI equipSlot, InventoryItem item)
{
    bool canPlace = _ui.ValidateEquipItem(item, equipSlot);
    bool slotOccupied = equipSlot.IsOccupied;
    Color slotOutlineColor;

    // ─── СЛОТ РЮКЗАКА ───
    if (equipSlot.SlotType == EquipmentSlotType.Backpack)
    {
        if (!slotOccupied)
        {
            // Пустой слот: рюкзак → белая, не-рюкзак → красная
            slotOutlineColor = canPlace ? _dragOutlineValidColor : _dragOutlineInvalidColor;
        }
        else
        {
            var equippedBackpack = equipSlot.EquippedItem;

            if (item.Data != null && item.Data.IsBackpack)
            {
                // Тащим РЮКЗАК на занятый слот → семантика свапа
                var draggedUI = _ui.DraggedUIItem;
                if (draggedUI == null)
                {
                    slotOutlineColor = _dragOutlineInvalidColor;
                }
                else
                {
                    var sourceCtrl = (draggedUI.GridType == GridType.Container && draggedUI.BoundController != null)
                        ? draggedUI.BoundController
                        : _ui.GetControllerForGrid(draggedUI.GridType);
                    var (sx, sy) = sourceCtrl != null
                        ? sourceCtrl.FindItemRootPosition(item.InstanceID)
                        : (-1, -1);

                    if (sourceCtrl == null || sx == -1)
                    {
                        slotOutlineColor = _dragOutlineInvalidColor;
                    }
                    else
                    {
                        _ui.SyncBackpackForValidation(item);
                        _ui.SyncBackpackForValidation(equippedBackpack);

                        bool swapValid = InventoryOperationValidator.TryResolveEquipSwap(
                            item, equippedBackpack, sourceCtrl, sx, sy,
                            out _, out _, out _);

                        slotOutlineColor = swapValid ? _dragOutlineSwapColor : _dragOutlineInvalidColor;
                    }
                }
            }
            else if (canPlace)
            {
                // Тащим НЕ-рюкзак, но слот рюкзака занят → не подходит по типу (красный)
                slotOutlineColor = _dragOutlineInvalidColor;
            }
            else
            {
                // Тащим НЕ-рюкзак на слот рюкзака → проверяем дроп ВНУТРЬ
                var bpCtrl = _ui.BackpackController;
                if (bpCtrl != null && equippedBackpack != null
                    && equippedBackpack.Data != null && equippedBackpack.Data.IsBackpack)
                {
                    bool dropValid = InventoryOperationValidator.ValidateDropIntoEquippedBackpack(
                        item, bpCtrl, out _, out _, out _);
                    slotOutlineColor = dropValid ? _dragOutlineValidColor : _dragOutlineInvalidColor;
                }
                else
                {
                    slotOutlineColor = _dragOutlineInvalidColor;
                }
            }
        }
    }
    // ─── ОСТАЛЬНЫЕ СЛОТЫ (Primary, Pistol, Melee) ───
    else
    {
        if (!canPlace)
        {
            slotOutlineColor = _dragOutlineInvalidColor;
        }
        else if (!slotOccupied)
        {
            slotOutlineColor = _dragOutlineValidColor;
        }
        else
        {
            // Swap для не-рюкзачных слотов
            var oldItem = equipSlot.EquippedItem;
            bool swapPossible = false;
            string reason = "empty";
            if (oldItem != null)
            {
                bool nestingOk = InventoryValidationService.NestingCheckBidirectional(item, oldItem);
                bool canPlaceOld = false;
                var draggedUI = _ui.DraggedUIItem;
                InventoryController sourceCtrl = null;
                if (draggedUI != null)
                {
                    sourceCtrl = (draggedUI.GridType == GridType.Container && draggedUI.BoundController != null)
                        ? draggedUI.BoundController
                        : _ui.GetControllerForGrid(draggedUI.GridType);
                }
                if (sourceCtrl != null && ControllerCanFitWithAutoRotate(sourceCtrl, oldItem))
                {
                    canPlaceOld = true;
                    reason = "source controller has space";
                }
                else
                {
                    foreach (var ctrl in new[] { _ui.PocketsController, _ui.Pocket2Controller, _ui.BackpackController })
                    {
                        if (ctrl != null && ControllerCanFitWithAutoRotate(ctrl, oldItem))
                        {
                            canPlaceOld = true;
                            reason = "player grid has space";
                            break;
                        }
                    }
                }
                swapPossible = nestingOk && canPlaceOld;
                if (!swapPossible) reason = nestingOk ? "no space for old item" : "nesting cycle";
            }
            slotOutlineColor = swapPossible ? _dragOutlineSwapColor : _dragOutlineInvalidColor;

            // ═══ ЛОГИРОВАНИЕ при СМЕНЕ значения (без спама) ═══
            bool log = false;
            if (_lastSwapPossibleCache.TryGetValue(equipSlot, out bool last))
            {
                if (last != swapPossible)
                {
                    _lastSwapPossibleCache[equipSlot] = swapPossible;
                    log = true;
                }
            }
            else
            {
                _lastSwapPossibleCache[equipSlot] = swapPossible;
                log = true; // первый раз логируем
            }

            if (log)
            {
                Debug.Log($"[HighlightEquipmentSlot] {equipSlot.SlotType}: swapPossible={swapPossible}, reason={reason}, " +
                          $"item='{item.Data?.DisplayName}', old='{oldItem?.Data?.DisplayName}'");
            }
        }
    }

    if (_hoveredItem != null) { _hoveredItem.SetSelected(false); _hoveredItem = null; }
    _ghostPresenter?.Show();
    ShowEquipmentSlotOutline(equipSlot, item.CurrentSize, slotOutlineColor);
}

// Вспомогательный компонент для кэширования состояния (добавить как отдельный класс или использовать Dictionary)
private class DragHighlightSlotState : MonoBehaviour { public bool LastSwapPossible; }

    private void ShowEquipmentSlotOutline(K_EquipmentSlotUI slot, Vector2Int itemSize, Color color)
{
    EnsureDragOutlineFrame();
    if (_dragOutlineFrame == null) return;

    var slotRT = slot.GetComponent<RectTransform>();
    if (slotRT == null) return;

    // ═══ ФИКС БАГ 4: Парентимся в КОРНЕВОЙ CANVAS ═══
    // Раньше парентились в _ui.transform, а координаты считали
    // относительно rootRT → несовпадение систем координат.
    RectTransform rootRT = _ui?.RootCanvasTransform as RectTransform;
    if (rootRT == null) return;

    if (_outlineCurrentParent != rootRT)
    {
        _dragOutlineFrame.transform.SetParent(rootRT, false);
        _outlineCurrentParent = rootRT;
    }

    // Z-order: рамка поверх всех панелей
    _dragOutlineFrame.transform.SetAsLastSibling();

    var frameRT = _dragOutlineFrame.GetComponent<RectTransform>();
    if (frameRT == null) return;

    frameRT.anchorMin = new Vector2(0f, 1f);
    frameRT.anchorMax = new Vector2(0f, 1f);
    frameRT.pivot = new Vector2(0f, 1f);
    frameRT.offsetMin = Vector2.zero;
    frameRT.offsetMax = Vector2.zero;
    frameRT.localScale = Vector3.one;

    Vector3[] corners = new Vector3[4];
    slotRT.GetWorldCorners(corners);

    // Координаты относительно rootRT — и фрейм тоже потомок rootRT
    Vector2 localTL = rootRT.InverseTransformPoint(corners[1]);
    Vector2 localBR = rootRT.InverseTransformPoint(corners[3]);
    float w = localBR.x - localTL.x;
    float h = localTL.y - localBR.y;

    if (w <= 0f || h <= 0f) { _dragOutlineFrame.SetActive(false); return; }

    frameRT.anchoredPosition = new Vector2(localTL.x, localTL.y);
    frameRT.sizeDelta = new Vector2(w, h);

    float t = _dragOutlineThickness;
    SetEdgeRect(_outlineTop, 0, 0, w, t);
    SetEdgeRect(_outlineBottom, 0, -h + t, w, t);
    SetEdgeRect(_outlineLeft, 0, -t, t, h - 2f * t);
    SetEdgeRect(_outlineRight, w - t, -t, t, h - 2f * t);

    if (_outlineLastColor != color)
    {
        _outlineTop.color = color;
        _outlineBottom.color = color;
        _outlineLeft.color = color;
        _outlineRight.color = color;
        _outlineLastColor = color;
    }

    _dragOutlineFrame.SetActive(true);
}

        private void DrawBackpackInvalidOutline(UI_Item backpackUI, InventoryItem draggedItem)
        {
            if (backpackUI?.Item == null || backpackUI.Item.Data == null || draggedItem == null) return;
            GridType gridType = backpackUI.GridType;
            Transform grid = ResolveGridForController(backpackUI.BoundController, backpackUI);
            if (grid == null) return;

            var bpSize = backpackUI.Item.CurrentSize;
            ShowDragOutline(grid, gridType, backpackUI.X, backpackUI.Y, bpSize, _dragOutlineInvalidColor);
        }

        private void SetEdgeRect(Image img, float x, float y, float w, float h)
        {
            var rt = img.rectTransform;
            rt.anchorMin = new Vector2(0, 1); rt.anchorMax = new Vector2(0, 1); rt.pivot = new Vector2(0, 1);
            rt.anchoredPosition = new Vector2(x, y); rt.sizeDelta = new Vector2(w, h);
        }

        private void EnsureDragOutlineFrame()
        {
            if (_dragOutlineFrame != null) return;
            _dragOutlineFrame = new GameObject("DragOutline", typeof(RectTransform));
            _dragOutlineFrame.AddComponent<LayoutElement>().ignoreLayout = true;
            _outlineTop = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeTop");
            _outlineBottom = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeBottom");
            _outlineLeft = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeLeft");
            _outlineRight = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeRight");
            _dragOutlineFrame.SetActive(false);
        }

        private Image CreateEdgeImage(Transform parent, string name)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var img = go.GetComponent<Image>();
            img.sprite = null; img.type = Image.Type.Simple; img.color = Color.clear; img.raycastTarget = false;
            return img;
        }

        private void HideDragOutline()
        {
            if (_dragOutlineFrame != null)
            {
                var frameRT = _dragOutlineFrame.GetComponent<RectTransform>();
                if (frameRT != null)
                {
                    frameRT.anchorMin = new Vector2(0f, 1f); frameRT.anchorMax = new Vector2(0f, 1f); frameRT.pivot = new Vector2(0f, 1f);
                    frameRT.offsetMin = Vector2.zero;
                    frameRT.offsetMax = Vector2.zero;
                }
                var inventoryTransform = _ui?.transform;
                if (inventoryTransform != null) _dragOutlineFrame.transform.SetParent(inventoryTransform, false);
                _dragOutlineFrame.SetActive(false);
            }
            _outlineCurrentParent = null;
            _outlineLastColor = Color.clear;
        }

        private void ClearHighlightsKeepGhostVisible() => HideAll();


        

        private bool ControllerCanFitWithAutoRotate(InventoryController controller, InventoryItem item)
        {
            if (controller == null || item == null) return false;
            var size = item.CurrentSize;
            if (controller.CanFitItem(size)) return true;
            if (item.Data != null && item.Data.CanRotate)
            {
                var rot = new Vector2Int(size.y, size.x);
                if ((rot.x != size.x || rot.y != size.y) && controller.CanFitItem(rot)) return true;
            }
            return false;
        }

      

  private bool CanPlaceItemInBackpackIcon(InventoryItem backpackItem, InventoryItem item)
{
    // Синхронизация снапшотов — идентично транзакции (паритет highlight/транзакция).
    _ui.SyncBackpackForValidation(item);
    _ui.SyncBackpackForValidation(backpackItem);
    // ЕДИНСТВЕННАЯ точка валидации icon-drop.
    return InventoryOperationValidator.ValidateDropIntoBackpack(item, backpackItem, _backpackManager, out _);
}
    }
}