﻿﻿// === Source: original file lines 19307-20183 ===
using K_Incident.Core.Inventory;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    public class InventoryController : IDisposable, ISaveable
    {
        #region Events & Constants
        public event Action OnInventoryChanged;
        public event Action<float> OnWeightChanged;
        public event Action<InventoryItem, int, int> OnItemPlaced;
        public event Action<InventoryItem> OnItemRemoved;
        public event Action<InventoryItem> OnItemRotated;
        public event Action<InventoryItem> OnItemQuantityChanged;

        public event Action<List<InventoryItem>> OnResizeOverflow;

        private const int MAX_STACK_LIMIT = 90;
        private const int DEFAULT_MAX_CAPACITY_GRAMS = 30000;
        private const float GRAM_TO_KG = 0.001f;
        private const int MIN_GRID_INDEX = 0;
        #endregion

        #region Fields
        public string SaveID { get; private set; }
        public bool IsDirty { get; set; } = true;

        private InventoryData _data;
        private ItemDatabase _database;
        private InventoryItem[,] _grid;
        private readonly Dictionary<uint, InventoryItem> _itemCache = new();
        private readonly Dictionary<uint, (int x, int y)> _positionCache = new();
        private int _currentWeightGrams;
        private int _maxCapacityGrams = DEFAULT_MAX_CAPACITY_GRAMS;
        private bool _isDisposed;
        #endregion

        #region Properties
        public bool IsDisposed => _isDisposed;
        public int Width => _data?.Width ?? 0;
        public int Height => _data?.Height ?? 0;
        public float CurrentWeightKg => _currentWeightGrams * GRAM_TO_KG;
        public float WeightRatio => _maxCapacityGrams > 0 ? _currentWeightGrams / (float)_maxCapacityGrams : 0f;
        public int MaxCapacityGrams => _maxCapacityGrams;
        #endregion

        #region Constructor
        public InventoryController(InventoryData data, ItemDatabase database, string saveID = null)
        {
            _data = data ?? throw new ArgumentNullException(nameof(data));
            _database = database ?? throw new ArgumentNullException(nameof(database));
            SaveID = saveID ?? $"Inv_{Guid.NewGuid():N}";

            InitializeGrid();
            LoadFromData();
        }

        private void InitializeGrid()
        {
            if (_data.Width <= 0 || _data.Height <= 0)
                throw new ArgumentException($"Invalid grid dimensions: {_data.Width}x{_data.Height}", nameof(_data));

            _grid = new InventoryItem[_data.Width, _data.Height];
            _currentWeightGrams = 0;
        }

        private void LoadFromData()
        {
            int skippedCount = 0;

            foreach (var saved in _data.GetItems())
            {
                var template = _database.GetItemData(saved.ItemID);
                if (template == null)
                {
                    LogWarning($"Template not found for ItemID: {saved.ItemID} (InstanceID: {saved.InstanceID})");
                    skippedCount++; continue;
                }

                var item = InventoryItem.FromSaveData(saved, template);
                if (item == null)
                {
                    LogWarning($"Failed to create item from SavedData: {saved.ItemID}");
                    skippedCount++; continue;
                }

                if (!CanPlaceInternal(item, saved.X, saved.Y, item.CurrentSize))
                {
                    LogWarning($"Cannot place item {saved.InstanceID} at ({saved.X},{saved.Y}) - bounds/collision conflict");
                    skippedCount++; continue;
                }

                if (!BindToGrid(item, saved.X, saved.Y))
                {
                    LogWarning($"BindToGrid failed for item {saved.InstanceID} at ({saved.X},{saved.Y})");
                    skippedCount++; continue;
                }
            }

            if (skippedCount > 0) Debug.LogWarning($"[InventoryController] Load complete: {skippedCount} items skipped");

            RecalculateWeight();
            _data.MarkClean();
            IsDirty = false;
        }
        #endregion

        #region Placement Logic
        public bool CanPlaceItem(InventoryItem item, int x, int y) =>
            item != null && item.Data != null && CanPlaceInternal(item, x, y, item.CurrentSize);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool IsValidCoordinate(int x, int y)
        {
            Debug.Assert(_data != null, "IsValidCoordinate called with null _data");
            return _data != null && x >= MIN_GRID_INDEX && y >= MIN_GRID_INDEX &&
                   x < _data.Width && y < _data.Height;
        }

        private bool CanPlaceInternal(InventoryItem item, int x, int y, Vector2Int size)
        {
            if (!IsValidCoordinate(x, y) || !IsValidCoordinate(x + size.x - 1, y + size.y - 1))
                return false;

            InventoryItem stackTarget = null;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    var existing = _grid[x + dx, y + dy];
                    if (existing == null || existing == item) continue;

                    if (!CanStack(existing, item)) return false;

                    if (stackTarget == null) stackTarget = existing;
                    else if (stackTarget.InstanceID != existing.InstanceID) return false;
                }
            }

            return true;
        }

        private bool CanOccupy(int x, int y, Vector2Int size, InventoryItem ignoredItem = null)
        {
            if (_isDisposed || _grid == null || _data == null)
                return false;
            if (size.x <= 0 || size.y <= 0)
                return false;

            if (x < 0 || y < 0 ||
                x > _data.Width - size.x ||
                y > _data.Height - size.y)
                return false;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    InventoryItem occupied = _grid[x + dx, y + dy];
                    if (occupied != null && !ReferenceEquals(occupied, ignoredItem))
                        return false;
                }
            }
            return true;
        }

        private void ClearCellsOwnedBy(InventoryItem item)
        {
            if (_grid == null) return;
            for (int y = 0; y < _data.Height; y++)
                for (int x = 0; x < _data.Width; x++)
                    if (ReferenceEquals(_grid[x, y], item))
                        _grid[x, y] = null;
        }

        private void FillCells(InventoryItem item, int x, int y, Vector2Int size)
        {
            if (_grid == null) return;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    _grid[x + dx, y + dy] = item;
        }

        private bool CanPlaceInternalEmptyOnly(int x, int y, Vector2Int size)
        {
            if (!IsValidCoordinate(x, y) || !IsValidCoordinate(x + size.x - 1, y + size.y - 1))
                return false;

            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    if (_grid[x + dx, y + dy] != null) return false;

            return true;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool CanStack(InventoryItem target, InventoryItem source)
        {
            if (target.PrefabID != source.PrefabID) return false;
            if (target.Quantity >= target.Data.HardStackLimit) return false;
            if (target.Durability != source.Durability) return false;
            if (target.RotationAngle != source.RotationAngle) return false;
            if (target.IsFolded != source.IsFolded) return false;
            return true;
        }

        public int TryPlaceItem(InventoryItem source, int x, int y)
        {
            if (_isDisposed || source == null || source.Data == null || source.Quantity <= 0) return 0;
            if (!CanPlaceInternal(source, x, y, source.CurrentSize)) return 0;

            int remainder = source.Quantity;
            int placedCount = 0;

            var targetStack = FindStackTarget(source, x, y);
            if (targetStack != null)
            {
                int space = targetStack.Data.HardStackLimit - targetStack.Quantity;
                if (space <= 0) return 0;

                int toAdd = Mathf.Min(space, remainder);
                int oldQty = targetStack.Quantity;
                targetStack.AddQuantity(toAdd);
                int actuallyAdded = targetStack.Quantity - oldQty;

                if (actuallyAdded <= 0) return 0;

                AdjustWeight(source.Data.WeightGrams * actuallyAdded);
                remainder -= actuallyAdded;
                placedCount += actuallyAdded;

                if (_positionCache.TryGetValue(targetStack.InstanceID, out var pos))
                    _data.UpdateItem(targetStack.InstanceID, pos.x, pos.y, targetStack.Quantity, targetStack.IsRotated);

                SafeInvoke(OnItemQuantityChanged, targetStack);
            }

            if (remainder > 0)
            {
                var newItem = new InventoryItem(source.Data, GlobalIDManager.GenerateID(), remainder, source.Durability, source.IsRotated);

                if (!BindToGrid(newItem, x, y))
                {
                    LogWarning($"Failed to bind new item {newItem.InstanceID} at ({x},{y})");
                    return placedCount;
                }

                _data.AddItem(newItem.ToSaveData(x, y));
                AdjustWeight(source.Data.WeightGrams * remainder);
                SafeInvoke(OnItemPlaced, newItem, x, y);
                placedCount += remainder;
            }

            if (placedCount > 0)
            {
                MarkDirty();
                SafeInvoke(OnInventoryChanged);
            }

            return placedCount;
        }

        public bool PlaceExistingItem(InventoryItem item, int x, int y)
        {
            if (_isDisposed || item == null || item.Data == null)
            {
                LogWarning($"PlaceExistingItem: invalid item");
                return false;
            }

            if (_itemCache.ContainsKey(item.InstanceID))
            {
                LogWarning($"PlaceExistingItem: item {item.InstanceID} already in cache — use MoveItem instead");
                return false;
            }

            if (!CanOccupy(x, y, item.CurrentSize, ignoredItem: item))
            {
                return false;
            }

            if (!BindToGrid(item, x, y))
            {
                LogWarning($"PlaceExistingItem: BindToGrid failed for item {item.InstanceID} at ({x},{y})");
                return false;
            }

            _data.AddItem(item.ToSaveData(x, y));
            AdjustWeight(item.TotalWeightGrams);
            SafeInvoke(OnItemPlaced, item, x, y);
            MarkDirty();
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        public bool PlaceExistingItemInFirstFreeSlot(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;

            for (int y = 0; y < _data.Height; y++)
                for (int x = 0; x < _data.Width; x++)
                    if (PlaceExistingItem(item, x, y))
                        return true;

            return false;
        }

       public bool MoveItem(InventoryItem item, int newX, int newY)
{
    if (_isDisposed || item == null || !_positionCache.ContainsKey(item.InstanceID))
    {
        LogWarning($"MoveItem: Item {item?.InstanceID} not found in position cache");
        return false;
    }
    var oldPos = _positionCache[item.InstanceID];
    // ═══ ФИКС [Integrity] "Cell outside footprint of its own item" ═══
    // Ранний return при совпадении позиции пропускал пересборку футпринта.
    // Предмет во время drag остаётся в сетке, а поворот (R) мутирует
    // CurrentSize — в сетке держится СТАРЫЙ футпринт. Drop в ту же корневую
    // позицию оставлял фантомные ячейки ((1,0) после 2x1→1x2) и не писал
    // IsRotated в _data. No-op разрешён только если футпринт и состояние
    // фактически не менялись.
    if (oldPos.x == newX && oldPos.y == newY && FootprintIntact(item, oldPos.x, oldPos.y))
    {
        var saved = _data.GetItem(item.InstanceID);
        if (saved.IsRotated == item.IsRotated && saved.Quantity == item.Quantity)
            return true;
    }
    if (!CanOccupy(newX, newY, item.CurrentSize, item))
    {
        LogWarning($"MoveItem: Cannot move item {item.InstanceID} to ({newX},{newY})");
        return false;
    }
    // КОРНЕВОЙ ФИКС: Очистка ячеек по принадлежности предмету.
    // При вращении предмета во время drag, item.CurrentSize менялся, и старый ClearCellRange
    // оставлял "фантомные" ячейки в сетке, так как чистил по новому размеру.
    ClearCellsOwnedBy(item);
    _itemCache.Remove(item.InstanceID);
    _positionCache.Remove(item.InstanceID);
    if (!BindToGrid(item, newX, newY))
    {
        LogWarning($"MoveItem: BindToGrid failed for item {item.InstanceID} at ({newX},{newY})");
        return false;
    }
    _data.UpdateItem(item.InstanceID, newX, newY, item.Quantity, item.IsRotated);
    MarkDirty();
    SafeInvoke(OnInventoryChanged);
    return true;
}

private bool FootprintIntact(InventoryItem item, int x, int y)
{
    var size = item.CurrentSize;
    if (x < 0 || y < 0 || x + size.x > _data.Width || y + size.y > _data.Height) return false;
    for (int dy = 0; dy < size.y; dy++)
        for (int dx = 0; dx < size.x; dx++)
            if (!ReferenceEquals(_grid[x + dx, y + dy], item)) return false;
    return true;
}

        private InventoryItem FindStackTarget(InventoryItem item, int x, int y)
        {
            var target = GetItemAt(x, y);
            if (target == null) return null;

            if (!IsRootCell(target.InstanceID, x, y)) return null;

            if (target.CurrentSize.x != item.CurrentSize.x ||
                target.CurrentSize.y != item.CurrentSize.y ||
                target.RotationAngle != item.RotationAngle) return null;

            if (!CanStack(target, item)) return null;

            return target;
        }

        private bool BindToGrid(InventoryItem item, int x, int y)
        {
            if (_itemCache.ContainsKey(item.InstanceID))
            {
                LogWarning($"Duplicate InstanceID {item.InstanceID} — skipping bind at ({x},{y})");
                return false;
            }

            var size = item.CurrentSize;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    _grid[x + dx, y + dy] = item;

            _itemCache[item.InstanceID] = item;
            _positionCache[item.InstanceID] = (x, y);
            return true;
        }
        #endregion

        #region Rotation & Removal
        public bool RotateItem(InventoryItem item)
        {
            if (_isDisposed || item == null || item.Data == null || !item.Data.CanRotate)
                return false;
            if (!_positionCache.TryGetValue(item.InstanceID, out var pos))
                return false;

            int oldAngle = item.RotationAngle;
            Vector2Int oldSize = item.CurrentSize;

            item.Rotate();
            if (item.RotationAngle == oldAngle)
                return false;

            Vector2Int candidateSize = item.CurrentSize;
            item.RestoreRotationState(oldAngle);

            if (!CanOccupy(pos.x, pos.y, candidateSize, ignoredItem: item))
                return false;

            ClearCellsOwnedBy(item);
            item.Rotate();

            if (item.CurrentSize != candidateSize)
            {
                item.RestoreRotationState(oldAngle);
                FillCells(item, pos.x, pos.y, oldSize);
                return false;
            }

            FillCells(item, pos.x, pos.y, candidateSize);

            _data.UpdateItem(item.InstanceID, pos.x, pos.y, item.Quantity, item.IsRotated);
            MarkDirty();
            SafeInvoke(OnItemRotated, item);
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        public bool RemoveItem(InventoryItem item)
        {
            if (_isDisposed || item == null || !_positionCache.ContainsKey(item.InstanceID)) return false;

            // КОРНЕВОЙ ФИКС: Безопасная очистка ячеек предмета. 
            // Устраняет баг с фантомными ячейками после вращения.
            ClearCellsOwnedBy(item);

            _itemCache.Remove(item.InstanceID);
            _positionCache.Remove(item.InstanceID);
            _data.RemoveItem(item.InstanceID);
            AdjustWeight(-item.TotalWeightGrams);

            SafeInvoke(OnItemRemoved, item);
            MarkDirty();
            SafeInvoke(OnInventoryChanged);
            return true;
        }
        #endregion

        #region Weight & Helpers
        public void AdjustWeight(int deltaGrams)
        {
            int oldWeight = _currentWeightGrams;
            _currentWeightGrams = Mathf.Max(0, _currentWeightGrams + deltaGrams);

            if (_currentWeightGrams != oldWeight) MarkDirty();
            SafeInvoke(OnWeightChanged, CurrentWeightKg);
        }

        private void RecalculateWeight()
        {
            int sum = 0;
            foreach (var item in _itemCache.Values) sum += item.TotalWeightGrams;
            _currentWeightGrams = sum;
            SafeInvoke(OnWeightChanged, CurrentWeightKg);
        }

        public InventoryItem GetItemAt(int x, int y)
        {
            if (_isDisposed || _data == null || _grid == null) return null;
            if (!IsValidCoordinate(x, y)) return null;
            return _grid[x, y];
        }

        public (int x, int y) FindItemRootPosition(uint instanceId)
        {
            for (int y = 0; y < Height; y++)
                for (int x = 0; x < Width; x++)
                {
                    var at = GetItemAt(x, y);
                    if (at != null && at.InstanceID == instanceId && IsRootCell(instanceId, x, y))
                        return (x, y);
                }
            return (-1, -1);
        }

        public bool IsRootCell(uint id, int x, int y) =>
            _positionCache.TryGetValue(id, out var pos) && pos.x == x && pos.y == y;

        private void MarkDirty() => IsDirty = true;

        private void LogWarning(string message, [CallerMemberName] string method = "")
        {
            if (!_isDisposed) Debug.LogWarning($"[InventoryController.{method}] {message}");
        }

        private void SafeInvoke(Action handler)
        {
            if (!_isDisposed) handler?.Invoke();
        }

        private void SafeInvoke<T>(Action<T> handler, T arg)
        {
            if (!_isDisposed) handler?.Invoke(arg);
        }

        private void SafeInvoke<T1, T2>(Action<T1, T2> handler, T1 arg1, T2 arg2)
        {
            if (!_isDisposed) handler?.Invoke(arg1, arg2);
        }

        private void SafeInvoke<T1, T2, T3>(Action<T1, T2, T3> handler, T1 arg1, T2 arg2, T3 arg3)
        {
            if (!_isDisposed) handler?.Invoke(arg1, arg2, arg3);
        }
        #endregion

        #region UI Helper Methods
        public int GetItemCount() => _itemCache.Count;

        public bool CanFitItem(Vector2Int size)
        {
            if (size.x > _data.Width || size.y > _data.Height) return false;
            for (int x = 0; x <= _data.Width - size.x; x++)
                for (int y = 0; y <= _data.Height - size.y; y++)
                    if (CanPlaceInternalEmptyOnly(x, y, size)) return true;
            return false;
        }

        public int GetFreeCellCount()
        {
            int count = 0;
            for (int x = 0; x < _data.Width; x++)
                for (int y = 0; y < _data.Height; y++)
                    if (_grid[x, y] == null) count++;
            return count;
        }

        public bool TryPlaceItemInFirstFreeSlot(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;
            Vector2Int size = item.CurrentSize;

            for (int y = 0; y < _data.Height; y++)
                for (int x = 0; x < _data.Width; x++)
                    if (CanPlaceItem(item, x, y)) return TryPlaceItem(item, x, y) > 0;

            return false;
        }

                public InventoryData GetSaveData() => _data;

        /// <summary>
        /// ФИКС: Безопасно обновляет SavedItem в _data перед сохранением или синхронизацией,
        /// используя уже актуальный _backpackContentsSerialized. НЕ вызывает GetSaveData(), избегая рекурсии.
        /// </summary>
        public void RefreshAllItemsInData()
{
    if (_isDisposed || _data == null)
        return;

    foreach (var kvp in _itemCache)
    {
        var item = kvp.Value;
        if (item == null)
            continue;

        RefreshItemInData(item);
    }
}
        public bool RefreshItemInData(InventoryItem item)
{
    if (_isDisposed || item == null || _data == null)
        return false;

    if (!_itemCache.TryGetValue(item.InstanceID, out var liveItem))
        return false;

    if (!ReferenceEquals(liveItem, item))
        return false;

    if (!_positionCache.TryGetValue(item.InstanceID, out var pos))
        return false;

    _data.UpdateItemWithContents(
        liveItem.InstanceID,
        pos.x,
        pos.y,
        liveItem.Quantity,
        liveItem.IsRotated,
        liveItem.IsFolded,
        liveItem.GetBackpackContentsRaw());

    MarkDirty();
    return true;
}
        
        public void Clear()
        {
            if (_isDisposed) return;

            if (_grid != null && _data != null)
            {
                Array.Clear(_grid, 0, _grid.Length);
                _grid = new InventoryItem[_data.Width, _data.Height];
            }

            _itemCache.Clear();
            _positionCache.Clear();
            _currentWeightGrams = 0;

            if (_data != null) _data.Clear();

            MarkDirty();
            SafeInvoke(OnInventoryChanged);
        }

        public bool Resize(int newWidth, int newHeight)
        {
            if (_isDisposed || _data == null) return false;
            newWidth = Mathf.Clamp(newWidth, 1, 20);
            newHeight = Mathf.Clamp(newHeight, 1, 20);
            if (newWidth == _data.Width && newHeight == _data.Height) return true;

            var snapshot = new List<(InventoryItem item, int x, int y)>(_itemCache.Count);
            foreach (var kvp in _positionCache)
                if (_itemCache.TryGetValue(kvp.Key, out var it) && it != null)
                    snapshot.Add((it, kvp.Value.x, kvp.Value.y));

            var tempGrid = new InventoryItem[newWidth, newHeight];
            var tempItemCache = new Dictionary<uint, InventoryItem>();
            var tempPositionCache = new Dictionary<uint, (int x, int y)>();
            var tempDataItems = new List<SavedItem>(snapshot.Count);

            var notPlaced = new List<InventoryItem>();

            foreach (var (item, x, y) in snapshot)
            {
                if (CanOccupyIn(tempGrid, newWidth, newHeight, x, y, item.CurrentSize, ignoredItem: item))
                {
                    PlaceInTemp(tempGrid, item, x, y, item.CurrentSize);
                    tempItemCache[item.InstanceID] = item;
                    tempPositionCache[item.InstanceID] = (x, y);
                    tempDataItems.Add(item.ToSaveData(x, y));
                }
                else
                {
                    bool placed = false;
                    for (int ny = 0; ny < newHeight && !placed; ny++)
                        for (int nx = 0; nx < newWidth && !placed; nx++)
                            if (CanOccupyIn(tempGrid, newWidth, newHeight, nx, ny, item.CurrentSize, null))
                            {
                                PlaceInTemp(tempGrid, item, nx, ny, item.CurrentSize);
                                tempItemCache[item.InstanceID] = item;
                                tempPositionCache[item.InstanceID] = (nx, ny);
                                tempDataItems.Add(item.ToSaveData(nx, ny));
                                placed = true;
                            }
                    if (!placed) notPlaced.Add(item);
                }
            }

            if (notPlaced.Count > 0 && OnResizeOverflow == null)
            {
                LogWarning(
                    $"Resize: {notPlaced.Count} items cannot fit in " +
                    $"{newWidth}x{newHeight} and no OnResizeOverflow subscriber. Aborting.");
                return false;
            }

            if (_grid != null) Array.Clear(_grid, 0, _grid.Length);
            _grid = tempGrid;
            _itemCache.Clear();
            foreach (var kvp in tempItemCache) _itemCache[kvp.Key] = kvp.Value;
            _positionCache.Clear();
            foreach (var kvp in tempPositionCache) _positionCache[kvp.Key] = kvp.Value;

            _data.Resize(newWidth, newHeight);
            foreach (var sd in tempDataItems) _data.AddItem(sd);

            if (notPlaced.Count > 0)
            {
                OnResizeOverflow.Invoke(notPlaced);
            }

            RecalculateWeight();
            MarkDirty();
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        private static bool CanOccupyIn(InventoryItem[,] grid, int w, int h, int x, int y, Vector2Int size, InventoryItem ignoredItem)
        {
            if (size.x <= 0 || size.y <= 0) return false;
            if (x < 0 || y < 0 || x > w - size.x || y > h - size.y) return false;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    var occ = grid[x + dx, y + dy];
                    if (occ != null && !ReferenceEquals(occ, ignoredItem))
                        return false;
                }
            return true;
        }

        private static void PlaceInTemp(InventoryItem[,] grid, InventoryItem item, int x, int y, Vector2Int size)
        {
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    grid[x + dx, y + dy] = item;
        }
        #endregion

        #region Serialization
        public void Save(BinaryWriter writer)
        {
            writer.Write(SaveID);
            writer.Write(IsDirty);
            _data?.Save(writer);
        }

        public void Load(BinaryReader reader)
        {
            if (_isDisposed || _data == null)
                throw new ObjectDisposedException(nameof(InventoryController));

            string loadedSaveId = reader.ReadString();
            _ = reader.ReadBoolean(); 

            if (!string.Equals(loadedSaveId, SaveID, StringComparison.Ordinal))
                Debug.LogWarning(
                    $"[InventoryController.Load] SaveID mismatch: " +
                    $"expected='{SaveID}', got='{loadedSaveId}'. " +
                    "Continuing load — payload structure must still match.");

            if (_grid != null)
                Array.Clear(_grid, 0, _grid.Length);

            _itemCache.Clear();
            _positionCache.Clear();

            _data.Load(reader);
            _grid = new InventoryItem[_data.Width, _data.Height];

            LoadFromData();
            IsDirty = false;

            SafeInvoke(OnInventoryChanged);
        }
        #endregion

        #region Disposable & Memory Safety
        public void Dispose()
        {
            if (_isDisposed) return;
            _isDisposed = true;

            OnInventoryChanged = null;
            OnWeightChanged = null;
            OnItemPlaced = null;
            OnItemRemoved = null;
            OnItemRotated = null;
            OnItemQuantityChanged = null;

            _itemCache.Clear();
            _positionCache.Clear();

            if (_grid != null)
            {
                Array.Clear(_grid, 0, _grid.Length);
                _grid = null;
            }

            _data = null;
            _database = null;
        }
    
        #endregion

                #region Debug
        [ContextMenu("Debug: Print Grid")]
        public void DebugPrintGrid()
        {
            if (_isDisposed || _data == null || _grid == null) return;

            Debug.Log($"=== GRID {_data.Width}x{_data.Height} ===");
            for (int y = _data.Height - 1; y >= 0; y--)
            {
                var row = "";
                for (int x = 0; x < _data.Width; x++)
                    row += _grid[x, y] == null ? "[ ]" : $"[{_grid[x, y]?.PrefabID}]";
                Debug.Log(row);
            }
            Debug.Log($"Weight: {CurrentWeightKg:F1}kg | Items: {_itemCache.Count}");
        }
        #endregion
    }
}