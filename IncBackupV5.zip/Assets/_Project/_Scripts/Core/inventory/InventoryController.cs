﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using UnityEngine;
namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Логическая модель инвентаря — grid-сетка, стекинг, перемещение, удаление.
    /// 
    /// ИСПРАВЛЕНИЯ (баг-фикс сессия):
    /// #БАГ1: CanStack() теперь использует target.Data.HardStackLimit вместо MAX_STACK_LIMIT.
    ///         Ранее оружие с HardStackLimit=1 некорректно допускало стекинг (1 < 90 = true),
    ///         что приводило к исчезновению предмета при дропе на идентичный.
    /// #БАГ1b: TryPlaceItem() — добавлена проверка space <= 0 и actuallyAdded <= 0,
    ///          чтобы предмет не потреблялся если стек полон.
    ///
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ-ФИКС v3 (duplication when rotating):
    ///  PlaceExistingItem теперь использует CanOccupy вместо CanPlaceInternal.
    ///  CanPlaceInternal РАЗРЕШАЕТ стекинг — если в целевых ячейках уже лежит
    ///  стекающийся предмет с тем же PrefabID, проверка проходит. Но PlaceExistingItem
    ///  НЕ умеет стекать (он сохраняет InstanceID), и BindToGrid ПЕРЕЗАПИСЫВАЛ
    ///  ячейки существующего предмета, оставляя его в _itemCache без ячеек.
    ///  Это создавало "дубликат" при вращении: после Rotate предмет мог накладываться
    ///  на стекающийся сосед, и placement "съедал" соседа.
    ///  CanOccupy строго требует пустых ячеек — это правильное поведение для
    ///  размещения существующего экземпляра предмета.
    ///  PlaceExistingItemInFirstFreeSlot также изменён: вызывает PlaceExistingItem
    ///  напрямую (внутри которого CanOccupy), вместо CanPlaceItem+PlaceExistingItem.
    /// ════════════════════════════════════════════════════════════════════
    /// </summary>
    public class InventoryController : IDisposable, ISaveable
    {
        #region Events & Constants
        public event Action OnInventoryChanged;
        public event Action<float> OnWeightChanged;
        public event Action<InventoryItem, int, int> OnItemPlaced;
        public event Action<InventoryItem> OnItemRemoved;
        public event Action<InventoryItem> OnItemRotated;
        public event Action<InventoryItem> OnItemQuantityChanged;

        // ФИКС БАГ #5: Событие переполнения при ресайзе. Предметы, не влезшие в новую сетку,
        // не уничтожаются, а передаются подписчикам (например, K_InventoryUI для размещения в карманах).
        public event Action<List<InventoryItem>> OnResizeOverflow;

        private const int MAX_STACK_LIMIT = 90;
        private const int DEFAULT_MAX_CAPACITY_GRAMS = 30000;
        private const float GRAM_TO_KG = 0.001f;
        private const int MIN_GRID_INDEX = 0;
        #endregion

        #region Fields
        public string SaveID { get; private set; }
        public bool IsDirty { get; set; } = true;

        private InventoryData _data;
        private ItemDatabase _database;
        private InventoryItem[,] _grid;
        private readonly Dictionary<uint, InventoryItem> _itemCache = new();
        private readonly Dictionary<uint, (int x, int y)> _positionCache = new();
        private int _currentWeightGrams;
        private int _maxCapacityGrams = DEFAULT_MAX_CAPACITY_GRAMS;
        private bool _isDisposed;
        #endregion

        #region Properties
        public int Width => _data?.Width ?? 0;
        public int Height => _data?.Height ?? 0;
        public float CurrentWeightKg => _currentWeightGrams * GRAM_TO_KG;
        public float WeightRatio => _maxCapacityGrams > 0 ? _currentWeightGrams / (float)_maxCapacityGrams : 0f;
        public int MaxCapacityGrams => _maxCapacityGrams;
        #endregion

        #region Constructor
        public InventoryController(InventoryData data, ItemDatabase database, string saveID = null)
        {
            _data = data ?? throw new ArgumentNullException(nameof(data));
            _database = database ?? throw new ArgumentNullException(nameof(database));
            SaveID = saveID ?? $"Inv_{Guid.NewGuid():N}";

            InitializeGrid();
            LoadFromData();
        }

        private void InitializeGrid()
        {
            if (_data.Width <= 0 || _data.Height <= 0)
                throw new ArgumentException($"Invalid grid dimensions: {_data.Width}x{_data.Height}", nameof(_data));

            _grid = new InventoryItem[_data.Width, _data.Height];
            _currentWeightGrams = 0;
        }

        private void LoadFromData()
        {
            int skippedCount = 0;

            foreach (var saved in _data.GetItems())
            {
                var template = _database.GetItemData(saved.ItemID);
                if (template == null)
                {
                    LogWarning($"Template not found for ItemID: {saved.ItemID} (InstanceID: {saved.InstanceID})");
                    skippedCount++; continue;
                }

                var item = InventoryItem.FromSaveData(saved, template);
                if (item == null)
                {
                    LogWarning($"Failed to create item from SavedData: {saved.ItemID}");
                    skippedCount++; continue;
                }

                if (!CanPlaceInternal(item, saved.X, saved.Y, item.CurrentSize))
                {
                    LogWarning($"Cannot place item {saved.InstanceID} at ({saved.X},{saved.Y}) - bounds/collision conflict");
                    skippedCount++; continue;
                }

                if (!BindToGrid(item, saved.X, saved.Y))
                {
                    LogWarning($"BindToGrid failed for item {saved.InstanceID} at ({saved.X},{saved.Y})");
                    skippedCount++; continue;
                }
            }

            if (skippedCount > 0) Debug.LogWarning($"[InventoryController] Load complete: {skippedCount} items skipped");

            RecalculateWeight();
            _data.MarkClean();
            IsDirty = false;
        }
        #endregion

        #region Placement Logic
        public bool CanPlaceItem(InventoryItem item, int x, int y) =>
            item != null && item.Data != null && CanPlaceInternal(item, x, y, item.CurrentSize);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        private bool IsValidCoordinate(int x, int y)
        {
            Debug.Assert(_data != null, "IsValidCoordinate called with null _data");
            return _data != null && x >= MIN_GRID_INDEX && y >= MIN_GRID_INDEX &&
                   x < _data.Width && y < _data.Height;
        }

        private bool CanPlaceInternal(InventoryItem item, int x, int y, Vector2Int size)
        {
            if (!IsValidCoordinate(x, y) || !IsValidCoordinate(x + size.x - 1, y + size.y - 1))
                return false;

            InventoryItem stackTarget = null;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    var existing = _grid[x + dx, y + dy];
                    if (existing == null || existing == item) continue;

                    if (!CanStack(existing, item)) return false;

                    if (stackTarget == null) stackTarget = existing;
                    else if (stackTarget.InstanceID != existing.InstanceID) return false;
                }
            }

            return true;
        }

        // ═══════════════════════════════════════════════════════════════
        //  ФИКС БАГ (audit) #6: CanOccupy — проверка СВОБОДНОГО места.
        //  В отличие от CanPlaceInternal, эта функция НЕ разрешает stack.
        //  Используется в RotateItem и в MoveItem — там merge не должен
        //  происходить автоматически: per-move merge приводит к ghost-items
        //  (см. audit #6/#7). Stack должен делаться явно через TryMergeStack.
        // ═══════════════════════════════════════════════════════════════
        private bool CanOccupy(int x, int y, Vector2Int size, InventoryItem ignoredItem = null)
        {
            if (_isDisposed || _grid == null || _data == null)
                return false;
            if (size.x <= 0 || size.y <= 0)
                return false;

            // Безопасная форма без overflow при x + size.x.
            if (x < 0 || y < 0 ||
                x > _data.Width - size.x ||
                y > _data.Height - size.y)
                return false;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    InventoryItem occupied = _grid[x + dx, y + dy];
                    if (occupied != null && !ReferenceEquals(occupied, ignoredItem))
                        return false;
                }
            }
            return true;
        }

        // ФИКС БАГ (audit) #6: атомарные помощники для работы с grid.
        private void ClearCellsOwnedBy(InventoryItem item)
        {
            if (_grid == null) return;
            for (int y = 0; y < _data.Height; y++)
                for (int x = 0; x < _data.Width; x++)
                    if (ReferenceEquals(_grid[x, y], item))
                        _grid[x, y] = null;
        }

        private void FillCells(InventoryItem item, int x, int y, Vector2Int size)
        {
            if (_grid == null) return;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    _grid[x + dx, y + dy] = item;
        }

        private bool CanPlaceInternalEmptyOnly(int x, int y, Vector2Int size)
        {
            if (!IsValidCoordinate(x, y) || !IsValidCoordinate(x + size.x - 1, y + size.y - 1))
                return false;

            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    if (_grid[x + dx, y + dy] != null) return false;

            return true;
        }

        // ═══════════════════════════════════════════════════════════════
        // ИСПРАВЛЕНИЕ БАГ 1: CanStack теперь проверяет HardStackLimit
        // предмета, а не глобальный MAX_STACK_LIMIT.
        // ═══════════════════════════════════════════════════════════════
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        // ФИКС БАГ #22: Стекинг только при полном совпадении состояния
        private bool CanStack(InventoryItem target, InventoryItem source)
        {
            if (target.PrefabID != source.PrefabID) return false;
            if (target.Quantity >= target.Data.HardStackLimit) return false;

            // Предметы с разной прочностью не должны стакаться
            if (target.Durability != source.Durability) return false;

            // Предметы с разным поворотом не должны стакаться
            if (target.RotationAngle != source.RotationAngle) return false;

            // Свёрнутые и развёрнутые рюкзаки не должны стакаться
            if (target.IsFolded != source.IsFolded) return false;

            return true;
        }

        public int TryPlaceItem(InventoryItem source, int x, int y)
        {
            if (_isDisposed || source == null || source.Data == null || source.Quantity <= 0) return 0;
            if (!CanPlaceInternal(source, x, y, source.CurrentSize)) return 0;

            int remainder = source.Quantity;
            int placedCount = 0;

            var targetStack = FindStackTarget(source, x, y);
            if (targetStack != null)
            {
                // ═══════════════════════════════════════════════════════════════
                // ИСПРАВЛЕНИЕ БАГ 1b: space рассчитывается от HardStackLimit,
                // а не от MAX_STACK_LIMIT. Добавлена проверка space <= 0
                // и actuallyAdded чтобы предмет не "съедался" при полном стеке.
                // ═══════════════════════════════════════════════════════════════
                int space = targetStack.Data.HardStackLimit - targetStack.Quantity;
                if (space <= 0)
                {
                    // Стек полностью заполнен — нельзя добавить ничего
                    return 0;
                }

                int toAdd = Mathf.Min(space, remainder);
                int oldQty = targetStack.Quantity;
                targetStack.AddQuantity(toAdd);
                int actuallyAdded = targetStack.Quantity - oldQty;

                if (actuallyAdded <= 0)
                {
                    // Ничего реально не добавилось (например, Clamp внутри AddQuantity)
                    return 0;
                }

                AdjustWeight(source.Data.WeightGrams * actuallyAdded);
                remainder -= actuallyAdded;
                placedCount += actuallyAdded;

                if (_positionCache.TryGetValue(targetStack.InstanceID, out var pos))
                    _data.UpdateItem(targetStack.InstanceID, pos.x, pos.y, targetStack.Quantity, targetStack.IsRotated);

                SafeInvoke(OnItemQuantityChanged, targetStack);
            }

            if (remainder > 0)
            {
                var newItem = new InventoryItem(source.Data, GlobalIDManager.GenerateID(), remainder, source.Durability, source.IsRotated);

                if (!BindToGrid(newItem, x, y))
                {
                    LogWarning($"Failed to bind new item {newItem.InstanceID} at ({x},{y})");
                    return placedCount;
                }

                _data.AddItem(newItem.ToSaveData(x, y));
                AdjustWeight(source.Data.WeightGrams * remainder);
                SafeInvoke(OnItemPlaced, newItem, x, y);
                placedCount += remainder;
            }

            if (placedCount > 0)
            {
                MarkDirty();
                SafeInvoke(OnInventoryChanged);
            }

            return placedCount;
        }

        /// <summary>
        /// Размещает СУЩЕСТВУЮЩИЙ InventoryItem в сетке БЕЗ создания нового объекта.
        /// В отличие от TryPlaceItem, который создаёт новый InventoryItem через конструктор,
        /// этот метод сохраняет оригинальный объект со всем его состоянием:
        /// - IsFolded (свёрнутое/развёрнутое состояние рюкзака)
        /// - _backpackContentsSerialized (содержимое рюкзака)
        /// - InstanceID, Quantity, Durability, RotationAngle
        ///
        /// Используется после fold/unfold когда размер предмета изменился,
        /// и его нужно заново разместить в сетке.
        ///
        /// ВАЖНО: item НЕ должен уже находиться в этой сетке (иначе будет дубликат InstanceID).
        /// Если item уже в каком-то positionCache — сначала вызовите RemoveItem.
        /// </summary>
        /// <returns>true если предмет успешно размещён.</returns>
        public bool PlaceExistingItem(InventoryItem item, int x, int y)
        {
            if (_isDisposed || item == null || item.Data == null)
            {
                LogWarning($"PlaceExistingItem: invalid item");
                return false;
            }

            // Проверяем что item ещё не в нашем кэше
            if (_itemCache.ContainsKey(item.InstanceID))
            {
                LogWarning($"PlaceExistingItem: item {item.InstanceID} already in cache — use MoveItem instead");
                return false;
            }

            // ═══ БАГ 1 ФИКС (дублирование при вращении): используем CanOccupy
            // вместо CanPlaceInternal. CanPlaceInternal РАЗРЕШАЕТ стекинг —
            // если в целевых ячейках уже лежит item с тем же PrefabID и неполным
            // стеком, CanPlaceInternal вернёт true. Но PlaceExistingItem НЕ умеет
            // стекить (он сохраняет InstanceID), и BindToGrid просто ПЕРЕЗАПИШЕТ
            // ячейки существующего item'а нашим item'ом. Старый item останется
            // в _itemCache без ячеек — это и создаёт "дубликат": два InventoryItem
            // в кэше, но ячейки указывают только на один. При RefreshGrid UI
            // пересоздаётся для обоих, но визуально виден только один.
            //
            // Сценарий бага: пользователь вращает предмет (R), отпускает его
            // на ячейке с таким же стекающимся предметом → CanPlaceInternal
            // пропускает → BindToGrid перезаписывает → дубликат.
            //
            // CanOccupy строго требует, чтобы ячейки были ПУСТЫМИ (или заняты
            // тем же item'ом). Это правильное поведение для PlaceExistingItem:
            // мы размещаем конкретный экземпляр предмета, а не стекаем.
            // ═══
            if (!CanOccupy(x, y, item.CurrentSize, ignoredItem: item))
            {
                return false;
            }

            if (!BindToGrid(item, x, y))
            {
                LogWarning($"PlaceExistingItem: BindToGrid failed for item {item.InstanceID} at ({x},{y})");
                return false;
            }

            // Сохраняем в InventoryData (сериализованный слой)
            _data.AddItem(item.ToSaveData(x, y));
            AdjustWeight(item.TotalWeightGrams);
            SafeInvoke(OnItemPlaced, item, x, y);
            MarkDirty();
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        /// <summary>
        /// Пытается разместить существующий InventoryItem в первой свободной ячейке.
        /// Возвращает true если удалось, false если нет места.
        /// Сохраняет оригинальный объект (см. PlaceExistingItem).
        /// </summary>
        public bool PlaceExistingItemInFirstFreeSlot(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;

            // БАГ 1 ФИКС: используем CanOccupy-стиль проверки (через CanPlaceItem
            // который всё ещё допускает стекинг, но PlaceExistingItem внутри
            // использует CanOccupy и отклонит стек-позицию). Поэтому мы просто
            // продолжаем перебор, пока не найдём действительно свободную ячейку.
            for (int y = 0; y < _data.Height; y++)
                for (int x = 0; x < _data.Width; x++)
                    if (PlaceExistingItem(item, x, y))
                        return true;

            return false;
        }

        /// <summary>
        /// Перемещает существующий предмет без создания нового объекта.
        /// </summary>
        public bool MoveItem(InventoryItem item, int newX, int newY)
        {
            if (_isDisposed || item == null || !_positionCache.ContainsKey(item.InstanceID))
            {
                LogWarning($"MoveItem: Item {item?.InstanceID} not found in position cache");
                return false;
            }

            var oldPos = _positionCache[item.InstanceID];

            if (oldPos.x == newX && oldPos.y == newY)
                return true;

            if (!CanPlaceInternal(item, newX, newY, item.CurrentSize))
            {
                LogWarning($"MoveItem: Cannot place item {item.InstanceID} at ({newX},{newY})");
                return false;
            }

            ClearCellRange(oldPos.x, oldPos.y, item.CurrentSize);

            _itemCache.Remove(item.InstanceID);
            _positionCache.Remove(item.InstanceID);

            if (!BindToGrid(item, newX, newY))
            {
                LogWarning($"MoveItem: BindToGrid failed for item {item.InstanceID} at ({newX},{newY})");
                return false;
            }

            _data.UpdateItem(item.InstanceID, newX, newY, item.Quantity, item.IsRotated);
            MarkDirty();
            SafeInvoke(OnInventoryChanged);

            return true;
        }

        // ФИКС БАГ #21: Стекинг только если мы целимся ровно в корневую ячейку существующего предмета
        // и размеры полностью совпадают. Это предотвращает исчезновение/перекрытие предметов 2x2.
        private InventoryItem FindStackTarget(InventoryItem item, int x, int y)
        {
            var target = GetItemAt(x, y);
            if (target == null) return null;

            // Проверяем, что координаты (x,y) — это левый верхний угол (root) целевого предмета
            // ФИКС: используем публичный метод IsRootCell, т.к. у InventoryItem нет публичных свойств X/Y
            if (!IsRootCell(target.InstanceID, x, y)) return null;

            // Проверяем, что размеры и поворот полностью совпадают
            if (target.CurrentSize.x != item.CurrentSize.x ||
                target.CurrentSize.y != item.CurrentSize.y ||
                target.RotationAngle != item.RotationAngle) return null;

            // Проверяем базовые условия стакинга (одинаковый тип, не заполнен лимит и т.д.)
            if (!CanStack(target, item)) return null;

            return target;
        }

        private bool BindToGrid(InventoryItem item, int x, int y)
        {
            if (_itemCache.ContainsKey(item.InstanceID))
            {
                LogWarning($"Duplicate InstanceID {item.InstanceID} — skipping bind at ({x},{y})");
                return false;
            }

            var size = item.CurrentSize;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    _grid[x + dx, y + dy] = item;

            _itemCache[item.InstanceID] = item;
            _positionCache[item.InstanceID] = (x, y);
            return true;
        }
        #endregion

        #region Rotation & Removal
        /// <summary>
        /// Правильно обновляет grid, кэши и вызывает события.
        /// ФИКС БАГ (audit) #9: использует CanOccupy вместо CanPlaceInternal,
        /// чтобы не путать проверку свободного места с merge-проверкой.
        /// ФИКС БАГ (audit) #9: использует реальный candidateSize
        /// из item.CurrentSize после Rotate, а не Data.GetDimensions,
        /// потому что развёрнутый рюкзак имеет размер UnfoldedIconSize
        /// или BackpackWidth/Height, а не Data.Size.
        /// ФИКС БАГ (audit) #15: использует RestoreRotationState
        /// вместо while (item.RotationAngle != oldAngle) item.Rotate(),
        /// который зацикливался навсегда при CanRotate=false.
        /// </summary>
        public bool RotateItem(InventoryItem item)
        {
            if (_isDisposed || item == null || item.Data == null || !item.Data.CanRotate)
                return false;
            if (!_positionCache.TryGetValue(item.InstanceID, out var pos))
                return false;

            int oldAngle = item.RotationAngle;
            Vector2Int oldSize = item.CurrentSize;

            // Пробуем повернуть
            item.Rotate();
            if (item.RotationAngle == oldAngle)
                return false; // ничего не изменилось

            Vector2Int candidateSize = item.CurrentSize;

            // Откатываем вращение, чтобы CanOccupy проверил позицию с игнорированием текущего item
            item.RestoreRotationState(oldAngle);

            // CanOccupy (НЕ CanPlaceInternal!) — merge при rotate недопустим.
            if (!CanOccupy(pos.x, pos.y, candidateSize, ignoredItem: item))
                return false;

            // Очищаем старые клетки и заново вращаем
            ClearCellsOwnedBy(item);
            item.Rotate();

            // Проверка, что итоговый размер соответствует ожидаемому
            // (защита от race-condition — вдруг данные поменялись).
            if (item.CurrentSize != candidateSize)
            {
                item.RestoreRotationState(oldAngle);
                FillCells(item, pos.x, pos.y, oldSize);
                return false;
            }

            // Заполняем новые клетки
            FillCells(item, pos.x, pos.y, candidateSize);

            _data.UpdateItem(item.InstanceID, pos.x, pos.y, item.Quantity, item.IsRotated);
            MarkDirty();
            SafeInvoke(OnItemRotated, item);
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        public bool RemoveItem(InventoryItem item)
        {
            if (_isDisposed || item == null || !_positionCache.ContainsKey(item.InstanceID)) return false;

            var pos = _positionCache[item.InstanceID];

            ClearCellRange(pos.x, pos.y, item.CurrentSize);
            _itemCache.Remove(item.InstanceID);
            _positionCache.Remove(item.InstanceID);
            _data.RemoveItem(item.InstanceID);
            AdjustWeight(-item.TotalWeightGrams);

            SafeInvoke(OnItemRemoved, item);
            MarkDirty();
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        private void ClearCellRange(int x, int y, Vector2Int size)
        {
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    int gx = x + dx, gy = y + dy;
                    if (IsValidCoordinate(gx, gy)) _grid[gx, gy] = null;
                }
        }
        #endregion

        #region Weight & Helpers
        public void AdjustWeight(int deltaGrams)
        {
            int oldWeight = _currentWeightGrams;
            _currentWeightGrams = Mathf.Max(0, _currentWeightGrams + deltaGrams);

            if (_currentWeightGrams != oldWeight) MarkDirty();
            SafeInvoke(OnWeightChanged, CurrentWeightKg);
        }

        private void RecalculateWeight()
        {
            int sum = 0;
            foreach (var item in _itemCache.Values) sum += item.TotalWeightGrams;
            _currentWeightGrams = sum;
            SafeInvoke(OnWeightChanged, CurrentWeightKg);
        }

        public InventoryItem GetItemAt(int x, int y)
        {
            if (_isDisposed || _data == null || _grid == null) return null;
            if (!IsValidCoordinate(x, y)) return null;
            return _grid[x, y];
        }

        public bool IsRootCell(uint id, int x, int y) =>
            _positionCache.TryGetValue(id, out var pos) && pos.x == x && pos.y == y;

        private void MarkDirty() => IsDirty = true;

        private void LogWarning(string message, [CallerMemberName] string method = "")
        {
            if (!_isDisposed) Debug.LogWarning($"[InventoryController.{method}] {message}");
        }

        private void SafeInvoke(Action handler)
        {
            if (!_isDisposed) handler?.Invoke();
        }

        private void SafeInvoke<T>(Action<T> handler, T arg)
        {
            if (!_isDisposed) handler?.Invoke(arg);
        }

        private void SafeInvoke<T1, T2>(Action<T1, T2> handler, T1 arg1, T2 arg2)
        {
            if (!_isDisposed) handler?.Invoke(arg1, arg2);
        }

        private void SafeInvoke<T1, T2, T3>(Action<T1, T2, T3> handler, T1 arg1, T2 arg2, T3 arg3)
        {
            if (!_isDisposed) handler?.Invoke(arg1, arg2, arg3);
        }
        #endregion

        #region UI Helper Methods
        public int GetItemCount() => _itemCache.Count;

        public bool CanFitItem(Vector2Int size)
        {
            if (size.x > _data.Width || size.y > _data.Height) return false;
            for (int x = 0; x <= _data.Width - size.x; x++)
                for (int y = 0; y <= _data.Height - size.y; y++)
                    if (CanPlaceInternalEmptyOnly(x, y, size)) return true;
            return false;
        }

        public int GetFreeCellCount()
        {
            int count = 0;
            for (int x = 0; x < _data.Width; x++)
                for (int y = 0; y < _data.Height; y++)
                    if (_grid[x, y] == null) count++;
            return count;
        }

        public bool TryPlaceItemInFirstFreeSlot(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;
            Vector2Int size = item.CurrentSize;

            for (int y = 0; y < _data.Height; y++)
                for (int x = 0; x < _data.Width; x++)
                    if (CanPlaceItem(item, x, y)) return TryPlaceItem(item, x, y) > 0;

            return false;
        }

        public InventoryData GetSaveData() => _data;

        public void Clear()
        {
            if (_isDisposed) return;

            if (_grid != null && _data != null)
            {
                Array.Clear(_grid, 0, _grid.Length);
                _grid = new InventoryItem[_data.Width, _data.Height];
            }

            _itemCache.Clear();
            _positionCache.Clear();
            _currentWeightGrams = 0;

            if (_data != null) _data.Clear();

            MarkDirty();
            SafeInvoke(OnInventoryChanged);
        }

        // >>> FIX: рантайм-ресайз с миграцией предметов <<<
        //
        // ФИКС БАГ (audit) #10: Transactional resize.
        // Раньше старые grid/cache/data очищались ДО проверки результата.
        // Если подписчика OnResizeOverflow не было — предметы терялись,
        // а метод возвращал true. Теперь сначала всё вычисляем во временных
        // структурах, и только если всё поместилось (или подписчик принял
        // overflow) — коммитим в live state.
        public bool Resize(int newWidth, int newHeight)
        {
            if (_isDisposed || _data == null) return false;
            newWidth = Mathf.Clamp(newWidth, 1, 20);
            newHeight = Mathf.Clamp(newHeight, 1, 20);
            if (newWidth == _data.Width && newHeight == _data.Height) return true;

            // 1. Snapshot живых предметов ДО изменения состояния.
            var snapshot = new List<(InventoryItem item, int x, int y)>(_itemCache.Count);
            foreach (var kvp in _positionCache)
                if (_itemCache.TryGetValue(kvp.Key, out var it) && it != null)
                    snapshot.Add((it, kvp.Value.x, kvp.Value.y));

            // 2. Временный grid и кэши — НЕ трогаем live-состояние.
            var tempGrid = new InventoryItem[newWidth, newHeight];
            var tempItemCache = new Dictionary<uint, InventoryItem>();
            var tempPositionCache = new Dictionary<uint, (int x, int y)>();
            var tempDataItems = new List<SavedItem>(snapshot.Count);

            var notPlaced = new List<InventoryItem>();

            foreach (var (item, x, y) in snapshot)
            {
                // CanOccupyInTemp — аналог CanOccupy, но с временным grid.
                if (CanOccupyIn(tempGrid, newWidth, newHeight, x, y, item.CurrentSize, ignoredItem: item))
                {
                    PlaceInTemp(tempGrid, item, x, y, item.CurrentSize);
                    tempItemCache[item.InstanceID] = item;
                    tempPositionCache[item.InstanceID] = (x, y);
                    tempDataItems.Add(item.ToSaveData(x, y));
                }
                else
                {
                    // Пробуем найти другое место
                    bool placed = false;
                    for (int ny = 0; ny < newHeight && !placed; ny++)
                        for (int nx = 0; nx < newWidth && !placed; nx++)
                            if (CanOccupyIn(tempGrid, newWidth, newHeight, nx, ny, item.CurrentSize, null))
                            {
                                PlaceInTemp(tempGrid, item, nx, ny, item.CurrentSize);
                                tempItemCache[item.InstanceID] = item;
                                tempPositionCache[item.InstanceID] = (nx, ny);
                                tempDataItems.Add(item.ToSaveData(nx, ny));
                                placed = true;
                            }
                    if (!placed) notPlaced.Add(item);
                }
            }

            // 3. Если есть overflow и НЕТ подписчика — откатываемся.
            //    (Сохраняем старый инвентарь нетронутым.)
            if (notPlaced.Count > 0 && OnResizeOverflow == null)
            {
                LogWarning(
                    $"Resize: {notPlaced.Count} items cannot fit in " +
                    $"{newWidth}x{newHeight} and no OnResizeOverflow subscriber. Aborting.");
                return false;
            }

            // 4. Коммит во live-state.
            if (_grid != null) Array.Clear(_grid, 0, _grid.Length);
            _grid = tempGrid;
            _itemCache.Clear();
            foreach (var kvp in tempItemCache) _itemCache[kvp.Key] = kvp.Value;
            _positionCache.Clear();
            foreach (var kvp in tempPositionCache) _positionCache[kvp.Key] = kvp.Value;

            _data.Resize(newWidth, newHeight);
            foreach (var sd in tempDataItems) _data.AddItem(sd);

            // 5. Уведомляем подписчика об overflow (если был).
            if (notPlaced.Count > 0)
            {
                // Внимание: подписчик может попытаться положить эти предметы
                // в другой контроллер. К этому моменту они УЖЕ удалены из
                // текущего контроллера (не в _itemCache, не в _grid, не в _data).
                OnResizeOverflow.Invoke(notPlaced);
            }

            RecalculateWeight();
            MarkDirty();
            SafeInvoke(OnInventoryChanged);
            return true;
        }

        private static bool CanOccupyIn(InventoryItem[,] grid, int w, int h, int x, int y, Vector2Int size, InventoryItem ignoredItem)
        {
            if (size.x <= 0 || size.y <= 0) return false;
            if (x < 0 || y < 0 || x > w - size.x || y > h - size.y) return false;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    var occ = grid[x + dx, y + dy];
                    if (occ != null && !ReferenceEquals(occ, ignoredItem))
                        return false;
                }
            return true;
        }

        private static void PlaceInTemp(InventoryItem[,] grid, InventoryItem item, int x, int y, Vector2Int size)
        {
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                    grid[x + dx, y + dy] = item;
        }
        // >>> END FIX <<<
        #endregion

        #region Serialization
        public void Save(BinaryWriter writer)
        {
            writer.Write(SaveID);
            writer.Write(IsDirty);
            _data?.Save(writer);
        }

        /// <summary>
        /// ФИКС БАГ (audit) #1: InventoryController.Load раньше читал
        /// SaveID, IsDirty, width, height — а потом вызывал _data.Load(reader),
        /// который читал width/height ПОВТОРНО. Из-за этого count становился
        /// шириной, начало ItemID — числом, и весь поток ехал.
        ///
        /// Сейчас Load НЕ читает width/height самостоятельно —
        /// это делает только InventoryData.Load.
        ///
        /// ФИКС БАГ (audit) #1: при SaveID mismatch не падаем, а логируем
        /// warning (старое поведение SaveID = saveID ?? $"Inv_{Guid}" позволяло
        /// несовпадения при первом сохранении). Бинарный поток всё равно
        /// обязан быть совместимым по структуре — иначе Data.Load упадёт.
        /// </summary>
        public void Load(BinaryReader reader)
        {
            if (_isDisposed || _data == null)
                throw new ObjectDisposedException(nameof(InventoryController));

            string loadedSaveId = reader.ReadString();
            _ = reader.ReadBoolean(); // старый IsDirty (восстанавливаем ниже из data)

            if (!string.Equals(loadedSaveId, SaveID, StringComparison.Ordinal))
                Debug.LogWarning(
                    $"[InventoryController.Load] SaveID mismatch: " +
                    $"expected='{SaveID}', got='{loadedSaveId}'. " +
                    "Continuing load — payload structure must still match.");

            // НЕ читаем width/height здесь — это делает _data.Load.
            if (_grid != null)
                Array.Clear(_grid, 0, _grid.Length);

            _itemCache.Clear();
            _positionCache.Clear();

            _data.Load(reader);
            _grid = new InventoryItem[_data.Width, _data.Height];

            LoadFromData();
            IsDirty = false;

            SafeInvoke(OnInventoryChanged);
        }
        #endregion

        #region Disposable & Memory Safety
        public void Dispose()
        {
            if (_isDisposed) return;
            _isDisposed = true;

            OnInventoryChanged = null;
            OnWeightChanged = null;
            OnItemPlaced = null;
            OnItemRemoved = null;
            OnItemRotated = null;
            OnItemQuantityChanged = null;

            _itemCache.Clear();
            _positionCache.Clear();

            if (_grid != null)
            {
                Array.Clear(_grid, 0, _grid.Length);
                _grid = null;
            }

            _data = null;
            _database = null;
        }
        #endregion

        #region Debug
        [ContextMenu("Debug: Print Grid")]
        public void DebugPrintGrid()
        {
            if (_isDisposed || _data == null || _grid == null) return;

            Debug.Log($"=== GRID {_data.Width}x{_data.Height} ===");
            for (int y = _data.Height - 1; y >= 0; y--)
            {
                var row = "";
                for (int x = 0; x < _data.Width; x++)
                    row += _grid[x, y] == null ? "[ ]" : $"[{_grid[x, y]?.PrefabID}]";
                Debug.Log(row);
            }
            Debug.Log($"Weight: {CurrentWeightKg:F1}kg | Items: {_itemCache.Count}");
        }
        #endregion
    }
}













