﻿// === NEW FILE: InventoryTransactionService.cs ===
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// БЛОК 2 + БЛОК 3: Транзакционный координатор операций над инвентарём.
    ///
    /// Паттерн Command (атомарная транзакция):
    ///   1. Snapshot  — фиксируем состояние задействованных предметов
    ///                  (где они лежали, в каком rotation/fold состоянии).
    ///   2. Validate  — проверяем целевые позиции через InventoryValidationService
    ///                  (Type Match, Grid Space, Nesting).
    ///   3. Execute   — удаляем из старых мест, размещаем в новых. Каждый
    ///                  шаг записывается в _placements для отката.
    ///   4. Rollback  — при любой ошибке отменяем размещения в обратном
    ///                  порядке и восстанавливаем снапшоты.
    ///
    /// Защита от спама: флаг _isTransactionActive блокирует повторный вход,
    /// пока текущая транзакция не завершена (commit или rollback).
    ///
    /// Все операции синхронные, в главном потоке, за один кадр.
    /// Никаких Task, async/await, корутин.
    ///
    /// АРХИТЕКТУРА:
    /// - InventoryTransactionService — координатор (этот файл).
    /// - InventoryValidationService  — чистые функции валидации (Block 1).
    /// - ItemSnapshot                — readonly struct, точка восстановления.
    /// - K_InventoryUI               — UI-слой, отображает результат только
    ///                                  после успешного коммита (ForceRefresh).
    /// </summary>
    public class InventoryTransactionService : MonoBehaviour
    {
        // ═══════════════════════════════════════════════════════════════
        //  Singleton
        // ═══════════════════════════════════════════════════════════════

        private static InventoryTransactionService _instance;

        public static InventoryTransactionService Instance
        {
            get
            {
                if (_instance != null) return _instance;
                _instance = FindFirstObjectByType<InventoryTransactionService>();
                if (_instance == null)
                {
                    var go = new GameObject(nameof(InventoryTransactionService));
                    _instance = go.AddComponent<InventoryTransactionService>();
                }
                return _instance;
            }
        }

        private void Awake()
        {
            if (_instance != null && _instance != this)
            {
                Destroy(gameObject);
                return;
            }
            _instance = this;
        }

        private void OnDestroy()
        {
            if (_instance == this) _instance = null;
        }

        // ═══════════════════════════════════════════════════════════════
        //  Inspector / cached state
        // ═══════════════════════════════════════════════════════════════

        [Header("References (auto-found if empty)")]
        [SerializeField] private K_InventoryUI _inventoryUI;

        private readonly List<K_EquipmentSlotUI> _cachedSlots = new(8);
        private bool _slotsCached;

        // ═══════════════════════════════════════════════════════════════
        //  Transaction state
        // ═══════════════════════════════════════════════════════════════

        // Предохранитель от спама входом: пока true, новые транзакции отклоняются.
        private bool _isTransactionActive;

        // Снапшоты исходных положений предметов (для отката к исходному состоянию).
        private readonly List<ItemSnapshot> _snapshots = new(4);

        // Записи о выполненных размещениях (для отката шагов выполнения).
        private readonly List<PlacementRecord> _placements = new(4);

        private struct PlacementRecord
        {
            public readonly InventoryItem Item;
            public readonly InventoryController Controller; // null если в слоте экипировки
            public readonly int X;
            public readonly int Y;
            public readonly K_EquipmentSlotUI Slot; // null если в сетке
            public readonly bool InSlot;

            public PlacementRecord(InventoryItem item, InventoryController controller, int x, int y)
            {
                Item = item; Controller = controller; X = x; Y = y; Slot = null; InSlot = false;
            }

            public PlacementRecord(InventoryItem item, K_EquipmentSlotUI slot)
            {
                Item = item; Controller = null; X = 0; Y = 0; Slot = slot; InSlot = true;
            }
        }

        // ═══════════════════════════════════════════════════════════════
        //  Public API
        // ═══════════════════════════════════════════════════════════════

        /// <summary>True, если сейчас выполняется транзакция (предохранитель).</summary>
        public bool IsTransactionActive => _isTransactionActive;

        /// <summary>
        /// БЛОК 2: Drag &amp; Drop Swap — предмет A (в руке, из сетки)
        /// перетаскивается на предмет B (в сетке).
        ///
        /// Контракт: A уже изъят из своего origin-контроллера слоем K_InventoryUI
        /// (TryStartDrag выставил _dragItemRemoved=true). Нам нужно только:
        /// 1. Snapshot A (где был) и B (где есть).
        /// 2. Валидация: NestingCheck + GridSpaceCheck для обоих на новых местах.
        /// 3. Удалить B из ctrlB.
        /// 4. Разместить A на месте B (или FindFreeSpace).
        /// 5. Разместить B на старом месте A (или FindFreeSpace).
        /// 6. При ошибке на любом шаге — Rollback.
        /// </summary>
        public bool TrySwapItems(UI_Item draggedUI, UI_Item targetUI, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (_isTransactionActive)
            {
                errorMessage = "Transaction already active";
                return false;
            }

            if (draggedUI == null || targetUI == null)
            {
                errorMessage = "Null UI references";
                return false;
            }

            var itemA = draggedUI.Item;
            var itemB = targetUI.Item;

            if (itemA == null || itemB == null || itemA == itemB)
            {
                errorMessage = "Invalid items";
                return false;
            }

            EnsureInitialized();
            if (_inventoryUI == null)
            {
                errorMessage = "No inventory UI";
                return false;
            }

            var ctrlA = GetControllerForUI(draggedUI);
            var ctrlB = GetControllerForUI(targetUI);
            if (ctrlB == null)
            {
                errorMessage = "No controller for target";
                return false;
            }

            // A уже удалён из ctrlA (K_InventoryUI.TryStartDrag это сделал).
            // ctrlA может быть null, если A был из container-окна, которое уже закрыто.
            int ax = draggedUI.X, ay = draggedUI.Y;
            int bx = targetUI.X, by = targetUI.Y;
            GridType gridA = draggedUI.GridType;
            GridType gridB = targetUI.GridType;

            BeginTransaction();
            try
            {
                // 1. Snapshots
                _snapshots.Add(ItemSnapshot.FromGrid(itemA, ctrlA, gridA, ax, ay));
                _snapshots.Add(ItemSnapshot.FromGrid(itemB, ctrlB, gridB, bx, by));

                // 2. Validate (Nesting — для рюкзаков)
                if (!InventoryValidationService.NestingCheckBidirectional(itemA, itemB))
                {
                    errorMessage = "Nesting cycle: cannot swap backpack with its descendant";
                    Rollback();
                    return false;
                }

                // 3. Remove B from ctrlB (A уже удалён)
                if (!ctrlB.RemoveItem(itemB))
                {
                    errorMessage = "Failed to remove target item B";
                    Rollback();
                    return false;
                }

                // 4. Place A at B's position (or FindFreeSpace)
                if (!TryPlaceItemInController(itemA, ctrlB, bx, by, errorMessage: out var errA))
                {
                    errorMessage = "Item A: " + errA;
                    Rollback();
                    return false;
                }

                // 5. Place B at A's old position (or FindFreeSpace, incl. other player grids)
                if (ctrlA != null)
                {
                    if (!TryPlaceItemInPlayerGrids(itemB, ctrlA, ax, ay, out var errB))
                    {
                        errorMessage = "Item B: " + errB;
                        Rollback();
                        return false;
                    }
                }
                else
                {
                    // ctrlA == null (например, A был из контейнера, который закрылся).
                    // Пытаемся разместить B в любой сетке игрока.
                    if (!TryPlaceItemInAnyPlayerGrid(itemB, out var errB))
                    {
                        errorMessage = "Item B (no origin controller): " + errB;
                        Rollback();
                        return false;
                    }
                }

                Commit();
                _inventoryUI.ForceRefresh();
                return true;
            }
            catch (System.Exception ex)
            {
                Debug.LogException(ex);
                errorMessage = "Transaction exception: " + ex.Message;
                Rollback();
                return false;
            }
        }

        /// <summary>
        /// БЛОК 2 (variant): Drag &amp; Drop Swap — предмет A (в руке, из слота
        /// экипировки) перетаскивается на предмет B (в сетке).
        ///
        /// Контракт: A ещё находится в слоте экипировки (K_InventoryUI хранит
        /// _draggedFromEquipmentSlot / _draggedFromSlotItem). Нам нужно:
        /// 1. Snapshot A (слот) и B (сетка).
        /// 2. Валидация.
        /// 3. Удалить B из ctrlB.
        /// 4. Разместить A на месте B (или FindFreeSpace).
        /// 5. Разместить B в слоте A (slot.SetEquippedItem(B)).
        /// 6. При ошибке — Rollback. Финализация drag-сессии — на вызывающем.
        /// </summary>
        public bool TrySwapEquipmentWithGridItem(UI_Item targetUI, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (_isTransactionActive)
            {
                errorMessage = "Transaction already active";
                return false;
            }

            EnsureInitialized();
            if (_inventoryUI == null)
            {
                errorMessage = "No inventory UI";
                return false;
            }

            if (!_inventoryUI.IsDraggingFromEquipmentSlot)
            {
                errorMessage = "Not dragging from equipment slot";
                return false;
            }

            var itemA = _inventoryUI.DraggedFromSlotItem;
            if (itemA == null)
            {
                errorMessage = "No dragged slot item";
                return false;
            }

            var itemB = targetUI != null ? targetUI.Item : null;
            if (itemB == null)
            {
                errorMessage = "No target item";
                return false;
            }
            if (itemA == itemB)
            {
                errorMessage = "Same item";
                return false;
            }

            // Найти source slot. Приватное поле K_InventoryUI._draggedFromEquipmentSlot
            // не доступно напрямую, но мы можем найти слот по InstanceID itemA.
            K_EquipmentSlotUI sourceSlot = FindSlotHoldingItem(itemA);
            if (sourceSlot == null)
            {
                errorMessage = "Cannot find source equipment slot for dragged item";
                return false;
            }

            var ctrlB = GetControllerForUI(targetUI);
            if (ctrlB == null)
            {
                errorMessage = "No controller for target";
                return false;
            }

            int bx = targetUI.X, by = targetUI.Y;

            BeginTransaction();
            try
            {
                // 1. Snapshots
                _snapshots.Add(ItemSnapshot.FromEquipmentSlot(itemA, sourceSlot, sourceSlot.SlotType));
                _snapshots.Add(ItemSnapshot.FromGrid(itemB, ctrlB, targetUI.GridType, bx, by));

                // 2. Validate
                // TypeMatchCheck: itemA должен подходить к сетке (любой тип подходит к сетке — пропускаем).
                // NestingCheck: для рюкзаков.
                if (!InventoryValidationService.NestingCheckBidirectional(itemA, itemB))
                {
                    errorMessage = "Nesting cycle: cannot swap backpack with its descendant";
                    Rollback();
                    return false;
                }

                // 3. Remove B from ctrlB
                if (!ctrlB.RemoveItem(itemB))
                {
                    errorMessage = "Failed to remove target item B from grid";
                    Rollback();
                    return false;
                }

                // 4. Place A at B's position (or FindFreeSpace)
                if (!TryPlaceItemInController(itemA, ctrlB, bx, by, out var errA))
                {
                    errorMessage = "Item A (from slot): " + errA;
                    Rollback();
                    return false;
                }

                // 5. Place B in the equipment slot (replacing A)
                // Сначала убираем A из слота (если ещё там) — это безопасно, A уже в сетке.
                if (sourceSlot.EquippedItem == itemA)
                {
                    sourceSlot.SetEquippedItem(null);
                }
                sourceSlot.SetEquippedItem(itemB);
                _placements.Add(new PlacementRecord(itemB, sourceSlot));

                // 6. Backpack hooks
                if (sourceSlot.SlotType == EquipmentSlotType.Backpack)
                {
                    // A был рюкзаком, теперь B в слоте. Если B — НЕ рюкзак,
                    // старый рюкзак-слот больше не содержит рюкзак.
                    if (itemA.Data != null && itemA.Data.IsBackpack)
                        _inventoryUI.OnBackpackUnequipped();
                    if (itemB.Data != null && itemB.Data.IsBackpack)
                        _inventoryUI.OnBackpackEquipped(itemB);
                }

                Commit();

                // Финализация drag-сессии из слота экипировки (очищает стейт K_InventoryUI).
                _inventoryUI.FinalizeEquipSlotDrag();
                _inventoryUI.ForceRefresh();
                return true;
            }
            catch (System.Exception ex)
            {
                Debug.LogException(ex);
                errorMessage = "Transaction exception: " + ex.Message;
                Rollback();
                return false;
            }
        }

        /// <summary>
        /// БЛОК 3: Контекстное меню (ПКМ → Надеть).
        ///
        /// Предмет A находится в одной из сеток игрока. Определяется целевой
        /// слот экипировки. Если слот пуст — простой перенос. Если слот занят
        /// предметом B — инициируется транзакция свапа: A уходит в слот,
        /// B пытается встать на старое место A (с автопоиском через
        /// FindFreeSpace при нехватке места).
        ///
        /// Возвращает true при успехе. При неудаче — false, errorMessage
        /// содержит причину, предмет остаётся на месте.
        /// </summary>
        public bool TryEquipFromContextMenu(InventoryItem item, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (_isTransactionActive)
            {
                errorMessage = "Transaction already active";
                return false;
            }

            if (item == null || item.Data == null)
            {
                errorMessage = "Invalid item";
                return false;
            }

            EnsureInitialized();
            if (_inventoryUI == null)
            {
                errorMessage = "No inventory UI";
                return false;
            }

            // 1. Определить целевой тип слота
            if (!InventoryValidationService.TryDetermineEquipSlotType(item, out var slotType))
            {
                errorMessage = "Item cannot be equipped (no matching slot type)";
                return false;
            }

            // 2. Type Match Check
            if (!InventoryValidationService.TypeMatchCheck(item, slotType))
            {
                errorMessage = $"Type mismatch: item '{item.Data.DisplayName}' cannot go to slot {slotType}";
                return false;
            }

            // 3. Найти подходящий слот (предпочитаем пустой)
            var targetSlot = GetEquipSlot(slotType);
            if (targetSlot == null)
            {
                errorMessage = $"No slot of type {slotType} found in scene";
                return false;
            }

            // 4. Найти текущее положение предмета A в сетке
            var (originGrid, ax, ay) = FindItemLocationInPlayerGrids(item);
            if (originGrid == null)
            {
                errorMessage = "Item not found in any player grid (already equipped or in container?)";
                return false;
            }

            var originCtrl = _inventoryUI.GetControllerForGrid(originGrid.Value);
            if (originCtrl == null)
            {
                errorMessage = "No origin controller";
                return false;
            }

            BeginTransaction();
            try
            {
                // 5. Snapshot A
                _snapshots.Add(ItemSnapshot.FromGrid(item, originCtrl, originGrid.Value, ax, ay));

                // 6. Если слот занят — snapshot B и проверка nesting
                InventoryItem oldItemB = targetSlot.IsOccupied ? targetSlot.EquippedItem : null;
                if (oldItemB != null)
                {
                    _snapshots.Add(ItemSnapshot.FromEquipmentSlot(oldItemB, targetSlot, targetSlot.SlotType));

                    if (!InventoryValidationService.NestingCheckBidirectional(item, oldItemB))
                    {
                        errorMessage = "Nesting cycle: cannot swap backpack with its descendant";
                        Rollback();
                        return false;
                    }
                }

                // 7. Удалить A из сетки
                if (!originCtrl.RemoveItem(item))
                {
                    errorMessage = "Failed to remove item A from origin grid";
                    Rollback();
                    return false;
                }

                // 8. Если слот занят B — разместить B на старом месте A
                if (oldItemB != null)
                {
                    // B наследует разворот A (как в OnEquipmentSlotDrop)
                    oldItemB.RestoreRotationState(item.RotationAngle);

                    if (!TryPlaceItemInPlayerGrids(oldItemB, originCtrl, ax, ay, out var errB))
                    {
                        errorMessage = "Cannot place old equipped item: " + errB;
                        Rollback();
                        return false;
                    }

                    // Очищаем слот (B теперь в сетке)
                    if (targetSlot.EquippedItem == oldItemB)
                        targetSlot.SetEquippedItem(null);
                }

                // 9. Экипировать A в слот
                targetSlot.SetEquippedItem(item);
                _placements.Add(new PlacementRecord(item, targetSlot));

                // 10. Backpack hooks
                if (slotType == EquipmentSlotType.Backpack)
                {
                    if (item.Data.IsBackpack)
                        _inventoryUI.OnBackpackEquipped(item);

                    if (oldItemB != null && oldItemB.Data != null && oldItemB.Data.IsBackpack)
                        _inventoryUI.OnBackpackUnequipped();
                }

                Commit();
                _inventoryUI.ForceRefresh();
                return true;
            }
            catch (System.Exception ex)
            {
                Debug.LogException(ex);
                errorMessage = "Transaction exception: " + ex.Message;
                Rollback();
                return false;
            }
        }

        /// <summary>
        /// БЛОК 2 (variant C): Drag предмета A из сетки на слот экипировки.
        ///
        /// Это путь, который сейчас обрабатывает K_InventoryUI.OnEquipmentSlotDrop
        /// (не транзакционно). Данный метод — транзакционная замена: вызывается
        /// из модифицированного OnEquipmentSlotDrop, выполняет весь swap
        /// атомарно и возвращает true/false. UI-чистку (возврат UI_Item в пул,
        /// сброс _isDragging и т.д.) выполняет вызывающий код в K_InventoryUI.
        ///
        /// Контракт: A уже изъят из origin-контроллера слоем K_InventoryUI
        /// (TryStartDrag выставил _dragItemRemoved=true). Сервису нужно только:
        /// 1. Snapshot A (откуда пришёл) и B (старый надетый, если есть).
        /// 2. Validate: TypeMatchCheck + NestingCheckBidirectional.
        /// 3. Если слот занят B: разместить B на старом месте A
        ///    (с FindFreeSpace + fallback в другие сетки игрока).
        /// 4. Экипировать A в slot.SetEquippedItem(A).
        /// 5. Backpack hooks.
        /// 6. При ошибке — Rollback. UI-чистку НЕ делаем (EndDragComplete
        ///    вернёт A в origin).
        /// </summary>
        public bool TryEquipFromDrag(UI_Item draggedUI, K_EquipmentSlotUI targetSlot, out string errorMessage)
        {
            errorMessage = string.Empty;

            if (_isTransactionActive)
            {
                errorMessage = "Transaction already active";
                return false;
            }

            if (draggedUI == null || targetSlot == null)
            {
                errorMessage = "Null references (draggedUI or targetSlot)";
                return false;
            }

            var itemA = draggedUI.Item;
            if (itemA == null || itemA.Data == null)
            {
                errorMessage = "Invalid dragged item";
                return false;
            }

            EnsureInitialized();
            if (_inventoryUI == null)
            {
                errorMessage = "No inventory UI";
                return false;
            }

            // 1. Type Match Check — соответствует ли тип предмета слоту
            if (!InventoryValidationService.TypeMatchCheck(itemA, targetSlot.SlotType))
            {
                errorMessage = $"Type mismatch: '{itemA.Data.DisplayName}' cannot go to slot {targetSlot.SlotType}";
                return false;
            }

            // Защита от бессмысленной операции: предмет уже в этом слоте
            if (targetSlot.EquippedItem == itemA)
            {
                errorMessage = "Item is already in this slot";
                return false;
            }

            var ctrlA = GetControllerForUI(draggedUI);
            int ax = draggedUI.X, ay = draggedUI.Y;
            GridType gridA = draggedUI.GridType;

            BeginTransaction();
            try
            {
                // 2. Snapshot A (откуда пришёл)
                _snapshots.Add(ItemSnapshot.FromGrid(itemA, ctrlA, gridA, ax, ay));

                // 3. Если слот занят — snapshot B + проверка nesting
                InventoryItem oldItemB = targetSlot.IsOccupied ? targetSlot.EquippedItem : null;
                if (oldItemB != null)
                {
                    _snapshots.Add(ItemSnapshot.FromEquipmentSlot(oldItemB, targetSlot, targetSlot.SlotType));

                    if (!InventoryValidationService.NestingCheckBidirectional(itemA, oldItemB))
                    {
                        errorMessage = "Nesting cycle: cannot swap backpack with its descendant";
                        Rollback();
                        return false;
                    }
                }

                // 4. Если слот занят B — разместить B на старом месте A
                if (oldItemB != null)
                {
                    // B наследует разворот A (как в OnEquipmentSlotDrop)
                    oldItemB.RestoreRotationState(itemA.RotationAngle);

                    if (ctrlA != null)
                    {
                        if (!TryPlaceItemInPlayerGrids(oldItemB, ctrlA, ax, ay, out var errB))
                        {
                            errorMessage = "Cannot place old equipped item: " + errB;
                            Rollback();
                            return false;
                        }
                    }
                    else
                    {
                        if (!TryPlaceItemInAnyPlayerGrid(oldItemB, out var errB))
                        {
                            errorMessage = "Cannot place old equipped item (no origin controller): " + errB;
                            Rollback();
                            return false;
                        }
                    }

                    // Очищаем слот (B теперь в сетке)
                    if (targetSlot.EquippedItem == oldItemB)
                        targetSlot.SetEquippedItem(null);
                }

                // 5. Экипировать A в слот
                targetSlot.SetEquippedItem(itemA);
                _placements.Add(new PlacementRecord(itemA, targetSlot));

                // 6. Backpack hooks
                if (targetSlot.SlotType == EquipmentSlotType.Backpack)
                {
                    if (itemA.Data.IsBackpack)
                        _inventoryUI.OnBackpackEquipped(itemA);

                    if (oldItemB != null && oldItemB.Data != null && oldItemB.Data.IsBackpack)
                        _inventoryUI.OnBackpackUnequipped();
                }

                Commit();
                // ВАЖНО: UI-чистку (draggedUI.SetActive(false), ReturnToPool,
                // сброс _isDragging и т.д.) выполняет K_InventoryUI.OnEquipmentSlotDrop
                // после того, как этот метод вернёт true. ForceRefresh вызывается там же.
                return true;
            }
            catch (System.Exception ex)
            {
                Debug.LogException(ex);
                errorMessage = "Transaction exception: " + ex.Message;
                Rollback();
                return false;
            }
        }

        // ═══════════════════════════════════════════════════════════════
        //  Transaction lifecycle
        // ═══════════════════════════════════════════════════════════════

        private void BeginTransaction()
        {
            _isTransactionActive = true;
            _snapshots.Clear();
            _placements.Clear();
        }

        private void Commit()
        {
            _snapshots.Clear();
            _placements.Clear();
            _isTransactionActive = false;
        }

        /// <summary>
        /// Откат транзакции. Выполняется в два прохода:
        /// 1. Undo placements — удаляем предмет из тех мест, куда мы его
        ///    поместили во время транзакции (в обратном порядке).
        /// 2. Restore snapshots — возвращаем предметы на исходные позиции
        ///    (в обратном порядке, чтобы восстановить исходное состояние).
        /// </summary>
        private void Rollback()
        {
            // 1. Undo placements (reverse order)
            for (int i = _placements.Count - 1; i >= 0; i--)
            {
                var p = _placements[i];
                if (p.Item == null) continue;

                if (p.InSlot && p.Slot != null)
                {
                    if (ReferenceEquals(p.Slot.EquippedItem, p.Item))
                        p.Slot.SetEquippedItem(null);
                }
                else if (p.Controller != null)
                {
                    // Если предмет всё ещё на этой позиции — удаляем.
                    // ReferenceEquals безопаснее, чем GetItemAt, потому что
                    // предмет мог быть удалён ранее (двойной rollback-шаг).
                    try
                    {
                        if (p.Controller.IsRootCell(p.Item.InstanceID, p.X, p.Y) ||
                            IsItemAnywhereInController(p.Controller, p.Item))
                        {
                            p.Controller.RemoveItem(p.Item);
                        }
                    }
                    catch (System.Exception ex)
                    {
                        Debug.LogWarning($"[Transaction.Rollback] Failed to remove item from placement: {ex.Message}");
                    }
                }
            }

            // 2. Restore snapshots (reverse order)
            for (int i = _snapshots.Count - 1; i >= 0; i--)
            {
                var snap = _snapshots[i];
                if (snap.Item == null) continue;

                // Восстановить rotation/fold состояние
                try { snap.Item.RestoreRotationState(snap.RotationAngle); }
                catch { /* ignore — лучше продолжить rollback, чем упасть */ }

                if (snap.IsFromEquipmentSlot && snap.OriginSlotUI != null)
                {
                    // Сначала убираем из слота то, что там сейчас (если что-то есть)
                    if (snap.OriginSlotUI.EquippedItem != null &&
                        snap.OriginSlotUI.EquippedItem != snap.Item)
                    {
                        // В слоте лежит какой-то другой предмет — откатываем его
                        // в любой grid как fallback (не должно случаться при
                        // корректной транзакции, но defensively).
                        var orphan = snap.OriginSlotUI.EquippedItem;
                        snap.OriginSlotUI.SetEquippedItem(null);
                        TryPlaceItemInAnyPlayerGrid(orphan, out _);
                    }
                    snap.OriginSlotUI.SetEquippedItem(snap.Item);
                }
                else
                {
                    // Предмет из сетки (или OriginController == null —
                    // например, контейнер закрылся). В любом случае
                    // удаляем его отовсюду и пытаемся разместить.
                    RemoveItemFromEverywhere(snap.Item);

                    if (snap.OriginController != null)
                    {
                        // Пробуем разместить на исходной позиции
                        if (!snap.OriginController.PlaceExistingItem(snap.Item, snap.OriginX, snap.OriginY))
                        {
                            if (!snap.OriginController.PlaceExistingItemInFirstFreeSlot(snap.Item))
                            {
                                if (!TryPlaceItemInAnyPlayerGrid(snap.Item, out _))
                                {
                                    Debug.LogError(
                                        $"[Transaction.Rollback] ITEM-LOSS: could not restore item " +
                                        $"'{snap.Item.Data?.DisplayName}' (InstanceID={snap.InstanceID}) " +
                                        $"to any player grid!");
                                }
                            }
                        }
                    }
                    else
                    {
                        // OriginController == null — fallback в любую сетку игрока
                        if (!TryPlaceItemInAnyPlayerGrid(snap.Item, out _))
                        {
                            Debug.LogError(
                                $"[Transaction.Rollback] ITEM-LOSS (no origin controller): " +
                                $"could not restore item '{snap.Item.Data?.DisplayName}' " +
                                $"(InstanceID={snap.InstanceID}) to any player grid!");
                        }
                    }
                }
            }

            _snapshots.Clear();
            _placements.Clear();
            _isTransactionActive = false;

            if (_inventoryUI != null)
                _inventoryUI.ForceRefresh();
        }

        // ═══════════════════════════════════════════════════════════════
        //  Placement helpers
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Пытается разместить item в controller на точной позиции (x, y).
        /// Если не влезает — FindFreeSpace в том же controller.
        /// При успехе записывает PlacementRecord для отката.
        /// </summary>
        private bool TryPlaceItemInController(
            InventoryItem item,
            InventoryController controller,
            int x,
            int y,
            out string errorMessage)
        {
            errorMessage = string.Empty;

            // Точная позиция
            if (InventoryValidationService.GridSpaceCheck(controller, item, x, y))
            {
                if (controller.PlaceExistingItem(item, x, y))
                {
                    _placements.Add(new PlacementRecord(item, controller, x, y));
                    return true;
                }
            }

            // FindFreeSpace в том же controller (с авто-ротацией)
            int origAngle = item.RotationAngle;
            if (InventoryValidationService.FindFreeSpace(controller, item, out int fx, out int fy))
            {
                if (controller.PlaceExistingItem(item, fx, fy))
                {
                    _placements.Add(new PlacementRecord(item, controller, fx, fy));
                    return true;
                }
                // FindFreeSpace нашёл место, но PlaceExistingItem не сработал — откатываем ротацию
                item.RestoreRotationState(origAngle);
            }

            errorMessage = $"no free space in controller '{controller.SaveID}'";
            return false;
        }

        /// <summary>
        /// Пытается разместить item в preferenceController на точной позиции (x, y),
        /// затем FindFreeSpace в preferenceController, затем FindFreeSpace в других
        /// сетках игрока (Pockets → Pocket2 → Backpack).
        /// </summary>
        private bool TryPlaceItemInPlayerGrids(
            InventoryItem item,
            InventoryController preferenceController,
            int preferredX,
            int preferredY,
            out string errorMessage)
        {
            errorMessage = string.Empty;

            // 1. Точная позиция в preferenceController
            if (preferenceController != null &&
                InventoryValidationService.GridSpaceCheck(preferenceController, item, preferredX, preferredY))
            {
                if (preferenceController.PlaceExistingItem(item, preferredX, preferredY))
                {
                    _placements.Add(new PlacementRecord(item, preferenceController, preferredX, preferredY));
                    return true;
                }
            }

            // 2. FindFreeSpace в preferenceController
            if (preferenceController != null)
            {
                int origAngle = item.RotationAngle;
                if (InventoryValidationService.FindFreeSpace(preferenceController, item, out int fx, out int fy))
                {
                    if (preferenceController.PlaceExistingItem(item, fx, fy))
                    {
                        _placements.Add(new PlacementRecord(item, preferenceController, fx, fy));
                        return true;
                    }
                    item.RestoreRotationState(origAngle);
                }
            }

            // 3. FindFreeSpace в других сетках игрока
            return TryPlaceItemInAnyPlayerGrid(item, out errorMessage);
        }

        /// <summary>
        /// Пытается разместить item в любой сетке игрока (Pockets → Pocket2 → Backpack).
        /// Container НЕ трогаем (может быть цикл).
        /// </summary>
        private bool TryPlaceItemInAnyPlayerGrid(InventoryItem item, out string errorMessage)
        {
            errorMessage = string.Empty;
            if (_inventoryUI == null || item == null) return false;

            var grids = new[]
            {
                (GridType.Pockets, _inventoryUI.GetControllerForGrid(GridType.Pockets)),
                (GridType.Pocket2, _inventoryUI.GetControllerForGrid(GridType.Pocket2)),
                (GridType.Backpack, _inventoryUI.GetControllerForGrid(GridType.Backpack)),
            };

            foreach (var (gridType, ctrl) in grids)
            {
                if (ctrl == null) continue;

                int origAngle = item.RotationAngle;
                if (InventoryValidationService.FindFreeSpace(ctrl, item, out int fx, out int fy))
                {
                    if (ctrl.PlaceExistingItem(item, fx, fy))
                    {
                        _placements.Add(new PlacementRecord(item, ctrl, fx, fy));
                        return true;
                    }
                    item.RestoreRotationState(origAngle);
                }
            }

            errorMessage = "no free space in any player grid";
            return false;
        }

        // ═══════════════════════════════════════════════════════════════
        //  Search / lookup helpers
        // ═══════════════════════════════════════════════════════════════

        private InventoryController GetControllerForUI(UI_Item uiItem)
        {
            if (uiItem == null || _inventoryUI == null) return null;

            // Для контейнерных сеток используем BoundController
            if (uiItem.GridType == GridType.Container && uiItem.BoundController != null)
                return uiItem.BoundController;

            return _inventoryUI.GetControllerForGrid(uiItem.GridType);
        }

        /// <summary>
        /// Ищет предмет во всех сетках игрока. Возвращает (GridType, x, y) или (null, 0, 0).
        /// Аналог K_InventoryUI.FindItemLocation, но без доступа к приватным полям
        /// (поэтому не заглядывает в Container-окна и loot-контроллер).
        /// </summary>
        private (GridType? grid, int x, int y) FindItemLocationInPlayerGrids(InventoryItem item)
        {
            if (item == null || _inventoryUI == null) return (null, 0, 0);
            uint id = item.InstanceID;

            var grids = new[]
            {
                (GridType.Pockets, _inventoryUI.GetControllerForGrid(GridType.Pockets)),
                (GridType.Pocket2, _inventoryUI.GetControllerForGrid(GridType.Pocket2)),
                (GridType.Backpack, _inventoryUI.GetControllerForGrid(GridType.Backpack)),
            };

            foreach (var (type, ctrl) in grids)
            {
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var at = ctrl.GetItemAt(x, y);
                        if (at != null && at.InstanceID == id)
                            return (type, x, y);
                    }
            }
            return (null, 0, 0);
        }

        private bool IsItemAnywhereInController(InventoryController ctrl, InventoryItem item)
        {
            if (ctrl == null || item == null) return false;
            uint id = item.InstanceID;
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var at = ctrl.GetItemAt(x, y);
                    if (at != null && at.InstanceID == id) return true;
                }
            return false;
        }

        private void RemoveItemFromEverywhere(InventoryItem item)
        {
            if (item == null || _inventoryUI == null) return;
            uint id = item.InstanceID;

            var grids = new[]
            {
                _inventoryUI.GetControllerForGrid(GridType.Pockets),
                _inventoryUI.GetControllerForGrid(GridType.Pocket2),
                _inventoryUI.GetControllerForGrid(GridType.Backpack),
            };

            foreach (var ctrl in grids)
            {
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var at = ctrl.GetItemAt(x, y);
                        if (at != null && at.InstanceID == id)
                        {
                            ctrl.RemoveItem(item);
                            return;
                        }
                    }
            }

            // Также проверяем слоты экипировки
            foreach (var slot in _cachedSlots)
            {
                if (slot != null && slot.EquippedItem != null && slot.EquippedItem.InstanceID == id)
                {
                    slot.SetEquippedItem(null);
                    return;
                }
            }
        }

        private K_EquipmentSlotUI FindSlotHoldingItem(InventoryItem item)
        {
            if (item == null) return null;
            EnsureSlotsCached();
            foreach (var slot in _cachedSlots)
            {
                if (slot != null && slot.EquippedItem != null && slot.EquippedItem.InstanceID == item.InstanceID)
                    return slot;
            }
            return null;
        }

        /// <summary>
        /// Возвращает подходящий слот экипировки для заданного типа.
        /// Для Primary (где 2 слота) предпочитает пустой; иначе первый занятый.
        /// </summary>
        private K_EquipmentSlotUI GetEquipSlot(EquipmentSlotType slotType)
        {
            EnsureSlotsCached();
            K_EquipmentSlotUI fallback = null;
            foreach (var slot in _cachedSlots)
            {
                if (slot == null || slot.SlotType != slotType) continue;
                if (!slot.IsOccupied) return slot; // предпочитаем пустой
                if (fallback == null) fallback = slot;
            }
            return fallback;
        }

        // ═══════════════════════════════════════════════════════════════
        //  Initialization
        // ═══════════════════════════════════════════════════════════════

        private void EnsureInitialized()
        {
            if (_inventoryUI == null)
                _inventoryUI = FindFirstObjectByType<K_InventoryUI>();
            EnsureSlotsCached();
        }

        private void EnsureSlotsCached()
        {
            if (_slotsCached) return;
            _slotsCached = true;
            _cachedSlots.Clear();
            var slots = FindObjectsByType<K_EquipmentSlotUI>(FindObjectsSortMode.None);
            foreach (var slot in slots)
                if (slot != null) _cachedSlots.Add(slot);
        }
    }
}
