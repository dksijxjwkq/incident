﻿// === NEW FILE: ItemSnapshot.cs ===
// Версия 2: поле FromEquipmentSlot переименовано в IsFromEquipmentSlot,
// чтобы избежать конфликта с одноимённым статическим фабричным методом
// FromEquipmentSlot(...) — в C# поле и метод не могут иметь одинаковое имя.
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Легковесный неизменяемый снапшот состояния InventoryItem на момент
    /// старта транзакции. readonly struct —> нулевые аллокации на heap,
    /// копирование по значению (zero-GC).
    ///
    /// Фиксирует:
    /// - Ссылку на живой InventoryItem (объект не копируется, мы только
    ///   запоминаем, где он лежал и в каком rotation/fold состоянии).
    /// - Исходное размещение: controller + GridType + (x, y) или
    ///   equipment slot + slot-type — для отката.
    /// - Визуальное состояние: RotationAngle, IsFolded — чтобы при откате
    ///   восстановить не только позицию, но и ориентацию предмета.
    ///
    /// ВАЖНО: сам InventoryItem остаётся мутируемым (он живой объект).
    /// Снапшот хранит только "точку восстановления".
    /// </summary>
    public readonly struct ItemSnapshot
    {
        // ── Живой предмет (не копия) ──
        public readonly InventoryItem Item;

        // ── Исходное размещение в сетке (если не из слота экипировки) ──
        public readonly InventoryController OriginController;
        public readonly GridType OriginGrid;
        public readonly int OriginX;
        public readonly int OriginY;

        // ── Исходное размещение в слоте экипировки ──
        // ФИКС v2: переименовано с FromEquipmentSlot → IsFromEquipmentSlot,
        // чтобы не конфликтовать со статическим фабричным методом
        // ItemSnapshot.FromEquipmentSlot(item, slotUI, slotType).
        public readonly bool IsFromEquipmentSlot;
        public readonly EquipmentSlotType EquipmentSlotType;
        public readonly K_EquipmentSlotUI OriginSlotUI;

        // ── Визуальное состояние для отката ──
        public readonly int RotationAngle;
        public readonly bool IsFolded;

        public ItemSnapshot(
            InventoryItem item,
            InventoryController originController,
            GridType originGrid,
            int originX,
            int originY,
            int rotationAngle,
            bool isFolded,
            bool isFromEquipmentSlot,
            EquipmentSlotType equipmentSlotType,
            K_EquipmentSlotUI originSlotUI)
        {
            Item = item;
            OriginController = originController;
            OriginGrid = originGrid;
            OriginX = originX;
            OriginY = originY;
            RotationAngle = rotationAngle;
            IsFolded = isFolded;
            IsFromEquipmentSlot = isFromEquipmentSlot;
            EquipmentSlotType = equipmentSlotType;
            OriginSlotUI = originSlotUI;
        }

        /// <summary>Снапшот валиден, если у нас есть ссылка на предмет с InstanceID > 0.</summary>
        public bool IsValid => Item != null && Item.InstanceID > 0;

        /// <summary>InstanceID предмета (0 если Item == null).</summary>
        public uint InstanceID => Item != null ? Item.InstanceID : 0;

        /// <summary>Удобный фабричный метод для предмета из обычной сетки.</summary>
        public static ItemSnapshot FromGrid(
            InventoryItem item,
            InventoryController controller,
            GridType grid,
            int x,
            int y)
        {
            return new ItemSnapshot(
                item, controller, grid, x, y,
                item != null ? item.RotationAngle : 0,
                item != null ? item.IsFolded : false,
                isFromEquipmentSlot: false,
                equipmentSlotType: default,
                originSlotUI: null);
        }

        /// <summary>Удобный фабричный метод для предмета из слота экипировки.</summary>
        public static ItemSnapshot FromEquipmentSlot(
            InventoryItem item,
            K_EquipmentSlotUI slotUI,
            EquipmentSlotType slotType)
        {
            return new ItemSnapshot(
                item, null, default, 0, 0,
                item != null ? item.RotationAngle : 0,
                item != null ? item.IsFolded : false,
                isFromEquipmentSlot: true,
                equipmentSlotType: slotType,
                originSlotUI: slotUI);
        }
    }
}
