﻿
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// UI-слот инвентаря. Отображает ячейку сетки, подсветку при drag и tint занятости.
    /// Реализует IDropHandler для приёма перетаскиваемых предметов.
    /// 
    /// ИСПРАВЛЕНИЯ (баг-фикс сессия):
    /// #БАГ3: Добавлен SetRaycastEnabled() и raycastTarget = false по умолчанию.
    ///        В покое слоты НЕ блокируют raycast → предметы можно кликать/тащить.
    ///        K_InventoryUI включает raycast на слотах только во время drag.
    ///
    /// БАГ 3 (drop-смещение на 1 клетку вниз в переносных сетках) ФИКС:
    ///   GetAdjustedDropPosition теперь принимает _boundController напрямую.
    ///   Раньше он использовал глобальные _currentContainerCols/Rows, которые
    ///   относятся к АКТИВНОМУ окну. Если игрок drag-дропает в НЕ активное
    ///   окно другого размера — CalculateSnapPosition использует неправильные
    ///   gridWidth/gridHeight → предмет placed на 1 клетку ниже/правее
    ///   ожидаемого. Теперь всегда используется BoundController слота.
    /// </summary>
    public class K_InventorySlotUI : MonoBehaviour, IDropHandler
    {
        #region Fields
        private K_InventoryUI _inventoryUI;
        private Image _backgroundImage;
        private Color _originalColor;
        private Image _cellOverlay; // Полноцветный overlay — закрывает ВЕСЬ слот
        // FIX баг3: контроллер окна, которому принадлежит слот.
        private InventoryController _boundController;
        public void BindController(InventoryController c) { _boundController = c; }
        #endregion

        #region Properties
        public int X { get; private set; }
        public int Y { get; private set; }
        public GridType GridType { get; private set; }
        public Image BackgroundImage => _backgroundImage;
        public Color CellOverlayColor => _cellOverlay != null ? _cellOverlay.color : Color.clear;

        /// <summary>
        /// FIX БАГ 3: Публичный доступ к контроллеру, привязанному к этому слоту.
        /// Используется в K_InventoryUI.UpdateDragCellHighlights для определения
        /// целевого контроллера при drag над окнами-контейнерами.
        /// Без этого призрак постановки рисуется в сетке активного окна (№2),
        /// хотя курсор находится над окном №3.
        /// </summary>
        public InventoryController BoundController => _boundController;
        #endregion

        #region Initialization
        public void Setup(int x, int y, GridType gridType, K_InventoryUI inventoryUI)
        {
            X = x;
            Y = y;
            GridType = gridType;
            _inventoryUI = inventoryUI;

            // Фоновый Image слота (рамка)
            if (_backgroundImage == null)
                _backgroundImage = GetComponent<Image>();
            if (_backgroundImage != null)
            {
                _originalColor = _backgroundImage.color;
                // ФИКС БАГ #3 (v2): По умолчанию слот НЕ блокирует raycast.
                // Это позволяет предметам в itemsContainer (которые могут быть
                // ниже в иерархии) получать IBeginDragHandler.
                // K_InventoryUI включает raycast на слотах при старте drag.
                _backgroundImage.raycastTarget = false;
            }

            // Создаём overlay — Image без sprite, заполняет ВЕСЬ слот
            EnsureCellOverlay();
        }

        /// <summary>
        /// ФИКС БАГ #3 (v2): Включает/выключает raycastTarget на фоновом Image слота.
        /// Вызывается из K_InventoryUI при начале/конце drag.
        /// </summary>
        public void SetRaycastEnabled(bool enabled)
        {
            if (_backgroundImage != null)
                _backgroundImage.raycastTarget = enabled;
        }

        /// <summary>
        /// Создаёт дочерний Image-overlay, который заполняет 100% площади слота.
        /// Используется для подсветки при drag и occupied tint.
        /// Решает проблему: у слота sprite может быть 9-sliced рамка с прозрачным центром.
        /// </summary>
        private void EnsureCellOverlay()
        {
            Transform existing = transform.Find("CellOverlay");
            if (existing != null)
            {
                _cellOverlay = existing.GetComponent<Image>();
                if (_cellOverlay == null)
                    _cellOverlay = existing.gameObject.AddComponent<Image>();
                _cellOverlay.color = Color.clear;
                _cellOverlay.raycastTarget = false;
                return;
            }

            var overlayObj = new GameObject("CellOverlay", typeof(RectTransform), typeof(Image));
            overlayObj.transform.SetParent(transform, false);

            var rt = overlayObj.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = Vector2.zero; // Растянется на весь parent
            rt.localScale = Vector3.one;

            _cellOverlay = overlayObj.GetComponent<Image>();
            _cellOverlay.sprite = null;
            _cellOverlay.type = Image.Type.Simple;
            _cellOverlay.color = Color.clear;
            _cellOverlay.raycastTarget = false;
        }
        #endregion

        #region Cell Color API

        /// <summary>Установить цвет overlay (для подсветки при drag).</summary>
        public void SetCellColor(Color color)
        {
            if (_cellOverlay != null)
                _cellOverlay.color = color;
        }

        /// <summary>Вернуть overlay к прозрачному.</summary>
        public void ResetCellColor()
        {
            if (_cellOverlay != null)
                _cellOverlay.color = Color.clear;
        }

        /// <summary>Сделать ячейку чуть светлее (занята предметом).</summary>
        public void TintOccupied(Color tint)
        {
            if (_cellOverlay == null) return;

            // Если alpha = 0 — overlay полностью прозрачный, ничего не рисуем.
            if (tint.a <= 0f)
            {
                _cellOverlay.color = Color.clear;
                return;
            }

            // Используем tint как есть. Никаких "если R>0 → 1f" — это и было источником белой пелены.
            _cellOverlay.color = tint;
        }

        #endregion

        #region Event Handlers (Unity UI)

        public void OnDrop(PointerEventData eventData)
        {
#if UNITY_EDITOR
            Debug.Log($"[SlotUI] OnDrop FIRED! GridType={GridType}, pos=({X},{Y}), pointerDrag={eventData.pointerDrag?.name}");
#endif
            if (eventData.pointerDrag == null) return;

            var draggedUI = eventData.pointerDrag.GetComponent<UI_Item>();
            var inventoryUI = _inventoryUI;
            if (inventoryUI == null) return;

            // Случай A: Предмет из инвентаря (UI_Item)
            if (draggedUI != null && draggedUI.Item != null)
            {
                var itemSize = draggedUI.Item.CurrentSize;

                // ═══ БАГ 3 ФИКС: передаём _boundController в GetAdjustedDropPosition ═══
                // Раньше GetAdjustedDropPosition использовал глобальные _currentContainerCols/Rows,
                // которые относятся к активному окну. Если игрок дропает в НЕ активное
                // окно другого размера — CalculateSnapPosition использует неправильные
                // gridWidth/gridHeight, и предмет placed на 1 клетку ниже/правее
                // ожидаемого. Теперь всегда используется BoundController слота.
                var (targetX, targetY) = inventoryUI.GetAdjustedDropPosition(
                    X, Y, itemSize, GridType, _boundController);

#if UNITY_EDITOR
                Debug.Log($"[SlotUI] Drop A: slot=({X},{Y}), size={itemSize.x}x{itemSize.y}, " +
                          $"boundCtrl={_boundController?.Width}x{_boundController?.Height}, " +
                          $"target=({targetX},{targetY})");
#endif

                inventoryUI.SetDropTargetController(_boundController);
                bool success = inventoryUI.TryPlaceItem(draggedUI, GridType, targetX, targetY);
                inventoryUI.SetDropTargetController(null);
                if (!success)
                {
#if UNITY_EDITOR
                    Debug.Log($"[SlotUI] Placement rejected at [{targetX},{targetY}] GridType={GridType}");
#endif
                }
                return;
            }

            // Случай B: Предмет из слота экипировки
            if (inventoryUI.IsDraggingFromEquipmentSlot)
            {
                var slotItem = inventoryUI.DraggedFromSlotItem;
                if (slotItem != null)
                {
                    var itemSize = slotItem.CurrentSize;

                    // ═══ БАГ 3 ФИКС: та же передача _boundController ═══
                    var (targetX, targetY) = inventoryUI.GetAdjustedDropPosition(
                        X, Y, itemSize, GridType, _boundController);

#if UNITY_EDITOR
                    Debug.Log($"[SlotUI] Drop B (equip): slot=({X},{Y}), size={itemSize.x}x{itemSize.y}, " +
                              $"boundCtrl={_boundController?.Width}x{_boundController?.Height}, " +
                              $"target=({targetX},{targetY})");
#endif

                    inventoryUI.SetDropTargetController(_boundController);
                    bool success = inventoryUI.TryPlaceItemFromEquipmentSlot(GridType, targetX, targetY);
                    inventoryUI.SetDropTargetController(null);
                    if (success)
                        inventoryUI.FinalizeEquipSlotDrag();
                    else
                    {
#if UNITY_EDITOR
                        Debug.Log($"[SlotUI] Equipment slot placement rejected at [{targetX},{targetY}] GridType={GridType}");
#endif
                    }
                }
                return;
            }

            Debug.LogWarning($"[SlotUI] Drop failed: pointerDrag has no valid UI_Item and not dragging from equipment slot.");
        }

        #endregion
    }
}
