﻿using K_Incident.Core.Inventory;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// UI-представление предмета в инвентаре.
    ///
    /// БАГ #4 (ФИКС): OnDrop на иконку рюкзака БОЛЬШЕ НЕ ОТКРЫВАЕТ UI-окно контейнера
    /// во время drag. Дроп кладёт предмет НАПРЯМУЮ через K_InventoryUI.TryDropItemIntoBackpack
    /// (временный контроллер, без открытия панелей). При неудаче метод возвращает false
    /// и НИЧЕГО не меняет — EndDragComplete вернёт предмет на исходную позицию.
    ///
    /// БАГ #3 (ФИКС этой правки): UpdateVisuals теперь ставит размер body ДО текста
    /// и вызывает ForceMeshUpdate(true) — иначе TMP не пересчитывал меш после выхода
    /// из пула, и название пропадало у последних предметов в ряду.
    ///
    /// БЛОК 2 (ФИКС): OnDrop теперь обрабатывает не только дроп на рюкзак
    /// (внутрь сетки рюкзака), но и дроп предмета на обычный предмет —
    /// свап (Tarkov-style) через InventoryTransactionService.TrySwapItems.
    /// Сервис выполняет атомарную транзакцию с snapshot/validate/rollback.
    /// </summary>
    public class UI_Item : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler,
    IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler,
    IDropHandler
    {
        #region Inspector Fields
        [Header("References")]
        [SerializeField] private Image _icon;
        [SerializeField] private TextMeshProUGUI _quantityText;
        [SerializeField] private GameObject _quantityGroup;

        [Header("Item Labels")]
        [SerializeField, Tooltip("Размер шрифта названия")]
        private float _nameFontSize = 10f;
        [SerializeField, Tooltip("Размер шрифта калибра")]
        private float _caliberFontSize = 9f;

        [Header("Selection (Click Highlight)")]
        [SerializeField, Tooltip("Цвет выделения при клике на предмет")]
        private Color _selectionColor = new Color(1f, 0.85f, 0f, 0.35f);

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false;
        #endregion

        #region Constants
        private static readonly Vector2 OFFSCREEN_POSITION = new Vector2(-9999f, -9999f);
        private static Sprite _transparentSprite;

        // FIX БАГ 3 (диагностика): кэш предметов, для которых уже залогировано
        // отсутствие IconFolded. Делает предупреждение ОДНОРАЗОВЫМ на предмет,
        // чтобы не спамить в консоль каждый рефреш.
        private static readonly HashSet<uint> _loggedMissingFoldIcon = new HashSet<uint>();
        #endregion

        #region Fields
        private InventoryItem _item;
        private K_InventoryUI _inventoryUI;
        private GridType _gridType;
        private int _gridX, _gridY;
        private bool _isDragging;
        private CanvasGroup _canvasGroup;
        private RectTransform _bodyRect;
        private RectTransform _iconRect;
        private bool _iconEnsuredAsChild;
        private Image _raycastTarget;
        private Image _selectionOverlay;
        private TextMeshProUGUI _nameText;
        private TextMeshProUGUI _caliberText;
        private InventoryController _boundController;
        #endregion

        #region Properties
        public InventoryItem Item => _item;
        public GridType GridType => _gridType;
        public int X => _gridX;
        public int Y => _gridY;
        public bool IsDragging => _isDragging;
        public Color SelectionColor => _selectionColor;
        public InventoryController BoundController => _boundController;
        #endregion

        private static Sprite GetTransparentSprite()
        {
            if (_transparentSprite != null) return _transparentSprite;
            var tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            tex.SetPixel(0, 0, Color.clear);
            tex.Apply();
            _transparentSprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), Vector2.zero, 1f);
            _transparentSprite.name = "TransparentRaycast";
            return _transparentSprite;
        }

        #region Initialization
        private void Awake()
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null)
                _canvasGroup = gameObject.AddComponent<CanvasGroup>();

            _bodyRect = GetComponent<RectTransform>();
            EnsureIconIsChild();
            EnsureRaycastTarget();
            EnsureSelectionOverlay();
        }

        private void EnsureIconIsChild()
        {
            if (_icon == null)
                _icon = GetComponentInChildren<Image>();
            if (_icon == null)
            {
                Debug.LogWarning($"[UI_Item] {gameObject.name}: Image (icon) не назначена!");
                return;
            }
            _iconRect = _icon.rectTransform;

            if (_iconRect == _bodyRect)
            {
                var childObj = new GameObject("Icon", typeof(RectTransform), typeof(Image));
                childObj.transform.SetParent(_bodyRect, false);
                var childRT = childObj.GetComponent<RectTransform>();
                childRT.anchorMin = new Vector2(0.5f, 0.5f);
                childRT.anchorMax = new Vector2(0.5f, 0.5f);
                childRT.pivot = new Vector2(0.5f, 0.5f);
                childRT.anchoredPosition = Vector2.zero;
                childRT.localRotation = Quaternion.identity;
                childRT.localScale = Vector3.one;
                var childImage = childObj.GetComponent<Image>();
                childImage.sprite = _icon.sprite;
                childImage.color = Color.white;
                childImage.type = _icon.type;
                childImage.preserveAspect = true;
                childImage.raycastTarget = true;
                childImage.enabled = true;
                _icon.enabled = false;
                _icon.raycastTarget = false;
                _icon = childImage;
                _iconRect = childRT;
            }
            else
            {
                _icon.raycastTarget = true;
            }
            _iconRect.anchorMin = new Vector2(0.5f, 0.5f);
            _iconRect.anchorMax = new Vector2(0.5f, 0.5f);
            _iconRect.pivot = new Vector2(0.5f, 0.5f);
            _iconRect.anchoredPosition = Vector2.zero;
            _iconRect.localScale = Vector3.one;
            _iconEnsuredAsChild = true;
        }

        private void EnsureRaycastTarget()
        {
            var allImages = GetComponents<Image>();
            foreach (var img in allImages)
            {
                if (img == null) continue;
                img.sprite = null;
                img.color = Color.clear;
                img.raycastTarget = false;
                img.enabled = false;
            }
            _raycastTarget = null;
        }

        private void EnsureSelectionOverlay()
        {
            Transform existing = _bodyRect.Find("SelectionOverlay");
            if (existing != null)
            {
                _selectionOverlay = existing.GetComponent<Image>();
                if (_selectionOverlay == null)
                    _selectionOverlay = existing.gameObject.AddComponent<Image>();
                _selectionOverlay.color = Color.clear;
                _selectionOverlay.raycastTarget = false;
                _selectionOverlay.enabled = false;
                return;
            }
            var overlayObj = new GameObject("SelectionOverlay", typeof(RectTransform), typeof(Image));
            overlayObj.transform.SetParent(_bodyRect, false);
            var rt = overlayObj.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = Vector2.zero;
            rt.localScale = Vector3.one;
            _selectionOverlay = overlayObj.GetComponent<Image>();
            _selectionOverlay.sprite = null;
            _selectionOverlay.type = Image.Type.Simple;
            _selectionOverlay.color = Color.clear;
            _selectionOverlay.raycastTarget = false;
            _selectionOverlay.enabled = false;
        }

        public void Setup(InventoryItem item, K_InventoryUI inventoryUI, GridType gridType, int x, int y)
        {
            _item = item;
            _inventoryUI = inventoryUI;
            _gridType = gridType;
            _gridX = x;
            _gridY = y;

            if (_canvasGroup != null)
            {
                _canvasGroup.interactable = true;
                _canvasGroup.blocksRaycasts = true;
                _canvasGroup.alpha = 1f;
            }

            ClearSelection();

            if (!gameObject.activeSelf)
                gameObject.SetActive(true);

            UpdateVisuals();

            // ═══ ДИАГНОСТИКА: логируем если текст не отобразился ═══
            if (_debugLogs && _nameText != null && _item.Data != null)
            {
                int chars = _nameText.textInfo.characterCount;
                float rw = _nameText.rectTransform.rect.width;
                if (chars == 0 && _item.Data.DisplayName.Length > 0)
                {
                    Debug.LogWarning(
                        $"[TEXT-BUG] Setup FAILED for '{_item.Data.DisplayName}' at [{x},{y}] {gridType}: " +
                        $"charCount=0, rectW={rw:F1}, " +
                        $"bodyW={(_bodyRect != null ? _bodyRect.rect.width.ToString("F1") : "null")}, " +
                        $"activeInHierarchy={gameObject.activeInHierarchy}");
                }
            }

            LogDebug($"[UI_Item] Setup: {item.Data.DisplayName} at [{x},{y}] GridType={gridType}");
        }
        #endregion

        #region Visual Updates
        private void EnsureNameLabel()
        {
            // ═══ ФИКС: Всегда пересоздаём TMP-объекты.
            // Внутреннее состояние TMP corruptится после цикла
            // text="" → text="..." в пуле. ForceMeshUpdate не лечит.
            // Пересоздание гарантирует чистый меш. ═══
            if (_nameText != null)
            {
                Destroy(_nameText.gameObject);
                _nameText = null;
            }
            if (_caliberText != null)
            {
                Destroy(_caliberText.gameObject);
                _caliberText = null;
            }

            TMP_FontAsset fontAsset = TMP_Settings.defaultFontAsset;
            if (fontAsset == null)
            {
                fontAsset = Resources.Load<TMP_FontAsset>("Fonts & Materials/LiberationSans SDF");
                if (fontAsset == null)
                    Debug.LogError("[UI_Item] TMP font asset not found!");
            }

            // ── Название ──
            var labelObj = new GameObject("ItemName", typeof(RectTransform), typeof(TextMeshProUGUI));
            labelObj.transform.SetParent(_bodyRect, false);
            var rt = labelObj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(2f, -2f);
            rt.sizeDelta = new Vector2(-4f, _nameFontSize * 3f + 4f);
            rt.localScale = Vector3.one;

            _nameText = labelObj.GetComponent<TextMeshProUGUI>();
            _nameText.font = fontAsset;
            _nameText.fontSize = _nameFontSize;
            _nameText.color = new Color(1f, 1f, 1f, 0.85f);
            _nameText.alignment = TextAlignmentOptions.TopLeft;
            _nameText.raycastTarget = false;
            _nameText.overflowMode = TextOverflowModes.Truncate;
            _nameText.textWrappingMode = TextWrappingModes.Normal;
            _nameText.fontStyle = FontStyles.Bold;
            _nameText.outlineColor = new Color(0f, 0f, 0f, 0.7f);
            _nameText.outlineWidth = 0.15f;

            // ── Калибр ──
            var calObj = new GameObject("ItemCaliber", typeof(RectTransform), typeof(TextMeshProUGUI));
            calObj.transform.SetParent(_bodyRect, false);
            var calRt = calObj.GetComponent<RectTransform>();
            calRt.anchorMin = new Vector2(0f, 0f);
            calRt.anchorMax = new Vector2(1f, 0f);
            calRt.pivot = new Vector2(0f, 0f);
            calRt.anchoredPosition = new Vector2(2f, 2f);
            calRt.sizeDelta = new Vector2(-4f, _caliberFontSize + 4f);
            calRt.localScale = Vector3.one;

            _caliberText = calObj.GetComponent<TextMeshProUGUI>();
            _caliberText.font = fontAsset;
            _caliberText.fontSize = _caliberFontSize;
            _caliberText.color = new Color(1f, 1f, 1f, 0.6f);
            _caliberText.alignment = TextAlignmentOptions.Left;
            _caliberText.verticalAlignment = VerticalAlignmentOptions.Bottom;
            _caliberText.raycastTarget = false;
            _caliberText.overflowMode = TextOverflowModes.Truncate;
            _caliberText.textWrappingMode = TextWrappingModes.NoWrap;
            _caliberText.outlineColor = new Color(0f, 0f, 0f, 0.7f);
            _caliberText.outlineWidth = 0.15f;
        }

        public void UpdateVisuals()
        {
            if (_item == null || _item.Data == null) return;

            if (!_iconEnsuredAsChild) EnsureIconIsChild();
            EnsureNameLabel(); // Теперь ВСЕГДА пересоздаёт TMP

            Sprite iconSprite = _item.CurrentIcon;
            if (_icon != null && iconSprite != null)
            {
                _icon.sprite = iconSprite;
                _icon.color = Color.white;
                _icon.enabled = true;
            }
            else if (_icon != null)
            {
                _icon.enabled = false;
            }

            if (_item.IsFolded && _item.Data.IconFolded == null)
            {
                if (_loggedMissingFoldIcon.Add(_item.InstanceID))
                    Debug.LogWarning($"[UI_Item] Backpack '{_item.Data.DisplayName}' is folded but " +
                        $"ItemStaticData.IconFolded is NOT set.");
            }

            float slotSize = _inventoryUI != null ? _inventoryUI.SlotSize : 70f;
            float slotSpacing = _inventoryUI != null ? _inventoryUI.SlotSpacing : 0f;

            Vector2Int currentSize = _item.CurrentSize;
            if (_bodyRect != null)
            {
                float widthPx = currentSize.x * slotSize + (currentSize.x - 1) * slotSpacing;
                float heightPx = currentSize.y * slotSize + (currentSize.y - 1) * slotSpacing;
                _bodyRect.sizeDelta = new Vector2(widthPx, heightPx);
                _bodyRect.localRotation = Quaternion.identity;
            }

            // ═══ Текст: просто ставим text. TMP сам построит меш
            // при следующем рендере Canvas. НЕ вызываем ForceMeshUpdate —
            // он не работает на только что созданных TMP-объектах в том же кадре. ═══
            if (_nameText != null)
            {
                _nameText.text = _item.Data.DisplayName;
            }

            if (_caliberText != null)
            {
                if (_item.Type == ItemType.Weapon && !string.IsNullOrEmpty(_item.Data.Caliber))
                {
                    _caliberText.gameObject.SetActive(true);
                    _caliberText.text = _item.Data.Caliber;
                }
                else
                {
                    _caliberText.text = string.Empty;
                    _caliberText.gameObject.SetActive(false);
                }
            }

            if (_icon != null && _iconRect != null)
            {
                Vector2Int normalSize = GetNormalIconSize(_item);
                bool iconSwapsAxes = Mathf.Abs(_item.IconBaseRotation % 180) > 0.01f;
                int iconWcells = iconSwapsAxes ? normalSize.y : normalSize.x;
                int iconHcells = iconSwapsAxes ? normalSize.x : normalSize.y;
                float iconW = iconWcells * slotSize + (iconWcells - 1) * slotSpacing;
                float iconH = iconHcells * slotSize + (iconHcells - 1) * slotSpacing;
                _iconRect.sizeDelta = new Vector2(iconW, iconH);
                _icon.preserveAspect = true;
                float visualAngle = _item.IconBaseRotation - _item.RotationAngle;
                _iconRect.localRotation = Quaternion.Euler(0, 0, visualAngle);
            }

            if (_quantityText != null && _quantityGroup != null)
            {
                if (_item.Quantity > 1)
                {
                    _quantityGroup.SetActive(true);
                    _quantityText.text = _item.Quantity.ToString();
                }
                else
                {
                    _quantityGroup.SetActive(false);
                }
            }
        }

        private static Vector2Int GetNormalIconSize(InventoryItem item)
        {
            if (item?.Data == null) return new Vector2Int(1, 1);
            var data = item.Data;
            if (item.IsFolded && data.CanFold)
                return data.SizeFolded;
            if (data.IsBackpack && data.UnfoldedIconSize.x > 0 && data.UnfoldedIconSize.y > 0)
                return data.UnfoldedIconSize;
            if (data.IsBackpack && data.BackpackWidth > 0 && data.BackpackHeight > 0)
                return new Vector2Int(data.BackpackWidth, data.BackpackHeight);
            return data.Size;
        }

        public void UpdateData(InventoryItem item)
        {
            _item = item;
            UpdateVisuals();
        }

        /// <summary>
        /// ═══ ФИКС «пропадающих названий» ═══
        /// Принудительно пересобирает мешы текстов НА СЛЕДУЮЩИЙ КАДР после refresh,
        /// когда Canvas уже пересчитал stretch-rect'ы. Вызывается из
        /// K_InventoryUI.DeferredTextRebuild для всех активных UI_Item.
        /// </summary>
        /// <summary>
        /// Принудительно пересобирает мешы текстов. Вызывается из
        /// K_InventoryUI.DeferredTextRebuild для всех активных UI_Item.
        /// </summary>
        public void ForceTextRefresh()
        {
            if (_item == null || _item.Data == null) return;
            if (!gameObject.activeInHierarchy) return;

            // ═══ Проверяем: если текст пустой после всех refresh —
            // пересоздаём TMP-объекты заново. ═══
            if (_nameText != null && _nameText.textInfo.characterCount == 0
                && !string.IsNullOrEmpty(_item.Data.DisplayName))
            {
                // Меш пустой — пересоздаём
                EnsureNameLabel();
                _nameText.text = _item.Data.DisplayName;

                if (_caliberText != null)
                {
                    if (_item.Type == ItemType.Weapon && !string.IsNullOrEmpty(_item.Data.Caliber))
                    {
                        _caliberText.gameObject.SetActive(true);
                        _caliberText.text = _item.Data.Caliber;
                    }
                    else
                    {
                        _caliberText.text = string.Empty;
                        _caliberText.gameObject.SetActive(false);
                    }
                }
            }
            else if (_nameText != null)
            {
                // Текст уже отрисован — просто обновляем значение
                _nameText.text = _item.Data.DisplayName;
                if (_caliberText != null)
                {
                    if (_item.Type == ItemType.Weapon && !string.IsNullOrEmpty(_item.Data.Caliber))
                    {
                        _caliberText.gameObject.SetActive(true);
                        _caliberText.text = _item.Data.Caliber;
                    }
                }
            }
        }
        #endregion

        #region Controller Binding
        /// <summary>
        /// Привязывает InventoryController к данному UI_Item.
        /// Используется для контейнерных сеток (Container) — K_InventoryUI вызывает
        /// sourceController.RemoveItem() при начале drag-а.
        /// </summary>
        public void BindController(InventoryController controller)
        {
            _boundController = controller;
        }

        /// <summary>
        /// Отвязывает контроллер, если привязанный объект совпадает.
        /// </summary>
        public void UnbindController(InventoryController controller)
        {
            if (_boundController == controller)
                _boundController = null;
        }
        #endregion

        #region Selection (Click Highlight)
        public void SetSelected(bool selected)
        {
            if (_selectionOverlay == null) return;
            _selectionOverlay.enabled = selected;
            _selectionOverlay.color = selected ? _selectionColor : Color.clear;
        }

        /// <summary>
        /// ФИКС БАГ (user feedback — red ghost on folded backpack):
        /// Перегрузка с кастомным цветом overlay. Используется K_InventoryUI
        /// при перетаскивании предмета на иконку рюкзака, чтобы показать
        /// валидность (зелёный) или инвалидность (красный) целевой позиции.
        /// </summary>
        public void SetSelected(bool selected, Color overlayColor)
        {
            if (_selectionOverlay == null) return;
            _selectionOverlay.enabled = selected;
            _selectionOverlay.color = selected ? overlayColor : Color.clear;
        }

        public void ClearSelection()
        {
            if (_selectionOverlay != null)
            {
                _selectionOverlay.color = Color.clear;
                _selectionOverlay.enabled = false;
            }
        }
        #endregion

        #region Pool Management

        public void ResetState()
        {
            _item = null;
            _inventoryUI = null;
            _gridType = GridType.Pockets;
            _gridX = 0;
            _gridY = 0;
            _isDragging = false;
            _boundController = null;
            ClearSelection();

            if (_icon != null)
            {
                _icon.sprite = null;
                _icon.enabled = false;
                if (_iconRect != null)
                    _iconRect.localRotation = Quaternion.identity;
            }

            if (_quantityGroup != null)
                _quantityGroup.SetActive(false);

            // ═══ ФИКС: Уничтожаем TMP-объекты при возврате в пул.
            // Они будут пересозданы в EnsureNameLabel при следующем Setup.
            // Это гарантирует чистое состояние TMP-меша. ═══
            if (_nameText != null)
            {
                Destroy(_nameText.gameObject);
                _nameText = null;
            }
            if (_caliberText != null)
            {
                Destroy(_caliberText.gameObject);
                _caliberText = null;
            }

            if (_canvasGroup != null)
            {
                _canvasGroup.interactable = false;
                _canvasGroup.blocksRaycasts = false;
                _canvasGroup.alpha = 1f;
            }

            if (_bodyRect != null)
                _bodyRect.localRotation = Quaternion.identity;
        }
        #endregion

        #region Drag & Drop (EventSystem Interfaces)
        // ФИКС БАГ (audit) #25: BeginDrag теперь:
        //   1. Проверяет left mouse button (раньше правая тоже запускала drag).
        //   2. НЕ модифицирует CanvasGroup/bodyRect ДО подтверждения StartDrag.
        //      Раньше мы прятали view на -9999 ещё до того, как source-controller
        //      подтвердил RemoveItem. При stale UI предмет оставался в source,
        //      но визуально пропадал. Теперь модификация visuals — только после
        //      успешного TryStartDrag.
        //   3. На OnEndDrag и в OnDisable возвращаем _isDragging=false,
        //      чтобы зависший drag не блокировал последующие клики.
        public void OnBeginDrag(PointerEventData eventData)
        {
            if (_item == null || _inventoryUI == null) return;
            if (eventData.button != PointerEventData.InputButton.Left) return;
            if (_isDragging) return;

            // ═══ ДИАГНОСТИКА: логируем состояние текстов ПЕРЕД drag ═══
            if (_debugLogs && _nameText != null)
            {
                int charsBefore = _nameText.textInfo.characterCount;
                float rwBefore = _nameText.rectTransform.rect.width;
                if (charsBefore == 0 && _nameText.text.Length > 0)
                {
                    Debug.LogWarning(
                        $"[TEXT-BUG] OnBeginDrag: text ALREADY empty before drag! " +
                        $"'{_item.Data?.DisplayName}', charCount=0, rectW={rwBefore:F1}");
                }
            }

            if (!_inventoryUI.TryStartDrag(this, eventData))
            {
                LogDebug($"[UI_Item] BeginDrag rejected: {_item.Data.DisplayName}");
                return;
            }

            _isDragging = true;
            if (_canvasGroup != null)
            {
                _canvasGroup.alpha = 0f;
                _canvasGroup.blocksRaycasts = false;
                _canvasGroup.interactable = false;
            }

            LogDebug($"[UI_Item] BeginDrag: {_item.Data.DisplayName}");
        }

        public void OnDrag(PointerEventData eventData)
        {
            _inventoryUI?.UpdateDragGhostPosition(eventData);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            _isDragging = false;

            // ═══ ФИКС ДУБЛИРОВАНИЯ: Восстанавливаем CanvasGroup ТОЛЬКО если
            // объект ещё активен в иерархии И предмет ещё не возвращён в контроллер.
            //
            // КРИТИЧНО: Если _inventoryUI.IsDragging == false и предмет уже
            // размещён (TryPlaceItem обработал дроп), то UI_Item мог быть
            // возвращён в пул (gameObject.SetActive(false)). В этом случае
            // activeInHierarchy == false и мы НЕ трогаем CanvasGroup.
            //
            // Если предмет "в воздухе" (drag за пределы сетки, OnDrop не стрелял),
            // то EndDragComplete запустит PostDragEndFallback, который вернёт
            // предмет и вызовет ForceRefresh. ForceRefresh → ReturnAllItemsToPool
            // → ResetState → SetActive(false). UI_Item будет корректно скрыт.
            //
            // НО: если мы сделаем alpha=1 СЕЙЧАС, а PostDragEndFallback вернёт
            // предмет и ForceRefresh создаст НОВЫЙ UI_Item, то старый UI_Item
            // (с alpha=1) может остаться видимым на 1 кадр, создавая визуальный
            // дубликат. Чтобы этого избежать, НЕ восстанавливаем alpha, если
            // предмет ещё не возвращён (drag за пределы сетки).
            // ═══
            if (_canvasGroup != null && gameObject.activeInHierarchy)
            {
                // Если drag-сессия ещё активна в K_InventoryUI (предмет "в воздухе"),
                // НЕ делаем alpha=1 — PostDragEndFallback сам восстановит через ForceRefresh.
                // Если drag-сессия уже завершена (TryPlaceItem обработал), делаем alpha=1.
                if (_inventoryUI == null || !_inventoryUI.IsDragging)
                {
                    _canvasGroup.alpha = 1f;
                    _canvasGroup.blocksRaycasts = true;
                    _canvasGroup.interactable = true;
                }
            }

            _inventoryUI?.EndDragComplete();
            LogDebug($"[UI_Item] EndDrag: {_item?.Data.DisplayName ?? "NULL"}");
        }

        protected virtual void OnDisable()
        {
            if (!_isDragging) return;
            _isDragging = false;

            if (_canvasGroup != null)
            {
                _canvasGroup.alpha = 1f;
                _canvasGroup.blocksRaycasts = true;
                _canvasGroup.interactable = true;
            }

            _inventoryUI?.EndDragComplete();
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            if (_isDragging || _item == null) return;
            _inventoryUI?.OnItemHovered(this);
            LogDebug($"[UI_Item] Hover Enter: {_item?.Data.DisplayName}");
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            if (_isDragging) return;
            _inventoryUI?.OnItemUnhovered(this);
            LogDebug($"[UI_Item] Hover Exit: {_item?.Data.DisplayName}");
        }
        public void OnPointerClick(PointerEventData eventData)
        {
            if (_isDragging || _item == null) return;

            if (eventData.button == PointerEventData.InputButton.Right)
            {
                if (K_ContextMenu.Instance != null)
                {
                    K_ContextMenu.Instance.Show(_item, eventData.position, _inventoryUI);
                }
                return;
            }
        }
        #endregion

        #region Drop Handling (на иконку раскрытого рюкзака)
        public void OnDrop(PointerEventData eventData)
        {
            if (_item == null || _inventoryUI == null) return;
            if (eventData.pointerDrag == null) return;

            // ФИКС БАГ (user feedback — duplication):
            // Если в K_InventoryUI drag-сессия НЕ активна (TryStartDrag отбойнул),
            // НЕ принимаем OnDrop. Unity всё равно стреляет OnDrop даже после abort,
            // потому что eventData.pointerDrag ещё указывает на UI_Item.
            // Без этой проверки мы бы попытались повторно разместить item, который
            // всё ещё лежит в source — получили бы дубликат.
            if (!_inventoryUI.IsDragging)
            {
                LogDebug($"[UI_Item.OnDrop] Ignored: inventory drag session not active.");
                return;
            }

            // ═══════════════════════════════════════════════════════════════
            //  БЛОК 2 (backpack-path): дроп на иконку РЮКЗАКА — кладём предмет
            //  ВНУТРЬ рюкзака через TryDropItemIntoBackpack.
            //  Сохраняет прежнее поведение (без открытия окна во время drag).
            // ═══════════════════════════════════════════════════════════════
            bool targetIsOpenableBackpack =
                _item.Data != null
                && _item.Data.IsBackpack
                && !(_item.IsFolded && !_item.Data.AlwaysShowGrid)
                && _item.HasInternalGrid;

            if (targetIsOpenableBackpack)
            {
                var draggedUI = eventData.pointerDrag.GetComponent<UI_Item>();
                if (draggedUI != null && draggedUI.Item != null)
                {
                    HandleDropFromInventory(draggedUI);
                    return;
                }
                if (_inventoryUI.IsDraggingFromEquipmentSlot)
                {
                    HandleDropFromEquipmentSlot();
                    return;
                }
            }

            // ═══════════════════════════════════════════════════════════════
            //  БЛОК 2 (swap-path): дроп предмета A на обычный предмет B
            //  (не рюкзак, либо рюкзак без открытой сетки).
            //  Делегируем в InventoryTransactionService.TrySwapItems —
            //  атомарная транзакция с snapshot/validate/execute/rollback.
            //
            //  Сервис сам ставит A на место B, а B — на старое место A
            //  (с FindFreeSpace при несовпадении габаритов).
            //  UI после успеха обновится через ForceRefresh внутри сервиса.
            //
            //  Если сервис вернул false — ничего не делаем: EndDragComplete
            //  в K_InventoryUI вернёт A на исходную позицию.
            // ═══════════════════════════════════════════════════════════════
            if (_item.Data != null)
            {
                var draggedUI = eventData.pointerDrag.GetComponent<UI_Item>();
                if (draggedUI != null && draggedUI.Item != null && draggedUI.Item != _item)
                {
                    var tx = InventoryTransactionService.Instance;
                    if (tx != null && !tx.IsTransactionActive)
                    {
                        bool ok = tx.TrySwapItems(draggedUI, this, out var err);
                        if (!ok)
                        {
                            LogDebug($"[UI_Item.OnDrop] Swap rejected: {err}");
                        }
                    }
                    return;
                }

                // Drag из слота экипировки на обычный предмет — swap slot <-> grid.
                if (_inventoryUI.IsDraggingFromEquipmentSlot)
                {
                    var tx = InventoryTransactionService.Instance;
                    if (tx != null && !tx.IsTransactionActive)
                    {
                        bool ok = tx.TrySwapEquipmentWithGridItem(this, out var err);
                        if (!ok)
                        {
                            LogDebug($"[UI_Item.OnDrop] Equip-swap rejected: {err}");
                        }
                    }
                    return;
                }
            }
        }

        /// <summary>
        /// БАГ #4 (ФИКС): дроп из инвентаря на иконку рюкзака.
        /// НЕ открывает UI-окно (иначе предмет застынет). Кладёт напрямую через
        /// TryDropItemIntoBackpack. При неудаче (нет места / цикл / навёл не полностью)
        /// возвращает false и НИЧЕГО не меняет — EndDragComplete вернёт предмет обратно.
        /// </summary>
        private void HandleDropFromInventory(UI_Item draggedUI)
        {
            var draggedItem = draggedUI.Item;
            if (draggedItem == _item) return;

            if (draggedItem.Data != null && draggedItem.Data.IsBackpack)
            {
                // ═══ НОВЫЙ ФИКС: синхронизация перед ContainsDescendant ═══
                _inventoryUI.SyncBackpackForValidationPublic(draggedItem);

                if (draggedItem.ContainsDescendant(_item.InstanceID))
                {
                    Debug.Log($"[BUG4-ONDROP] BLOCKED: cycle — cannot drop " +
                              $"'{draggedItem.Data.DisplayName}' onto '{_item.Data.DisplayName}'.");
                    return;
                }
            }

            bool ok = _inventoryUI.TryDropItemIntoBackpack(draggedUI, _item, false);
            if (!ok)
                Debug.Log($"[BUG4-ONDROP] No space in '{_item.Data.DisplayName}' " +
                          $"for '{draggedItem.Data.DisplayName}' — item will return to origin.");
        }
        private void HandleDropFromEquipmentSlot()
        {
            var slotItem = _inventoryUI.DraggedFromSlotItem;
            if (slotItem == null) return;

            // Защита от циклических ссылок — только для рюкзаков.
            if (slotItem.Data != null && slotItem.Data.IsBackpack)
            {
                // ═══ НОВЫЙ ФИКС: Принудительная синхронизация содержимого
                // экипированного рюкзака из _backpackController ПЕРЕД проверкой.
                // Без этого ContainsDescendant видит устаревший/пустой снимок. ═══
                _inventoryUI.SyncBackpackForValidationPublic(slotItem);

                if (slotItem.ContainsDescendant(_item.InstanceID))
                {
                    Debug.Log($"[BUG4-ONDROP-EQUIP] BLOCKED: cycle from equipment slot. " +
                              $"'{slotItem.Data.DisplayName}' contains '{_item.Data?.DisplayName}'.");
                    return;
                }
            }

            bool ok = _inventoryUI.TryDropItemIntoBackpack(null, _item, true);
            if (!ok)
                Debug.Log($"[BUG4-ONDROP-EQUIP] No space in '{_item.Data.DisplayName}' " +
                          $"for equip item — item will return to slot.");
        }

        #endregion

        #region Debug Helpers
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs)
                Debug.Log(message);
        }
        /// <summary>
        /// Диагностический метод. Вызывается из DeferredTextRebuild или вручную.
        /// Логирует полное состояние текстов для поиска корня бага.
        /// </summary>
        public void DiagnoseTextState(string caller)
        {
            if (_item == null || _item.Data == null) return;
            if (_nameText == null) return;

            int chars = _nameText.textInfo.characterCount;
            string text = _nameText.text;
            bool active = gameObject.activeInHierarchy;
            bool textActive = _nameText.gameObject.activeSelf;
            float rectW = _nameText.rectTransform.rect.width;
            float rectH = _nameText.rectTransform.rect.height;
            float bodyW = _bodyRect != null ? _bodyRect.rect.width : -1f;
            float bodyH = _bodyRect != null ? _bodyRect.rect.height : -1f;
            float alpha = _canvasGroup != null ? _canvasGroup.alpha : -1f;
            Vector2 anchorMin = _nameText.rectTransform.anchorMin;
            Vector2 anchorMax = _nameText.rectTransform.anchorMax;
            Vector2 sizeDelta = _nameText.rectTransform.sizeDelta;

            if (chars == 0 && text.Length > 0)
            {
                Debug.LogError(
                    $"[TEXT-DIAG] {caller}: TEXT INVISIBLE!\n" +
                    $"  Item: '{_item.Data.DisplayName}' (ID={_item.InstanceID})\n" +
                    $"  text='{text}', charCount={chars}\n" +
                    $"  nameRect: w={rectW:F2}, h={rectH:F2}\n" +
                    $"  nameRect anchors: min=({anchorMin.x},{anchorMin.y}), max=({anchorMax.x},{anchorMax.y})\n" +
                    $"  nameRect sizeDelta: ({sizeDelta.x:F2},{sizeDelta.y:F2})\n" +
                    $"  bodyRect: w={bodyW:F2}, h={bodyH:F2}\n" +
                    $"  gameObject.activeInHierarchy={active}\n" +
                    $"  nameText.gameObject.activeSelf={textActive}\n" +
                    $"  canvasGroup.alpha={alpha:F2}\n" +
                    $"  parent={(_bodyRect != null && _bodyRect.parent != null ? _bodyRect.parent.name : "null")}\n" +
                    $"  parentActive={(_bodyRect != null && _bodyRect.parent != null ? _bodyRect.parent.gameObject.activeInHierarchy.ToString() : "null")}");
            }
        }
        #endregion
    }
}