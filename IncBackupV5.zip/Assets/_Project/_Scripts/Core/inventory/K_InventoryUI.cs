﻿
using K_Incident.Core.Inventory;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Главный UI-контроллер инвентаря.
    /// Управляет сетками (карманы, рюкзак, контейнер окружения), drag&amp;drop, пулом UI_Item.
    ///
    /// ИСПРАВЛЕНИЯ (баг-фикс сессия):
    /// #БАГ2: GetSlotAt/GetGridWidth для Container использовали controller.Width
    ///        вместо реальных размеров UI-сетки → неправильный индекс слота →
    ///        жёлтая подсветка на неверных ячейках. Добавлены _currentContainerCols/Rows.
    ///        Также CalculateSnapPosition в UpdateDragCellHighlights и GetAdjustedDropPosition
    ///        исправлены на использование GetGridWidth/Height.
    /// #БАГ1: Предметы в контейнере окружения улетали за пределы сетки / зависали.
    ///        Причины: (1) SyncContainer передавал world-координату как screen-координату
    ///        в ScreenPointToLocalPointInRectangle — неверно для ScreenSpaceCamera Canvas.
    ///        (2) SyncRectTransform на itemsContainer каждый кадр перезаписывал позицию
    ///        с неправильными anchors (center вместо top-left).
    ///        (3) Репарентинг itemsContainer ломал иерархию.
    ///        Исправление: SyncContainer переписан на world-space через InverseTransformPoint
    ///        с фиксированными top-left anchors. SyncRectTransform отключается.
    /// #БАГ3: слоты блокировали raycast к предметам. Исправление: toggle raycast на
    ///        слотах — false в покое, true при drag.
    /// #БАГ PANEL: Панель surroundingsPanel теперь идеально накладывается на сетку и таскает её.
    ///
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ-ФИКС v2 (user feedback session):
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ 1 (color feedback): При наведении предмета на развёрнутый рюкзак
    ///    иконка рюкзака подсвечивалась кастомным цветом (зелёно-жёлтым valid
    ///    или красным invalid), а не обычным жёлтым hover. ФИКС: убран кастомный
    ///    цвет в двух местах UpdateDragCellHighlights, вызывается SetSelected(true)
    ///    без параметра → используется _selectionColor (обычный hover 0.35).
    ///
    ///  БАГ 2 (red fill on invalid): При invalid-позиции (свёрнутый рюкзак, цикл,
    ///    нет места) иконка рюкзака полностью заливалась красным. Причина: тот же
    ///    SetSelected(true, color) использует _selectionOverlay — Image с
    ///    anchorMin=0,0/anchorMax=1,1, который полностью заливает body предмета.
    ///    ФИКС: тот же, что и БАГ 1 — без кастомного цвета. Валидность позиции
    ///    теперь НЕ отражается на иконке рюкзака; только outline ячеек остаётся
    ///    красным/белым (через ShowDragOutline).
    ///
    ///  БАГ 3 (drop shifts 1 cell down in container windows): При drop в окно
    ///    контейнера предмет placed на 1 клетку ниже/правее outline.
    ///    Причина: GetAdjustedDropPosition использовал глобальные _currentContainerCols/Rows
    ///    (от активного окна), а не BoundController слота. Если открыто несколько
    ///    окон разного размера — CalculateSnapPosition использовал неправильные
    ///    границы, и Clamp сдвигал target. ФИКС: добавлена перегрузка
    ///    GetAdjustedDropPosition(slotX, slotY, itemSize, gridType, boundController),
    ///    которая вызывается из K_InventorySlotUI.OnDrop с _boundController.
    ///
    ///  БАГ 4 (items lost on save/load): После save/load в надетом рюкзаке
    ///    оказывались не все предметы (только верхний рюкзак, вложенные пропадали).
    ///    Причина: OnBackpackEquipped делал Resize и RebuildBackpackGrid, но НЕ
    ///    загружал _backpackContentsSerialized в _backpackController. Save и Load
    ///    сохраняли BackpackContents корректно, но UI показывал пустой рюкзак
    ///    (т.к. RefreshGrid берёт данные из _backpackController, а он был пустой).
    ///    ФИКС: в OnBackpackEquipped добавлена загрузка SavedItem'ов из
    ///    backpackItem.GetBackpackSavedItems() в _backpackController через
    ///    InventoryItem.FromSaveData + PlaceExistingItem (сохраняет InstanceID,
    ///    IsFolded, вложенные BackpackContents). После загрузки _backpackContentsSerialized
    ///    очищается (живой контроллер — источник правды).
    /// ════════════════════════════════════════════════════════════════════
    ///
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ-ФИКС v3 (второй раунд user feedback):
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ 1 v3 (duplication when rotating): Иногда при вращении предмета (R)
    ///    во время drag он дублировался. Причина: InventoryController.PlaceExistingItem
    ///    использовал CanPlaceInternal (который РАЗРЕШАЕТ стекинг) вместо CanOccupy.
    ///    Если после вращения предмет накладывался на ячейку с таким же стекающимся
    ///    предметом — CanPlaceInternal возвращал true, но BindToGrid ПЕРЕЗАПИСЫВАЛ
    ///    ячейки существующего предмета. Старый оставался в _itemCache без ячеек,
    ///    новый занимал его место → при RefreshGrid пересоздавался UI для обоих.
    ///    ФИКС: PlaceExistingItem использует CanOccupy (строгая проверка пустых
    ///    ячеек). PlaceExistingItemInFirstFreeSlot теперь вызывает PlaceExistingItem
    ///    напрямую (внутри которого CanOccupy). Также в RotateDraggedItem добавлена
    ///    защитная проверка: вращение разрешено только при активной drag-сессии
    ///    и _dragItemRemoved=true (или _draggedFromEquipmentSlot != null).
    ///
    ///  БАГ 2 v3 (red outline for folded backpack): При наведении предмета на
    ///    СВЁРНУТЫЙ рюкзак должна отображаться КРАСНАЯ ОБВОДКА footprint рюкзака.
    ///    Раньше (после фикса v2) показывался тот же жёлтый hover, что и для
    ///    развёрнутого. ФИКС: в UpdateDragCellHighlights добавлена проверка
    ///    canPlaceInBackpackIcon — если false (свёрнутый / цикл / нет места),
    ///    вызывается DrawBackpackInvalidOutline, который через ShowDragOutline
    ///    рисует красную рамку вокруг (bx, by, bw, bh) рюкзака. Жёлтая hover-
    ///    заливка в этом случае НЕ показывается. Для валидных позиций (развёрнутый
    ///    рюкзак с местом) — обычный жёлтый hover, как и раньше.
    /// ════════════════════════════════════════════════════════════════════
    ///
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ-ФИКС v4 (третий раунд user feedback — fold/unfold):
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ 1 v4 (fold/unfold через ПКМ перестаёт работать): После drag-сессии
    ///    предмет остаётся "_dragItemRemoved=true" (удалён из source, но fallback
    ///    ещё не отработал). Если в этот момент игрок вызывает fold/unfold через
    ///    ПКМ — HandleInventoryBackpackFold сбрасывал drag-состояние без возврата
    ///    предмета в origin. FindItemLocation его не находил → fold/unfold молча
    ///    abort'ил. ФИКС: перед сбросом drag-состояния проверяем, что этот item
    ///    сейчас "в воздухе" — если да, СНАЧАЛА возвращаем его в origin через
    ///    PlaceExistingItem. Только потом сбрасываем _isDragging, _dragItemRemoved,
    ///    _draggedItem и продолжаем fold/unfold.
    ///
    ///  БАГ 2 v4 (ломается одна из переносных сеток): GetControllerForGrid(Container)
    ///    ВСЕГДА возвращает _activeContainerController. Если fold/unfold вызывается
    ///    для рюкзака из НЕ активного окна — controller неправильный, item не
    ///    удаляется/не размещается → "переносная сетка перестаёт работать".
    ///    ФИКС: в HandleInventoryBackpackFold добавлен поиск controller по окнам
    ///    (_openContainerWindows). Если item — владелец окна (BackpackInstanceID
    ///    совпадает) или лежит в окне как предмет — берём Controller этого окна.
    ///    Только если не найдено — fallback на _activeContainerController.
    ///
    ///  БАГ 3 v4 (закрытие всех окон перед fold): Раньше закрывалось только активное
    ///    окно рюкзака (CloseBackpackAsContainer), а фоновые окна оставались висеть
    ///    со ссылками на уничтоженный controller. Теперь CloseAllWindowsForBackpack
    ///    закрывает ВСЕ окна этого рюкзака, корректно очищая _activeItems,
    ///    _openedBackpacks и _activeContainerController.
    /// ════════════════════════════════════════════════════════════════════
    ///
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ-ФИКС v5 (четвёртый раунд user feedback):
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ 1 v5 (дублирование при вращении — истинная причина): RefreshSlot
    ///    в ветке "uiItem.X != x || uiItem.Y != y" вызывал ReturnToPool(uiItem)
    ///    БЕЗ проверки uiItem == _draggedItem. Если во время drag вызывался
    ///    ForceRefresh (например, после вращения), и RefreshSlot для ЧУЖОЙ ячейки
    ///    находил там _draggedItem (из-за рассинхронизации _activeItems) —
    ///    _draggedItem возвращался в пул. Затем пул переиспользовал его для
    ///    другого предмета, а старая ссылка _draggedItem оставалась висеть.
    ///    При EndDragComplete item размещался заново, и появлялся дубликат:
    ///    один item в двух UI_Item (один в пуле как другой предмет,
    ///    другой — только что созданный). ФИКС: добавлена проверка
    ///    uiItem == _draggedItem перед ReturnToPool во ВСЕХ ветках RefreshSlot.
    ///    Также добавлено диагностическое логирование в RotateDraggedItem.
    ///
    ///  БАГ 2 v5 (красная обводка по позиции предмета, а не курсора): Раньше
    ///    raycast для определения backpackHit делался только по позиции КУРСОРА.
    ///    Если игрок наводил ПРЕДМЕТ (ghost) на рюкзак, но курсор был не над
    ///    рюкзаком (например, над пустой ячейкой рядом) — backpackHit не
    ///    находился, и красная обводка не рисовалась. ФИКС: перед основным
    ///    raycast-циклом делаем дополнительные raycast'ы по 4 углам + центру
    ///    ghost. Если хотя бы один попадает в UI_Item рюкзака — используем его
    ///    как backpackHit (приоритет над курсором). Это позволяет игроку
    ///    наводить ПРЕДМЕТ на рюкзак независимо от позиции курсора.
    /// ════════════════════════════════════════════════════════════════════
    ///
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ-ФИКС v6 (пятый раунд user feedback — финальные фиксы):
    /// ════════════════════════════════════════════════════════════════════
    ///  БАГ 1 v6 (раздвоение при дропе на свёрнутый рюкзак): Игрок наводит
    ///    рюкзак-A на рюкзак-B (свёрнутый), видит красную обводку, отпускает ЛКМ.
    ///    OnDrop стреляет на слот под курсором → TryPlaceItem находит
    ///    backpackInFootprint → TryDropItemIntoBackpack возвращает false
    ///    (рюкзак свёрнут) → TryPlaceItem возвращал false БЕЗ возврата item
    ///    в source. EndDragComplete через 1 кадр возвращал item в origin
    ///    через PostDragEndFallback, но в этом кадре item был "в воздухе",
    ///    что приводило к раздвоению: RefreshSlot находил старый UI_Item в
    ///    _activeItems и НЕ удалял его (т.к. item==null в ячейке), а затем
    ///    создавал новый UI_Item для того же item после возврата в origin →
    ///    два UI_Item на один InventoryItem.
    ///    ФИКС: при неудачном TryDropItemIntoBackpack — СРАЗУ возвращаем item
    ///    в source controller синхронно, помечаем _dropHandled=true, очищаем
    ///    ghost и подсветку, возвращаем draggedUI в пул. EndDragComplete потом
    ///    найдёт item уже размещённым и не будет дублировать.
    ///
    ///  БАГ 2 v6 (красная обводка без касания): v5 использовал raycast по
    ///    4 углам + центру ghost. Это давало ложные срабатывания: даже если
    ///    ghost лишь касался углом рюкзака (а визуально не пересекал его) —
    ///    уже рисовалась красная обводка. ФИКС: используем ТОЛЬКО ЦЕНТР ghost.
    ///    Это даёт интуитивное поведение: игрок должен навести ЦЕНТР предмета
    ///    на рюкзак, чтобы появилась обводка. Если центр ghost над пустой
    ///    ячейкой рядом с рюкзаком — обводки нет.
    /// ════════════════════════════════════════════════════════════════════
    /// </summary>
    public class K_InventoryUI : MonoBehaviour, K_Incident.Core.ISaveable
    {
        #region Inspector Fields

        [Header("Grid Config")]
        [SerializeField, Tooltip("Размер слота в пикселях")]
        private float _slotSize = 70f;

        [SerializeField, Tooltip("Отступ между слотами")]
        private float _slotSpacing = 0f;

        [Header("References")]
        [SerializeField] private K_InventorySetup _inventorySetup;
        [SerializeField] private TextMeshProUGUI _weightText;
        [SerializeField] private GameObject _slotPrefab;
        [SerializeField] private GameObject _uiItemPrefab;
        [SerializeField] private GameObject _dragGhostPrefab;

        [Header("Player Inventory (LEFT PANE)")]
        [SerializeField] private Transform _pocketsGrid;
        [SerializeField] private Transform _pocket2Grid;
        [SerializeField] private Transform _backpackGrid;
        [SerializeField] private GameObject _backpackPanel;
        [SerializeField] private Transform _pocketsItemsContainer;
        [SerializeField] private Transform _pocket2ItemsContainer;
        [SerializeField] private Transform _backpackItemsContainer;

        [Header("Equipment Slots")]
        [SerializeField] private K_EquipmentSlotUI _primarySlot1;
        [SerializeField] private K_EquipmentSlotUI _primarySlot2;
        [SerializeField] private K_EquipmentSlotUI _pistolSlot;
        [SerializeField] private K_EquipmentSlotUI _meleeSlot;
        [SerializeField] private K_EquipmentSlotUI _backpackSlot;

        [Header("Surroundings/Container (RIGHT PANE)")]
        [SerializeField] private GameObject _surroundingsPanel;
        [SerializeField] private Transform _surroundingsGrid;
        [SerializeField] private Transform _surroundingsItemsContainer;
        [SerializeField] private TextMeshProUGUI _containerNameText;

        // ═══════════════════════════════════════════════════════════════
        // МУЛЬТИОКОННАЯ СИСТЕМА: несколько рюкзаков открыто одновременно
        // Каждое окно — отдельный K_ContainerWindow со своей панелью/сеткой.
        // _surroundingsPanel/Grid/ItemsContainer указывают на АКТИВНОЕ окно
        // (или на оригинальные объекты для лута).
        // ═══════════════════════════════════════════════════════════════
        [Header("Multi-Window Focus System")]
        [SerializeField, Tooltip("Родитель для всех плавающих окон контейнеров. " +
            "Все окна должны быть детьми одного родителя для корректного z-order.")]
        private Transform _floatingWindowsRoot;

        private List<K_ContainerWindow> _openContainerWindows = new List<K_ContainerWindow>();
        private K_ContainerWindow _activeContainerWindow;
        private K_ContainerWindow _suspendedBackpackWindow;
        private bool _openingBackpackContainer;

        // Оригинальные ссылки (для возврата при луте)
        private GameObject _originalSurroundingsPanel;
        private Transform _originalSurroundingsGrid;
        private Transform _originalSurroundingsItemsContainer;
        // ═══ ФИКС «пропадающих названий»: корутина отложенного пересбора текстов ═══
        private Coroutine _textRebuildCoroutine;
        // ═══════════════════════════════════════════════════════════════
        // ФИЧА #2: Префаб заголовка панели контейнера (DragZone).
        // Если задан — инстанцируется при открытии рюкзака-контейнера и
        // используется как зона перетаскивания. Если null — генерируется
        // программно с параметрами ниже (обратная совместимость).
        // Размер/вид префаба настраивается в редакторе в любое время.
        // ════════════════════════════════════════════════════════════════
        [Header("Draggable Container Header (ФИЧА #2)")]
        [SerializeField, Tooltip("Префаб заголовка панели контейнера (DragZone). Если задан — " +
            "инстанцируется при открытии рюкзака-контейнера. Должен содержать RectTransform. " +
            "Текст имени рюкзака будет найден через GetComponentInChildren<TextMeshProUGUI>(). " +
            "Если null — генерируется программно с параметрами ниже.")]
        private GameObject _containerHeaderPrefab;

        [SerializeField, Tooltip("Высота заголовка панели (px). Только для программной генерации, " +
            "когда _containerHeaderPrefab не задан.")]
        private float _containerHeaderHeight = 32f;

        [SerializeField, Tooltip("Цвет фона заголовка панели. Только для программной генерации.")]
        private Color _containerHeaderColor = new Color(0.12f, 0.13f, 0.15f, 0.95f);

        [Header("Background")]
        [SerializeField, Tooltip("Объект с фоном инвентаря (Image). Raycast Target должен быть снят.")]
        private GameObject _inventoryBackground;

        [Header("Health Doll")]
        [SerializeField, Tooltip("Панель куклы здоровья. Используется во вкладке 'Здоровье'.")]
        private GameObject _healthDollPanel;

        [Header("Tab System")]
        [SerializeField, Tooltip("Панель содержимого вкладки 'Инвентарь' (сетки, слоты экипировки).")]
        private GameObject _inventoryContentPane;
        [SerializeField, Tooltip("Панель содержимого вкладки 'Здоровье' (кукла, эффекты, состояние).")]
        private GameObject _healthContentPane;
        [SerializeField, Tooltip("Кнопки вкладок. Индекс 0 = Инвентарь, индекс 1 = Здоровье.")]
        private GameObject[] _tabButtons;
        [SerializeField, Tooltip("Цвет активной кнопки вкладки.")]
        private Color _activeTabColor = new Color(1f, 0.85f, 0f, 0.8f);
        [SerializeField, Tooltip("Цвет неактивной кнопки вкладки.")]
        private Color _inactiveTabColor = new Color(0.6f, 0.6f, 0.6f, 0.5f);

        [Header("Configuration")]
        [SerializeField] private KeyCode _openCloseKey = KeyCode.Tab;
        [SerializeField] private KeyCode _rotateKey = KeyCode.R;
        [SerializeField, Tooltip("Клавиша быстрого свернуть/развернуть наведённый рюкзак в инвентаре.")]
        private KeyCode _foldKey = KeyCode.F;

        [Header("UI Colors")]
        [SerializeField] private Color _dragValidColor = new Color(0.33f, 0.55f, 0.33f, 0.7f);
        [SerializeField] private Color _dragInvalidColor = new Color(0.71f, 0.24f, 0.24f, 0.7f);
        [SerializeField] private Color _textNormalColor = new Color(0.71f, 0.73f, 0.75f);
        [SerializeField] private Color _textWarningColor = new Color(0.71f, 0.55f, 0.24f);
        [SerializeField] private Color _textCriticalColor = new Color(0.71f, 0.24f, 0.24f);

        [Header("Hover Highlight")]
        [SerializeField, Tooltip("Включить выделение предмета при наведении")]
        private bool _enableHoverHighlight = true;

        [Header("Occupied Cell Tint")]
        [SerializeField, Tooltip("Тонировка ячеек, занятых предметом. alpha=0 → выключено.")]
        private Color _occupiedCellTint = new Color(1f, 1f, 1f, 0f); // белая, но alpha=0 → невидимо

        [Header("Internal Border Hiders")]
        [SerializeField, Tooltip("Цвет перекрытия внутренних границ. Подбери под цвет фона ячейки.")]
        private Color _borderHiderColor = new Color(0.12f, 0.12f, 0.12f, 1f);
        [SerializeField, Tooltip("Толщина перекрытия границы (px). Ширина вертикальной / высота горизонтальной линии.")]
        private float _borderHiderThickness = 3f;

        [Header("Border Hider Inset (отступы от краёв ячейки)")]
        [SerializeField, Tooltip("Отступ сверху для вертикальных hider'ов. Отрицательное = выходит за верх ячейки.")]
        private float _bhInsetTop = 1f;
        [SerializeField, Tooltip("Отступ снизу для вертикальных hider'ов. Отрицательное = выходит за низ ячейки.")]
        private float _bhInsetBottom = 1f;
        [SerializeField, Tooltip("Отступ слева для горизонтальных hider'ов. Отрицательное = выходит за левый край.")]
        private float _bhInsetLeft = 1f;
        [SerializeField, Tooltip("Отступ справа для горизонтальных hider'ов. Отрицательное = выходит за правый край.")]
        private float _bhInsetRight = 1f;

        [Header("Grid Bottom Border Fix (PP)")]
        [SerializeField, Tooltip("Цвет нарисованной нижней границы. Подбери под цвет рамок ячеек.")]
        private Color _gridBottomBorderColor = new Color(0.3f, 0.3f, 0.3f, 1f);

        [Header("Internal Borders (grid lines inside items)")]
        [SerializeField, Tooltip("Если true — линии сетки внутри многоячеечных предметов " +
                                 "скрываются (предмет выглядит как единая плитка). " +
                                 "Если false (по умолчанию) — линии остаются видимыми, " +
                                 "предмет выглядит как набор отдельных ячеек с иконкой.")]
        private bool _hideBordersUnderItems = false;
        [SerializeField, Tooltip("Толщина нарисованной нижней границы (px).")]
        private float _gridBottomBorderHeight = 1f;
        [SerializeField, Tooltip("Сдвиг границы вверх от математического низа (px). Увеличь если линия обрезается.")]
        private float _gridBottomBorderOffset = 1f;

        [Header("Drag Outline Highlight")]
        [SerializeField, Tooltip("Цвет рамки при валидной позиции drag")]
        private Color _dragOutlineValidColor = new Color(1f, 0.85f, 0f, 0.8f);
        [SerializeField, Tooltip("Цвет рамки при невалидной позиции drag")]
        private Color _dragOutlineInvalidColor = new Color(0.85f, 0.15f, 0.15f, 0.8f);
        [SerializeField, Tooltip("Толщина рамки подсветки при drag (px)")]
        private float _dragOutlineThickness = 2f;

        [Header("Context Menu Style")]
        [SerializeField, Tooltip("Ассет визуального стиля контекстного меню. Создайте через Create > K Context Menu Style. " +
            "Если null — используются дефолтные значения. Редактируется в Inspector в любое время, даже вне Play-режима!")]
        private K_ContextMenuStyle _contextMenuStyle;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false; // ФИКС БАГ #46: Выключено по умолчанию

        /// <summary>Публичный доступ к флагу дебаг-логов (используется в UI_Item).</summary>
        public bool DebugLogs => _debugLogs;

        #endregion

        #region Constants

        private const int POCKET_COLUMNS = 2;
        private const int POCKET_ROWS = 2;
        private const int BACKPACK_BASE_COLS = 8;
        private const int BACKPACK_BASE_ROWS = 10;

        private const int POOL_PREWARM_COUNT = 100;
        private const float UI_REFRESH_THROTTLE = 0.3f;
        private const int GHOST_SORTING_ORDER = 32000;
        private const float DROP_FALLBACK_DELAY = 0.05f;

        private const float WEIGHT_WARNING_RATIO = 0.9f;
        private const float WEIGHT_CRITICAL_RATIO = 1.1f;
        // >>> FIX проблема 1: лимит переносных сеток (матрёшка) <<<

        // >>> END FIX <<<

        #endregion

        #region Fields
        private bool _isExecutingRefresh = false;
        private InventoryController _pocketsController;
        private InventoryController _pocket2Controller;
        private InventoryController _backpackController;
        private InventoryController _activeContainerController;
        private CanvasGroup _canvasGroup;

        [SerializeField] private K_PlayerMotor _playerMotor;

        private bool _isOpen;
        private bool _isLootingContainer;
        private bool _pendingRefresh;
        private float _lastRefreshTime;

        private bool _isDragging;
        // ═══ ФИКС БАГ 2: рюкзак, чьё содержимое сейчас загружено в _backpackController.
        // Нужен для идемпотентности OnBackpackEquipped и безопасного слива содержимого
        // при смене рюкзака без явного unequip.
        private InventoryItem _loadedBackpackItem;
        private bool _backpackEquipped;
        private UI_Item _draggedItem;
        private GameObject _dragGhost;
        private Image _dragGhostImage;
        private RectTransform _dragGhostIconRect;
        private TextMeshProUGUI _dragGhostNameText; // Название предмета на drag ghost
        private TextMeshProUGUI _dragGhostCaliberText; // Калибр на drag ghost
        private CanvasGroup _dragGhostCanvasGroup;
        private Canvas _dragGhostCanvas;
        private RectTransform _dragGhostRT;
        private Transform _rootCanvasTransform;
        private UnityEngine.Camera _rootCanvasCamera; // ИСПРАВЛЕНИЕ БАГ 2: кэш камеры для правильной конверсии координат
        private readonly List<RaycastResult> _raycastBuffer = new List<RaycastResult>(8);
        // БАГ 2 v5 ФИКС: отдельный буфер для raycast по позиции ghost (предмета, а не курсора).
        // Используется в UpdateDragCellHighlights, чтобы определить, накрывает ли
        // тащимый предмет (ghost) рюкзак — даже если курсор находится не над рюкзаком.
        private readonly List<RaycastResult> _ghostRaycastBuffer = new List<RaycastResult>(16);

        // Border hider pool
        private readonly Queue<GameObject> _borderHiderPool = new Queue<GameObject>();
        private readonly List<GameObject> _activeBorderHiders = new List<GameObject>();
        private PointerEventData _cachedEventData;
        // ФИКС БАГ #8: Кэш ссылки на EventSystem для проверки пересоздания (у PointerEventData нет публичного eventSystem)
        private EventSystem _cachedEventSystem;
        // ФИКС БАГ (user feedback — lag): throttle для UpdateDragCellHighlights (30 FPS).
        private float _lastDragHighlightTime;

        private K_EquipmentSlotUI _draggedFromEquipmentSlot;
        private InventoryItem _draggedFromSlotItem;

        // Tab system
        private int _activeTab = 0; // 0 = Инвентарь, 1 = Здоровье
        private GameObject _tabBar;
        private UnityEngine.UI.Button _tabBtnInventory;
        private UnityEngine.UI.Button _tabBtnHealth;
        /// <summary>
        /// Визуальный поворот иконки слота экипировки в момент начала drag.
        /// Нужен чтобы ghost наследовал ориентацию оружия из слота.
        /// </summary>
        private float _draggedFromSlotIconRotation = 0f;

        // Hover
        private UI_Item _hoveredItem;

        // Drag outline frame (border highlight)
        private GameObject _dragOutlineFrame;
        private Image _outlineTop, _outlineBottom, _outlineLeft, _outlineRight;
        private Transform _outlineCurrentParent;
        private Color _outlineLastColor = Color.clear;

        // Drag state: origin (for fallback on cancel)
        private GridType _dragOriginGridType;
        private int _dragOriginX, _dragOriginY;
        private int _dragOriginRotationAngle;
        private bool _dragOriginFolded;   // <<< v12: исходное fold-состояние при старте drag
        private bool _dragItemRemoved;
        private bool _dropHandled;
        private Image _dragGhostRootImage;

        // БАГ #5: Флаг того, что сейчас перетаскивается ПАНЕЛЬ (не предмет).
        // Пока true — RefreshAll откладывается (становится pending), чтобы
        // не репарентить UI_Item'ы в pool и обратно во время drag панели.
        // ForceRefresh() игнорирует этот флаг (экстренное обновление).
        private bool _isDraggingPanel;
        private K_ContainerWindow _draggedBackpackWindow;
        private bool _pendingRefreshAfterPanelDrag;

        private Vector2 _pocketsGridPadding = Vector2.zero;
        private Vector2 _pocket2GridPadding = Vector2.zero;
        private Vector2 _backpackGridPadding = Vector2.zero;
        private Vector2 _containerGridPadding = Vector2.zero;

        // Для отложенной очистки после drag из слота экипировки
        private Coroutine _equipDragCleanupCoroutine;

        // ФИКС БАГ #4: Храним реальные размеры рюкзака
        private int _currentBackpackCols = BACKPACK_BASE_COLS;
        private int _currentBackpackRows = BACKPACK_BASE_ROWS;

        // ФИКС БАГ #2+3: Храним реальные размеры UI-сетки контейнера окружения.
        // Без этого GetSlotAt использует controller.Width, который может
        // не совпадать с width, переданным в RebuildSurroundingsGrid →
        // неправильный индекс слота → жёлтая подсветка на неверных ячейках.
        private int _currentContainerCols;
        private int _currentContainerRows;

        // ФИКС БАГ #6: Фоллбэк для refresh после неудачного drop
        private bool _needsPostDragRefresh;
        private Coroutine _postDragRefreshCoroutine;

        // ═══════════════════════════════════════════════════════════════
        //  ФИКС v2: BACKPACK-AS-CONTAINER
        //  Кэш открытых рюкзаков как контейнеров (когда они НЕ надеты).
        //  Key: InstanceID рюкзака. Value: созданный InventoryController.
        //  Когда рюкзак закрывается — контроллер dispose'ится, содержимое
        //  синхронизируется в InventoryItem._backpackContentsSerialized.
        // ═══════════════════════════════════════════════════════════════
        private readonly Dictionary<string, InventoryController> _openedBackpacks = new Dictionary<string, InventoryController>();

        /// <summary>
        /// Рюкзак, который сейчас открыт как активный контейнер (через OpenContainer).
        /// null если открыт лутбокс/сундук, а не рюкзак.
        /// </summary>
        private InventoryItem _activeBackpackContainer;
        // FIX баг3: контроллер окна, в которое сейчас дропают (ставит слот перед вызовом TryPlace*).
        private InventoryController _dropTargetController;
        public void SetDropTargetController(InventoryController c) { _dropTargetController = c; }

        private readonly Queue<UI_Item> _itemPool = new Queue<UI_Item>(POOL_PREWARM_COUNT);
        private readonly Dictionary<string, UI_Item> _activeItems = new Dictionary<string, UI_Item>(200);

        private Action _onInventoryChangedHandler;
        private Action<float> _onWeightChangedHandler;
        private Action<InventoryItem, int, int> _onItemPlacedHandler;
        private Action<InventoryItem> _onItemChangedHandler;

        private Coroutine _refreshCoroutine;

        // Для синхронизации панели с сеткой
        private Coroutine _panelSyncCoroutine;

        public static event Action<InventoryController> OnContainerClosed;

        #endregion

        #region Properties

        public bool IsOpen => _isOpen;
        public bool IsLooting => _isLootingContainer;
        public bool IsDragging => _isDragging;
        public float SlotSize => _slotSize;
        public float SlotSpacing => _slotSpacing;

        public bool IsDraggingFromEquipmentSlot => _draggedFromEquipmentSlot != null && _draggedFromSlotItem != null;
        public InventoryItem DraggedFromSlotItem => _draggedFromSlotItem;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null) _canvasGroup = gameObject.AddComponent<CanvasGroup>();
            InitializeCanvasState();

            // ═══ МУЛЬТИОКОННАЯ СИСТЕМА: сохраняем оригинальные ссылки ═══
            _originalSurroundingsPanel = _surroundingsPanel;
            _originalSurroundingsGrid = _surroundingsGrid;
            _originalSurroundingsItemsContainer = _surroundingsItemsContainer;

            // Если floatingWindowsRoot не задан — создаём автоматически
            if (_floatingWindowsRoot == null && _originalSurroundingsPanel != null)
            {
                var rootObj = new GameObject("FloatingWindowsRoot", typeof(RectTransform));
                rootObj.transform.SetParent(_originalSurroundingsPanel.transform.parent, false);
                rootObj.transform.SetAsLastSibling();
                var rootRT = rootObj.GetComponent<RectTransform>();
                rootRT.anchorMin = Vector2.zero;
                rootRT.anchorMax = Vector2.one;
                rootRT.pivot = new Vector2(0.5f, 0.5f);
                rootRT.sizeDelta = Vector2.zero;
                rootRT.localScale = Vector3.one;
                _floatingWindowsRoot = rootObj.transform;
                Debug.Log("[MULTI-WIN] Auto-created FloatingWindowsRoot");
            }

            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(false);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(false);
            if (_tabBar != null) _tabBar.SetActive(false);
            if (_healthContentPane != null) _healthContentPane.SetActive(false);
            if (_inventoryContentPane != null) _inventoryContentPane.SetActive(false);

            _rootCanvasTransform = FindRootCanvas();

            if (_dragGhostPrefab != null)
            {
                _dragGhost = Instantiate(_dragGhostPrefab);
                _dragGhost.SetActive(false);

                RectTransform prefabRT = _dragGhost.GetComponent<RectTransform>();
                Image prefabImage = _dragGhost.GetComponent<Image>();
                _dragGhostRT = prefabRT;

                if (prefabImage != null)
                {
                    _dragGhostRootImage = prefabImage;
                    _dragGhostImage = CreateChildIcon(_dragGhostRT, prefabImage);
                    _dragGhostIconRect = _dragGhostImage.rectTransform;
                    prefabImage.enabled = false;
                    prefabImage.raycastTarget = false;
                }
                else
                {
                    Debug.LogError("[InventoryUI] DragGhost Prefab MISSING Image on root!");
                    _dragGhost = null;
                }

                if (_dragGhostRT != null && _dragGhostImage != null)
                {
                    _dragGhostImage.raycastTarget = false;
                    _dragGhostImage.color = Color.white;
                    _dragGhostImage.enabled = true;

                    _dragGhostCanvasGroup = _dragGhost.GetComponent<CanvasGroup>();
                    if (_dragGhostCanvasGroup == null)
                        _dragGhostCanvasGroup = _dragGhost.AddComponent<CanvasGroup>();
                    _dragGhostCanvasGroup.blocksRaycasts = false;
                    _dragGhostCanvasGroup.interactable = false;
                    _dragGhostCanvasGroup.alpha = 1f;

                    _dragGhostCanvas = _dragGhost.GetComponent<Canvas>();
                    if (_dragGhostCanvas == null)
                        _dragGhostCanvas = _dragGhost.AddComponent<Canvas>();
                    _dragGhostCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                    _dragGhostCanvas.overrideSorting = true;
                    _dragGhostCanvas.sortingOrder = GHOST_SORTING_ORDER;

                    if (_rootCanvasTransform != null)
                        _dragGhost.transform.SetParent(_rootCanvasTransform, false);
                    else
                        _dragGhost.transform.SetParent(transform.root, false);

                    // Создаём текст названия для drag ghost (слева снизу)
                    var ghostLabelObj = new GameObject("GhostName", typeof(RectTransform), typeof(TextMeshProUGUI));
                    ghostLabelObj.transform.SetParent(_dragGhostRT, false);
                    var ghostLabelRT = ghostLabelObj.GetComponent<RectTransform>();
                    ghostLabelRT.anchorMin = new Vector2(0f, 0.5f);
                    ghostLabelRT.anchorMax = new Vector2(1f, 0.5f);
                    ghostLabelRT.pivot = new Vector2(0f, 1f);
                    ghostLabelRT.anchoredPosition = new Vector2(2f, 0f);
                    ghostLabelRT.sizeDelta = new Vector2(-4f, 12f);
                    ghostLabelRT.localScale = Vector3.one;

                    _dragGhostNameText = ghostLabelObj.GetComponent<TextMeshProUGUI>();
                    _dragGhostNameText.fontSize = 10f;
                    _dragGhostNameText.color = new Color(1f, 1f, 1f, 0.85f);
                    _dragGhostNameText.alignment = TextAlignmentOptions.Left;
                    _dragGhostNameText.verticalAlignment = VerticalAlignmentOptions.Top;
                    _dragGhostNameText.raycastTarget = false;
                    _dragGhostNameText.overflowMode = TextOverflowModes.Truncate;
                    _dragGhostNameText.textWrappingMode = TextWrappingModes.NoWrap;
                    _dragGhostNameText.fontStyle = FontStyles.Bold;
                    var ghostShadow = ghostLabelObj.AddComponent<Shadow>();
                    ghostShadow.effectColor = new Color(0f, 0f, 0f, 0.7f);
                    ghostShadow.effectDistance = new Vector2(1f, -1f);

                    // Создаём текст калибра для drag ghost (под названием)
                    var ghostCalObj = new GameObject("GhostCaliber", typeof(RectTransform), typeof(TextMeshProUGUI));
                    ghostCalObj.transform.SetParent(_dragGhostRT, false);
                    var ghostCalRT = ghostCalObj.GetComponent<RectTransform>();
                    ghostCalRT.anchorMin = new Vector2(0f, 0f);
                    ghostCalRT.anchorMax = new Vector2(1f, 0f);
                    ghostCalRT.pivot = new Vector2(0f, 0f);
                    ghostCalRT.anchoredPosition = new Vector2(2f, 2f);
                    ghostCalRT.sizeDelta = new Vector2(-4f, 11f);
                    ghostCalRT.localScale = Vector3.one;

                    _dragGhostCaliberText = ghostCalObj.GetComponent<TextMeshProUGUI>();
                    _dragGhostCaliberText.fontSize = 9f;
                    _dragGhostCaliberText.color = new Color(1f, 1f, 1f, 0.6f);
                    _dragGhostCaliberText.alignment = TextAlignmentOptions.Left;
                    _dragGhostCaliberText.verticalAlignment = VerticalAlignmentOptions.Bottom;
                    _dragGhostCaliberText.raycastTarget = false;
                    _dragGhostCaliberText.overflowMode = TextOverflowModes.Truncate;
                    _dragGhostCaliberText.textWrappingMode = TextWrappingModes.NoWrap;
                    var ghostCalShadow = ghostCalObj.AddComponent<Shadow>();
                    ghostCalShadow.effectColor = new Color(0f, 0f, 0f, 0.7f);
                    ghostCalShadow.effectDistance = new Vector2(1f, -1f);
                }
            }

            // ФИКС БАГ #7: НЕ создаём _cachedEventData здесь.
            // Он будет создан лениво в UpdateDragCellHighlights() с правильным EventSystem.

            PreWarmPool(POOL_PREWARM_COUNT);
            DisableLayoutOnItemContainers();
            SetupItemsContainerRaycasts();
            SetupBackgroundRaycast();

            // ═══════════════════════════════════════════════════════════════
            // ИСПРАВЛЕНИЕ БАГ 3: Items containers ВЫШЕ grid'ов в иерархии
            // Без этого слоты сетки (с raycastTarget Image) блокируют
            // клики по предметам, лежащим в itemsContainer.
            // ═══════════════════════════════════════════════════════════════
            if (_pocketsItemsContainer != null && _pocketsGrid != null)
                _pocketsItemsContainer.SetAsLastSibling();
            if (_pocket2ItemsContainer != null && _pocket2Grid != null)
                _pocket2ItemsContainer.SetAsLastSibling();
            if (_backpackItemsContainer != null && _backpackGrid != null)
                _backpackItemsContainer.SetAsLastSibling();
            if (_surroundingsItemsContainer != null && _surroundingsGrid != null)
                _surroundingsItemsContainer.SetAsLastSibling();

            // ФИКС: Если itemsContainer внутри grid'а — GridLayoutGroup сломает его.
            // Защищаем до BuildAllGrids (который в Start).
            ProtectItemsContainersFromLayout();

            // Автосоздание контекстного меню (если ещё нет)
            EnsureContextMenu();
        }

        private void Start()
        {
            if (!InitializeReferences())
            {
                enabled = false;
                return;
            }
            if (_playerMotor == null)
                _playerMotor = FindFirstObjectByType<K_PlayerMotor>();
            BuildAllGrids();
            SubscribeToEvents();
            UpdateWeightDisplay(0f);
            ForceRefresh();

            // ФИКС БАГ (audit) #4 / user feedback — equipment backpack исчезает после F9:
            // K_InventoryUI реализует ISaveable, чтобы SaveManager мог сохранять и
            // восстанавливать экипированные предметы (Primary1, Primary2, Pistol,
            // Melee, Backpack) вместе с содержимым надетого рюкзака.
            // Без этого F5/F9 терял всё, что было надето, — предметы просто исчезали.
            K_Incident.Core.K_SaveManager.Instance?.Register(this);
        }

        // ═══════════════════════════════════════════════════════════════
        //  ФИКС БАГ (audit) #4: ISaveable implementation для equipment.
        //  SaveID = "Player_Equipment". Сохраняет все 5 equipment slots
        //  (Primary1, Primary2, Pistol, Melee, Backpack) и содержимое
        //  надетого рюкзака (через BackpackContents).
        // ═══════════════════════════════════════════════════════════════
        public string SaveID => "Player_Equipment";
        public bool IsDirty { get; set; } = true;

        public void Save(System.IO.BinaryWriter writer)
        {
            // v12: синхронизируем живые контроллеры открытых рюкзаков в их
            // _backpackContentsSerialized, чтобы F5 при открытом окне не терял содержимое.
            foreach (var kvp in _openedBackpacks)
            {
                if (kvp.Value == null) continue;
                var bpItem = FindItemByInstanceId(uint.Parse(kvp.Key));
                if (bpItem != null)
                {
                    var live = kvp.Value.GetSaveData()?.GetItems();
                    if (live != null) bpItem.ReplaceBackpackContents(live);
                }
            }
            // Сохраняем 5 слотов экипировки в фиксированном порядке.
            // Каждый слот: itemCount (0 = пусто, 1 = занято) + SavedItem.
            var slots = new K_EquipmentSlotUI[]
            {
                _primarySlot1, _primarySlot2, _pistolSlot, _meleeSlot, _backpackSlot
            };

            // Сначала синхронизируем содержимое надетого рюкзака в его _backpackContentsSerialized,
            // чтобы оно попало в save.
            if (_backpackSlot != null && _backpackSlot.EquippedItem != null && _backpackController != null)
            {
                var savedItems = _backpackController.GetSaveData()?.GetItems()
                                 ?? System.Array.Empty<SavedItem>();
                _backpackSlot.EquippedItem.ReplaceBackpackContents(savedItems);
            }

            foreach (var slot in slots)
            {
                if (slot == null || slot.EquippedItem == null)
                {
                    writer.Write(0); // пусто
                    continue;
                }
                writer.Write(1); // занято
                var saved = slot.EquippedItem.ToSaveData(0, 0);
                WriteSavedItemEquipment(writer, saved);
            }
        }

        public void Load(System.IO.BinaryReader reader)
        {
            var slots = new K_EquipmentSlotUI[]
            {
                _primarySlot1, _primarySlot2, _pistolSlot, _meleeSlot, _backpackSlot
            };

            // Снимаем всё, что сейчас надето (если было).
            foreach (var slot in slots)
            {
                if (slot != null && slot.EquippedItem != null)
                    slot.SetEquippedItem(null);
            }

            // Если был надет рюкзак — очищаем _backpackController.
            if (_backpackController != null)
            {
                _backpackController.Clear();
                OnBackpackUnequipped();
            }

            var db = K_InventorySetup.DatabaseInstance;
            if (db == null)
            {
                Debug.LogWarning("[K_InventoryUI.Load] No database — equipment load skipped.");
                return;
            }

            // Загружаем 5 слотов.
            for (int i = 0; i < slots.Length; i++)
            {
                int hasItem = reader.ReadInt32();
                if (hasItem == 0) continue;
                if (slots[i] == null) continue;

                var saved = ReadSavedItemEquipment(reader);
                if (!saved.IsValid()) continue;

                var template = db.GetItemData(saved.ItemID);
                if (template == null)
                {
                    Debug.LogWarning($"[K_InventoryUI.Load] Template '{saved.ItemID}' not found — skipping slot {i}.");
                    continue;
                }

                var item = InventoryItem.FromSaveData(saved, template);
                if (item == null) continue;

                slots[i].SetEquippedItem(item);
                if (slots[i].SlotType == EquipmentSlotType.Backpack && item.Data.IsBackpack)
                    OnBackpackEquipped(item);
            }

            ForceRefresh();
        }

        // Рекурсивная запись SavedItem (включая BackpackContents) — БЕЗ width/height,
        // потому что equipment не имеет grid-позиции.
        private void WriteSavedItemEquipment(System.IO.BinaryWriter writer, SavedItem item)
        {
            writer.Write(item.ItemID);
            writer.Write(item.InstanceID);
            writer.Write(item.Quantity);
            writer.Write(item.Durability);
            writer.Write(item.IsRotated);
            writer.Write(item.IsFolded);
            int contentsCount = item.BackpackContents?.Count ?? 0;
            writer.Write(contentsCount);
            if (contentsCount > 0)
                foreach (var inner in item.BackpackContents)
                    WriteSavedItemEquipment(writer, inner);
        }

        private SavedItem ReadSavedItemEquipment(System.IO.BinaryReader reader)
        {
            var item = new SavedItem
            {
                ItemID = reader.ReadString(),
                InstanceID = reader.ReadUInt32(),
                X = 0,
                Y = 0,
                Quantity = Mathf.Max(1, reader.ReadInt32()),
                Durability = Mathf.Max(0, reader.ReadInt32()),
                IsRotated = reader.ReadBoolean(),
                IsFolded = reader.ReadBoolean()
            };
            int contentsCount = reader.ReadInt32();
            if (contentsCount > 0)
            {
                item.BackpackContents = new List<SavedItem>(contentsCount);
                for (int j = 0; j < contentsCount; j++)
                    item.BackpackContents.Add(ReadSavedItemEquipment(reader));
            }
            return item;
        }
        /// <summary>
        /// Гарантирует, что itemsContainer не управляется GridLayoutGroup родителя.
        /// Вызывается в Awake для всех 4 контейнеров, чтобы защитить от ошибки
        /// иерархии (itemsContainer внутри grid'а).
        /// </summary>

        private void Update()
        {
            if (Input.GetKeyDown(_openCloseKey)) ToggleInventory();

            if (_isDragging)
            {
                if (Input.GetKeyDown(_rotateKey))
                    RotateDraggedItem();
            }

            // F сворачивает/разворачивает ТАЩИМЫЙ рюкзак (только во время drag).
            if (_isOpen && _isDragging && Input.GetKeyDown(_foldKey))
            {
                var foldItem = _draggedItem != null ? _draggedItem.Item : _draggedFromSlotItem;
                if (foldItem != null && foldItem.CanFold)
                {
                    if (foldItem.IsFolded)
                    {
                        // ── РАЗВОРАЧИВАЕМ (всегда можно) ──
                        bool ok = foldItem.ToggleFold(contentsEmpty: true);
                        if (ok)
                        {
                            if (_dragGhostImage != null)
                                _dragGhostImage.sprite = foldItem.CurrentIcon;
                            UpdateGhostSize();
                            UpdateGhostRotation();
                            UpdateDragCellHighlights();
                        }
                    }
                    else
                    {
                        // ── СВОРАЧИВАЕМ (только если пуст) ──
                        SyncBackpackContentsBeforeFold(foldItem);
                        if (!IsBackpackContentsEmpty(foldItem))
                        {
                            Debug.Log($"[FOLD-F] Cannot fold '{foldItem.Data?.DisplayName}' — not empty!");
                        }
                        else
                        {
                            // ✅ ФИКС 1: Закрываем ВСЕ окна-контейнеры этого рюкзака
                            // ДО сворачивания, чтобы переносные сетки не оставались висеть.
                            CloseAllWindowsForBackpack(foldItem);

                            bool ok = foldItem.ToggleFold(contentsEmpty: true);
                            if (ok)
                            {
                                if (_dragGhostImage != null)
                                    _dragGhostImage.sprite = foldItem.CurrentIcon;
                                UpdateGhostSize();
                                UpdateGhostRotation();
                                UpdateDragCellHighlights();
                            }
                        }
                    }
                }
            }
        }
        private void ProtectItemsContainersFromLayout()
        {
            ProtectFromLayout(_pocketsGrid, _pocketsItemsContainer);
            ProtectFromLayout(_pocket2Grid, _pocket2ItemsContainer);
            ProtectFromLayout(_backpackGrid, _backpackItemsContainer);
            ProtectFromLayout(_surroundingsGrid, _surroundingsItemsContainer);
        }

        private void ProtectFromLayout(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;
            if (itemsContainer.parent == grid)
            {
                var le = itemsContainer.GetComponent<LayoutElement>();
                if (le == null) le = itemsContainer.gameObject.AddComponent<LayoutElement>();
                le.ignoreLayout = true;
                var graphic = itemsContainer.GetComponent<Graphic>();
                if (graphic != null) graphic.raycastTarget = false;
                // itemsContainer должен быть ВЫШЕ слотов для правильного raycast
                itemsContainer.SetAsLastSibling();
            }
        }



        private void OnDestroy()
        {
            // ФИКС БАГ (audit) #4: Unregister из SaveManager, чтобы SaveManager
            // не держал ссылку на уничтоженный K_InventoryUI.
            K_Incident.Core.K_SaveManager.Instance?.Unregister(this);

            UnsubscribeFromEvents();
            UnsubscribeFromContainerEvents();
            ClearPooledItems();
            if (_dragGhost != null) Destroy(_dragGhost);
            if (_panelSyncCoroutine != null) StopCoroutine(_panelSyncCoroutine);
        }

        #endregion

        #region Initialization

        private Transform FindRootCanvas()
        {
            var parentCanvas = GetComponentInParent<Canvas>();
            if (parentCanvas != null)
            {
                while (parentCanvas.transform.parent != null && parentCanvas.transform.parent.GetComponent<Canvas>() != null)
                    parentCanvas = parentCanvas.transform.parent.GetComponent<Canvas>();
                // ИСПРАВЛЕНИЕ БАГ 2: кэшируем камеру корневого Canvas
                _rootCanvasCamera = parentCanvas.renderMode == RenderMode.ScreenSpaceCamera
                    ? parentCanvas.worldCamera : null;
                return parentCanvas.transform;
            }
            var fallback = FindFirstObjectByType<Canvas>();
            if (fallback != null)
                _rootCanvasCamera = fallback.renderMode == RenderMode.ScreenSpaceCamera
                    ? fallback.worldCamera : null;
            return fallback?.transform;
        }

        private void InitializeCanvasState()
        {
            _canvasGroup.alpha = 0f;
            _canvasGroup.interactable = false;
            _canvasGroup.blocksRaycasts = false;
        }

        private Image CreateChildIcon(RectTransform parent, Image source)
        {
            var childObj = new GameObject("GhostIcon", typeof(RectTransform), typeof(Image));
            childObj.transform.SetParent(parent, false);

            var childRT = childObj.GetComponent<RectTransform>();
            childRT.anchorMin = new Vector2(0.5f, 0.5f);
            childRT.anchorMax = new Vector2(0.5f, 0.5f);
            childRT.pivot = new Vector2(0.5f, 0.5f);
            childRT.anchoredPosition = Vector2.zero;
            childRT.localScale = Vector3.one;
            childRT.localRotation = Quaternion.identity;

            var childImage = childObj.GetComponent<Image>();
            childImage.sprite = source.sprite;
            childImage.color = Color.white;
            childImage.type = source.type;
            childImage.preserveAspect = false;
            childImage.raycastTarget = false;
            childImage.enabled = true;

            return childImage;
        }

        private void SetupItemsContainerRaycasts()
        {
            var containers = new[] { _pocketsItemsContainer, _pocket2ItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                // Отключаем raycast на самом контейнере (чтобы он не блокировал предметы)
                var graphic = container.GetComponent<Graphic>();
                if (graphic != null) graphic.raycastTarget = false;
                // ФИКС MissingComponentException: CanvasGroup ДОЛЖЕН быть на каждом контейнере.
                var cg = container.GetComponent<CanvasGroup>();
                if (cg == null)
                    cg = container.gameObject.AddComponent<CanvasGroup>();
                cg.blocksRaycasts = true;
                cg.interactable = true;
                cg.alpha = 1f;
            }
        }

        private void SetupBackgroundRaycast()
        {
            if (_inventoryBackground != null)
            {
                var bgGraphic = _inventoryBackground.GetComponent<Graphic>();
                if (bgGraphic != null) bgGraphic.raycastTarget = false;
            }
        }

        private bool InitializeReferences()
        {
            if (_inventorySetup == null)
                _inventorySetup = FindFirstObjectByType<K_InventorySetup>();

            _pocketsController = _inventorySetup?.PocketsController;
            _pocket2Controller = _inventorySetup?.Pocket2Controller;
            _backpackController = _inventorySetup?.BackpackController;

            if (_pocketsController == null || _pocket2Controller == null || _backpackController == null)
            {
                Debug.LogError("[InventoryUI] Controllers are null! Check K_InventorySetup.");
                return false;
            }
            return true;
        }

        private void PreWarmPool(int count)
        {
            if (_uiItemPrefab == null) return;
            for (int i = 0; i < count; i++)
            {
                var item = CreateNewPooledItem();
                if (item != null) _itemPool.Enqueue(item);
            }
        }

        private UI_Item CreateNewPooledItem()
        {
            if (_uiItemPrefab == null) return null;
            // БАГ #5: Создаём в pool parent, не в transform корня инвентаря.
            var newItem = Instantiate(_uiItemPrefab, GetPoolParent()).GetComponent<UI_Item>();
            if (newItem == null) return null;
            newItem.gameObject.SetActive(false);
            var cg = newItem.GetComponent<CanvasGroup>();
            if (cg == null) cg = newItem.gameObject.AddComponent<CanvasGroup>();
            cg.alpha = 1f;
            cg.interactable = true;
            cg.blocksRaycasts = true;
            return newItem;
        }

        private void DisableLayoutOnItemContainers()
        {
            var containers = new[] { _pocketsItemsContainer, _pocket2ItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                var grid = container.GetComponent<GridLayoutGroup>();
                if (grid != null) grid.enabled = false;
                foreach (var graphic in container.GetComponents<Graphic>())
                    graphic.raycastTarget = false;
            }
        }

        #endregion

        #region Grid Management

        private void BuildAllGrids()
        {
            // Диагностика: проверяем назначения Inspector
            if (_pocketsGrid == null) Debug.LogError("[InventoryUI] _pocketsGrid NOT assigned!");
            if (_pocket2Grid == null) Debug.LogError("[InventoryUI] _pocket2Grid NOT assigned!");
            if (_pocket2ItemsContainer == null) Debug.LogError("[InventoryUI] _pocket2ItemsContainer NOT assigned!");
            if (_pocketsItemsContainer == null) Debug.LogError("[InventoryUI] _pocketsItemsContainer NOT assigned!");

            BuildGrid(_pocketsGrid, POCKET_COLUMNS * POCKET_ROWS, POCKET_COLUMNS, GridType.Pockets);
            BuildGrid(_pocket2Grid, POCKET_COLUMNS * POCKET_ROWS, POCKET_COLUMNS, GridType.Pocket2);
            // Рюкзак: не строим дефолтную сетку. Сетка строится только при экипировке рюкзака.
            SetupEquipmentSlots();

            // ═══════════════════════════════════════════════════════════════
            // ФИКС POCKET2: Репарентим itemsContainer внутрь grid'а для ВСЕХ сеток.
            // Это тот же фикс, что уже применён для _surroundingsItemsContainer
            // (см. RebuildSurroundingsGrid). Без репарентинга:
            //   1) OnDrop не стреляет — raycast блокируется элементами между
            //      itemsContainer и grid (разные родители в иерархии).
            //   2) Позиционирование предметов ломается — SyncContainer через
            //      world-space хрупок при разных Canvas/scaling.
            //   3) Предмет телепортируется назад — TryPlaceItem не вызывается.
            // ════════════════════════════════════════════════════════════════
            ReparentItemsContainerIntoGrid(_pocketsGrid, _pocketsItemsContainer);
            ReparentItemsContainerIntoGrid(_pocket2Grid, _pocket2ItemsContainer);
            ReparentItemsContainerIntoGrid(_backpackGrid, _backpackItemsContainer);
            // surroundings — уже репарентится в RebuildSurroundingsGrid

            EnsureItemsContainersOnTop();

            // ФИКС СИЛУЭТОВ: После репарентинга itemsContainer'ов внутрь grid'ов,
            // LayoutGroup может пересчитать layout. Обновляем equipment слоты,
            // чтобы силуэты корректно отображались.
            _primarySlot1?.Refresh();
            _primarySlot2?.Refresh();
            _pistolSlot?.Refresh();
            _meleeSlot?.Refresh();
            _backpackSlot?.Refresh();
        }

        /// <summary>
        /// Гарантирует, что itemsContainer для каждой сетки находится ПОСЛЕ всех слотов
        /// в иерархии siblings. Без этого после BuildGrid / RebuildGrid новые слоты
        // оказываются выше itemsContainer → блокируют OnDrop и клики по предметам.
        /// </summary>
        private void EnsureItemsContainersOnTop()
        {
            EnsureContainerAboveGrid(_pocketsGrid, _pocketsItemsContainer);
            EnsureContainerAboveGrid(_pocket2Grid, _pocket2ItemsContainer);
            EnsureContainerAboveGrid(_backpackGrid, _backpackItemsContainer);
            EnsureContainerAboveGrid(_surroundingsGrid, _surroundingsItemsContainer);

            // FIX БАГ 1: Гарантируем порядок иерархии в окнах-контейнерах.
            foreach (var window in _openContainerWindows)
            {
                if (window == null || window.GridRect == null || window.ItemsContainer == null) continue;
                EnsureContainerAboveGrid(window.GridRect, window.ItemsContainer);
            }
        }

        /// <summary>
        /// Если itemsContainer — ребёнок того же parent'а что и grid,
        /// перемещает его в конец (выше слотов). Если разные родители —
        /// просто SetAsLastSibling внутри своего parent'а.
        /// </summary>
        private void EnsureContainerAboveGrid(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;
            // Если itemsContainer внутри grid (как surroundings container) —
            // просто SetAsLastSibling внутри grid.
            if (itemsContainer.parent == grid)
            {
                itemsContainer.SetAsLastSibling();
                return;
            }
            // Если общий родитель — itemsContainer должен быть после grid.
            if (itemsContainer.parent == grid.parent)
            {
                itemsContainer.SetAsLastSibling();
                return;
            }
            // Разные родители — просто гарантировать последний sibling
            itemsContainer.SetAsLastSibling();
        }

        /// <summary>
        /// ФИКС POCKET2: Репарентит itemsContainer внутрь grid'а.
        /// Это гарантирует:
        ///   1) Правильное позиционирование (общая система координат, anchoredPosition=(0,0)
        ///      совпадает с top-left grid'а — CreateUIItem работает корректно).
        ///   2) Raycast: предметы гарантированно ВЫШЕ слотов в иерархии
        ///      (SetAsLastSibling), клики не блокируются другими UI-элементами.
        ///   3) OnDrop на слотах стреляет корректно.
        /// ignoreLayout=true исключает itemsContainer из GridLayoutGroup.
        /// SyncRectTransform отключается — он больше не нужен.
        /// CanvasGroup добавляется/настраивается для корректного raycast.
        /// </summary>
        private void ReparentItemsContainerIntoGrid(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;
            if (itemsContainer.parent == grid) return; // Уже внутри

            // Отключаем SyncRectTransform — больше не нужен
            var syncRT = itemsContainer.GetComponent<SyncRectTransform>();
            if (syncRT != null)
                syncRT.enabled = false;

            // ВАЖНО: LayoutElement.ignoreLayout=true ДОЛЖЕН быть добавлен ДО SetParent,
            // иначе GridLayoutGroup успеет перестроить layout и сломать позиции слотов.
            var layoutElem = itemsContainer.GetComponent<LayoutElement>();
            if (layoutElem == null)
                layoutElem = itemsContainer.gameObject.AddComponent<LayoutElement>();
            layoutElem.ignoreLayout = true;

            // CanvasGroup — ДОЛЖЕН быть на itemsContainer
            // blocksRaycasts = true: дети (предметы) получают raycast для OnBeginDrag
            // Если false — ВСЕ дети исключаются из raycast → нельзя взять предмет
            var canvasGroup = itemsContainer.GetComponent<CanvasGroup>();
            if (canvasGroup == null)
                canvasGroup = itemsContainer.gameObject.AddComponent<CanvasGroup>();
            canvasGroup.blocksRaycasts = true;
            canvasGroup.interactable = true;
            canvasGroup.alpha = 1f;

            // Репарентим внутрь grid'а (LayoutElement уже добавлен → GridLayoutGroup
            // не будет управлять itemsContainer как ячейкой)
            itemsContainer.SetParent(grid, false);
            itemsContainer.SetAsLastSibling();

            // ФИКС ВИДИМОСТИ: Форсируем пересчёт layout после репарентинга.
            // Без этого GridLayoutGroup может "съесть" размер itemsContainer или
            // позиция слотов может быть неправильной.
            var gridRT = grid.GetComponent<RectTransform>();
            if (gridRT != null)
                LayoutRebuilder.ForceRebuildLayoutImmediate(gridRT);

            // ФИКС ВИДИМОСТИ: Явно устанавливаем anchors/pivot/size/position
            // itemsContainer'а после репарентинга. SetParent(false) сбрасывает
            // локальные свойства, но SyncContainer (вызывается позже из ForceRefresh)
            // не всегда успевает до первого рендера.
            var itemsRT = itemsContainer.GetComponent<RectTransform>();
            if (itemsRT != null && gridRT != null)
            {
                itemsRT.anchorMin = new Vector2(0f, 1f);
                itemsRT.anchorMax = new Vector2(0f, 1f);
                itemsRT.pivot = new Vector2(0f, 1f);
                itemsRT.sizeDelta = gridRT.sizeDelta;
                itemsRT.anchoredPosition = Vector2.zero;
                itemsRT.localScale = Vector3.one;
                itemsRT.localRotation = Quaternion.identity;
            }

            Debug.Log($"[InventoryUI] Reparented '{itemsContainer.name}' into grid '{grid.name}', " +
                $"grid.sizeDelta={gridRT?.sizeDelta}, items.sizeDelta={itemsRT?.sizeDelta}");
        }

        private void SetupEquipmentSlots()
        {
            _primarySlot1?.Initialize(this, EquipmentSlotType.Primary);
            _primarySlot2?.Initialize(this, EquipmentSlotType.Primary);
            _pistolSlot?.Initialize(this, EquipmentSlotType.Pistol);
            _meleeSlot?.Initialize(this, EquipmentSlotType.Melee);
            _backpackSlot?.Initialize(this, EquipmentSlotType.Backpack);

            // Диагностика: проверяем силуэты слотов
            Debug.Log($"[InventoryUI] Equipment slots after Initialize:");
            Debug.Log($"  Primary1: occupied={_primarySlot1?.IsOccupied}, icon={_primarySlot1 != null}");
            Debug.Log($"  Primary2: occupied={_primarySlot2?.IsOccupied}, icon={_primarySlot2 != null}");
            Debug.Log($"  Pistol:   occupied={_pistolSlot?.IsOccupied}, icon={_pistolSlot != null}");
            Debug.Log($"  Melee:    occupied={_meleeSlot?.IsOccupied}, icon={_meleeSlot != null}");
            Debug.Log($"  Backpack: occupied={_backpackSlot?.IsOccupied}, icon={_backpackSlot != null}");
        }

        private void BuildGrid(Transform parent, int slotCount, int columns, GridType gridType)
        {
            if (parent == null || _slotPrefab == null) return;
            var containerToPreserve = GetItemsContainer(gridType);
            // ФИКС: Если itemsContainer — ребёнок grid'а, GridLayoutGroup будет
            // управлять его размером и позицией как обычной ячейкой. Это ломает
            // отображение предметов. Добавляем LayoutElement.ignoreLayout=true.
            if (containerToPreserve != null && containerToPreserve.parent == parent)
            {
                var le = containerToPreserve.GetComponent<LayoutElement>();
                if (le == null) le = containerToPreserve.gameObject.AddComponent<LayoutElement>();
                le.ignoreLayout = true;
                // Также отключаем raycastTarget на Graphic, чтобы не блокировал слоты
                var graphic = containerToPreserve.GetComponent<Graphic>();
                if (graphic != null) graphic.raycastTarget = false;
            }
            ClearGrid(parent, containerToPreserve);
            SetupGridLayout(parent, columns);
            CacheGridLayoutPadding(parent, gridType);

            for (int i = 0; i < slotCount; i++)
            {
                var slot = Instantiate(_slotPrefab, parent);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % columns;
                    int y = i / columns;
                    slotUI.Setup(x, y, gridType, this);
                }
            }
            // Явно выставляем размер сетки, чтобы он соответствовал количеству слотов,
            // а не старому размеру из префаба (например 280 для 2×4 вместо 140 для 2×2).
            // Сохраняем мировую позицию top-left угла, чтобы сетка не прыгнула после смены anchors.
            var gridRT = parent.GetComponent<RectTransform>();
            var gridLayout = parent.GetComponent<GridLayoutGroup>();
            if (gridLayout != null && gridRT != null)
            {
                Vector3[] corners = new Vector3[4];
                gridRT.GetWorldCorners(corners);
                Vector3 savedWorldTopLeft = corners[1];

                int rows = Mathf.CeilToInt((float)slotCount / columns);
                float padLeft = gridLayout.padding.left;
                float padRight = gridLayout.padding.right;
                float padTop = gridLayout.padding.top;
                float padBot = gridLayout.padding.bottom;
                float w = padLeft + columns * _slotSize + (columns - 1) * _slotSpacing + padRight;
                float h = padTop + rows * _slotSize + (rows - 1) * _slotSpacing + padBot;
                gridRT.anchorMin = new Vector2(0f, 1f);
                gridRT.anchorMax = new Vector2(0f, 1f);
                gridRT.pivot = new Vector2(0f, 1f);
                gridRT.sizeDelta = new Vector2(w, h);

                // Восстанавливаем позицию top-left угла в новом anchor-пространстве
                if (gridRT.parent != null)
                {
                    Vector2 localTL = gridRT.parent.InverseTransformPoint(savedWorldTopLeft);
                    RectTransform pr = gridRT.parent as RectTransform;
                    if (pr != null) localTL -= new Vector2(pr.rect.xMin, pr.rect.yMax);
                    gridRT.anchoredPosition = localTL;
                }
            }
            LayoutRebuilder.ForceRebuildLayoutImmediate(parent.GetComponent<RectTransform>());
            DrawGridBottomBorder(parent, columns, slotCount / columns, GetPaddingForGrid(gridType));

            // ФИКС: После создания слотов itemsContainer должен быть выше них.
            // Иначе itemsContainer (CanvasGroup.blocksRaycasts=true) блокирует
            // raycast к слотам → OnDrop не стреляет → предмет телепортируется назад.
            var container = GetItemsContainer(gridType);
            if (container != null)
                EnsureContainerAboveGrid(parent, container);
        }

        private Vector2 GetPaddingForGrid(GridType type) => type switch
        {
            GridType.Pockets => _pocketsGridPadding,
            GridType.Pocket2 => _pocket2GridPadding,
            GridType.Backpack => _backpackGridPadding,
            GridType.Container => _containerGridPadding,
            _ => Vector2.zero
        };

        private void CacheGridLayoutPadding(Transform grid, GridType gridType)
        {
            if (grid == null) return;

            var layout = grid.GetComponent<GridLayoutGroup>();
            if (layout != null)
            {
                Vector2 padding = new Vector2(layout.padding.left, layout.padding.top);

                switch (gridType)
                {
                    case GridType.Pockets: _pocketsGridPadding = padding; break;
                    case GridType.Pocket2: _pocket2GridPadding = padding; break;
                    case GridType.Backpack: _backpackGridPadding = padding; break;
                    case GridType.Container: _containerGridPadding = padding; break;
                }
            }
        }

        /// <summary>
        /// Удаляет детей grid'а (слоты), но СОХРАНЯЕТ itemsContainer.
        /// Если itemsContainer — ребёнок grid'а (ошибка иерархии!),
        /// он не будет удалён чтобы не сломать систему.
        /// </summary>
        private void ClearGrid(Transform parent, Transform preserveChild = null)
        {
            if (parent == null) return;
            for (int i = parent.childCount - 1; i >= 0; i--)
            {
                var child = parent.GetChild(i);
                if (child == preserveChild) continue;
                Destroy(child.gameObject);
            }
        }

        private void SetupGridLayout(Transform parent, int columns)
        {
            var grid = parent.GetComponent<GridLayoutGroup>();
            if (grid == null) grid = parent.gameObject.AddComponent<GridLayoutGroup>();
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = columns;
            grid.cellSize = new Vector2(_slotSize, _slotSize);
            grid.spacing = new Vector2(_slotSpacing, _slotSpacing);
            grid.childAlignment = TextAnchor.UpperLeft;
        }

        /// <summary>
        /// Рисует нижнюю границу сетки отдельной линией (поверх слотов).
        /// Нужна потому что Pixel Perfect на Canvas обрезает нижнюю рамку спрайтов.
        /// </summary>
        public void DrawGridBottomBorder(Transform grid, int columns, int rows, Vector2 padding)
        {
            if (grid == null || columns <= 0 || rows <= 0) return;

            // Удаляем старую линию если есть
            Transform existing = grid.Find("BottomBorderFix");
            if (existing != null) Destroy(existing);

            var obj = new GameObject("BottomBorderFix", typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(grid, false);
            obj.AddComponent<LayoutElement>().ignoreLayout = true;

            float step = _slotSize + _slotSpacing;
            float lineWidth = columns * step;

            // Позиция: низ ячейковой области + offset вверх
            float posY = -(padding.y + rows * step) + _gridBottomBorderOffset;

            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(padding.x, posY);
            rt.sizeDelta = new Vector2(lineWidth, _gridBottomBorderHeight);
            rt.localScale = Vector3.one;

            var img = obj.GetComponent<Image>();
            img.color = _gridBottomBorderColor;
            img.raycastTarget = false;
            img.maskable = true;
        }

        #endregion

        #region UI Control

        public void ToggleInventory()
        {
            if (_isOpen) CloseAll();
            else OpenInventoryOnly();
        }

        private void OpenInventoryOnly()
        {
            _isOpen = true;
            SetCanvasActive(true);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(true);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
            // Показываем вкладки
            if (_tabBar != null) _tabBar.SetActive(true);
            // Вкладка здоровья — показываем/скрываем вместе с инвентарём
            if (_healthContentPane != null) _healthContentPane.SetActive(_activeTab == 1);
            if (_inventoryContentPane != null) _inventoryContentPane.SetActive(_activeTab == 0);
            // Синхронизируем backpack grid с текущим состоянием
            SyncBackpackPanelState();
            ForceRefresh();
        }

        public void CloseAll()
        {
            // ФИКС БАГ (audit) #13 / user feedback — duplication when closing inventory during drag:
            // СНАЧАЛА отменяем drag и возвращаем предмет в исходный controller,
            // ЗАТЕМ уничтожаем окна и controllers. Раньше порядок был обратный:
            // DestroyAllContainerWindows + CloseAllOpenedBackpacks сначала,
            // CancelDrag потом — и CancelDrag находил disposed origin controller,
            // предмет оставался «в воздухе», при следующем OnDrop дублировался.
            //
            // Правильный порядок (по аудиту):
            //   1. Block new input
            //   2. Cancel drag and restore exact source
            //   3. Flush nested windows from deepest to root
            //   4. Destroy windows
            //   5. Dispose controllers
            //   6. Close visual UI

            // Закрываем контекстное меню если открыто
            if (K_ContextMenu.Instance != null)
                K_ContextMenu.Instance.Hide();

            // 1. СНАЧАЛА отменяем drag — предмет возвращается в исходный controller.
            CancelDrag();

            // 2. Теперь безопасно закрываем окна и controllers.
            // МУЛЬТИОКОННАЯ СИСТЕМА: закрываем все окна контейнеров
            DestroyAllContainerWindows();

            // ФИКС v2: Закрываем все открытые рюкзаки-контейнеры (с сохранением содержимого)
            CloseAllOpenedBackpacks();

            // ФИКС БАГ #2: Отписываемся от событий контейнера
            UnsubscribeFromContainerEvents();
            ClearHover();

            _isOpen = false;
            _isLootingContainer = false;
            _activeContainerController = null;

            SetCanvasActive(false);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(true);
            if (_backpackPanel != null) _backpackPanel.SetActive(false);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(false);
            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);

            if (_healthContentPane != null) _healthContentPane.SetActive(false);
            if (_inventoryContentPane != null) _inventoryContentPane.SetActive(false);
            if (_tabBar != null) _tabBar.SetActive(false);

            ReturnAllItemsToPool();
            ReturnAllBorderHidersToPool();
            OnContainerClosed?.Invoke(_pocketsController);
        }

        /// <summary>
        /// Экстренная отмена drag (например, при закрытии инвентаря).
        /// Скрывает ghost (у которого свой Canvas ScreenSpaceOverlay),
        /// возвращает предмет на исходную позицию, очищает все drag-переменные.
        /// Без этого ghost зависает на экране после закрытия инвентаря.
        /// </summary>
        private void CancelDrag()
        {
            // Останавливаем отложенный возврат
            if (_postDragRefreshCoroutine != null)
            {
                StopCoroutine(_postDragRefreshCoroutine);
                _postDragRefreshCoroutine = null;
            }
            if (!_isDragging && !_dragItemRemoved) return;

            // 1) Скрываем ghost
            if (_dragGhost != null)
                _dragGhost.SetActive(false);

            // 2) Возвращаем предмет в контроллер, если он был удалён при старте drag
            if (_draggedItem != null && _draggedItem.Item != null && _dragItemRemoved)
            {
                var item = _draggedItem.Item;

                bool alreadyPlaced = false;
                var (foundGrid, _, _) = FindItemLocation(item);
                if (foundGrid != null)
                    alreadyPlaced = true;

                if (!alreadyPlaced)
                {
                    var controller = (_dragOriginGridType == GridType.Container && _draggedItem.BoundController != null)
                        ? _draggedItem.BoundController
                        : GetControllerForGrid(_dragOriginGridType);

                    if (controller != null)
                    {
                        // v12: возвращаем в том состоянии, в котором взяли (fold + поворот),
                        // ДО первой попытки размещения.
                        RestoreDragOriginState(item);

                        bool placed = controller.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
                        if (!placed)
                            placed = controller.PlaceExistingItemInFirstFreeSlot(item);
                        if (!placed)
                        {
                            Debug.LogWarning($"[CANCEL-DRAG] Origin grid '{_dragOriginGridType}' full. " +
                                              "Trying all player grids.");
                            placed = TryPlaceInAnyPlayerGrid(item);
                        }
                        if (!placed)
                            Debug.LogError($"[CANCEL-DRAG] Could not return item '{item.Data?.DisplayName}' " +
                                            $"to ANY grid. Item is LOST! InstanceID={item.InstanceID}");
                    }
                    else
                    {
                        RestoreDragOriginState(item);
                        bool placed = TryPlaceInAnyPlayerGrid(item);
                        if (!placed)
                            Debug.LogError($"[CANCEL-DRAG] No controller + no fallback grid. " +
                                            $"Item '{item.Data?.DisplayName}' is LOST!");
                    }
                }
            }

            // 3) Останавливаем ВСЕ отложенные корутины
            if (_postDragRefreshCoroutine != null)
            {
                StopCoroutine(_postDragRefreshCoroutine);
                _postDragRefreshCoroutine = null;
            }
            if (_refreshCoroutine != null)
            {
                StopCoroutine(_refreshCoroutine);
                _refreshCoroutine = null;
            }
            _pendingRefresh = false;

            // ═══ ФИКС БАГ 2 (дубль при закрытии/открытии инвентаря): ═══
            // Сохраняем ссылку на перетаскиваемый UI_Item и СНАЧАЛА сбрасываем
            // drag-стейт (_isDragging=false, _draggedItem=null), а ПОТОМ синхронно
            // пулим его. Важно: обнуляем _draggedItem ДО ReturnToPool, иначе защита
            // ReturnToPool (item == _draggedItem && _isDragging) заблокирует пул.
            // Синхронный пул убирает UI_Item из _activeItems и деактивирует его ДО того,
            // как CloseAll деактивирует панели и дёрнет OnDisable/прерывание drag —
            // это устраняет гонку, из-за которой при повторном открытии предмет двоился.
            var draggedToPool = _draggedItem;

            _isDragging = false;
            _draggedItem = null;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedFromSlotIconRotation = 0f;
            _dragItemRemoved = false;
            _dropHandled = false;
            _needsPostDragRefresh = false;

            if (_hoveredItem != null)
            {
                _hoveredItem.SetSelected(false);
                _hoveredItem = null;
            }

            if (draggedToPool != null)
                ReturnToPool(draggedToPool);

            // 4) Сбрасываем подсветки и raycast
            ClearDragCellHighlights();
            SetAllGridSlotsRaycast(false);
            RestoreRaycastForDraggedBackpackWindow();
        }
        public void OpenContainer(InventoryController containerController, string containerName, int width, int height)
        {
            Debug.Log($"[OPEN-CONTAINER] START: name={containerName}, size={width}x{height}, " +
                      $"_isLootingContainer={_isLootingContainer}, " +
                      $"_openingBackpackContainer={_openingBackpackContainer}");

            // МУЛЬТИОКОННАЯ СИСТЕМА: если это лут (не рюкзак) — приостанавливаем окна
            if (!_openingBackpackContainer && _openContainerWindows.Count > 0)
            {
                SuspendBackpackWindowsForLoot();
            }

            if (containerController == null)
            {
                Debug.LogWarning("[OPEN-CONTAINER] ABORT: containerController is null");
                return;
            }

            // БАГ #5 ФИКС: Сбрасываем флаг drag панели
            _isDraggingPanel = false;
            _pendingRefreshAfterPanelDrag = false;

            if (_isLootingContainer && _activeContainerController == containerController)
            {
                Debug.Log("[OPEN-CONTAINER] Same container already open — closing (toggle)");
                CloseAll();
                return;
            }

            // ФИКС БАГ #2: Отписываемся от событий СТАРОГО контейнера перед переключением
            UnsubscribeFromContainerEvents();

            _activeContainerController = containerController;
            _isLootingContainer = true;
            _isOpen = true;

            // Подписываемся на события НОВОГО контейнера
            SubscribeToContainerEvents();

            SetCanvasActive(true);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);

            // ========== ФИКС БАГ: Показываем инвентарь игрока при лутании ==========
            // Раньше при OpenContainer() активировался только _surroundingsPanel
            // (панель контейнера), но не инвентарь игрока (_backpackPanel, _inventoryBackground).
            // Из-за этого при открытии ящика видна была только панель лутания без инвентаря.
            if (_backpackPanel != null) _backpackPanel.SetActive(true);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
            if (_inventoryContentPane != null) _inventoryContentPane.SetActive(_activeTab == 0);
            if (_healthContentPane != null) _healthContentPane.SetActive(_activeTab == 1);
            // ====================================================================

            if (_surroundingsPanel != null)
            {
                _surroundingsPanel.SetActive(true);
                Debug.Log($"[OPEN-CONTAINER] _surroundingsPanel SetActive(true). " +
                          $"Panel active={_surroundingsPanel.activeSelf}, parent={_surroundingsPanel.transform.parent?.name}");
                if (_containerNameText != null)
                {
                    _containerNameText.text = containerName;
                    _containerNameText.raycastTarget = false;
                }
                RebuildSurroundingsGrid(width, height);
                Debug.Log($"[OPEN-CONTAINER] RebuildSurroundingsGrid done. " +
                          $"_currentContainerCols={_currentContainerCols}, _currentContainerRows={_currentContainerRows}");
            }
            else
            {
                Debug.LogWarning("[OPEN-CONTAINER] _surroundingsPanel is NULL — cannot show container UI!");
            }

            SetupBackgroundRaycast();
            ForceRefresh();
            Debug.Log($"[OPEN-CONTAINER] END: container '{containerName}' should be visible now.");
        }

        /// <summary>
        /// ФИКС БАГ #2: Подписка на события активного контейнера.
        /// </summary>
        private void SubscribeToContainerEvents()
        {
            if (_activeContainerController == null) return;
            _activeContainerController.OnInventoryChanged += _onInventoryChangedHandler;
            _activeContainerController.OnItemPlaced += _onItemPlacedHandler;
            _activeContainerController.OnItemRemoved += _onItemChangedHandler;
            _activeContainerController.OnItemRotated += _onItemChangedHandler;
            _activeContainerController.OnItemQuantityChanged += _onItemChangedHandler;
        }

        /// <summary>
        /// ФИКС БАГ #2: Отписка от событий активного контейнера.
        /// </summary>
        private void UnsubscribeFromContainerEvents()
        {
            if (_activeContainerController == null) return;
            _activeContainerController.OnInventoryChanged -= _onInventoryChangedHandler;
            _activeContainerController.OnItemPlaced -= _onItemPlacedHandler;
            _activeContainerController.OnItemRemoved -= _onItemChangedHandler;
            _activeContainerController.OnItemRotated -= _onItemChangedHandler;
            _activeContainerController.OnItemQuantityChanged -= _onItemChangedHandler;
        }

        private void SetCanvasActive(bool active)
        {
            if (_canvasGroup == null) return;
            _canvasGroup.alpha = active ? 1f : 0f;
            _canvasGroup.interactable = active;
            _canvasGroup.blocksRaycasts = active;
        }

        private void RebuildSurroundingsGrid(int width, int height)
        {
            if (_surroundingsGrid == null || _slotPrefab == null) return;
            _currentContainerCols = width;
            _currentContainerRows = height;
            if (_surroundingsItemsContainer != null)
                _surroundingsItemsContainer.SetParent(transform, false);
            ClearGrid(_surroundingsGrid, _surroundingsItemsContainer);
            SetupGridLayout(_surroundingsGrid, width);
            CacheGridLayoutPadding(_surroundingsGrid, GridType.Container);
            for (int i = 0; i < width * height; i++)
            {
                var slot = Instantiate(_slotPrefab, _surroundingsGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % width;
                    int y = i / width;
                    slotUI.Setup(x, y, GridType.Container, this);
                    // ═══ ФИКС БАГОВ 1+2 (v18): привязываем контроллер ЛУТА к слотам.
                    // Без этого GetLootControllerFromSlots()/RestoreLootControllerIfLooting()
                    // всегда возвращают null (BoundController == null):
                    //  - после закрытия окна рюкзака сетка окружения «исчезает» (баг 1);
                    //  - CanUnfoldInCurrentGrid не находит контроллер → «Развернуть» не работает (баг 2).
                    slotUI.BindController(_activeContainerController);
                }
            }
            var gridRect = _surroundingsGrid.GetComponent<RectTransform>();
            if (gridRect != null)
            {
                var gridLayout = _surroundingsGrid.GetComponent<GridLayoutGroup>();
                if (gridLayout != null)
                {
                    Vector3[] corners = new Vector3[4];
                    gridRect.GetWorldCorners(corners);
                    Vector3 savedWorldTopLeft = corners[1];
                    int rows = height;
                    float padL = gridLayout.padding.left;
                    float padR = gridLayout.padding.right;
                    float padT = gridLayout.padding.top;
                    float padB = gridLayout.padding.bottom;
                    float w = padL + width * _slotSize + Mathf.Max(0, width - 1) * _slotSpacing + padR;
                    float h = padT + rows * _slotSize + Mathf.Max(0, rows - 1) * _slotSpacing + padB;
                    gridRect.anchorMin = new Vector2(0f, 1f);
                    gridRect.anchorMax = new Vector2(0f, 1f);
                    gridRect.pivot = new Vector2(0f, 1f);
                    gridRect.sizeDelta = new Vector2(w, h);
                    if (gridRect.parent != null)
                    {
                        Vector2 localTL = gridRect.parent.InverseTransformPoint(savedWorldTopLeft);
                        RectTransform parentRT = gridRect.parent as RectTransform;
                        if (parentRT != null)
                            localTL -= new Vector2(parentRT.rect.xMin, parentRT.rect.yMax);
                        gridRect.anchoredPosition = localTL;
                    }
                }
                LayoutRebuilder.ForceRebuildLayoutImmediate(gridRect);
            }
            DrawGridBottomBorder(_surroundingsGrid, width, height, _containerGridPadding);
            if (_surroundingsItemsContainer != null && _surroundingsGrid != null)
            {
                var syncRT = _surroundingsItemsContainer.GetComponent<SyncRectTransform>();
                if (syncRT != null) syncRT.enabled = false;
                _surroundingsItemsContainer.SetParent(_surroundingsGrid, false);
                _surroundingsItemsContainer.SetAsLastSibling();
                var layoutElem = _surroundingsItemsContainer.GetComponent<LayoutElement>();
                if (layoutElem == null) layoutElem = _surroundingsItemsContainer.gameObject.AddComponent<LayoutElement>();
                layoutElem.ignoreLayout = true;
                var canvasGroup = _surroundingsItemsContainer.GetComponent<CanvasGroup>();
                if (canvasGroup != null) canvasGroup.blocksRaycasts = true;
            }
            SetGridSlotsRaycast(_surroundingsGrid, false);
            if (_activeBackpackContainer == null)
            {
                DisableSurroundingsPanelDrag();
            }
        }
        private void DisableSurroundingsPanelDrag()
        {
            if (_surroundingsPanel == null && _surroundingsGrid == null) return;

            // Связываем иерархию (Grid → ребёнок Panel, ItemsContainer → ребёнок Grid).
            // Это безопасно и для лута — просто обеспечивает консистентность.
            try { LinkSurroundingsHierarchy(); }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[LOOT] LinkSurroundingsHierarchy failed (non-critical): {ex.Message}");
            }

            if (_surroundingsPanel != null)
            {
                // Удаляем K_DraggablePanel с панели (если остался от рюкзака).
                var drag = _surroundingsPanel.GetComponent<K_DraggablePanel>();
                if (drag != null)
                {
                    DestroyImmediate(drag);
                    Debug.Log("[LOOT] Removed K_DraggablePanel from _surroundingsPanel (loot mode — not draggable)");
                }

                // Удаляем программно созданные хедеры (DragZone/Header/Title).
                string[] headerNames = { "DragZone", "Header", "Title", "TitleBar", "TopBar", "ContainerName" };
                foreach (var hName in headerNames)
                {
                    var hdr = _surroundingsPanel.transform.Find(hName);
                    if (hdr != null)
                        DestroyImmediate(hdr.gameObject);
                }

                // Image панели: raycastTarget = false — панель не должна ловить клики
                // (для лута нет K_DraggablePanel, так что raycast всё равно некому обрабатывать).
                var panelImg = _surroundingsPanel.GetComponent<Image>();
                if (panelImg != null)
                    panelImg.raycastTarget = false;
            }

            // Image грида: raycastTarget = false (как в редакторе).
            if (_surroundingsGrid != null)
            {
                var gridImg = _surroundingsGrid.GetComponent<Image>();
                if (gridImg != null)
                    gridImg.raycastTarget = false;

                // Удаляем K_DraggablePanel с грида (если был добавлен ранее).
                var gridDrag = _surroundingsGrid.GetComponent<K_DraggablePanel>();
                if (gridDrag != null)
                    DestroyImmediate(gridDrag);
            }
        }

        /// <summary>
        /// Связывает _surroundingsGrid с _surroundingsPanel для перетаскивания рюкзака.
        ///
        /// КЛЮЧЕВАЯ ИДЕЯ: панель БЕЗ собственного Image — она НЕ ловит клики.
        /// Грид сам ловит клики через свой фоновый Image (raycastTarget=true).
        /// Событие пробрасывается от грида к панели через Unity EventSystem hierarchy.
        ///
        /// Цепочка raycast при клике на пустую ячейку:
        ///   слот (raycastTarget=false) → пропускает →
        ///   грид Image (raycastTarget=true) → ловит →
        ///   ExecuteEvents.ExecuteHierarchy: грид (нет IPointerDownHandler) →
        ///   панель (K_DraggablePanel.IPointerDownHandler) → OnPointerDown → drag!
        ///
        /// При клике на предмет:
        ///   UI_Item (raycastTarget=true, есть IPointerDownHandler) → перехватывает →
        ///   панель НЕ получает событие → предмет тащится, панель стоит.
        ///
        /// ВЫЗЫВАТЬ ТОЛЬКО из OpenBackpackAsContainer (НЕ для лута!).
        /// Для лута вызывается DetachGridFromPanel() вместо этого.
        /// </summary>
        private void SetupSurroundingsPanelHierarchy()
        {
            if (_surroundingsPanel == null || _surroundingsGrid == null) return;

            var panelRT = _surroundingsPanel.GetComponent<RectTransform>();
            var gridRT = _surroundingsGrid.GetComponent<RectTransform>();

            // ═══════════════════════════════════════════════════════════
            // 1. Убираем ВСЕ layout-компоненты с панели
            // ═══════════════════════════════════════════════════════════
            var oldVlg = panelRT.GetComponent<VerticalLayoutGroup>();
            if (oldVlg != null) DestroyImmediate(oldVlg);
            var oldCsf = panelRT.GetComponent<ContentSizeFitter>();
            if (oldCsf != null) DestroyImmediate(oldCsf);
            var oldHlg = panelRT.GetComponent<HorizontalLayoutGroup>();
            if (oldHlg != null) DestroyImmediate(oldHlg);
            var oldLep = panelRT.GetComponent<LayoutElement>();
            if (oldLep != null) DestroyImmediate(oldLep);

            // ═══════════════════════════════════════════════════════════
            // 2. Панель: отключить Image raycast — панель НЕ ловит клики!
            //    Клик ловит ГРИД, событие пробрасывается через hierarchy.
            // ═══════════════════════════════════════════════════════════
            // Панель: рамка + raycast=false (клик ловит грид, событие пробрасывается через hierarchy).
            var panelImg = panelRT.GetComponent<Image>();
            if (panelImg == null)
                panelImg = panelRT.gameObject.AddComponent<Image>();
            panelImg.raycastTarget = false;
            panelImg.color = new Color(0.15f, 0.16f, 0.18f, 0.95f);
            panelImg.maskable = true;

            // ═══════════════════════════════════════════════════════════
            // 3. СОХРАНЯЕМ мировую позицию грида ДО репарентинга!
            //    Без этого грид прыгнет на позицию панели после SetParent.
            // ═══════════════════════════════════════════════════════════
            Vector3[] gridCorners = new Vector3[4];
            gridRT.GetWorldCorners(gridCorners);
            Vector3 savedWorldTopLeft = gridCorners[1]; // top-left corner

            // ═══════════════════════════════════════════════════════════
            // 4. Репарентим грид в панель
            // ═══════════════════════════════════════════════════════════
            if (gridRT.parent != panelRT)
                gridRT.SetParent(panelRT, false);

            // ═══════════════════════════════════════════════════════════
            // 5. ВЫЧИСЛЯЕМ размер грида из GridLayoutGroup
            //    (GridLayoutGroup НЕ задаёт размер родителя — нужно считать вручную!)
            // ═══════════════════════════════════════════════════════════
            float gridWidth = 0f;
            float gridHeight = 0f;

            var gridLayout = gridRT.GetComponent<GridLayoutGroup>();
            if (gridLayout != null && _currentContainerCols > 0 && _currentContainerRows > 0)
            {
                int cols = _currentContainerCols;
                int rows = _currentContainerRows;
                float cellW = gridLayout.cellSize.x;
                float cellH = gridLayout.cellSize.y;
                float spaceX = gridLayout.spacing.x;
                float spaceY = gridLayout.spacing.y;

                gridWidth = gridLayout.padding.left
                           + cols * cellW
                           + Mathf.Max(0, cols - 1) * spaceX
                           + gridLayout.padding.right;
                gridHeight = gridLayout.padding.top
                            + rows * cellH
                            + Mathf.Max(0, rows - 1) * spaceY
                            + gridLayout.padding.bottom;
            }

            // Fallback: если GridLayoutGroup нет — считаем из _slotSize
            if (gridWidth <= 0f && _currentContainerCols > 0)
            {
                gridWidth = _currentContainerCols * _slotSize
                           + Mathf.Max(0, _currentContainerCols - 1) * _slotSpacing;
                gridHeight = _currentContainerRows * _slotSize
                            + Mathf.Max(0, _currentContainerRows - 1) * _slotSpacing;
            }

            // ═══════════════════════════════════════════════════════════
            // 6. Определяем высоту DragZone-хедера (если есть)
            // ═══════════════════════════════════════════════════════════
            float headerHeight = 0f;
            var dzTransform = panelRT.transform.Find("DragZone");
            if (dzTransform != null)
            {
                var dzRT = dzTransform as RectTransform;
                if (dzRT != null) headerHeight = dzRT.rect.height;
            }
            // Если DragZone ещё не создан — берём из K_DraggablePanel (если есть)
            if (headerHeight <= 0f)
            {
                var existingDrag = panelRT.GetComponent<K_DraggablePanel>();
                if (existingDrag != null)
                {
                    // _headerHeight приватное — используем 0, DragZone будет создан
                    // позже в EnableDraggableSurroundingsPanel и подстроится.
                }
            }

            // ═══════════════════════════════════════════════════════════
            // 7. ЗАДАЁМ размер и позицию ГРИДА (внутри панели)
            // ═══════════════════════════════════════════════════════════
            gridRT.anchorMin = new Vector2(0f, 1f);
            gridRT.anchorMax = new Vector2(0f, 1f);
            gridRT.pivot = new Vector2(0f, 1f);
            gridRT.sizeDelta = new Vector2(gridWidth, gridHeight);
            // Смещаем грид вниз на headerHeight чтобы не перекрывать DragZone
            gridRT.anchoredPosition = new Vector2(0f, -headerHeight);

            var gridLe = gridRT.GetComponent<LayoutElement>();
            if (gridLe == null) gridLe = gridRT.gameObject.AddComponent<LayoutElement>();
            gridLe.ignoreLayout = true;

            // ═══════════════════════════════════════════════════════════
            // 8. ГРИД: Image с raycastTarget=true — ловит клики по пустым ячейкам
            // ═══════════════════════════════════════════════════════════
            LayoutRebuilder.ForceRebuildLayoutImmediate(gridRT);
            var gridImg = gridRT.GetComponent<Image>();
            if (gridImg == null)
                gridImg = gridRT.gameObject.AddComponent<Image>();
            gridImg.raycastTarget = true;
            // НЕ меняем цвет — он установлен в редакторе (фон сетки)
            gridImg.maskable = false;

            // ═══════════════════════════════════════════════════════════
            // 9. ЗАДАЁМ размер и позицию ПАНЕЛИ
            //    Панель = грид + хедер сверху. Восстанавливаем мировую позицию.
            // ═══════════════════════════════════════════════════════════
            panelRT.anchorMin = new Vector2(0f, 1f);
            panelRT.anchorMax = new Vector2(0f, 1f);
            panelRT.pivot = new Vector2(0f, 1f);
            panelRT.sizeDelta = new Vector2(gridWidth, gridHeight + headerHeight);

            // Восстанавливаем позицию: top-left панель + (0, -headerHeight) = top-left грида
            // Поэтому top-left панели = savedWorldTopLeft + (0, +headerHeight)
            if (panelRT.parent != null)
            {
                // Переводим сохранённую мировую позицию в локальную координату родителя панели
                Vector2 localTL = panelRT.parent.InverseTransformPoint(savedWorldTopLeft);
                RectTransform parentRT = panelRT.parent as RectTransform;
                if (parentRT != null)
                    localTL -= new Vector2(parentRT.rect.xMin, parentRT.rect.yMax);
                // Сдвигаем вверх на headerHeight (грид ниже хедера)
                localTL += new Vector2(0f, headerHeight);
                panelRT.anchoredPosition = localTL;
            }

            // ═══════════════════════════════════════════════════════════
            // 10. itemsContainer: внутри грида, ignoreLayout, без raycast
            // ═══════════════════════════════════════════════════════════
            if (_surroundingsItemsContainer != null)
            {
                if (_surroundingsItemsContainer.parent != gridRT)
                    _surroundingsItemsContainer.SetParent(gridRT, false);
                _surroundingsItemsContainer.SetAsLastSibling();

                var icLe = _surroundingsItemsContainer.GetComponent<LayoutElement>();
                if (icLe == null) icLe = _surroundingsItemsContainer.gameObject.AddComponent<LayoutElement>();
                icLe.ignoreLayout = true;

                var icGraphic = _surroundingsItemsContainer.GetComponent<Graphic>();
                if (icGraphic != null) icGraphic.raycastTarget = false;
            }

            // ═══════════════════════════════════════════════════════════
            // 11. Z-order: DragZone/хедер первый, грид последний
            // ═══════════════════════════════════════════════════════════
            gridRT.SetAsLastSibling();

            // ═══════════════════════════════════════════════════════════
            // 12. K_DraggablePanel на панели (если ещё нет)
            // ═══════════════════════════════════════════════════════════
            var drag = panelRT.GetComponent<K_DraggablePanel>();
            if (drag == null) drag = panelRT.gameObject.AddComponent<K_DraggablePanel>();
            drag.FindDragZone();

            Debug.Log($"[PANEL-SETUP] Grid size calculated: {gridWidth:F0}x{gridHeight:F0}, " +
                      $"header={headerHeight:F0}, panel size={gridWidth:F0}x{gridHeight + headerHeight:F0}");
        }

        /// <summary>
        /// Отвязывает грид от панели (для лута или при закрытии рюкзака).
        /// Возвращает грид в transform K_InventoryUI.
        /// </summary>
        private void DetachGridFromPanel()
        {
            // ФИКС: Этот метод больше НЕ разрушает иерархию Panel→Grid→ItemsContainer.
            // Иерархия остаётся связанной всегда — для лута просто отключаем K_DraggablePanel
            // через DisableSurroundingsPanelDrag().
            //
            // Метод оставлен как no-op для обратной совместимости со старыми вызовами.
            // Если нужно реально отключить drag — вызывайте DisableSurroundingsPanelDrag().
            Debug.Log("[V13-DRAG] DetachGridFromPanel: no-op (hierarchy preserved, use DisableSurroundingsPanelDrag to disable drag)");
        }

        #region Multi-Window Focus System

        /// <summary>
        /// Создаёт новое окно контейнера и делает его активным.
        /// Вызывается из OpenBackpackAsContainer.
        /// </summary>
        private K_ContainerWindow CreateContainerWindow(
            InventoryController controller, string instanceID, string displayName, int w, int h)
        {
            if (_floatingWindowsRoot == null || _slotPrefab == null)
            {
                Debug.LogError("[MULTI-WIN] Cannot create window: missing root or slotPrefab");
                return null;
            }

            var windowObj = new GameObject($"Window_{instanceID}", typeof(RectTransform));
            windowObj.transform.SetParent(_floatingWindowsRoot, false);
            windowObj.transform.SetAsLastSibling();

            var window = windowObj.AddComponent<K_ContainerWindow>();
            float headerH = _containerHeaderPrefab != null ? _containerHeaderHeight : 32f;

            // Позиция: если есть активное окно — сдвигаем; иначе — где был оригинальный грид
            Vector2 position = GetNextWindowPosition();

            window.Initialize(
                controller, instanceID, w, h,
                _slotPrefab, _slotSize, _slotSpacing,
                _containerHeaderColor, headerH,
                this,
                null, // backgroundSprite — используем программный
                displayName
            );
            window.SetPosition(position);
            // >>> FIX проблема 4: контрастный хедер переносной сетки <<<
            StyleWindowHeader(window);
            // >>> END FIX <<<
            // Подписываемся на фокус
            window.OnWindowFocused += OnContainerWindowFocused;

            _openContainerWindows.Add(window);
            Debug.Log($"[MULTI-WIN] Created window #{_openContainerWindows.Count} " +
                      $"'{displayName}' at {position}");

            return window;
        }

        // >>> FIX проблема 4: стилизация хедера окна (контраст + линия + жирный текст) <<<
        private void StyleWindowHeader(K_ContainerWindow window)
        {
            if (window == null || window.DragZoneTransform == null) return;
            var dz = window.DragZoneTransform;
            var dzImg = dz.GetComponent<Image>();
            if (dzImg != null) dzImg.color = new Color(0.24f, 0.26f, 0.30f, 0.98f);
            if (dz.Find("HeaderBottomLine") == null)
            {
                var lineObj = new GameObject("HeaderBottomLine", typeof(RectTransform), typeof(Image));
                lineObj.transform.SetParent(dz, false);
                var lineRT = lineObj.GetComponent<RectTransform>();
                lineRT.anchorMin = new Vector2(0f, 0f); lineRT.anchorMax = new Vector2(1f, 0f);
                lineRT.pivot = new Vector2(0.5f, 0f); lineRT.anchoredPosition = Vector2.zero;
                lineRT.sizeDelta = new Vector2(0f, 1f); lineRT.localScale = Vector3.one;
                var lineImg = lineObj.GetComponent<Image>();
                lineImg.color = new Color(0.45f, 0.47f, 0.52f, 1f); lineImg.raycastTarget = false;
            }
            var titleTr = dz.Find("WindowTitle");
            if (titleTr != null)
            {
                var tmp = titleTr.GetComponent<TMPro.TextMeshProUGUI>();
                if (tmp != null)
                {
                    tmp.fontStyle = TMPro.FontStyles.Bold;
                    tmp.color = new Color(0.92f, 0.92f, 0.95f, 1f);
                    tmp.fontSize = 14f;
                    tmp.overflowMode = TMPro.TextOverflowModes.Truncate;
                    tmp.textWrappingMode = TMPro.TextWrappingModes.NoWrap;
                    var nrt = titleTr.GetComponent<RectTransform>();
                    if (nrt != null) { nrt.offsetMin = new Vector2(8f, 0f); nrt.offsetMax = new Vector2(-8f, 0f); }
                }
            }
        }
        // >>> END FIX <<<

        /// <summary>
        /// Вычисляет позицию для нового окна (сдвиг чтобы не перекрывал предыдущие).
        /// </summary>
        private Vector2 GetNextWindowPosition()
        {
            // Если есть оригинальный грид — используем его мировую позицию как базу
            if (_originalSurroundingsGrid != null)
            {
                var gridRT = _originalSurroundingsGrid.GetComponent<RectTransform>();
                if (gridRT != null)
                {
                    Vector3[] corners = new Vector3[4];
                    gridRT.GetWorldCorners(corners);
                    Vector2 worldTL = _floatingWindowsRoot.InverseTransformPoint(corners[1]);
                    RectTransform parentRT = _floatingWindowsRoot as RectTransform;
                    if (parentRT != null)
                        worldTL -= new Vector2(parentRT.rect.xMin, parentRT.rect.yMax);

                    // Сдвигаем для каждого следующего окна
                    int offset = _openContainerWindows.Count;
                    return worldTL + new Vector2(offset * 30f, -offset * 30f);
                }
            }

            // Fallback
            int idx = _openContainerWindows.Count;
            return new Vector2(300f + idx * 30f, -100f - idx * 30f);
        }

        /// <summary>
        /// Делает окно активным: переключает ссылки, обновляет предметы.
        /// </summary>
        private void ActivateContainerWindow(K_ContainerWindow window)
        {
            if (window == null) return;

            // 1. Деактивируем текущее активное окно
            if (_activeContainerWindow != null && _activeContainerWindow != window)
            {
                DeactivateContainerWindow(_activeContainerWindow);
            }

            // 2. (ФИКС БАГ #44) ReturnBackgroundItemsToPool удалён как мёртвый код.
            // Окна всегда активны, фоновый рендеринг не нужен.

            // 3. Переключаем ссылки на активное окно.
            // v12: во время лутания НЕ перехватываем _surroundings* и _activeContainerController —
            // иначе лут-сетка «ломается», пока открыто окно рюкзака.
            _activeContainerWindow = window;
            _activeContainerWindow.IsActive = true;
            _activeContainerWindow.SetInteractable(true);
            if (!_isLootingContainer)
            {
                _surroundingsPanel = window.PanelRect.gameObject;
                _surroundingsGrid = window.GridRect;
                _surroundingsItemsContainer = window.ItemsContainer;
                UnsubscribeFromContainerEvents();
                _activeContainerController = window.Controller;
                SubscribeToContainerEvents();
                _currentContainerCols = window.GridWidth;
                _currentContainerRows = window.GridHeight;
            }

            // 4. Обновляем имя контейнера
            if (_containerNameText != null && window.Controller != null)
                _containerNameText.text = ""; // Имя уже в хедере окна

            // 5. Перерендериваем предметы
            ForceRefresh();

            // FIX БАГ: Принудительно сбрасываем raycast на слотах, так как новое окно 
            // могло создать слоты с raycastTarget=true (из префаба), что блокировало дроп.
            SetAllGridSlotsRaycast(false);

            Debug.Log($"[MULTI-WIN] Activated window '{window.BackpackInstanceID}'");
        }
        /// <summary>
        /// Переводит окно в фоновый режим (теперь no-op, все окна всегда активны).
        /// </summary>
        private void DeactivateContainerWindow(K_ContainerWindow window)
        {
            if (window == null) return;
            // FIX БАГ 1+2: Все окна всегда активны. Фонового режима больше нет.
            // Каждое окно управляет своими предметами независимо.
            window.IsActive = true;
        }

        // ФИКС БАГ #44: ReturnBackgroundItemsToPool удалён как мёртвый код.
        // Раньше возвращал фоновые предметы окна в пул, но BackgroundItems больше не существует.

        /// <summary>
        /// Вызывается при клике на окно (K_ContainerWindow.OnWindowFocused).
        /// Если окно не активно — делает его активным (фокус).
        /// </summary>
        private void OnContainerWindowFocused(K_ContainerWindow window)
        {
            // Z-order переключение отключено. Все окна всегда активны.
        }

        /// <summary>
        /// Приостанавливает активное окно рюкзака и восстанавливает оригинальные
        /// ссылки для открытия лутового ящика.
        /// </summary>
        private void SuspendBackpackWindowsForLoot()
        {
            // ФИКС БАГ #19: Скрываем окна рюкзаков при открытии лута, чтобы они не перекрывали экран
            foreach (var window in _openContainerWindows)
            {
                if (window != null && window.PanelRect != null)
                {
                    window.PanelRect.gameObject.SetActive(false);
                }
            }

            _surroundingsPanel = _originalSurroundingsPanel;
            _surroundingsGrid = _originalSurroundingsGrid;
            _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
        }

        /// <summary>
        /// Восстанавливает приостановленное окно рюкзака после закрытия лута.
        /// </summary>
        private void ResumeBackpackWindowsAfterLoot()
        {
            if (_openContainerWindows.Count > 0)
            {
                // ФИКС БАГ #19: Возвращаем видимость окнам рюкзаков
                foreach (var window in _openContainerWindows)
                {
                    if (window != null && window.PanelRect != null)
                    {
                        window.PanelRect.gameObject.SetActive(true);
                    }
                }

                var lastWindow = _openContainerWindows[_openContainerWindows.Count - 1];
                _surroundingsPanel = lastWindow.PanelRect.gameObject;
                _surroundingsGrid = lastWindow.GridRect;
                _surroundingsItemsContainer = lastWindow.ItemsContainer;
                _activeContainerWindow = lastWindow;
                _activeContainerController = lastWindow.Controller;
                _currentContainerCols = lastWindow.GridWidth;
                _currentContainerRows = lastWindow.GridHeight;
            }
            else
            {
                _surroundingsPanel = _originalSurroundingsPanel;
                _surroundingsGrid = _originalSurroundingsGrid;
                _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
            }
            Debug.Log("[MULTI-WIN] Resumed after loot");
        }

        // ФИКС БАГ #44: RefreshBackgroundWindows удалён как мёртвый код.
        // Окна всегда активны, рендеринг идёт через RefreshAllWindows.

        /// <summary>
        /// FIX БАГ 1+2: Обновляет предметы во ВСЕХ открытых окнах.
        /// Каждое окно рендерит свои предметы в свой ItemsContainer.
        /// </summary>
        private void RefreshAllWindows()
        {
            foreach (var window in _openContainerWindows)
            {
                if (window == null || window.Controller == null || window.ItemsContainer == null) continue;
                RefreshWindowItems(window);
            }
        }

        private void RefreshWindowItems(K_ContainerWindow window)
        {
            int cols = window.GridWidth;
            int rows = window.GridHeight;
            var controller = window.Controller;

            for (int y = 0; y < rows; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    string key = $"Win_{window.BackpackInstanceID}_{x}_{y}";
                    var item = controller.GetItemAt(x, y);

                    if (_activeItems.TryGetValue(key, out var uiItem))
                    {
                        if (uiItem == null)
                        {
                            _activeItems.Remove(key);
                            if (item != null && controller.IsRootCell(item.InstanceID, x, y))
                            {
                                CreateWindowItem(window, item, x, y, key);
                            }
                            continue;
                        }

                        if (item == null)
                        {
                            if (uiItem == _draggedItem) { _activeItems.Remove(key); continue; }
                            ReturnToPool(uiItem);
                        }
                        else
                        {
                            // ═══ ФИКС: СНАЧАЛА активация, ПОТОМ данные ═══
                            uiItem.gameObject.SetActive(true);
                            uiItem.UpdateData(item);
                        }
                    }
                    else if (item != null && controller.IsRootCell(item.InstanceID, x, y))
                    {
                        CreateWindowItem(window, item, x, y, key);
                    }
                }
            }
        }
        private void CreateWindowItem(K_ContainerWindow window, InventoryItem item, int x, int y, string key)
        {
            if (window.ItemsContainer == null || _uiItemPrefab == null) return;

            var newUiItem = GetPooledItem();
            if (newUiItem == null) return;

            newUiItem.transform.SetParent(window.ItemsContainer, false);
            newUiItem.transform.SetAsLastSibling();

            var rect = newUiItem.GetComponent<RectTransform>();
            if (rect != null)
            {
                Vector2Int currentSize = item.CurrentSize;
                float widthPx = currentSize.x * _slotSize + Mathf.Max(0, currentSize.x - 1) * _slotSpacing;
                float heightPx = currentSize.y * _slotSize + Mathf.Max(0, currentSize.y - 1) * _slotSpacing;
                rect.anchorMin = new Vector2(0f, 1f);
                rect.anchorMax = new Vector2(0f, 1f);
                rect.pivot = new Vector2(0f, 1f);
                rect.sizeDelta = new Vector2(widthPx, heightPx);
                rect.anchoredPosition = new Vector2(
                    x * (_slotSize + _slotSpacing),
                    -y * (_slotSize + _slotSpacing));
                rect.localScale = Vector3.one;
                rect.localRotation = Quaternion.identity;
            }

            newUiItem.gameObject.SetActive(true);
            newUiItem.Setup(item, this, GridType.Container, x, y);
            newUiItem.BindController(window.Controller);
            _activeItems[key] = newUiItem;
        }

        // ФИКС БАГ #44: RefreshBackgroundWindow и CreateBackgroundItem удалены как мёртвый код.
        // Фоновый рендеринг больше не нужен, т.к. все окна всегда активны и рендерятся через RefreshAllWindows.

        /// <summary>
        /// Закрывает и уничтожает окно контейнера.
        /// </summary>
        /// </summary>
        /// <summary>
        /// Закрывает и уничтожает окно контейнера.
        ///
        /// ФИКС БАГ 2 (матрёшка): Каскадно закрывает ВСЕ дочерние окна —
        /// окна, чьи рюкзаки-владельцы лежат внутри контроллера этого окна.
        /// Рекурсия гарантирует, что сначала закрываются самые глубокие
        /// потомки, потом их родители.
        ///
        /// ФИКС БАГ 3 (пропажа предметов): Сохраняет содержимое через
        /// item.ToSaveData(x, y) вместо GetSaveData().GetItems().
        /// ToSaveData синхронизирует BackpackContents из живого контроллера
        /// вложенного рюкзака (если он открыт), гарантируя актуальность данных.
        /// </summary>
        private void DestroyContainerWindow(K_ContainerWindow window)
        {
            if (window == null) return;

            // Защита от повторного вызова (каскадная рекурсия могла уже уничтожить)
            if (!_openContainerWindows.Contains(window)) return;

            // ═══ ФИКС БАГ 2: Каскадное закрытие дочерних окон ═══
            // Находим все окна, чьи рюкзаки-владельцы лежат в контроллере этого окна.
            // Закрываем их РЕКУРСИВНО — они сами закроют своих потомков.
            if (window.Controller != null)
            {
                // Копируем список, т.к. рекурсивный DestroyContainerWindow
                // модифицирует _openContainerWindows.
                var childWindows = new List<K_ContainerWindow>();
                foreach (var otherWindow in _openContainerWindows)
                {
                    if (otherWindow == null || otherWindow == window) continue;
                    if (DoesControllerContainBackpack(window.Controller, otherWindow.BackpackInstanceID))
                    {
                        childWindows.Add(otherWindow);
                    }
                }

                foreach (var child in childWindows)
                {
                    // Рекурсия: дочернее окно закроет своих потомков,
                    // сохранит содержимое, dispose'ит контроллер.
                    DestroyContainerWindow(child);
                }
            }

            // ═══ Чистим _activeItems для этого окна ═══
            string prefix = $"Win_{window.BackpackInstanceID}_";
            var keysToRemove = new List<string>();
            foreach (var kvp in _activeItems)
            {
                if (kvp.Key.StartsWith(prefix))
                    keysToRemove.Add(kvp.Key);
            }
            foreach (var key in keysToRemove)
                _activeItems.Remove(key);

            // ═══ ФИКС БАГ 3: Сохраняем содержимое через ToSaveData ═══
            // GetSaveData().GetItems() возвращает SavedItem, созданные при BindToGrid.
            // Их BackpackContents НЕ обновляется при изменении вложенных рюкзаков.
            // ToSaveData(x, y) вызывает SyncSerializedFromController() и возвращает
            // АКТУАЛЬНЫЕ данные, включая содержимое вложенных рюкзаков.
            if (window.Controller != null && _openedBackpacks.ContainsKey(window.BackpackInstanceID))
            {
                var owner = FindBackpackItemByID(window.BackpackInstanceID);
                if (owner != null)
                {
                    var ctrl = window.Controller;
                    var freshItems = new List<SavedItem>();
                    for (int y = 0; y < ctrl.Height; y++)
                    {
                        for (int x = 0; x < ctrl.Width; x++)
                        {
                            var item = ctrl.GetItemAt(x, y);
                            if (item != null && ctrl.IsRootCell(item.InstanceID, x, y))
                            {
                                freshItems.Add(item.ToSaveData(x, y));
                            }
                        }
                    }
                    owner.ReplaceBackpackContents(freshItems);
                }

                if (_openedBackpacks.TryGetValue(window.BackpackInstanceID, out var ctrl2))
                {
                    ctrl2.Dispose();
                    _openedBackpacks.Remove(window.BackpackInstanceID);
                }
            }

            window.OnWindowFocused -= OnContainerWindowFocused;
            _openContainerWindows.Remove(window);

            if (window.gameObject != null)
                Destroy(window.gameObject);

            Debug.Log($"[MULTI-WIN] Destroyed window '{window.BackpackInstanceID}' " +
                      $"(cascade). Open windows remaining: {_openContainerWindows.Count}");
        }
        private void DestroyAllContainerWindows()
        {
            // FIX: Закрываем окна в обратном порядке (от самых вложенных к корневым).
            // Это гарантирует, что родительский контроллер не уничтожится раньше дочернего.
            for (int i = _openContainerWindows.Count - 1; i >= 0; i--)
            {
                if (_openContainerWindows[i] != null)
                    DestroyContainerWindow(_openContainerWindows[i]);
            }

            _activeContainerWindow = null;
            _suspendedBackpackWindow = null;

            // Восстанавливаем оригинальные ссылки
            _surroundingsPanel = _originalSurroundingsPanel;
            _surroundingsGrid = _originalSurroundingsGrid;
            _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
        }

        #endregion

        public void OnBackpackEquipped(InventoryItem backpackItem)
        {
            if (backpackItem == null || backpackItem.Data == null) return;

            // ═══ ФИКС БАГ 2 (ДЮП): рюкзак с ЖИВЫМ окном/контроллером не может быть
            // экипирован «параллельно» с ним. Синхронизируем живое содержимое в предмет
            // и закрываем все окна ДО загрузки в _backpackController, иначе содержимое
            // существует в двух местах одновременно (окно + сетка рюкзака).
            string bpIdStr = backpackItem.InstanceID.ToString();
            if (_openedBackpacks.ContainsKey(bpIdStr)
                || _openContainerWindows.Any(w => w != null && w.BackpackInstanceID == bpIdStr))
            {
                if (_openedBackpacks.TryGetValue(bpIdStr, out var liveCtrl) && liveCtrl != null)
                {
                    var liveItems = liveCtrl.GetSaveData()?.GetItems();
                    if (liveItems != null) backpackItem.ReplaceBackpackContents(liveItems);
                }
                CloseAllWindowsForBackpack(backpackItem);
            }

            _backpackEquipped = true;

            int w = backpackItem.Data.BackpackWidth;
            int h = backpackItem.Data.BackpackHeight;
            if (w <= 0 || h <= 0 || _backpackController == null || _backpackGrid == null) return;

            // ═══ ФИКС БАГ 2 (ошибка "Cannot restore ... no space" при каждом открытии
            // инвентаря): SyncBackpackPanelState вызывает OnBackpackEquipped на КАЖДОЕ
            // открытие. Без этого guard содержимое лилось повторно в контроллер, где уже
            // лежат те же InstanceID → PlaceExistingItem отклонял как "already in cache".
            if (_loadedBackpackItem != backpackItem)
            {
                // Страховка: если в контроллере осталось содержимое ДРУГОГО рюкзака
                // (смена без явного unequip) — сливаем его в старый предмет, не теряем.
                if (_loadedBackpackItem != null)
                {
                    var oldItems = _backpackController.GetSaveData()?.GetItems();
                    if (oldItems != null) _loadedBackpackItem.ReplaceBackpackContents(oldItems);
                }

                _backpackController.Clear();
                _backpackController.Resize(w, h);

                var savedContents = backpackItem.GetBackpackSavedItems();
                if (savedContents != null && savedContents.Count > 0)
                {
                    var db = K_InventorySetup.DatabaseInstance;
                    if (db != null)
                    {
                        int restoredCount = 0;
                        int skippedCount = 0;
                        foreach (var saved in savedContents)
                        {
                            var template = db.GetItemData(saved.ItemID);
                            if (template == null)
                            {
                                Debug.LogWarning($"[OnBackpackEquipped] Template '{saved.ItemID}' " +
                                    $"not found in database, skipping. InstanceID={saved.InstanceID}");
                                skippedCount++;
                                continue;
                            }
                            var innerItem = InventoryItem.FromSaveData(saved, template);
                            if (innerItem == null)
                            {
                                Debug.LogWarning($"[OnBackpackEquipped] Failed to restore " +
                                    $"item '{saved.ItemID}' (InstanceID={saved.InstanceID}) from save data.");
                                skippedCount++;
                                continue;
                            }
                            bool placed = _backpackController.PlaceExistingItem(innerItem, saved.X, saved.Y);
                            if (!placed)
                                placed = _backpackController.PlaceExistingItemInFirstFreeSlot(innerItem);
                            if (placed) restoredCount++;
                            else
                            {
                                Debug.LogError($"[OnBackpackEquipped] Cannot restore '{saved.ItemID}' " +
                                    $"(InstanceID={saved.InstanceID}) into backpack '{backpackItem.Data.DisplayName}' — " +
                                    $"no space. Item is LOST. Increase backpack size or clear save data.");
                                skippedCount++;
                            }
                        }
                        Debug.Log($"[OnBackpackEquipped] Restored {restoredCount} items " +
                            $"(skipped {skippedCount}) from save into '{backpackItem.Data.DisplayName}' " +
                            $"({w}x{h} grid).");
                    }
                    else
                    {
                        Debug.LogError("[OnBackpackEquipped] DatabaseInstance is null — " +
                            "cannot restore backpack contents. Items will be lost!");
                    }
                }

                // Живой контроллер — источник правды.
                backpackItem.ReplaceBackpackContents(null);
                _loadedBackpackItem = backpackItem;
            }

            // надетый рюкзак ВСЕГДА развёрнут (инвариант)
            if (backpackItem.CanFold) backpackItem.SetFolded(false);
            RebuildBackpackGrid(w, h);
        }
        public void OnBackpackUnequipped()
        {
            _backpackEquipped = false;
            _loadedBackpackItem = null; // ═══ ФИКС БАГ 2: сброс маркера загруженного рюкзака ═══

            if (_backpackSlot != null && _backpackSlot.EquippedItem != null)
            {
                var bpItem = _backpackSlot.EquippedItem;
                if (_backpackController != null)
                {
                    var savedItems = _backpackController.GetSaveData()?.GetItems()
                        ?? System.Array.Empty<SavedItem>();
                    bpItem.ReplaceBackpackContents(savedItems);
                    _backpackController.Clear();
                }
                else
                {
                    bpItem.ReplaceBackpackContents(null);
                }
            }

            if (_backpackGrid != null)
                ClearGrid(_backpackGrid, _backpackItemsContainer);
            _currentBackpackCols = 0;
            _currentBackpackRows = 0;
        }

        #region Tab System

        /// <summary>
        /// Переключить вкладку: 0 = Инвентарь, 1 = Здоровье.
        /// Вызывать из кнопок в UI.
        /// </summary>
        public void SwitchTab(int tabIndex)
        {
            if (tabIndex < 0 || tabIndex > 1) return;
            _activeTab = tabIndex;
            ApplyTabState();
        }

        /// <summary>Переключить на следующую вкладку (инвентарь ↔ здоровье).</summary>
        public void ToggleTab()
        {
            SwitchTab(_activeTab == 0 ? 1 : 0);
        }

        private void ApplyTabState()
        {
            bool showInventory = _activeTab == 0;
            bool showHealth = _activeTab == 1;

            if (_inventoryContentPane != null)
                _inventoryContentPane.SetActive(showInventory);
            if (_healthContentPane != null)
                _healthContentPane.SetActive(showHealth);

            // Обновляем цвета кнопок вкладок
            UpdateTabButtonColors();
        }

        private void UpdateTabButtonColors()
        {
            if (_tabButtons == null) return;
            for (int i = 0; i < _tabButtons.Length; i++)
            {
                if (_tabButtons[i] == null) continue;
                var img = _tabButtons[i].GetComponent<Image>();
                if (img != null)
                    img.color = (i == _activeTab) ? _activeTabColor : _inactiveTabColor;
            }
        }

        /// <summary>Текущая активная вкладка (0=Инвентарь, 1=Здоровье).</summary>
        public int ActiveTab => _activeTab;

        /// <summary>
        /// Синхронизирует видимость панели рюкзака с состоянием экипировки.
        /// Если рюкзак не надет — скрывает _backpackPanel.
        /// </summary>
        private void SyncBackpackPanelState()
        {
            if (_backpackSlot == null || _backpackPanel == null) return;
            bool hasBackpack = _backpackSlot.IsOccupied && _backpackSlot.EquippedItem?.Data?.IsBackpack == true;
            _backpackPanel.SetActive(hasBackpack || _activeTab == 0); // Всегда показываем на вкладке инвентаря
            if (hasBackpack)
                OnBackpackEquipped(_backpackSlot.EquippedItem);
        }

        #endregion

        public void RebuildBackpackGrid(int width, int height)
        {
            if (_backpackGrid == null || _slotPrefab == null) return;

            // ФИКС БАГ #4: Запоминаем реальные размеры рюкзака
            _currentBackpackCols = width;
            _currentBackpackRows = height;

            ClearGrid(_backpackGrid, _backpackItemsContainer);
            SetupGridLayout(_backpackGrid, width);
            CacheGridLayoutPadding(_backpackGrid, GridType.Backpack);

            for (int i = 0; i < width * height; i++)
            {
                var slot = Instantiate(_slotPrefab, _backpackGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % width;
                    int y = i / width;
                    slotUI.Setup(x, y, GridType.Backpack, this);
                }
            }

            // ФИКС: После создания слотов itemsContainer должен быть выше них.
            // Иначе новые слоты окажутся выше itemsContainer → блокируют raycast.
            EnsureContainerAboveGrid(_backpackGrid, _backpackItemsContainer);

            // ФИКС unfold-overflow: ВЫЧИСЛЯЕМ и ЗАДАЁМ размер grid'а по формуле
            // (как в BuildGrid). Без этого gridRT.sizeDelta остаётся от предыдущего
            // (возможно большего) рюкзака, и itemsContainer наследует раздутый размер →
            // предмет визуально вылезает за границы слотов, а RectMask2D не клиппает,
            // потому что предмет всё ещё внутри контейнера.
            var gridRT2 = _backpackGrid.GetComponent<RectTransform>();
            var gridLayout2 = _backpackGrid.GetComponent<GridLayoutGroup>();
            if (gridRT2 != null && gridLayout2 != null)
            {
                // Сохраняем мировую позицию top-left угла, чтобы сетка не прыгнула
                Vector3[] corners = new Vector3[4];
                gridRT2.GetWorldCorners(corners);
                Vector3 savedWorldTopLeft = corners[1];

                int rows = height;
                float padLeft = gridLayout2.padding.left;
                float padRight = gridLayout2.padding.right;
                float padTop = gridLayout2.padding.top;
                float padBot = gridLayout2.padding.bottom;
                float w = padLeft + width * _slotSize + Mathf.Max(0, width - 1) * _slotSpacing + padRight;
                float h = padTop + rows * _slotSize + Mathf.Max(0, rows - 1) * _slotSpacing + padBot;
                gridRT2.anchorMin = new Vector2(0f, 1f);
                gridRT2.anchorMax = new Vector2(0f, 1f);
                gridRT2.pivot = new Vector2(0f, 1f);
                gridRT2.sizeDelta = new Vector2(w, h);

                // Восстанавливаем позицию top-left угла
                if (gridRT2.parent != null)
                {
                    Vector2 localTL = gridRT2.parent.InverseTransformPoint(savedWorldTopLeft);
                    RectTransform pr = gridRT2.parent as RectTransform;
                    if (pr != null) localTL -= new Vector2(pr.rect.xMin, pr.rect.yMax);
                    gridRT2.anchoredPosition = localTL;
                }
            }

            // ФИКС unfold-overflow #2: Защищаем grid от родительских LayoutGroup.
            // Без этого VerticalLayoutGroup/HorizontalLayoutGroup на родителе
            // (например, на _backpackPanel в префабе) перезапишет gridRT.sizeDelta
            // после RebuildBackpackGrid, и контейнер снова получит неправильный размер.
            // K_ContainerWindow делает то же самое (строка 569 в его Initialize).
            var gridLe = _backpackGrid.GetComponent<LayoutElement>();
            if (gridLe == null) gridLe = _backpackGrid.gameObject.AddComponent<LayoutElement>();
            gridLe.ignoreLayout = true;

            // ФИКС unfold-overflow #4: УБИРАЕМ RectMask2D с _backpackGrid если она была
            // добавлена ранее. RectMask2D на гриде клиппает спрайты предметов которые
            // по дизайну слегка выходят за границы ячеек — это нормальное поведение
            // для инвентарей. Маска должна быть ТОЛЬКО на itemsContainer.
            var existingGridMask = _backpackGrid.GetComponent<RectMask2D>();
            if (existingGridMask != null)
                Destroy(existingGridMask);

            LayoutRebuilder.ForceRebuildLayoutImmediate(_backpackGrid.GetComponent<RectTransform>());

            // ФИКС: Явно обновляем RectTransform itemsContainer после rebuild.
            // GridLayoutGroup мог пересчитать layout, и itemsContainer (хоть и ignoreLayout)
            // мог потерять корректную позицию/размер.
            if (_backpackItemsContainer != null)
            {
                var itemsRT = _backpackItemsContainer.GetComponent<RectTransform>();
                var gridRT = _backpackGrid.GetComponent<RectTransform>();
                if (itemsRT != null && gridRT != null)
                {
                    itemsRT.anchorMin = new Vector2(0f, 1f);
                    itemsRT.anchorMax = new Vector2(0f, 1f);
                    itemsRT.pivot = new Vector2(0f, 1f);
                    itemsRT.sizeDelta = gridRT.sizeDelta;
                    itemsRT.anchoredPosition = Vector2.zero;
                    itemsRT.localScale = Vector3.one;
                    itemsRT.localRotation = Quaternion.identity;
                }

                // Убеждаемся что CanvasGroup настроен корректно
                var cg = _backpackItemsContainer.GetComponent<CanvasGroup>();
                if (cg != null)
                {
                    cg.alpha = 1f;
                    cg.interactable = true;
                    cg.blocksRaycasts = true;
                }
            }

            RefreshAll();
            DrawGridBottomBorder(_backpackGrid, width, height, _backpackGridPadding);

            // ФИКС unfold-overflow #6: Запускаем корутину которая перепроверяет
            // размер контейнера через несколько кадров. Это ловит случаи когда
            // родительская LayoutGroup/ContentSizeFitter/Animator перезаписывает
            // размер ПОСЛЕ нашего фикса (на следующем кадре).
            StartCoroutine(EnforceBackpackContainerSize(width, height));
        }

        /// <summary>
        /// ФИКС unfold-overflow #6: Перепроверяет и принудительно исправляет
        /// размер _backpackGrid и _backpackItemsContainer в течение нескольких кадров.
        /// Это гарантирует что даже если что-то перезапишет размер (LayoutGroup,
        /// ContentSizeFitter, Animator и т.д.), мы вернём его обратно.
        /// </summary>
        private IEnumerator EnforceBackpackContainerSize(int width, int height)
        {
            for (int frame = 0; frame < 5; frame++)
            {
                yield return null; // ждём следующий кадр

                if (_backpackGrid == null) yield break;

                var gridRT = _backpackGrid.GetComponent<RectTransform>();
                var gridLayout = _backpackGrid.GetComponent<GridLayoutGroup>();
                if (gridRT == null || gridLayout == null) yield break;

                float padLeft = gridLayout.padding.left;
                float padRight = gridLayout.padding.right;
                float padTop = gridLayout.padding.top;
                float padBot = gridLayout.padding.bottom;
                float correctW = padLeft + width * _slotSize + Mathf.Max(0, width - 1) * _slotSpacing + padRight;
                float correctH = padTop + height * _slotSize + Mathf.Max(0, height - 1) * _slotSpacing + padBot;

                // Исправляем размер grid'а если его перезаписали
                if (Mathf.Abs(gridRT.sizeDelta.x - correctW) > 0.5f ||
                    Mathf.Abs(gridRT.sizeDelta.y - correctH) > 0.5f)
                {
                    gridRT.sizeDelta = new Vector2(correctW, correctH);
                }

                // Исправляем размер itemsContainer'а
                if (_backpackItemsContainer != null)
                {
                    var itemsRT = _backpackItemsContainer.GetComponent<RectTransform>();
                    if (itemsRT != null)
                    {
                        if (Mathf.Abs(itemsRT.sizeDelta.x - correctW) > 0.5f ||
                            Mathf.Abs(itemsRT.sizeDelta.y - correctH) > 0.5f)
                        {
                            itemsRT.sizeDelta = new Vector2(correctW, correctH);
                        }
                        // Также гарантируем что anchoredPosition = (0,0)
                        // чтобы контейнер точно совпадал с гридом
                        if (itemsRT.anchoredPosition != Vector2.zero)
                            itemsRT.anchoredPosition = Vector2.zero;
                    }
                }
            }
        }

        #endregion

        #region Refresh System

        public void RefreshAll()
        {
            // ФИКС ИСЧЕЗНОВЕНИЯ: Предмет удалён из сетки при старте drag
            // (_dragItemRemoved=true) и «в воздухе» — его нет ни в одном контроллере.
            if (_dragItemRemoved)
            {
                _pendingRefresh = true;
                return;
            }

            // БАГ #5 ФИКС: Убрана блокировка через _isDraggingPanel — она могла
            // застрять в true (если K_DraggablePanel был уничтожен во время drag)
            // и навсегда заблокировать refresh. Вместо этого используется
            // pool parent (GetPoolParent) который не вызывает мерцания.

            if (_pendingRefresh) return;
            if (Time.time - _lastRefreshTime < UI_REFRESH_THROTTLE)
            {
                _pendingRefresh = true;
                return;
            }
            _pendingRefresh = true;
            _lastRefreshTime = Time.time;
            if (_refreshCoroutine != null) StopCoroutine(_refreshCoroutine);
            _refreshCoroutine = StartCoroutine(RefreshNextFrame());
        }

        /// <summary>
        /// БАГ #5: Уведомления о drag панели. Сохранены для обратной совместимости,
        /// но больше не блокируют refresh (это вызывало застревание).
        /// </summary>
        public void NotifyPanelDragStarted() { }
        public void NotifyPanelDragEnded() { }

        public void ForceRefresh()
        {
            if (_dragItemRemoved)
            {
                _pendingRefresh = true;
                return;
            }
            _pendingRefresh = false;
            _lastRefreshTime = 0f;

            SyncItemsContainerPositions();

            if (_refreshCoroutine != null)
            {
                StopCoroutine(_refreshCoroutine);
                _refreshCoroutine = null;
            }

            // ФИКС ЗАДЕРЖКИ: Выполняем синхронно, без yield return null
            ExecuteRefreshImmediate();
        }

        private IEnumerator RefreshNextFrame()
        {
            yield return null;
            ExecuteRefreshImmediate();
            _refreshCoroutine = null;
        }

        private void ExecuteRefreshImmediate()
        {
            // Защита от реентерабельного вызова (SetActive → OnDisable → EndDragComplete → ForceRefresh)
            if (_isExecutingRefresh) return;
            _isExecutingRefresh = true;
            try
            {
                _pendingRefresh = false;
                SyncItemsContainerPositions();
                ReturnAllItemsToPool();
                RefreshGrid(GridType.Pockets, POCKET_COLUMNS, POCKET_ROWS, _pocketsItemsContainer);
                RefreshGrid(GridType.Pocket2, POCKET_COLUMNS, POCKET_ROWS, _pocket2ItemsContainer);
                if (_backpackGrid != null)
                    RefreshGrid(GridType.Backpack, _currentBackpackCols, _currentBackpackRows, _backpackItemsContainer);

                // Сетка окружения рендерится ВСЕГДА при лутании; если контроллер слетел —
                // восстанавливаем из слотов окружения ДО рендера.
                if (_isLootingContainer && _originalSurroundingsItemsContainer != null)
                {
                    if (_activeContainerController == null)
                    {
                        _activeContainerController = GetLootControllerFromSlots();
                        if (_activeContainerController != null)
                        {
                            if (_currentContainerCols <= 0) _currentContainerCols = _activeContainerController.Width;
                            if (_currentContainerRows <= 0) _currentContainerRows = _activeContainerController.Height;
                        }
                    }
                    if (_activeContainerController != null)
                    {
                        RefreshGrid(GridType.Container,
                            _activeContainerController.Width,
                            _activeContainerController.Height,
                            _originalSurroundingsItemsContainer);
                    }
                }

                _primarySlot1?.Refresh();
                _primarySlot2?.Refresh();
                _pistolSlot?.Refresh();
                _meleeSlot?.Refresh();
                _backpackSlot?.Refresh();
                UpdateOccupiedCellTints();
                UpdateInternalBorders();
                EnsureItemsContainersOnTop();
                RefreshAllWindows();

                // ═══ ФИКС «пропадающих названий»: отложенный пересбор текстов должен
                // запускаться после КАЖДОЙ refresh-проходки. Если старая корутина ещё
                // висит — перезапускаем, иначе предметы, пересозданные «поздней»
                // проходкой, останутся с пустым TMP-мешем. ═══
                if (_textRebuildCoroutine != null)
                {
                    StopCoroutine(_textRebuildCoroutine);
                    _textRebuildCoroutine = null;
                }
                if (gameObject.activeInHierarchy)
                    _textRebuildCoroutine = StartCoroutine(DeferredTextRebuild());
            }
            finally
            {
                _isExecutingRefresh = false;
            }
        }

        /// <summary>
        /// ═══ ФИКС «пропадающих названий» ═══
        /// Ждёт 1 кадр (Canvas пересчитывает stretch-rect'ы в конце кадра),
        /// затем принудительно пересобирает тексты ВСЕХ активных UI_Item.
        /// БЕЗ ЭТОГО МЕТОДА СКРИПТ НЕ КОМПИЛИРУЕТСЯ (CS0103) и Unity запускает
        /// старую сборку — отсюда «вернувшийся» баг с текстом.
        /// </summary>
        private IEnumerator DeferredTextRebuild()
        {
            // v21: два прохода через кадр — закрывает гонку, когда refresh
            // случается сразу после первого пересбора текстов.
            for (int pass = 0; pass < 2; pass++)
            {
                yield return null;
                Canvas.ForceUpdateCanvases();
                foreach (var kvp in _activeItems)
                {
                    if (kvp.Value != null)
                        kvp.Value.ForceTextRefresh();
                }
            }
            _textRebuildCoroutine = null;
        }

        private void RefreshGrid(GridType type, int cols, int rows, Transform container)
        {
            var controller = GetControllerForGrid(type);
            if (controller == null || container == null) return;

            for (int y = 0; y < rows; y++)
                for (int x = 0; x < cols; x++)
                    RefreshSlot(type, x, y, controller, container);
        }

        private void RefreshSlot(GridType type, int x, int y, InventoryController controller, Transform container)
        {
            string key = GetCellKey(type, x, y);
            var item = controller.GetItemAt(x, y);

            if (_activeItems.TryGetValue(key, out var uiItem))
            {
                // ═══ ФИКС: Защита от уничтоженных объектов (Unity fake null) ═══
                if (uiItem == null)
                {
                    _activeItems.Remove(key);
                    if (item != null && controller.IsRootCell(item.InstanceID, x, y))
                        CreateUIItem(item, x, y, type, container);
                    return;
                }

                if (item == null)
                {
                    if (uiItem == _draggedItem)
                    {
                        _activeItems.Remove(key);
                        return;
                    }
                    ReturnToPool(uiItem);
                }
                else
                {
                    if (uiItem.X != x || uiItem.Y != y)
                    {
                        if (uiItem == _draggedItem)
                        {
                            _activeItems.Remove(key);
                            return;
                        }
                        ReturnToPool(uiItem);
                        CreateUIItem(item, x, y, type, container);
                    }
                    else
                    {
                        if (uiItem.Item != null && uiItem.Item.InstanceID != item.InstanceID)
                        {
                            if (uiItem == _draggedItem)
                            {
                                _activeItems.Remove(key);
                            }
                            else
                            {
                                ReturnToPool(uiItem);
                            }
                            CreateUIItem(item, x, y, type, container);
                        }
                        else
                        {
                            // ═══ ФИКС: СНАЧАЛА активация, ПОТОМ данные — TMP должен
                            //     обновляться на activeInHierarchy объекте. ═══
                            uiItem.gameObject.SetActive(true);
                            uiItem.UpdateData(item);
                        }
                    }
                }
            }
            else if (item != null && controller.IsRootCell(item.InstanceID, x, y))
            {
                CreateUIItem(item, x, y, type, container);
            }
        }
        private K_InventorySlotUI GetSlotAt(GridType gridType, int x, int y)
        {
            Transform grid = gridType switch
            {
                GridType.Pockets => _pocketsGrid,
                GridType.Pocket2 => _pocket2Grid,
                GridType.Backpack => _backpackGrid,
                GridType.Container => _surroundingsGrid,
                _ => null
            };
            if (grid == null) return null;

            int columns = GetGridWidth(gridType);
            int index = y * columns + x;
            if (index < 0 || index >= grid.childCount) return null;
            return grid.GetChild(index).GetComponent<K_InventorySlotUI>();
        }

        private string GetCellKey(GridType type, int x, int y)
        {
            if (type == GridType.Container)
            {
                if (_isLootingContainer && _activeContainerWindow != null)
                    return $"Loot_{x}_{y}";
                if (_activeContainerWindow != null)
                    return $"Win_{_activeContainerWindow.BackpackInstanceID}_{x}_{y}";
                return $"Container_{x}_{y}";
            }
            return $"{type}_{x}_{y}";
        }
        private void CreateUIItem(InventoryItem item, int x, int y, GridType type, Transform container)
        {
            string key = GetCellKey(type, x, y);
            if (_activeItems.ContainsKey(key)) return;

            if (container == null || _uiItemPrefab == null || item == null) return;

            var uiItem = GetPooledItem();
            if (uiItem == null) return;

            uiItem.transform.SetParent(container, false);
            uiItem.transform.SetAsLastSibling();

            var rect = uiItem.GetComponent<RectTransform>();
            if (rect != null)
            {
                Vector2Int currentSize = item.CurrentSize;
                float widthPx = currentSize.x * _slotSize + (currentSize.x - 1) * _slotSpacing;
                float heightPx = currentSize.y * _slotSize + (currentSize.y - 1) * _slotSpacing;

                Vector2 padding = type switch
                {
                    GridType.Pockets => _pocketsGridPadding,
                    GridType.Pocket2 => _pocket2GridPadding,
                    GridType.Backpack => _backpackGridPadding,
                    GridType.Container => _containerGridPadding,
                    _ => Vector2.zero
                };

                rect.anchorMin = new Vector2(0f, 1f);
                rect.anchorMax = new Vector2(0f, 1f);
                rect.pivot = new Vector2(0f, 1f);
                rect.sizeDelta = new Vector2(widthPx, heightPx);

                rect.anchoredPosition = new Vector2(
                    padding.x + x * (_slotSize + _slotSpacing),
                    -padding.y - y * (_slotSize + _slotSpacing)
                );

                rect.localScale = Vector3.one;
                rect.localRotation = Quaternion.identity;
            }

            uiItem.gameObject.SetActive(true);
            uiItem.Setup(item, this, type, x, y);
            if (type == GridType.Container) uiItem.BindController(_activeContainerController);
            _activeItems[key] = uiItem;
        }

        private Transform GetItemsContainer(GridType type) => type switch
        {
            GridType.Pockets => _pocketsItemsContainer,
            GridType.Pocket2 => _pocket2ItemsContainer,
            GridType.Backpack => _backpackItemsContainer,
            GridType.Container => _surroundingsItemsContainer,
            _ => null
        };

        private void SyncItemsContainerPositions()
        {
            SyncContainer(_pocketsGrid, _pocketsItemsContainer);
            SyncContainer(_pocket2Grid, _pocket2ItemsContainer);

            // ДИАГНОСТИКА Pocket2: логируем позицию контейнера и grid'а
            if (_pocket2Grid != null && _pocket2ItemsContainer != null)
            {
                var gridRT = _pocket2Grid.GetComponent<RectTransform>();
                var contRT = _pocket2ItemsContainer.GetComponent<RectTransform>();
                var contCG = _pocket2ItemsContainer.GetComponent<CanvasGroup>();
                Debug.Log($"[DIAG Pocket2] Grid parent={_pocket2Grid.parent?.name}, " +
                    $"Container parent={_pocket2ItemsContainer.parent?.name}, " +
                    $"Container.active={_pocket2ItemsContainer.gameObject.activeSelf}, " +
                    $"CG.alpha={contCG?.alpha}, CG.blocksRaycasts={contCG?.blocksRaycasts}, " +
                    $"Grid.rect={gridRT?.rect}, Container.anchoredPos={contRT?.anchoredPosition}, " +
                    $"Container.sizeDelta={contRT?.sizeDelta}, Container.localScale={contRT?.localScale}");
            }

            SyncContainer(_backpackGrid, _backpackItemsContainer);
            SyncContainer(_surroundingsGrid, _surroundingsItemsContainer);
        }

        /// <summary>
        /// Синхронизирует itemsContainer с grid через world-space.
        ///
        /// ФИКС БАГ 1 (предметы улетают за пределы / зависают в ящике окружения):
        /// Предыдущая реализация имела три проблемы:
        ///   1) В ветке "разные родители" world-координата передавалась в
        ///      ScreenPointToLocalPointInRectangle как screen-координата —
        ///      для ScreenSpaceCamera Canvas это давало полностью неверную позицию.
        ///   2) В ветке "same parent" копировались anchorMin/anchorMax/pivot grid'а.
        ///      Если grid имеет stretch-anchors ((0,0)→(1,1)), itemsContainer тоже
        ///      получал stretch-anchors, но sizeDelta копировался как есть —
        ///      это давало НУЛЕВОЙ размер при stretch, либо двойной при min-size.
        ///   3) Компонент SyncRectTransform на itemsContainer перезаписывал позицию
        ///      каждый кадр в LateUpdate, конфликтуя с ручной синхронизацией.
        ///
        /// Решение: ВСЕГДА использовать world-space через InverseTransformPoint.
        /// Всегда ставить top-left anchors (0,1), чтобы совпадало с системой
        /// координат, которую использует CreateUIItem для предметов.
        /// </summary>
        private void SyncContainer(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;

            RectTransform gridRect = grid.GetComponent<RectTransform>();
            RectTransform itemsRect = itemsContainer.GetComponent<RectTransform>();

            if (gridRect == null || itemsRect == null) return;

            // ═══════════════════════════════════════════════════
            // Быстрая ветка: itemsContainer — дочерний элемент grid'а
            // (surroundings container после RebuildSurroundingsGrid).
            // anchoredPosition=(0,0) с top-left anchors/pivot точно
            // совпадает с top-left углом grid'а. Никаких конверсий.
            // ═══════════════════════════════════════════════════
            if (itemsContainer.parent == grid)
            {
                itemsRect.anchorMin = new Vector2(0f, 1f);
                itemsRect.anchorMax = new Vector2(0f, 1f);
                itemsRect.pivot = new Vector2(0f, 1f);
                itemsRect.sizeDelta = gridRect.sizeDelta;
                itemsRect.anchoredPosition = Vector2.zero;
                itemsRect.localScale = Vector3.one;
                return;
            }

            // ═══════════════════════════════════════════════════
            // Разные родители (pockets/backpack) — синхронизация
            // через world-space.
            // ════════════════════════════════════════════════════
            Vector3[] gridCorners = new Vector3[4];
            gridRect.GetWorldCorners(gridCorners);

            Vector3 worldTopLeft = gridCorners[1];
            Vector2 worldSize = gridCorners[2] - gridCorners[0];

            Vector2 localTopLeft;
            Vector2 parentScale = Vector2.one;

            if (itemsRect.parent != null)
            {
                localTopLeft = itemsRect.parent.InverseTransformPoint(worldTopLeft);
                parentScale = new Vector2(
                    Mathf.Abs(itemsRect.parent.lossyScale.x),
                    Mathf.Abs(itemsRect.parent.lossyScale.y));
            }
            else
            {
                localTopLeft = worldTopLeft;
            }

            Vector2 localSize = new Vector2(
                worldSize.x / parentScale.x,
                worldSize.y / parentScale.y);

            // Компенсация разницы между пивотом и anchor-точкой родителя
            RectTransform parentRect = itemsRect.parent as RectTransform;
            if (parentRect != null)
            {
                localTopLeft -= new Vector2(parentRect.rect.xMin, parentRect.rect.yMax);
            }

            itemsRect.anchorMin = new Vector2(0f, 1f);
            itemsRect.anchorMax = new Vector2(0f, 1f);
            itemsRect.pivot = new Vector2(0f, 1f);
            itemsRect.sizeDelta = localSize;
            itemsRect.anchoredPosition = localTopLeft;
            itemsRect.localScale = gridRect.localScale;
        }

        #endregion

        #region Occupied Cell Tinting

        private void UpdateOccupiedCellTints()
        {
            ResetAllSlotColors();
            TintOccupiedCells(GridType.Pockets, _pocketsController);
            TintOccupiedCells(GridType.Pocket2, _pocket2Controller);
            TintOccupiedCells(GridType.Backpack, _backpackController);
            if (_isLootingContainer && _activeContainerController != null)
                TintOccupiedCells(GridType.Container, _activeContainerController);
        }

        private void ResetAllSlotColors()
        {
            ResetGridSlotColors(_pocketsGrid);
            ResetGridSlotColors(_pocket2Grid);
            ResetGridSlotColors(_backpackGrid);
            ResetGridSlotColors(_surroundingsGrid);
        }

        private void ResetGridSlotColors(Transform grid)
        {
            if (grid == null) return;
            for (int i = 0; i < grid.childCount; i++)
            {
                var slot = grid.GetChild(i).GetComponent<K_InventorySlotUI>();
                slot?.ResetCellColor();
            }
        }

        private void TintOccupiedCells(GridType gridType, InventoryController controller)
        {
            if (controller == null) return;
            for (int y = 0; y < controller.Height; y++)
            {
                for (int x = 0; x < controller.Width; x++)
                {
                    if (controller.GetItemAt(x, y) != null)
                    {
                        var slot = GetSlotAt(gridType, x, y);
                        slot?.TintOccupied(_occupiedCellTint);
                    }
                }
            }
        }

        #endregion

        #region Internal Border Hiders

        /// <summary>
        /// Скрывает границы сетки между ячейками, занятыми одним предметом.
        /// Border hider'ы размещаются в дочернем overlay внутри grid'а (не в itemsContainer!),
        /// чтобы их локальные координаты ТОЧНО совпадали со слотами — без sub-pixel смещения.
        /// </summary>
        private void UpdateInternalBorders()
        {
            // Если тумблер выключен — НЕ скрываем линии сетки внутри предметов.
            // Все активные hider'ы возвращаются в пул (если остались от предыдущих
            // вызовов), новых не создаётся. Сетка внутри предметов остаётся видимой.
            if (!_hideBordersUnderItems)
            {
                ReturnAllBorderHidersToPool();
                return;
            }

            try
            {
                // Возвращаем все активные hider'ы в пул
                foreach (var hider in _activeBorderHiders)
                {
                    if (hider == null) continue;
                    hider.SetActive(false);
                    _borderHiderPool.Enqueue(hider);
                }
                _activeBorderHiders.Clear();

                // Создаём hider'ы для каждой сетки (через grid-local overlay)
                CreateBorderHidersForGrid(_pocketsController, _pocketsGrid, _pocketsGridPadding);
                CreateBorderHidersForGrid(_pocket2Controller, _pocket2Grid, _pocket2GridPadding);
                CreateBorderHidersForGrid(_backpackController, _backpackGrid, _backpackGridPadding);
                if (_isLootingContainer && _activeContainerController != null)
                    CreateBorderHidersForGrid(_activeContainerController, _surroundingsGrid, _containerGridPadding);
            }
            catch (System.Exception ex)
            {
                // БАГ #5 ФИКС: MissingReferenceException может возникнуть если
                // панель/слоты были уничтожены во время refresh. Логируем и
                // продолжаем — refresh не должен падать целиком.
                Debug.LogWarning($"[UpdateInternalBorders] Skipped due to: {ex.GetType().Name}: {ex.Message}");
            }
        }

        /// <summary>
        /// Получает или создаёт дочерний объект BorderOverlay внутри grid'а.
        /// Overlay имеет LayoutElement.ignoreLayout = true, чтобы GridLayoutGroup
        /// его не трогал. Координаты внутри overlay совпадают с локальными
        /// координатами grid'а (top-left pivot, anchoredPosition = 0).
        /// </summary>
        private Transform GetOrCreateBorderOverlay(Transform grid)
        {
            if (grid == null) return null;

            Transform overlay = grid.Find("BorderOverlay");
            if (overlay != null) return overlay;

            var obj = new GameObject("BorderOverlay", typeof(RectTransform));
            obj.transform.SetParent(grid, false);

            // Исключаем из GridLayoutGroup
            var le = obj.AddComponent<LayoutElement>();
            le.ignoreLayout = true;

            var rt = obj.GetComponent<RectTransform>();
            // Top-left anchors/pivot — совпадает с системой координат слотов
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = Vector2.zero;
            rt.localScale = Vector3.one;

            // Размер = размер grid'а
            var gridRect = grid.GetComponent<RectTransform>();
            if (gridRect != null)
                rt.sizeDelta = gridRect.sizeDelta;

            // Если itemsContainer — дочерний элемент grid'а (surroundings),
            // ставим overlay ПЕРЕД ним, чтобы hider'ы были ПОД предметами
            if (_surroundingsItemsContainer != null && _surroundingsItemsContainer.parent == grid)
                obj.transform.SetSiblingIndex(_surroundingsItemsContainer.GetSiblingIndex());

            return obj.transform;
        }

        private void CreateBorderHidersForGrid(InventoryController controller, Transform grid, Vector2 padding)
        {
            if (controller == null || grid == null) return;

            Transform overlay = GetOrCreateBorderOverlay(grid);
            if (overlay == null) return;

            // Синхронизируем размер overlay с grid'ом (на случай ресайза)
            var gridRect = grid.GetComponent<RectTransform>();
            var overlayRect = overlay.GetComponent<RectTransform>();
            if (gridRect != null && overlayRect != null)
                overlayRect.sizeDelta = gridRect.sizeDelta;

            float step = _slotSize + _slotSpacing;

            for (int y = 0; y < controller.Height; y++)
            {
                for (int x = 0; x < controller.Width; x++)
                {
                    var item = controller.GetItemAt(x, y);
                    if (item == null || !controller.IsRootCell(item.InstanceID, x, y))
                        continue;

                    Vector2Int size = item.CurrentSize;

                    // Вертикальные линии (между ячейками в одной строке)
                    // Ширина = thickness, Высота = slotSize - top - bottom (может быть > slotSize при отрицательных inset)
                    for (int dy = 0; dy < size.y; dy++)
                    {
                        for (int dx = 0; dx < size.x - 1; dx++)
                        {
                            float posX = padding.x + (x + dx + 1) * step - _borderHiderThickness / 2f;
                            float posY = -(padding.y + (y + dy) * step) - _bhInsetTop;
                            float h = _slotSize - _bhInsetTop - _bhInsetBottom;
                            if (h > 0f)
                                SpawnBorderHider(overlay, posX, posY, _borderHiderThickness, h);
                        }
                    }

                    // Горизонтальные линии (между ячейками в одном столбце)
                    // Высота = thickness, Ширина = slotSize - left - right
                    for (int dx = 0; dx < size.x; dx++)
                    {
                        for (int dy = 0; dy < size.y - 1; dy++)
                        {
                            float posX = padding.x + (x + dx) * step + _bhInsetLeft;
                            float posY = -(padding.y + (y + dy + 1) * step) + _borderHiderThickness / 2f;
                            float w = _slotSize - _bhInsetLeft - _bhInsetRight;
                            if (w > 0f)
                                SpawnBorderHider(overlay, posX, posY, w, _borderHiderThickness);
                        }
                    }
                }
            }
        }

        private void SpawnBorderHider(Transform parent, float posX, float posY, float width, float height)
        {
            GameObject hider;
            if (_borderHiderPool.Count > 0)
                hider = _borderHiderPool.Dequeue();
            else
                hider = new GameObject("BorderHider", typeof(RectTransform), typeof(Image));

            hider.transform.SetParent(parent, false);

            var img = hider.GetComponent<Image>();
            if (img == null) img = hider.AddComponent<Image>();
            img.color = _borderHiderColor;
            img.raycastTarget = false;
            img.maskable = true;
            img.sprite = null;
            img.type = Image.Type.Simple;

            var rt = hider.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(posX, posY);
            rt.sizeDelta = new Vector2(width, height);
            rt.localScale = Vector3.one;
            rt.localRotation = Quaternion.identity;

            hider.SetActive(true);
            _activeBorderHiders.Add(hider);
        }

        /// <summary>
        /// Возвращает все активные border hider'ы в пул и очищает список.
        /// </summary>
        private void ReturnAllBorderHidersToPool()
        {
            foreach (var hider in _activeBorderHiders)
            {
                hider.SetActive(false);
                _borderHiderPool.Enqueue(hider);
            }
            _activeBorderHiders.Clear();
        }

        #endregion

        #region Drag & Drop System

        public void StartDrag(UI_Item draggedItem, PointerEventData eventData)
        {
            // ФИКС БАГ (audit) #11: делегируем в TryStartDrag и игнорируем bool.
            // Реальная проверка ошибки делается в TryStartDrag.
            TryStartDrag(draggedItem, eventData);
        }

        /// <summary>
        /// ФИКС БАГ (audit) #11: Безопасный BeginDrag с возвращаемым значением.
        /// Возвращает false, если drag не удалось начать (item==null, либо
        /// source controller не смог RemoveItem). В этом случае UI_Item НЕ
        /// должен скрывать CanvasGroup — предмет остаётся видимым.
        /// </summary>
        public bool TryStartDrag(UI_Item draggedItem, PointerEventData eventData)
        {
            if (draggedItem?.Item == null || _dragGhost == null || _dragGhostRT == null) return false;

            // ФИКС: Запрещаем перетаскивание на ПКМ/средней.
            if (eventData.button != PointerEventData.InputButton.Left) return false;

            // ═══════════════════════════════════════════════════════════════
            // БАГ-ФИКС: Если предыдущий drag оставил предмет "в воздухе"
            // (_dragItemRemoved=true) и fallback ещё не вернул его —
            // новый OnBeginDrag остановит корутину, и предмет потеряется.
            // Решение: возвращаем предмет СИНХРОННО перед новым drag.
            // ═══════════════════════════════════════════════════════════════
            if (_dragItemRemoved && _draggedItem?.Item != null)
            {
                var orphanItem = _draggedItem.Item;
                var originController = GetControllerForGrid(_dragOriginGridType);
                bool orphanPlaced = false;
                if (originController != null)
                {
                    orphanPlaced = originController.PlaceExistingItem(orphanItem, _dragOriginX, _dragOriginY);
                    if (!orphanPlaced)
                        orphanPlaced = originController.PlaceExistingItemInFirstFreeSlot(orphanItem);
                }
                if (!orphanPlaced)
                {
                    Debug.LogWarning($"[START-DRAG] Orphan item '{orphanItem.Data?.DisplayName}' " +
                                      "could not be returned to origin. Trying all player grids.");
                    orphanPlaced = TryPlaceInAnyPlayerGrid(orphanItem);
                }
                if (!orphanPlaced)
                    Debug.LogError($"[START-DRAG] Orphan item '{orphanItem.Data?.DisplayName}' " +
                                   $"is LOST! InstanceID={orphanItem.InstanceID}");
                _dragItemRemoved = false;
                _dropHandled = false;
                _needsPostDragRefresh = false;
            }

            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedFromSlotIconRotation = 0f;
            _draggedItem = draggedItem;
            _isDragging = true;
            _dropHandled = false;
            _needsPostDragRefresh = false;

            // Отменяем pending fallback refresh
            if (_postDragRefreshCoroutine != null)
            {
                StopCoroutine(_postDragRefreshCoroutine);
                _postDragRefreshCoroutine = null;
            }

            // ФИКС #3: Сохраняем оригинальную позицию и УДАЛЯЕМ предмет из сетки.
            _dragOriginGridType = draggedItem.GridType;
            _dragOriginX = draggedItem.X;
            _dragOriginY = draggedItem.Y;
            _dragOriginRotationAngle = draggedItem.Item.RotationAngle;
            _dragOriginFolded = draggedItem.Item.IsFolded;
            _dragItemRemoved = false;

            // ФИКС: Используем BoundController только для Container (плавающие окна)
            var sourceController = (draggedItem.GridType == GridType.Container && draggedItem.BoundController != null)
                ? draggedItem.BoundController
                : GetControllerForGrid(draggedItem.GridType);

            // ═══════════════════════════════════════════════════════════════
            // ФИКС БАГ (audit) #11: проверяем результат RemoveItem.
            // Если RemoveItem вернул false (item не в positionCache, либо
            // controller disposed), НЕ продолжаем drag — иначе предмет
            // останется в source, но UI будет считать его «удалённым»,
            // и drop в destination создаст дубликат.
            // ═══════════════════════════════════════════════════════════════
            if (sourceController != null)
            {
                bool removed = sourceController.RemoveItem(draggedItem.Item);
                if (!removed)
                {
                    Debug.LogWarning(
                        $"[StartDrag] RemoveItem failed for '{draggedItem.Item.Data?.DisplayName}'. " +
                        "Aborting drag to avoid duplication.");
                    // Сбрасываем drag state — UI_Item тоже не должен скрывать view.
                    _isDragging = false;
                    _draggedItem = null;
                    return false;
                }
                _dragItemRemoved = true;

                // ФИКС: сразу очищаем occupied tint с ячеек, которые занимал предмет.
                Vector2Int originSize = draggedItem.Item.CurrentSize;
                for (int dy = 0; dy < originSize.y; dy++)
                {
                    for (int dx = 0; dx < originSize.x; dx++)
                    {
                        var slot = GetSlotAt(draggedItem.GridType,
                            draggedItem.X + dx, draggedItem.Y + dy);
                        if (slot != null)
                            slot.ResetCellColor();
                    }
                }
            }
            else
            {
                // Нет controller — не можем безопасно начать drag.
                Debug.LogWarning(
                    $"[StartDrag] No source controller for GridType={draggedItem.GridType}. Aborting.");
                _isDragging = false;
                _draggedItem = null;
                return false;
            }

            // Снимаем hover при начале drag
            if (_hoveredItem == draggedItem)
            {
                _hoveredItem.SetSelected(false);
                _hoveredItem = null;
            }

            SetupDragOutline(draggedItem.Item);

            // ФИКС БАГ #3 (v2): Включаем raycast на слотах для OnDrop
            SetAllGridSlotsRaycast(true);

            // >>> НОВЫЙ ФИКС: Отключаем рейкаст у окна перетаскиваемого рюкзака <<<
            RestoreRaycastForDraggedBackpackWindow();
            DisableRaycastForDraggedBackpackWindow(draggedItem.Item);
            // ----------------------------------------------------------------

            _dragGhost.SetActive(true);
            UpdateDragGhostPosition(eventData);

            // ═══ ФИКС ДВОЕНИЯ ИКОНОК ═══
            var cg = draggedItem.GetComponent<CanvasGroup>();
            if (cg == null) cg = draggedItem.gameObject.AddComponent<CanvasGroup>();
            cg.alpha = 0f;
            cg.blocksRaycasts = false;

            return true;
        }

        public void StartDragFromEquipmentSlot(K_EquipmentSlotUI slot, PointerEventData eventData)
        {
            if (slot?.EquippedItem == null || _dragGhost == null || _dragGhostRT == null) return;

            // ФИКС: Запрещаем перетаскивание предметов на ПКМ/средней.
            if (eventData.button != PointerEventData.InputButton.Left)
            {
                // Возвращаем видимость иконке слота, если она была скрыта
                var icon = slot.transform.Find("Icon");
                if (icon != null)
                {
                    var cg = icon.GetComponent<CanvasGroup>();
                    if (cg != null)
                    {
                        cg.alpha = 1f;
                        cg.blocksRaycasts = true;
                    }
                }
                return;
            }

            var item = slot.EquippedItem;

            // ФИКС БАГ 1: Вычисляем правильный RotationAngle, чтобы призрак не лежал на боку.
            // Мы хотим, чтобы визуальный угол в сетке совпадал с углом в слоте (slot.IconEulerZ).
            // Формула: visualAngle = IconBaseRotation - RotationAngle
            // Следовательно: RotationAngle = IconBaseRotation - slot.IconEulerZ
            if (slot.SlotType == EquipmentSlotType.Backpack)
            {
                int targetAngle = Mathf.RoundToInt(item.IconBaseRotation - slot.IconEulerZ);
                int normalizedTarget = ((targetAngle % 360) + 360) % 360;
                int safety = 0;
                while (((item.RotationAngle % 360 + 360) % 360) != normalizedTarget && safety < 4)
                {
                    item.Rotate();
                    safety++;
                }
            }

            _draggedFromEquipmentSlot = slot;
            _draggedFromSlotItem = item;
            _draggedItem = null;
            _isDragging = true;
            _dropHandled = false;
            _dragItemRemoved = false;
            _needsPostDragRefresh = false;
            _draggedFromSlotIconRotation = slot.IconEulerZ;
            // v12: запоминаем исходное состояние предмета (для RestoreDragOriginState).
            _dragOriginRotationAngle = item.RotationAngle;
            _dragOriginFolded = item.IsFolded;

            if (_postDragRefreshCoroutine != null)
            {
                StopCoroutine(_postDragRefreshCoroutine);
                _postDragRefreshCoroutine = null;
            }

            SetupDragOutline(item);
            SetAllGridSlotsRaycast(true);
            RestoreRaycastForDraggedBackpackWindow();
            DisableRaycastForDraggedBackpackWindow(item);

            _dragGhost.SetActive(true);
            UpdateDragGhostPosition(eventData);
        }
        public void UpdateDragGhostPosition(PointerEventData eventData)
        {
            if (!_isDragging || _dragGhost == null || !_dragGhost.activeSelf || _dragGhostRT == null) return;

            RectTransform canvasRT = _rootCanvasTransform as RectTransform;
            if (canvasRT == null) return;

            // ИСПРАВЛЕНИЕ БАГ 2: передаём _rootCanvasCamera вместо null.
            // Для ScreenSpaceCamera Canvas без камеры конверсия неправильная —
            // ghost смещается пропорционально позиции на экране,
            // поэтому на разных клетках разное расстояние до подсветки.
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRT, eventData.position, _rootCanvasCamera, out Vector2 localPoint))
                _dragGhostRT.anchoredPosition = localPoint;

            // ФИКС БАГ (user feedback — иконка застревает):
            // UpdateDragCellHighlights имеет throttle (30 FPS), чтобы избежать лагов
            // при глубоком вложении рюкзаков. Position ghost обновляется КАЖДЫЙ кадр
            // (это дёшево), а heavy raycast/highlights — реже.
            UpdateDragCellHighlights();
        }

        /// <summary>
        /// Вращение при перетаскивании: 2 состояния (0°→90°→0° циклично).
        /// Предмет уже удалён из сетки при старте drag.
        /// </summary>
        private void RotateDraggedItem()
        {
            // ═══ БАГ 1 ФИКС (дублирование при вращении): защитная проверка ═══
            // Вращение разрешено ТОЛЬКО во время активной drag-сессии, когда
            // предмет уже удалён из source-контроллера (_dragItemRemoved=true
            // для предметов из сетки) или находится в слоте экипировки
            // (_draggedFromEquipmentSlot != null).
            //
            // Если вращать предмет, который всё ещё находится в контроллере
            // (например, из-за рассинхронизации состояния после прерванного
            // drag-and-drop), его CurrentSize изменится, но клетки в _grid
            // останутся указывать на старый размер. Это создаёт несоответствие
            // между моделью и UI, и при следующем RefreshGrid может появиться
            // дубликат.
            if (!_isDragging)
            {
                Debug.LogWarning("[RotateDraggedItem] Rejected: drag session not active.");
                return;
            }

            var item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null) return;

            // Для предметов из сетки — обязательно _dragItemRemoved=true.
            // Для предметов из слота экипировки — _draggedFromEquipmentSlot != null.
            if (_draggedFromEquipmentSlot == null && !_dragItemRemoved)
            {
                Debug.LogWarning($"[RotateDraggedItem] Rejected: item '{item.Data?.DisplayName}' " +
                    "is still in source controller (dragItemRemoved=false). Rotating it would " +
                    "desync grid cells from CurrentSize.");
                return;
            }

            // FIX БАГ 4: Для предметов из слота экипировки вращение доступно
            // даже если CanRotate=false в данных (визуальное положение в слоте
            // фиксировано, но в сетке предмет может быть повёрнут).
            if (!item.Data.CanRotate && _draggedFromEquipmentSlot == null) return;

            // ═══ БАГ 1 v5 ФИКС: проверка, что _draggedItem всё ещё валиден ═══
            // Если _draggedItem был возвращён в пул (например, из-за бага в
            // RefreshSlot, который мы только что исправили), его gameObject
            // может быть неактивным. Вращать такой предмет бессмысленно —
            // это создаст несоответствие между ghost и реальным UI_Item.
            // Логируем состояние для диагностики.
            int prevAngle = item.RotationAngle;
            Vector2Int prevSize = item.CurrentSize;

            // Прямое вращение без привязки к сетке
            item.Rotate();

            Debug.Log($"[RotateDraggedItem] '{item.Data?.DisplayName}': " +
                $"angle {prevAngle}→{item.RotationAngle}, " +
                $"size {prevSize.x}x{prevSize.y}→{item.CurrentSize.x}x{item.CurrentSize.y}, " +
                $"draggedItem={(_draggedItem != null ? "valid" : "null")}, " +
                $"dragItemRemoved={_dragItemRemoved}");

            UpdateGhostSize();
            UpdateGhostRotation();
            // ФИКС: обновляем подсветку ячеек после смены размера
            UpdateDragCellHighlights();
        }

        private void UpdateGhostSize()
        {
            if (_dragGhostRT == null) return;

            // БАГ #1 ФИКС: body и иконка используют РАЗНЫЕ размеры.
            //   - body: CurrentSize — учитывает поворот (становится (h,w) при rotation=90).
            //   - иконка: НОРМАЛЬНЫЙ размер (без поворота) — GetNormalIconSize.
            //     Если IconBaseRotation меняет оси (90°/270°), swap'аем normalSize
            //     при расчёте размера иконки — это компенсирует поворот body.
            //
            // Раньше currentSize и normalSize были одинаковыми (оба CurrentSize),
            // что приводило к двойному swap'у осей для иконок с IconBaseRotation=90°
            // (оружие). Иконка меняла размер при повороте тела предмета —
            // это и есть БАГ #1.
            Vector2Int currentSize;
            Vector2Int normalSize;

            var iconItem = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (iconItem != null)
            {
                currentSize = iconItem.CurrentSize;
                normalSize = GetNormalIconSize(iconItem);
            }
            else
            {
                currentSize = new Vector2Int(1, 1);
                normalSize = new Vector2Int(1, 1);
            }

            float bodyW = currentSize.x * _slotSize + (currentSize.x - 1) * _slotSpacing;
            float bodyH = currentSize.y * _slotSize + (currentSize.y - 1) * _slotSpacing;
            _dragGhostRT.sizeDelta = new Vector2(bodyW, bodyH);

            // Иконка ghost — размер по normalSize с swap для IconBaseRotation.
            float baseRot = iconItem?.IconBaseRotation ?? 0f;
            bool iconSwapsAxes = Mathf.Abs(baseRot % 180) > 0.01f;
            int iconWcells = iconSwapsAxes ? normalSize.y : normalSize.x;
            int iconHcells = iconSwapsAxes ? normalSize.x : normalSize.y;
            float iconW = iconWcells * _slotSize + (iconWcells - 1) * _slotSpacing;
            float iconH = iconHcells * _slotSize + (iconHcells - 1) * _slotSpacing;
            _dragGhostIconRect.sizeDelta = new Vector2(iconW, iconH);
        }

        /// <summary>
        /// БАГ #1 ФИКС: Возвращает нормальный (не повернутый) размер иконки.
        /// Тот же алгоритм, что в UI_Item.GetNormalIconSize — вынесен в
        /// K_InventoryUI чтобы переиспользовать для drag ghost.
        /// </summary>
        private static Vector2Int GetNormalIconSize(InventoryItem item)
        {
            if (item?.Data == null) return new Vector2Int(1, 1);
            var data = item.Data;
            if (item.IsFolded && data.CanFold) return data.SizeFolded;
            if (data.IsBackpack && data.UnfoldedIconSize.x > 0 && data.UnfoldedIconSize.y > 0)
                return data.UnfoldedIconSize;
            if (data.IsBackpack && data.BackpackWidth > 0 && data.BackpackHeight > 0)
                return new Vector2Int(data.BackpackWidth, data.BackpackHeight);
            return data.Size;
        }

        private void UpdateGhostRotation()
        {
            var item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null || _dragGhostIconRect == null) return;

            _dragGhostRT.localRotation = Quaternion.identity;

            // Единая формула для ВСЕХ случаев:
            // visualAngle = IconBaseRotation - RotationAngle
            //
            // Для предметов из слота экипировки:
            //   _draggedFromSlotIconRotation хранит визуальный угол иконки В СЛОТЕ
            //   (slot.IconEulerZ). Для рюкзака это 0°, для оружия -90°.
            //   Но IconBaseRotation предмета может отличаться от slot.IconEulerZ.
            //   Разница (IconBaseRotation - slot.IconEulerZ) — это «поправка»,
            //   которую нужно добавить к базовой формуле.
            //
            // Итого:
            //   Из сетки:  visualAngle = IconBaseRotation - RotationAngle
            //   Из слота:  visualAngle = IconBaseRotation - RotationAngle
            //              (та же формула! slot.IconEulerZ уже учтён в том,
            //               как иконка отображалась в слоте, а ghost должен
            //               выглядеть так же, как предмет выглядел бы в сетке)

            float visualAngle = item.IconBaseRotation - item.RotationAngle;

            _dragGhostIconRect.localRotation = Quaternion.Euler(0, 0, visualAngle);
        }
        /// <summary>
        /// Подсветка во время drag:
        /// - над пустыми слотами — рамка размером тащимого предмета (зелёная/красная);
        /// - над иконкой рюкзака, который может принять — жёлтый hover иконки;
        /// - над рюкзаком, который принять не может — красная обводка (DrawBackpackInvalidOutline);
        /// - над СОБСТВЕННОЙ сеткой тащимого рюкзака — без обводки вообще.
        /// </summary>
        private void UpdateDragCellHighlights()
        {
            if (EventSystem.current == null) return;
            if (Time.unscaledTime - _lastDragHighlightTime < 0.033f) return;
            _lastDragHighlightTime = Time.unscaledTime;

            InventoryItem item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null) { ClearHighlightsKeepGhostVisible(); return; }

            if (_cachedEventData == null || _cachedEventSystem != EventSystem.current)
            {
                _cachedEventSystem = EventSystem.current;
                _cachedEventData = new PointerEventData(EventSystem.current);
            }
            _cachedEventData.position = Input.mousePosition;
            _raycastBuffer.Clear();
            EventSystem.current.RaycastAll(_cachedEventData, _raycastBuffer);

            K_ContainerWindow topWindow = FindTopWindowFromBuffer(_raycastBuffer);

            K_InventorySlotUI hitSlot = null;
            bool canPlace = false;
            UI_Item backpackHit = null;
            bool canPlaceInBackpackIcon = false;
            InventoryController hitController = null;

            // ТРИГГЕР 1 — «ИКОНКА»: визуальное перекрытие rect'ов ghost и рюкзака.
            if (_dragGhostRT != null)
            {
                UI_Item ghostBackpack = FindBestBackpackUnderGhost(item, topWindow);
                if (ghostBackpack != null)
                {
                    backpackHit = ghostBackpack;
                    canPlaceInBackpackIcon = CanPlaceItemInBackpackIcon(ghostBackpack.Item, item);
                }
            }

            // НОВЫЙ ТРИГГЕР: Принудительный поиск рюкзака по Raycast (чтобы иконка 100% перехватывала дроп)
            if (backpackHit == null)
            {
                foreach (var result in _raycastBuffer)
                {
                    var uiItem = result.gameObject.GetComponentInParent<UI_Item>();
                    if (uiItem != null && uiItem != _draggedItem && uiItem.Item != null
                        && uiItem.Item.Data != null && uiItem.Item.Data.IsBackpack
                        && BackpackMatchesTopWindow(uiItem, topWindow))
                    {
                        backpackHit = uiItem;
                        canPlaceInBackpackIcon = CanPlaceItemInBackpackIcon(uiItem.Item, item);
                        break; // Рюкзак найден — ломаем цикл, слоты больше не ищем!
                    }
                }
            }

            foreach (var result in _raycastBuffer)
            {
                var slot = result.gameObject.GetComponent<K_InventorySlotUI>();
                if (slot != null)
                {
                    if (backpackHit == null)
                    {
                        var backpackOnSlot = FindBackpackCoveringSlot(slot);
                        if (backpackOnSlot != null && BackpackMatchesTopWindow(backpackOnSlot, topWindow))
                        {
                            backpackHit = backpackOnSlot;
                            canPlaceInBackpackIcon = CanPlaceItemInBackpackIcon(backpackOnSlot.Item, item);
                        }
                    }

                    if (backpackHit != null)
                    {
                        if (canPlaceInBackpackIcon) break;

                        if (IsSameGrid(slot, backpackHit))
                        {
                            int bx = backpackHit.X, by = backpackHit.Y;
                            Vector2Int bs = backpackHit.Item.CurrentSize;
                            if (slot.X >= bx && slot.X < bx + bs.x && slot.Y >= by && slot.Y < by + bs.y)
                                break;
                        }
                        backpackHit = null;
                        canPlaceInBackpackIcon = false;
                    }

                    if (!SlotMatchesTopWindow(slot, topWindow)) continue;

                    InventoryController controller;
                    if (slot.GridType == GridType.Container && slot.BoundController != null) controller = slot.BoundController;
                    else controller = GetControllerForGrid(slot.GridType);
                    if (controller == null) continue;

                    int gridW, gridH;
                    if (slot.GridType == GridType.Container) { gridW = controller.Width; gridH = controller.Height; }
                    else { gridW = GetGridWidth(slot.GridType); gridH = GetGridHeight(slot.GridType); }

                    Vector2Int itemSize = item.CurrentSize;
                    var (targetX, targetY) = CalculateSnapPosition(slot.X, slot.Y, itemSize, gridW, gridH);

                    if (backpackHit == null)
                    {
                        var bpInFootprint = FindBackpackInFootprint(controller, targetX, targetY, item);
                        if (bpInFootprint != null && !controller.CanPlaceItem(item, targetX, targetY))
                        {
                            var bpUi = FindUIItemForItem(bpInFootprint);
                            if (bpUi != null)
                            {
                                backpackHit = bpUi;
                                canPlaceInBackpackIcon = CanPlaceItemInBackpackIcon(bpInFootprint, item);
                                break;
                            }
                        }
                    }

                    canPlace = controller.CanPlaceItem(item, targetX, targetY);
                    if (canPlace && slot.GridType == GridType.Backpack && item.Data?.IsBackpack == true)
                    {
                        if (_backpackSlot != null && _backpackSlot.EquippedItem == item) canPlace = false;
                    }
                    if (canPlace && slot.GridType == GridType.Container && _openContainerWindows.Any(w => w != null && w.Controller == controller && w.BackpackInstanceID == item.InstanceID.ToString())) canPlace = false;

                    if (canPlace && slot.GridType == GridType.Container)
                    {
                        InventoryItem targetBackpack = null;
                        var targetWindow = _openContainerWindows.Find(w => w.Controller == controller);
                        if (targetWindow != null && uint.TryParse(targetWindow.BackpackInstanceID, out uint targetId))
                            targetBackpack = FindItemByInstanceId(targetId);
                        if (targetBackpack != null && WouldCreateCircularReference(item, targetBackpack)) canPlace = false;
                    }

                    hitSlot = slot;
                    hitController = controller;
                    break;
                }

                var equipSlot = result.gameObject.GetComponent<K_EquipmentSlotUI>();
                if (equipSlot != null)
                {
                    if (backpackHit != null) break;
                    canPlace = ValidateEquipItem(item, equipSlot);
                    break;
                }
            }

            bool draggedIsBackpack = item.Data != null && item.Data.IsBackpack;
            bool overOwnContainerWindow = draggedIsBackpack && topWindow != null && topWindow.BackpackInstanceID == item.InstanceID.ToString();
            bool overOwnBackpackGrid = draggedIsBackpack && hitSlot != null && hitSlot.GridType == GridType.Backpack && _backpackSlot != null && _backpackSlot.EquippedItem == item;

            if (overOwnContainerWindow || overOwnBackpackGrid)
            {
                if (_hoveredItem != null) { _hoveredItem.SetSelected(false); _hoveredItem = null; }
                if (_dragGhost != null) _dragGhost.SetActive(true);
                ClearDragCellHighlights();
                return;
            }

            bool backpackAbsorbsDrop = backpackHit != null && canPlaceInBackpackIcon;

            if (backpackHit != null)
            {
                if (_dragGhost != null) _dragGhost.SetActive(true);
                if (_hoveredItem != null && _hoveredItem != backpackHit) _hoveredItem.SetSelected(false);

                if (backpackAbsorbsDrop)
                {
                    backpackHit.SetSelected(true);
                    _hoveredItem = backpackHit;
                    ClearDragCellHighlights();
                }
                else
                {
                    _hoveredItem = null;
                    // Теперь обводка будет рисоваться строго по рюкзаку
                    DrawBackpackInvalidOutline(backpackHit, item);
                }
                return;
            }

            if (_hoveredItem != null) { _hoveredItem.SetSelected(false); _hoveredItem = null; }
            if (hitSlot == null) { ClearHighlightsKeepGhostVisible(); return; }

            if (_dragGhost != null) _dragGhost.SetActive(true);
            Vector2Int itemSize2 = item.CurrentSize;
            int gridW2, gridH2;
            if (hitSlot.GridType == GridType.Container && hitController != null) { gridW2 = hitController.Width; gridH2 = hitController.Height; }
            else { gridW2 = GetGridWidth(hitSlot.GridType); gridH2 = GetGridHeight(hitSlot.GridType); }

            var (tx, ty) = CalculateSnapPosition(hitSlot.X, hitSlot.Y, itemSize2, gridW2, gridH2);
            Color outlineColor2 = canPlace ? _dragOutlineValidColor : _dragOutlineInvalidColor;

            Transform grid;
            if (hitSlot.GridType == GridType.Container)
            {
                grid = hitSlot.transform.parent;
                while (grid != null && grid.GetComponent<GridLayoutGroup>() == null) grid = grid.parent;
                if (grid == null) grid = _surroundingsGrid;
            }
            else
            {
                grid = hitSlot.GridType switch { GridType.Pockets => _pocketsGrid, GridType.Pocket2 => _pocket2Grid, GridType.Backpack => _backpackGrid, _ => null };
            }
            if (grid == null) return;
            ShowDragOutline(grid, hitSlot.GridType, tx, ty, itemSize2, outlineColor2);
        }
        private bool IsSameGrid(K_InventorySlotUI slot, UI_Item backpack)
        {
            if (slot == null || backpack == null) return false;
            if (slot.GridType != backpack.GridType) return false;
            if (slot.GridType == GridType.Container)
                return slot.BoundController != null && slot.BoundController == backpack.BoundController;
            return true;
        }

        /// <summary>Пересекает ли снап-позиция тащимого предмета footprint целевого рюкзака.</summary>


        /// <summary>v12: рюкзак внутри футпринта дропа (даже при частичном перекрытии).</summary>
        private InventoryItem FindBackpackInFootprint(InventoryController controller, int targetX, int targetY, InventoryItem item)
        {
            if (controller == null || item == null) return null;
            var size = item.CurrentSize;
            for (int dy = 0; dy < size.y; dy++)
                for (int dx = 0; dx < size.x; dx++)
                {
                    int cx = targetX + dx, cy = targetY + dy;
                    if (cx >= 0 && cx < controller.Width && cy >= 0 && cy < controller.Height)
                    {
                        var other = controller.GetItemAt(cx, cy);
                        if (other != null && other != item && other.Data != null && other.Data.IsBackpack)
                            return other;
                    }
                }
            return null;
        }

        /// <summary>v12: поиск UI_Item по InventoryItem (для подсветки рюкзака).</summary>
        private UI_Item FindUIItemForItem(InventoryItem item)
        {
            if (item == null) return null;
            foreach (var kvp in _activeItems)
                if (kvp.Value != null && kvp.Value.Item == item)
                    return kvp.Value;
            return null;
        }
        private bool SnapIntersectsBackpack(K_InventorySlotUI slot, InventoryItem item, UI_Item backpack)
        {
            if (backpack?.Item == null) return false;
            int gridW, gridH;
            if (slot.GridType == GridType.Container && slot.BoundController != null)
            {
                gridW = slot.BoundController.Width;
                gridH = slot.BoundController.Height;
            }
            else
            {
                gridW = GetGridWidth(slot.GridType);
                gridH = GetGridHeight(slot.GridType);
            }
            var (tx, ty) = CalculateSnapPosition(slot.X, slot.Y, item.CurrentSize, gridW, gridH);
            Vector2Int s = item.CurrentSize;
            int bx = backpack.X, by = backpack.Y;
            Vector2Int bs = backpack.Item.CurrentSize;
            return tx < bx + bs.x && bx < tx + s.x && ty < by + bs.y && by < ty + s.y;
        }
        private K_ContainerWindow FindTopWindowFromBuffer(List<RaycastResult> buffer)
        {
            for (int i = 0; i < buffer.Count; i++)
            {
                var win = buffer[i].gameObject.GetComponentInParent<K_ContainerWindow>();
                if (win != null && win.isActiveAndEnabled && _openContainerWindows.Contains(win))
                    return win;
            }
            return null;
        }

        /// <summary>Слот учитывается, только если он из верхнего окна (или окна под курсором нет).</summary>
        private bool SlotMatchesTopWindow(K_InventorySlotUI slot, K_ContainerWindow topWindow)
        {
            if (topWindow == null) return true;
            return slot.GridType == GridType.Container
                && slot.BoundController != null
                && slot.BoundController == topWindow.Controller;
        }

        /// <summary>Рюкзак-иконка учитывается, только если он из верхнего окна (или окна нет).</summary>
        private bool BackpackMatchesTopWindow(UI_Item backpackUi, K_ContainerWindow topWindow)
        {
            if (topWindow == null) return true;
            return backpackUi.BoundController != null
                && backpackUi.BoundController == topWindow.Controller;
        }

        /// <summary>
        /// ТРИГГЕР «ИКОНКА»: ищет рюкзак, которого ВИЗУАЛЬНО накрывает прямоугольник
        /// ghost'а (пересечение screen-rect'ов), а не по одной точке и НЕ по логическому
        /// footprint'у слота. Порог отсекает ложные срабатывания на касание углом:
        /// принимаем, если центр ghost внутри рюкзака, ИЛИ центр рюкзака внутри ghost,
        /// ИЛИ перекрытие >= 25% меньшей площади.
        /// Фильтр topWindow не даёт «светиться сквозь» нижнее окно матрёшки.
        /// </summary>
        private UI_Item FindBestBackpackUnderGhost(InventoryItem draggedItem, K_ContainerWindow topWindow)
        {
            if (_dragGhostRT == null) return null;

            // screen-rect ghost'а
            Vector3[] gc = new Vector3[4];
            _dragGhostRT.GetWorldCorners(gc);
            Vector2 gMin = new Vector2(float.MaxValue, float.MaxValue);
            Vector2 gMax = new Vector2(float.MinValue, float.MinValue);
            for (int i = 0; i < 4; i++)
            {
                Vector2 sp = RectTransformUtility.WorldToScreenPoint(_rootCanvasCamera, gc[i]);
                if (sp.x < gMin.x) gMin.x = sp.x;
                if (sp.y < gMin.y) gMin.y = sp.y;
                if (sp.x > gMax.x) gMax.x = sp.x;
                if (sp.y > gMax.y) gMax.y = sp.y;
            }
            if (gMin.x >= gMax.x || gMin.y >= gMax.y) return null;
            Vector2 gCenter = (gMin + gMax) * 0.5f;
            float areaG = (gMax.x - gMin.x) * (gMax.y - gMin.y);
            if (areaG <= 0f) return null;

            UI_Item best = null;
            float bestScore = -1f;
            Vector3[] bc = new Vector3[4];

            foreach (var kvp in _activeItems)
            {
                var ui = kvp.Value;
                if (ui == null || ui == _draggedItem) continue;
                if (ui.Item == null || ui.Item.Data == null || !ui.Item.Data.IsBackpack) continue;
                if (!ui.gameObject.activeInHierarchy) continue;
                if (!BackpackMatchesTopWindow(ui, topWindow)) continue;

                var rt = ui.transform as RectTransform;
                if (rt == null) continue;
                rt.GetWorldCorners(bc);

                Vector2 bMin = new Vector2(float.MaxValue, float.MaxValue);
                Vector2 bMax = new Vector2(float.MinValue, float.MinValue);
                for (int i = 0; i < 4; i++)
                {
                    Vector2 sp = RectTransformUtility.WorldToScreenPoint(_rootCanvasCamera, bc[i]);
                    if (sp.x < bMin.x) bMin.x = sp.x;
                    if (sp.y < bMin.y) bMin.y = sp.y;
                    if (sp.x > bMax.x) bMax.x = sp.x;
                    if (sp.y > bMax.y) bMax.y = sp.y;
                }
                if (bMin.x >= bMax.x || bMin.y >= bMax.y) continue;

                float ix = Mathf.Min(gMax.x, bMax.x) - Mathf.Max(gMin.x, bMin.x);
                float iy = Mathf.Min(gMax.y, bMax.y) - Mathf.Max(gMin.y, bMin.y);
                if (ix <= 0f || iy <= 0f) continue;          // нет перекрытия
                float overlap = ix * iy;

                float areaB = (bMax.x - bMin.x) * (bMax.y - bMin.y);
                float minArea = Mathf.Min(areaG, areaB);
                Vector2 bCenter = (bMin + bMax) * 0.5f;
                bool centerGinB = gCenter.x >= bMin.x && gCenter.x <= bMax.x && gCenter.y >= bMin.y && gCenter.y <= bMax.y;
                bool centerBinG = bCenter.x >= gMin.x && bCenter.x <= gMax.x && bCenter.y >= gMin.y && bCenter.y <= gMax.y;

                // Порог: реальный визуальный контакт, а не касание углом.
                if (!centerGinB && !centerBinG && overlap < minArea * 0.25f)
                    continue;

                float score = overlap
                    + (centerBinG ? 1e6f : 0f)
                    + (centerGinB ? 1e6f : 0f)
                    - Vector2.Distance(gCenter, bCenter) * 0.01f;
                if (score > bestScore)
                {
                    bestScore = score;
                    best = ui;
                }
            }
            return best;
        }

        /// <summary>
        /// ТРИГГЕР 3: Ищет рюкзак, покрывающий данный слот, по _activeItems.
        /// Нужен когда ghost/курсор не попали напрямую в UI_Item рюкзака,
        /// но слот находится внутри его footprint.
        /// </summary>
        private UI_Item FindBackpackCoveringSlot(K_InventorySlotUI slot)
        {
            if (slot == null) return null;
            foreach (var kvp in _activeItems)
            {
                var ui = kvp.Value;
                if (ui == null || ui.Item == null || ui.Item.Data == null) continue;
                if (!ui.Item.Data.IsBackpack) continue;
                if (ui.GridType != slot.GridType) continue;
                if (ui == _draggedItem) continue;
                // Для Container grid — контроллеры должны совпадать
                if (slot.GridType == GridType.Container)
                {
                    if (slot.BoundController == null || ui.BoundController == null) continue;
                    if (slot.BoundController != ui.BoundController) continue;
                }
                int bx = ui.X, by = ui.Y;
                Vector2Int bs = ui.Item.CurrentSize;
                if (slot.X >= bx && slot.X < bx + bs.x &&
                    slot.Y >= by && slot.Y < by + bs.y)
                    return ui;
            }
            return null;
        }
        private void DrawBackpackInvalidOutline(UI_Item backpackUI, InventoryItem draggedItem)
        {
            if (backpackUI?.Item == null || backpackUI.Item.Data == null || draggedItem == null) return;

            GridType gridType = backpackUI.GridType;
            int bx = backpackUI.X;
            int by = backpackUI.Y;

            Transform grid = null;
            if (gridType == GridType.Container)
            {
                var t = backpackUI.transform.parent;
                while (t != null)
                {
                    if (t.GetComponent<GridLayoutGroup>() != null) { grid = t; break; }
                    t = t.parent;
                }
                if (grid == null) grid = _surroundingsGrid;
            }
            else
            {
                grid = gridType switch
                {
                    GridType.Pockets => _pocketsGrid,
                    GridType.Pocket2 => _pocket2Grid,
                    GridType.Backpack => _backpackGrid,
                    _ => null
                };
            }
            if (grid == null) return;

            int gridW, gridH;
            if (gridType == GridType.Container && backpackUI.BoundController != null)
            {
                gridW = backpackUI.BoundController.Width;
                gridH = backpackUI.BoundController.Height;
            }
            else
            {
                gridW = GetGridWidth(gridType);
                gridH = GetGridHeight(gridType);
            }

            // ═══ Рамка следует за СНАП-ФУТПРИНТОМ тащимого предмета —
            // поэтому снова может НАПОЛОВИНУ перекрывать предмет. Но рисуется ТОЛЬКО
            // если снап-футпринт реально ПЕРЕСЕКАЕТ клетки рюкзака. ═══
            var draggedSize = draggedItem.CurrentSize;
            if (!TryGetSnapTargetInGrid(grid, draggedSize, gridW, gridH, out int sx, out int sy)) return;

            var bpSize = backpackUI.Item.CurrentSize;
            bool intersects = sx < bx + bpSize.x && bx < sx + draggedSize.x
                           && sy < by + bpSize.y && by < sy + draggedSize.y;
            if (!intersects) return;

            ShowDragOutline(grid, gridType, sx, sy, draggedSize, _dragOutlineInvalidColor);
        }
        private bool TryGetSnapTargetInGrid(Transform grid, Vector2Int size, int gridW, int gridH, out int sx, out int sy)
        {
            sx = sy = 0;
            if (_dragGhostRT == null || grid == null) return false;
            var gridRT = grid.GetComponent<RectTransform>();
            var layout = grid.GetComponent<GridLayoutGroup>();
            if (gridRT == null || layout == null) return false;

            Vector3 centerWorld = _dragGhostRT.TransformPoint(_dragGhostRT.rect.center);
            Vector2 screen = RectTransformUtility.WorldToScreenPoint(null, centerWorld);
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(gridRT, screen, null, out var local))
                return false;

            // pivot сетки (0,1): local.x — вправо от левого края, local.y — вниз со знаком минус.
            float stepX = layout.cellSize.x + layout.spacing.x;
            float stepY = layout.cellSize.y + layout.spacing.y;
            int cx = Mathf.FloorToInt(local.x / stepX);
            int cy = Mathf.FloorToInt(-local.y / stepY);

            var (x, y) = CalculateSnapPosition(cx, cy, size, gridW, gridH);
            sx = x; sy = y;
            return true;
        }
        private bool IsGhostCenterOverBackpack(UI_Item backpackUI)
        {
            if (_dragGhostRT == null || backpackUI == null) return false;
            var bpRect = backpackUI.transform as RectTransform;
            if (bpRect == null) return false;

            Vector3 center = _dragGhostRT.TransformPoint(_dragGhostRT.rect.center);
            Vector3[] corners = new Vector3[4];
            bpRect.GetWorldCorners(corners);

            float minX = Mathf.Min(corners[0].x, corners[1].x, corners[2].x, corners[3].x);
            float maxX = Mathf.Max(corners[0].x, corners[1].x, corners[2].x, corners[3].x);
            float minY = Mathf.Min(corners[0].y, corners[1].y, corners[2].y, corners[3].y);
            float maxY = Mathf.Max(corners[0].y, corners[1].y, corners[2].y, corners[3].y);

            return center.x >= minX && center.x <= maxX && center.y >= minY && center.y <= maxY;
        }
        private bool BackpackHasNoSpaceFor(InventoryItem backpackItem, InventoryItem item)
        {
            if (backpackItem == null || item == null || backpackItem.Data == null) return false;
            if (backpackItem.InstanceID == item.InstanceID) return false;
            // Свёрнутый — структурный invalid, не «полный».
            if (backpackItem.IsFolded && !backpackItem.Data.AlwaysShowGrid) return false;
            if (!backpackItem.HasInternalGrid) return false;
            // Циклические ссылки — структурный invalid.
            if (item.Data != null && item.Data.IsBackpack)
            {
                if (item.ContainsDescendant(backpackItem.InstanceID)) return false;
                if (backpackItem.ContainsDescendant(item.InstanceID)) return false;
            }

            // Живой контроллер (рюкзак открыт окном) — честная проверка места.
            string bpIdStr = backpackItem.InstanceID.ToString();
            if (_openedBackpacks.TryGetValue(bpIdStr, out var liveCtrl) && liveCtrl != null)
                return !ControllerCanFitWithAutoRotate(liveCtrl, item);

            // Закрытый рюкзак — по сериализованным данным.
            var savedItems = backpackItem.GetBackpackSavedItems();
            int totalCells = backpackItem.Data.BackpackWidth * backpackItem.Data.BackpackHeight;
            int occupiedCells = 0;
            foreach (var saved in savedItems)
            {
                var template = K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID);
                if (template != null)
                {
                    var sz = saved.IsRotated
                        ? new Vector2Int(template.Size.y, template.Size.x)
                        : template.Size;
                    occupiedCells += sz.x * sz.y;
                }
            }
            int freeCells = totalCells - occupiedCells;
            var itemSize = item.CurrentSize;
            return freeCells < itemSize.x * itemSize.y;
        }
        private bool TryGetGridCellFromScreen(Vector2 screenPos, Transform grid, out int cx, out int cy)
        {
            cx = cy = -1;
            if (grid == null) return false;
            var gridRT = grid.GetComponent<RectTransform>();
            var layout = grid.GetComponent<GridLayoutGroup>();
            if (gridRT == null || layout == null) return false;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(gridRT, screenPos, _rootCanvasCamera, out Vector2 local))
                return false;

            float stepX = _slotSize + _slotSpacing;
            float stepY = _slotSize + _slotSpacing;
            // pivot grid'а = (0,1) (top-left) → local.y <= 0
            float lx = local.x - layout.padding.left;
            float ly = -local.y - layout.padding.top;
            if (lx < 0f || ly < 0f) return false;

            cx = Mathf.FloorToInt(lx / stepX);
            cy = Mathf.FloorToInt(ly / stepY);
            return true;
        }

        private bool CanPlaceItemInBackpackIcon(InventoryItem backpackItem, InventoryItem item)
        {
            if (backpackItem == null || item == null) return false;
            if (backpackItem.InstanceID == item.InstanceID) return false;

            // ФИКС БАГ (user feedback — red ghost on folded backpack):
            // СВЁРНУТЫЙ рюкзак НЕ может принять предметы через drag-and-drop
            // на иконку (если AlwaysShowGrid=false). Игрок должен сначала
            // развернуть рюкзак. ВАЖНО: AlwaysShowGrid=true разрешает приём
            // даже в свёрнутом состоянии (по спеку фичи #1).
            if (backpackItem.IsFolded && !backpackItem.Data.AlwaysShowGrid)
                return false;

            // Развёрнутый рюкзак без внутренней сетки тоже не может принимать.
            if (!backpackItem.HasInternalGrid) return false;

            if (item.Data != null && item.Data.IsBackpack)
            {
                item.GetBackpackSavedItems();
                if (item.ContainsDescendant(backpackItem.InstanceID)) return false;
            }

            if (backpackItem.ContainsDescendant(item.InstanceID)) return false;

            // ═══════════════════════════════════════════════════════════
            // ФИКС: Если рюкзак открыт как окно — проверяем через ЖИВОЙ
            // контроллер, а не через устаревший _backpackContentsSerialized.
            // ═══════════════════════════════════════════════════════════
            string bpIdStr = backpackItem.InstanceID.ToString();
            if (_openedBackpacks.TryGetValue(bpIdStr, out var liveCtrl) && liveCtrl != null)
            {
                return ControllerCanFitWithAutoRotate(liveCtrl, item);
            }

            // Рюкзак НЕ открыт — проверяем по сериализованным данным
            var savedItems = backpackItem.GetBackpackSavedItems();
            int totalCells = backpackItem.Data.BackpackWidth * backpackItem.Data.BackpackHeight;
            int occupiedCells = 0;
            foreach (var saved in savedItems)
            {
                var template = K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID);
                if (template != null)
                {
                    var sz = saved.IsRotated
                        ? new Vector2Int(template.Size.y, template.Size.x)
                        : template.Size;
                    occupiedCells += sz.x * sz.y;
                }
            }
            int freeCells = totalCells - occupiedCells;
            var itemSize = item.CurrentSize;
            return freeCells >= itemSize.x * itemSize.y;
        }
        /// <summary>
        /// БАГ #3 ФИКС: Находит grid, в котором лежит указанный предмет.
        /// Возвращает (grid Transform, GridType, x, y) или (null, default, 0, 0).
        /// </summary>
        /// /// <summary>
        /// v13: Влезает ли предмет в контроллер С УЧЁТОМ авто-поворота —
        /// зеркалит логику дропа (TryDropItemIntoBackpack → TryFindPlacementWithAutoRotate),
        /// чтобы подсветка не показывала invalid, когда дроп развернёт предмет и положит.
        /// </summary>
        private bool ControllerCanFitWithAutoRotate(InventoryController controller, InventoryItem item)
        {
            if (controller == null || item == null) return false;
            var size = item.CurrentSize;
            if (controller.CanFitItem(size)) return true;
            if (item.Data != null && item.Data.CanRotate)
            {
                var rot = new Vector2Int(size.y, size.x);
                if ((rot.x != size.x || rot.y != size.y) && controller.CanFitItem(rot)) return true;
            }
            return false;
        }
        private (Transform grid, GridType gridType, int x, int y) FindItemGridLocation(InventoryItem item)
        {
            if (item == null) return (null, default, 0, 0);

            var (gridType, x, y) = FindItemLocation(item);
            if (gridType == null) return (null, default, 0, 0);

            Transform grid = gridType.Value switch
            {
                GridType.Pockets => _pocketsGrid,
                GridType.Pocket2 => _pocket2Grid,
                GridType.Backpack => _backpackGrid,
                GridType.Container => _surroundingsGrid,
                _ => null
            };
            return (grid, gridType.Value, x, y);
        }

        /// <summary>
        /// Показывает рамку-подсветку вокруг ячеек, которые займёт предмет при дропе.
        /// Рамка состоит из 4 Image-полосок (верх, низ, лево, право) внутри grid'а.
        /// </summary>
        private void ShowDragOutline(Transform grid, GridType gridType, int tx, int ty, Vector2Int itemSize, Color color)
        {
            EnsureDragOutlineFrame();

            // Репарентим при смене grid'а
            if (_outlineCurrentParent != grid)
            {
                _dragOutlineFrame.transform.SetParent(grid, false);
                _outlineCurrentParent = grid;
            }

            float cellStep = _slotSize + _slotSpacing;
            Vector2 padding = GetPaddingForGrid(gridType);
            float t = _dragOutlineThickness;

            // Позиция и размер всей области (top-left anchor, pivot top-left)
            float frameX = padding.x + tx * cellStep;
            float frameY = -(padding.y + ty * cellStep); // UI Y инвертирован
            float frameW = itemSize.x * cellStep - _slotSpacing;
            float frameH = itemSize.y * cellStep - _slotSpacing;

            // Обрезаем рамку по границам сетки, чтобы не вылезала за неё
            var gridRT = grid.GetComponent<RectTransform>();
            float gridRight = gridRT.rect.width;
            float gridBottom = -gridRT.rect.height;

            float clampedLeft = Mathf.Max(frameX, 0f);
            float clampedTop = Mathf.Min(frameY, 0f);
            float clampedRight = Mathf.Min(frameX + frameW, gridRight);
            float clampedBottom = Mathf.Max(frameY - frameH, gridBottom);

            float clampedW = clampedRight - clampedLeft;
            float clampedH = clampedTop - clampedBottom;

            var frameRT = _dragOutlineFrame.GetComponent<RectTransform>();
            frameRT.anchorMin = new Vector2(0, 1);
            frameRT.anchorMax = new Vector2(0, 1);
            frameRT.pivot = new Vector2(0, 1);

            if (clampedW <= 0 || clampedH <= 0)
            {
                _dragOutlineFrame.SetActive(false);
                return;
            }

            frameRT.anchoredPosition = new Vector2(clampedLeft, clampedTop);
            frameRT.sizeDelta = new Vector2(clampedW, clampedH);

            // Верхняя полоска
            SetEdgeRect(_outlineTop, 0, 0, clampedW, t);
            // Нижняя полоска
            SetEdgeRect(_outlineBottom, 0, -clampedH + t, clampedW, t);
            // Левая полоска
            SetEdgeRect(_outlineLeft, 0, -t, t, clampedH - 2 * t);
            // Правая полоска
            SetEdgeRect(_outlineRight, clampedW - t, -t, t, clampedH - 2 * t);

            // Обновляем цвет только если изменился
            if (_outlineLastColor != color)
            {
                _outlineTop.color = color;
                _outlineBottom.color = color;
                _outlineLeft.color = color;
                _outlineRight.color = color;
                _outlineLastColor = color;
            }

            _dragOutlineFrame.SetActive(true);
        }

        /// <summary>Устанавливает позицию и размер edge-полоски (top-left anchor, pivot top-left).</summary>
        private void SetEdgeRect(Image img, float x, float y, float w, float h)
        {
            var rt = img.rectTransform;
            rt.anchorMin = new Vector2(0, 1);
            rt.anchorMax = new Vector2(0, 1);
            rt.pivot = new Vector2(0, 1);
            rt.anchoredPosition = new Vector2(x, y);
            rt.sizeDelta = new Vector2(w, h);
        }

        /// <summary>Ленивое создание рамки подсветки (4 Image-полоски).</summary>
        private void EnsureDragOutlineFrame()
        {
            if (_dragOutlineFrame != null) return;

            _dragOutlineFrame = new GameObject("DragOutline", typeof(RectTransform));
            // LayoutElement с ignoreLayout чтобы не влиял на GridLayoutGroup
            var le = _dragOutlineFrame.AddComponent<LayoutElement>();
            le.ignoreLayout = true;

            _outlineTop = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeTop");
            _outlineBottom = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeBottom");
            _outlineLeft = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeLeft");
            _outlineRight = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeRight");

            _dragOutlineFrame.SetActive(false);
        }

        /// <summary>Создаёт дочерний Image для одной стороны рамки.</summary>
        private Image CreateEdgeImage(Transform parent, string name)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var img = go.GetComponent<Image>();
            img.sprite = null;
            img.type = Image.Type.Simple;
            img.color = Color.clear;
            img.raycastTarget = false;
            return img;
        }

        /// <summary>Скрывает рамку подсветки.</summary>
        private void HideDragOutline()
        {
            if (_dragOutlineFrame != null)
            {
                // Выносим из grid'а чтобы ClearGrid не уничтожил рамку
                // при следующем RebuildSurroundingsGrid / RebuildBackpackGrid.
                _dragOutlineFrame.transform.SetParent(transform, false);
                _dragOutlineFrame.SetActive(false);
            }
            _outlineCurrentParent = null;
            _outlineLastColor = Color.clear;
        }

        /// <summary>
        /// Смещает ghost так, чтобы его центр совпадал с центром подсвеченной области ячеек.
        /// Без этого ghost стоит на курсоре, а подсветка — со смещением (до пол-ячейки).
        /// </summary>
        private void SnapGhostToHighlightArea(GridType gridType, int tx, int ty, Vector2Int itemSize)
        {
            if (_dragGhostRT == null || _rootCanvasTransform == null) return;

            var topLeftSlot = GetSlotAt(gridType, tx, ty);
            if (topLeftSlot == null) return;

            var slotRT = topLeftSlot.transform as RectTransform;
            var canvasRT = _rootCanvasTransform as RectTransform;
            if (slotRT == null || canvasRT == null) return;

            // Центр левой верхней ячейки → canvas-local координаты
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                canvasRT, slotRT.position, null, out Vector2 slotCenterLocal))
                return;

            // Смещение от центра первой ячейки до центра всей подсвеченной области
            float cellStep = _slotSize + _slotSpacing;
            float offsetX = ((float)itemSize.x - 1f) * 0.5f * cellStep;
            float offsetY = -((float)itemSize.y - 1f) * 0.5f * cellStep; // минус: UI Y инвертирован

            _dragGhostRT.anchoredPosition = slotCenterLocal + new Vector2(offsetX, offsetY);
        }

        private void ClearDragCellHighlights()
        {
            HideDragOutline();
        }

        /// <summary>За границей сетки: подсветку убрать, ghost оставить видимым.</summary>
        private void ClearHighlightsKeepGhostVisible()
        {
            ClearDragCellHighlights();
            // Ghost НЕ скрываем — игрок должен видеть что он тащит
        }

        private void HideDragGhostAndClearHighlights()
        {
            ClearDragCellHighlights();
            if (_dragGhost != null) _dragGhost.SetActive(false);
        }

        /// <summary>
        /// ФИКС БАГ #3 (v2): Переключает raycastTarget на фоновых Image слотов.
        /// Когда НЕ таскаем — слоты НЕ блокируют raycast, предметы можно кликать.
        /// Когда таскаем — слоты СТАНОВЯТСЯ raycast-целями для OnDrop.
        /// Это решает проблему, когда itemsContainer и grid имеют разных родителей
        /// (SetAsLastSibling не помогает → слоты блокируют IBeginDragHandler).
        /// </summary>
        private void SetAllGridSlotsRaycast(bool enabled)
        {
            SetGridSlotsRaycast(_pocketsGrid, enabled);
            SetGridSlotsRaycast(_pocket2Grid, enabled);
            SetGridSlotsRaycast(_backpackGrid, enabled);
            SetGridSlotsRaycast(_surroundingsGrid, enabled);

            // FIX БАГ 1: Переключаем raycast на слотах ВСЕХ открытых окон.
            foreach (var window in _openContainerWindows)
            {
                if (window == null || window.GridRect == null) continue;
                SetGridSlotsRaycast(window.GridRect, enabled);
            }

            // FIX БАГ 1: КРИТИЧЕСКИЙ вызов — переключает blocksRaycasts на контейнерах.
            SetItemsContainersBlocksRaycasts(!enabled);

            foreach (var window in _openContainerWindows)
            {
                if (window == null || window.GridRect == null) continue;
                SetGridSlotsRaycast(window.GridRect, enabled);
            }

            SetItemsContainersBlocksRaycasts(!enabled);
        }
        private void SetItemsContainersBlocksRaycasts(bool blocksRaycasts)
        {
            // FIX: Чтобы работал Drag-and-Drop по картинке рюкзака (UI_Item), 
            // blocksRaycasts ВСЕГДА должен быть true для контейнеров с предметами.
            var containers = new[] { _pocketsItemsContainer, _pocket2ItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                var cg = container.GetComponent<CanvasGroup>();
                if (cg != null)
                    cg.blocksRaycasts = true; // Жестко ставим true
            }

            // Окна-контейнеры: blocksRaycasts тоже ВСЕГДА true.
            foreach (var window in _openContainerWindows)
            {
                if (window == null || window.ItemsContainer == null) continue;
                var cg = window.ItemsContainer.GetComponent<CanvasGroup>();
                if (cg != null)
                    cg.blocksRaycasts = true;
            }
        }

        private void SetGridSlotsRaycast(Transform grid, bool enabled)
        {
            if (grid == null)
            {
                Debug.LogWarning($"[Raycast] SetGridSlotsRaycast: grid is NULL!");
                return;
            }
            int count = 0;
            for (int i = 0; i < grid.childCount; i++)
            {
                var slotUI = grid.GetChild(i).GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    slotUI.SetRaycastEnabled(enabled);
                    count++;
                }
            }
            Debug.Log($"[Raycast] {grid.name}: {enabled} on {count}/{grid.childCount} children");
        }

        public bool TryPlaceItem(UI_Item draggedItem, GridType targetGrid, int targetX, int targetY)
        {
            if (draggedItem?.Item == null) return false;
            if (!_isDragging || _draggedItem != draggedItem)
            {
                Debug.LogWarning(
                    $"[TryPlaceItem] Rejected: drag session not active for this UI_Item " +
                    $"(isDragging={_isDragging}, draggedItemMatch={_draggedItem == draggedItem}).");
                return false;
            }

            var item = draggedItem.Item;
            var targetController = (targetGrid == GridType.Container && _dropTargetController != null)
                ? _dropTargetController : GetControllerForGrid(targetGrid);
            if (targetController == null)
            {
                Debug.Log($"[InventoryUI] TryPlaceItem REJECTED: no controller for {targetGrid}");
                return false;
            }

            var sourceController = (draggedItem.GridType == GridType.Container && draggedItem.BoundController != null)
                ? draggedItem.BoundController
                : GetControllerForGrid(draggedItem.GridType);

            // ═══ НОВАЯ СИСТЕМА СВАПА ПРЕДМЕТОВ ═══
            if (!targetController.CanPlaceItem(item, targetX, targetY))
            {
                var targetItem = targetController.GetItemAt(targetX, targetY);
                if (targetItem != null && targetItem != item)
                {
                    return TrySwapItems(draggedItem, targetGrid, targetItem);
                }
            }
            // ═══ КОНЕЦ БЛОКА СВАПА ═══

            InventoryItem backpackInFootprint = FindBackpackInFootprint(targetController, targetX, targetY, item);
            bool directPlacePossible = targetController.CanPlaceItem(item, targetX, targetY);
            if (backpackInFootprint != null && !directPlacePossible)
            {
                if (TryDropItemIntoBackpack(draggedItem, backpackInFootprint, false))
                    return true;

                if (sourceController != null && _dragItemRemoved)
                {
                    bool restored = sourceController.PlaceExistingItem(item, draggedItem.X, draggedItem.Y);
                    if (!restored)
                    {
                        RestoreDragOriginState(item);
                        restored = sourceController.PlaceExistingItem(item, draggedItem.X, draggedItem.Y);
                    }
                    if (!restored) restored = sourceController.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
                    if (!restored) TryPlaceInAnyPlayerGrid(item);
                }

                _dragItemRemoved = false;
                _dropHandled = true;
                _needsPostDragRefresh = false;
                if (_postDragRefreshCoroutine != null) { StopCoroutine(_postDragRefreshCoroutine); _postDragRefreshCoroutine = null; }
                _isDragging = false;
                _draggedItem = null;
                _draggedFromEquipmentSlot = null;
                _draggedFromSlotItem = null;
                _draggedFromSlotIconRotation = 0f;
                if (draggedItem != null) { draggedItem.gameObject.SetActive(false); ReturnToPool(draggedItem); }
                if (_dragGhost != null) _dragGhost.SetActive(false);
                ClearDragCellHighlights();
                SetAllGridSlotsRaycast(false);
                RestoreRaycastForDraggedBackpackWindow();
                if (_hoveredItem != null) { _hoveredItem.SetSelected(false); _hoveredItem = null; }
                ForceRefresh();
                return false;
            }

            if (sourceController == targetController)
            {
                if (_dragItemRemoved)
                {
                    bool placed = targetController.PlaceExistingItem(item, targetX, targetY);
                    if (placed)
                    {
                        if (_postDragRefreshCoroutine != null) { StopCoroutine(_postDragRefreshCoroutine); _postDragRefreshCoroutine = null; }
                        _isDragging = false;
                        _draggedItem = null;
                        _draggedFromEquipmentSlot = null;
                        _draggedFromSlotItem = null;
                        _draggedFromSlotIconRotation = 0f;
                        _dragItemRemoved = false;
                        _dropHandled = true;
                        _needsPostDragRefresh = false;
                        if (draggedItem != null) { draggedItem.gameObject.SetActive(false); ReturnToPool(draggedItem); }
                        EndDragComplete();
                        ForceRefresh();
                        return true;
                    }
                    bool restoredBack = sourceController.PlaceExistingItem(item, draggedItem.X, draggedItem.Y);
                    if (!restoredBack)
                    {
                        RestoreDragOriginState(item);
                        restoredBack = sourceController.PlaceExistingItem(item, draggedItem.X, draggedItem.Y);
                    }
                    if (!restoredBack) restoredBack = sourceController.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
                    if (!restoredBack) TryPlaceInAnyPlayerGrid(item);

                    _dragItemRemoved = false;
                    _dropHandled = true;
                    _needsPostDragRefresh = false;
                    if (_postDragRefreshCoroutine != null) { StopCoroutine(_postDragRefreshCoroutine); _postDragRefreshCoroutine = null; }
                    _isDragging = false;
                    _draggedItem = null;
                    _draggedFromEquipmentSlot = null;
                    _draggedFromSlotItem = null;
                    _draggedFromSlotIconRotation = 0f;
                    if (draggedItem != null) { draggedItem.gameObject.SetActive(false); ReturnToPool(draggedItem); }
                    if (_dragGhost != null) _dragGhost.SetActive(false);
                    ClearDragCellHighlights();
                    SetAllGridSlotsRaycast(false);
                    RestoreRaycastForDraggedBackpackWindow();
                    ForceRefresh();
                    return false;
                }
                else
                {
                    if (draggedItem.X == targetX && draggedItem.Y == targetY) return true;
                    bool moved = sourceController.MoveItem(item, targetX, targetY);
                    if (moved)
                    {
                        _isDragging = false;
                        _draggedItem = null;
                        if (draggedItem != null) { draggedItem.gameObject.SetActive(false); ReturnToPool(draggedItem); }
                        EndDragComplete();
                        ForceRefresh();
                    }
                    return moved;
                }
            }

            if (targetGrid == GridType.Backpack && item.Data?.IsBackpack == true)
            {
                bool isEquippedBackpack = _backpackSlot != null && _backpackSlot.EquippedItem == item;
                if (isEquippedBackpack) return false;
                if (_backpackSlot != null && _backpackSlot.EquippedItem != null)
                {
                    if (WouldCreateCircularReference(item, _backpackSlot.EquippedItem)) return false;
                }
            }

            if (targetGrid == GridType.Container
                && _openContainerWindows.Any(w => w != null && w.Controller == targetController
                    && w.BackpackInstanceID == item.InstanceID.ToString()))
            {
                Debug.Log($"[V14-RECURSION] BLOCKED: backpack '{item.Data?.DisplayName}' cannot be placed into its own container grid (recursion).");
                return false;
            }

            if (targetGrid == GridType.Container)
            {
                InventoryItem targetBackpack = null;
                var targetWindow = _openContainerWindows.Find(w => w.Controller == targetController);
                if (targetWindow != null && uint.TryParse(targetWindow.BackpackInstanceID, out uint targetId))
                {
                    targetBackpack = FindItemByInstanceId(targetId);
                }
                if (targetBackpack != null && WouldCreateCircularReference(item, targetBackpack))
                {
                    Debug.Log($"[NEW-BUG4] BLOCKED: circular reference! Cannot place '{item.Data?.DisplayName}' into '{targetBackpack.Data?.DisplayName}'.");
                    return false;
                }
            }

            if (item.Data != null && item.Data.IsBackpack && _openedBackpacks.ContainsKey(item.InstanceID.ToString()))
                CloseAllWindowsForBackpack(item);

            if (_dragItemRemoved)
            {
                bool placed = targetController.PlaceExistingItem(item, targetX, targetY);
                if (placed)
                {
                    if (_postDragRefreshCoroutine != null) { StopCoroutine(_postDragRefreshCoroutine); _postDragRefreshCoroutine = null; }
                    _isDragging = false;
                    _draggedItem = null;
                    _draggedFromEquipmentSlot = null;
                    _draggedFromSlotItem = null;
                    _draggedFromSlotIconRotation = 0f;
                    _dragItemRemoved = false;
                    _dropHandled = true;
                    _needsPostDragRefresh = false;
                    if (draggedItem != null) { draggedItem.gameObject.SetActive(false); ReturnToPool(draggedItem); }
                    EndDragComplete();
                    ForceRefresh();
                    return true;
                }
                if (sourceController != null)
                {
                    bool restored = sourceController.PlaceExistingItem(item, draggedItem.X, draggedItem.Y);
                    if (!restored)
                    {
                        RestoreDragOriginState(item);
                        restored = sourceController.PlaceExistingItem(item, draggedItem.X, draggedItem.Y);
                    }
                    if (!restored) restored = sourceController.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
                    if (!restored) TryPlaceInAnyPlayerGrid(item);
                }
                else
                {
                    TryPlaceInAnyPlayerGrid(item);
                }

                _dragItemRemoved = false;
                _dropHandled = true;
                _needsPostDragRefresh = false;
                if (_postDragRefreshCoroutine != null) { StopCoroutine(_postDragRefreshCoroutine); _postDragRefreshCoroutine = null; }
                _isDragging = false;
                _draggedItem = null;
                _draggedFromEquipmentSlot = null;
                _draggedFromSlotItem = null;
                _draggedFromSlotIconRotation = 0f;
                if (draggedItem != null) { draggedItem.gameObject.SetActive(false); ReturnToPool(draggedItem); }
                if (_dragGhost != null) _dragGhost.SetActive(false);
                ClearDragCellHighlights();
                SetAllGridSlotsRaycast(false);
                RestoreRaycastForDraggedBackpackWindow();
                ForceRefresh();
                return false;
            }

            int originX = draggedItem.X;
            int originY = draggedItem.Y;
            if (!sourceController.RemoveItem(item))
                return false;

            bool success = targetController.PlaceExistingItem(item, targetX, targetY);
            if (!success)
            {
                bool restored = sourceController.PlaceExistingItem(item, originX, originY);
                if (!restored)
                {
                    RestoreDragOriginState(item);
                    restored = sourceController.PlaceExistingItem(item, originX, originY);
                }
                if (!restored) restored = sourceController.PlaceExistingItemInFirstFreeSlot(item);
                if (!restored) restored = TryPlaceInAnyPlayerGrid(item);
                if (!restored)
                    Debug.LogError($"[TRY-PLACE] Item '{item.Data?.DisplayName}' LOST during cross-grid transfer rollback! InstanceID={item.InstanceID}");
            }

            if (success)
            {
                _isDragging = false;
                _draggedItem = null;
                if (draggedItem != null) { draggedItem.gameObject.SetActive(false); ReturnToPool(draggedItem); }
                EndDragComplete();
                ForceRefresh();
            }
            else
            {
                _dragItemRemoved = false;
                _dropHandled = true;
                _needsPostDragRefresh = false;
                _isDragging = false;
                _draggedItem = null;
                if (draggedItem != null) { draggedItem.gameObject.SetActive(false); ReturnToPool(draggedItem); }
                if (_dragGhost != null) _dragGhost.SetActive(false);
                ClearDragCellHighlights();
                SetAllGridSlotsRaycast(false);
                RestoreRaycastForDraggedBackpackWindow();
                ForceRefresh();
            }
            return success;
        }

        /// <summary>
        /// Безопасная замена (свап) предметов. Возвращает false, если замена невозможна (не влезает размер).
        /// Предотвращает исчезновение предметов: если один не поместился, откатывает изменения.
        /// </summary>
        private bool TrySwapItems(UI_Item draggedUI, GridType targetGrid, InventoryItem targetItem)
        {
            if (draggedUI?.Item == null || targetItem == null) return false;
            if (!_isDragging || _draggedItem != draggedUI) return false; // ИСПРАВЛЕНО: _draggedUI -> _draggedItem

            var item = draggedUI.Item;
            var targetController = (targetGrid == GridType.Container && _dropTargetController != null)
                ? _dropTargetController : GetControllerForGrid(targetGrid);
            var sourceController = (draggedUI.GridType == GridType.Container && draggedUI.BoundController != null)
                ? draggedUI.BoundController
                : GetControllerForGrid(draggedUI.GridType);

            if (targetController == null || sourceController == null) return false;

            // Ищем точную стартовую ячейку (root cell) целевого предмета
            int tX = -1, tY = -1;
            for (int y = 0; y < targetController.Height; y++)
            {
                for (int x = 0; x < targetController.Width; x++)
                {
                    if (targetController.GetItemAt(x, y) == targetItem && targetController.IsRootCell(targetItem.InstanceID, x, y))
                    {
                        tX = x; tY = y; break;
                    }
                }
                if (tX != -1) break;
            }
            if (tX == -1) return false;

            int sX = draggedUI.X;
            int sY = draggedUI.Y;

           
            if (item.Data?.IsBackpack == true || targetItem.Data?.IsBackpack == true)
            {
                // ═══ НОВЫЙ ФИКС: синхронизируем ОБА рюкзака перед проверкой ═══
                if (item.Data != null && item.Data.IsBackpack)
                    SyncBackpackForValidation(item);
                if (targetItem.Data != null && targetItem.Data.IsBackpack)
                    SyncBackpackForValidation(targetItem);

                if (item.ContainsDescendant(targetItem.InstanceID) || targetItem.ContainsDescendant(item.InstanceID))
                {
                    Debug.Log($"[SWAP-CYCLE-BLOCK] Blocked swap between " +
                              $"'{item.Data?.DisplayName}' and '{targetItem.Data?.DisplayName}' — nesting cycle.");
                    return false;
                }
            }

            // 1. Удаляем целевой предмет из его сетки
            targetController.RemoveItem(targetItem);

            // 2. Пробуем поместить тащимый предмет на место целевого
            bool sourcePlaced = targetController.PlaceExistingItem(item, tX, tY);
            if (!sourcePlaced)
            {
                // Если не влезло в ту же точку, пробуем найти любое свободное место
                sourcePlaced = targetController.PlaceExistingItemInFirstFreeSlot(item);
            }

            if (sourcePlaced)
            {
                // 3. Пробуем поместить целевой предмет на место тащимого
                bool targetPlaced = sourceController.PlaceExistingItem(targetItem, sX, sY);
                if (!targetPlaced)
                {
                    targetPlaced = sourceController.PlaceExistingItemInFirstFreeSlot(targetItem);
                }

                if (targetPlaced)
                {
                    // Успех! Завершаем драг.
                    _dropHandled = true;
                    _dragItemRemoved = false;
                    _isDragging = false;
                    draggedUI.gameObject.SetActive(false);
                    ReturnToPool(draggedUI);
                    EndDragComplete();
                    ForceRefresh();
                    return true;
                }
                else
                {
                    // Целевой предмет не влез на место тащимого! ОТКАТ!
                    Debug.Log($"[SWAP] Cannot place target item '{targetItem.Data?.DisplayName}' at source. Rolling back.");
                    targetController.RemoveItem(item);
                    targetController.PlaceExistingItem(targetItem, tX, tY);
                    return false;
                }
            }
            else
            {
                // Тащимый предмет не влез на место целевого! ОТКАТ!
                Debug.Log($"[SWAP] Cannot place source item '{item.Data?.DisplayName}' at target. Rolling back.");
                targetController.PlaceExistingItem(targetItem, tX, tY);
                return false;
            }
        }
        public bool TryPlaceItemFromEquipmentSlot(GridType targetGrid, int targetX, int targetY)
        {
            if (_draggedFromEquipmentSlot == null || _draggedFromSlotItem == null) return false;
            if (!_isDragging) return false;
            var item = _draggedFromSlotItem;

            if (targetGrid == GridType.Backpack && item.Data?.IsBackpack == true)
            {
                bool isEquippedBackpack = _backpackSlot != null && _backpackSlot.EquippedItem == item;
                if (isEquippedBackpack) return false;
            }

            var targetController = (targetGrid == GridType.Container && _dropTargetController != null)
                ? _dropTargetController : GetControllerForGrid(targetGrid);
            if (targetController == null) return false;

            // ═══ НОВЫЙ ФИКС (БАГ 1): Запрет размещения экипированного рюкзака
            // в собственную сетку или в сетку любого потомка (матрёшка). ═══
            if (item.Data != null && item.Data.IsBackpack)
            {
                // а) Запрет в собственную сетку (backpackController = сетка экипированного рюкзака)
                if (targetController == _backpackController)
                {
                    Debug.Log("[CYCLE-BLOCK] Cannot place equipped backpack into its own grid.");
                    return false;
                }

                // б) Запрет в сетку потомка (окно-контейнер, принадлежащее содержимому рюкзака)
                if (targetGrid == GridType.Container)
                {
                    SyncBackpackForValidation(item);

                    var targetWindow = _openContainerWindows.Find(w => w != null && w.Controller == targetController);
                    if (targetWindow != null && uint.TryParse(targetWindow.BackpackInstanceID, out uint targetOwnerId))
                    {
                        if (item.InstanceID == targetOwnerId || item.ContainsDescendant(targetOwnerId))
                        {
                            Debug.Log($"[CYCLE-BLOCK] Cannot place equipped backpack " +
                                      $"'{item.Data?.DisplayName}' into descendant grid " +
                                      $"'{targetWindow.BackpackInstanceID}'.");
                            return false;
                        }
                    }
                }
            }
            // ═══ КОНЕЦ ФИКСА ═══

            // Swap path
            if (!targetController.CanPlaceItem(item, targetX, targetY))
            {
                var targetItem = targetController.GetItemAt(targetX, targetY);
                if (targetItem != null && targetItem != item)
                {
                    // ═══ НОВЫЙ ФИКС (БАГ 2): Запрет свапа экипированного рюкзака
                    // с предметом, который находится ВНУТРИ этого рюкзака. ═══
                    if (item.Data != null && item.Data.IsBackpack)
                    {
                        SyncBackpackForValidation(item);
                        if (item.ContainsDescendant(targetItem.InstanceID))
                        {
                            Debug.Log($"[CYCLE-BLOCK] Cannot swap equipped backpack " +
                                      $"'{item.Data?.DisplayName}' with its own content " +
                                      $"'{targetItem.Data?.DisplayName}' (InstanceID={targetItem.InstanceID}).");
                            return false;
                        }
                    }
                    // ═══ КОНЕЦ ФИКСА ═══

                    if (_draggedFromEquipmentSlot.ValidateItemForSlot(targetItem))
                    {
                        targetController.RemoveItem(targetItem);
                        bool placed = targetController.PlaceExistingItem(item, targetX, targetY);
                        if (!placed) placed = targetController.PlaceExistingItemInFirstFreeSlot(item);
                        if (placed)
                        {
                            _draggedFromEquipmentSlot.SetEquippedItem(targetItem);
                            if (_draggedFromEquipmentSlot.SlotType == EquipmentSlotType.Backpack)
                                OnBackpackEquipped(targetItem);
                            ForceRefresh();
                            return true;
                        }
                        else
                        {
                            targetController.PlaceExistingItem(targetItem, targetX, targetY);
                            return false;
                        }
                    }
                    else
                    {
                        return false;
                    }
                }
            }

            if (targetGrid == GridType.Container && _activeBackpackContainer != null
                && _activeBackpackContainer.InstanceID == item.InstanceID
                && targetController == _activeContainerController)
            {
                Debug.Log($"[V14-RECURSION] BLOCKED (FromEquipSlot): backpack '{item.Data?.DisplayName}' " +
                          "cannot be placed into its own container grid.");
                return false;
            }

            if (targetController.CanPlaceItem(item, targetX, targetY))
            {
                if (targetController.PlaceExistingItem(item, targetX, targetY))
                {
                    _draggedFromEquipmentSlot.SetEquippedItem(null);
                    if (_draggedFromEquipmentSlot.SlotType == EquipmentSlotType.Backpack)
                        OnBackpackUnequipped();
                    ForceRefresh();
                    return true;
                }
            }
            return false;
        }
        public bool TryEquipItemFromSlot(K_EquipmentSlotUI sourceSlot, K_EquipmentSlotUI targetSlot)
        {
            if (sourceSlot?.EquippedItem == null || targetSlot == null || sourceSlot == targetSlot) return false;

            var item = sourceSlot.EquippedItem;
            if (!ValidateEquipItem(item, targetSlot)) return false;

            // Если целевой слот занят — пробуем swap между слотами
            if (targetSlot.IsOccupied && targetSlot.EquippedItem != null)
            {
                var oldTargetItem = targetSlot.EquippedItem;

                // Проверяем: может ли старый предмет целевого слота поместиться в исходный слот?
                if (sourceSlot.ValidateItemForSlot(oldTargetItem))
                {
                    // Swap: старый предмет → исходный слот
                    sourceSlot.SetEquippedItem(oldTargetItem);
                    targetSlot.SetEquippedItem(null);
                }
                else
                {
                    // Старый предмет не подходит для исходного слота — пробуем unequip в инвентарь.
                    // Наследуем разворот нового предмета перед размещением в сетке.
                    oldTargetItem.RestoreRotationState(item.RotationAngle);
                    targetSlot.Unequip();
                    if (targetSlot.IsOccupied) return false; // Не получилось разместить
                }
            }
            else
            {
                // Целевой слот пуст — просто убираем из исходного
                sourceSlot.SetEquippedItem(null);
            }

            targetSlot.OnDropItem(item);

            // Хук: рюкзак экипирован из другого слота
            if (targetSlot.SlotType == EquipmentSlotType.Backpack && item.Data?.IsBackpack == true)
                OnBackpackEquipped(item);
            // Хук: рюкзак убран из слота при swap
            if (sourceSlot.SlotType == EquipmentSlotType.Backpack && !targetSlot.ValidateItemForSlot(sourceSlot.EquippedItem))
                OnBackpackUnequipped();

            return true;
        }

        /// <summary>
        /// ФИКС #3 + #6 + БАГ ИСЧЕЗНОВЕНИЯ: При отмене drag — вернуть предмет на исходную позицию.
        ///
        /// КРИТИЧЕСКИЙ ФИКС: В Unity OnEndDrag ВСЕГДА вызывается ДО OnDrop.
        /// Раньше EndDragComplete немедленно возвращал предмет через TryPlaceItem,
        /// который создавал НОВЫЙ InventoryItem (новый InstanceID). Затем OnDrop
        /// пытался оперировать ОРИГИНАЛЬНЫМ item'ом (которого больше не было в
        /// _positionCache) → MoveItem/RemoveItem silent-fail → предмет терялся.
        ///
        /// Решение: НЕ возвращать предмет здесь. Отложить на 1 фрейм — после OnDrop.
        /// Если OnDrop успешно разместил предмет (_dropHandled=true, _needsPostDragRefresh
        /// сброшен), отложенный код только очищает стейт. Если OnDrop не стрелял
        /// или провалился — отложенный код возвращает предмет на исходную позицию.
        /// </summary>
        /// /// <summary> Помещает предмет в слот экипировки. Если слот занят, меняет их местами. </summary>
        public void EquipItemFromContextMenu(InventoryItem item)
        {
            if (item == null) return;

            EquipmentSlotType targetSlotType = item.Type switch
            {
                ItemType.Weapon => item.Data.IsPistol ? EquipmentSlotType.Pistol : EquipmentSlotType.Primary,
                ItemType.Backpack => EquipmentSlotType.Backpack,
                _ => EquipmentSlotType.Melee
            };

            K_EquipmentSlotUI targetSlot = targetSlotType switch
            {
                EquipmentSlotType.Primary => (_primarySlot1 != null && !_primarySlot1.IsOccupied ? _primarySlot1 : _primarySlot2),
                EquipmentSlotType.Pistol => _pistolSlot,
                EquipmentSlotType.Backpack => _backpackSlot,
                _ => _meleeSlot
            };

            if (targetSlot == null) return;

            var (originGrid, x, y) = FindItemLocation(item);
            if (originGrid == null) return;

            var sourceController = GetControllerForGrid(originGrid.Value);
            if (sourceController == null) return;

            if (targetSlot.IsOccupied && targetSlot.EquippedItem != null)
            {
                var oldItem = targetSlot.EquippedItem;
                sourceController.RemoveItem(item);
                targetSlot.SetEquippedItem(item);

                oldItem.RestoreRotationState(0);
                if (!sourceController.PlaceExistingItem(oldItem, x, y))
                {
                    if (!sourceController.PlaceExistingItemInFirstFreeSlot(oldItem))
                    {
                        TryPlaceInAnyPlayerGrid(oldItem);
                    }
                }

                if (targetSlot.SlotType == EquipmentSlotType.Backpack)
                    OnBackpackEquipped(item);

                ForceRefresh();
            }
            else
            {
                sourceController.RemoveItem(item);
                targetSlot.SetEquippedItem(item);
                if (targetSlot.SlotType == EquipmentSlotType.Backpack)
                    OnBackpackEquipped(item);
                ForceRefresh();
            }
        }

        public K_ContainerWindow FindWindowByController(InventoryController controller)
        {
            if (controller == null) return null;
            foreach (var w in _openContainerWindows)
            {
                if (w != null && w.Controller == controller) return w;
            }
            return null;
        }


        public void EndDragComplete()
        {
            _isDragging = false;
            ClearDragCellHighlights();
            if (_dragGhost != null) _dragGhost.SetActive(false);
            SetAllGridSlotsRaycast(false);
            RestoreRaycastForDraggedBackpackWindow();

            // ═══ ФИКС ДУБЛИРОВАНИЯ: Если дроп уже обработан (успешно ИЛИ
            // неудачно с синхронным возвратом в source) — НЕ запускаем fallback.
            if (_dropHandled || !_dragItemRemoved || _draggedItem == null)
            {
                _needsPostDragRefresh = false;
                _dragItemRemoved = false;
                _dropHandled = false;
                _draggedItem = null;
                _draggedFromEquipmentSlot = null;
                _draggedFromSlotItem = null;
                _draggedFromSlotIconRotation = 0f;

                if (_postDragRefreshCoroutine != null)
                {
                    StopCoroutine(_postDragRefreshCoroutine);
                    _postDragRefreshCoroutine = null;
                }

                if (_pendingRefresh)
                    ForceRefresh();
                return;
            }

            // ═══ ФИКС ДУБЛИРОВАНИЯ: Перед запуском fallback, скрываем
            // перетаскиваемый UI_Item, чтобы он не был видимым на 1 кадр
            // (между OnEndDrag и PostDragEndFallback). Без этого старый
            // UI_Item (alpha=1) виден, а ForceRefresh создаёт новый → 
            // визуальный дубликат на 1 кадр.
            if (_draggedItem != null && _draggedItem.gameObject.activeInHierarchy)
            {
                var cg = _draggedItem.GetComponent<CanvasGroup>();
                if (cg != null)
                {
                    cg.alpha = 0f;
                    cg.blocksRaycasts = false;
                    cg.interactable = false;
                }
            }

            // Откладываем возврат предмета на следующий фрейм (после OnDrop)
            _needsPostDragRefresh = true;
            if (_postDragRefreshCoroutine != null)
                StopCoroutine(_postDragRefreshCoroutine);
            _postDragRefreshCoroutine = StartCoroutine(PostDragEndFallback());
        }
        private IEnumerator PostDragEndFallback()
        {
            yield return null;
            if (!_needsPostDragRefresh || _dropHandled)
            {
                _dragItemRemoved = false;
                _dropHandled = false;
                _draggedItem = null;
                _draggedFromEquipmentSlot = null;
                _draggedFromSlotItem = null;
                _draggedFromSlotIconRotation = 0f;
                _postDragRefreshCoroutine = null;
                yield break;
            }
            _needsPostDragRefresh = false;
            if (_dragItemRemoved && _draggedItem?.Item != null)
            {
                var item = _draggedItem.Item;
                var controller = (_dragOriginGridType == GridType.Container && _draggedItem.BoundController != null)
                    ? _draggedItem.BoundController
                    : GetControllerForGrid(_dragOriginGridType);

                bool itemAlreadyPlacedSomewhere = false;
                try
                {
                    var (foundGrid, _, _) = FindItemLocation(item);
                    if (foundGrid != null)
                        itemAlreadyPlacedSomewhere = true;
                }
                catch { /* ignore */ }

                if (itemAlreadyPlacedSomewhere)
                {
                    _dragItemRemoved = false;
                    _dropHandled = false;
                    _draggedItem = null;
                    _draggedFromEquipmentSlot = null;
                    _draggedFromSlotItem = null;
                    _draggedFromSlotIconRotation = 0f;
                    _postDragRefreshCoroutine = null;
                    ForceRefresh();
                    yield break;
                }

                if (controller == null && _dragOriginGridType == GridType.Container)
                    controller = _pocketsController ?? _pocket2Controller ?? _backpackController;

                if (controller != null)
                {
                    // v12: ВОЗВРАТ В ТОМ СОСТОЯНИИ, В КОТОРОМ ВЗЯЛИ (fold + поворот) ДО размещения.
                    RestoreDragOriginState(item);
                    bool placed = controller.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
                    if (!placed)
                        placed = controller.PlaceExistingItemInFirstFreeSlot(item);
                    if (!placed)
                    {
                        Debug.LogWarning($"[ITEM-LOSS-PREVENTION] Origin grid '{_dragOriginGridType}' full. " +
                                         $"Trying all other player grids for '{item.Data?.DisplayName}'.");
                        placed = TryPlaceInAnyPlayerGrid(item);
                    }
                    if (!placed)
                    {
                        Debug.LogError($"[ITEM-LOSS] Could not place item '{item.Data?.DisplayName}' " +
                                       $"in ANY player grid after drag fallback. Item is LOST! " +
                                       $"InstanceID={item.InstanceID}");
                    }
                }
                else
                {
                    Debug.LogWarning($"[BUG4-FALLBACK] No origin controller. Trying ALL player grids.");
                    RestoreDragOriginState(item);
                    bool placed = TryPlaceInAnyPlayerGrid(item);
                    if (!placed)
                        Debug.LogError($"[BUG4-FALLBACK] No controller available to return item " +
                                       $"'{item.Data?.DisplayName}'. Item is LOST!");
                }
            }

            _dragItemRemoved = false;
            _dropHandled = false;
            _draggedItem = null;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedFromSlotIconRotation = 0f;
            ForceRefresh();
            _postDragRefreshCoroutine = null;
        }
        public void EndDragFromEquipmentSlot()
        {
            _isDragging = false;
            ClearDragCellHighlights();
            if (_dragGhost != null) _dragGhost.SetActive(false);
            SetAllGridSlotsRaycast(false);

            // >>> НОВЫЙ ФИКС: Возвращаем рейкаст окну рюкзака <<<
            RestoreRaycastForDraggedBackpackWindow();
            // ----------------------------------------------------

            // Откладываем очистку на следующий фрейм
            if (_equipDragCleanupCoroutine != null)
                StopCoroutine(_equipDragCleanupCoroutine);
            _equipDragCleanupCoroutine = StartCoroutine(LateEquipDragCleanup());
        }

        /// <summary>
        /// Отложенная очистка после drag из слота экипировки.
        /// Если OnDrop не обработал дроп — предмет остаётся в слоте.
        /// </summary>
        /// <summary>
        /// Отложенная очистка после drag из слота экипировки.
        /// Если OnDrop не обработал дроп — предмет остаётся в слоте.
        /// </summary>
        private IEnumerator LateEquipDragCleanup()
        {
            yield return null; // Ждём 1 фрейм — OnDrop уже отстрелял

            // Если дроп был обработан (OnDrop вызвал FinalizeEquipSlotDrag) — ничего не делаем
            if (_draggedFromEquipmentSlot == null)
            {
                _equipDragCleanupCoroutine = null;
                yield break;
            }

            // Дроп не обработан — предмет остаётся в слоте, просто очищаем стейт
            var slot = _draggedFromEquipmentSlot;
            var item = _draggedFromSlotItem;

            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedFromSlotIconRotation = 0f;
            _draggedItem = null;

            if (slot != null)
            {
                // FIX БАГ 4: Сбрасываем вращение при возврате в слот.
                // Визуальное положение в слоте фиксировано (Refresh() ставит 0° для Backpack),
                // но RotationAngle мог измениться во время drag. Сбрасываем, чтобы
                // CurrentSize соответствовал визуальному положению.
                // ФИКС БАГ (audit) #15: используем RestoreRotationState вместо while,
                // чтобы не зависнуть при CanRotate=false.
                if (item != null && item.RotationAngle != 0)
                {
                    item.RestoreRotationState(0);
                }
                slot.Refresh();
            }

            ForceRefresh();
            _equipDragCleanupCoroutine = null;
        }

        /// <summary>
        /// Временно отключает рейкаст у плавающего окна рюкзака, который сейчас перетаскивается.
        /// Это позволяет курсору "проходить сквозь" окно (включая заголовок) и взаимодействовать с сетками под ним.
        /// </summary>
        private void DisableRaycastForDraggedBackpackWindow(InventoryItem item)
        {
            if (item == null || item.Data == null || !item.Data.IsBackpack) return;

            string idStr = item.InstanceID.ToString();
            _draggedBackpackWindow = _openContainerWindows.Find(w => w != null && w.BackpackInstanceID == idStr);

            if (_draggedBackpackWindow != null)
            {
                // Отключаем рейкаст у слотов и фона сетки
                if (_draggedBackpackWindow.GridRect != null)
                {
                    SetGridSlotsRaycast(_draggedBackpackWindow.GridRect, false);
                    var gridImg = _draggedBackpackWindow.GridRect.GetComponent<Image>();
                    if (gridImg != null) gridImg.raycastTarget = false;
                }

                // Отключаем рейкаст у хедера (DragZone), чтобы он не блокировал курсор
                if (_draggedBackpackWindow.DragZoneTransform != null)
                {
                    var dzImg = _draggedBackpackWindow.DragZoneTransform.GetComponent<Image>();
                    if (dzImg != null) dzImg.raycastTarget = false;
                }

                // Полностью отключаем блокировку рейкастов у панели окна
                var panelCG = _draggedBackpackWindow.GetComponent<CanvasGroup>();
                if (panelCG != null) panelCG.blocksRaycasts = false;
            }
        }

        /// <summary>
        /// Восстанавливает рейкаст у плавающего окна после завершения перетаскивания.
        /// </summary>
        private void RestoreRaycastForDraggedBackpackWindow()
        {
            if (_draggedBackpackWindow != null)
            {
                if (_draggedBackpackWindow.GridRect != null)
                {
                    var gridImg = _draggedBackpackWindow.GridRect.GetComponent<Image>();
                    if (gridImg != null) gridImg.raycastTarget = true;
                }

                if (_draggedBackpackWindow.DragZoneTransform != null)
                {
                    var dzImg = _draggedBackpackWindow.DragZoneTransform.GetComponent<Image>();
                    if (dzImg != null) dzImg.raycastTarget = true;
                }

                var panelCG = _draggedBackpackWindow.GetComponent<CanvasGroup>();
                if (panelCG != null) panelCG.blocksRaycasts = true;
            }
            _draggedBackpackWindow = null;
        }

        /// <summary>
        /// Вызывается из OnDrop (сетка) при успешном дропе предмета из слота экипировки.
        /// </summary>
        public void FinalizeEquipSlotDrag()
        {
            // Отменяем отложенную очистку
            if (_equipDragCleanupCoroutine != null)
            {
                StopCoroutine(_equipDragCleanupCoroutine);
                _equipDragCleanupCoroutine = null;
            }

            // Хук: если из слота вытащили рюкзак — скрыть сетку рюкзака
            if (_draggedFromEquipmentSlot != null &&
                _draggedFromEquipmentSlot.SlotType == EquipmentSlotType.Backpack)
            {
                OnBackpackUnequipped();
            }

            // ФИКС БАГ (audit) #16: Safety net — гарантируем, что source slot очищен.
            // Если TryPlaceItemFromEquipmentSlot или TryDropItemIntoBackpack уже
            // очистили _equippedItem, эта строка — no-op. Иначе она предотвращает
            // дублирование item между source slot и destination.
            if (_draggedFromEquipmentSlot != null &&
                _draggedFromSlotItem != null &&
                ReferenceEquals(_draggedFromEquipmentSlot.EquippedItem, _draggedFromSlotItem))
            {
                Debug.LogWarning(
                    $"[FinalizeEquipSlotDrag] Source slot still held dragged item " +
                    $"'{_draggedFromSlotItem.Data?.DisplayName}'. Clearing as safety net.");
                _draggedFromEquipmentSlot.SetEquippedItem(null);
            }

            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedFromSlotIconRotation = 0f;
            _draggedItem = null;

            ForceRefresh();

            // >>> НОВЫЙ ФИКС: Возвращаем рейкаст окну рюкзака <<<
            RestoreRaycastForDraggedBackpackWindow();
            // ----------------------------------------------------

            // ФИКС БАГ (audit) K_InventoryUI RefreshAll deadlock:
            // После конца drag-сессии — drain pending refresh.
            if (_pendingRefresh)
                ForceRefresh();
        }

        private bool ValidateEquipItem(InventoryItem item, K_EquipmentSlotUI slot)
        {
            if (item?.Data == null) return false;
            return slot.SlotType switch
            {
                EquipmentSlotType.Primary => item.Type == ItemType.Weapon && !item.Data.IsPistol && !item.Data.IsMelee,
                EquipmentSlotType.Pistol => item.Type == ItemType.Weapon && item.Data.IsPistol,
                EquipmentSlotType.Melee => item.Data.IsMelee,
                EquipmentSlotType.Backpack => item.Data.IsBackpack,
                _ => false
            };
        }

        #endregion

        #region Event Handling

        private void SubscribeToEvents()
        {
            _onInventoryChangedHandler = RefreshAll;
            _onWeightChangedHandler = UpdateWeightDisplay;
            _onItemPlacedHandler = (item, x, y) => RefreshAll();
            _onItemChangedHandler = _ => RefreshAll();

            if (_pocketsController != null)
            {
                _pocketsController.OnInventoryChanged += _onInventoryChangedHandler;
                _pocketsController.OnItemPlaced += _onItemPlacedHandler;
                _pocketsController.OnItemRemoved += _onItemChangedHandler;
                _pocketsController.OnItemRotated += _onItemChangedHandler;
                _pocketsController.OnItemQuantityChanged += _onItemChangedHandler;
                _pocketsController.OnWeightChanged += _onWeightChangedHandler;
            }

            if (_pocket2Controller != null)
            {
                _pocket2Controller.OnInventoryChanged += _onInventoryChangedHandler;
                _pocket2Controller.OnItemPlaced += _onItemPlacedHandler;
                _pocket2Controller.OnItemRemoved += _onItemChangedHandler;
                _pocket2Controller.OnItemRotated += _onItemChangedHandler;
                _pocket2Controller.OnItemQuantityChanged += _onItemChangedHandler;
                _pocket2Controller.OnWeightChanged += _onWeightChangedHandler;
            }

            if (_backpackController != null)
            {
                _backpackController.OnInventoryChanged += _onInventoryChangedHandler;
                _backpackController.OnItemPlaced += _onItemPlacedHandler;
                _backpackController.OnItemRemoved += _onItemChangedHandler;
                _backpackController.OnItemRotated += _onItemChangedHandler;
                _backpackController.OnItemQuantityChanged += _onItemChangedHandler;
                _backpackController.OnWeightChanged += _onWeightChangedHandler;
            }
        }

        private void UnsubscribeFromEvents()
        {
            if (_pocketsController != null)
            {
                _pocketsController.OnInventoryChanged -= _onInventoryChangedHandler;
                _pocketsController.OnItemPlaced -= _onItemPlacedHandler;
                _pocketsController.OnItemRemoved -= _onItemChangedHandler;
                _pocketsController.OnItemRotated -= _onItemChangedHandler;
                _pocketsController.OnItemQuantityChanged -= _onItemChangedHandler;
                _pocketsController.OnWeightChanged -= _onWeightChangedHandler;
            }

            if (_pocket2Controller != null)
            {
                _pocket2Controller.OnInventoryChanged -= _onInventoryChangedHandler;
                _pocket2Controller.OnItemPlaced -= _onItemPlacedHandler;
                _pocket2Controller.OnItemRemoved -= _onItemChangedHandler;
                _pocket2Controller.OnItemRotated -= _onItemChangedHandler;
                _pocket2Controller.OnItemQuantityChanged -= _onItemChangedHandler;
                _pocket2Controller.OnWeightChanged -= _onWeightChangedHandler;
            }

            if (_backpackController != null)
            {
                _backpackController.OnInventoryChanged -= _onInventoryChangedHandler;
                _backpackController.OnItemPlaced -= _onItemPlacedHandler;
                _backpackController.OnItemRemoved -= _onItemChangedHandler;
                _backpackController.OnItemRotated -= _onItemChangedHandler;
                _backpackController.OnItemQuantityChanged -= _onItemChangedHandler;
                _backpackController.OnWeightChanged -= _onWeightChangedHandler;
            }
        }

        private void UpdateWeightDisplay(float kg)
        {
            if (_weightText == null) return;

            float totalKg = 0f;
            float maxCapacity = 0f;

            if (_pocketsController != null)
            {
                totalKg += _pocketsController.CurrentWeightKg;
                maxCapacity += _pocketsController.MaxCapacityGrams;
            }
            if (_pocket2Controller != null)
            {
                totalKg += _pocket2Controller.CurrentWeightKg;
                maxCapacity += _pocket2Controller.MaxCapacityGrams;
            }
            if (_backpackController != null)
            {
                totalKg += _backpackController.CurrentWeightKg;
                maxCapacity += _backpackController.MaxCapacityGrams;
            }

            float ratio = maxCapacity > 0 ? (totalKg * 1000f) / maxCapacity : 0f;
            Color textColor = ratio > WEIGHT_CRITICAL_RATIO ? _textCriticalColor
                            : ratio > WEIGHT_WARNING_RATIO ? _textWarningColor
                            : _textNormalColor;

            float maxKg = maxCapacity / 1000f;
            _weightText.text = $"<color=#{ColorUtility.ToHtmlStringRGB(textColor)}>{totalKg:F1} / {maxKg:F0} kg</color>";
        }

        #endregion

        #region Pool Management

        private UI_Item GetPooledItem()
        {
            if (_itemPool.Count > 0) return _itemPool.Dequeue();
            return CreateNewPooledItem();
        }

        /// <summary>
        /// ФИКС БАГ #3: ReturnToPool теперь удаляет элемент из _activeItems.
        /// Это предотвращает двойной возврат и коррупцию пула.
        ///
        /// БАГ #5 ФИКС: SetParent теперь идёт в отдельный "pool container"
        /// (_poolParent), а не в transform самого K_InventoryUI. Это решает
        /// проблему пропадания UI предметов в перетаскиваемой панели:
        /// раньше SetParent(transform) переподключал предмет к корню
        /// инвентаря, что во время drag панели вызывало визуальное
        /// мерцание/исчезновение. Теперь pool живёт в отдельной ветке
        /// иерархии, которая не затрагивается drag-операциями.
        /// </summary>
        private void ReturnToPool(UI_Item item)
        {
            if (item == null) return;

            // ═══ ФИКС БАГ 2: Защита от уничтоженных объектов ═══
            if (item.gameObject == null) return;

            // ═══ ФИКС ДУБЛИРОВАНИЯ: Никогда не пулим перетаскиваемый предмет.
            if (item == _draggedItem && _isDragging)
            {
                Debug.LogWarning("[ReturnToPool] Blocked: attempted to pool the actively dragged item.");
                return;
            }

            // ═══ ФИКС: Защита от двойного enqueue.
            Transform poolParent = GetPoolParent();
            if (!item.gameObject.activeSelf && item.transform.parent == poolParent)
            {
                string keyToRemove = null;
                foreach (var kvp in _activeItems)
                {
                    if (kvp.Value == item) { keyToRemove = kvp.Key; break; }
                }
                if (keyToRemove != null) _activeItems.Remove(keyToRemove);
                return;
            }

            // Безопасное удаление из словаря
            string keyToRemove2 = null;
            foreach (var kvp in _activeItems)
            {
                if (kvp.Value == item)
                {
                    keyToRemove2 = kvp.Key;
                    break;
                }
            }
            if (keyToRemove2 != null)
                _activeItems.Remove(keyToRemove2);

            // Возвращаем прозрачность и рейкаст
            var cg = item.GetComponent<CanvasGroup>();
            if (cg != null)
            {
                cg.alpha = 1f;
                cg.blocksRaycasts = true;
                cg.interactable = true;
            }

            item.ResetState();

            // ═══ ФИКС БАГ 2: Не вызываем SetActive(false) если уже неактивен ═══
            if (item.gameObject.activeSelf)
                item.gameObject.SetActive(false);

            if (item.transform.parent != poolParent)
            {
                // ═══ ФИКС БАГ 2: try-catch для защиты от каскадного SetActive ═══
                try
                {
                    item.transform.SetParent(poolParent, false);
                }
                catch (System.Exception)
                {
                    StartCoroutine(DelayedReturnToPool(item, poolParent));
                    return;
                }
            }

            _itemPool.Enqueue(item);
        }
        private void ReturnAllItemsToPool()
        {
            UI_Item protectedItem = _draggedItem;

            // ═══════════════════════════════════════════════════════════
            // ФИКС: Собираем ключи для удаления отдельно, т.к.
            // уничтоженные объекты (== null) нельзя вернуть в пул.
            // ═══════════════════════════════════════════════════════════
            var keysToRemove = new List<string>();

            foreach (var kvp in _activeItems)
            {
                var item = kvp.Value;
                if (item == protectedItem) continue;

                if (item == null)
                {
                    // Объект уничтожен (например, вместе с окном) — просто удаляем ключ
                    keysToRemove.Add(kvp.Key);
                    continue;
                }

                ReturnToPoolOnly(item);
            }

            foreach (var key in keysToRemove)
                _activeItems.Remove(key);

            _activeItems.Clear();

            if (protectedItem != null && protectedItem.Item != null && !_dragItemRemoved)
            {
                string key = GetCellKey(protectedItem.GridType, protectedItem.X, protectedItem.Y);
                _activeItems[key] = protectedItem;
            }
        }

        /// <summary>
        /// Внутренний метод: возвращает элемент в пул БЕЗ удаления из _activeItems.
        /// Используется в ReturnAllItemsToPool() для очистки всех элементов.
        /// </summary>
        /// <summary>
        /// Внутренний метод: возвращает элемент в пул БЕЗ удаления из _activeItems.
        /// Используется в ReturnAllItemsToPool() для очистки всех элементов.
        ///
        /// ФИКС БАГ 2: Защита от "GameObject is already being activated or deactivated"
        /// при SetParent во время каскадного SetActive(false).
        /// </summary>
        private void ReturnToPoolOnly(UI_Item item)
        {
            if (item == null) return;

            // ═══ ФИКС БАГ 2: Если объект уничтожен — пропускаем ═══
            if (item.gameObject == null) return;

            item.ResetState();

            // Не вызываем SetActive(false) если уже неактивен (избегаем рекурсии OnDisable)
            if (item.gameObject.activeSelf)
                item.gameObject.SetActive(false);

            // БАГ #5: Используем выделенный pool parent.
            Transform poolParent = GetPoolParent();
            if (item.transform.parent != poolParent)
            {
                // ═══ ФИКС БАГ 2: try-catch на случай если Unity всё ещё
                //     в процессе SetActive (каскадный вызов из OnDisable) ═══
                try
                {
                    item.transform.SetParent(poolParent, false);
                }
                catch (System.Exception)
                {
                    // Отложенный перенос на следующий кадр
                    StartCoroutine(DelayedReturnToPool(item, poolParent));
                    return;
                }
            }
            _itemPool.Enqueue(item);
        }

        /// <summary>
        /// ФИКС БАГ 2: Отложенный перенос UI_Item в пул на следующий кадр.
        /// Используется когда SetParent невозможен (объект в процессе деактивации).
        /// </summary>
        private IEnumerator DelayedReturnToPool(UI_Item item, Transform poolParent)
        {
            yield return null;
            if (item != null && item.transform != null && item.gameObject != null)
            {
                if (item.transform.parent != poolParent)
                    item.transform.SetParent(poolParent, false);
                if (!_itemPool.Contains(item))
                    _itemPool.Enqueue(item);
            }
        }
        private Transform _poolParent;
        private Transform GetPoolParent()
        {
            if (_poolParent != null) return _poolParent;
            var go = new GameObject("__K_InventoryUI_Pool__", typeof(RectTransform));
            go.transform.SetParent(transform, false);
            go.SetActive(false); // Скрываем весь пул от рендера и raycast'а.
            _poolParent = go.transform;
            return _poolParent;
        }

        private void ClearPooledItems()
        {
            foreach (var item in _itemPool) if (item != null) Destroy(item.gameObject);
            _itemPool.Clear();
            _activeItems.Clear();

            foreach (var hider in _borderHiderPool) if (hider != null) Destroy(hider);
            _borderHiderPool.Clear();
            foreach (var hider in _activeBorderHiders) if (hider != null) Destroy(hider);
            _activeBorderHiders.Clear();
        }

        private void MarkForRefresh()
        {
            _needsPostDragRefresh = false; // Сбрасываем fallback

            if (!_pendingRefresh)
            {
                _pendingRefresh = true;
                StartCoroutine(RefreshNextFrame());
            }
        }

        #endregion

        #region Public API

        public InventoryController GetControllerForGrid(GridType gridType) => gridType switch
        {
            GridType.Pockets => _pocketsController,
            GridType.Pocket2 => _pocket2Controller,
            GridType.Backpack => _backpackController,
            GridType.Container => _activeContainerController,
            _ => null
        };

        /// <summary>
        /// ФИКС БАГ "предметы бесследно исчезают": Пробует разместить item в ЛЮБОЙ
        /// сетке игрока (Pockets, Pocket2, Backpack). Возвращает true если хотя бы
        /// в одной сетке нашлось место.
        ///
        /// Используется как LAST-RESORT fallback в:
        /// - PostDragEndFallback: когда origin grid заполнена.
        /// - CancelDrag: когда TryPlaceItemInFirstFreeSlot не сработал.
        /// - StartDrag orphan-handling: когда возвращаем "зависший" предмет.
        ///
        /// ВАЖНО: НЕ пытаемся разместить в Container (это содержимое рюкзака,
        /// может создать цикл). Только в сетки самого игрока.
        /// </summary>
        private bool TryPlaceInAnyPlayerGrid(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;

            // Порядок: Pockets → Pocket2 → Backpack (Container НЕ трогаем — может быть цикл)
            var controllers = new[]
            {
                _pocketsController,
                _pocket2Controller,
                _backpackController
            };

            foreach (var ctrl in controllers)
            {
                if (ctrl == null) continue;
                try
                {
                    if (ctrl.PlaceExistingItemInFirstFreeSlot(item))
                    {
                        Debug.Log($"[ITEM-LOSS-PREVENTION] Placed '{item.Data.DisplayName}' " +
                                  $"in grid '{ctrl.SaveID}' as fallback.");
                        return true;
                    }
                }
                catch (System.Exception ex)
                {
                    Debug.LogError($"[ITEM-LOSS-PREVENTION] Exception placing item in " +
                                   $"grid '{ctrl.SaveID}': {ex.Message}");
                }
            }

            return false;
        }
        /// <summary>
        /// v12: Восстанавливает состояние предмета НА МОМЕНТ СТАРТА DRAG
        /// (поворот И fold). Используется при любом неудачном возврате, чтобы
        /// предмет возвращался таким, каким его взяли: свёрнутый рюкзак возвращается
        /// свёрнутым и поэтому влезаёт на своё исходное место.
        /// </summary>
        private void RestoreDragOriginState(InventoryItem item)
        {
            if (item == null) return;
            item.RestoreRotationState(_dragOriginRotationAngle);
            if (item.Data != null && item.Data.CanFold && item.IsFolded != _dragOriginFolded)
                item.SetFolded(_dragOriginFolded);
        }

        public int GetGridWidth(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_COLUMNS;
            if (gridType == GridType.Pocket2) return POCKET_COLUMNS;
            if (gridType == GridType.Backpack) return _currentBackpackCols; // ФИКС БАГ #4
            if (gridType == GridType.Container) return _currentContainerCols; // ФИКС БАГ #2
            var c = GetControllerForGrid(gridType);
            return c?.Width ?? 0;
        }

        public int GetGridHeight(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_ROWS;
            if (gridType == GridType.Pocket2) return POCKET_ROWS;
            if (gridType == GridType.Backpack) return _currentBackpackRows; // ФИКС БАГ #4
            if (gridType == GridType.Container) return _currentContainerRows; // ФИКС БАГ #2
            var c = GetControllerForGrid(gridType);
            return c?.Height ?? 0;
        }
        // >>> FIX unfold-overflow: видимый размер сетки <<<
        private (int width, int height) GetEffectiveGridSize(GridType gridType, InventoryController controller)
        {
            int cw = controller != null ? controller.Width : 0;
            int ch = controller != null ? controller.Height : 0;
            int uw = GetGridWidth(gridType);
            int uh = GetGridHeight(gridType);
            int w = (cw > 0 && uw > 0) ? Mathf.Min(cw, uw) : Mathf.Max(cw, uw);
            int h = (ch > 0 && uh > 0) ? Mathf.Min(ch, uh) : Mathf.Max(ch, uh);
            return (w, h);
        }
        // >>> END FIX <<<
        /// <summary>
        /// ФИКС БАГ #2: Публичный доступ к _activeBackpackContainer.
        /// Используется UI_Item.OnDrop для проверки рекурсии
        /// (рюкзак нельзя положить в самого себя).
        /// </summary>
        public InventoryItem ActiveBackpackContainer => _activeBackpackContainer;
        public bool CanOpenBackpackAsContainer(InventoryItem item)
        {
            if (item == null || item.Data == null || !item.Data.IsBackpack) return false;
            if (item.IsFolded && !item.Data.AlwaysShowGrid) return false;
            return true;
        }


        public void OnEquipmentSlotDrop(K_EquipmentSlotUI slot, PointerEventData eventData)
        {
            if (slot == null || eventData?.pointerDrag == null) return;

            var draggedUI = eventData.pointerDrag.GetComponent<UI_Item>();
            if (draggedUI?.Item != null)
            {
                var item = draggedUI.Item;

                // Дебаг: почему дроп отклонён
                if (_debugLogs)
                {
                    Debug.Log($"[EquipDrop] Предмет: {item.Data?.DisplayName}, Type: {item.Data?.Type}, " +
                        $"IsBackpack: {item.Data?.IsBackpack}, IsPistol: {item.Data?.IsPistol}, IsMelee: {item.Data?.IsMelee} | " +
                        $"Слот: {slot.SlotType}, Валидация: {ValidateEquipItem(item, slot)}");
                }

                // Ранняя валидация типа — если не совпадает (пистолет в Primary и т.д.),
                // сразу выходим без транзакции. EndDragComplete вернёт предмет обратно в сетку.
                if (!ValidateEquipItem(item, slot))
                {
                    return;
                }

                // ═══════════════════════════════════════════════════════════════
                //  Транзакционный swap: делегируем в InventoryTransactionService.
                //  Сервис сам делает snapshot/validate/execute/rollback.
                //  Если вернул false — НЕ трогаем UI, EndDragComplete вернёт A в origin.
                // ═══════════════════════════════════════════════════════════════
                // ═══ НОВЫЙ ФИКС (БАГ 2, обратное направление):
                // Запрет экипировки предмета из сетки рюкзака А в слот рюкзака А.
                // Если targetSlot содержит рюкзак, и draggedItem находится ВНУТРИ этого рюкзака — блок. ═══
                if (slot.EquippedItem != null && slot.EquippedItem.Data != null && slot.EquippedItem.Data.IsBackpack)
                {
                    SyncBackpackForValidation(slot.EquippedItem);
                    if (slot.EquippedItem.ContainsDescendant(item.InstanceID))
                    {
                        Debug.Log($"[CYCLE-BLOCK] Cannot equip '{item.Data?.DisplayName}' from inside " +
                                  $"'{slot.EquippedItem.Data?.DisplayName}' into its own slot.");
                        return;
                    }
                }
               
                var tx = InventoryTransactionService.Instance;
                if (tx == null)
                {
                    Debug.LogError("[OnEquipmentSlotDrop] InventoryTransactionService.Instance is null — abort.");
                    return;
                }

                if (tx.IsTransactionActive)
                {
                    Debug.LogWarning("[OnEquipmentSlotDrop] Another transaction is active — abort.");
                    return;
                }

                bool ok = tx.TryEquipFromDrag(draggedUI, slot, out string errorMessage);
                if (!ok)
                {
                    Debug.LogWarning($"[OnEquipmentSlotDrop] Transaction rejected: {errorMessage}");
                    // НЕ делаем UI-чистку. EndDragComplete (PostDragEndFallback) вернёт A в origin.
                    return;
                }

                // ═══════════════════════════════════════════════════════════════
                // Успех: сервис уже экипировал A в slot и разместил B (если был)
                // на старом месте A. Нам остаётся только UI-чистка.
                // ═══════════════════════════════════════════════════════════════
                _dragItemRemoved = false;
                _dropHandled = true;
                _needsPostDragRefresh = false;
                draggedUI.gameObject.SetActive(false);
                ReturnToPool(draggedUI);

                _isDragging = false;
                _draggedItem = null;
                ClearDragCellHighlights();
                if (_dragGhost != null) _dragGhost.SetActive(false);

                // Выключаем raycast на слотах (возвращаем blocksRaycasts на itemsContainers)
                SetAllGridSlotsRaycast(false);

                // Возвращаем рейкаст окну рюкзака (если тащили рюкзак с открытым окном)
                RestoreRaycastForDraggedBackpackWindow();

                if (_postDragRefreshCoroutine != null)
                {
                    StopCoroutine(_postDragRefreshCoroutine);
                    _postDragRefreshCoroutine = null;
                }
                _needsPostDragRefresh = false;

                // Backpack-хук уже вызван внутри сервиса (TryEquipFromDrag), но дублируем
                // для обратной совместимости с другими подписчиками — OnBackpackEquipped
                // идемпотентен (внутри проверяет _loadedBackpackItem).
                if (slot.SlotType == EquipmentSlotType.Backpack && item.Data?.IsBackpack == true)
                    OnBackpackEquipped(item);

                ForceRefresh();
                return;
            }

            // Drag из другого слота экипировки (slot → slot) — оставляем прежнюю логику.
            // Этот путь не требует транзакционной модели (обе стороны — слоты экипировки,
            // нет сложной логики FindFreeSpace в сетке).
            if (_draggedFromEquipmentSlot != null && _draggedFromSlotItem != null)
            {
                if (ValidateEquipItem(_draggedFromSlotItem, slot))
                    TryEquipItemFromSlot(_draggedFromEquipmentSlot, slot);
            }
        }

        #endregion

        #region Hover Highlight

        /// <summary>
        /// TASK 1: Выделение предмета при наведении (hover).
        /// Вызывается из UI_Item.OnPointerEnter.
        /// </summary>
        public void OnItemHovered(UI_Item hoveredItem)
        {
            if (!_enableHoverHighlight) return;
            if (hoveredItem == null || hoveredItem.Item == null) return;
            if (_isDragging) return;

            // Снимаем с предыдущего
            if (_hoveredItem != null && _hoveredItem != hoveredItem)
                _hoveredItem.SetSelected(false);

            hoveredItem.SetSelected(true);
            _hoveredItem = hoveredItem;
        }

        /// <summary>Снять выделение при уходе курсора.</summary>
        public void OnItemUnhovered(UI_Item unhoveredItem)
        {
            if (unhoveredItem == null) return;
            if (_hoveredItem == unhoveredItem)
            {
                unhoveredItem.SetSelected(false);
                _hoveredItem = null;
            }
        }

        /// <summary>Снять hover со всех предметов.</summary>
        private void ClearHover()
        {
            if (_hoveredItem != null)
            {
                _hoveredItem.SetSelected(false);
                _hoveredItem = null;
            }
        }

        #endregion

        #region Drag Outline & Snap Helpers

        /// <summary>
        /// ФИКС #5: Настраивает призрак как обводку (semi-transparent rect без иконки).
        /// </summary>
        private void SetupDragOutline(InventoryItem item)
        {
            if (_dragGhost == null || _dragGhostRT == null) return;

            if (_rootCanvasTransform != null)
                _dragGhost.transform.SetParent(_rootCanvasTransform, false);

            // Root: обводка (semi-transparent цвет, без sprite)
            _dragGhostRT.anchorMin = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchorMax = new Vector2(0.5f, 0.5f);
            _dragGhostRT.pivot = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchoredPosition = Vector2.zero;
            _dragGhostRT.localScale = Vector3.one;
            _dragGhostRT.localRotation = Quaternion.identity;
            _dragGhostRT.SetAsLastSibling();

            if (_dragGhostRootImage != null)
            {
                _dragGhostRootImage.sprite = null;
                _dragGhostRootImage.type = Image.Type.Simple;
                _dragGhostRootImage.color = Color.clear;
                _dragGhostRootImage.enabled = false;
                _dragGhostRootImage.raycastTarget = false;
            }

            // TASK 4: Иконка ВИДНА — предмет «летает» над ячейками
            if (_dragGhostImage != null)
            {
                _dragGhostImage.enabled = true;
                _dragGhostImage.sprite = item.CurrentIcon; // ФИКС v2: CurrentIcon учитывает fold
                _dragGhostImage.preserveAspect = true; // ФИКС БАГ #4: Сохраняем пропорции иконки, НЕ растягиваем
            }

            // Название предмета на ghost (скрыто при перетаскивании)
            if (_dragGhostNameText != null)
            {
                _dragGhostNameText.text = "";
                _dragGhostNameText.gameObject.SetActive(false);
            }

            // Калибр на ghost (скрыто при перетаскивании)
            if (_dragGhostCaliberText != null)
            {
                _dragGhostCaliberText.text = string.Empty;
                _dragGhostCaliberText.gameObject.SetActive(false);
            }

            UpdateGhostSize();
            UpdateGhostRotation();
        }

        /// <summary>
        /// ФИКС #1: Вычисляет top-left позицию предмета из позиции курсора (центр предмета).
        /// </summary>
        public static (int x, int y) CalculateSnapPosition(
            int cursorSlotX, int cursorSlotY, Vector2Int itemSize, int gridWidth, int gridHeight)
        {
            // Cursor = центр предмета. Top-left = cursor - size/2.
            int targetX = cursorSlotX - itemSize.x / 2;
            int targetY = cursorSlotY - itemSize.y / 2;

            // Clamp чтобы предмет не вылезал за сетку
            int maxX = Mathf.Max(0, gridWidth - itemSize.x);
            int maxY = Mathf.Max(0, gridHeight - itemSize.y);

            targetX = Mathf.Clamp(targetX, 0, maxX);
            targetY = Mathf.Clamp(targetY, 0, maxY);

            return (targetX, targetY);
        }

        /// <summary>
        /// Публичный метод для K_InventorySlotUI — рассчитывает скорректированную позицию drop.
        /// </summary>
        public (int x, int y) GetAdjustedDropPosition(int slotX, int slotY, Vector2Int itemSize, GridType gridType)
        {
            // ФИКС БАГ #2: Используем реальные размеры UI-сетки, не controller.Width
            int gridW = GetGridWidth(gridType);
            int gridH = GetGridHeight(gridType);
            if (gridW <= 0 || gridH <= 0)
            {
                var controller = GetControllerForGrid(gridType);
                gridW = controller?.Width ?? 0;
                gridH = controller?.Height ?? 0;
            }
            if (gridW <= 0) return (slotX, slotY);
            return CalculateSnapPosition(slotX, slotY, itemSize, gridW, gridH);
        }

        /// <summary>
        /// ═══ БАГ 3 ФИКС: перегрузка с явным boundController ═══
        /// Без этого CalculateSnapPosition использовал глобальные _currentContainerCols/Rows,
        /// которые относятся к АКТИВНОМУ окну-контейнеру. Если игрок drag-and-droпает
        /// в НЕ активное окно (особенно если у окон разные размеры) — Clamp в
        /// CalculateSnapPosition работает с неправильными границами, и предмет
        /// placed на 1 клетку ниже/правее ожидаемого (или выше/левее — зависит
        /// от того, какое окно активно).
        ///
        /// Теперь K_InventorySlotUI.OnDrop передаёт свой _boundController напрямую,
        /// и размеры берутся из него — что всегда соответствует окну, над которым
        /// находится слот.
        /// </summary>
        public (int x, int y) GetAdjustedDropPosition(
            int slotX, int slotY, Vector2Int itemSize, GridType gridType,
            InventoryController boundController)
        {
            int gridW, gridH;

            // Приоритет 1: boundController (если передан и валиден).
            // Это критично для Container — окно, которому принадлежит слот,
            // может отличаться от активного окна.
            if (boundController != null && boundController.Width > 0 && boundController.Height > 0)
            {
                gridW = boundController.Width;
                gridH = boundController.Height;
            }
            else
            {
                // Приоритет 2: GetGridWidth/Height (для Pockets/Pocket2/Backpack
                // это константы; для Container — _currentContainerCols/Rows).
                gridW = GetGridWidth(gridType);
                gridH = GetGridHeight(gridType);

                // Приоритет 3: контроллер сетки (через GetControllerForGrid).
                if (gridW <= 0 || gridH <= 0)
                {
                    var controller = GetControllerForGrid(gridType);
                    gridW = controller?.Width ?? 0;
                    gridH = controller?.Height ?? 0;
                }
            }

            if (gridW <= 0) return (slotX, slotY);
            return CalculateSnapPosition(slotX, slotY, itemSize, gridW, gridH);
        }

        #endregion

        // >>> FIX проблемы 2+6: дроп на иконку рюкзака без открытия панели + авто-поворот <<<
        // >>> FIX проблемы 2+6: дроп на иконку рюкзака без открытия панели + авто-поворот <<<
        // >>> FIX проблемы 2+6: дроп на иконку рюкзака без открытия панели + авто-поворот <<<
        public bool TryDropItemIntoBackpack(UI_Item draggedUI, InventoryItem target, bool fromEquip)
        {
            // ФИКС БАГ (user feedback — duplication): защита от OnDrop после abort.
            if (!_isDragging)
            {
                Debug.LogWarning(
                    "[TryDropItemIntoBackpack] Rejected: drag session not active.");
                return false;
            }

            InventoryItem item = fromEquip ? _draggedFromSlotItem : (draggedUI != null ? draggedUI.Item : null);
            if (item == null || target == null || target.Data == null || !target.Data.IsBackpack) return false;
            if (target.IsFolded && !target.Data.AlwaysShowGrid) return false;
            if (!target.HasInternalGrid || item == target) return false;
         
            if (item.Data != null && item.Data.IsBackpack)
            {
                // ═══ НОВЫЙ ФИКС: синхронизация перед WouldCreateCircularReference ═══
                SyncBackpackForValidation(item);
                SyncBackpackForValidation(target);

                if (WouldCreateCircularReference(item, target))
                {
                    Debug.Log($"[CYCLE-BLOCK] TryDropItemIntoBackpack rejected: " +
                              $"'{item.Data?.DisplayName}' → '{target.Data?.DisplayName}' would create cycle.");
                    return false;
                }
            }

            int origAngle = item.RotationAngle;
            var db = K_InventorySetup.DatabaseInstance;
            if (db == null) return false;
            int w = target.Data.BackpackWidth, h = target.Data.BackpackHeight;
            if (w <= 0 || h <= 0) return false;

            // FIX: Ищем контроллер в _openedBackpacks, а не только в активном окне.
            // Это позволяет корректно бросать предметы в неактивные открытые рюкзаки.
            InventoryController liveCtrl = null;
            if (_openedBackpacks.TryGetValue(target.InstanceID.ToString(), out var openCtrl))
                liveCtrl = openCtrl;

            InventoryController workCtrl; bool workIsTemp;
            if (liveCtrl != null)
            {
                workCtrl = liveCtrl;
                workIsTemp = false;
            }
            else
            {
                var data = new InventoryData(w, h);
                var savedItems = target.GetBackpackSavedItems();
                if (savedItems != null) foreach (var s in savedItems) data.AddItem(s);
                workCtrl = new InventoryController(data, db, "TempDrop_" + target.InstanceID);
                workIsTemp = true;
            }

            if (!TryFindPlacementWithAutoRotate(workCtrl, item, out int px, out int py))
            {
                // ФИКС БАГ (audit) #15: RestoreRotationState вместо while.
                item.RestoreRotationState(origAngle);
                if (workIsTemp) workCtrl.Dispose();
                return false; // предмет вернёт EndDragComplete
            }

            // FIX: Размещаем предмет напрямую в workCtrl, минуя TryPlaceItem.
            // TryPlaceItem ломался, если target не был активным окном, так как он обращался к _activeContainerController.
            bool placed = workCtrl.PlaceExistingItem(item, px, py);
            if (!placed)
                placed = workCtrl.PlaceExistingItemInFirstFreeSlot(item);

            if (placed)
            {
                // Если использовали временный контроллер, сохраняем данные обратно в рюкзак
                if (workIsTemp)
                {
                    target.ReplaceBackpackContents(workCtrl.GetSaveData().GetItems());
                    workCtrl.Dispose();
                }

                // Очищаем состояние drag-and-drop
                if (fromEquip)
                {
                    FinalizeEquipSlotDrag();
                }
                else
                {
                    if (draggedUI != null)
                    {
                        draggedUI.gameObject.SetActive(false);
                        ReturnToPool(draggedUI);
                    }
                }

                // FIX БАГ 1 & 2: Предмет был деактивирован (draggedUI.SetActive(false)), 
                // поэтому Unity Event System НЕ вызовет OnEndDrag. Мы должны вызвать 
                // EndDragComplete() вручную, чтобы скрыть призрак (ghost) и отключить 
                // raycast на слотах (SetAllGridSlotsRaycast(false)). Иначе сетки "залипают".
                _dropHandled = true;
                _dragItemRemoved = false;
                _needsPostDragRefresh = false;
                if (_postDragRefreshCoroutine != null)
                {
                    StopCoroutine(_postDragRefreshCoroutine);
                    _postDragRefreshCoroutine = null;
                }
                _draggedItem = null;

                EndDragComplete();

                ForceRefresh(); // Обновляем UI всех окон
                return true;
            }

            // Если placement вдруг не удался (хотя должен был), откатываем вращение
            // ФИКС БАГ (audit) #15: RestoreRotationState вместо while.
            item.RestoreRotationState(origAngle);
            if (workIsTemp) workCtrl.Dispose();
            return false;
        }
        private bool TryFindPlacementWithAutoRotate(InventoryController ctrl, InventoryItem item, out int px, out int py)
        {
            px = 0; py = 0;
            if (TryFindFreeCell(ctrl, item, out px, out py)) return true;
            if (item.Data != null && item.Data.CanRotate && item.CurrentSize.x != item.CurrentSize.y)
            {
                item.Rotate();
                if (TryFindFreeCell(ctrl, item, out px, out py)) return true;
                item.Rotate();
            }
            return false;
        }
        private bool TryFindFreeCell(InventoryController ctrl, InventoryItem item, out int px, out int py)
        {
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                    if (ctrl.CanPlaceItem(item, x, y)) { px = x; py = y; return true; }
            px = 0; py = 0; return false;
        }
        // >>> END FIX <<<

        #region Context Menu

        /// <summary>
        /// Автоматически создаёт K_ContextMenu если его ещё нет на сцене.
        /// Вызывается из Awake после инициализации Canvas.
        /// </summary>
        private void EnsureContextMenu()
        {
            if (K_ContextMenu.Instance != null) return;

            var rootCanvas = FindRootCanvas();
            var go = new GameObject("ContextMenu", typeof(RectTransform), typeof(Image), typeof(CanvasGroup));
            if (rootCanvas != null)
                go.transform.SetParent(rootCanvas.transform, false);
            else
                go.transform.SetParent(transform.root, false);
            // НЕ деактивируем до AddComponent — иначе Awake отложится
            // и GetComponentInParent не найдёт Canvas

            var ctx = go.AddComponent<K_ContextMenu>();
            ctx.Initialize(rootCanvas);

            // Передаём стиль из Inspector, если назначен
            if (_contextMenuStyle != null)
                ctx.SetStyle(_contextMenuStyle);

            // Теперь деактивируем — меню скрыто по умолчанию
            go.SetActive(false);
        }

        #endregion

        #region Backpack Fold/Unfold

        /// <summary>
        /// ФИКС v2: Проверяет, пуст ли рюкзак внутри.
        /// - Для экипированного: проверяет _backpackController И сериализованные данные.
        /// - Для неэкипированного: проверяет сериализованные данные (InventoryItem.HasBackpackContents)
        ///   а также активный контроллер рюкзака-контейнера, если он сейчас открыт.
        /// </summary>
        /// <summary>
        /// Синхронизирует содержимое рюкзака из ВСЕХ возможных источников
        /// (экипированный контроллер, открытый контейнер) в _backpackContentsSerialized.
        /// Вызывать ПЕРЕД любой проверки "пуст ли рюкзак".
        /// </summary>
        private void SyncBackpackContentsBeforeFold(InventoryItem item)
        {
            if (item == null || !item.Data.IsBackpack) return;

            // 1. Экипированный рюкзак → ВСЕГДА синхронизируем (даже если пуст)
            if (_backpackSlot != null && _backpackSlot.EquippedItem == item)
            {
                if (_backpackController != null)
                {
                    var savedItems = _backpackController.GetSaveData()?.GetItems();
                    item.ReplaceBackpackContents(savedItems);
                }
            }

            // 2. Открыт как контейнер → ВСЕГДА синхронизируем (даже если пуст)
            string idStr = item.InstanceID.ToString();
            if (_openedBackpacks.TryGetValue(idStr, out var ctrl))
            {
                if (ctrl != null)
                {
                    var savedItems = ctrl.GetSaveData()?.GetItems();
                    item.ReplaceBackpackContents(savedItems);
                }
            }
        }
        /// <summary>
        /// Публичная обёртка для UI_Item. Синхронизирует содержимое рюкзака
        /// перед проверкой циклических ссылок.
        /// </summary>
        public void SyncBackpackForValidationPublic(InventoryItem backpackItem)
        {
            SyncBackpackForValidation(backpackItem);
        }
        /// <summary>
        /// Синхронизирует _backpackContentsSerialized рюкзака из ЖИВОГО контроллера
        /// (экипированный → _backpackController, открытый окном → _openedBackpacks).
        /// ОБЯЗАТЕЛЬНО вызывать перед любой проверкой ContainsDescendant /
        /// WouldCreateCircularReference, иначе проверка работает по устаревшему снимку.
        /// </summary>
        private void SyncBackpackForValidation(InventoryItem backpackItem)
        {
            if (backpackItem == null || backpackItem.Data == null || !backpackItem.Data.IsBackpack)
                return;

            // Экипированный рюкзак
            if (_backpackSlot != null && _backpackSlot.EquippedItem == backpackItem && _backpackController != null)
            {
                var savedItems = _backpackController.GetSaveData()?.GetItems();
                if (savedItems != null)
                    backpackItem.ReplaceBackpackContents(savedItems);
                return;
            }

            // Открыт как окно-контейнер
            string idStr = backpackItem.InstanceID.ToString();
            if (_openedBackpacks.TryGetValue(idStr, out var ctrl) && ctrl != null)
            {
                var savedItems = ctrl.GetSaveData()?.GetItems();
                if (savedItems != null)
                    backpackItem.ReplaceBackpackContents(savedItems);
            }
        }
        public bool IsBackpackContentsEmpty(InventoryItem item)
        {
            if (item == null || !item.Data.IsBackpack) return true;

            // ФИКС БАГ #7: Принудительно синхронизируем сериализованные данные перед проверкой
            SyncBackpackContentsBeforeFold(item);

            // 1. Если есть открытый контроллер рюкзака — проверяем его
            if (_openedBackpacks.TryGetValue(item.InstanceID.ToString(), out var ctrl))
            {
                if (ctrl != null && ctrl.GetItemCount() > 0) return false;
            }

            // 2. Если рюкзак экипирован — проверяем _backpackController
            if (_backpackSlot != null && _backpackSlot.EquippedItem == item)
            {
                if (_backpackController != null && _backpackController.GetItemCount() > 0)
                    return false;
            }

            // 3. Проверяем сериализованные данные самого предмета
            // (SyncBackpackContentsBeforeFold выше гарантирует, что они актуальны)
            return !item.HasBackpackContents;
        }

        /// <summary>
        /// Проверяет, можно ли развернуть рюкзак в текущей сетке.
        ///
        /// БАГ-ФИКС v10: разворачивание больше НЕ меняет RotationAngle, поэтому
        /// проверяется ТОЛЬКО та ориентация, в которой предмет реально развернётся:
        /// базовый развёрнутый размер, повёрнутый на ТЕКУЩИЙ угол предмета
        /// (ось swap при 90°/270°). Собственные ячейки предмета игнорируются
        /// (CanPlaceRotatedInController), позиция подбирается любая.
        /// </summary>
        public bool CanUnfoldInCurrentGrid(InventoryItem item)
        {
            if (item == null || !item.CanFold || !item.IsFolded) return true;
            // Экипированный рюкзак — всегда можно (слот не имеет размера)
            if (_backpackSlot != null && _backpackSlot.EquippedItem == item) return true;

            var (originGrid, originX, originY) = FindItemLocation(item);
            if (originGrid == null)
            {
                Debug.Log($"[CAN-UNFOLD] '{item.Data?.DisplayName}' not found in any grid → false");
                return false;
            }
            // БАГ-ФИКС: для Container ищем контроллер по окнам/сеткам, а не только
            // «активное окно» — после закрытия окна вложенного рюкзака активное окно
            // могло остаться null, и unfold ошибочно блокировался.
            InventoryController controller = originGrid.Value == GridType.Container
                ? FindControllerForItem(item)
                : GetControllerForGrid(originGrid.Value);
            if (controller == null)
            {
                Debug.Log($"[CAN-UNFOLD] '{item.Data?.DisplayName}' no controller for {originGrid} → false");
                return false;
            }

            var (effectiveW, effectiveH) = GetEffectiveGridSize(originGrid.Value, controller);

            // v10: ориентация развёрнутого предмета = базовый размер, повёрнутый
            // на текущий RotationAngle (90°/270° меняют оси местами).
            Vector2Int baseSize = ComputeUnfoldedSize(item);
            bool axisSwap = Mathf.Abs(item.RotationAngle % 180) > 0;
            Vector2Int unfoldedSize = axisSwap ? new Vector2Int(baseSize.y, baseSize.x) : baseSize;

            // 1) Та же позиция (свои ячейки игнорируются — предмет будет удалён перед unfold)
            if (originX + unfoldedSize.x <= effectiveW && originY + unfoldedSize.y <= effectiveH
                && CanPlaceRotatedInController(controller, unfoldedSize, originX, originY, item))
            {
                Debug.Log($"[CAN-UNFOLD] '{item.Data.DisplayName}' samePos=({originX},{originY}) → true");
                return true;
            }

            // 2) Любая позиция в той же ориентации
            for (int y = 0; y <= effectiveH - unfoldedSize.y; y++)
                for (int x = 0; x <= effectiveW - unfoldedSize.x; x++)
                    if (CanPlaceRotatedInController(controller, unfoldedSize, x, y, item))
                    {
                        Debug.Log($"[CAN-UNFOLD] '{item.Data.DisplayName}' anywhere=({x},{y}) → true");
                        return true;
                    }

            Debug.Log($"[CAN-UNFOLD] '{item.Data.DisplayName}' → false " +
                      $"(unfolded={unfoldedSize.x}x{unfoldedSize.y} @ angle={item.RotationAngle}, grid={effectiveW}x{effectiveH})");
            return false;
        }
        private static Vector2Int ComputeUnfoldedSize(InventoryItem item)
        {
            if (item?.Data == null) return new Vector2Int(1, 1);
            var data = item.Data;
            if (data.IsBackpack && data.UnfoldedIconSize.x > 0 && data.UnfoldedIconSize.y > 0)
                return data.UnfoldedIconSize;
            if (data.IsBackpack && data.BackpackWidth > 0 && data.BackpackHeight > 0)
                return new Vector2Int(data.BackpackWidth, data.BackpackHeight);
            return data.Size;
        }

        /// <summary>
        /// БАГ #2 ФИКС: Проверяет, можно ли разместить предмет заданного размера
        /// в controller на позиции (x, y). Используется в PlaceBackpackWithSmartFit.
        /// </summary>
        private bool CanPlaceInController(InventoryController controller, Vector2Int size, int x, int y)
        {
            if (controller == null) return false;
            if (x < 0 || y < 0) return false;
            if (x + size.x > controller.Width) return false;
            if (y + size.y > controller.Height) return false;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    if (controller.GetItemAt(x + dx, y + dy) != null)
                        return false;
                }
            }
            return true;
        }

        /// <summary>
        /// ФИКС V14: Проверяет, можно ли разместить предмет с указанным размером
        /// (возможно повёрнутым) в контроллере на позиции (x,y). Игнорирует
        /// текущее состояние rotation у item — использует переданный size напрямую.
        /// </summary>
        private bool CanPlaceRotatedInController(InventoryController controller, Vector2Int size, int x, int y, InventoryItem ignoreItem)
        {
            if (controller == null) return false;
            if (x < 0 || y < 0) return false;
            if (x + size.x > controller.Width) return false;
            if (y + size.y > controller.Height) return false;

            for (int dy = 0; dy < size.y; dy++)
            {
                for (int dx = 0; dx < size.x; dx++)
                {
                    var at = controller.GetItemAt(x + dx, y + dy);
                    if (at != null && at.InstanceID != ignoreItem.InstanceID)
                        return false;
                }
            }
            return true;
        }

        /// <summary>
        /// Опустошает рюкзак — вытаскивает все предметы из него в ту же сетку,
        /// в которой лежит рюкзак.
        ///
        /// Логика:
        /// - Если рюкзак экипирован — вытаскивает в карманы игрока (pocketsController).
        /// - Если рюкзак лежит в сетке — вытаскивает в ту же сетку.
        /// - Если места не хватает — вытащатся только те предметы, кому хватило места.
        ///   Остальные останутся в рюкзаке.
        /// - Если рюкзак сейчас ОТКРЫТ как контейнер — сначала закрываем его.
        ///
        /// Возвращает количество предметов, которые удалось вытащить.
        /// </summary>
        public int EmptyBackpackContents(InventoryItem backpackItem)
        {
            if (backpackItem == null || !backpackItem.Data.IsBackpack)
            {
                Debug.LogWarning("[InventoryUI] EmptyBackpackContents: item is null or not a backpack");
                return 0;
            }
            if (backpackItem.IsFolded && !backpackItem.Data.AlwaysShowGrid)
            {
                Debug.Log($"[InventoryUI] Cannot empty folded backpack '{backpackItem.Data.DisplayName}' — unfold first.");
                return 0;
            }

            // 1. Закрываем окна самого рюкзака и всех вложенных рюкзаков
            CloseAllWindowsForBackpack(backpackItem);
            CloseNestedBackpackWindows(backpackItem);

            var savedItems = backpackItem.GetBackpackSavedItems();
            if (savedItems == null || savedItems.Count == 0)
            {
                Debug.Log($"[InventoryUI] Backpack '{backpackItem.Data.DisplayName}' is already empty");
                return 0;
            }

            // 2. Определяем, куда вытаскивать предметы (логика v17 без изменений)
            InventoryController targetController = null;
            var fallbackControllers = new List<InventoryController>();
            if (_backpackSlot != null && _backpackSlot.EquippedItem == backpackItem)
            {
                targetController = _pocketsController;
                fallbackControllers.Add(_pocketsController);
                fallbackControllers.Add(_pocket2Controller);
            }
            else
            {
                var allCtrls = new List<InventoryController> { _pocketsController, _pocket2Controller, _backpackController };
                if (_isLootingContainer && _activeContainerController != null)
                    allCtrls.Add(_activeContainerController);
                if (_isLootingContainer && _activeContainerController == null)
                {
                    var lootCtrlFallback = GetLootControllerFromSlots();
                    if (lootCtrlFallback != null)
                        allCtrls.Add(lootCtrlFallback);
                }
                foreach (var w in _openContainerWindows)
                {
                    if (w != null && w.Controller != null)
                        allCtrls.Add(w.Controller);
                }
                foreach (var ctrl in allCtrls)
                {
                    if (ctrl == null) continue;
                    for (int y = 0; y < ctrl.Height; y++)
                        for (int x = 0; x < ctrl.Width; x++)
                        {
                            if (ctrl.GetItemAt(x, y) == backpackItem)
                            {
                                targetController = ctrl;
                                break;
                            }
                        }
                    if (targetController != null) break;
                }
                if (targetController == null)
                    targetController = _pocketsController;

                bool isInLoot = _isLootingContainer && targetController == _activeContainerController;
                bool isInLootFromSlots = _isLootingContainer && targetController == GetLootControllerFromSlots();
                bool isInWindow = targetController != null
                    && _openContainerWindows.Any(w => w != null && w.Controller == targetController);
                if (isInLoot || isInLootFromSlots || isInWindow)
                {
                    fallbackControllers.Clear();
                    fallbackControllers.Add(targetController);
                }
                else
                {
                    fallbackControllers.Add(_pocketsController);
                    fallbackControllers.Add(_pocket2Controller);
                    fallbackControllers.Add(_backpackController);
                }
            }

            var db = K_InventorySetup.DatabaseInstance;
            if (db == null)
            {
                Debug.LogError("[InventoryUI] Database not initialized");
                return 0;
            }

            int extracted = 0;
            var remaining = new List<SavedItem>();

            // ═══ ФИКС БАГ 1: УМНАЯ УПАКОВКА (First-Fit Decreasing).
            // Результат НЕ зависит от раскладки в источнике: крупные предметы
            // размещаются первыми, мелкие дозаполняют остатки. Плюс полное
            // слияние стеков освобождает клетки для остальных.
            var candidates = new List<InventoryItem>();
            var savedByInstance = new Dictionary<uint, SavedItem>();
            foreach (var saved in savedItems)
            {
                var template = db.GetItemData(saved.ItemID);
                if (template == null)
                {
                    Debug.LogWarning($"[EMPTY-BACKPACK] Cannot restore item '{saved.ItemID}' — template missing. Stays in backpack.");
                    remaining.Add(saved);
                    continue;
                }
                var inner = InventoryItem.FromSaveData(saved, template);
                if (inner == null)
                {
                    Debug.LogWarning($"[EMPTY-BACKPACK] FromSaveData returned null for '{saved.ItemID}'. Stays in backpack.");
                    remaining.Add(saved);
                    continue;
                }
                candidates.Add(inner);
                savedByInstance[inner.InstanceID] = saved;
            }

            // Сортировка: площадь ↓, длинная сторона ↓, InstanceID (детерминизм)
            candidates.Sort((a, b) =>
            {
                int areaA = a.CurrentSize.x * a.CurrentSize.y;
                int areaB = b.CurrentSize.x * b.CurrentSize.y;
                if (areaA != areaB) return areaB.CompareTo(areaA);
                int longA = Mathf.Max(a.CurrentSize.x, a.CurrentSize.y);
                int longB = Mathf.Max(b.CurrentSize.x, b.CurrentSize.y);
                if (longA != longB) return longB.CompareTo(longA);
                return a.InstanceID.CompareTo(b.InstanceID);
            });

            Debug.Log($"[EMPTY-BACKPACK] START empty '{backpackItem.Data.DisplayName}': " +
                $"{savedItems.Count} items inside, targetGrid={targetController.SaveID}, " +
                $"fallbacks={fallbackControllers.Count}.");

            foreach (var inner in candidates)
            {
                bool placedAnywhere = TryPlaceSmartPacked(inner, targetController, fallbackControllers.ToArray());
                if (placedAnywhere)
                {
                    extracted++;
                    Debug.Log($"[EMPTY-BACKPACK] Extracted '{inner.Data?.DisplayName}' (InstanceID={inner.InstanceID}).");
                }
                else
                {
                    Debug.Log($"[EMPTY-BACKPACK] Cannot place '{inner.Data?.DisplayName}' anywhere — stays in backpack.");
                    remaining.Add(savedByInstance[inner.InstanceID]);
                }
            }

            if (extracted + remaining.Count != savedItems.Count)
            {
                Debug.LogError($"[EMPTY-BACKPACK] CRITICAL: lost items! " +
                    $"savedItems.Count={savedItems.Count}, extracted={extracted}, " +
                    $"remaining={remaining.Count}. Diff={savedItems.Count - extracted - remaining.Count}.");
            }

            backpackItem.ReplaceBackpackContents(remaining);

            Debug.Log($"[EMPTY-BACKPACK] DONE empty '{backpackItem.Data.DisplayName}': " +
                $"extracted={extracted}, remaining={remaining.Count}.");

            ForceRefresh();
            return extracted;
        }
        /// <summary>
        /// ФИКС БАГ 1: умное размещение при опустошении. Сначала полное слияние
        /// стеков (освобождает клетки), затем bottom-left размещение с перебором
        /// ориентаций. НЕ даёт предмету «сбежать» из допустимого списка сеток.
        /// </summary>
        private bool TryPlaceSmartPacked(InventoryItem item, InventoryController primary, InventoryController[] fallbacks)
        {
            if (item == null) return false;

            // 1) Полное слияние с существующим стеком (только если влезает ЦЕЛИКОМ —
            //    без частичных слияний, чтобы ничего не потерять).
            if (TryFullStackMerge(item, primary)) return true;
            if (fallbacks != null)
                foreach (var fc in fallbacks)
                    if (fc != null && fc != primary && TryFullStackMerge(item, fc)) return true;

            // 2) Пространственное размещение: bottom-left + поворот.
            if (PlaceSmartInController(item, primary)) return true;
            if (fallbacks != null)
                foreach (var fc in fallbacks)
                    if (fc != null && fc != primary && PlaceSmartInController(item, fc)) return true;

            return false;
        }

        private bool PlaceSmartInController(InventoryItem item, InventoryController ctrl)
        {
            if (ctrl == null) return false;

            // Ориентация 1: текущая
            if (TryPlaceBottomLeft(item, ctrl)) return true;

            // Ориентация 2: повёрнутая (если можно и не квадрат)
            if (item.Data != null && item.Data.CanRotate)
            {
                Vector2Int sz = item.CurrentSize;
                if (sz.x != sz.y)
                {
                    item.Rotate();
                    bool ok = TryPlaceBottomLeft(item, ctrl);
                    if (!ok) item.Rotate(); // откат — предмет остаётся в исходном состоянии
                    return ok;
                }
            }
            return false;
        }

        /// <summary>
        /// First-fit bottom-left: первая свободная позиция при сканировании
        /// сверху-вниз, слева-направо. PlaceExistingItem сам гарантирует, что
        /// клетки пустые (CanOccupy) — никакого перезаписывания/исчезновения.
        /// </summary>
        private bool TryPlaceBottomLeft(InventoryItem item, InventoryController ctrl)
        {
            if (ctrl == null) return false;
            Vector2Int size = item.CurrentSize;
            for (int y = 0; y <= ctrl.Height - size.y; y++)
                for (int x = 0; x <= ctrl.Width - size.x; x++)
                    if (ctrl.PlaceExistingItem(item, x, y))
                        return true;
            return false;
        }

        /// <summary>
        /// Полное слияние стека: добавляет item в существующий совместимый стек,
        /// только если количество влезает целиком (лимит, прочность, поворот, fold).
        /// </summary>
        private bool TryFullStackMerge(InventoryItem item, InventoryController ctrl)
        {
            if (item == null || ctrl == null || item.Data == null) return false;
            if (item.Data.HardStackLimit <= 1 || item.Quantity <= 0) return false;

            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var at = ctrl.GetItemAt(x, y);
                    if (at == null || at == item) continue;
                    if (at.PrefabID != item.PrefabID) continue;
                    if (at.Durability != item.Durability) continue;
                    if (at.RotationAngle != item.RotationAngle) continue;
                    if (at.IsFolded != item.IsFolded) continue;
                    if (at.Quantity + item.Quantity > at.Data.HardStackLimit) continue;

                    int old = at.Quantity;
                    at.AddQuantity(item.Quantity);
                    int added = at.Quantity - old;
                    if (added <= 0) continue;

                    ctrl.GetSaveData().UpdateItem(at.InstanceID, x, y, at.Quantity, at.IsRotated);
                    ctrl.AdjustWeight(item.Data.WeightGrams * added);
                    return true;
                }
            return false;
        }
        private void CloseNestedBackpackWindows(InventoryItem backpackItem, int depth = 0)
        {
            // Защита от циклических ссылок и слишком глубокой вложенности
            if (backpackItem == null || !backpackItem.Data.IsBackpack || depth > 16) return;

            var savedItems = backpackItem.GetBackpackSavedItems();
            if (savedItems == null) return;
            var db = K_InventorySetup.DatabaseInstance;
            if (db == null) return;

            foreach (var saved in savedItems)
            {
                if (saved.InstanceID > 0)
                {
                    string idStr = saved.InstanceID.ToString();
                    if (_openedBackpacks.TryGetValue(idStr, out var ctrl))
                    {
                        var owner = FindBackpackItemByID(idStr) ?? InventoryItem.FromSaveData(saved, db.GetItemData(saved.ItemID));
                        if (owner != null)
                        {
                            var items = ctrl.GetSaveData()?.GetItems();
                            owner.ReplaceBackpackContents(items);
                        }
                        ctrl.Dispose();
                        _openedBackpacks.Remove(idStr);
                    }
                    var win = _openContainerWindows.Find(w => w.BackpackInstanceID == idStr);
                    if (win != null) DestroyContainerWindow(win);
                }
                var template = db.GetItemData(saved.ItemID);
                if (template != null && template.IsBackpack)
                {
                    var innerItem = InventoryItem.FromSaveData(saved, template);
                    if (innerItem != null) CloseNestedBackpackWindows(innerItem, depth + 1); // Передаем увеличенную глубину
                }
            }
        }
        /// <summary>
        /// Пытается разместить предмет в основной сетке, при неудаче — в fallback-сетках.
        /// В каждой сетке автоматически пробует развернуть предмет (если CanRotate).
        /// Возвращает true если удалось разместить хотя бы в одну сетку.
        ///
        /// ФИКС БАГ "предметы исчезают при опустошении": PlaceExistingItemInFirstFreeSlot
        /// НЕ разворачивает предмет автоматически. Если вертикальный (1×2) предмет не
        /// помещается, а свободное место только 2×1 — он остаётся в рюкзаке. Этот метод
        /// пробует развернуть предмет и повторить placement.
        /// </summary>
        
        public void ToggleBackpackFold(InventoryItem item, bool fold)
        {
            Debug.Log($"[V9-FOLD] ToggleBackpackFold START: item={item?.Data?.DisplayName}, " +
                $"fold={fold}, item.IsFolded={item?.IsFolded}, item.CanFold={item?.CanFold}, " +
                $"item.IsBackpack={item?.Data?.IsBackpack}");

            if (item == null || !item.CanFold)
            {
                Debug.LogWarning($"[V9-FOLD] ABORT: item null or CanFold=false " +
                    $"(item={(item == null ? "null" : item.Data?.DisplayName)}, CanFold={item?.CanFold})");
                return;
            }

            // ФИКС v9: Раньше проверялся только item.CanFold, но не item.Data.IsBackpack.
            // Это могло привести к тому, что unfold пытались вызвать на предмете который
            // не является рюкзаком (но имеет CanFold=true по ошибке в данных).
            if (!item.Data.IsBackpack)
            {
                Debug.LogWarning($"[V9-FOLD] ABORT: item is not a backpack " +
                    $"(item={item.Data.DisplayName}, Type={item.Type})");
                return;
            }

            // ✅ Синхронизируем содержимое ПЕРЕД проверкой пустоты
            if (fold)
                SyncBackpackContentsBeforeFold(item);

            // Проверяем: нельзя свернуть непустой рюкзак
            if (fold && !IsBackpackContentsEmpty(item))
            {
                Debug.Log($"[V9-FOLD] Cannot fold backpack '{item.Data.DisplayName}' — not empty");
                return;
            }

            // Нельзя свернуть уже свёрнутый или развернуть уже развёрнутый
            if (fold && item.IsFolded)
            {
                Debug.Log($"[V9-FOLD] Already folded, nothing to do");
                return;
            }
            if (!fold && !item.IsFolded)
            {
                Debug.Log($"[V9-FOLD] Already unfolded, nothing to do");
                return;
            }

            // Случай 1: Рюкзак экипирован в слоте
            if (_backpackSlot != null && _backpackSlot.EquippedItem == item)
            {
                Debug.Log($"[V9-FOLD] → HandleEquippedBackpackFold");
                HandleEquippedBackpackFold(item, fold);
                return;
            }

            // Случай 2: Рюкзак лежит в сетке инвентаря (карманы, рюкзак, контейнер)
            Debug.Log($"[V9-FOLD] → HandleInventoryBackpackFold");
            HandleInventoryBackpackFold(item, fold);
        }

        /// <summary>
        /// Fold/unfold для экипированного рюкзака.
        ///
        /// FOLD:
        /// - Сначала синхронизируем содержимое _backpackController → item._backpackContentsSerialized.
        /// - Очищаем сетку рюкзака (визуально).
        /// - Ставим IsFolded=true.
        ///
        /// UNFOLD:
        /// - IsFolded=false.
        /// - Перестраиваем сетку рюкзака.
        /// - Восстанавливаем содержимое из item._backpackContentsSerialized в _backpackController.
        /// </summary>
        private void HandleEquippedBackpackFold(InventoryItem item, bool fold)
        {
            if (fold)
            {
                // ✅ Синхронизируем и проверяем
                SyncEquippedBackpackControllerToItem(item);
                if (!IsBackpackContentsEmpty(item))
                {
                    Debug.Log($"[FOLD] Equipped backpack '{item.Data.DisplayName}' is not empty — cannot fold");
                    return;
                }
                // ... остальная логика fold ...
            }
            if (fold)
            {
                // 1. Сливаем содержимое контроллера в сериализованный список предмета
                SyncEquippedBackpackControllerToItem(item);

                // 2. Очищаем сам контроллер (предметы временно живут в item._backpackContentsSerialized)
                if (_backpackController != null)
                    _backpackController.Clear();

                if (!item.ToggleFold(contentsEmpty: true))
                {
                    RestoreEquippedBackpackControllerFromItem(item);
                    return;
                }

                // 4. Скрываем UI-сетку рюкзака

                // 4. Скрываем UI-сетку рюкзака
                if (_backpackGrid != null)
                    ClearGrid(_backpackGrid, _backpackItemsContainer);
                _currentBackpackCols = 0;
                _currentBackpackRows = 0;

                Debug.Log($"[InventoryUI] Equipped backpack FOLDED: {item.Data.DisplayName} " +
                          $"(contents preserved: {item.GetBackpackSavedItems().Count} items)");
            }
            else
            {
                // 1. Разворачиваем флаг (всегда можно)
                item.ToggleFold(contentsEmpty: true);

                // 2. Перестраиваем UI-сетку рюкзака
                if (item.Data.BackpackWidth > 0 && item.Data.BackpackHeight > 0)
                    RebuildBackpackGrid(item.Data.BackpackWidth, item.Data.BackpackHeight);

                // 3. Восстанавливаем содержимое контроллера из сериализованных данных
                RestoreEquippedBackpackControllerFromItem(item);

                Debug.Log($"[InventoryUI] Equipped backpack UNFOLDED: {item.Data.DisplayName} " +
                          $"(contents restored: {item.GetBackpackSavedItems().Count} items)");
            }

            // Обновляем иконку в слоте экипировки
            _backpackSlot?.Refresh();

            ForceRefresh();
        }

        /// <summary>
        /// Синхронизирует содержимое экипированного _backpackController
        /// в сериализованный список item._backpackContentsSerialized.
        /// </summary>
        private void SyncEquippedBackpackControllerToItem(InventoryItem item)
        {
            if (_backpackController == null || item == null) return;

            var savedItems = _backpackController.GetSaveData()?.GetItems();
            if (savedItems == null) return;

            item.ReplaceBackpackContents(savedItems);
        }

        /// <summary>
        /// Восстанавливает содержимое экипированного _backpackController
        /// из сериализованного списка item._backpackContentsSerialized.
        /// </summary>
        private void RestoreEquippedBackpackControllerFromItem(InventoryItem item)
        {
            if (_backpackController == null || item == null) return;

            // Очищаем текущее состояние контроллера
            _backpackController.Clear();

            // Восстанавливаем из сохранённых данных
            var savedItems = item.GetBackpackSavedItems();
            if (savedItems == null || savedItems.Count == 0) return;

            foreach (var saved in savedItems)
            {
                var template = K_InventorySetup.DatabaseInstance?.GetItemData(saved.ItemID);
                if (template == null)
                {
                    Debug.LogWarning($"[InventoryUI] Cannot restore item '{saved.ItemID}' — template missing");
                    continue;
                }
                var inner = InventoryItem.FromSaveData(saved, template);
                if (inner == null) continue;

                // ВАЖНО: используем PlaceExistingItem, чтобы сохранить _isFolded и
                // _backpackContentsSerialized внутреннего предмета (если это тоже рюкзак).
                // TryPlaceItem создал бы новый объект и сбросил бы fold-состояние.
                _backpackController.PlaceExistingItem(inner, saved.X, saved.Y);
            }
        }

        /// <summary>
        /// Fold/unfold для рюкзака, лежащего в сетке инвентаря.
        /// Операция НЕ меняет разворот предмета: каким рюкзак был свёрнут —
        /// таким разворачивается, и наоборот. Smart-fit подбирает ТОЛЬКО позицию
        /// (без поворота); если в текущей ориентации не влезает — откат,
        /// рюкзак остаётся в прежнем состоянии.
        /// </summary>
        /// <summary>
        /// Fold/unfold для рюкзака, лежащего в сетке инвентаря.
        /// Операция НЕ меняет разворот предмета: каким свернули/развернули — таким и остаётся.
        /// Smart-fit подбирает ТОЛЬКО позицию (без поворота); не влезает — откат.
        /// Если рюкзак открыт окном — все его окна закрываются ДО изменения состояния
        /// (и сворачивание делает и то и другое за одно нажатие).
        /// </summary>
        private void HandleInventoryBackpackFold(InventoryItem item, bool fold)
        {
            try
            {
                Debug.Log($"[V9-FOLD] HandleInventoryBackpackFold START: item={item.Data.DisplayName}, fold={fold}");

                // Если предмет "в воздухе" (drag) — сначала возвращаем его в origin.
                if (_isDragging && _dragItemRemoved && _draggedItem != null && _draggedItem.Item == item)
                {
                    Debug.Log($"[V9-FOLD] Item is mid-drag (_dragItemRemoved=true). Returning to origin.");
                    var orphanOriginController = GetControllerForGrid(_dragOriginGridType);
                    if (orphanOriginController != null)
                    {
                        bool orphanPlaced = orphanOriginController.PlaceExistingItem(item, _dragOriginX, _dragOriginY);
                        if (!orphanPlaced) orphanPlaced = orphanOriginController.PlaceExistingItemInFirstFreeSlot(item);
                        if (!orphanPlaced) orphanPlaced = TryPlaceInAnyPlayerGrid(item);
                        if (!orphanPlaced)
                            Debug.LogError($"[V9-FOLD] Could not return orphan item '{item.Data.DisplayName}' to origin!");
                    }
                }

                // Отменяем отложенный PostDragEndFallback, чтобы он не перетёр новую позицию.
                if (_postDragRefreshCoroutine != null)
                {
                    StopCoroutine(_postDragRefreshCoroutine);
                    _postDragRefreshCoroutine = null;
                }
                _needsPostDragRefresh = false;
                _dragItemRemoved = false;
                _dropHandled = false;
                _draggedItem = null;
                _draggedFromEquipmentSlot = null;
                _draggedFromSlotItem = null;
                _draggedFromSlotIconRotation = 0f;
                _isDragging = false;

                var (originGrid, originX, originY) = FindItemLocation(item);
                Debug.Log($"[V9-FOLD] FindItemLocation → grid={originGrid}, pos=({originX},{originY})");
                if (originGrid == null)
                {
                    Debug.LogWarning($"[V9-FOLD] Cannot find backpack '{item.Data.DisplayName}' in any grid");
                    return;
                }

                // ═══ БАГ-ФИКС v11 (сетка закрылась, но рюкзак не свернулся): ═══
                // Контроллер ищем ТОЛЬКО по физическому нахождению предмета (ячейки
                // сеток/окон). СТАРЫЙ код первым циклом находил окно-ВЛАДЕЛЕЦ самого
                // предмета (его собственный открытый контейнер) — а ниже это окно
                // закрывается и его контроллер dispose'ится → RemoveItem/Place работали
                // с disposed-контроллером → исключение → «сетка закрылась, рюкзак не свернулся».
                InventoryController controller = originGrid.Value == GridType.Container
                    ? FindControllerForItem(item)          // ячейки окон, НЕ окно-владелец
                    : GetControllerForGrid(originGrid.Value);
                if (controller == null)
                    controller = _activeContainerController;
                if (controller == null)
                {
                    Debug.LogWarning($"[V9-FOLD] No controller for grid {originGrid}");
                    return;
                }

                int origX = originX;
                int origY = originY;
                int origRotationAngle = item.RotationAngle; // для отката при неудаче

                // Если рюкзак открыт окном — закрываем ВСЕ его окна ДО изменения состояния.
                if (_activeBackpackContainer == item
                    || _openContainerWindows.Any(w => w != null && w.BackpackInstanceID == item.InstanceID.ToString()))
                {
                    Debug.Log($"[V9-FOLD] Closing ALL windows for backpack '{item.Data.DisplayName}' before fold/unfold");
                    CloseAllWindowsForBackpack(item);
                    // Закрытое окно могло быть тем, в котором лежал предмет, только если
                    // предмет лежал в СОБСТВЕННОМ окне — это невозможно (предмет не может
                    // лежать сам в себе), поэтому controller выше всегда живой.
                }

                controller.RemoveItem(item);
                bool ok = item.ToggleFold(contentsEmpty: true);
                Debug.Log($"[V9-FOLD] item.ToggleFold → ok={ok}, new size={item.CurrentSize}, IsFolded={item.IsFolded}");
                if (!ok)
                {
                    Debug.LogWarning($"[V9-FOLD] ToggleFold failed, returning item to original position");
                    controller.PlaceExistingItem(item, origX, origY);
                    ForceRefresh();
                    return;
                }

                // Разворот НЕ меняется; smart-fit без поворота — только подбор позиции.
                bool allowRotation = false;
                var (effectiveW, effectiveH) = GetEffectiveGridSize(originGrid.Value, controller);
                bool placed = PlaceBackpackWithSmartFit(controller, item, origX, origY, allowRotation, effectiveW, effectiveH);

                if (!placed)
                {
                    // Не влезло в текущей ориентации — откат fold-состояния и позиции.
                    Debug.LogWarning($"[V9-FOLD] Smart-fit failed — rolling back fold state. " +
                                     $"Item stays {(fold ? "folded" : "unfolded")} at original position.");
                    bool rollbackOk = item.ToggleFold(contentsEmpty: !fold);
                    if (!rollbackOk)
                        Debug.LogError($"[V9-FOLD] CRITICAL: ToggleFold rollback failed! Item is in inconsistent state.");
                    item.RestoreRotationState(origRotationAngle);
                    if (!controller.PlaceExistingItem(item, origX, origY))
                    {
                        if (!controller.PlaceExistingItemInFirstFreeSlot(item))
                            Debug.LogError($"[V9-FOLD] CRITICAL: Cannot return item '{item.Data.DisplayName}' to grid after failed fold/unfold! Item is orphaned.");
                    }
                    ForceRefresh();
                    return;
                }

                Debug.Log($"[V9-FOLD] {(fold ? "FOLDED" : "UNFOLDED")} OK: {item.Data.DisplayName}, size={item.CurrentSize}");
                ForceRefresh();
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[V9-FOLD] HandleInventoryBackpackFold CRASHED: {ex}");
            }
        }
        private bool PlaceBackpackWithSmartFit(InventoryController controller, InventoryItem item,
    int origX, int origY, bool allowRotation, int effectiveW, int effectiveH)
        {
            if (controller == null || item == null) return false;
            int gridW = effectiveW;   // <<< видимый размер, НЕ controller.Width
            int gridH = effectiveH;   // <<< видимый размер, НЕ controller.Height
            System.Func<int, int, Vector2Int, bool> fits = (x, y, s) =>
                x >= 0 && y >= 0 && x + s.x <= gridW && y + s.y <= gridH;
            Vector2Int size = item.CurrentSize;
            if (size.x > gridW || size.y > gridH)
            {
                if (!allowRotation || size.y > gridW || size.x > gridH) return false;
            }
            else
            {
                if (fits(origX, origY, size) && controller.PlaceExistingItem(item, origX, origY)) return true;
                int clampedX = Mathf.Max(0, Mathf.Min(origX, gridW - size.x));
                if (clampedX != origX && fits(clampedX, origY, size) && controller.PlaceExistingItem(item, clampedX, origY)) return true;
                int clampedY = Mathf.Max(0, Mathf.Min(origY, gridH - size.y));
                if (clampedY != origY && fits(origX, clampedY, size) && controller.PlaceExistingItem(item, origX, clampedY)) return true;
                if ((clampedX != origX || clampedY != origY) && fits(clampedX, clampedY, size) && controller.PlaceExistingItem(item, clampedX, clampedY)) return true;
                for (int radius = 0; radius < Mathf.Max(gridW, gridH); radius++)
                    for (int dy = -radius; dy <= radius; dy++)
                        for (int dx = -radius; dx <= radius; dx++)
                        {
                            if (Mathf.Abs(dx) != radius && Mathf.Abs(dy) != radius) continue;
                            int nx = origX + dx, ny = origY + dy;
                            if (nx < 0 || ny < 0 || nx + size.x > gridW || ny + size.y > gridH) continue;
                            if (controller.PlaceExistingItem(item, nx, ny)) return true;
                        }
                // last-resort по controller.Width УБРАН — он обходил visible-границу и давал вылезание.
            }
            if (allowRotation && item.Data != null && item.Data.CanRotate && size.x != size.y)
            {
                item.Rotate();
                Vector2Int rotSize = item.CurrentSize;
                if (rotSize.x <= gridW && rotSize.y <= gridH)
                {
                    int rcx = Mathf.Max(0, Mathf.Min(origX, gridW - rotSize.x));
                    int rcy = Mathf.Max(0, Mathf.Min(origY, gridH - rotSize.y));
                    if ((fits(origX, origY, rotSize) && controller.PlaceExistingItem(item, origX, origY))
                        || (fits(rcx, origY, rotSize) && controller.PlaceExistingItem(item, rcx, origY))
                        || (fits(origX, rcy, rotSize) && controller.PlaceExistingItem(item, origX, rcy))
                        || (fits(rcx, rcy, rotSize) && controller.PlaceExistingItem(item, rcx, rcy)))
                        return true;
                    for (int radius = 0; radius < Mathf.Max(gridW, gridH); radius++)
                        for (int dy = -radius; dy <= radius; dy++)
                            for (int dx = -radius; dx <= radius; dx++)
                            {
                                if (Mathf.Abs(dx) != radius && Mathf.Abs(dy) != radius) continue;
                                int nx = origX + dx, ny = origY + dy;
                                if (nx < 0 || ny < 0 || nx + rotSize.x > gridW || ny + rotSize.y > gridH) continue;
                                if (controller.PlaceExistingItem(item, nx, ny)) return true;
                            }
                }
                item.Rotate();
            }
            return false;
        }



        /// <summary>
        /// БАГ #4 ФИКС: Проверяет, создаст ли placement циклическую
        /// ссылку между рюкзаками.
        ///
        /// Сценарий: Рюкзак A содержит рюкзак B. B открыт как контейнер.
        /// Пользователь пытается положить A в сетку B → это создаст
        /// цикл A→B→A. Оба рюкзака исчезнут из инвентаря.
        ///
        /// ПРОВЕРКА (двусторонняя, более надёжная чем раньше):
        /// 1. item содержит _activeBackpackContainer — item → ... → activeContainer
        ///    (если положить item в activeContainer, получится цикл).
        /// 2. _activeBackpackContainer содержит item — activeContainer → ... → item
        ///    (item уже внутри activeContainer — перенос бессмысленен/дубликат).
        ///
        /// ВАЖНО: Использует InventoryItem.ContainsDescendant, который:
        /// - Сначала синхронизирует _backpackContentsSerialized из активного
        ///   контроллера — иначе устаревший снимок может пропустить цикл.
        /// - Ограничивает глубину рекурсии 32 уровнями — защита от зацикливания
        ///   на повреждённых данных (когда снимок сам содержит цикл).
        /// </summary>

        /// <summary>
        /// ФИКС БАГ 3: Рекурсивно проверяет живые контроллеры, чтобы узнать,
        /// содержит ли указанный рюкзак целевой предмет (даже если он глубоко внутри открытых окон).
        /// </summary>
        private bool DoesControllerContainItemRecursive(InventoryController ctrl, uint targetId, int depth = 0)
        {
            if (ctrl == null || depth > 16) return false;
            for (int y = 0; y < ctrl.Height; y++)
            {
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var it = ctrl.GetItemAt(x, y);
                    if (it == null) continue;
                    if (it.InstanceID == targetId) return true;

                    if (it.Data != null && it.Data.IsBackpack)
                    {
                        // Ищем открытое окно для этого рюкзака
                        var innerWindow = _openContainerWindows.Find(w => w.BackpackInstanceID == it.InstanceID.ToString());
                        if (innerWindow != null && innerWindow.Controller != null)
                        {
                            if (DoesControllerContainItemRecursive(innerWindow.Controller, targetId, depth + 1))
                                return true;
                        }
                        // Иначе проверяем по сериализованным данным (если окно закрыто)
                        else if (it.ContainsDescendant(targetId)) return true;
                    }
                }
            }
            return false;
        }
        private bool WouldCreateCircularReference(InventoryItem item, InventoryItem targetBackpack = null)
        {
            var target = targetBackpack ?? _activeBackpackContainer;
            if (target == null) return false;
            if (item == null) return false;

            // Прямая ссылка: item == target (перенос сам в себя)
            if (item.InstanceID == target.InstanceID)
            {
                Debug.Log($"[BUG4-CYCLE] Detected: item == target (self-drop).");
                return true;
            }

            uint targetId = target.InstanceID;
            uint itemId = item.InstanceID;

            // ═══ Синхронизируем ЦЕЛЕВОЙ рюкзак из живого контроллера ═══
            string targetIdStr = target.InstanceID.ToString();
            if (_openedBackpacks.TryGetValue(targetIdStr, out var targetCtrl) && targetCtrl != null)
            {
                var targetSavedItems = targetCtrl.GetSaveData()?.GetItems();
                if (targetSavedItems != null)
                    target.ReplaceBackpackContents(targetSavedItems);
            }

            // ═══ Синхронизируем item (если рюкзак) ═══
            if (item.Data.IsBackpack)
            {
                if (_backpackSlot != null && _backpackSlot.EquippedItem == item && _backpackController != null)
                {
                    var equippedSavedItems = _backpackController.GetSaveData()?.GetItems();
                    if (equippedSavedItems != null)
                        item.ReplaceBackpackContents(equippedSavedItems);
                }
                else if (_openedBackpacks.TryGetValue(item.InstanceID.ToString(), out var itemCtrl) && itemCtrl != null)
                {
                    var itemSavedItems = itemCtrl.GetSaveData()?.GetItems();
                    if (itemSavedItems != null)
                        item.ReplaceBackpackContents(itemSavedItems);
                }
            }

            // ═══ ПРОВЕРКА 1: item содержит target → цикл при placement в target ═══
            // Актуально ТОЛЬКО для рюкзаков (не-рюкзак не может "содержать" target).
            if (item.Data.IsBackpack)
            {
                if (_backpackSlot != null && _backpackSlot.EquippedItem == item && _backpackController != null)
                {
                    if (DoesControllerContainItemRecursive(_backpackController, targetId)) return true;
                }
                else if (_openedBackpacks.TryGetValue(item.InstanceID.ToString(), out var itemCtrl) && itemCtrl != null)
                {
                    if (DoesControllerContainItemRecursive(itemCtrl, targetId)) return true;
                }
                else
                {
                    if (item.ContainsDescendant(targetId)) return true;
                }
            }

            // ═══ ПРОВЕРКА 2: target содержит item ═══
            // ═══════════════════════════════════════════════════════════════
            // ФИКС БАГ (матрёшка): Раньше эта проверка блокировала ЛЮБОЙ
            // предмет, который уже находился внутри target (даже через
            // вложенный рюкзак). Например: C содержит D, D содержит X.
            // Перетаскивание X из D в C блокировалось, потому что
            // C.ContainsDescendant(X) == true (X внутри D, D внутри C).
            //
            // Но это НЕ циклическая ссылка! Это просто перемещение
            // предмета из вложенного рюкзака в родительский.
            //
            // Циклическая ссылка для НЕ-рюкзаков невозможна в принципе
            // (не-рюкзак не может содержать другой предмет).
            //
            // Для РЮКЗАКОВ: если item-рюкзак уже внутри target, и мы
            // хотим положить item в target — это тоже НЕ цикл (item
            // просто переместится из вложенного рюкзака в parent).
            // Цикл был бы только если target внутри item (проверка 1).
            //
            // ЕДИНСТВЕННЫЙ случай, когда target.ContainsDescendant(item)
            // должен блокировать: item == target (уже проверено выше).
            //
            // Поэтому: для НЕ-рюкзаков проверка 2 ПОЛНОСТЬЮ УБРАНА.
            // Для рюкзаков проверка 1 уже покрывает все случаи цикла.
            // ═══════════════════════════════════════════════════════════════

            return false;
        }
        private bool IsBackpackInContentsRecursive(List<SavedItem> contents, uint targetInstanceId)
        {
            return InventoryItem.ContainsDescendantRecursive(contents, targetInstanceId);
        }

        /// <summary>
        /// Находит, в какой сетке и на какой позиции лежит предмет.
        /// Возвращает (gridType, x, y) или (null, 0, 0) если не найден.
        /// </summary>


        private (GridType? gridType, int x, int y) FindItemLocation(InventoryItem item)
        {
            if (item == null) return (null, 0, 0);
            uint id = item.InstanceID;
            var grids = new (GridType type, InventoryController controller)[]
            {
        (GridType.Pockets, _pocketsController),
        (GridType.Pocket2, _pocket2Controller),
        (GridType.Backpack, _backpackController),
            };
            foreach (var (type, controller) in grids)
            {
                if (controller == null) continue;
                for (int y = 0; y < controller.Height; y++)
                    for (int x = 0; x < controller.Width; x++)
                    {
                        var atPos = controller.GetItemAt(x, y);
                        if (atPos != null && atPos.InstanceID == id) return (type, x, y);
                    }
            }
            // FIX баг3: ищем во ВСЕХ открытых окнах-контейнерах, а не только в активном.
            for (int i = 0; i < _openContainerWindows.Count; i++)
            {
                var w = _openContainerWindows[i];
                if (w == null || w.Controller == null) continue;
                var c = w.Controller;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var atPos = c.GetItemAt(x, y);
                        if (atPos != null && atPos.InstanceID == id) return (GridType.Container, x, y);
                    }
            }
            // v13: сетка окружения (лут) НЕ входит в _openContainerWindows —
            // проверяем её отдельно (во время лутания _activeContainerController
            // и есть контроллер лута). Тогда «Опустошить», fold и unfold работают
            // относительно контейнера, в котором лежит рюкзак, а не падают
            // в fallback «в инвентарь игрока».
            // v17: контроллер лута берём из _activeContainerController, а если он
            // null/протух — восстанавливаем из слотов окружения.
            if (_isLootingContainer)
            {
                var c = _activeContainerController != null ? _activeContainerController : GetLootControllerFromSlots();
                if (c != null)
                {
                    for (int y = 0; y < c.Height; y++)
                        for (int x = 0; x < c.Width; x++)
                        {
                            var atPos = c.GetItemAt(x, y);
                            if (atPos != null && atPos.InstanceID == id) return (GridType.Container, x, y);
                        }
                }
            }
            return (null, 0, 0);
        }

        private InventoryController FindControllerForItem(InventoryItem item)
        {
            if (item == null) return null;
            uint id = item.InstanceID;
            var players = new[] { _pocketsController, _pocket2Controller, _backpackController };
            foreach (var c in players)
            {
                if (c == null) continue;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var at = c.GetItemAt(x, y);
                        if (at != null && at.InstanceID == id) return c;
                    }
            }
            foreach (var w in _openContainerWindows)
            {
                var c = w?.Controller;
                if (c == null) continue;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var at = c.GetItemAt(x, y);
                        if (at != null && at.InstanceID == id) return c;
                    }
            }
            // ═══ ФИКС БАГ 2 (v18): ищем также в контроллере ЛУТА (сетка окружения).
            // Без этого CanUnfoldInCurrentGrid / HandleInventoryBackpackFold получали
            // null для рюкзака, лежащего в луте → «Развернуть» не работало. ═══
            if (_isLootingContainer)
            {
                var c = _activeContainerController != null ? _activeContainerController : GetLootControllerFromSlots();
                if (c != null)
                {
                    for (int y = 0; y < c.Height; y++)
                        for (int x = 0; x < c.Width; x++)
                        {
                            var at = c.GetItemAt(x, y);
                            if (at != null && at.InstanceID == id) return c;
                        }
                }
            }
            return null;
        }
        private bool IsWindowAncestorOfRecursive(
            InventoryController potentialAncestorCtrl,
            string descendantBackpackId,
            int depth = 0)
        {
            if (potentialAncestorCtrl == null || string.IsNullOrEmpty(descendantBackpackId) || depth > 16)
                return false;

            for (int y = 0; y < potentialAncestorCtrl.Height; y++)
            {
                for (int x = 0; x < potentialAncestorCtrl.Width; x++)
                {
                    var item = potentialAncestorCtrl.GetItemAt(x, y);
                    if (item == null) continue;

                    // Прямое совпадение: рюкзак-потомок лежит прямо в этом контроллере
                    if (item.InstanceID.ToString() == descendantBackpackId)
                        return true;

                    // Рекурсия: если item — рюкзак, и он открыт как окно,
                    // проверяем его контроллер
                    if (item.Data != null && item.Data.IsBackpack)
                    {
                        string itemIdStr = item.InstanceID.ToString();
                        var innerWindow = _openContainerWindows.Find(
                            w => w != null && w.BackpackInstanceID == itemIdStr);
                        if (innerWindow != null && innerWindow.Controller != null)
                        {
                            if (IsWindowAncestorOfRecursive(
                                innerWindow.Controller, descendantBackpackId, depth + 1))
                                return true;
                        }
                        // Если окно не открыто, проверяем сериализованные данные
                        else if (item.ContainsDescendant(uint.Parse(descendantBackpackId)))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// ФИКС БАГ 2+3: Проверяет, содержит ли контроллер рюкзак с указанным InstanceID.
        /// </summary>
        private bool DoesControllerContainBackpack(InventoryController ctrl, string backpackInstanceId)
        {
            if (ctrl == null || string.IsNullOrEmpty(backpackInstanceId)) return false;
            for (int y = 0; y < ctrl.Height; y++)
                for (int x = 0; x < ctrl.Width; x++)
                {
                    var item = ctrl.GetItemAt(x, y);
                    if (item != null && item.InstanceID.ToString() == backpackInstanceId)
                        return true;
                }
            return false;
        }
        #endregion

        #region Backpack As Container

        /// <summary>
        /// Открывает рюкзак как контейнер (аналогично лутбоксу).
        /// Используется когда рюкзак НЕ надет (лежит в кармане/другом рюкзаке/контейнере),
        /// но развёрнут — игрок хочет положить в него предметы.
        ///
        /// Создаёт InventoryController, инициализированный из
        /// item._backpackContentsSerialized, и передаёт его в OpenContainer().
        /// </summary>
        public void OpenBackpackAsContainer(InventoryItem backpackItem)
        {
            if (backpackItem == null || !backpackItem.Data.IsBackpack) return;
            if (backpackItem.IsFolded && !backpackItem.Data.AlwaysShowGrid) return;
            int w = backpackItem.Data.BackpackWidth, h = backpackItem.Data.BackpackHeight;
            if (w <= 0 || h <= 0 || _slotPrefab == null) return;
            string idStr = backpackItem.InstanceID.ToString();

            // Уже открыто (активно или в фоне)? Активируем; если активно — закрываем (toggle).
            var existing = _openContainerWindows.Find(x => x != null && x.BackpackInstanceID == idStr);
            if (existing != null)
            {
                if (_activeContainerWindow == existing) { CloseBackpackAsContainer(); return; }
                ActivateContainerWindow(existing);
                _activeBackpackContainer = backpackItem;
                return;
            }



            InventoryController controller;
            if (_openedBackpacks.TryGetValue(idStr, out var existingCtrl)) controller = existingCtrl;
            else
            {
                var db = K_InventorySetup.DatabaseInstance;
                if (db == null) return;
                var data = new InventoryData(w, h);
                var savedItems = backpackItem.GetBackpackSavedItems();
                if (savedItems != null) foreach (var s in savedItems) data.AddItem(s);
                controller = new InventoryController(data, db, $"Backpack_{backpackItem.InstanceID}");
                _openedBackpacks[idStr] = controller;
            }
            _activeBackpackContainer = backpackItem;
            _openingBackpackContainer = true;
            var window = CreateContainerWindow(controller, idStr, backpackItem.Data.DisplayName, w, h);
            if (window == null) { _openingBackpackContainer = false; return; }
            ActivateContainerWindow(window);
            _openingBackpackContainer = false;

            SetCanvasActive(true);
            _isOpen = true;
            if (_backpackPanel != null) _backpackPanel.SetActive(true);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
            ForceRefresh();
            Debug.Log($"[MULTI-WIN] Opened '{backpackItem.Data.DisplayName}' as window #{_openContainerWindows.Count}");
        }

        /// <summary>
        /// Проверяет, открыто ли окно-контейнер для данного рюкзака.
        /// Используется K_ContextMenu для показа "Закрыть" вместо "Открыть".
        /// </summary>
        public bool IsBackpackWindowOpen(InventoryItem item)
        {
            if (item == null) return false;
            string idStr = item.InstanceID.ToString();
            return _openContainerWindows.Exists(w => w != null && w.BackpackInstanceID == idStr);
        }

        /// <summary>
        /// Закрывает окно-контейнер для данного рюкзака (по item, не по instanceID).
        /// Вызывается из K_ContextMenu.HandleCloseBackpack.
        /// </summary>
        public void CloseBackpackWindowByItem(InventoryItem item)
        {
            if (item == null) return;
            string idStr = item.InstanceID.ToString();
            CloseSpecificBackpackWindow(idStr);
            RestoreLootControllerIfLooting();
        }
        // >>> FIX: показ инвентаря вынесен (используется мультиоконным открытием) <<<
        private void EnsureInventoryVisible()
        {
            SetCanvasActive(true);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(true);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
            if (_inventoryContentPane != null) _inventoryContentPane.SetActive(_activeTab == 0);
            _isOpen = true;
        }
        // >>> END FIX <<<


        /// <summary>
        /// ФИКС: Раньше гарантировала наличие DragZone на _surroundingsPanel.
        /// Сейчас режим переключён на "drag from anywhere" — DragZone НЕ нужна.
        /// Метод оставлен как no-op для обратной совместимости со старыми вызовами.
        /// </summary>
        private void EnsureDragZoneExists()
        {
            if (_surroundingsPanel == null) return;
            if (_surroundingsPanel.transform.Find("DragZone") != null) return;
            float h = _containerHeaderHeight > 0f ? _containerHeaderHeight : 30f;
            var dzObj = new GameObject("DragZone", typeof(RectTransform), typeof(Image));
            dzObj.transform.SetParent(_surroundingsPanel.transform, false);
            dzObj.transform.SetAsFirstSibling();
            var dzRT = dzObj.GetComponent<RectTransform>();
            dzRT.anchorMin = new Vector2(0f, 1f); dzRT.anchorMax = new Vector2(1f, 1f);
            dzRT.pivot = new Vector2(0.5f, 1f); dzRT.anchoredPosition = Vector2.zero;
            dzRT.sizeDelta = new Vector2(0f, h); dzRT.localScale = Vector3.one;
            dzObj.AddComponent<LayoutElement>().ignoreLayout = true;
            var dzImg = dzObj.GetComponent<Image>();
            dzImg.color = new Color(0.24f, 0.26f, 0.30f, 0.98f); // контраст вместо сливающегося 0.12
            dzImg.raycastTarget = true;
            var lineObj = new GameObject("HeaderBottomLine", typeof(RectTransform), typeof(Image));
            lineObj.transform.SetParent(dzObj.transform, false);
            var lineRT = lineObj.GetComponent<RectTransform>();
            lineRT.anchorMin = new Vector2(0f, 0f); lineRT.anchorMax = new Vector2(1f, 0f);
            lineRT.pivot = new Vector2(0.5f, 0f); lineRT.anchoredPosition = Vector2.zero;
            lineRT.sizeDelta = new Vector2(0f, 1f); lineRT.localScale = Vector3.one;
            var lineImg = lineObj.GetComponent<Image>();
            lineImg.color = new Color(0.45f, 0.47f, 0.52f, 1f); lineImg.raycastTarget = false;
            if (_containerNameText != null)
            {
                var nameObj = new GameObject("WindowTitle", typeof(RectTransform));
                nameObj.transform.SetParent(dzObj.transform, false);
                var nameRT = nameObj.GetComponent<RectTransform>();
                nameRT.anchorMin = Vector2.zero; nameRT.anchorMax = Vector2.one;
                nameRT.pivot = new Vector2(0.5f, 0.5f);
                nameRT.offsetMin = new Vector2(8f, 0f); nameRT.offsetMax = new Vector2(-8f, 0f);
                nameRT.localScale = Vector3.one;
                var nameText = nameObj.AddComponent<TextMeshProUGUI>();
                nameText.text = _containerNameText.text;
                nameText.alignment = TMPro.TextAlignmentOptions.Center;
                nameText.verticalAlignment = TMPro.VerticalAlignmentOptions.Middle;
                nameText.fontSize = 14f; nameText.fontStyle = TMPro.FontStyles.Bold;
                nameText.color = new Color(0.92f, 0.92f, 0.95f, 1f);
                nameText.raycastTarget = false;
                nameText.overflowMode = TMPro.TextOverflowModes.Truncate;
                nameText.textWrappingMode = TMPro.TextWrappingModes.NoWrap;
            }
        }

        /// <summary>
        /// ФИКС V13 + БАГ #3: Добавляет K_DraggablePanel на _surroundingsPanel чтобы
        /// пользователь мог перетаскивать сетку рюкзака по экрану.
        ///
        /// ФИКС БАГ #3: Создаёт ЯВНУЮ зону-заголовок (DragZone) на панели
        /// контейнера, за которую можно перетащить панель. Без явной зоны
        /// перетаскивание было невозможно, т.к. все клики перехватывались
        /// слотами и предметами.
        ///
        /// ФИЧА #2 ФИКС: Теперь использует _containerHeaderPrefab из Инспектора,
        /// если он задан. Если null — fallback к программной генерации с
        /// _containerHeaderHeight/Color.
        ///
        /// ФИЧА #3: После настройки вызывается draggable.BringToFront() чтобы
        /// окно оказалось поверх других открытых окон (фокус при открытии).
        /// </summary>
        private void EnableDraggableSurroundingsPanel()
        {
            if (_surroundingsPanel == null || _surroundingsGrid == null)
            {
                Debug.LogWarning("[V13-DRAG] Cannot enable draggable: _surroundingsPanel or _surroundingsGrid is null");
                return;
            }

            try
            {
                // ═══ Иерархия и размеры УЖЕ настроены в SetupSurroundingsPanelHierarchy().
                //    Здесь только настраиваем K_DraggablePanel.
                //
                // Цепочка raycast при клике на пустую ячейку:
                //   слот (raycastTarget=false) → пропускает →
                //   грид Image (raycastTarget=true) → ловит →
                //   ExecuteEvents.ExecuteHierarchy: грид (нет IPointerDownHandler) →
                //   панель (K_DraggablePanel.IPointerDownHandler) → OnPointerDown → drag!
                //
                // При клике на предмет:
                //   UI_Item (raycastTarget=true) → перехватывает →
                //   панель НЕ получает событие → предмет тащится, панель стоит.

                // K_DraggablePanel на панели (если нет — добавляем).
                var draggable = _surroundingsPanel.GetComponent<K_DraggablePanel>();
                if (draggable == null)
                {
                    draggable = _surroundingsPanel.AddComponent<K_DraggablePanel>();
                    Debug.Log("[V13-DRAG] Added K_DraggablePanel to _surroundingsPanel");
                }
                else
                {
                    Debug.Log("[V13-DRAG] Reusing existing K_DraggablePanel on _surroundingsPanel");
                }

                // Отключаем авто-создание DragZone — работаем в режиме "drag from anywhere".
                SetPrivateField(draggable, "_autoCreateHeader", false);
                SetPrivateField(draggable, "_dragFromAnywhere", true);
                SetPrivateField(draggable, "_headerCreatedInternally", false);
                draggable.SetDragZone(null);
                draggable.FindDragZone();

                // НЕ трогаем Image панели и грида! SetupSurroundingsPanelHierarchy()
                // уже правильно выставил: панель raycastTarget=false, грид raycastTarget=true.
                // НЕ удаляем DragZone — он нужен как визуальный хедер и его высота
                // уже учтена в размерах панели.

                draggable.BringToFront();

                Debug.Log("[V13-DRAG] Draggable panel enabled (hierarchy already set up by SetupSurroundingsPanelHierarchy).");
            }
            catch (System.Exception ex)
            {
                Debug.LogError($"[V13-DRAG] EnableDraggableSurroundingsPanel FAILED: {ex}");
            }
        }

        /// <summary>
        /// ФИКС v16 (ПОДХОД РАБОЧЕГО ИИ): Связывает Panel → Grid → ItemsContainer
        /// в единую иерархию с ОДИНАКОВЫМИ координатами и размером.
        ///
        /// КЛЮЧЕВАЯ ИДЕЯ (от рабочего ИИ):
        /// 1. СОХРАНЯЕМ мировую позицию top-left угла ГРИДА до репарентинга.
        /// 2. ВЫЧИСЛЯЕМ правильный размер из GridLayoutGroup (cellSize × cols/rows + spacing + padding).
        /// 3. SetParent(panel, false) — грид становится ребёнком панели.
        /// 4. Устанавливаем грид: anchor/pivot=(0,1) top-left, pos=(0,0), size=gridSize.
        /// 5. ItemsContainer → ребёнок грида, те же настройки.
        /// 6. ДВИГАЕМ ПАНЕЛЬ к сохранённому top-left углу грида (а НЕ наоборот!).
        ///    Это гарантирует, что панель окажется ровно там, где был грид.
        ///
        /// Почему так: SetParent(panel, false) сбрасывает локальную позицию грида
        /// в (0,0). Если панель была на (503, 18), то грид "прыгает" на (503, 18).
        /// Чтобы это исправить — после репарентинга мы вычисляем позицию панели
        /// так, чтобы её top-left совпал с сохранённым top-left грида.
        /// </summary>
        private void LinkSurroundingsHierarchy()
        {
            if (_surroundingsPanel == null || _surroundingsGrid == null) return;

            var panelRT = _surroundingsPanel.GetComponent<RectTransform>();
            var gridRT = _surroundingsGrid.GetComponent<RectTransform>();
            if (panelRT == null || gridRT == null) return;

            // 1. СОХРАНЯЕМ мировую позицию top-left угла ГРИДА до репарентинга.
            //    GetWorldCorners возвращает 4 угла: [0]=bottom-left, [1]=top-left,
            //    [2]=top-right, [3]=bottom-right.
            Vector3[] gridCorners = new Vector3[4];
            gridRT.GetWorldCorners(gridCorners);
            Vector3 savedWorldTopLeft = gridCorners[1]; // top-left

            // 2. ВЫЧИСЛЯЕМ правильный размер грида из GridLayoutGroup.
            //    (НЕ берём gridRT.rect.size — он может быть испорчен прошлыми запусками.)
            Vector2 gridSize = ComputeGridSize(gridRT);
            if (gridSize.x <= 0f || gridSize.y <= 0f)
            {
                gridSize = new Vector2(gridRT.rect.width, gridRT.rect.height);
                Debug.LogWarning($"[PANEL-SETUP] ComputeGridSize returned 0 — using grid.rect.size={gridSize}");
            }

            // 3. Репарентим грид в панель (worldPositionStays=false).
            if (gridRT.parent != panelRT)
                gridRT.SetParent(panelRT, false);

            // 4. Грид: top-left anchor/pivot, pos=(0,0), size=gridSize.
            //    Anchor/pivot=(0,1) значит top-left. anchoredPosition=zero в такой
            //    конфигурации помещает top-left угол грида точно в top-left угол панели.
            gridRT.anchorMin = new Vector2(0f, 1f);
            gridRT.anchorMax = new Vector2(0f, 1f);
            gridRT.pivot = new Vector2(0f, 1f);
            gridRT.anchoredPosition = Vector2.zero;
            gridRT.sizeDelta = gridSize;
            gridRT.localScale = Vector3.one;

            // Игнорируем layout, чтобы родительский LayoutGroup не двигал грид.
            var gridLe = gridRT.GetComponent<LayoutElement>();
            if (gridLe == null) gridLe = gridRT.gameObject.AddComponent<LayoutElement>();
            gridLe.ignoreLayout = true;

            // Грид — последний sibling (поверх других детей панели, если есть).
            gridRT.SetAsLastSibling();

            // 5. ItemsContainer → ребёнок грида.
            if (_surroundingsItemsContainer != null)
            {
                var itemsRT = _surroundingsItemsContainer.GetComponent<RectTransform>();
                if (itemsRT != null)
                {
                    if (_surroundingsItemsContainer.parent != gridRT)
                        _surroundingsItemsContainer.SetParent(gridRT, false);
                    _surroundingsItemsContainer.SetAsLastSibling();

                    itemsRT.anchorMin = new Vector2(0f, 1f);
                    itemsRT.anchorMax = new Vector2(0f, 1f);
                    itemsRT.pivot = new Vector2(0f, 1f);
                    itemsRT.anchoredPosition = Vector2.zero;
                    itemsRT.sizeDelta = gridSize;
                    itemsRT.localScale = Vector3.one;

                    var icLe = _surroundingsItemsContainer.GetComponent<LayoutElement>();
                    if (icLe == null) icLe = _surroundingsItemsContainer.gameObject.AddComponent<LayoutElement>();
                    icLe.ignoreLayout = true;

                    var icGraphic = _surroundingsItemsContainer.GetComponent<Graphic>();
                    if (icGraphic != null) icGraphic.raycastTarget = false;
                }
            }

            // 6. ДВИГАЕМ ПАНЕЛЬ к сохранённому top-left углу грида.
            //    У панели будет pivot=(0,1) top-left, anchor=(0,1).
            //    Тогда anchoredPosition=localTL помещает top-left угол панели в
            //    savedWorldTopLeft — то есть ровно туда, где был грид.
            panelRT.anchorMin = new Vector2(0f, 1f);
            panelRT.anchorMax = new Vector2(0f, 1f);
            panelRT.pivot = new Vector2(0f, 1f);
            panelRT.sizeDelta = gridSize;
            panelRT.localScale = Vector3.one;

            if (panelRT.parent != null)
            {
                Vector2 localTL = panelRT.parent.InverseTransformPoint(savedWorldTopLeft);
                RectTransform parentRT = panelRT.parent as RectTransform;
                if (parentRT != null)
                    localTL -= new Vector2(parentRT.rect.xMin, parentRT.rect.yMax);
                panelRT.anchoredPosition = localTL;
            }

            Debug.Log($"[PANEL-SETUP] Grid size calculated: {gridSize.x:F0}x{gridSize.y:F0}, " +
                      $"Panel.pos={panelRT.anchoredPosition}, " +
                      $"Panel.size={panelRT.sizeDelta}, " +
                      $"Grid.parent={gridRT.parent?.name}, " +
                      $"ItemsContainer.parent={_surroundingsItemsContainer?.parent?.name}");
        }

        /// <summary>
        /// Вычисляет размер грида на основе GridLayoutGroup (cellSize × cols/rows + padding + spacing).
        /// Fallback на _slotSize × _currentContainerCols/Rows если GridLayoutGroup нет.
        /// </summary>
        private Vector2 ComputeGridSize(RectTransform gridRT)
        {
            float w = 0f, h = 0f;
            var gridLayout = gridRT.GetComponent<GridLayoutGroup>();
            if (gridLayout != null && _currentContainerCols > 0 && _currentContainerRows > 0)
            {
                int cols = _currentContainerCols;
                int rows = _currentContainerRows;
                float cellW = gridLayout.cellSize.x;
                float cellH = gridLayout.cellSize.y;
                float spaceX = gridLayout.spacing.x;
                float spaceY = gridLayout.spacing.y;
                w = gridLayout.padding.left + cols * cellW + Mathf.Max(0, cols - 1) * spaceX + gridLayout.padding.right;
                h = gridLayout.padding.top + rows * cellH + Mathf.Max(0, rows - 1) * spaceY + gridLayout.padding.bottom;
            }
            if (w <= 0f && _currentContainerCols > 0)
            {
                w = _currentContainerCols * _slotSize + Mathf.Max(0, _currentContainerCols - 1) * _slotSpacing;
                h = _currentContainerRows * _slotSize + Mathf.Max(0, _currentContainerRows - 1) * _slotSpacing;
            }
            if (w <= 0f) w = gridRT.rect.width;
            if (h <= 0f) h = gridRT.rect.height;
            return new Vector2(w, h);
        }

        /// <summary>
        /// ФИКС: Программно выравнивает _surroundingsPanel ТОЧНО по _surroundingsGrid
        /// (top-left = top-left, size = size грида). Без добавления headerHeight.
        /// Используется когда панель работает в режиме "drag from anywhere" без
        /// явной DragZone — тогда панель должна полностью совпадать с гридом.
        /// </summary>
        private void AlignPanelToGridExact()
        {
            if (_surroundingsPanel == null || _surroundingsGrid == null) return;

            var panelRT = _surroundingsPanel.GetComponent<RectTransform>();
            var gridRT = _surroundingsGrid.GetComponent<RectTransform>();
            if (panelRT == null || gridRT == null) return;

            // Сохраняем мировую позицию top-left угла грида.
            Vector3[] corners = new Vector3[4];
            gridRT.GetWorldCorners(corners);
            Vector3 savedWorldTopLeft = corners[1]; // top-left
            Vector3 savedWorldBottomRight = corners[3]; // bottom-right
            Vector2 worldSize = new Vector2(
                savedWorldBottomRight.x - savedWorldTopLeft.x,
                savedWorldTopLeft.y - savedWorldBottomRight.y);

            // Репарентим грид в панель (если ещё не там) — панель должна
            // двигать грид как дочерний. WorldPositionStays=false, потому что
            // мы вручную восстановим позицию после SetParent.
            if (gridRT.parent != panelRT)
            {
                gridRT.SetParent(panelRT, false);
            }

            // Настраиваем грид: top-left anchor/pivot, position=(0,0), size=worldSize.
            // В локальных координатах панели (с pivot панели (0,1) top-left)
            // это поместит top-left грида точно в top-left панели.
            gridRT.anchorMin = new Vector2(0f, 1f);
            gridRT.anchorMax = new Vector2(0f, 1f);
            gridRT.pivot = new Vector2(0f, 1f);
            gridRT.anchoredPosition = Vector2.zero;
            gridRT.sizeDelta = worldSize;
            gridRT.localScale = Vector3.one;

            // Игнорируем layout, чтобы GridLayoutGroup не пытался управлять позицией.
            var gridLe = gridRT.GetComponent<LayoutElement>();
            if (gridLe == null) gridLe = gridRT.gameObject.AddComponent<LayoutElement>();
            gridLe.ignoreLayout = true;

            // Грид должен быть последним sibling (поверх DragZone/хедера, если есть).
            gridRT.SetAsLastSibling();

            // Настраиваем панель: top-left pivot, размер = размер грида (БЕЗ headerHeight).
            // Восстанавливаем мировую позицию top-left угла.
            panelRT.anchorMin = new Vector2(0f, 1f);
            panelRT.anchorMax = new Vector2(0f, 1f);
            panelRT.pivot = new Vector2(0f, 1f);
            panelRT.sizeDelta = worldSize;

            if (panelRT.parent != null)
            {
                Vector2 localTL = panelRT.parent.InverseTransformPoint(savedWorldTopLeft);
                RectTransform parentRT = panelRT.parent as RectTransform;
                if (parentRT != null)
                    localTL -= new Vector2(parentRT.rect.xMin, parentRT.rect.yMax);
                panelRT.anchoredPosition = localTL;
            }
            panelRT.localScale = Vector3.one;

            // itemsContainer — внутри грида, ignoreLayout, без raycast.
            if (_surroundingsItemsContainer != null)
            {
                if (_surroundingsItemsContainer.parent != gridRT)
                    _surroundingsItemsContainer.SetParent(gridRT, false);
                _surroundingsItemsContainer.SetAsLastSibling();

                var icLe = _surroundingsItemsContainer.GetComponent<LayoutElement>();
                if (icLe == null) icLe = _surroundingsItemsContainer.gameObject.AddComponent<LayoutElement>();
                icLe.ignoreLayout = true;

                var icGraphic = _surroundingsItemsContainer.GetComponent<Graphic>();
                if (icGraphic != null) icGraphic.raycastTarget = false;
            }

            Debug.Log($"[V13-DRAG] Panel aligned to grid exactly: " +
                      $"size={worldSize.x:F0}x{worldSize.y:F0}, " +
                      $"panel.pos={panelRT.anchoredPosition}, grid.pos={gridRT.anchoredPosition}");
        }

        /// <summary>
        /// ФИЧА #2: Маркер для программно созданного заголовка.
        /// </summary>
        private class ProgrammaticHeaderMarker : MonoBehaviour
        {
        }

        /// <summary>
        /// ФИЧА #2: Превращает _surroundingsPanel в плавающее окно.
        /// Репарентим панель в root canvas (чтобы она могла двигаться по всему экрану),
        /// центрируем на экране, и настраивает anchors/pivot для свободного перемещения.
        ///
        /// Вызывается при открытии рюкзака как контейнера (не для обычного лутания ящиков).
        /// </summary>
        private void DetachPanelAsFloatingWindow()
        {
            if (_surroundingsPanel == null) return;
            var panelRect = _surroundingsPanel.GetComponent<RectTransform>();
            if (panelRect == null) return;

            // Находим root canvas от самой панели (а не от K_InventoryUI).
            Canvas rootCanvas = null;
            var c = _surroundingsPanel.GetComponentInParent<Canvas>();
            while (c != null)
            {
                if (c.transform.parent == null || c.transform.parent.GetComponent<Canvas>() == null)
                {
                    rootCanvas = c;
                    break;
                }
                c = c.transform.parent.GetComponent<Canvas>();
            }
            if (rootCanvas == null)
            {
                Debug.LogWarning("[V13-DRAG] DetachPanelAsFloatingWindow: root canvas not found.");
                return;
            }

            // Репарентим панель в root canvas (если ещё не там).
            if (panelRect.parent != rootCanvas.transform)
            {
                panelRect.SetParent(rootCanvas.transform, false);
                Debug.Log($"[V13-DRAG] Reparented panel to root canvas '{rootCanvas.name}'.");
            }

            // Центрируем на экране.
            panelRect.anchorMin = new Vector2(0.5f, 0.5f);
            panelRect.anchorMax = new Vector2(0.5f, 0.5f);
            panelRect.pivot = new Vector2(0.5f, 0.5f);
            panelRect.anchoredPosition = Vector2.zero;

            Debug.Log($"[V13-DRAG] Panel detached as floating window. " +
                      $"Canvas={rootCanvas.name}, panel size={panelRect.rect.size}");
        }

        /// <summary>
        /// ФИЧА #2: Копирует настройки header из K_InventoryUI в K_DraggablePanel.
        /// Использует SerializedField-доступ через reflection, т.к. поля приватные.
        /// Альтернатива — сделать поля публичными, но это сломает инкапсуляцию.
        /// </summary>
        private void SyncDraggablePanelHeaderSettings(K_DraggablePanel draggable)
        {
            if (draggable == null) return;
            try
            {
#if UNITY_EDITOR
                var so = new UnityEditor.SerializedObject(draggable);
                if (_containerHeaderPrefab != null)
                {
                    var prefabProp = so.FindProperty("_headerPrefab");
                    if (prefabProp != null)
                        prefabProp.objectReferenceValue = _containerHeaderPrefab;
                }
                var heightProp = so.FindProperty("_headerHeight");
                if (heightProp != null)
                    heightProp.floatValue = _containerHeaderHeight;
                var colorProp = so.FindProperty("_headerColor");
                if (colorProp != null)
                    colorProp.colorValue = _containerHeaderColor;
                so.ApplyModifiedPropertiesWithoutUndo();
#else
                SetPrivateField(draggable, "_headerPrefab", _containerHeaderPrefab);
                SetPrivateField(draggable, "_headerHeight", _containerHeaderHeight);
                SetPrivateField(draggable, "_headerColor", _containerHeaderColor);
#endif
            }
            catch (System.Exception ex)
            {
                Debug.LogWarning($"[FICHA2] SyncDraggablePanelHeaderSettings failed: {ex.Message}");
            }
        }

        private static void SetPrivateField(object target, string fieldName, object value)
        {
            if (target == null) return;
            var field = target.GetType().GetField(fieldName,
                System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            if (field != null)
                field.SetValue(target, value);
        }

        /// <summary>
        /// ФИЧА #2: Находит TextMeshProUGUI в DragZone (внутри K_DraggablePanel)
        /// и устанавливает текст названия контейнера.
        /// </summary>
        private void SetContainerHeaderText(K_DraggablePanel draggable, string text)
        {
            if (draggable == null) return;
            var dragZone = draggable.transform.Find("DragZone");
            if (dragZone == null) return;
            var tmp = dragZone.GetComponentInChildren<TMPro.TextMeshProUGUI>();
            if (tmp != null)
                tmp.text = text;
        }

        /// <summary>
        /// Закрывает рюкзак-контейнер: синхронизирует содержимое обратно в
        /// InventoryItem._backpackContentsSerialized и освобождает контроллер.
        ///
        /// ФИКС V13: Больше НЕ вызывает CloseAll() — это закрывало ВЕСЬ инвентарь.
        /// Теперь закрывает ТОЛЬКО _surroundingsPanel (панель контейнера рюкзака),
        /// сохраняя основной инвентарь открытым.
        /// </summary>
        public void CloseBackpackAsContainer()
        {
            if (_activeContainerWindow != null)
            {
                // Мультиоконное закрытие: синхронизация + dispose + активация фонового (если есть).
                CloseSpecificBackpackWindow(_activeContainerWindow.BackpackInstanceID);
                return;
            }
            // Fallback на случай рассинхрона (окон нет, но _activeBackpackContainer задан).
            if (_activeBackpackContainer == null) return;
            var backpackItem = _activeBackpackContainer;
            var instanceIdStr = backpackItem.InstanceID.ToString();
            if (_openedBackpacks.TryGetValue(instanceIdStr, out var controller))
            {
                var savedItems = controller.GetSaveData()?.GetItems();
                backpackItem.ReplaceBackpackContents(savedItems);
                controller.Dispose();
                _openedBackpacks.Remove(instanceIdStr);
            }
            _activeBackpackContainer = null;
            _activeContainerController = null;
            _currentContainerCols = 0;
            _currentContainerRows = 0;
            _isLootingContainer = false;
            UnsubscribeFromContainerEvents();
            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
            ForceRefresh();
        }
        /// <summary>
        /// Закрывает ВСЕ окна-контейнеры, связанные с указанным рюкзаком.
        ///
        /// ФИКС БАГ 2+3: НЕ сохраняет содержимое вручную — это делает
        /// DestroyContainerWindow через ToSaveData (актуальные данные).
        /// Каскадное закрытие потомков тоже внутри DestroyContainerWindow.
        /// </summary>
        private void CloseAllWindowsForBackpack(InventoryItem backpackItem)
        {
            if (backpackItem == null) return;
            string idStr = backpackItem.InstanceID.ToString();

            // Копируем список, т.к. DestroyContainerWindow модифицирует _openContainerWindows
            var windowsToClose = _openContainerWindows.FindAll(
                w => w != null && w.BackpackInstanceID == idStr);

            foreach (var window in windowsToClose)
            {
                // Защита: окно могло быть уничтожено каскадно (если оно дочернее
                // для другого окна в этом же списке)
                if (window == null || !_openContainerWindows.Contains(window))
                    continue;

                // DestroyContainerWindow сам:
                //   1. Каскадно закроет дочерние окна
                //   2. Сохранит содержимое через ToSaveData
                //   3. Dispose'ит контроллер
                //   4. Уничтожит gameObject
                DestroyContainerWindow(window);
            }

            // Удаляем из кэша (если ещё не удалён в DestroyContainerWindow)
            if (_openedBackpacks.TryGetValue(idStr, out var ctrl))
            {
                ctrl.Dispose();
                _openedBackpacks.Remove(idStr);
            }

            if (_activeBackpackContainer != null &&
    _activeBackpackContainer.InstanceID.ToString() == idStr)
            {
                _activeBackpackContainer = null;
                // v13: во время лутания _activeContainerController — это контроллер ЛУТА,
                // а не окна рюкзака. Не сбрасываем его, иначе сетка окружения
                // (и иконки рюкзаков в ней) «исчезает» после закрытия окна рюкзака.
                if (!_isLootingContainer)
                {
                    _activeContainerController = null;
                    _currentContainerCols = 0;
                    _currentContainerRows = 0;
                    UnsubscribeFromContainerEvents();
                }
            }

            // Если активное окно было уничтожено — сбрасываем
            if (_activeContainerWindow != null &&
                !_openContainerWindows.Contains(_activeContainerWindow))
            {
                _activeContainerWindow = null;
                _surroundingsPanel = _originalSurroundingsPanel;
                _surroundingsGrid = _originalSurroundingsGrid;
                _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
            }
            // БАГ-ФИКС: если активное окно закрылось, а другие окна остались открытыми —
            // активируем последнее оставшееся. Иначе _activeContainerController остаётся
            // null (CanUnfoldInCurrentGrid и др. ломаются).
            if (_activeContainerWindow == null && _openContainerWindows.Count > 0)
            {
                var last = _openContainerWindows[_openContainerWindows.Count - 1];
                ActivateContainerWindow(last);
                if (_activeBackpackContainer == null)
                    _activeBackpackContainer = FindBackpackItemByID(last.BackpackInstanceID);
            }
        }
        /// <summary>
        /// v15: После закрытия окна рюкзака ВО ВРЕМЯ ЛУТАНИЯ в _activeContainerController
        /// может остаться disposed-контроллер закрытого окна (Assert "null _data") или null —
        /// сетка окружения «исчезает», драг сыплет Assert'ами.
        /// Восстанавливаем контроллер лута из BoundController слотов окружения
        /// (слоты лута живут в _originalSurroundingsItemsContainer и переживают окна).
        /// </summary>
        private void RestoreLootControllerIfLooting()
        {
            if (!_isLootingContainer) return;
            if (_originalSurroundingsItemsContainer == null) return;

            var slots = _originalSurroundingsItemsContainer.GetComponentsInChildren<K_InventorySlotUI>(true);
            if (slots == null) return;
            foreach (var s in slots)
            {
                if (s != null && s.BoundController != null)
                {
                    _activeContainerController = s.BoundController;
                    if (_currentContainerCols <= 0) _currentContainerCols = s.BoundController.Width;
                    if (_currentContainerRows <= 0) _currentContainerRows = s.BoundController.Height;
                    break;
                }
            }
        }

        /// <summary>
        /// v17: Контроллер лута из BoundController слотов окружения.
        /// Работает даже когда _activeContainerController null/не лут
        /// (лут не входит в _openContainerWindows).
        /// </summary>
        private InventoryController GetLootControllerFromSlots()
        {
            if (_originalSurroundingsItemsContainer == null) return null;
            var slots = _originalSurroundingsItemsContainer.GetComponentsInChildren<K_InventorySlotUI>(true);
            if (slots == null) return null;
            foreach (var s in slots)
                if (s != null && s.BoundController != null)
                    return s.BoundController;
            return null;
        }
        /// <summary>
        /// Закрывает окно конкретного рюкзака по InstanceID.
        /// Мультиоконная версия CloseBackpackAsContainer.
        ///
        /// ФИКС БАГ 2: DestroyContainerWindow каскадно закроет все дочерние окна.
        /// </summary>
        public void CloseSpecificBackpackWindow(string instanceID)
        {
            var window = _openContainerWindows.Find(w => w != null && w.BackpackInstanceID == instanceID);
            if (window != null)
            {
                if (_activeContainerWindow == window)
                {
                    _activeContainerWindow = null;
                    // ═══ ФИКС БАГ 1 (v18): во время лутания _activeContainerController —
                    // это контроллер ЛУТА, а НЕ закрываемого окна. Сбрасываем ТОЛЬКО если не лутаем. ═══
                    if (!_isLootingContainer)
                    {
                        _activeContainerController = null;
                        _currentContainerCols = 0;
                        _currentContainerRows = 0;
                    }
                    _surroundingsPanel = _originalSurroundingsPanel;
                    _surroundingsGrid = _originalSurroundingsGrid;
                    _surroundingsItemsContainer = _originalSurroundingsItemsContainer;
                    // Ищем следующее окно для активации (НЕ дочернее закрываемого)
                    if (_openContainerWindows.Count > 1)
                    {
                        var nextWindow = _openContainerWindows.Find(
                            w => w != null && w != window
                            && !DoesControllerContainBackpack(window.Controller, w.BackpackInstanceID));
                        if (nextWindow != null)
                        {
                            ActivateContainerWindow(nextWindow);
                            var found = FindBackpackItemByID(nextWindow.BackpackInstanceID);
                            if (found == null && _backpackSlot != null
                                && _backpackSlot.EquippedItem != null
                                && _backpackSlot.EquippedItem.InstanceID.ToString() == nextWindow.BackpackInstanceID)
                            {
                                found = _backpackSlot.EquippedItem;
                            }
                            _activeBackpackContainer = found;
                        }
                    }
                }
                // Каскадное закрытие + сохранение через ToSaveData
                DestroyContainerWindow(window);
            }

            // v15: запоминаем, что шло лутание, ДО сброса флага ниже.
            bool wasLooting = _isLootingContainer;
            UnsubscribeFromContainerEvents();
            if (_openContainerWindows.Count == 0 && !wasLooting)
            {
                _isLootingContainer = false;
            }
            if (_activeBackpackContainer != null &&
                _activeBackpackContainer.InstanceID.ToString() == instanceID)
            {
                _activeBackpackContainer = null;
            }

            // ═══ ФИКС БАГ 3 (v19): ВО ВРЕМЯ ЛУТАНИЯ НЕ ДАЁМ контроллеру окна
            // затереть контроллер ЛУТА. Раньше ветка `if (_activeContainerWindow != null)`
            // ставила _activeContainerController = контроллер окна даже при лутании,
            // и сетка окружения рендерила чужое содержимое / пустоту — иконки лута «исчезали». ═══
            if (_activeContainerWindow != null)
            {
                if (!_isLootingContainer)
                    _activeContainerController = _activeContainerWindow.Controller;
                SubscribeToContainerEvents();
            }
            else if (wasLooting)
            {
                _isLootingContainer = true;
                RestoreLootControllerIfLooting();
                SubscribeToContainerEvents();
            }

            // ═══ ФИКС БАГ 3 (v19): страховка — если лутаем, а контроллер лута всё ещё
            // null (слоты перестроились и т.п.), восстанавливаем его принудительно. ═══
            if (_isLootingContainer && _activeContainerController == null)
            {
                _activeContainerController = GetLootControllerFromSlots();
                if (_activeContainerController != null)
                {
                    if (_currentContainerCols <= 0) _currentContainerCols = _activeContainerController.Width;
                    if (_currentContainerRows <= 0) _currentContainerRows = _activeContainerController.Height;
                    SubscribeToContainerEvents();
                }
            }
            ForceRefresh();
        }
        private InventoryItem FindBackpackItemByID(string instanceID)
        {
            // Слот экипировки — первым.
            if (_backpackSlot != null && _backpackSlot.EquippedItem != null
                && _backpackSlot.EquippedItem.InstanceID.ToString() == instanceID)
            {
                return _backpackSlot.EquippedItem;
            }

            // 1. Основные контроллеры игрока
            var controllers = new[] { _pocketsController, _pocket2Controller, _backpackController };
            foreach (var ctrl in controllers)
            {
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var item = ctrl.GetItemAt(x, y);
                        if (item != null && item.InstanceID.ToString() == instanceID)
                            return item;
                    }
            }

            // ═══ ФИКС БАГ 3 (v19): ищем в контроллере ЛУТА (сетка окружения).
            // Раньше рюкзак, лежащий в луте, не находился → DestroyContainerWindow
            // получал owner == null → содержимое матрёшки не синхронизировалось
            // в владельца (данные терялись), а закрытие работало «вслепую». ═══
            if (_isLootingContainer)
            {
                var lootCtrl = _activeContainerController != null
                    ? _activeContainerController
                    : GetLootControllerFromSlots();
                if (lootCtrl != null)
                {
                    for (int y = 0; y < lootCtrl.Height; y++)
                        for (int x = 0; x < lootCtrl.Width; x++)
                        {
                            var item = lootCtrl.GetItemAt(x, y);
                            if (item != null && item.InstanceID.ToString() == instanceID)
                                return item;
                        }
                }
            }

            // 2. Контроллеры открытых окон (рюкзаки внутри рюкзаков)
            foreach (var window in _openContainerWindows)
            {
                if (window == null || window.Controller == null) continue;
                var ctrl = window.Controller;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var item = ctrl.GetItemAt(x, y);
                        if (item != null && item.InstanceID.ToString() == instanceID)
                            return item;
                    }
            }

            // 3. Сериализованное содержимое рюкзаков (рекурсивно, для закрытых рюкзаков)
            foreach (var ctrl in controllers)
            {
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var item = ctrl.GetItemAt(x, y);
                        if (item != null && item.Data != null && item.Data.IsBackpack)
                        {
                            var found = FindInBackpackContentsRecursive(item, instanceID, 0);
                            if (found != null) return found;
                        }
                    }
            }

            // Сериализованное содержимое НАДЕТОГО рюкзака.
            if (_backpackSlot != null && _backpackSlot.EquippedItem != null
                && _backpackSlot.EquippedItem.Data != null
                && _backpackSlot.EquippedItem.Data.IsBackpack)
            {
                var found = FindInBackpackContentsRecursive(
                    _backpackSlot.EquippedItem, instanceID, 0);
                if (found != null) return found;
            }
            return null;
        }
        private InventoryItem FindInBackpackContentsRecursive(
            InventoryItem backpack, string targetInstanceID, int depth)
        {
            if (backpack == null || depth > 16) return null;

            var contents = backpack.GetBackpackSavedItems();
            if (contents == null || contents.Count == 0) return null;

            var db = K_InventorySetup.DatabaseInstance;
            if (db == null) return null;

            foreach (var saved in contents)
            {
                if (saved.InstanceID.ToString() == targetInstanceID)
                {
                    // ═══════════════════════════════════════════════════
                    // ФИКС: Сначала ищем РЕАЛЬНЫЙ объект в открытых окнах.
                    // Если рюкзак-родитель открыт как окно, его контроллер
                    // содержит реальный InventoryItem. Возвращаем его,
                    // а не создаём новый (который будет потерян).
                    // ═══════════════════════════════════════════════════
                    foreach (var window in _openContainerWindows)
                    {
                        if (window == null || window.Controller == null) continue;
                        var ctrl = window.Controller;
                        for (int y = 0; y < ctrl.Height; y++)
                            for (int x = 0; x < ctrl.Width; x++)
                            {
                                var item = ctrl.GetItemAt(x, y);
                                if (item != null && item.InstanceID.ToString() == targetInstanceID)
                                    return item; // РЕАЛЬНЫЙ объект из контроллера
                            }
                    }

                    // Также проверяем основные контроллеры
                    var controllers = new[] { _pocketsController, _pocket2Controller, _backpackController };
                    foreach (var ctrl in controllers)
                    {
                        if (ctrl == null) continue;
                        for (int y = 0; y < ctrl.Height; y++)
                            for (int x = 0; x < ctrl.Width; x++)
                            {
                                var item = ctrl.GetItemAt(x, y);
                                if (item != null && item.InstanceID.ToString() == targetInstanceID)
                                    return item;
                            }
                    }

                    // Fallback: создаём из SavedItem (для полностью закрытых рюкзаков)
                    var template = db.GetItemData(saved.ItemID);
                    if (template != null)
                        return InventoryItem.FromSaveData(saved, template);
                    return null;
                }

                // Рекурсия: если вложенный предмет — рюкзак, ищем внутри него
                if (saved.BackpackContents != null && saved.BackpackContents.Count > 0)
                {
                    var template = db.GetItemData(saved.ItemID);
                    if (template != null && template.IsBackpack)
                    {
                        var innerItem = InventoryItem.FromSaveData(saved, template);
                        if (innerItem != null)
                        {
                            var found = FindInBackpackContentsRecursive(
                                innerItem, targetInstanceID, depth + 1);
                            if (found != null) return found;
                        }
                    }
                }
            }

            return null;
        }
        private K_ContainerWindow FindOpenWindowContainingItem(InventoryItem item)
        {
            if (item == null) return null;
            uint id = item.InstanceID;
            for (int i = 0; i < _openContainerWindows.Count; i++)
            {
                var w = _openContainerWindows[i];
                if (w == null || w.Controller == null) continue;
                var c = w.Controller;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var it = c.GetItemAt(x, y);
                        if (it != null && it.InstanceID == id) return w;
                    }
            }
            return null;
        }
        // FIX баг2: глубина вложенности рюкзака по открытым окнам-предкам.
        // 0 = лежит в инвентаре/слоте/мире (не внутри открытого контейнера).
        private int GetBackpackNestingDepth(InventoryItem item)
        {
            int depth = 0;
            var cur = item;
            for (int guard = 0; guard < 16; guard++)
            {
                var w = FindOpenWindowContainingItem(cur);
                if (w == null) return depth;          // предок — не открытое окно → стоп
                depth++;
                var owner = FindBackpackItemByID(w.BackpackInstanceID);
                if (owner == null) return depth;
                cur = owner;
            }
            return depth;
        }

        /// <summary>
        /// ФИКС V13: Закрывает ТОЛЬКО панель контейнера рюкзака (_surroundingsPanel),
        /// НЕ закрывая основной инвентарь (_backpackPanel, _inventoryBackground, CanvasGroup).
        ///
        /// Что делает:
        /// 1. Скрывает _surroundingsPanel
        /// 2. Очищает сетку контейнера (_surroundingsGrid)
        /// 3. Сбрасывает флаг _isLootingContainer и _activeContainerController
        /// 4. Отписывается от событий контейнера
        /// 5. Возвращает предметы контейнера в пул
        /// 6. Обновляет основной инвентарь (ForceRefresh)
        ///
        /// НЕ делает (в отличие от CloseAll):
        /// - НЕ скрывает _backpackPanel / _inventoryBackground
        /// - НЕ деактивирует CanvasGroup (инвентарь остаётся кликабельным)
        /// - НЕ вызывает SetMovementEnabled(true) — игрок остаётся в инвентаре
        /// </summary>
        private void CloseBackpackContainerPanelOnly()
        {
            // Отписываемся от событий контейнера
            UnsubscribeFromContainerEvents();

            // Отключаем drag панели (если был включён) — иерархию не разрушаем.
            DisableSurroundingsPanelDrag();

            // Скрываем панель контейнера
            if (_surroundingsPanel != null)
                _surroundingsPanel.SetActive(false);

            // Очищаем сетку контейнера
            if (_surroundingsGrid != null)
                ClearGrid(_surroundingsGrid, _surroundingsItemsContainer);

            // Сбрасываем флаги контейнера
            _isLootingContainer = false;
            _activeContainerController = null;
            _currentContainerCols = 0;
            _currentContainerRows = 0;

            // Возвращаем предметы контейнера в пул (только те, что были в сетке контейнера)
            // ВНИМАНИЕ: ReturnAllItemsToPool возвращает ВСЕ предметы — вызывать нельзя,
            // иначе пропадут предметы в основном инвентаре. Вместо этого полагаемся
            // на ClearGrid выше и на ForceRefresh, который пересоздаст UI предметы.

            // Обновляем основной инвентарь
            ForceRefresh();
        }

        /// <summary>
        /// Закрывает ВСЕ открытые рюкзаки-контейнеры.
        /// Вызывать из CloseAll() / OnDisable() / при очистке инвентаря.
        /// </summary>
        public void CloseAllOpenedBackpacks()
        {
            // Сначала синхронизируем активный
            if (_activeBackpackContainer != null)
            {
                CloseBackpackAsContainer();
            }

            // Закрываем остальные (если есть в кэше)
            if (_openedBackpacks.Count > 0)
            {
                // Находим все рюкзаки, которые ещё живы в инвентаре, и сохраняем им содержимое
                // ВНИМАНИЕ: _openedBackpacks имеет ключ string (InstanceID.ToString()),
                // а FindItemByInstanceId принимает uint — поэтому парсим ключ.
                var toRemove = new List<string>();
                foreach (var kvp in _openedBackpacks)
                {
                    var item = FindItemByInstanceId(uint.Parse(kvp.Key));
                    if (item != null)
                    {
                        var savedItems = kvp.Value.GetSaveData()?.GetItems();
                        item.ReplaceBackpackContents(savedItems);
                    }
                    kvp.Value.Dispose();
                    toRemove.Add(kvp.Key);
                }
                foreach (var id in toRemove)
                    _openedBackpacks.Remove(id);
            }
        }

        /// <summary>
        /// Поиск предмета по InstanceID во всех контроллерах игрока
        /// (pockets, pocket2, backpack) и в активном контейнере.
        /// </summary>
        private InventoryItem FindItemByInstanceId(uint instanceId)
        {
            var controllers = new[] { _pocketsController, _pocket2Controller, _backpackController };
            foreach (var ctrl in controllers)
            {
                if (ctrl == null) continue;
                for (int y = 0; y < ctrl.Height; y++)
                    for (int x = 0; x < ctrl.Width; x++)
                    {
                        var it = ctrl.GetItemAt(x, y);
                        if (it != null && it.InstanceID == instanceId) return it;
                    }
            }
            if (_backpackSlot != null && _backpackSlot.EquippedItem != null && _backpackSlot.EquippedItem.InstanceID == instanceId)
                return _backpackSlot.EquippedItem;
            // FIX баг3: ищем во всех открытых окнах-контейнерах.
            for (int i = 0; i < _openContainerWindows.Count; i++)
            {
                var w = _openContainerWindows[i];
                if (w == null || w.Controller == null) continue;
                var c = w.Controller;
                for (int y = 0; y < c.Height; y++)
                    for (int x = 0; x < c.Width; x++)
                    {
                        var it = c.GetItemAt(x, y);
                        if (it != null && it.InstanceID == instanceId) return it;
                    }
            }
            return null;
        }

        #endregion

        #region Debug Helpers

        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs)
                UnityEngine.Debug.Log(message);
        }

        #endregion
    }
}