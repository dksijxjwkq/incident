﻿
using System;
using System.Collections.Generic;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Предмет в инвентаре. Содержит ссылку на статические данные + динамическое состояние.
    ///
    /// ФИКС v2 (полная поддержка fold/unfold):
    /// - Добавлено _backpackContentsSerialized: List<SavedItem> — содержимое рюкзака,
    ///   которое хранится вместе с предметом и переживает сворачивание/перемещение.
    /// - Добавлен транзитный _backpackContentsController — живой InventoryController,
    ///   который создаётся, когда рюкзак открыт как контейнер. При закрытии
    ///   содержимое синхронизируется обратно в _backpackContentsSerialized.
    ///
    /// ФИЧА #1 (AlwaysShowGrid):
    /// BackpackGridSize теперь возвращает развёрнутый размер сетки даже если
    /// _isFolded = true, при условии что Data.AlwaysShowGrid = true. Это
    /// позволяет открывать контейнер свёрнутого рюкзака через ПКМ → Открыть.
    ///
    /// БАГ #4 (защита от циклических ссылок):
    /// Добавлен ContainsDescendant(instanceId) — рекурсивная проверка того,
    /// находится ли указанный предмет (по InstanceID) внутри содержимого
    /// этого рюкзака на любом уровне вложенности. Используется в K_InventoryUI
    /// и UI_Item.OnDrop для блокировки переноса родительского контейнера
    /// в его же дочерний.
    /// </summary>
    public class InventoryItem
    {
        [SerializeField] private ItemStaticData _data;
        [SerializeField] private uint _instanceID;
        [SerializeField] private int _quantity;
        [SerializeField] private int _durability;
        [SerializeField] private bool _isRotated;

        [SerializeField] private int _rotationAngle = 0;
        [SerializeField] private bool _isFolded; // Свёрнут ли рюкзак

        // ═══════════════════════════════════════════════════════════════
        //  ФИКС v2: СОДЕРЖИМОЕ РЮКЗАКА
        //  Хранится как List<SavedItem>, чтобы переживать:
        //  - сворачивание (предметы остаются в списке, но UI их не показывает)
        //  - перемещение рюкзака между сетками
        //  - снятие/надевание рюкзака
        //  - сохранение/загрузку
        // ═══════════════════════════════════════════════════════════════
        [SerializeField]
        private List<SavedItem> _backpackContentsSerialized = new List<SavedItem>();

        // Транзитный контроллер — создаётся, когда рюкзак открыт как контейнер.
        // НЕ сериализуется. При закрытии содержимое переносится обратно в _backpackContentsSerialized.
        [NonSerialized] private InventoryController _backpackContentsController;
        [NonSerialized] private bool _backpackControllerDirty;

        [NonSerialized] private Vector2Int _sizeNormal;
        [NonSerialized] private Vector2Int _sizeRotated;
        [NonSerialized] private bool _sizeCached;

        public InventoryItem(ItemStaticData data, uint instanceID, int quantity, int durability, bool isRotated)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (instanceID == 0) throw new ArgumentException("InstanceID must be > 0", nameof(instanceID));
            if (quantity <= 0) throw new ArgumentException("Quantity must be > 0", nameof(quantity));

            _data = data;
            _instanceID = instanceID;
            _quantity = quantity;
            _durability = Mathf.Clamp(durability, 0, data.MaxDurability);
            _isRotated = isRotated;
            _rotationAngle = isRotated ? -90 : 0;
            // ФИКС: По умолчанию рюкзак СПАВНИТСЯ В СВЁРНУТОМ состоянии (если поддерживает fold).
            // Это соответствует спеку: "я спавню рюкзак — он появляется в свёрнутом состоянии
            // с folded иконкой". FromSaveData потом переопределит это значение из сохранения.
            _isFolded = data.CanFold;
            if (_backpackContentsSerialized == null) _backpackContentsSerialized = new List<SavedItem>();
            CacheSizes();
        }

#if UNITY_EDITOR
        /// <summary>
        /// Вызывается Unity после десериализации.
        /// </summary>
        void OnValidate()
        {
            if (_isRotated && _rotationAngle % 180 == 0)
                _rotationAngle = -90;
            else if (!_isRotated && _rotationAngle % 180 != 0)
                _rotationAngle = 0;
            if (_backpackContentsSerialized == null)
                _backpackContentsSerialized = new List<SavedItem>();
            _sizeCached = false;
        }
#endif

        public ItemStaticData Data => _data;
        public uint InstanceID => _instanceID;
        public ushort PrefabID => _data?.PrefabID ?? 0;
        public ItemType Type => _data?.Type ?? ItemType.Misc;
        public int Quantity => _quantity;
        public int Durability => _durability;
        public bool IsRotated => _rotationAngle != 0;
        public int RotationAngle => _rotationAngle;
        public float IconBaseRotation => _data?.IconBaseRotation ?? 0f;

        /// <summary>Свёрнут ли рюкзак. Влияет на CurrentSize и CurrentIcon.</summary>
        public bool IsFolded => _isFolded;

        /// <summary>Можно ли свернуть этот рюкзак (Data.CanFold).</summary>
        public bool CanFold => _data?.CanFold ?? false;

        public Vector2Int CurrentSize
        {
            get
            {
                if (!_sizeCached) CacheSizes();
                return _rotationAngle == 0 ? _sizeNormal : _sizeRotated;
            }
        }

        /// <summary>
        /// Размер внутренней сетки рюкзака с учётом свёрнутого состояния.
        ///
        /// ФИЧА #1: Если Data.AlwaysShowGrid = true — возвращает развёрнутый
        /// размер сетки даже когда рюкзак свёрнут. Иначе (старое поведение):
        /// свёрнутый рюкзак → (0,0) → UI не показывает сетку.
        /// Развёрнутый рюкзак → Data.BackpackGridSize (например 8x10).
        /// </summary>
        public Vector2Int BackpackGridSize
        {
            get
            {
                if (_data == null) return Vector2Int.zero;
                if (_isFolded)
                {
                    // ФИЧА #1: AlwaysShowGrid разрешает доступ к сетке даже в свёрнутом состоянии.
                    if (_data.AlwaysShowGrid)
                        return new Vector2Int(_data.BackpackWidth, _data.BackpackHeight);
                    return _data.BackpackGridSizeFolded; // обычно (0,0)
                }
                return new Vector2Int(_data.BackpackWidth, _data.BackpackHeight);
            }
        }

        /// <summary>
        /// Возвращает true, если рюкзак предоставляет внутреннюю сетку
        /// (можно открыть как контейнер через ПКМ → Открыть).
        ///
        /// ФИЧА #1: Учитывает AlwaysShowGrid — такие рюкзаки всегда предоставляют сетку.
        /// </summary>
        public bool HasInternalGrid
        {
            get
            {
                if (_data == null || !_data.IsBackpack) return false;
                if (_data.BackpackWidth <= 0 || _data.BackpackHeight <= 0) return false;
                if (_isFolded && !_data.AlwaysShowGrid) return false;
                return true;
            }
        }

        /// <summary>
        /// Текущая иконка с учётом свёрнутого состояния.
        /// </summary>
        public Sprite CurrentIcon
        {
            get
            {
                if (_data == null) return null;
                if (_isFolded && _data.IconFolded != null) return _data.IconFolded;
                return _data.Icon;
            }
        }

        public int TotalWeightGrams => (_data?.WeightGrams ?? 0) * _quantity;
        public bool IsFullStack => _quantity >= (_data?.HardStackLimit ?? 1);
        public int SpaceInStack => (_data?.HardStackLimit ?? 1) - _quantity;

        // ═══════════════════════════════════════════════════════════════
        //  ФИКС v2: API для работы с содержимым рюкзака
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// true если рюкзак непустой (есть SavedItems в _backpackContentsSerialized
        /// или есть активный контроллер с предметами).
        /// </summary>
        public bool HasBackpackContents
        {
            get
            {
                if (_backpackContentsController != null && _backpackContentsController.GetItemCount() > 0)
                    return true;
                return _backpackContentsSerialized != null && _backpackContentsSerialized.Count > 0;
            }
        }

        /// <summary>
        /// Возвращает SavedItem-снапшот содержимого рюкзака.
        /// Если есть активный контроллер — берёт из него (синхронизированное состояние).
        /// Иначе — из сериализованного списка.
        /// </summary>
        public List<SavedItem> GetBackpackSavedItems()
        {
            if (_backpackContentsController != null)
                SyncSerializedFromController();
            return _backpackContentsSerialized ?? new List<SavedItem>();
        }

        /// <summary>
        /// Возвращает активный InventoryController рюкзака или null.
        /// </summary>
        public InventoryController GetBackpackController() => _backpackContentsController;

        /// <summary>
        /// Привязывает контроллер к рюкзаку.
        /// </summary>
        internal void SetBackpackController(InventoryController controller)
        {
            _backpackContentsController = controller;
            _backpackControllerDirty = true;
        }

        /// <summary>
        /// Отвязывает контроллер от рюкзака. Содержимое синхронизируется
        /// в _backpackContentsSerialized перед отвязкой.
        /// </summary>
        internal void ClearBackpackController()
        {
            if (_backpackContentsController != null)
            {
                SyncSerializedFromController();
                _backpackContentsController = null;
            }
        }

        /// <summary>
        /// ПОЛНОСТЬЮ ЗАМЕНЯЕТ сериализованное содержимое рюкзака новым списком.
        /// Используется K_InventoryUI когда:
        /// - экипированный рюкзак сворачивается (содержимое сливается из _backpackController)
        /// - рюкзак-контейнер закрывается (содержимое сливается из временного контроллера)
        ///
        /// ВАЖНО: Старое содержимое ПОЛНОСТЬЮ затирается. Если передать null или пустой
        /// список — рюкзак станет пустым.
        /// </summary>
        public void ReplaceBackpackContents(IReadOnlyList<SavedItem> newContents)
        {
            if (_backpackContentsSerialized == null)
                _backpackContentsSerialized = new List<SavedItem>();
            else
                _backpackContentsSerialized.Clear();

            if (newContents != null)
            {
                foreach (var s in newContents)
                    _backpackContentsSerialized.Add(s);
            }
            _backpackControllerDirty = false;
        }

        /// <summary>
        /// Синхронизирует _backpackContentsSerialized из активного контроллера.
        /// </summary>
        private void SyncSerializedFromController()
        {
            if (_backpackContentsController == null) return;
            if (_backpackContentsSerialized == null) _backpackContentsSerialized = new List<SavedItem>();
            else _backpackContentsSerialized.Clear();

            var data = _backpackContentsController.GetSaveData();
            if (data != null)
            {
                var items = data.GetItems();
                foreach (var it in items)
                    _backpackContentsSerialized.Add(it);
            }
            _backpackControllerDirty = false;
        }

        /// <summary>
        /// Принудительно помечает содержимое рюкзака как изменённое.
        /// </summary>
        public void MarkBackpackContentsDirty() => _backpackControllerDirty = true;

        /// <summary>
        /// true если содержимое рюкзака было изменено через контроллер
        /// и требует синхронизации перед сохранением.
        /// </summary>
        public bool IsBackpackContentsDirty => _backpackControllerDirty;

        // ═══════════════════════════════════════════════════════════════
        //  БАГ #4: API ДЛЯ ПРОВЕРКИ ЦИКЛИЧЕСКИХ ССЫЛОК
        //  ContainsDescendant(instanceId) — рекурсивно проверяет, находится
        //  ли предмет с указанным InstanceID внутри содержимого этого
        //  рюкзака на любом уровне вложенности. Используется:
        ///    - K_InventoryUI.WouldCreateCircularReference
        ///    - UI_Item.OnDrop (drag на иконку раскрытого рюкзака)
        ///  Перед проверкой принудительно синхронизирует _backpackContentsSerialized
        ///  из активного контроллера, чтобы избежать ложных отрицаний
        ///  из-за устаревшего снимка.
        // ═══════════════════════════════════════════════════════════════

        /// <summary>
        /// Возвращает true, если предмет с указанным InstanceID находится
        /// внутри содержимого этого рюкзака (на любом уровне вложенности).
        ///
        /// Сначала синхронизирует _backpackContentsSerialized из активного
        /// контроллера (если есть), чтобы проверка работала с актуальными
        /// данными. Это критично для БАГ #4: без синхронизации можно
        /// перетащить родительский рюкзак в его же дочерний, потому что
        /// снимок содержимого окажется устаревшим.
        /// </summary>
        public bool ContainsDescendant(uint instanceId)
        {
            if (instanceId == 0) return false;
            // Принудительная синхронизация: контроллер мог быть изменён
            // (например, в него положили предмет через UI), но снимок
            // _backpackContentsSerialized ещё не обновился.
            var contents = GetBackpackSavedItems();
            return ContainsDescendantRecursive(contents, instanceId);
        }

        /// <summary>
        /// Возвращает true, если ЛЮБОЙ из потомков этого рюкзака является
        /// рюкзаком с указанным InstanceID. Синоним ContainsDescendant,
        /// добавлен для читаемости вызывающего кода.
        /// </summary>
        public bool IsAncestorOf(InventoryItem possibleDescendant)
        {
            if (possibleDescendant == null) return false;
            return ContainsDescendant(possibleDescendant.InstanceID);
        }

        /// <summary>
        /// Статический рекурсивный поиск по списку SavedItem.
        /// Вынесен в отдельный метод, чтобы его можно было использовать
        /// без ссылки на InventoryItem (например, для сырых сохранённых данных).
        /// </summary>
        public static bool ContainsDescendantRecursive(List<SavedItem> contents, uint targetInstanceId)
        {
            if (contents == null || contents.Count == 0) return false;

            // Защита от зацикливания на повреждённых данных (цикл в снимке).
            // Рекурсия ограничена глубиной 32 — этого достаточно для любого
            // реального инвентаря, и при этом ловит любые циклы.
            return ContainsDescendantRecursiveInternal(contents, targetInstanceId, depth: 0);
        }

        private const int MAX_DESCENDANT_SEARCH_DEPTH = 32;

        private static bool ContainsDescendantRecursiveInternal(List<SavedItem> contents, uint targetInstanceId, int depth)
        {
            if (contents == null || depth > MAX_DESCENDANT_SEARCH_DEPTH) return false;

            foreach (var savedItem in contents)
            {
                if (savedItem.InstanceID == targetInstanceId) return true;

                if (savedItem.BackpackContents != null && savedItem.BackpackContents.Count > 0)
                {
                    if (ContainsDescendantRecursiveInternal(savedItem.BackpackContents, targetInstanceId, depth + 1))
                        return true;
                }
            }
            return false;
        }

        // ═══════════════════════════════════════════════════════════════
        //  ПРЕДМЕТНЫЕ ОПЕРАЦИИ
        // ═══════════════════════════════════════════════════════════════

        // ФИКС БАГ (audit) #26: AddQuantity/RemoveQuantity принимали
        // отрицательные числа, что инвертировало смысл операции
        // (AddQuantity(-5) увеличивал стек, RemoveQuantity(-5) — уменьшал).
        // Теперь отрицательный аргумент — no-op, так как это явная ошибка
        // вызывающего кода, но мы не хотим кидать исключение в runtime.
        internal void AddQuantity(int amount)
        {
            if (amount <= 0) return;
            int limit = _data?.HardStackLimit ?? int.MaxValue;
            _quantity = Mathf.Min(_quantity + amount, limit);
        }

        internal void RemoveQuantity(int amount)
        {
            if (amount <= 0) return;
            _quantity = Mathf.Max(_quantity - amount, 0);
        }

        public void Rotate()
        {
            if (_data == null || !_data.CanRotate) return;
            _rotationAngle = _rotationAngle == 0 ? -90 : 0;
            _isRotated = _rotationAngle != 0;
            _sizeCached = false;
        }

        internal void RestoreRotationState(int angle)
        {
            _rotationAngle = (angle % 180 != 0) ? -90 : 0;
            _isRotated = _rotationAngle != 0;
            _sizeCached = false;
        }

        /// <summary>
        /// Переключает состояние свёрнутости рюкзака.
        /// Свернуть МОЖНО только если рюкзак пуст (HasBackpackContents == false).
        /// Развёрнуть можно всегда.
        ///
        /// ВАЖНО: Вызывающий код (K_InventoryUI) ДОЛЖЕН:
        /// - Для экипированного рюкзака: перед fold сбросить _backpackController
        ///   в _backpackContentsSerialized (это делает InventoryItem.ClearBackpackController()).
        /// - После unfold: пересоздать сетку, и если нужно — открыть контроллер заново.
        /// </summary>
        public bool ToggleFold(bool contentsEmpty)
        {
            if (_data == null || !_data.CanFold) return false;

            if (_isFolded)
            {
                // Разворачиваем — всегда можно
                _isFolded = false;
                _sizeCached = false;
                return true;
            }
            else
            {
                // Сворачиваем — только если пуст (двойная проверка: флаг + реальное содержимое)
                if (!contentsEmpty || HasBackpackContents)
                {
                    Debug.Log($"[InventoryItem] Cannot fold backpack '{_data.DisplayName}' — not empty " +
                              $"(flag={contentsEmpty}, hasContents={HasBackpackContents})");
                    return false;
                }
                _isFolded = true;
                _sizeCached = false;
                return true;
            }
        }

        /// <summary>
        /// Принудительно устанавливает свёрнутое состояние.
        /// Используется при десериализации. НЕ проверяет содержимое.
        /// </summary>
        internal void SetFolded(bool folded)
        {
            if (_data == null || !_data.CanFold) return;
            _isFolded = folded;
            _sizeCached = false;
        }

        public bool CanStackWith(InventoryItem other) =>
            other != null && _data?.PrefabID == other.PrefabID && _quantity < (_data?.HardStackLimit ?? 1);

        public bool CanFitInSpace(int width, int height)
        {
            var size = CurrentSize;
            return size.x <= width && size.y <= height;
        }

        public SavedItem ToSaveData(int x, int y)
        {
            // Перед сохранением — синхронизируем содержимое рюкзака, если контроллер активен
            if (_backpackContentsController != null)
                SyncSerializedFromController();

            // ФИКС БАГ (audit) #25: глубокое клонирование BackpackContents.
            // Раньше new List<SavedItem>(_backpackContentsSerialized) — shallow copy
            // расшаривала вложенные списки. SavedItem.DeepClone рекурсивно
            // копирует всё дерево, чтобы возвращаемый SavedItem не имел общих
            // ссылок с живым состоянием.
            List<SavedItem> contentsClone = null;
            if (_backpackContentsSerialized != null && _backpackContentsSerialized.Count > 0)
            {
                contentsClone = new List<SavedItem>(_backpackContentsSerialized.Count);
                foreach (var child in _backpackContentsSerialized)
                    contentsClone.Add(SavedItem.DeepClone(child));
            }

            return new SavedItem(
                _data?.ItemID ?? "",
                _instanceID,
                x, y,
                _quantity,
                _durability,
                _isRotated,
                _isFolded
            )
            {
                BackpackContents = contentsClone
            };
        }

        public static InventoryItem FromSaveData(SavedItem saveData, ItemStaticData data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (!saveData.IsValid())
            {
                Debug.LogWarning($"[InventoryItem] Invalid SavedItem: ItemID='{saveData.ItemID}', InstanceID={saveData.InstanceID}");
                return null;
            }
            if (saveData.ItemID != data.ItemID)
            {
                Debug.LogError($"[InventoryItem] ItemID mismatch: Saved='{saveData.ItemID}' != Template='{data.ItemID}'");
                return null;
            }

            // ФИКС БАГ (audit) #15: Если в сохранении IsRotated=true у предмета,
            // у которого CanRotate=false — это повреждённое состояние. Отклоняем,
            // иначе в RotateItem/BeginDrag возможны бесконечные циклы восстановления
            // поворота (Rotate() молча no-op на CanRotate=false).
            if (saveData.IsRotated && !data.CanRotate)
            {
                Debug.LogError(
                    $"[InventoryItem] Corrupted save: item '{saveData.ItemID}' " +
                    $"has IsRotated=true but CanRotate=false. Rejecting.");
                return null;
            }

            // ФИКС БАГ (audit) #15: То же для fold-состояния.
            if (saveData.IsFolded && !data.CanFold)
            {
                Debug.LogError(
                    $"[InventoryItem] Corrupted save: item '{saveData.ItemID}' " +
                    $"has IsFolded=true but CanFold=false. Rejecting.");
                return null;
            }

            var item = new InventoryItem(data, saveData.InstanceID, saveData.Quantity, saveData.Durability, saveData.IsRotated);
            if (saveData.IsRotated) item._rotationAngle = -90;
            // ФИКС: Явно восстанавливаем fold-состояние из сохранения.
            // Конструктор теперь по умолчанию ставит _isFolded = data.CanFold (true для рюкзаков),
            // поэтому мы должны ЯВНО переопределить из saveData (в т.ч. в false).
            if (data.CanFold) item._isFolded = saveData.IsFolded;
            else item._isFolded = false;

            // ФИКС БАГ (audit) #25: глубокое копирование BackpackContents.
            // Раньше new List<SavedItem>(saveData.BackpackContents) — это shallow copy:
            // внешние SavedItem-структуры копировались по значению, но внутренние
            // List<SavedItem> внутри вложенных рюкзаков расшаривались.
            // Используем SavedItem.DeepClone для надёжного разделения.
            if (saveData.BackpackContents != null && saveData.BackpackContents.Count > 0)
            {
                item._backpackContentsSerialized = new List<SavedItem>(saveData.BackpackContents.Count);
                foreach (var child in saveData.BackpackContents)
                    item._backpackContentsSerialized.Add(SavedItem.DeepClone(child));
            }
            item._sizeCached = false;
            return item;
        }

        private void CacheSizes()
        {
            if (_data == null)
            {
                _sizeNormal = _sizeRotated = new Vector2Int(1, 1);
                _sizeCached = true;
                return;
            }

            if (_isFolded && _data.CanFold)
            {
                _sizeNormal = _data.SizeFolded;
                _sizeRotated = new Vector2Int(_data.SizeFolded.y, _data.SizeFolded.x);
            }
            else
            {
                // ФИКС V13: Для развёрнутого рюкзака используем BackpackWidth × BackpackHeight
                // как размер в инвентаре. Раньше использовался Data.Size — но он в инспекторе
                // обычно равен свёрнутому размеру (2x1), и при unfold размер иконки НЕ менялся.
                //
                // ФИКС V14: Добавлена возможность ОТДЕЛЬНО настроить размер иконки рюкзака
                // в инвентаре (когда он развёрнут) — НЕ обязательно совпадающий с размером
                // внутренней сетки рюкзака.
                //
                // Например: сетка рюкзака 5x5 (внутри 5x5 ячеек для предметов), но в
                // инвентаре развёрнутый рюкзак занимает 4x4 ячейки. Это позволяет делать
                // визуально более компактные рюкзаки.
                //
                // Логика приоритета:
                //   1. Если Data.UnfoldedIconSize > (0,0) — используем его.
                //   2. Иначе если Data.IsBackpack с BackpackWidth/Height > 0 — используем их
                //      (это обратно-совместимо с V13).
                //   3. Иначе — Data.Size (для нерюкзаков или рюкзаков без fold).
                //
                // ВАЖНО: ВНУТРЕННЯЯ сетка рюкзака (BackpackGridSize) всегда использует
                // BackpackWidth × BackpackHeight — это размер для OpenContainer.
                // UnfoldedIconSize влияет ТОЛЬКО на размер иконки/предмета в инвентаре.
                Vector2Int unfoldedSize;
                if (_data.IsBackpack && _data.UnfoldedIconSize.x > 0 && _data.UnfoldedIconSize.y > 0)
                {
                    unfoldedSize = _data.UnfoldedIconSize;
                }
                else if (_data.IsBackpack && _data.BackpackWidth > 0 && _data.BackpackHeight > 0)
                {
                    unfoldedSize = new Vector2Int(_data.BackpackWidth, _data.BackpackHeight);
                }
                else
                {
                    unfoldedSize = _data.Size;
                }

                _sizeNormal = unfoldedSize;
                _sizeRotated = new Vector2Int(unfoldedSize.y, unfoldedSize.x);
            }
            _sizeCached = true;
        }

        [ContextMenu("Debug: Print Info")]
        public void DebugPrint()
        {
            Debug.Log($"[InventoryItem] {_data?.ItemID ?? "NULL"} | Qty: {_quantity} | " +
                $"Size: {CurrentSize.x}x{CurrentSize.y} | Angle: {_rotationAngle}° | " +
                $"Folded: {_isFolded} | Contents: {_backpackContentsSerialized?.Count ?? 0} items");
        }
    }
}











