﻿
using K_Incident.Core.Inventory;
using System;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Точка входа для системы инвентаря.
    /// ✅ ИСПРАВЛЕНО БАГ 4: Три независимых контроллера (Pocket1 2x2 + Pocket2 2x2 + Backpack 8x10).
    /// ✅ ИСПРАВЛЕНО БАГ 5: Глубокое клонирование InventoryData для защиты ScriptableObject от мутации в Editor.
    /// </summary>
    public class K_InventorySetup : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField, Tooltip("База данных предметов (ScriptableObject)")]
        private ItemDatabase _database;

        [Header("Initial Data (Optional)")]
        [SerializeField, Tooltip("Начальные данные КАРМАНА 1 (опционально)")]
        private InventoryData _initialPocketsData;

        [SerializeField, Tooltip("Начальные данные КАРМАНА 2 (опционально)")]
        private InventoryData _initialPocket2Data;

        [SerializeField, Tooltip("Начальные данные РЮКЗАКА (опционально)")]
        private InventoryData _initialBackpackData;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = true;

        #endregion

        #region Constants

        private const int POCKETS_WIDTH = 2;
        private const int POCKETS_HEIGHT = 2;
        private const int DEFAULT_BACKPACK_WIDTH = 8;
        private const int DEFAULT_BACKPACK_HEIGHT = 10;
        private const uint INSTANCE_ID_BUFFER = 10000;

        #endregion

        #region Fields

        private InventoryController _pocketsController;
        private InventoryController _pocket2Controller;
        private InventoryController _backpackController;
        private K_WeightManager _cachedWeightManager;

        #endregion

        #region Properties

        public static ItemDatabase DatabaseInstance { get; private set; }
        public static bool IsInitialized { get; private set; } = false;

        /// <summary>Контроллер КАРМАНА 1 (2x2)</summary>
        public InventoryController PocketsController => _pocketsController;

        /// <summary>Контроллер КАРМАНА 2 (2x2)</summary>
        public InventoryController Pocket2Controller => _pocket2Controller;

        /// <summary>Контроллер РЮКЗАКА (на спине, 8x10)</summary>
        public InventoryController BackpackController => _backpackController;

        /// <summary>
        /// ⚠️ DEPRECATED: Оставлено для обратной совместимости.
        /// Возвращает PocketsController. Используйте PocketsController или BackpackController явно.
        /// </summary>
        [Obsolete("Use PocketsController or BackpackController explicitly")]
        public InventoryController Controller => _pocketsController;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (_database == null)
            {
                Debug.LogError("[InventorySetup] CRITICAL: ItemDatabase NOT assigned!");
                enabled = false;
                return;
            }

            uint globalMaxId = FindGlobalMaxInstanceId();
            GlobalIDManager.InitWithMaxId(globalMaxId);

            DatabaseInstance = _database;
            _database.Initialize();

            // ✅ ФИКС БАГОВ 4 и 5: Глубокое клонирование + жесткие размеры
            var runtimePocketsData = CloneInventoryData(_initialPocketsData, POCKETS_WIDTH, POCKETS_HEIGHT);
            _pocketsController = new InventoryController(runtimePocketsData, _database, "Player_Pocket1");

            var runtimePocket2Data = CloneInventoryData(_initialPocket2Data, POCKETS_WIDTH, POCKETS_HEIGHT);
            _pocket2Controller = new InventoryController(runtimePocket2Data, _database, "Player_Pocket2");

            var runtimeBackpackData = CloneInventoryData(_initialBackpackData, DEFAULT_BACKPACK_WIDTH, DEFAULT_BACKPACK_HEIGHT);
            _backpackController = new InventoryController(runtimeBackpackData, _database, "Player_Backpack");

            _pocketsController.OnInventoryChanged += OnInventoryUpdated;
            _pocketsController.OnWeightChanged += OnWeightUpdated;
            _pocket2Controller.OnInventoryChanged += OnInventoryUpdated;
            _pocket2Controller.OnWeightChanged += OnWeightUpdated;
            _backpackController.OnInventoryChanged += OnInventoryUpdated;
            _backpackController.OnWeightChanged += OnWeightUpdated;

            IsInitialized = true;
            LogDebug($"[InventorySetup] ✅ Initialized. Pocket1: {POCKETS_WIDTH}x{POCKETS_HEIGHT}, Pocket2: {POCKETS_WIDTH}x{POCKETS_HEIGHT}, Backpack: {DEFAULT_BACKPACK_WIDTH}x{DEFAULT_BACKPACK_HEIGHT}");
        }

        private void Start()
        {
            if (!IsInitialized) return;

            K_SaveManager.Instance?.Register(_pocketsController);
            K_SaveManager.Instance?.Register(_pocket2Controller);
            K_SaveManager.Instance?.Register(_backpackController);
            LogDebug("[InventorySetup] All controllers registered with SaveManager.");

            _cachedWeightManager = FindFirstObjectByType<K_WeightManager>();
            if (_cachedWeightManager != null)
            {
                // ФИКС БАГ (audit) K_InventorySetup: анонимные лямбды нельзя
                // отписать в OnDestroy. Заменены на именованные методы.
                _pocketsController.OnWeightChanged += OnAnyControllerWeightChanged;
                _pocket2Controller.OnWeightChanged += OnAnyControllerWeightChanged;
                _backpackController.OnWeightChanged += OnAnyControllerWeightChanged;
                UpdateTotalWeight();
                LogDebug("[InventorySetup] Connected to WeightManager (combined weight).");
            }
            else
            {
                Debug.LogWarning("[InventorySetup] K_WeightManager not found!");
            }
        }

        private void OnDestroy()
        {
            // ФИКС БАГ (audit) K_InventorySetup: СНАЧАЛА Unregister из SaveManager,
            // потом unsubscribe, потом Dispose. Раньше Dispose шёл первым, и
            // SaveManager, появившийся после Start, мог держать ссылку на
            // disposed controller.
            var saveManager = K_SaveManager.Instance;
            saveManager?.Unregister(_pocketsController);
            saveManager?.Unregister(_pocket2Controller);
            saveManager?.Unregister(_backpackController);

            if (_pocketsController != null)
            {
                _pocketsController.OnInventoryChanged -= OnInventoryUpdated;
                _pocketsController.OnWeightChanged -= OnWeightUpdated;
                _pocketsController.OnWeightChanged -= OnAnyControllerWeightChanged;
                _pocketsController.Dispose();
                _pocketsController = null;
            }

            if (_pocket2Controller != null)
            {
                _pocket2Controller.OnInventoryChanged -= OnInventoryUpdated;
                _pocket2Controller.OnWeightChanged -= OnWeightUpdated;
                _pocket2Controller.OnWeightChanged -= OnAnyControllerWeightChanged;
                _pocket2Controller.Dispose();
                _pocket2Controller = null;
            }

            if (_backpackController != null)
            {
                _backpackController.OnInventoryChanged -= OnInventoryUpdated;
                _backpackController.OnWeightChanged -= OnWeightUpdated;
                _backpackController.OnWeightChanged -= OnAnyControllerWeightChanged;
                _backpackController.Dispose();
                _backpackController = null;
            }

            DatabaseInstance = null;
            IsInitialized = false;
            _cachedWeightManager = null;
        }

        #endregion

        #region Event Handlers

        private void OnInventoryUpdated()
        {
            LogDebug("[Inventory] Changed!");
        }

        private void OnWeightUpdated(float kg) { }

        // ФИКС БАГ (audit) K_InventorySetup: именованный обработчик
        // для weight events, чтобы можно было корректно отписаться.
        private void OnAnyControllerWeightChanged(float _)
        {
            UpdateTotalWeight();
        }

        private void UpdateTotalWeight()
        {
            if (_cachedWeightManager == null) return;
            float total = 0f;
            if (_pocketsController != null) total += _pocketsController.CurrentWeightKg;
            if (_pocket2Controller != null) total += _pocket2Controller.CurrentWeightKg;
            if (_backpackController != null) total += _backpackController.CurrentWeightKg;
            _cachedWeightManager.SetWeight(total);
        }

        #endregion

        #region Utilities

        /// <summary>
        /// ✅ Глубокое клонирование InventoryData с жестким ограничением размеров.
        /// Защищает ScriptableObject от мутации в Editor и гарантирует корректные размеры.
        /// </summary>
        private InventoryData CloneInventoryData(InventoryData source, int forceWidth, int forceHeight)
        {
            var clone = new InventoryData(forceWidth, forceHeight);

            if (source != null)
            {
                foreach (var savedItem in source.GetItems())
                {
                    if (savedItem.X < forceWidth && savedItem.Y < forceHeight)
                    {
                        clone.AddItem(savedItem);
                    }
                    else
                    {
                        Debug.LogWarning($"[InventorySetup] Skipped item {savedItem.ItemID} at ({savedItem.X},{savedItem.Y}) - outside {forceWidth}x{forceHeight} grid");
                    }
                }
            }

            return clone;
        }

        private uint FindGlobalMaxInstanceId()
        {
            uint maxId = 0;

            if (_initialPocketsData != null)
                ScanMaxInstanceIdRecursive(_initialPocketsData.GetItems(), ref maxId);

            if (_initialPocket2Data != null)
                ScanMaxInstanceIdRecursive(_initialPocket2Data.GetItems(), ref maxId);

            if (_initialBackpackData != null)
                ScanMaxInstanceIdRecursive(_initialBackpackData.GetItems(), ref maxId);

            // ФИКС БАГ (audit) #23: используем ObserveID (через InitWithMaxId),
            // который использует checked-арифметику и отклоняет 0/uint.MaxValue.
            return maxId + INSTANCE_ID_BUFFER;
        }

        /// <summary>
        /// ФИКС БАГ (audit) K_InventorySetup: рекурсивный обход содержимого
        /// рюкзаков для поиска максимального InstanceID. Раньше сканировались
        /// только top-level items — nested contents (вещи внутри рюкзака)
        /// игнорировались, и GlobalIDManager мог выдать новый ID, совпадающий
        /// с уже существующим вложенным предметом → дубликат InstanceID.
        /// </summary>
        private void ScanMaxInstanceIdRecursive(System.Collections.Generic.IReadOnlyList<global::K_Incident.Core.Inventory.SavedItem> items, ref uint maxId, int depth = 0)
        {
            const int MAX_DEPTH = 32;
            if (items == null || depth > MAX_DEPTH) return;

            foreach (var item in items)
            {
                if (item.InstanceID > maxId && item.InstanceID != uint.MaxValue)
                    maxId = item.InstanceID;

                if (item.BackpackContents != null && item.BackpackContents.Count > 0)
                    ScanMaxInstanceIdRecursive(item.BackpackContents, ref maxId, depth + 1);
            }
        }

        public static ItemDatabase GetDatabase()
        {
            if (!IsInitialized)
            {
                Debug.LogWarning("[InventorySetup] GetDatabase() called before initialization!");
                return null;
            }
            return DatabaseInstance;
        }

        private void LogDebug(string message)
        {
            if (_debugLogs) Debug.Log(message);
        }

        #endregion

        #region Editor Helpers

#if UNITY_EDITOR
        [ContextMenu("Print Both Grids")]
        private void PrintGrids()
        {
            Debug.Log("=== POCKET 1 ===");
            _pocketsController?.DebugPrintGrid();
            Debug.Log("=== POCKET 2 ===");
            _pocket2Controller?.DebugPrintGrid();
            Debug.Log("=== BACKPACK ===");
            _backpackController?.DebugPrintGrid();
        }

        [ContextMenu("Clear All")]
        private void ClearAll()
        {
            _pocketsController?.Clear();
            _pocket2Controller?.Clear();
            _backpackController?.Clear();
            Debug.Log("[InventorySetup] All inventories cleared.");
        }
#endif

        #endregion
    }
}














