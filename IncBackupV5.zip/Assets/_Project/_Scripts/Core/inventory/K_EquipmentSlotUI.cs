﻿
using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    public enum EquipmentSlotType { Primary, Pistol, Melee, Backpack }

    /// <summary>
    /// UI слота экипировки.
    /// Поддерживает силуэты для пустых слотов, кастомные метки.
    /// </summary>
    public class K_EquipmentSlotUI : MonoBehaviour,
        IPointerClickHandler,
        IPointerEnterHandler,
        IPointerExitHandler,
        IDropHandler,
        IBeginDragHandler,
        IDragHandler,
        IEndDragHandler
    {
        #region Constants

        private const float FLASH_ERROR_DURATION = 0.15f;
        private const float HOVER_THROTTLE = 0.2f;
        private const float DROP_FEEDBACK_DURATION = 0.1f;

        private static readonly Color COLOR_VALID_DROP = new Color(0.2f, 0.8f, 0.2f, 0.6f);
        private static readonly Color COLOR_INVALID_DROP = new Color(0.9f, 0.2f, 0.2f, 0.6f);
        private static readonly Color COLOR_HOVER = new Color(1f, 1f, 1f, 0.15f);
        private static readonly Color COLOR_ITEM_HOVER = new Color(1f, 0.85f, 0f, 0.35f);

        private static readonly Vector2 SIZE_PRIMARY = new Vector2(130f, 315f);
        private static readonly Vector2 SIZE_PISTOL = new Vector2(120f, 120f);
        private static readonly Vector2 SIZE_MELEE = new Vector2(120f, 120f);
        private static readonly Vector2 SIZE_BACKPACK = new Vector2(100f, 100f);

        #endregion

        #region Inspector Fields

        [SerializeField] private Image _icon;
        [SerializeField] private TextMeshProUGUI _label;
        [SerializeField] private Image _highlight;
        [SerializeField, Tooltip("Тип слота: Primary, Pistol, Melee, Backpack")]
        private EquipmentSlotType _slotType;
        [SerializeField, Tooltip("Если нет места в инвентаре при снятии - попытаться вернуть предмет в инвентарь.")]
        private bool _spawnOnGroundIfNoSpace;
        [SerializeField, Tooltip("LayerMask для raycast при спавне предмета на землю")]
        private LayerMask _groundLayer = Physics.DefaultRaycastLayers;

        [Header("Custom Label")]
        [SerializeField, Tooltip("Кастомная метка слота. Если пусто — используется стандартная по типу.")]
        private string _customLabel = "";

        [Header("Empty Slot Silhouette")]
        [SerializeField, Tooltip("Силуэт предмета для пустого слота. Показывается полупрозрачным, чтобы игрок понимал что сюда можно положить.")]
        private Sprite _emptySlotSprite;
        [SerializeField, Tooltip("Цвет силуэта в пустом слоте.")]
        private Color _emptySlotColor = new Color(0.5f, 0.5f, 0.5f, 0.5f);
        [SerializeField, Tooltip("Поворот силуэта (градусы по Z). Для оружия обычно -90.")]
        private float _emptySlotRotation = -90f;

        [Header("Item Hover Highlight")]
        [SerializeField, Tooltip("Цвет подсветки при наведении на занятый слот. По умолчанию совпадает с UI_Item.")]
        private Color _itemHoverColor = new Color(1f, 0.85f, 0f, 0.35f);

        [Header("Pixel Perfect Bottom Border Fix")]
        [SerializeField, Tooltip("Цвет нижней границы. Подбери под цвет рамки слота.")]
        private Color _bottomBorderColor = new Color(0.3f, 0.3f, 0.3f, 1f);
        [SerializeField, Tooltip("Толщина нижней границы (px).")]
        private float _bottomBorderHeight = 1f;
        [SerializeField, Tooltip("Сдвиг границы вверх от математического низа (px).")]
        private float _bottomBorderOffset = 1f;

        #endregion

        #region Fields

        public event Action<K_EquipmentSlotUI, bool> OnHoverChanged;
        public event Action<K_EquipmentSlotUI, InventoryItem> OnValidDropPreview;
        public event Action<K_EquipmentSlotUI> OnDropAccepted;

        private K_InventoryUI _inventoryUI;
        private InventoryItem _equippedItem;
        private RectTransform _rectTransform;
        private Coroutine _hoverThrottleCoroutine;
        private Coroutine _flashErrorCoroutine;
        private Coroutine _dropFeedbackCoroutine;
        private bool _isHovering;
        private bool _isDraggingOver;
        private bool _isDraggingFromSlot;
        private Image _itemHoverOverlay;

        #endregion

        #region Properties

        public EquipmentSlotType SlotType => _slotType;
        public bool IsOccupied => _equippedItem != null;
        public InventoryItem EquippedItem => _equippedItem;
        public float IconEulerZ => _icon != null ? _icon.rectTransform.localEulerAngles.z : 0f;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _rectTransform = GetComponent<RectTransform>();

            if (_highlight != null)
            {
                _highlight.enabled = false;
                _highlight.raycastTarget = false;
                _highlight.color = Color.clear;
            }

            if (_icon != null)
                _icon.enabled = false;

            DrawBottomBorderFix();
            EnsureItemHoverOverlay();
        }

        private void DrawBottomBorderFix()
        {
            if (_rectTransform == null) return;

            Transform existing = transform.Find("SlotBottomBorderFix");
            if (existing != null) Destroy(existing);

            var obj = new GameObject("SlotBottomBorderFix", typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(transform, false);

            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(1f, 0f);
            rt.pivot = new Vector2(0.5f, 0f);
            rt.anchoredPosition = new Vector2(0f, _bottomBorderOffset);
            rt.sizeDelta = new Vector2(0f, _bottomBorderHeight);

            var img = obj.GetComponent<Image>();
            img.color = _bottomBorderColor;
            img.raycastTarget = false;
            img.maskable = true;
        }

        public void Initialize(K_InventoryUI inventoryUI, EquipmentSlotType slotType)
        {
            _inventoryUI = inventoryUI;
            _slotType = slotType;
            if (_rectTransform != null)
                _rectTransform.sizeDelta = GetSlotSize(slotType);
            UpdateLabelText();
            Refresh();
        }

        private static Vector2 GetSlotSize(EquipmentSlotType type) => type switch
        {
            EquipmentSlotType.Primary => SIZE_PRIMARY,
            EquipmentSlotType.Pistol => SIZE_PISTOL,
            EquipmentSlotType.Melee => SIZE_MELEE,
            EquipmentSlotType.Backpack => SIZE_BACKPACK,
            _ => SIZE_PISTOL
        };

        private void UpdateLabelText()
        {
            if (_label == null) return;

            // Если задана кастомная метка — используем её
            if (!string.IsNullOrEmpty(_customLabel))
            {
                _label.text = _customLabel;
                return;
            }

            _label.text = _slotType switch
            {
                EquipmentSlotType.Primary => gameObject.name.Contains("1") ? "ПЕРВИЧНОЕ" : "ВТОРИЧНОЕ",
                EquipmentSlotType.Pistol => "ПИСТОЛЕТ",
                EquipmentSlotType.Melee => "ХОЛОДНОЕ",
                EquipmentSlotType.Backpack => "РЮКЗАК",
                _ => string.Empty
            };
        }

        #endregion

        #region Pointer Handlers

        public void OnPointerEnter(PointerEventData eventData)
        {
            _isHovering = true;
            if (_hoverThrottleCoroutine == null)
                _hoverThrottleCoroutine = StartCoroutine(ThrottledHoverUpdate());

            if (IsOccupied && !_isDraggingFromSlot)
                ShowItemHover();
            else if (_highlight != null && _highlight.enabled)
                _highlight.color = COLOR_HOVER;
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            _isHovering = false;
            _isDraggingOver = false;
            if (_hoverThrottleCoroutine != null)
            {
                StopCoroutine(_hoverThrottleCoroutine);
                _hoverThrottleCoroutine = null;
            }

            HideItemHover();

            if (!IsOccupied && _highlight != null && _highlight.enabled)
                _highlight.color = Color.clear;

            OnHoverChanged?.Invoke(this, false);
        }

        private IEnumerator ThrottledHoverUpdate()
        {
            yield return new WaitForSeconds(HOVER_THROTTLE);
            while (_isHovering)
            {
                OnHoverChanged?.Invoke(this, true);
                yield return new WaitForSeconds(HOVER_THROTTLE);
            }
            _hoverThrottleCoroutine = null;
        }

        #endregion

        #region Drop Handler

        public void OnDrop(PointerEventData eventData)
        {
            TriggerDropFeedback(true);
            _inventoryUI?.OnEquipmentSlotDrop(this, eventData);
        }

        public void TriggerDropFeedback(bool isValid)
        {
            if (_highlight == null || !_highlight.enabled) return;
            if (_dropFeedbackCoroutine != null) StopCoroutine(_dropFeedbackCoroutine);
            _dropFeedbackCoroutine = StartCoroutine(FlashDropFeedback(isValid ? COLOR_VALID_DROP : COLOR_INVALID_DROP));
        }

        private IEnumerator FlashDropFeedback(Color targetColor)
        {
            if (_highlight == null) yield break;
            var originalColor = _highlight.color;
            _highlight.color = targetColor;
            yield return new WaitForSeconds(DROP_FEEDBACK_DURATION);
            if (_highlight != null)
                _highlight.color = _isHovering ? COLOR_HOVER : Color.clear;
            _dropFeedbackCoroutine = null;
        }

        #endregion

        #region Click Handler

        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Right) return;
            if (_equippedItem == null) return;

            if (K_ContextMenu.Instance != null)
            {
                K_ContextMenu.Instance.Show(_equippedItem, eventData.position, _inventoryUI, this);
            }
            else
            {
                Unequip();
            }
        }

        public void Unequip()
        {
            if (_equippedItem == null) return;
            if (_inventoryUI == null)
            {
                Debug.LogWarning("[EquipmentSlot] inventoryUI is null - cannot unequip");
                return;
            }

            // ФИКС БАГ (audit) #17: надетый рюкзак НЕЛЬЗЯ снять в его собственное
            // содержимое. Для backpack-slot мы исключаем _backpackController
            // из списка destinations, чтобы положить надетый рюкзак в его же
            // внутреннюю сетку было нельзя.
            bool isBackpackSlot = _slotType == EquipmentSlotType.Backpack;

            bool placed = false;

            var pocketsController = _inventoryUI.GetControllerForGrid(GridType.Pockets);
            if (pocketsController != null)
                placed = pocketsController.PlaceExistingItemInFirstFreeSlot(_equippedItem);

            if (!placed)
            {
                var pocket2Controller = _inventoryUI.GetControllerForGrid(GridType.Pocket2);
                if (pocket2Controller != null)
                    placed = pocket2Controller.PlaceExistingItemInFirstFreeSlot(_equippedItem);
            }

            if (!placed && !isBackpackSlot)
            {
                // Только не-rюкзак можно пытаться положить в рюкзак.
                // Для надетого рюкзака backpackController — это ЕГО СОБСТВЕННОЕ
                // содержимое, и класть его туда = «снять внутрь себя».
                var backpackController = _inventoryUI.GetControllerForGrid(GridType.Backpack);
                if (backpackController != null)
                    placed = backpackController.PlaceExistingItemInFirstFreeSlot(_equippedItem);
            }

            if (!placed)
            {
                if (_spawnOnGroundIfNoSpace)
                {
                    // ФИКС БАГ (audit) #18: TrySpawnItemOnGround теперь fail-closed.
                    // Пока world-item service не реализован, всегда возвращает false —
                    // item остаётся у текущего владельца. Slot НЕ очищается.
                    if (!TrySpawnItemOnGround(_equippedItem))
                    {
                        if (_flashErrorCoroutine != null) StopCoroutine(_flashErrorCoroutine);
                        _flashErrorCoroutine = StartCoroutine(FlashSlotError());
                        Debug.LogWarning(
                            "[EquipmentSlot] No space for unequip and ground spawn is not implemented. " +
                            "Item stays equipped.");
                        return;
                    }
                }
                else
                {
                    if (_flashErrorCoroutine != null) StopCoroutine(_flashErrorCoroutine);
                    _flashErrorCoroutine = StartCoroutine(FlashSlotError());
                    Debug.LogWarning("[EquipmentSlot] No space in Pockets, Pocket2 or Backpack! Item NOT unequipped.");
                    return;
                }
            }

            if (isBackpackSlot)
                _inventoryUI.OnBackpackUnequipped();

            _equippedItem = null;
            Refresh();
        }

        private IEnumerator FlashSlotError()
        {
            if (_icon == null) yield break;
            var originalColor = _icon.color;
            _icon.color = Color.red;
            yield return new WaitForSeconds(FLASH_ERROR_DURATION);
            if (_icon != null && _icon.gameObject.activeInHierarchy)
                _icon.color = originalColor;
        }

        /// <summary>
        /// ФИКС БАГ (audit) #18: Fail-closed ground spawn.
        /// World-item service ещё не реализован. Возвращает false ВСЕГДА —
        /// caller (Unequip) оставляет item в equipment slot.
        /// Когда world service появится, заменить тело на реальную реализацию,
        /// которая возвращает true только после успешного Instantiate в сцене.
        /// </summary>
        private bool TrySpawnItemOnGround(InventoryItem item)
        {
            if (item == null) return false;
            Debug.LogWarning(
                $"[EquipmentSlot] TrySpawnItemOnGround: not implemented. " +
                $"Item '{item.Data?.DisplayName}' stays equipped (fail-closed).");
            return false;
        }

        #endregion

        #region Drag from slot

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (_equippedItem == null || _inventoryUI == null) return;

            _isDraggingFromSlot = true;
            HideItemHover();

            if (_icon != null)
                _icon.color = new Color(1f, 1f, 1f, 0.5f);

            _inventoryUI.StartDragFromEquipmentSlot(this, eventData);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!_isDraggingFromSlot || _inventoryUI == null) return;
            _inventoryUI.UpdateDragGhostPosition(eventData);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (!_isDraggingFromSlot) return;

            _isDraggingFromSlot = false;

            if (_icon != null)
                _icon.color = Color.white;

            _inventoryUI?.EndDragFromEquipmentSlot();
        }

        #endregion

        #region Item Management

        public void OnDropItem(InventoryItem item)
        {
#if UNITY_EDITOR
            Debug.Assert(item?.Data != null, $"[EquipmentSlot] OnDropItem called with invalid item data");
#endif
            if (!ValidateItemForSlot(item))
            {
                TriggerDropFeedback(false);
                return;
            }

            _equippedItem = item;
            Refresh();
            OnDropAccepted?.Invoke(this);
        }

        public bool ValidateItemForSlot(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;

            return _slotType switch
            {
                EquipmentSlotType.Primary => item.Type == ItemType.Weapon && !item.Data.IsPistol && !item.Data.IsMelee,
                EquipmentSlotType.Pistol => item.Type == ItemType.Weapon && item.Data.IsPistol,
                EquipmentSlotType.Melee => item.Data.IsMelee,
                EquipmentSlotType.Backpack => item.Data.IsBackpack,
                _ => false
            };
        }

        public bool CanAcceptItemPreview(InventoryItem item)
        {
            if (IsOccupied) return false;
            return ValidateItemForSlot(item);
        }

        public void UpdateDropPreview(InventoryItem item, bool isValid)
        {
            if (_highlight == null || !_highlight.enabled) return;
            _isDraggingOver = true;
            _highlight.color = isValid ? COLOR_VALID_DROP : COLOR_INVALID_DROP;
            _highlight.enabled = true;
            OnValidDropPreview?.Invoke(this, isValid ? item : null);
        }

        public void ClearDropPreview()
        {
            _isDraggingOver = false;
            if (_highlight != null && _highlight.enabled)
                _highlight.color = _isHovering ? COLOR_HOVER : Color.clear;
        }

        public void Refresh()
        {
            if (_icon == null) return;

            // ФИКС v8: В слоте экипировки рюкзак ВСЕГДА показывает РАЗВЁРНУТУЮ иконку (Data.Icon),
            // независимо от IsFolded. Слот — это визуальное представление надетого рюкзака.
            // IsFolded влияет только на то, доступна ли внутренняя сетка рюкзака (через ПКМ → Открыть).
            Sprite displayIcon = null;
            if (_equippedItem != null)
            {
                if (_equippedItem.Data != null && _equippedItem.Data.IsBackpack && _equippedItem.CanFold)
                    displayIcon = _equippedItem.Data.Icon; // всегда развёрнутая
                else
                    displayIcon = _equippedItem.CurrentIcon;
            }

            bool hasItem = displayIcon != null;

            if (hasItem)
            {
                _icon.sprite = displayIcon;
                _icon.enabled = true;
                _icon.color = Color.white;

                // ФИКС v3: Поворот иконки зависит от типа слота.
                // - Primary (оружие): -90° — винтовка вертикально
                // - Pistol / Melee / Backpack: 0° — не вращаем
                float iconRotation = _slotType switch
                {
                    EquipmentSlotType.Primary => -90f,
                    EquipmentSlotType.Pistol => 0f,
                    EquipmentSlotType.Melee => 0f,
                    EquipmentSlotType.Backpack => 0f,
                    _ => 0f
                };

                if (_icon.rectTransform != null)
                    _icon.rectTransform.localRotation = Quaternion.Euler(0f, 0f, iconRotation);
                _icon.preserveAspect = true;

                if (_label != null)
                {
                    _label.gameObject.SetActive(true);
                    _label.color = Color.white;
                }

                if (_isHovering && !_isDraggingFromSlot)
                    ShowItemHover();
                else
                    HideItemHover();
            }
            else
            {
                // Пустой слот — показываем силуэт если есть
                if (_emptySlotSprite != null)
                {
                    _icon.sprite = _emptySlotSprite;
                    _icon.enabled = true;
                    _icon.color = _emptySlotColor;
                    if (_icon.rectTransform != null)
                        _icon.rectTransform.localRotation = Quaternion.Euler(0f, 0f, _emptySlotRotation);
                    _icon.preserveAspect = true;
                }
                else
                {
                    _icon.sprite = null;
                    _icon.enabled = false;
                    _icon.color = Color.white;
                }

                if (_label != null)
                {
                    _label.gameObject.SetActive(true);
                    _label.color = Color.white;
                }
                if (_highlight != null)
                {
                    _highlight.enabled = _isHovering || _isDraggingOver;
                    _highlight.color = _isDraggingOver ? COLOR_VALID_DROP : (_isHovering ? COLOR_HOVER : Color.clear);
                }
            }
        }

        public void SetEquippedItem(InventoryItem item)
        {
            _equippedItem = item;
            Refresh();

            // ФИКС БАГ (audit) #4: помечаем ISaveable (K_InventoryUI) как dirty,
            // чтобы SaveManager знал, что нужно сохранить экипировку при F5.
            if (_inventoryUI is K_Incident.Core.ISaveable saveable)
                saveable.IsDirty = true;
        }

        private void OnDestroy()
        {
            if (_flashErrorCoroutine != null) StopCoroutine(_flashErrorCoroutine);
            if (_hoverThrottleCoroutine != null) StopCoroutine(_hoverThrottleCoroutine);
            if (_dropFeedbackCoroutine != null) StopCoroutine(_dropFeedbackCoroutine);
        }

        #endregion

        #region Item Hover Overlay

        private void EnsureItemHoverOverlay()
        {
            if (_itemHoverOverlay != null) return;

            var obj = new GameObject("ItemHoverOverlay", typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(transform, false);
            obj.transform.SetAsLastSibling();

            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = Vector2.zero;

            _itemHoverOverlay = obj.GetComponent<Image>();
            _itemHoverOverlay.sprite = null;
            _itemHoverOverlay.type = Image.Type.Simple;
            _itemHoverOverlay.color = Color.clear;
            _itemHoverOverlay.raycastTarget = false;
        }

        private void ShowItemHover()
        {
            if (_itemHoverOverlay == null) return;
            _itemHoverOverlay.transform.SetAsLastSibling();
            _itemHoverOverlay.color = _itemHoverColor;
        }

        private void HideItemHover()
        {
            if (_itemHoverOverlay == null) return;
            _itemHoverOverlay.color = Color.clear;
        }

        #endregion

        #region Editor Helpers

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (_highlight == null)
                _highlight = transform.Find("Highlight")?.GetComponent<Image>();
        }
#endif

        #endregion
    }
}














