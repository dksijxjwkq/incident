﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Debug_UIInteraction : MonoBehaviour,
    IPointerEnterHandler,
    IPointerExitHandler,
    IPointerDownHandler,
    IPointerUpHandler,
    IPointerClickHandler
{
    [Header("Debug Settings")]
    [SerializeField] private bool _verboseLogs = true;

    private Graphic _graphic;
    private CanvasGroup _canvasGroup;

    private void Awake()
    {
        _graphic = GetComponent<Graphic>();
        _canvasGroup = GetComponent<CanvasGroup>();

        Debug.Log($"[DEBUG] UI Item AWAKE: {gameObject.name}");
        Debug.Log($"[DEBUG]   - Graphic enabled: {_graphic?.enabled}");
        Debug.Log($"[DEBUG]   - Raycast Target: {_graphic?.raycastTarget}");
        Debug.Log($"[DEBUG]   - CanvasGroup: {_canvasGroup != null}");
        if (_canvasGroup != null)
        {
            Debug.Log($"[DEBUG]   - CG Interactable: {_canvasGroup.interactable}");
            Debug.Log($"[DEBUG]   - CG BlocksRaycasts: {_canvasGroup.blocksRaycasts}");
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        if (!_verboseLogs) return;
        Debug.Log($"[DEBUG] ✅ OnPointerEnter - Cursor OVER item");
        Debug.Log($"[DEBUG]   - Mouse Pos: {eventData.position}");
        Debug.Log($"[DEBUG]   - Pointer ID: {eventData.pointerId}");
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        if (!_verboseLogs) return;
        Debug.Log($"[DEBUG] ❌ OnPointerExit - Cursor LEFT item");
    }

    public void OnPointerDown(PointerEventData eventData)
    {
        if (!_verboseLogs) return;
        Debug.Log($"[DEBUG] 🖱️ OnPointerDown - Mouse BUTTON DOWN");
        Debug.Log($"[DEBUG]   - Button: {eventData.button}");
        Debug.Log($"[DEBUG]   - Press Position: {eventData.pressPosition}");
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        if (!_verboseLogs) return;
        Debug.Log($"[DEBUG] 🖱️ OnPointerUp - Mouse BUTTON UP");
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        if (!_verboseLogs) return;
        Debug.Log($"[DEBUG] 👆 OnPointerClick - CLICK detected");
    }

    [ContextMenu("Test Raycast")]
    public void TestRaycast()
    {
        Debug.Log($"=== RAYCAST TEST ===");
        Debug.Log($"Graphic: {_graphic != null}");
        Debug.Log($"Raycast Target: {_graphic?.raycastTarget}");
        Debug.Log($"CanvasGroup: {_canvasGroup != null}");
        Debug.Log($"Layer: {LayerMask.LayerToName(gameObject.layer)}");
        Debug.Log($"Active: {gameObject.activeInHierarchy}");

        // Проверка EventSystem
        var es = EventSystem.current;
        if (es == null)
            Debug.LogError("❌ EventSystem NOT FOUND in scene!");
        else
        {
            Debug.Log($"✅ EventSystem found: {es.gameObject.name}");
            Debug.Log($"   - Current Module: {es.currentInputModule?.GetType().Name}");
        }
    }
}
