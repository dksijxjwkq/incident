﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;
using System;
using System.Collections;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Главный UI-контроллер инвентаря.
    /// Управляет сетками (карманы, рюкзак, контейнер окружения), drag&amp;drop, пулом UI_Item.
    /// 
    /// ИСПРАВЛЕНИЯ (баг-фикс сессия):
    /// #БАГ2: GetSlotAt/GetGridWidth для Container использовали controller.Width
    ///        вместо реальных размеров UI-сетки → неправильный индекс слота →
    ///        жёлтая подсветка на неверных ячейках. Добавлены _currentContainerCols/Rows.
    ///        Также CalculateSnapPosition в UpdateDragCellHighlights и GetAdjustedDropPosition
    ///        исправлены на использование GetGridWidth/Height.
    /// #БАГ1: Предметы в контейнере окружения улетали за пределы сетки / зависали.
    ///        Причины: (1) SyncContainer передавал world-координату как screen-координату
    ///        в ScreenPointToLocalPointInRectangle — неверно для ScreenSpaceCamera Canvas.
    ///        (2) SyncRectTransform на itemsContainer каждый кадр перезаписывал позицию
    ///        с неправильными anchors (center вместо top-left).
    ///        (3) Репарентинг itemsContainer ломал иерархию.
    ///        Исправление: SyncContainer переписан на world-space через InverseTransformPoint
    ///        с фиксированными top-left anchors. SyncRectTransform отключается.
    /// #БАГ3: слоты блокировали raycast к предметам. Исправление: toggle raycast на
    ///        слотах — false в покое, true при drag.
    /// </summary>
    public class K_InventoryUI : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Grid Config")]
        [SerializeField, Tooltip("Размер слота в пикселях")]
        private float _slotSize = 70f;

        [SerializeField, Tooltip("Отступ между слотами")]
        private float _slotSpacing = 0f;

        [Header("References")]
        [SerializeField] private K_InventorySetup _inventorySetup;
        [SerializeField] private TextMeshProUGUI _weightText;
        [SerializeField] private GameObject _slotPrefab;
        [SerializeField] private GameObject _uiItemPrefab;
        [SerializeField] private GameObject _dragGhostPrefab;

        [Header("Player Inventory (LEFT PANE)")]
        [SerializeField] private Transform _pocketsGrid;
        [SerializeField] private Transform _pocket2Grid;
        [SerializeField] private Transform _backpackGrid;
        [SerializeField] private GameObject _backpackPanel;
        [SerializeField] private Transform _pocketsItemsContainer;
        [SerializeField] private Transform _pocket2ItemsContainer;
        [SerializeField] private Transform _backpackItemsContainer;

        [Header("Equipment Slots")]
        [SerializeField] private K_EquipmentSlotUI _primarySlot1;
        [SerializeField] private K_EquipmentSlotUI _primarySlot2;
        [SerializeField] private K_EquipmentSlotUI _pistolSlot;
        [SerializeField] private K_EquipmentSlotUI _backpackSlot;

        [Header("Surroundings/Container (RIGHT PANE)")]
        [SerializeField] private GameObject _surroundingsPanel;
        [SerializeField] private Transform _surroundingsGrid;
        [SerializeField] private Transform _surroundingsItemsContainer;
        [SerializeField] private TextMeshProUGUI _containerNameText;

        [Header("Background")]
        [SerializeField, Tooltip("Объект с фоном инвентаря (Image). Raycast Target должен быть снят.")]
        private GameObject _inventoryBackground;

        [Header("Configuration")]
        [SerializeField] private KeyCode _openCloseKey = KeyCode.Tab;
        [SerializeField] private KeyCode _rotateKey = KeyCode.R;

        [Header("UI Colors")]
        [SerializeField] private Color _dragValidColor = new Color(0.33f, 0.55f, 0.33f, 0.7f);
        [SerializeField] private Color _dragInvalidColor = new Color(0.71f, 0.24f, 0.24f, 0.7f);
        [SerializeField] private Color _textNormalColor = new Color(0.71f, 0.73f, 0.75f);
        [SerializeField] private Color _textWarningColor = new Color(0.71f, 0.55f, 0.24f);
        [SerializeField] private Color _textCriticalColor = new Color(0.71f, 0.24f, 0.24f);

        [Header("Hover Highlight")]
        [SerializeField, Tooltip("Включить выделение предмета при наведении")]
        private bool _enableHoverHighlight = true;

        [Header("Occupied Cell Tint")]
        [SerializeField, Tooltip("Тонировка ячеек, занятых предметом. alpha=0 → выключено.")]
        private Color _occupiedCellTint = new Color(1f, 1f, 1f, 0f); // белая, но alpha=0 → невидимо

        [Header("Internal Border Hiders")]
        [SerializeField, Tooltip("Цвет перекрытия внутренних границ. Подбери под цвет фона ячейки.")]
        private Color _borderHiderColor = new Color(0.12f, 0.12f, 0.12f, 1f);
        [SerializeField, Tooltip("Толщина перекрытия границы (px). Ширина вертикальной / высота горизонтальной линии.")]
        private float _borderHiderThickness = 3f;

        [Header("Border Hider Inset (отступы от краёв ячейки)")]
        [SerializeField, Tooltip("Отступ сверху для вертикальных hider'ов. Отрицательное = выходит за верх ячейки.")]
        private float _bhInsetTop = 1f;
        [SerializeField, Tooltip("Отступ снизу для вертикальных hider'ов. Отрицательное = выходит за низ ячейки.")]
        private float _bhInsetBottom = 1f;
        [SerializeField, Tooltip("Отступ слева для горизонтальных hider'ов. Отрицательное = выходит за левый край.")]
        private float _bhInsetLeft = 1f;
        [SerializeField, Tooltip("Отступ справа для горизонтальных hider'ов. Отрицательное = выходит за правый край.")]
        private float _bhInsetRight = 1f;

        [Header("Grid Bottom Border Fix (PP)")]
        [SerializeField, Tooltip("Цвет нарисованной нижней границы. Подбери под цвет рамок ячеек.")]
        private Color _gridBottomBorderColor = new Color(0.3f, 0.3f, 0.3f, 1f);
        [SerializeField, Tooltip("Толщина нарисованной нижней границы (px).")]
        private float _gridBottomBorderHeight = 1f;
        [SerializeField, Tooltip("Сдвиг границы вверх от математического низа (px). Увеличь если линия обрезается.")]
        private float _gridBottomBorderOffset = 1f;

        [Header("Drag Outline Highlight")]
        [SerializeField, Tooltip("Цвет рамки при валидной позиции drag")]
        private Color _dragOutlineValidColor = new Color(1f, 0.85f, 0f, 0.8f);
        [SerializeField, Tooltip("Цвет рамки при невалидной позиции drag")]
        private Color _dragOutlineInvalidColor = new Color(0.85f, 0.15f, 0.15f, 0.8f);
        [SerializeField, Tooltip("Толщина рамки подсветки при drag (px)")]
        private float _dragOutlineThickness = 2f;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = true;

        /// <summary>Публичный доступ к флагу дебаг-логов (используется в UI_Item).</summary>
        public bool DebugLogs => _debugLogs;

        #endregion

        #region Constants

        private const int POCKET_COLUMNS = 2;
        private const int POCKET_ROWS = 2;
        private const int BACKPACK_BASE_COLS = 8;
        private const int BACKPACK_BASE_ROWS = 10;

        private const int POOL_PREWARM_COUNT = 100;
        private const float UI_REFRESH_THROTTLE = 0.3f;
        private const int GHOST_SORTING_ORDER = 32000;
        private const float DROP_FALLBACK_DELAY = 0.05f;

        private const float WEIGHT_WARNING_RATIO = 0.9f;
        private const float WEIGHT_CRITICAL_RATIO = 1.1f;

        #endregion

        #region Fields

        private InventoryController _pocketsController;
        private InventoryController _pocket2Controller;
        private InventoryController _backpackController;
        private InventoryController _activeContainerController;
        private CanvasGroup _canvasGroup;

        [SerializeField] private K_PlayerMotor _playerMotor;

        private bool _isOpen;
        private bool _isLootingContainer;
        private bool _pendingRefresh;
        private float _lastRefreshTime;

        private bool _isDragging;
        private UI_Item _draggedItem;
        private GameObject _dragGhost;
        private Image _dragGhostImage;
        private RectTransform _dragGhostIconRect;
        private TextMeshProUGUI _dragGhostNameText; // Название предмета на drag ghost
        private TextMeshProUGUI _dragGhostCaliberText; // Калибр на drag ghost
        private CanvasGroup _dragGhostCanvasGroup;
        private Canvas _dragGhostCanvas;
        private RectTransform _dragGhostRT;
        private Transform _rootCanvasTransform;
        private UnityEngine.Camera _rootCanvasCamera; // ИСПРАВЛЕНИЕ БАГ 2: кэш камеры для правильной конверсии координат
        private readonly List<RaycastResult> _raycastBuffer = new List<RaycastResult>(8);

        // Border hider pool
        private readonly Queue<GameObject> _borderHiderPool = new Queue<GameObject>();
        private readonly List<GameObject> _activeBorderHiders = new List<GameObject>();
        private PointerEventData _cachedEventData;

        private K_EquipmentSlotUI _draggedFromEquipmentSlot;
        private InventoryItem _draggedFromSlotItem;

        // Hover
        private UI_Item _hoveredItem;

        // Drag outline frame (border highlight)
        private GameObject _dragOutlineFrame;
        private Image _outlineTop, _outlineBottom, _outlineLeft, _outlineRight;
        private Transform _outlineCurrentParent;
        private Color _outlineLastColor = Color.clear;

        // Drag state: origin (for fallback on cancel)
        private GridType _dragOriginGridType;
        private int _dragOriginX, _dragOriginY;
        private int _dragOriginRotationAngle;
        private bool _dragItemRemoved;
        private bool _dropHandled;
        private Image _dragGhostRootImage;

        private Vector2 _pocketsGridPadding = Vector2.zero;
        private Vector2 _pocket2GridPadding = Vector2.zero;
        private Vector2 _backpackGridPadding = Vector2.zero;
        private Vector2 _containerGridPadding = Vector2.zero;

        // ФИКС БАГ #4: Храним реальные размеры рюкзака
        private int _currentBackpackCols = BACKPACK_BASE_COLS;
        private int _currentBackpackRows = BACKPACK_BASE_ROWS;

        // ФИКС БАГ #2+3: Храним реальные размеры UI-сетки контейнера окружения.
        // Без этого GetSlotAt использует controller.Width, который может
        // не совпадать с width, переданным в RebuildSurroundingsGrid →
        // неправильный индекс слота → жёлтая подсветка на неверных ячейках.
        private int _currentContainerCols;
        private int _currentContainerRows;

        // ФИКС БАГ #6: Фоллбэк для refresh после неудачного drop
        private bool _needsPostDragRefresh;
        private Coroutine _postDragRefreshCoroutine;

        private readonly Queue<UI_Item> _itemPool = new Queue<UI_Item>(POOL_PREWARM_COUNT);
        private readonly Dictionary<string, UI_Item> _activeItems = new Dictionary<string, UI_Item>(200);

        private Action _onInventoryChangedHandler;
        private Action<float> _onWeightChangedHandler;
        private Action<InventoryItem, int, int> _onItemPlacedHandler;
        private Action<InventoryItem> _onItemChangedHandler;

        private Coroutine _refreshCoroutine;

        public static event Action<InventoryController> OnContainerClosed;

        #endregion

        #region Properties

        public bool IsOpen => _isOpen;
        public bool IsLooting => _isLootingContainer;
        public bool IsDragging => _isDragging;
        public float SlotSize => _slotSize;
        public float SlotSpacing => _slotSpacing;

        public bool IsDraggingFromEquipmentSlot => _draggedFromEquipmentSlot != null && _draggedFromSlotItem != null;
        public InventoryItem DraggedFromSlotItem => _draggedFromSlotItem;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null) _canvasGroup = gameObject.AddComponent<CanvasGroup>();
            InitializeCanvasState();

            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(false);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(false);

            _rootCanvasTransform = FindRootCanvas();

            if (_dragGhostPrefab != null)
            {
                _dragGhost = Instantiate(_dragGhostPrefab);
                _dragGhost.SetActive(false);

                RectTransform prefabRT = _dragGhost.GetComponent<RectTransform>();
                Image prefabImage = _dragGhost.GetComponent<Image>();
                _dragGhostRT = prefabRT;

                if (prefabImage != null)
                {
                    _dragGhostRootImage = prefabImage;
                    _dragGhostImage = CreateChildIcon(_dragGhostRT, prefabImage);
                    _dragGhostIconRect = _dragGhostImage.rectTransform;
                    prefabImage.enabled = false;
                    prefabImage.raycastTarget = false;
                }
                else
                {
                    Debug.LogError("[InventoryUI] DragGhost Prefab MISSING Image on root!");
                    _dragGhost = null;
                }

                if (_dragGhostRT != null && _dragGhostImage != null)
                {
                    _dragGhostImage.raycastTarget = false;
                    _dragGhostImage.color = Color.white;
                    _dragGhostImage.enabled = true;

                    _dragGhostCanvasGroup = _dragGhost.GetComponent<CanvasGroup>();
                    if (_dragGhostCanvasGroup == null)
                        _dragGhostCanvasGroup = _dragGhost.AddComponent<CanvasGroup>();
                    _dragGhostCanvasGroup.blocksRaycasts = false;
                    _dragGhostCanvasGroup.interactable = false;
                    _dragGhostCanvasGroup.alpha = 1f;

                    _dragGhostCanvas = _dragGhost.GetComponent<Canvas>();
                    if (_dragGhostCanvas == null)
                        _dragGhostCanvas = _dragGhost.AddComponent<Canvas>();
                    _dragGhostCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                    _dragGhostCanvas.overrideSorting = true;
                    _dragGhostCanvas.sortingOrder = GHOST_SORTING_ORDER;

                    if (_rootCanvasTransform != null)
                        _dragGhost.transform.SetParent(_rootCanvasTransform, false);
                    else
                        _dragGhost.transform.SetParent(transform.root, false);

                    // Создаём текст названия для drag ghost (слева снизу)
                    var ghostLabelObj = new GameObject("GhostName", typeof(RectTransform), typeof(TextMeshProUGUI));
                    ghostLabelObj.transform.SetParent(_dragGhostRT, false);
                    var ghostLabelRT = ghostLabelObj.GetComponent<RectTransform>();
                    ghostLabelRT.anchorMin = new Vector2(0f, 0.5f);
                    ghostLabelRT.anchorMax = new Vector2(1f, 0.5f);
                    ghostLabelRT.pivot = new Vector2(0f, 1f);
                    ghostLabelRT.anchoredPosition = new Vector2(2f, 0f);
                    ghostLabelRT.sizeDelta = new Vector2(-4f, 12f);
                    ghostLabelRT.localScale = Vector3.one;

                    _dragGhostNameText = ghostLabelObj.GetComponent<TextMeshProUGUI>();
                    _dragGhostNameText.fontSize = 10f;
                    _dragGhostNameText.color = new Color(1f, 1f, 1f, 0.85f);
                    _dragGhostNameText.alignment = TextAlignmentOptions.Left;
                    _dragGhostNameText.verticalAlignment = VerticalAlignmentOptions.Top;
                    _dragGhostNameText.raycastTarget = false;
                    _dragGhostNameText.overflowMode = TextOverflowModes.Truncate;
                    _dragGhostNameText.textWrappingMode = TextWrappingModes.NoWrap;
                    _dragGhostNameText.fontStyle = FontStyles.Bold;
                    var ghostShadow = ghostLabelObj.AddComponent<Shadow>();
                    ghostShadow.effectColor = new Color(0f, 0f, 0f, 0.7f);
                    ghostShadow.effectDistance = new Vector2(1f, -1f);

                    // Создаём текст калибра для drag ghost (под названием)
                    var ghostCalObj = new GameObject("GhostCaliber", typeof(RectTransform), typeof(TextMeshProUGUI));
                    ghostCalObj.transform.SetParent(_dragGhostRT, false);
                    var ghostCalRT = ghostCalObj.GetComponent<RectTransform>();
                    ghostCalRT.anchorMin = new Vector2(0f, 0f);
                    ghostCalRT.anchorMax = new Vector2(1f, 0f);
                    ghostCalRT.pivot = new Vector2(0f, 0f);
                    ghostCalRT.anchoredPosition = new Vector2(2f, 2f);
                    ghostCalRT.sizeDelta = new Vector2(-4f, 11f);
                    ghostCalRT.localScale = Vector3.one;

                    _dragGhostCaliberText = ghostCalObj.GetComponent<TextMeshProUGUI>();
                    _dragGhostCaliberText.fontSize = 9f;
                    _dragGhostCaliberText.color = new Color(1f, 1f, 1f, 0.6f);
                    _dragGhostCaliberText.alignment = TextAlignmentOptions.Left;
                    _dragGhostCaliberText.verticalAlignment = VerticalAlignmentOptions.Bottom;
                    _dragGhostCaliberText.raycastTarget = false;
                    _dragGhostCaliberText.overflowMode = TextOverflowModes.Truncate;
                    _dragGhostCaliberText.textWrappingMode = TextWrappingModes.NoWrap;
                    var ghostCalShadow = ghostCalObj.AddComponent<Shadow>();
                    ghostCalShadow.effectColor = new Color(0f, 0f, 0f, 0.7f);
                    ghostCalShadow.effectDistance = new Vector2(1f, -1f);
                }
            }

            // ФИКС БАГ #7: НЕ создаём _cachedEventData здесь.
            // Он будет создан лениво в UpdateDragCellHighlights() с правильным EventSystem.

            PreWarmPool(POOL_PREWARM_COUNT);
            DisableLayoutOnItemContainers();
            SetupItemsContainerRaycasts();
            SetupBackgroundRaycast();

            // ═══════════════════════════════════════════════════════════════
            // ИСПРАВЛЕНИЕ БАГ 3: Items containers ВЫШЕ grid'ов в иерархии
            // Без этого слоты сетки (с raycastTarget Image) блокируют
            // клики по предметам, лежащим в itemsContainer.
            // ═══════════════════════════════════════════════════════════════
            if (_pocketsItemsContainer != null && _pocketsGrid != null)
                _pocketsItemsContainer.SetAsLastSibling();
            if (_pocket2ItemsContainer != null && _pocket2Grid != null)
                _pocket2ItemsContainer.SetAsLastSibling();
            if (_backpackItemsContainer != null && _backpackGrid != null)
                _backpackItemsContainer.SetAsLastSibling();
            if (_surroundingsItemsContainer != null && _surroundingsGrid != null)
                _surroundingsItemsContainer.SetAsLastSibling();
        }

        private void Start()
        {
            if (!InitializeReferences())
            {
                enabled = false;
                return;
            }

            if (_playerMotor == null)
                _playerMotor = FindFirstObjectByType<K_PlayerMotor>();

            BuildAllGrids();
            SubscribeToEvents();
            UpdateWeightDisplay(0f);
            ForceRefresh();
        }

        private void Update()
        {
            if (Input.GetKeyDown(_openCloseKey)) ToggleInventory();

            if (_isDragging)
            {
                if (Input.GetKeyDown(_rotateKey))
                    RotateDraggedItem();
            }
        }

        private void OnDestroy()
        {
            UnsubscribeFromEvents();
            UnsubscribeFromContainerEvents();
            ClearPooledItems();
            if (_dragGhost != null) Destroy(_dragGhost);
        }

        #endregion

        #region Initialization

        private Transform FindRootCanvas()
        {
            var parentCanvas = GetComponentInParent<Canvas>();
            if (parentCanvas != null)
            {
                while (parentCanvas.transform.parent != null && parentCanvas.transform.parent.GetComponent<Canvas>() != null)
                    parentCanvas = parentCanvas.transform.parent.GetComponent<Canvas>();
                // ИСПРАВЛЕНИЕ БАГ 2: кэшируем камеру корневого Canvas
                _rootCanvasCamera = parentCanvas.renderMode == RenderMode.ScreenSpaceCamera
                    ? parentCanvas.worldCamera : null;
                return parentCanvas.transform;
            }
            var fallback = FindFirstObjectByType<Canvas>();
            if (fallback != null)
                _rootCanvasCamera = fallback.renderMode == RenderMode.ScreenSpaceCamera
                    ? fallback.worldCamera : null;
            return fallback?.transform;
        }

        private void InitializeCanvasState()
        {
            _canvasGroup.alpha = 0f;
            _canvasGroup.interactable = false;
            _canvasGroup.blocksRaycasts = false;
        }

        private Image CreateChildIcon(RectTransform parent, Image source)
        {
            var childObj = new GameObject("GhostIcon", typeof(RectTransform), typeof(Image));
            childObj.transform.SetParent(parent, false);

            var childRT = childObj.GetComponent<RectTransform>();
            childRT.anchorMin = new Vector2(0.5f, 0.5f);
            childRT.anchorMax = new Vector2(0.5f, 0.5f);
            childRT.pivot = new Vector2(0.5f, 0.5f);
            childRT.anchoredPosition = Vector2.zero;
            childRT.localScale = Vector3.one;
            childRT.localRotation = Quaternion.identity;

            var childImage = childObj.GetComponent<Image>();
            childImage.sprite = source.sprite;
            childImage.color = Color.white;
            childImage.type = source.type;
            childImage.preserveAspect = false;
            childImage.raycastTarget = false;
            childImage.enabled = true;

            return childImage;
        }

        private void SetupItemsContainerRaycasts()
        {
            var containers = new[] { _pocketsItemsContainer, _pocket2ItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                // Отключаем raycast на самом контейнере (чтобы он не блокировал предметы)
                var graphic = container.GetComponent<Graphic>();
                if (graphic != null) graphic.raycastTarget = false;
                // CanvasGroup.blocksRaycasts ДОЛЖЕН быть true — иначе дети не получают raycast
                var cg = container.GetComponent<CanvasGroup>();
                if (cg != null) cg.blocksRaycasts = true;
            }
        }

        private void SetupBackgroundRaycast()
        {
            if (_inventoryBackground != null)
            {
                var bgGraphic = _inventoryBackground.GetComponent<Graphic>();
                if (bgGraphic != null) bgGraphic.raycastTarget = false;
            }
        }

        private bool InitializeReferences()
        {
            if (_inventorySetup == null)
                _inventorySetup = FindFirstObjectByType<K_InventorySetup>();

            _pocketsController = _inventorySetup?.PocketsController;
            _pocket2Controller = _inventorySetup?.Pocket2Controller;
            _backpackController = _inventorySetup?.BackpackController;

            if (_pocketsController == null || _pocket2Controller == null || _backpackController == null)
            {
                Debug.LogError("[InventoryUI] Controllers are null! Check K_InventorySetup.");
                return false;
            }
            return true;
        }

        private void PreWarmPool(int count)
        {
            if (_uiItemPrefab == null) return;
            for (int i = 0; i < count; i++)
            {
                var item = CreateNewPooledItem();
                if (item != null) _itemPool.Enqueue(item);
            }
        }

        private UI_Item CreateNewPooledItem()
        {
            if (_uiItemPrefab == null) return null;
            var newItem = Instantiate(_uiItemPrefab, transform).GetComponent<UI_Item>();
            if (newItem == null) return null;
            newItem.gameObject.SetActive(false);
            var cg = newItem.GetComponent<CanvasGroup>();
            if (cg == null) cg = newItem.gameObject.AddComponent<CanvasGroup>();
            cg.alpha = 1f;
            cg.interactable = true;
            cg.blocksRaycasts = true;
            return newItem;
        }

        private void DisableLayoutOnItemContainers()
        {
            var containers = new[] { _pocketsItemsContainer, _pocket2ItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                var grid = container.GetComponent<GridLayoutGroup>();
                if (grid != null) grid.enabled = false;
                foreach (var graphic in container.GetComponents<Graphic>())
                    graphic.raycastTarget = false;
            }
        }

        #endregion

        #region Grid Management

        private void BuildAllGrids()
        {
            BuildGrid(_pocketsGrid, POCKET_COLUMNS * POCKET_ROWS, POCKET_COLUMNS, GridType.Pockets);
            BuildGrid(_pocket2Grid, POCKET_COLUMNS * POCKET_ROWS, POCKET_COLUMNS, GridType.Pocket2);
            if (_backpackGrid != null && _backpackPanel != null)
                RebuildBackpackGrid(BACKPACK_BASE_COLS, BACKPACK_BASE_ROWS);
            SetupEquipmentSlots();
        }

        private void SetupEquipmentSlots()
        {
            _primarySlot1?.Initialize(this, EquipmentSlotType.Primary);
            _primarySlot2?.Initialize(this, EquipmentSlotType.Primary);
            _pistolSlot?.Initialize(this, EquipmentSlotType.Pistol);
            _backpackSlot?.Initialize(this, EquipmentSlotType.Backpack);
        }

        private void BuildGrid(Transform parent, int slotCount, int columns, GridType gridType)
        {
            if (parent == null || _slotPrefab == null) return;
            ClearGrid(parent);
            SetupGridLayout(parent, columns);
            CacheGridLayoutPadding(parent, gridType);

            for (int i = 0; i < slotCount; i++)
            {
                var slot = Instantiate(_slotPrefab, parent);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % columns;
                    int y = i / columns;
                    slotUI.Setup(x, y, gridType, this);
                }
            }
            // Явно выставляем размер сетки, чтобы он соответствовал количеству слотов,
            // а не старому размеру из префаба (например 280 для 2×4 вместо 140 для 2×2).
            // Сохраняем мировую позицию top-left угла, чтобы сетка не прыгнула после смены anchors.
            var gridRT = parent.GetComponent<RectTransform>();
            var gridLayout = parent.GetComponent<GridLayoutGroup>();
            if (gridLayout != null && gridRT != null)
            {
                Vector3[] corners = new Vector3[4];
                gridRT.GetWorldCorners(corners);
                Vector3 savedWorldTopLeft = corners[1];

                int rows = Mathf.CeilToInt((float)slotCount / columns);
                float padLeft = gridLayout.padding.left;
                float padRight = gridLayout.padding.right;
                float padTop = gridLayout.padding.top;
                float padBot = gridLayout.padding.bottom;
                float w = padLeft + columns * _slotSize + (columns - 1) * _slotSpacing + padRight;
                float h = padTop + rows * _slotSize + (rows - 1) * _slotSpacing + padBot;
                gridRT.anchorMin = new Vector2(0f, 1f);
                gridRT.anchorMax = new Vector2(0f, 1f);
                gridRT.pivot = new Vector2(0f, 1f);
                gridRT.sizeDelta = new Vector2(w, h);

                // Восстанавливаем позицию top-left угла в новом anchor-пространстве
                if (gridRT.parent != null)
                {
                    Vector2 localTL = gridRT.parent.InverseTransformPoint(savedWorldTopLeft);
                    RectTransform pr = gridRT.parent as RectTransform;
                    if (pr != null) localTL -= new Vector2(pr.rect.xMin, pr.rect.yMax);
                    gridRT.anchoredPosition = localTL;
                }
            }
            LayoutRebuilder.ForceRebuildLayoutImmediate(parent.GetComponent<RectTransform>());
            DrawGridBottomBorder(parent, columns, slotCount / columns, GetPaddingForGrid(gridType));
        }

        private Vector2 GetPaddingForGrid(GridType type) => type switch
        {
            GridType.Pockets => _pocketsGridPadding,
            GridType.Pocket2 => _pocket2GridPadding,
            GridType.Backpack => _backpackGridPadding,
            GridType.Container => _containerGridPadding,
            _ => Vector2.zero
        };

        private void CacheGridLayoutPadding(Transform grid, GridType gridType)
        {
            if (grid == null) return;

            var layout = grid.GetComponent<GridLayoutGroup>();
            if (layout != null)
            {
                Vector2 padding = new Vector2(layout.padding.left, layout.padding.top);

                switch (gridType)
                {
                    case GridType.Pockets: _pocketsGridPadding = padding; break;
                    case GridType.Pocket2: _pocket2GridPadding = padding; break;
                    case GridType.Backpack: _backpackGridPadding = padding; break;
                    case GridType.Container: _containerGridPadding = padding; break;
                }
            }
        }

        private void ClearGrid(Transform parent)
        {
            if (parent == null) return;
            for (int i = parent.childCount - 1; i >= 0; i--)
                Destroy(parent.GetChild(i).gameObject);
        }

        private void SetupGridLayout(Transform parent, int columns)
        {
            var grid = parent.GetComponent<GridLayoutGroup>();
            if (grid == null) grid = parent.gameObject.AddComponent<GridLayoutGroup>();
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = columns;
            grid.cellSize = new Vector2(_slotSize, _slotSize);
            grid.spacing = new Vector2(_slotSpacing, _slotSpacing);
            grid.childAlignment = TextAnchor.UpperLeft;
        }

        /// <summary>
        /// Рисует нижнюю границу сетки отдельной линией (поверх слотов).
        /// Нужна потому что Pixel Perfect на Canvas обрезает нижнюю рамку спрайтов.
        /// </summary>
        private void DrawGridBottomBorder(Transform grid, int columns, int rows, Vector2 padding)
        {
            if (grid == null || columns <= 0 || rows <= 0) return;

            // Удаляем старую линию если есть
            Transform existing = grid.Find("BottomBorderFix");
            if (existing != null) Destroy(existing);

            var obj = new GameObject("BottomBorderFix", typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(grid, false);
            obj.AddComponent<LayoutElement>().ignoreLayout = true;

            float step = _slotSize + _slotSpacing;
            float lineWidth = columns * step;

            // Позиция: низ ячейковой области + offset вверх
            float posY = -(padding.y + rows * step) + _gridBottomBorderOffset;

            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(padding.x, posY);
            rt.sizeDelta = new Vector2(lineWidth, _gridBottomBorderHeight);
            rt.localScale = Vector3.one;

            var img = obj.GetComponent<Image>();
            img.color = _gridBottomBorderColor;
            img.raycastTarget = false;
            img.maskable = true;
        }

        #endregion

        #region UI Control

        public void ToggleInventory()
        {
            if (_isOpen) CloseAll();
            else OpenInventoryOnly();
        }

        private void OpenInventoryOnly()
        {
            _isOpen = true;
            SetCanvasActive(true);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(true);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
            ForceRefresh();
        }

        public void CloseAll()
        {
            // ФИКС БАГ #2: Отписываемся от событий контейнера
            UnsubscribeFromContainerEvents();
            ClearHover();
            CancelDrag();

            _isOpen = false;
            _isLootingContainer = false;
            _activeContainerController = null;

            SetCanvasActive(false);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(true);
            if (_backpackPanel != null) _backpackPanel.SetActive(false);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(false);
            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);

            ReturnAllItemsToPool();
            ReturnAllBorderHidersToPool();
            OnContainerClosed?.Invoke(_pocketsController);
        }

        /// <summary>
        /// Экстренная отмена drag (например, при закрытии инвентаря).
        /// Скрывает ghost (у которого свой Canvas ScreenSpaceOverlay),
        /// возвращает предмет на исходную позицию, очищает все drag-переменные.
        /// Без этого ghost зависает на экране после закрытия инвентаря.
        /// </summary>
        private void CancelDrag()
        {
            if (!_isDragging) return;

            // 1) Скрываем ghost — у него свой Canvas с overrideSorting,
            //    поэтому SetCanvasActive(false) на инвентаре его НЕ скрывает.
            if (_dragGhost != null)
                _dragGhost.SetActive(false);

            // 2) Возвращаем предмет в инвентарь-данные, если он был удалён
            //    из ячейки в начале drag'а (_dragItemRemoved = true).
            if (_draggedItem != null && _draggedItem.Item != null && _dragItemRemoved)
            {
                var item = _draggedItem.Item;
                var controller = GetControllerForGrid(_dragOriginGridType);
                if (controller != null)
                {
                    int placed = controller.TryPlaceItem(item, _dragOriginX, _dragOriginY);
                    if (placed == 0)
                        controller.TryPlaceItemInFirstFreeSlot(item);
                }
            }

            // 2b) Предмет из слота экипировки не удалялся при старте drag,
            //     он остаётся в слоте — просто очищаем ссылки ниже.

            // 3) Останавливаем ВСЕ отложенные корутины (и refresh, и post-drag).
            //    Без этого оставшийся RefreshNextFrame может запулить предметы
            //    после того как CloseAll уже скрыл панели.
            if (_postDragRefreshCoroutine != null)
            {
                StopCoroutine(_postDragRefreshCoroutine);
                _postDragRefreshCoroutine = null;
            }
            if (_refreshCoroutine != null)
            {
                StopCoroutine(_refreshCoroutine);
                _refreshCoroutine = null;
            }
            _pendingRefresh = false;

            // 4) Очищаем ВСЕ drag-переменные ДО ReturnAllItemsToPool,
            //    чтобы _draggedItem == null и предмет не был «защищён» от пула.
            _isDragging = false;
            _draggedItem = null;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _dragItemRemoved = false;
            _dropHandled = false;
            _needsPostDragRefresh = false;

            // 5) Сбрасываем визуальные подсветки слотов и raycast
            ClearDragCellHighlights();
            SetAllGridSlotsRaycast(false);
        }

        public void OpenContainer(InventoryController containerController, string containerName, int width, int height)
        {
            if (containerController == null) return;
            if (_isLootingContainer && _activeContainerController == containerController)
            {
                CloseAll();
                return;
            }

            // ФИКС БАГ #2: Отписываемся от событий СТАРОГО контейнера перед переключением
            UnsubscribeFromContainerEvents();

            _activeContainerController = containerController;
            _isLootingContainer = true;
            _isOpen = true;

            // Подписываемся на события НОВОГО контейнера
            SubscribeToContainerEvents();

            SetCanvasActive(true);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);

            // ========== ФИКС БАГ: Показываем инвентарь игрока при лутании ==========
            // Раньше при OpenContainer() активировался только _surroundingsPanel
            // (панель контейнера), но не инвентарь игрока (_backpackPanel, _inventoryBackground).
            // Из-за этого при открытии ящика видна была только панель лутания без инвентаря.
            if (_backpackPanel != null) _backpackPanel.SetActive(true);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
            // ====================================================================

            if (_surroundingsPanel != null)
            {
                _surroundingsPanel.SetActive(true);
                if (_containerNameText != null)
                {
                    _containerNameText.text = containerName;
                    // ИСПРАВЛЕНИЕ БАГ 2/3: ContainerName внутри ItemsContainer
                    // блокирует raycast к слотам сетки под ним
                    _containerNameText.raycastTarget = false;
                }
                RebuildSurroundingsGrid(width, height);
            }

            SetupBackgroundRaycast();
            ForceRefresh();
        }

        /// <summary>
        /// ФИКС БАГ #2: Подписка на события активного контейнера.
        /// </summary>
        private void SubscribeToContainerEvents()
        {
            if (_activeContainerController == null) return;
            _activeContainerController.OnInventoryChanged += _onInventoryChangedHandler;
            _activeContainerController.OnItemPlaced += _onItemPlacedHandler;
            _activeContainerController.OnItemRemoved += _onItemChangedHandler;
            _activeContainerController.OnItemRotated += _onItemChangedHandler;
            _activeContainerController.OnItemQuantityChanged += _onItemChangedHandler;
        }

        /// <summary>
        /// ФИКС БАГ #2: Отписка от событий активного контейнера.
        /// </summary>
        private void UnsubscribeFromContainerEvents()
        {
            if (_activeContainerController == null) return;
            _activeContainerController.OnInventoryChanged -= _onInventoryChangedHandler;
            _activeContainerController.OnItemPlaced -= _onItemPlacedHandler;
            _activeContainerController.OnItemRemoved -= _onItemChangedHandler;
            _activeContainerController.OnItemRotated -= _onItemChangedHandler;
            _activeContainerController.OnItemQuantityChanged -= _onItemChangedHandler;
        }

        private void SetCanvasActive(bool active)
        {
            if (_canvasGroup == null) return;
            _canvasGroup.alpha = active ? 1f : 0f;
            _canvasGroup.interactable = active;
            _canvasGroup.blocksRaycasts = active;
        }

        private void RebuildSurroundingsGrid(int width, int height)
        {
            if (_surroundingsGrid == null || _slotPrefab == null) return;

            // ФИКС БАГ #2: Запоминаем реальные размеры UI-сетки контейнера
            _currentContainerCols = width;
            _currentContainerRows = height;

            // ═══════════════════════════════════════════════════════════════
            // ФИКС: Сохраняем _surroundingsItemsContainer от уничтожения.
            // В первом вызове RebuildSurroundingsGrid он репарентится
            // внутрь _surroundingsGrid. При повторном вызове ClearGrid
            // уничтожает ВСЕХ детей grid'а — включая itemsContainer.
            // Сериализованная ссылка становится "мёртвой" → MissingReferenceException
            // и предметы контейнера не отображаются при повторном открытии.
            // ═══════════════════════════════════════════════════════════════
            if (_surroundingsItemsContainer != null)
                _surroundingsItemsContainer.SetParent(transform, false);

            ClearGrid(_surroundingsGrid);
            SetupGridLayout(_surroundingsGrid, width);
            CacheGridLayoutPadding(_surroundingsGrid, GridType.Container);

            for (int i = 0; i < width * height; i++)
            {
                var slot = Instantiate(_slotPrefab, _surroundingsGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % width;
                    int y = i / width;
                    slotUI.Setup(x, y, GridType.Container, this);
                }
            }

            // ФИКС БАГ СМЕЩЕНИЯ: Без ForceRebuildLayoutImmediate GridLayoutGroup
            // ещё не рассчитал реальные размеры ячеек. SyncContainer скопирует
            // нулевые/старые размеры → items container будет смещён относительно grid.
            var gridRect = _surroundingsGrid.GetComponent<RectTransform>();
            if (gridRect != null)
                LayoutRebuilder.ForceRebuildLayoutImmediate(gridRect);
            DrawGridBottomBorder(_surroundingsGrid, width, height, _containerGridPadding);

            // ═══════════════════════════════════════════════════════════════
            // ФИКС БАГ 1 (предметы улетают / зависают в контейнере):
            //
            // Проблема: itemsContainer и grid имели разных родителей.
            // SyncRectTransform на itemsContainer конфликтовал с SyncContainer —
            // каждый LateUpdate перезаписывал позицию, часто с неправильными
            // anchors (center вместо top-left), из-за чего предметы улетали
            // за пределы сетки.
            //
            // Решение:
            // 1) НЕ репарентим itemsContainer — оставляем его там, где был.
            //    Новый SyncContainer работает через world-space (InverseTransformPoint)
            //    и не зависит от того, одинаковые ли родители.
            // 2) Отключаем SyncRectTransform — он больше не нужен, SyncContainer
            //    теперь сам справляется с любой иерархией.
            // 3) Добавляем LayoutElement(ignoreLayout=true), чтобы родительский
            //    LayoutGroup (если есть) не управлял позицией itemsContainer.
            // ═══════════════════════════════════════════════════════════════
            if (_surroundingsItemsContainer != null && _surroundingsGrid != null)
            {
                // Отключаем SyncRectTransform — больше не нужен
                var syncRT = _surroundingsItemsContainer.GetComponent<SyncRectTransform>();
                if (syncRT != null)
                    syncRT.enabled = false;

                // ФИКС БАГ 1: Делаем itemsContainer ДОЧЕРНИМ ЭЛЕМЕНТОМ grid'а.
                // Это решает ДВЕ проблемы сразу:
                // 1) Позиционирование: общая система координат, anchoredPosition=(0,0)
                //    совпадает с top-left grid'а — CreateUIItem работает корректно.
                // 2) Raycast: предметы гарантированно ВЫШЕ слотов в иерархии
                //    (SetAsLastSibling), клики не блокируются другими UI-элементами.
                // ignoreLayout=true исключает из GridLayoutGroup.
                _surroundingsItemsContainer.SetParent(_surroundingsGrid, false);
                _surroundingsItemsContainer.SetAsLastSibling();

                var layoutElem = _surroundingsItemsContainer.GetComponent<LayoutElement>();
                if (layoutElem == null)
                    layoutElem = _surroundingsItemsContainer.gameObject.AddComponent<LayoutElement>();
                layoutElem.ignoreLayout = true;

                // ФИКС БАГ 1 (RAYCAST): CanvasGroup.blocksRaycasts ДОЛЖЕН быть true.
                // Если false — ВСЕ дети (предметы) исключаются из raycast'а в Unity,
                // и OnBeginDrag никогда не срабатывает. Пользователь не может взять предмет.
                var canvasGroup = _surroundingsItemsContainer.GetComponent<CanvasGroup>();
                if (canvasGroup != null)
                    canvasGroup.blocksRaycasts = true;
            }

            // Слоты контейнера: raycastTarget = false по умолчанию.
            // Включается только во время drag (через SetGridSlotsRaycast).
            SetGridSlotsRaycast(_surroundingsGrid, false);
        }

        public void OnBackpackEquipped(InventoryItem backpackItem)
        {
            if (_backpackGrid != null && backpackItem?.Data != null && _isOpen)
                RebuildBackpackGrid(backpackItem.Data.BackpackWidth, backpackItem.Data.BackpackHeight);
        }

        public void OnBackpackUnequipped()
        {
            if (_backpackGrid != null && _isOpen)
                RebuildBackpackGrid(BACKPACK_BASE_COLS, BACKPACK_BASE_ROWS);
        }

        public void RebuildBackpackGrid(int width, int height)
        {
            if (_backpackGrid == null || _slotPrefab == null) return;

            // ФИКС БАГ #4: Запоминаем реальные размеры рюкзака
            _currentBackpackCols = width;
            _currentBackpackRows = height;

            ClearGrid(_backpackGrid);
            SetupGridLayout(_backpackGrid, width);
            CacheGridLayoutPadding(_backpackGrid, GridType.Backpack);

            for (int i = 0; i < width * height; i++)
            {
                var slot = Instantiate(_slotPrefab, _backpackGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % width;
                    int y = i / width;
                    slotUI.Setup(x, y, GridType.Backpack, this);
                }
            }
            RefreshAll();
            DrawGridBottomBorder(_backpackGrid, width, height, _backpackGridPadding);
        }

        #endregion

        #region Refresh System

        public void RefreshAll()
        {
            // ФИКС ИСЧЕЗНОВЕНИЯ: Предмет удалён из сетки при старте drag
            // (_dragItemRemoved=true) и «в воздухе» — его нет ни в одном контроллере.
            // Любой RefreshAll в этом состоянии запустит корутину, которая
            // выполнится на следующем кадре. Если к этому моменту дроп ещё
            // не обработан, корутина запулит предметы с устаревшим state.
            //
            // Блокируем refresh ПОКА _dragItemRemoved=true (включая окно
            // между EndDragComplete и OnDrop, где _isDragging уже false).
            // ForceRefresh() (из успешного OnDrop) сбросит _dragItemRemoved
            // и запустит корутину с корректным state.
            if (_dragItemRemoved)
            {
                _pendingRefresh = true;
                return;
            }

            if (_pendingRefresh) return;
            if (Time.time - _lastRefreshTime < UI_REFRESH_THROTTLE)
            {
                _pendingRefresh = true;
                return;
            }
            _pendingRefresh = true;
            _lastRefreshTime = Time.time;
            if (_refreshCoroutine != null) StopCoroutine(_refreshCoroutine);
            _refreshCoroutine = StartCoroutine(RefreshNextFrame());
        }

        public void ForceRefresh()
        {
            _pendingRefresh = false;
            _lastRefreshTime = 0f;

            SyncItemsContainerPositions();

            if (_refreshCoroutine != null)
            {
                StopCoroutine(_refreshCoroutine);
                _refreshCoroutine = null;
            }
            _refreshCoroutine = StartCoroutine(RefreshNextFrame());
        }

        private IEnumerator RefreshNextFrame()
        {
            yield return null;
            _pendingRefresh = false;

            SyncItemsContainerPositions();

            ReturnAllItemsToPool();

            RefreshGrid(GridType.Pockets, POCKET_COLUMNS, POCKET_ROWS, _pocketsItemsContainer);
            RefreshGrid(GridType.Pocket2, POCKET_COLUMNS, POCKET_ROWS, _pocket2ItemsContainer);

            // ФИКС БАГ #4: Используем реальные размеры рюкзака, не захардкоженные
            if (_backpackGrid != null)
                RefreshGrid(GridType.Backpack, _currentBackpackCols, _currentBackpackRows, _backpackItemsContainer);

            if (_isLootingContainer && _activeContainerController != null)
                RefreshGrid(GridType.Container, _activeContainerController.Width, _activeContainerController.Height, _surroundingsItemsContainer);

            _primarySlot1?.Refresh();
            _primarySlot2?.Refresh();
            _pistolSlot?.Refresh();
            _backpackSlot?.Refresh();

            // Occupied cell tinting (task 2)
            UpdateOccupiedCellTints();

            // Internal border hiders for multi-cell items
            UpdateInternalBorders();
        }

        private void RefreshGrid(GridType type, int cols, int rows, Transform container)
        {
            var controller = GetControllerForGrid(type);
            if (controller == null || container == null) return;

            for (int y = 0; y < rows; y++)
                for (int x = 0; x < cols; x++)
                    RefreshSlot(type, x, y, controller, container);
        }

        private void RefreshSlot(GridType type, int x, int y, InventoryController controller, Transform container)
        {
            string key = GetCellKey(type, x, y);
            var item = controller.GetItemAt(x, y);

            if (_activeItems.TryGetValue(key, out var uiItem))
            {
                if (item == null)
                {
                    // ФИКС #3: Не возвращаем в пул перетаскиваемый предмет
                    if (uiItem == _draggedItem)
                    {
                        _activeItems.Remove(key);
                        return;
                    }
                    ReturnToPool(uiItem);
                }
                else
                {
                    if (uiItem.X != x || uiItem.Y != y)
                    {
                        ReturnToPool(uiItem);
                        CreateUIItem(item, x, y, type, container);
                    }
                    else
                    {
                        uiItem.UpdateData(item);
                        uiItem.gameObject.SetActive(true);
                    }
                }
            }
            else if (item != null && controller.IsRootCell(item.InstanceID, x, y))
            {
                CreateUIItem(item, x, y, type, container);
            }
        }

        /// <summary>Найти слот UI по координатам в сетке. Слоты идут по порядку GridLayoutGroup.</summary>
        private K_InventorySlotUI GetSlotAt(GridType gridType, int x, int y)
        {
            Transform grid = gridType switch
            {
                GridType.Pockets => _pocketsGrid,
                GridType.Pocket2 => _pocket2Grid,
                GridType.Backpack => _backpackGrid,
                GridType.Container => _surroundingsGrid,
                _ => null
            };
            if (grid == null) return null;

            int columns = GetGridWidth(gridType);
            int index = y * columns + x;
            if (index < 0 || index >= grid.childCount) return null;
            return grid.GetChild(index).GetComponent<K_InventorySlotUI>();
        }

        private string GetCellKey(GridType type, int x, int y) => $"{type}_{x}_{y}";

        private void CreateUIItem(InventoryItem item, int x, int y, GridType type, Transform container)
        {
            string key = GetCellKey(type, x, y);
            if (_activeItems.ContainsKey(key)) return;

            if (container == null || _uiItemPrefab == null || item == null) return;

            var uiItem = GetPooledItem();
            if (uiItem == null) return;

            uiItem.transform.SetParent(container, false);
            uiItem.transform.SetAsLastSibling();

            var rect = uiItem.GetComponent<RectTransform>();
            if (rect != null)
            {
                Vector2Int currentSize = item.CurrentSize;
                float widthPx = currentSize.x * _slotSize + (currentSize.x - 1) * _slotSpacing;
                float heightPx = currentSize.y * _slotSize + (currentSize.y - 1) * _slotSpacing;

                Vector2 padding = type switch
                {
                    GridType.Pockets => _pocketsGridPadding,
                    GridType.Pocket2 => _pocket2GridPadding,
                    GridType.Backpack => _backpackGridPadding,
                    GridType.Container => _containerGridPadding,
                    _ => Vector2.zero
                };

                rect.anchorMin = new Vector2(0f, 1f);
                rect.anchorMax = new Vector2(0f, 1f);
                rect.pivot = new Vector2(0f, 1f);
                rect.sizeDelta = new Vector2(widthPx, heightPx);

                rect.anchoredPosition = new Vector2(
                    padding.x + x * (_slotSize + _slotSpacing),
                    -padding.y - y * (_slotSize + _slotSpacing)
                );

                rect.localScale = Vector3.one;
                rect.localRotation = Quaternion.identity;
            }

            uiItem.gameObject.SetActive(true);
            uiItem.Setup(item, this, type, x, y);
            _activeItems[key] = uiItem;
        }

        private Transform GetItemsContainer(GridType type) => type switch
        {
            GridType.Pockets => _pocketsItemsContainer,
            GridType.Pocket2 => _pocket2ItemsContainer,
            GridType.Backpack => _backpackItemsContainer,
            GridType.Container => _surroundingsItemsContainer,
            _ => null
        };

        private void SyncItemsContainerPositions()
        {
            SyncContainer(_pocketsGrid, _pocketsItemsContainer);
            SyncContainer(_pocket2Grid, _pocket2ItemsContainer);
            SyncContainer(_backpackGrid, _backpackItemsContainer);
            SyncContainer(_surroundingsGrid, _surroundingsItemsContainer);
        }

        /// <summary>
        /// Синхронизирует itemsContainer с grid через world-space.
        ///
        /// ФИКС БАГ 1 (предметы улетают за пределы / зависают в ящике окружения):
        /// Предыдущая реализация имела три проблемы:
        ///   1) В ветке "разные родители" world-координата передавалась в
        ///      ScreenPointToLocalPointInRectangle как screen-координата —
        ///      для ScreenSpaceCamera Canvas это давало полностью неверную позицию.
        ///   2) В ветке "same parent" копировались anchorMin/anchorMax/pivot grid'а.
        ///      Если grid имеет stretch-anchors ((0,0)→(1,1)), itemsContainer тоже
        ///      получал stretch-anchors, но sizeDelta копировался как есть —
        ///      это давало НУЛЕВОЙ размер при stretch, либо двойной при min-size.
        ///   3) Компонент SyncRectTransform на itemsContainer перезаписывал позицию
        ///      каждый кадр в LateUpdate, конфликтуя с ручной синхронизацией.
        ///
        /// Решение: ВСЕГДА использовать world-space через InverseTransformPoint.
        /// Всегда ставить top-left anchors (0,1), чтобы совпадало с системой
        /// координат, которую использует CreateUIItem для предметов.
        /// </summary>
        private void SyncContainer(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;

            RectTransform gridRect = grid.GetComponent<RectTransform>();
            RectTransform itemsRect = itemsContainer.GetComponent<RectTransform>();

            if (gridRect == null || itemsRect == null) return;

            // ═══════════════════════════════════════════════════
            // Быстрая ветка: itemsContainer — дочерний элемент grid'а
            // (surroundings container после RebuildSurroundingsGrid).
            // anchoredPosition=(0,0) с top-left anchors/pivot точно
            // совпадает с top-left углом grid'а. Никаких конверсий.
            // ═══════════════════════════════════════════════════
            if (itemsContainer.parent == grid)
            {
                itemsRect.anchorMin = new Vector2(0f, 1f);
                itemsRect.anchorMax = new Vector2(0f, 1f);
                itemsRect.pivot = new Vector2(0f, 1f);
                itemsRect.sizeDelta = gridRect.sizeDelta;
                itemsRect.anchoredPosition = Vector2.zero;
                itemsRect.localScale = Vector3.one;
                return;
            }

            // ═══════════════════════════════════════════════════
            // Разные родители (pockets/backpack) — синхронизация
            // через world-space.
            // ═══════════════════════════════════════════════════
            Vector3[] gridCorners = new Vector3[4];
            gridRect.GetWorldCorners(gridCorners);

            Vector3 worldTopLeft = gridCorners[1];
            Vector2 worldSize = gridCorners[2] - gridCorners[0];

            Vector2 localTopLeft;
            Vector2 parentScale = Vector2.one;

            if (itemsRect.parent != null)
            {
                localTopLeft = itemsRect.parent.InverseTransformPoint(worldTopLeft);
                parentScale = new Vector2(
                    Mathf.Abs(itemsRect.parent.lossyScale.x),
                    Mathf.Abs(itemsRect.parent.lossyScale.y));
            }
            else
            {
                localTopLeft = worldTopLeft;
            }

            Vector2 localSize = new Vector2(
                worldSize.x / parentScale.x,
                worldSize.y / parentScale.y);

            // Компенсация разницы между пивотом и anchor-точкой родителя
            RectTransform parentRect = itemsRect.parent as RectTransform;
            if (parentRect != null)
            {
                localTopLeft -= new Vector2(parentRect.rect.xMin, parentRect.rect.yMax);
            }

            itemsRect.anchorMin = new Vector2(0f, 1f);
            itemsRect.anchorMax = new Vector2(0f, 1f);
            itemsRect.pivot = new Vector2(0f, 1f);
            itemsRect.sizeDelta = localSize;
            itemsRect.anchoredPosition = localTopLeft;
            itemsRect.localScale = gridRect.localScale;
        }

        #endregion

        #region Occupied Cell Tinting

        private void UpdateOccupiedCellTints()
        {
            ResetAllSlotColors();
            TintOccupiedCells(GridType.Pockets, _pocketsController);
            TintOccupiedCells(GridType.Pocket2, _pocket2Controller);
            TintOccupiedCells(GridType.Backpack, _backpackController);
            if (_isLootingContainer && _activeContainerController != null)
                TintOccupiedCells(GridType.Container, _activeContainerController);
        }

        private void ResetAllSlotColors()
        {
            ResetGridSlotColors(_pocketsGrid);
            ResetGridSlotColors(_pocket2Grid);
            ResetGridSlotColors(_backpackGrid);
            ResetGridSlotColors(_surroundingsGrid);
        }

        private void ResetGridSlotColors(Transform grid)
        {
            if (grid == null) return;
            for (int i = 0; i < grid.childCount; i++)
            {
                var slot = grid.GetChild(i).GetComponent<K_InventorySlotUI>();
                slot?.ResetCellColor();
            }
        }

        private void TintOccupiedCells(GridType gridType, InventoryController controller)
        {
            if (controller == null) return;
            for (int y = 0; y < controller.Height; y++)
            {
                for (int x = 0; x < controller.Width; x++)
                {
                    if (controller.GetItemAt(x, y) != null)
                    {
                        var slot = GetSlotAt(gridType, x, y);
                        slot?.TintOccupied(_occupiedCellTint);
                    }
                }
            }
        }

        #endregion

        #region Internal Border Hiders

        /// <summary>
        /// Скрывает границы сетки между ячейками, занятыми одним предметом.
        /// Border hider'ы размещаются в дочернем overlay внутри grid'а (не в itemsContainer!),
        /// чтобы их локальные координаты ТОЧНО совпадали со слотами — без sub-pixel смещения.
        /// </summary>
        private void UpdateInternalBorders()
        {
            // Возвращаем все активные hider'ы в пул
            foreach (var hider in _activeBorderHiders)
            {
                hider.SetActive(false);
                _borderHiderPool.Enqueue(hider);
            }
            _activeBorderHiders.Clear();

            // Создаём hider'ы для каждой сетки (через grid-local overlay)
            CreateBorderHidersForGrid(_pocketsController, _pocketsGrid, _pocketsGridPadding);
            CreateBorderHidersForGrid(_pocket2Controller, _pocket2Grid, _pocket2GridPadding);
            CreateBorderHidersForGrid(_backpackController, _backpackGrid, _backpackGridPadding);
            if (_isLootingContainer && _activeContainerController != null)
                CreateBorderHidersForGrid(_activeContainerController, _surroundingsGrid, _containerGridPadding);
        }

        /// <summary>
        /// Получает или создаёт дочерний объект BorderOverlay внутри grid'а.
        /// Overlay имеет LayoutElement.ignoreLayout = true, чтобы GridLayoutGroup
        /// его не трогал. Координаты внутри overlay совпадают с локальными
        /// координатами grid'а (top-left pivot, anchoredPosition = 0).
        /// </summary>
        private Transform GetOrCreateBorderOverlay(Transform grid)
        {
            if (grid == null) return null;

            Transform overlay = grid.Find("BorderOverlay");
            if (overlay != null) return overlay;

            var obj = new GameObject("BorderOverlay", typeof(RectTransform));
            obj.transform.SetParent(grid, false);

            // Исключаем из GridLayoutGroup
            var le = obj.AddComponent<LayoutElement>();
            le.ignoreLayout = true;

            var rt = obj.GetComponent<RectTransform>();
            // Top-left anchors/pivot — совпадает с системой координат слотов
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = Vector2.zero;
            rt.localScale = Vector3.one;

            // Размер = размер grid'а
            var gridRect = grid.GetComponent<RectTransform>();
            if (gridRect != null)
                rt.sizeDelta = gridRect.sizeDelta;

            // Если itemsContainer — дочерний элемент grid'а (surroundings),
            // ставим overlay ПЕРЕД ним, чтобы hider'ы были ПОД предметами
            if (_surroundingsItemsContainer != null && _surroundingsItemsContainer.parent == grid)
                obj.transform.SetSiblingIndex(_surroundingsItemsContainer.GetSiblingIndex());

            return obj.transform;
        }

        private void CreateBorderHidersForGrid(InventoryController controller, Transform grid, Vector2 padding)
        {
            if (controller == null || grid == null) return;

            Transform overlay = GetOrCreateBorderOverlay(grid);
            if (overlay == null) return;

            // Синхронизируем размер overlay с grid'ом (на случай ресайза)
            var gridRect = grid.GetComponent<RectTransform>();
            var overlayRect = overlay.GetComponent<RectTransform>();
            if (gridRect != null && overlayRect != null)
                overlayRect.sizeDelta = gridRect.sizeDelta;

            float step = _slotSize + _slotSpacing;

            for (int y = 0; y < controller.Height; y++)
            {
                for (int x = 0; x < controller.Width; x++)
                {
                    var item = controller.GetItemAt(x, y);
                    if (item == null || !controller.IsRootCell(item.InstanceID, x, y))
                        continue;

                    Vector2Int size = item.CurrentSize;

                    // Вертикальные линии (между ячейками в одной строке)
                    // Ширина = thickness, Высота = slotSize - top - bottom (может быть > slotSize при отрицательных inset)
                    for (int dy = 0; dy < size.y; dy++)
                    {
                        for (int dx = 0; dx < size.x - 1; dx++)
                        {
                            float posX = padding.x + (x + dx + 1) * step - _borderHiderThickness / 2f;
                            float posY = -(padding.y + (y + dy) * step) - _bhInsetTop;
                            float h = _slotSize - _bhInsetTop - _bhInsetBottom;
                            if (h > 0f)
                                SpawnBorderHider(overlay, posX, posY, _borderHiderThickness, h);
                        }
                    }

                    // Горизонтальные линии (между ячейками в одном столбце)
                    // Высота = thickness, Ширина = slotSize - left - right
                    for (int dx = 0; dx < size.x; dx++)
                    {
                        for (int dy = 0; dy < size.y - 1; dy++)
                        {
                            float posX = padding.x + (x + dx) * step + _bhInsetLeft;
                            float posY = -(padding.y + (y + dy + 1) * step) + _borderHiderThickness / 2f;
                            float w = _slotSize - _bhInsetLeft - _bhInsetRight;
                            if (w > 0f)
                                SpawnBorderHider(overlay, posX, posY, w, _borderHiderThickness);
                        }
                    }
                }
            }
        }

        private void SpawnBorderHider(Transform parent, float posX, float posY, float width, float height)
        {
            GameObject hider;
            if (_borderHiderPool.Count > 0)
                hider = _borderHiderPool.Dequeue();
            else
                hider = new GameObject("BorderHider", typeof(RectTransform), typeof(Image));

            hider.transform.SetParent(parent, false);

            var img = hider.GetComponent<Image>();
            if (img == null) img = hider.AddComponent<Image>();
            img.color = _borderHiderColor;
            img.raycastTarget = false;
            img.maskable = true;
            img.sprite = null;
            img.type = Image.Type.Simple;

            var rt = hider.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.anchoredPosition = new Vector2(posX, posY);
            rt.sizeDelta = new Vector2(width, height);
            rt.localScale = Vector3.one;
            rt.localRotation = Quaternion.identity;

            hider.SetActive(true);
            _activeBorderHiders.Add(hider);
        }

        /// <summary>
        /// Возвращает все активные border hider'ы в пул и очищает список.
        /// </summary>
        private void ReturnAllBorderHidersToPool()
        {
            foreach (var hider in _activeBorderHiders)
            {
                hider.SetActive(false);
                _borderHiderPool.Enqueue(hider);
            }
            _activeBorderHiders.Clear();
        }

        #endregion

        #region Drag & Drop System

        public void StartDrag(UI_Item draggedItem, PointerEventData eventData)
        {
            if (draggedItem?.Item == null || _dragGhost == null || _dragGhostRT == null) return;

            // ═══════════════════════════════════════════════════════════════
            // БАГ-ФИКС: Если предыдущий drag оставил предмет "в воздухе"
            // (_dragItemRemoved=true) и fallback ещё не вернул его —
            // новый OnBeginDrag остановит корутину, и предмет потеряется.
            // Решение: возвращаем предмет СИНХРОННО перед новым drag.
            // ═══════════════════════════════════════════════════════════════
            if (_dragItemRemoved && _draggedItem?.Item != null)
            {
                var orphanItem = _draggedItem.Item;
                var originController = GetControllerForGrid(_dragOriginGridType);
                if (originController != null)
                {
                    int placed = originController.TryPlaceItem(orphanItem, _dragOriginX, _dragOriginY);
                    if (placed == 0)
                        originController.TryPlaceItemInFirstFreeSlot(orphanItem);
                }
                _dragItemRemoved = false;
                _dropHandled = false;
                _needsPostDragRefresh = false;
            }

            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedItem = draggedItem;
            _isDragging = true;
            _dropHandled = false;
            _needsPostDragRefresh = false;

            // Отменяем pending fallback refresh
            if (_postDragRefreshCoroutine != null)
            {
                StopCoroutine(_postDragRefreshCoroutine);
                _postDragRefreshCoroutine = null;
            }

            // ФИКС #3: Сохраняем оригинальную позицию и УДАЛЯЕМ предмет из сетки.
            // Теперь вращение свободное — не привязано к текущей позиции в сетке.
            _dragOriginGridType = draggedItem.GridType;
            _dragOriginX = draggedItem.X;
            _dragOriginY = draggedItem.Y;
            _dragOriginRotationAngle = draggedItem.Item.RotationAngle;
            _dragItemRemoved = false;

            var sourceController = GetControllerForGrid(draggedItem.GridType);
            if (sourceController != null)
            {
                sourceController.RemoveItem(draggedItem.Item);
                _dragItemRemoved = true;

                // ФИКС: сразу очищаем occupied tint с ячеек, которые занимал предмет.
                // Иначе до следующего refresh на старом месте остаётся подсветка.
                Vector2Int originSize = draggedItem.Item.CurrentSize;
                for (int dy = 0; dy < originSize.y; dy++)
                {
                    for (int dx = 0; dx < originSize.x; dx++)
                    {
                        var slot = GetSlotAt(draggedItem.GridType,
                            draggedItem.X + dx, draggedItem.Y + dy);
                        if (slot != null)
                            slot.ResetCellColor();
                    }
                }
            }

            // Снимаем hover при начале drag
            if (_hoveredItem == draggedItem)
            {
                _hoveredItem.SetSelected(false);
                _hoveredItem = null;
            }

            SetupDragOutline(draggedItem.Item);

            // ФИКС БАГ #3 (v2): Включаем raycast на слотах для OnDrop
            SetAllGridSlotsRaycast(true);

            _dragGhost.SetActive(true);
            UpdateDragGhostPosition(eventData);
        }

        public void StartDragFromEquipmentSlot(K_EquipmentSlotUI slot, PointerEventData eventData)
        {
            if (slot?.EquippedItem == null || _dragGhost == null || _dragGhostRT == null) return;
            var item = slot.EquippedItem;

            _draggedFromEquipmentSlot = slot;
            _draggedFromSlotItem = item;
            _draggedItem = null;
            _isDragging = true;
            _dropHandled = false;
            _dragItemRemoved = false;
            _needsPostDragRefresh = false;

            if (_postDragRefreshCoroutine != null)
            {
                StopCoroutine(_postDragRefreshCoroutine);
                _postDragRefreshCoroutine = null;
            }

            SetupDragOutline(item);

            // ФИКС БАГ #3 (v2): Включаем raycast на слотах для OnDrop
            SetAllGridSlotsRaycast(true);

            _dragGhost.SetActive(true);
            UpdateDragGhostPosition(eventData);
        }

        public void UpdateDragGhostPosition(PointerEventData eventData)
        {
            if (!_isDragging || _dragGhost == null || !_dragGhost.activeSelf || _dragGhostRT == null) return;

            RectTransform canvasRT = _rootCanvasTransform as RectTransform;
            if (canvasRT == null) return;

            // ИСПРАВЛЕНИЕ БАГ 2: передаём _rootCanvasCamera вместо null.
            // Для ScreenSpaceCamera Canvas без камеры конверсия неправильная —
            // ghost смещается пропорционально позиции на экране,
            // поэтому на разных клетках разное расстояние до подсветки.
            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRT, eventData.position, _rootCanvasCamera, out Vector2 localPoint))
                _dragGhostRT.anchoredPosition = localPoint;

            UpdateDragCellHighlights();
        }

        /// <summary>
        /// Вращение при перетаскивании: 2 состояния (0°→90°→0° циклично).
        /// Предмет уже удалён из сетки при старте drag.
        /// </summary>
        private void RotateDraggedItem()
        {
            var item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null || !item.Data.CanRotate) return;

            // Прямое вращение без привязки к сетке
            item.Rotate();
            UpdateGhostSize();
            UpdateGhostRotation();
            // ФИКС: обновляем подсветку ячеек после смены размера
            UpdateDragCellHighlights();
        }

        private void UpdateGhostSize()
        {
            if (_dragGhostRT == null) return;

            Vector2Int currentSize;
            Vector2Int normalSize;

            if (_draggedItem?.Item != null)
            {
                currentSize = _draggedItem.Item.CurrentSize;
                normalSize = _draggedItem.Item.Data.Size;
            }
            else if (_draggedFromSlotItem != null)
            {
                currentSize = _draggedFromSlotItem.CurrentSize;
                normalSize = _draggedFromSlotItem.Data.Size;
            }
            else
            {
                currentSize = new Vector2Int(1, 1);
                normalSize = new Vector2Int(1, 1);
            }

            float bodyW = currentSize.x * _slotSize + (currentSize.x - 1) * _slotSpacing;
            float bodyH = currentSize.y * _slotSize + (currentSize.y - 1) * _slotSpacing;
            _dragGhostRT.sizeDelta = new Vector2(bodyW, bodyH);

            // Иконка ghost — размер по Data.Size с swap для IconBaseRotation.
            var iconItem = _draggedItem?.Item ?? _draggedFromSlotItem;
            float baseRot = iconItem?.IconBaseRotation ?? 0f;
            bool iconSwapsAxes = Mathf.Abs(baseRot % 180) > 0.01f;
            float iconW = (iconSwapsAxes ? normalSize.y : normalSize.x) * _slotSize
                              + ((iconSwapsAxes ? normalSize.y : normalSize.x) - 1) * _slotSpacing;
            float iconH = (iconSwapsAxes ? normalSize.x : normalSize.y) * _slotSize
                              + ((iconSwapsAxes ? normalSize.x : normalSize.y) - 1) * _slotSpacing;
            _dragGhostIconRect.sizeDelta = new Vector2(iconW, iconH);
        }

        private void UpdateGhostRotation()
        {
            var item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null || _dragGhostIconRect == null) return;

            _dragGhostRT.localRotation = Quaternion.identity;
            float visualAngle = item.IconBaseRotation - item.RotationAngle;
            _dragGhostIconRect.localRotation = Quaternion.Euler(0, 0, visualAngle);
        }

        /// <summary>
        /// TASK 3+4+6: Подсветка ячеек под курсором вместо обводки призрака.
        /// Иконка предмета видна (летает над ячейками). За границей — скрыть всё.
        /// </summary>
        private void UpdateDragCellHighlights()
        {
            if (EventSystem.current == null) return;

            InventoryItem item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null) { ClearHighlightsKeepGhostVisible(); return; }

            // Ленивая инициализация
            if (_cachedEventData == null)
                _cachedEventData = new PointerEventData(EventSystem.current);

            _cachedEventData.position = Input.mousePosition;
            _raycastBuffer.Clear();
            EventSystem.current.RaycastAll(_cachedEventData, _raycastBuffer);

            K_InventorySlotUI hitSlot = null;
            bool canPlace = false;

            foreach (var result in _raycastBuffer)
            {
                var slot = result.gameObject.GetComponent<K_InventorySlotUI>();
                if (slot != null)
                {
                    var controller = GetControllerForGrid(slot.GridType);
                    if (controller == null) continue;

                    Vector2Int itemSize = item.CurrentSize;
                    // ФИКС БАГ #2: Используем реальные размеры UI-сетки
                    int gridW = GetGridWidth(slot.GridType);
                    int gridH = GetGridHeight(slot.GridType);
                    var (targetX, targetY) = CalculateSnapPosition(
                        slot.X, slot.Y, itemSize, gridW, gridH);

                    canPlace = controller.CanPlaceItem(item, targetX, targetY);
                    hitSlot = slot;
                    break;
                }

                var equipSlot = result.gameObject.GetComponent<K_EquipmentSlotUI>();
                if (equipSlot != null)
                {
                    canPlace = ValidateEquipItem(item, equipSlot);
                    break;
                }
            }

            // За границей сетки — убрать подсветку, ghost виден
            if (hitSlot == null)
            {
                ClearHighlightsKeepGhostVisible();
                return;
            }

            // Показываем ghost (с иконкой)
            if (_dragGhost != null) _dragGhost.SetActive(true);

            // Рассчитываем позицию рамки подсветки
            Vector2Int itemSize2 = item.CurrentSize;
            int gridW2 = GetGridWidth(hitSlot.GridType);
            int gridH2 = GetGridHeight(hitSlot.GridType);
            var (tx, ty) = CalculateSnapPosition(
                hitSlot.X, hitSlot.Y, itemSize2, gridW2, gridH2);

            Color outlineColor = canPlace ? _dragOutlineValidColor : _dragOutlineInvalidColor;

            Transform grid = hitSlot.GridType switch
            {
                GridType.Pockets => _pocketsGrid,
                GridType.Pocket2 => _pocket2Grid,
                GridType.Backpack => _backpackGrid,
                GridType.Container => _surroundingsGrid,
                _ => null
            };
            if (grid == null) return;

            ShowDragOutline(grid, hitSlot.GridType, tx, ty, itemSize2, outlineColor);
        }

        /// <summary>
        /// Показывает рамку-подсветку вокруг ячеек, которые займёт предмет при дропе.
        /// Рамка состоит из 4 Image-полосок (верх, низ, лево, право) внутри grid'а.
        /// </summary>
        private void ShowDragOutline(Transform grid, GridType gridType, int tx, int ty, Vector2Int itemSize, Color color)
        {
            EnsureDragOutlineFrame();

            // Репарентим при смене grid'а
            if (_outlineCurrentParent != grid)
            {
                _dragOutlineFrame.transform.SetParent(grid, false);
                _outlineCurrentParent = grid;
            }

            float cellStep = _slotSize + _slotSpacing;
            Vector2 padding = GetPaddingForGrid(gridType);
            float t = _dragOutlineThickness;

            // Позиция и размер всей области (top-left anchor, pivot top-left)
            float frameX = padding.x + tx * cellStep;
            float frameY = -(padding.y + ty * cellStep); // UI Y инвертирован
            float frameW = itemSize.x * cellStep - _slotSpacing;
            float frameH = itemSize.y * cellStep - _slotSpacing;

            // Обрезаем рамку по границам сетки, чтобы не вылезала за неё
            var gridRT = grid.GetComponent<RectTransform>();
            float gridRight = gridRT.rect.width;
            float gridBottom = -gridRT.rect.height;

            float clampedLeft = Mathf.Max(frameX, 0f);
            float clampedTop = Mathf.Min(frameY, 0f);
            float clampedRight = Mathf.Min(frameX + frameW, gridRight);
            float clampedBottom = Mathf.Max(frameY - frameH, gridBottom);

            float clampedW = clampedRight - clampedLeft;
            float clampedH = clampedTop - clampedBottom;

            var frameRT = _dragOutlineFrame.GetComponent<RectTransform>();
            frameRT.anchorMin = new Vector2(0, 1);
            frameRT.anchorMax = new Vector2(0, 1);
            frameRT.pivot = new Vector2(0, 1);

            if (clampedW <= 0 || clampedH <= 0)
            {
                _dragOutlineFrame.SetActive(false);
                return;
            }

            frameRT.anchoredPosition = new Vector2(clampedLeft, clampedTop);
            frameRT.sizeDelta = new Vector2(clampedW, clampedH);

            // Верхняя полоска
            SetEdgeRect(_outlineTop, 0, 0, clampedW, t);
            // Нижняя полоска
            SetEdgeRect(_outlineBottom, 0, -clampedH + t, clampedW, t);
            // Левая полоска
            SetEdgeRect(_outlineLeft, 0, -t, t, clampedH - 2 * t);
            // Правая полоска
            SetEdgeRect(_outlineRight, clampedW - t, -t, t, clampedH - 2 * t);

            // Обновляем цвет только если изменился
            if (_outlineLastColor != color)
            {
                _outlineTop.color = color;
                _outlineBottom.color = color;
                _outlineLeft.color = color;
                _outlineRight.color = color;
                _outlineLastColor = color;
            }

            _dragOutlineFrame.SetActive(true);
        }

        /// <summary>Устанавливает позицию и размер edge-полоски (top-left anchor, pivot top-left).</summary>
        private void SetEdgeRect(Image img, float x, float y, float w, float h)
        {
            var rt = img.rectTransform;
            rt.anchorMin = new Vector2(0, 1);
            rt.anchorMax = new Vector2(0, 1);
            rt.pivot = new Vector2(0, 1);
            rt.anchoredPosition = new Vector2(x, y);
            rt.sizeDelta = new Vector2(w, h);
        }

        /// <summary>Ленивое создание рамки подсветки (4 Image-полоски).</summary>
        private void EnsureDragOutlineFrame()
        {
            if (_dragOutlineFrame != null) return;

            _dragOutlineFrame = new GameObject("DragOutline", typeof(RectTransform));
            // LayoutElement с ignoreLayout чтобы не влиял на GridLayoutGroup
            var le = _dragOutlineFrame.AddComponent<LayoutElement>();
            le.ignoreLayout = true;

            _outlineTop = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeTop");
            _outlineBottom = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeBottom");
            _outlineLeft = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeLeft");
            _outlineRight = CreateEdgeImage(_dragOutlineFrame.transform, "EdgeRight");

            _dragOutlineFrame.SetActive(false);
        }

        /// <summary>Создаёт дочерний Image для одной стороны рамки.</summary>
        private Image CreateEdgeImage(Transform parent, string name)
        {
            var go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            var img = go.GetComponent<Image>();
            img.sprite = null;
            img.type = Image.Type.Simple;
            img.color = Color.clear;
            img.raycastTarget = false;
            return img;
        }

        /// <summary>Скрывает рамку подсветки.</summary>
        private void HideDragOutline()
        {
            if (_dragOutlineFrame != null)
            {
                // Выносим из grid'а чтобы ClearGrid не уничтожил рамку
                // при следующем RebuildSurroundingsGrid / RebuildBackpackGrid.
                _dragOutlineFrame.transform.SetParent(transform, false);
                _dragOutlineFrame.SetActive(false);
            }
            _outlineCurrentParent = null;
            _outlineLastColor = Color.clear;
        }

        /// <summary>
        /// Смещает ghost так, чтобы его центр совпадал с центром подсвеченной области ячеек.
        /// Без этого ghost стоит на курсоре, а подсветка — со смещением (до пол-ячейки).
        /// </summary>
        private void SnapGhostToHighlightArea(GridType gridType, int tx, int ty, Vector2Int itemSize)
        {
            if (_dragGhostRT == null || _rootCanvasTransform == null) return;

            var topLeftSlot = GetSlotAt(gridType, tx, ty);
            if (topLeftSlot == null) return;

            var slotRT = topLeftSlot.transform as RectTransform;
            var canvasRT = _rootCanvasTransform as RectTransform;
            if (slotRT == null || canvasRT == null) return;

            // Центр левой верхней ячейки → canvas-local координаты
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                canvasRT, slotRT.position, null, out Vector2 slotCenterLocal))
                return;

            // Смещение от центра первой ячейки до центра всей подсвеченной области
            float cellStep = _slotSize + _slotSpacing;
            float offsetX = ((float)itemSize.x - 1f) * 0.5f * cellStep;
            float offsetY = -((float)itemSize.y - 1f) * 0.5f * cellStep; // минус: UI Y инвертирован

            _dragGhostRT.anchoredPosition = slotCenterLocal + new Vector2(offsetX, offsetY);
        }

        private void ClearDragCellHighlights()
        {
            HideDragOutline();
        }

        /// <summary>За границей сетки: подсветку убрать, ghost оставить видимым.</summary>
        private void ClearHighlightsKeepGhostVisible()
        {
            ClearDragCellHighlights();
            // Ghost НЕ скрываем — игрок должен видеть что он тащит
        }

        private void HideDragGhostAndClearHighlights()
        {
            ClearDragCellHighlights();
            if (_dragGhost != null) _dragGhost.SetActive(false);
        }

        /// <summary>
        /// ФИКС БАГ #3 (v2): Переключает raycastTarget на фоновых Image слотов.
        /// Когда НЕ таскаем — слоты НЕ блокируют raycast, предметы можно кликать.
        /// Когда таскаем — слоты СТАНОВЯТСЯ raycast-целями для OnDrop.
        /// Это решает проблему, когда itemsContainer и grid имеют разных родителей
        /// (SetAsLastSibling не помогает → слоты блокируют IBeginDragHandler).
        /// </summary>
        private void SetAllGridSlotsRaycast(bool enabled)
        {
            SetGridSlotsRaycast(_pocketsGrid, enabled);
            SetGridSlotsRaycast(_pocket2Grid, enabled);
            SetGridSlotsRaycast(_backpackGrid, enabled);
            SetGridSlotsRaycast(_surroundingsGrid, enabled);
        }

        private void SetGridSlotsRaycast(Transform grid, bool enabled)
        {
            if (grid == null) return;
            for (int i = 0; i < grid.childCount; i++)
            {
                var slotUI = grid.GetChild(i).GetComponent<K_InventorySlotUI>();
                if (slotUI != null) slotUI.SetRaycastEnabled(enabled);
            }
        }

        public bool TryPlaceItem(UI_Item draggedItem, GridType targetGrid, int targetX, int targetY)
        {
            if (draggedItem?.Item == null) return false;

            var item = draggedItem.Item;
            var targetController = GetControllerForGrid(targetGrid);
            if (targetController == null) return false;

            if (targetX < 0 || targetY < 0 ||
                targetX >= targetController.Width ||
                targetY >= targetController.Height)
            {
                LogDebug($"[InventoryUI] REJECTED - out of bounds ({targetX},{targetY})");
                return false;
            }

            // ФИКС #3 + БАГ ИСЧЕЗНОВЕНИЯ: Если предмет был удалён из сетки при старте drag — просто размещаем.
            // _needsPostDragRefresh = false отменяет отложенный возврат в PostDragEndFallback.
            if (_dragItemRemoved)
            {
                int earlyPlaceCount = targetController.TryPlaceItem(item, targetX, targetY);
                if (earlyPlaceCount > 0)
                {
                    // ═══════════════════════════════════════════════════════════
                    // ФИКС UI ИСЧЕЗНОВЕНИЯ В CONTAINER + ПРЕДОТВРАЩЕНИЕ ДУБЛИРОВАНИЯ:
                    //
                    // Проблема: PostDragEndFallback и RefreshNextFrame — обе
                    // корутины на следующем кадре. Если _draggedItem не очищен
                    // до ForceRefresh(), ReturnAllItemsToPool() «защищает»
                    // старый UI_Item от пула → конфликт при RefreshGrid.
                    //
                    // Решение: обнуляем _draggedItem СИНХРОННО здесь.
                    // ReturnAllItemsToPool() увидит null и пулит ВСЕ предметы,
                    // а RefreshGrid пересоздаст UI из актуальных данных контроллеров.
                    // НЕ вручную возвращаем в пул — это может дать двойной enqueue,
                    // если ReturnAllItemsToPool тоже обработает этот элемент.
                    // ═══════════════════════════════════════════════════════════

                    // Останавливаем PostDragEndFallback — дроп уже обработан
                    if (_postDragRefreshCoroutine != null)
                    {
                        StopCoroutine(_postDragRefreshCoroutine);
                        _postDragRefreshCoroutine = null;
                    }

                    // Обнуляем ВСЕ drag-переменные ДО ForceRefresh.
                    // Без _draggedItem ReturnAllItemsToPool не будет «защищать»
                    // старый UI_Item от пула.
                    _draggedItem = null;
                    _draggedFromEquipmentSlot = null;
                    _draggedFromSlotItem = null;
                    _dragItemRemoved = false;
                    _dropHandled = true;
                    _needsPostDragRefresh = false;

                    ForceRefresh();
                    return true;
                }
                return false;
            }

            // Оригинальная логика для предметов которые НЕ были удалены из сетки
            var sourceController = GetControllerForGrid(draggedItem.GridType);

            if (sourceController == targetController &&
                draggedItem.X == targetX &&
                draggedItem.Y == targetY)
                return true;

            if (sourceController == targetController)
            {
                bool moved = sourceController.MoveItem(item, targetX, targetY);
                if (moved) ForceRefresh();
                return moved;
            }

            int originX = draggedItem.X;
            int originY = draggedItem.Y;

            if (!sourceController.RemoveItem(item))
                return false;

            int placedCount = targetController.TryPlaceItem(item, targetX, targetY);
            bool success = placedCount > 0;

            if (!success)
                sourceController.TryPlaceItem(item, originX, originY);

            if (success) ForceRefresh();

            return success;
        }

        public bool TryEquipItem(UI_Item draggedItem, K_EquipmentSlotUI slot)
        {
            if (draggedItem?.Item == null || slot == null) return false;
            var item = draggedItem.Item;
            if (!ValidateEquipItem(item, slot)) return false;

            var sourceController = GetControllerForGrid(draggedItem.GridType);
            if (sourceController == null) return false;

            // Если слот занят — пробуем swap: старый предмет → на место нового
            if (slot.IsOccupied && slot.EquippedItem != null)
            {
                var oldEquipped = slot.EquippedItem;

                // Старый предмет наследует разворот нового
                oldEquipped.RestoreRotationState(item.RotationAngle);

                // Пытаемся поставить старый предмет на позицию нового
                int placed = sourceController.TryPlaceItem(oldEquipped, draggedItem.X, draggedItem.Y);
                if (placed == 0)
                {
                    bool fallback = sourceController.TryPlaceItemInFirstFreeSlot(oldEquipped);
                    placed = fallback ? 1 : 0;
                }

                if (placed == 0) return false; // Нет места для старого предмета

                // Старый предмет размещён — убираем новый из сетки
                if (!sourceController.RemoveItem(item)) return false;

                string itemKey = GetCellKey(draggedItem.GridType, draggedItem.X, draggedItem.Y);
                _activeItems.Remove(itemKey);

                slot.SetEquippedItem(null);
                slot.OnDropItem(item);
                draggedItem.gameObject.SetActive(false);
                ReturnToPool(draggedItem);
                ForceRefresh();
                return true;
            }

            // Слот пуст — обычная экипировка
            if (sourceController.RemoveItem(item))
            {
                string itemKey = GetCellKey(draggedItem.GridType, draggedItem.X, draggedItem.Y);
                _activeItems.Remove(itemKey);

                slot.OnDropItem(item);
                draggedItem.gameObject.SetActive(false);
                ReturnToPool(draggedItem);

                ForceRefresh();
                return true;
            }
            return false;
        }

        public bool TryPlaceItemFromEquipmentSlot(GridType targetGrid, int targetX, int targetY)
        {
            if (_draggedFromEquipmentSlot == null || _draggedFromSlotItem == null) return false;

            var item = _draggedFromSlotItem;
            var targetController = GetControllerForGrid(targetGrid);
            if (targetController == null) return false;

            if (targetX < 0 || targetY < 0 ||
                targetX >= targetController.Width ||
                targetY >= targetController.Height)
                return false;

            int placedCount = targetController.TryPlaceItem(item, targetX, targetY);

            if (placedCount > 0)
            {
                _draggedFromEquipmentSlot.SetEquippedItem(null);
                ForceRefresh();
                return true;
            }

            return false;
        }

        public bool TryEquipItemFromSlot(K_EquipmentSlotUI sourceSlot, K_EquipmentSlotUI targetSlot)
        {
            if (sourceSlot?.EquippedItem == null || targetSlot == null || sourceSlot == targetSlot) return false;

            var item = sourceSlot.EquippedItem;
            if (!ValidateEquipItem(item, targetSlot)) return false;

            // Если целевой слот занят — пробуем swap между слотами
            if (targetSlot.IsOccupied && targetSlot.EquippedItem != null)
            {
                var oldTargetItem = targetSlot.EquippedItem;

                // Проверяем: может ли старый предмет целевого слота поместиться в исходный слот?
                if (sourceSlot.ValidateItemForSlot(oldTargetItem))
                {
                    // Swap: старый предмет → исходный слот
                    sourceSlot.SetEquippedItem(oldTargetItem);
                    targetSlot.SetEquippedItem(null);
                }
                else
                {
                    // Старый предмет не подходит для исходного слота — пробуем unequip в инвентарь.
                    // Наследуем разворот нового предмета перед размещением в сетке.
                    oldTargetItem.RestoreRotationState(item.RotationAngle);
                    targetSlot.Unequip();
                    if (targetSlot.IsOccupied) return false; // Не получилось разместить
                }
            }
            else
            {
                // Целевой слот пуст — просто убираем из исходного
                sourceSlot.SetEquippedItem(null);
            }

            targetSlot.OnDropItem(item);
            return true;
        }

        /// <summary>
        /// ФИКС #3 + #6 + БАГ ИСЧЕЗНОВЕНИЯ: При отмене drag — вернуть предмет на исходную позицию.
        ///
        /// КРИТИЧЕСКИЙ ФИКС: В Unity OnEndDrag ВСЕГДА вызывается ДО OnDrop.
        /// Раньше EndDragComplete немедленно возвращал предмет через TryPlaceItem,
        /// который создавал НОВЫЙ InventoryItem (новый InstanceID). Затем OnDrop
        /// пытался оперировать ОРИГИНАЛЬНЫМ item'ом (которого больше не было в
        /// _positionCache) → MoveItem/RemoveItem silent-fail → предмет терялся.
        ///
        /// Решение: НЕ возвращать предмет здесь. Отложить на 1 фрейм — после OnDrop.
        /// Если OnDrop успешно разместил предмет (_dropHandled=true, _needsPostDragRefresh
        /// сброшен), отложенный код только очищает стейт. Если OnDrop не стрелял
        /// или провалился — отложенный код возвращает предмет на исходную позицию.
        /// </summary>
        public void EndDragComplete()
        {
            _isDragging = false;
            ClearDragCellHighlights();
            if (_dragGhost != null) _dragGhost.SetActive(false);

            // ФИКС БАГ #3 (v2): Выключаем raycast на слотах
            SetAllGridSlotsRaycast(false);

            // Откладываем возврат предмета на следующий фрейм (после OnDrop)
            _needsPostDragRefresh = true;
            if (_postDragRefreshCoroutine != null)
                StopCoroutine(_postDragRefreshCoroutine);
            _postDragRefreshCoroutine = StartCoroutine(PostDragEndFallback());
        }

        /// <summary>
        /// Отложенная обработка конца drag. Выполняется через 1 фрейм после OnEndDrag,
        /// что гарантирует: OnDrop уже отстрелял (если должен был).
        /// </summary>
        private IEnumerator PostDragEndFallback()
        {
            // Ждём 1 фрейм — OnDrop успевает отстрелить
            yield return null;

            if (!_needsPostDragRefresh)
            {
                // OnDrop успешно обработал дроп и сбросил флаг.
                // Очищаем оставшиеся ссылки — предмет уже на новом месте.
                _dragItemRemoved = false;
                _dropHandled = false;
                _draggedItem = null;
                _draggedFromEquipmentSlot = null;
                _draggedFromSlotItem = null;
                _postDragRefreshCoroutine = null;
                yield break;
            }

            // OnDrop не обработал дроп (не стрелял или placement fail).
            // Возвращаем предмет на исходную позицию.
            _needsPostDragRefresh = false;

            if (_dragItemRemoved && !_dropHandled && _draggedItem?.Item != null)
            {
                var item = _draggedItem.Item;
                var controller = GetControllerForGrid(_dragOriginGridType);

                if (controller != null)
                {
                    // Пытаемся вернуть на исходную позицию с ТЕКУЩИМ вращением
                    int placed = controller.TryPlaceItem(item, _dragOriginX, _dragOriginY);
                    if (placed == 0)
                    {
                        // Не влезает — разворачиваем обратно к оригинальному вращению
                        while (item.RotationAngle != _dragOriginRotationAngle)
                            item.Rotate();

                        placed = controller.TryPlaceItem(item, _dragOriginX, _dragOriginY);
                    }
                    if (placed == 0)
                    {
                        // Исходная позиция занята — ищем любое свободное место
                        controller.TryPlaceItemInFirstFreeSlot(item);
                    }
                    // Если и FirstFreeSlot не нашёл — предмет остаётся "в воздухе",
                    // но ui_item reference ещё жив, ForceRefresh пересоздаст визуал.
                }
            }

            _dragItemRemoved = false;
            _dropHandled = false;
            _draggedItem = null;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;

            ForceRefresh();
            _postDragRefreshCoroutine = null;
        }

        public void EndDragFromEquipmentSlot()
        {
            _isDragging = false;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedItem = null;
            ClearDragCellHighlights();
            if (_dragGhost != null) _dragGhost.SetActive(false);

            // ФИКС БАГ #3 (v2): Выключаем raycast на слотах
            SetAllGridSlotsRaycast(false);

            ForceRefresh();
        }

        private bool ValidateEquipItem(InventoryItem item, K_EquipmentSlotUI slot)
        {
            if (item?.Data == null) return false;
            return slot.SlotType switch
            {
                EquipmentSlotType.Primary => item.Type == ItemType.Weapon && !item.Data.IsPistol,
                EquipmentSlotType.Pistol => item.Type == ItemType.Weapon && item.Data.IsPistol,
                EquipmentSlotType.Backpack => item.Data.IsBackpack,
                _ => false
            };
        }

        #endregion

        #region Event Handling

        private void SubscribeToEvents()
        {
            _onInventoryChangedHandler = RefreshAll;
            _onWeightChangedHandler = UpdateWeightDisplay;
            _onItemPlacedHandler = (item, x, y) => RefreshAll();
            _onItemChangedHandler = _ => RefreshAll();

            if (_pocketsController != null)
            {
                _pocketsController.OnInventoryChanged += _onInventoryChangedHandler;
                _pocketsController.OnItemPlaced += _onItemPlacedHandler;
                _pocketsController.OnItemRemoved += _onItemChangedHandler;
                _pocketsController.OnItemRotated += _onItemChangedHandler;
                _pocketsController.OnItemQuantityChanged += _onItemChangedHandler;
                _pocketsController.OnWeightChanged += _onWeightChangedHandler;
            }

            if (_pocket2Controller != null)
            {
                _pocket2Controller.OnInventoryChanged += _onInventoryChangedHandler;
                _pocket2Controller.OnItemPlaced += _onItemPlacedHandler;
                _pocket2Controller.OnItemRemoved += _onItemChangedHandler;
                _pocket2Controller.OnItemRotated += _onItemChangedHandler;
                _pocket2Controller.OnItemQuantityChanged += _onItemChangedHandler;
                _pocket2Controller.OnWeightChanged += _onWeightChangedHandler;
            }

            if (_backpackController != null)
            {
                _backpackController.OnInventoryChanged += _onInventoryChangedHandler;
                _backpackController.OnItemPlaced += _onItemPlacedHandler;
                _backpackController.OnItemRemoved += _onItemChangedHandler;
                _backpackController.OnItemRotated += _onItemChangedHandler;
                _backpackController.OnItemQuantityChanged += _onItemChangedHandler;
                _backpackController.OnWeightChanged += _onWeightChangedHandler;
            }
        }

        private void UnsubscribeFromEvents()
        {
            if (_pocketsController != null)
            {
                _pocketsController.OnInventoryChanged -= _onInventoryChangedHandler;
                _pocketsController.OnItemPlaced -= _onItemPlacedHandler;
                _pocketsController.OnItemRemoved -= _onItemChangedHandler;
                _pocketsController.OnItemRotated -= _onItemChangedHandler;
                _pocketsController.OnItemQuantityChanged -= _onItemChangedHandler;
                _pocketsController.OnWeightChanged -= _onWeightChangedHandler;
            }

            if (_pocket2Controller != null)
            {
                _pocket2Controller.OnInventoryChanged -= _onInventoryChangedHandler;
                _pocket2Controller.OnItemPlaced -= _onItemPlacedHandler;
                _pocket2Controller.OnItemRemoved -= _onItemChangedHandler;
                _pocket2Controller.OnItemRotated -= _onItemChangedHandler;
                _pocket2Controller.OnItemQuantityChanged -= _onItemChangedHandler;
                _pocket2Controller.OnWeightChanged -= _onWeightChangedHandler;
            }

            if (_backpackController != null)
            {
                _backpackController.OnInventoryChanged -= _onInventoryChangedHandler;
                _backpackController.OnItemPlaced -= _onItemPlacedHandler;
                _backpackController.OnItemRemoved -= _onItemChangedHandler;
                _backpackController.OnItemRotated -= _onItemChangedHandler;
                _backpackController.OnItemQuantityChanged -= _onItemChangedHandler;
                _backpackController.OnWeightChanged -= _onWeightChangedHandler;
            }
        }

        private void UpdateWeightDisplay(float kg)
        {
            if (_weightText == null) return;

            float totalKg = 0f;
            float maxCapacity = 0f;

            if (_pocketsController != null)
            {
                totalKg += _pocketsController.CurrentWeightKg;
                maxCapacity += _pocketsController.MaxCapacityGrams;
            }
            if (_pocket2Controller != null)
            {
                totalKg += _pocket2Controller.CurrentWeightKg;
                maxCapacity += _pocket2Controller.MaxCapacityGrams;
            }
            if (_backpackController != null)
            {
                totalKg += _backpackController.CurrentWeightKg;
                maxCapacity += _backpackController.MaxCapacityGrams;
            }

            float ratio = maxCapacity > 0 ? (totalKg * 1000f) / maxCapacity : 0f;
            Color textColor = ratio > WEIGHT_CRITICAL_RATIO ? _textCriticalColor
                            : ratio > WEIGHT_WARNING_RATIO ? _textWarningColor
                            : _textNormalColor;

            float maxKg = maxCapacity / 1000f;
            _weightText.text = $"<color=#{ColorUtility.ToHtmlStringRGB(textColor)}>{totalKg:F1} / {maxKg:F0} kg</color>";
        }

        #endregion

        #region Pool Management

        private UI_Item GetPooledItem()
        {
            if (_itemPool.Count > 0) return _itemPool.Dequeue();
            return CreateNewPooledItem();
        }

        /// <summary>
        /// ФИКС БАГ #3: ReturnToPool теперь удаляет элемент из _activeItems.
        /// Это предотвращает двойной возврат и коррупцию пула.
        /// </summary>
        private void ReturnToPool(UI_Item item)
        {
            if (item == null) return;

            // ФИКС БАГ #3: Удаляем из _activeItems, чтобы ReturnAllItemsToPool
            // не вернул этот элемент повторно
            foreach (var kvp in _activeItems)
            {
                if (kvp.Value == item)
                {
                    _activeItems.Remove(kvp.Key);
                    break;
                }
            }

            item.ResetState();
            item.gameObject.SetActive(false);
            item.transform.SetParent(transform, false);
            _itemPool.Enqueue(item);
        }

        private void ReturnAllItemsToPool()
        {
            UI_Item protectedItem = _draggedItem;

            foreach (var item in _activeItems.Values)
            {
                if (item == protectedItem) continue;
                ReturnToPoolOnly(item);
            }

            _activeItems.Clear();

            // ФИКС #3: Если предмет удалён из сетки — НЕ добавляем в _activeItems.
            // Иначе RefreshGrid увидит пустую ячейку и вернёт предмет в пул.
            if (protectedItem != null && protectedItem.Item != null && !_dragItemRemoved)
            {
                string key = GetCellKey(protectedItem.GridType, protectedItem.X, protectedItem.Y);
                _activeItems[key] = protectedItem;
            }
        }

        /// <summary>
        /// Внутренний метод: возвращает элемент в пул БЕЗ удаления из _activeItems.
        /// Используется в ReturnAllItemsToPool() для очистки всех элементов.
        /// </summary>
        private void ReturnToPoolOnly(UI_Item item)
        {
            if (item == null) return;
            item.ResetState();
            item.gameObject.SetActive(false);
            item.transform.SetParent(transform, false);
            _itemPool.Enqueue(item);
        }

        private void ClearPooledItems()
        {
            foreach (var item in _itemPool) if (item != null) Destroy(item.gameObject);
            _itemPool.Clear();
            _activeItems.Clear();

            foreach (var hider in _borderHiderPool) if (hider != null) Destroy(hider);
            _borderHiderPool.Clear();
            foreach (var hider in _activeBorderHiders) if (hider != null) Destroy(hider);
            _activeBorderHiders.Clear();
        }

        private void MarkForRefresh()
        {
            _needsPostDragRefresh = false; // Сбрасываем fallback

            if (!_pendingRefresh)
            {
                _pendingRefresh = true;
                StartCoroutine(RefreshNextFrame());
            }
        }

        #endregion

        #region Public API

        public InventoryController GetControllerForGrid(GridType gridType) => gridType switch
        {
            GridType.Pockets => _pocketsController,
            GridType.Pocket2 => _pocket2Controller,
            GridType.Backpack => _backpackController,
            GridType.Container => _activeContainerController,
            _ => null
        };

        public int GetGridWidth(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_COLUMNS;
            if (gridType == GridType.Pocket2) return POCKET_COLUMNS;
            if (gridType == GridType.Backpack) return _currentBackpackCols; // ФИКС БАГ #4
            if (gridType == GridType.Container) return _currentContainerCols; // ФИКС БАГ #2
            var c = GetControllerForGrid(gridType);
            return c?.Width ?? 0;
        }

        public int GetGridHeight(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_ROWS;
            if (gridType == GridType.Pocket2) return POCKET_ROWS;
            if (gridType == GridType.Backpack) return _currentBackpackRows; // ФИКС БАГ #4
            if (gridType == GridType.Container) return _currentContainerRows; // ФИКС БАГ #2
            var c = GetControllerForGrid(gridType);
            return c?.Height ?? 0;
        }

        public void OnEquipmentSlotDrop(K_EquipmentSlotUI slot, PointerEventData eventData)
        {
            if (slot == null || eventData?.pointerDrag == null) return;

            var draggedUI = eventData.pointerDrag.GetComponent<UI_Item>();
            if (draggedUI?.Item != null)
            {
                var item = draggedUI.Item;

                // ВСЕГДА валидируем тип предмета — даже если предмет уже удалён из сетки.
                // Раньше _dragItemRemoved вызывал short-circuit и валидация пропускалась.
                if (!ValidateEquipItem(item, slot))
                {
                    // Невалидный тип (пистолет в Primary и т.д.) — не делаем _dropHandled,
                    // чтобы EndDragComplete вернул предмет обратно в сетку.
                    return;
                }

                // Если слот ЗАНЯТ — пробуем swap: старый предмет → на место нового в инвентаре
                if (slot.IsOccupied && slot.EquippedItem != null)
                {
                    var oldEquipped = slot.EquippedItem;
                    var originController = GetControllerForGrid(_dragOriginGridType);

                    if (originController != null)
                    {
                        // Старый предмет наследует разворот нового
                        oldEquipped.RestoreRotationState(item.RotationAngle);

                        // Пытаемся поставить старый предмет на исходную позицию нового
                        int placed = originController.TryPlaceItem(oldEquipped, _dragOriginX, _dragOriginY);
                        if (placed == 0)
                        {
                            // Исходная позиция занята — пробуем любое свободное место в той же сетке
                            bool fallback = originController.TryPlaceItemInFirstFreeSlot(oldEquipped);
                            placed = fallback ? 1 : 0;
                        }

                        if (placed == 0)
                        {
                            // Старый предмет больше нового / нет места — ОТМЕНА swap.
                            // EndDragComplete вернёт новый предмет обратно в сетку.
                            return;
                        }

                        // Старый предмет размещён в инвентаре — очищаем слот
                        slot.SetEquippedItem(null);
                    }
                    else
                    {
                        // Нет контроллера для исходной сетки — отмена
                        return;
                    }
                }

                // Успех: экипируем новый предмет
                _dragItemRemoved = false;
                _dropHandled = true;
                _needsPostDragRefresh = false; // Отменяем отложенный возврат
                slot.OnDropItem(item);
                draggedUI.gameObject.SetActive(false);
                ReturnToPool(draggedUI);

                _isDragging = false;
                _draggedItem = null;
                ClearDragCellHighlights();
                if (_dragGhost != null) _dragGhost.SetActive(false);
                if (_postDragRefreshCoroutine != null)
                {
                    StopCoroutine(_postDragRefreshCoroutine);
                    _postDragRefreshCoroutine = null;
                }
                _needsPostDragRefresh = false;

                ForceRefresh();
                return;
            }

            // Drag из другого слота экипировки (slot → slot)
            if (_draggedFromEquipmentSlot != null && _draggedFromSlotItem != null)
            {
                if (ValidateEquipItem(_draggedFromSlotItem, slot))
                    TryEquipItemFromSlot(_draggedFromEquipmentSlot, slot);
            }
        }

        #endregion

        #region Hover Highlight

        /// <summary>
        /// TASK 1: Выделение предмета при наведении (hover).
        /// Вызывается из UI_Item.OnPointerEnter.
        /// </summary>
        public void OnItemHovered(UI_Item hoveredItem)
        {
            if (!_enableHoverHighlight) return;
            if (hoveredItem == null || hoveredItem.Item == null) return;
            if (_isDragging) return;

            // Снимаем с предыдущего
            if (_hoveredItem != null && _hoveredItem != hoveredItem)
                _hoveredItem.SetSelected(false);

            hoveredItem.SetSelected(true);
            _hoveredItem = hoveredItem;
        }

        /// <summary>Снять выделение при уходе курсора.</summary>
        public void OnItemUnhovered(UI_Item unhoveredItem)
        {
            if (unhoveredItem == null) return;
            if (_hoveredItem == unhoveredItem)
            {
                unhoveredItem.SetSelected(false);
                _hoveredItem = null;
            }
        }

        /// <summary>Снять hover со всех предметов.</summary>
        private void ClearHover()
        {
            if (_hoveredItem != null)
            {
                _hoveredItem.SetSelected(false);
                _hoveredItem = null;
            }
        }

        #endregion

        #region Drag Outline & Snap Helpers

        /// <summary>
        /// ФИКС #5: Настраивает призрак как обводку (semi-transparent rect без иконки).
        /// </summary>
        private void SetupDragOutline(InventoryItem item)
        {
            if (_dragGhost == null || _dragGhostRT == null) return;

            if (_rootCanvasTransform != null)
                _dragGhost.transform.SetParent(_rootCanvasTransform, false);

            // Root: обводка (semi-transparent цвет, без sprite)
            _dragGhostRT.anchorMin = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchorMax = new Vector2(0.5f, 0.5f);
            _dragGhostRT.pivot = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchoredPosition = Vector2.zero;
            _dragGhostRT.localScale = Vector3.one;
            _dragGhostRT.localRotation = Quaternion.identity;
            _dragGhostRT.SetAsLastSibling();

            if (_dragGhostRootImage != null)
            {
                _dragGhostRootImage.sprite = null;
                _dragGhostRootImage.type = Image.Type.Simple;
                _dragGhostRootImage.color = Color.clear;
                _dragGhostRootImage.enabled = false;
                _dragGhostRootImage.raycastTarget = false;
            }

            // TASK 4: Иконка ВИДНА — предмет «летает» над ячейками
            if (_dragGhostImage != null)
            {
                _dragGhostImage.enabled = true;
                _dragGhostImage.sprite = item.Data.Icon;
                _dragGhostImage.preserveAspect = false;
            }

            // Название предмета на ghost (скрыто при перетаскивании)
            if (_dragGhostNameText != null)
            {
                _dragGhostNameText.text = "";
                _dragGhostNameText.gameObject.SetActive(false);
            }

            // Калибр на ghost (скрыто при перетаскивании)
            if (_dragGhostCaliberText != null)
            {
                _dragGhostCaliberText.text = string.Empty;
                _dragGhostCaliberText.gameObject.SetActive(false);
            }

            UpdateGhostSize();
            UpdateGhostRotation();
        }

        /// <summary>
        /// ФИКС #1: Вычисляет top-left позицию предмета из позиции курсора (центр предмета).
        /// </summary>
        public static (int x, int y) CalculateSnapPosition(
            int cursorSlotX, int cursorSlotY, Vector2Int itemSize, int gridWidth, int gridHeight)
        {
            // Cursor = центр предмета. Top-left = cursor - size/2.
            int targetX = cursorSlotX - itemSize.x / 2;
            int targetY = cursorSlotY - itemSize.y / 2;

            // Clamp чтобы предмет не вылезал за сетку
            int maxX = Mathf.Max(0, gridWidth - itemSize.x);
            int maxY = Mathf.Max(0, gridHeight - itemSize.y);

            targetX = Mathf.Clamp(targetX, 0, maxX);
            targetY = Mathf.Clamp(targetY, 0, maxY);

            return (targetX, targetY);
        }

        /// <summary>
        /// Публичный метод для K_InventorySlotUI — рассчитывает скорректированную позицию drop.
        /// </summary>
        public (int x, int y) GetAdjustedDropPosition(int slotX, int slotY, Vector2Int itemSize, GridType gridType)
        {
            // ФИКС БАГ #2: Используем реальные размеры UI-сетки, не controller.Width
            int gridW = GetGridWidth(gridType);
            int gridH = GetGridHeight(gridType);
            if (gridW <= 0 || gridH <= 0)
            {
                var controller = GetControllerForGrid(gridType);
                gridW = controller?.Width ?? 0;
                gridH = controller?.Height ?? 0;
            }
            if (gridW <= 0) return (slotX, slotY);
            return CalculateSnapPosition(slotX, slotY, itemSize, gridW, gridH);
        }

        #endregion

        #region Debug Helpers

        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs)
                UnityEngine.Debug.Log(message);
        }

        #endregion
    }
}