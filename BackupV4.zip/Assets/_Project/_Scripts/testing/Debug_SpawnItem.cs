﻿using UnityEngine;
using K_Incident.Core.Inventory;

namespace K_Incident.Core
{
    /// <summary>
    /// Отладочный компонент для спавна предметов.
    /// ✅ ИСПРАВЛЕНО БАГ 5: Опция _skipIfAlreadyExists (по умолчанию FALSE).
    /// ✅ ИСПРАВЛЕНО: Поддержка выбора целевого контроллера (Pockets/Backpack).
    /// ✅ ИСПРАВЛЕНО: Не спавнит предмет если нет места.
    /// </summary>
    public class Debug_SpawnItem : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField, Tooltip("Перетащи сюда ItemStaticData из ItemDatabase")]
        private ItemStaticData _itemToSpawn;

        [SerializeField, Tooltip("Ссылка на K_InventorySetup в сцене")]
        private K_InventorySetup _inventorySetup;

        [Header("Spawn Settings")]
        [SerializeField, Tooltip("Количество предметов")]
        private int _quantity = 1;

        [SerializeField, Tooltip("Прочность (0-100)")]
        private int _durability = 100;

        [SerializeField, Tooltip("Повернуть предмет в сетке?")]
        private bool _rotated = false;

        [SerializeField, Tooltip("Целевой контроллер для спавна")]
        private TargetController _targetController = TargetController.Backpack;

        [Header("Debug")]
        [SerializeField, Tooltip("Показывать логи спавна")]
        private bool _debugLogs = true;

        [SerializeField, Tooltip("Пропускать спавн, если предмет уже есть (по умолчанию FALSE)")]
        private bool _skipIfAlreadyExists = false;

        #endregion

        #region Enums

        private enum TargetController
        {
            Pockets,
            Pocket2,
            Backpack
        }

        #endregion

        #region Fields

        private bool _isSpawning = false;

        #endregion

        #region Context Menu Actions

        [ContextMenu("🔫 Spawn Item")]
        public void SpawnItem()
        {
            if (_isSpawning)
            {
                if (_debugLogs) Debug.LogWarning("[Debug] Spawn already in progress, skipping...");
                return;
            }

            if (_itemToSpawn == null || _inventorySetup == null)
            {
                Debug.LogError("[Debug] ItemStaticData или InventorySetup не назначены!");
                return;
            }

            var playerController = _targetController switch
            {
                TargetController.Pockets => _inventorySetup.PocketsController,
                TargetController.Pocket2 => _inventorySetup.Pocket2Controller,
                TargetController.Backpack => _inventorySetup.BackpackController,
                _ => null
            };

            if (playerController == null)
            {
                Debug.LogError($"[Debug] {_targetController} InventoryController is null!");
                return;
            }

            // ✅ Проверка опциональна (по умолчанию выключена)
            if (_skipIfAlreadyExists && _quantity == 1 && _itemToSpawn.HardStackLimit == 1)
            {
                foreach (var existingItem in playerController.GetSaveData().GetItems())
                {
                    if (existingItem.ItemID == _itemToSpawn.ItemID)
                    {
                        if (_debugLogs) Debug.LogWarning($"[Debug] Item '{_itemToSpawn.DisplayName}' already exists! Skipping.");
                        return;
                    }
                }
            }

            // Проверяем, есть ли место для предмета ПЕРЕД созданием
            Vector2Int itemSize = _rotated
                ? new Vector2Int(_itemToSpawn.Size.y, _itemToSpawn.Size.x)
                : _itemToSpawn.Size;

            var tempItem = new InventoryItem(_itemToSpawn, GlobalIDManager.GenerateID(), _quantity, _durability, _rotated);

            bool hasSpace = false;
            var sd = playerController.GetSaveData();
            for (int y = 0; y < sd.Height && !hasSpace; y++)
                for (int x = 0; x < sd.Width && !hasSpace; x++)
                    if (playerController.CanPlaceItem(tempItem, x, y))
                        hasSpace = true;

            if (!hasSpace)
            {
                if (_debugLogs) Debug.LogWarning($"[Debug] ❌ No space for '{_itemToSpawn.DisplayName}' (size {itemSize.x}x{itemSize.y}) in {_targetController}");
                return;
            }

            _isSpawning = true;

            try
            {
                bool placed = playerController.TryPlaceItemInFirstFreeSlot(tempItem);

                if (placed)
                {
                    if (_debugLogs) Debug.Log($"[Debug] ✅ Spawned '{_itemToSpawn.DisplayName}' x{_quantity} in {_targetController}");
                }
                else
                {
                    if (_debugLogs) Debug.LogWarning($"[Debug] ❌ Failed to place '{_itemToSpawn.DisplayName}' in {_targetController}");
                }
            }
            finally
            {
                _isSpawning = false;
            }
        }

        [ContextMenu("🔫 Spawn 5x Item")]
        public void SpawnMultipleItems()
        {
            int originalQuantity = _quantity;
            _quantity = 5;
            SpawnItem();
            _quantity = originalQuantity;
        }

        [ContextMenu("🗑️ Clear Pockets")]
        public void ClearPockets()
        {
            if (_inventorySetup?.PocketsController != null)
            {
                _inventorySetup.PocketsController.Clear();
                if (_debugLogs) Debug.Log("[Debug] Pocket 1 cleared.");
            }
        }

        [ContextMenu("🗑️ Clear Pocket 2")]
        public void ClearPocket2()
        {
            if (_inventorySetup?.Pocket2Controller != null)
            {
                _inventorySetup.Pocket2Controller.Clear();
                if (_debugLogs) Debug.Log("[Debug] Pocket 2 cleared.");
            }
        }

        [ContextMenu("🗑️ Clear Backpack")]
        public void ClearBackpack()
        {
            if (_inventorySetup?.BackpackController != null)
            {
                _inventorySetup.BackpackController.Clear();
                if (_debugLogs) Debug.Log("[Debug] Backpack cleared.");
            }
        }

        [ContextMenu("🗑️ Clear All")]
        public void ClearAll()
        {
            ClearPockets();
            ClearPocket2();
            ClearBackpack();
        }

        #endregion
    }
}