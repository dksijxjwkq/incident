﻿using System;
using UnityEngine;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// Предмет в инвентаре. Содержит ссылку на статические данные + динамическое состояние.
    /// </summary>
    [Serializable]
    public class InventoryItem
    {
        [SerializeField] private ItemStaticData _data;
        [SerializeField] private uint _instanceID;
        [SerializeField] private int _quantity;
        [SerializeField] private int _durability;
        [SerializeField] private bool _isRotated;

        [SerializeField] private int _rotationAngle = 0;
        [NonSerialized] private Vector2Int _sizeNormal;
        [NonSerialized] private Vector2Int _sizeRotated;
        [NonSerialized] private bool _sizeCached;

        public InventoryItem(ItemStaticData data, uint instanceID, int quantity, int durability, bool isRotated)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (instanceID == 0) throw new ArgumentException("InstanceID must be > 0", nameof(instanceID));
            if (quantity <= 0) throw new ArgumentException("Quantity must be > 0", nameof(quantity));

            _data = data;
            _instanceID = instanceID;
            _quantity = quantity;
            _durability = Mathf.Clamp(durability, 0, data.MaxDurability);
            _isRotated = isRotated;
            _rotationAngle = isRotated ? -90 : 0;
            CacheSizes();
        }

        /// <summary>
        /// Вызывается Unity после десериализации.
        /// Защита: если _isRotated=true но _rotationAngle==0 (старые сохранения),
        /// восстанавливаем угол чтобы CurrentSize был корректным.
        /// </summary>
#if UNITY_EDITOR
        void OnValidate()
        {
            if (_isRotated && _rotationAngle % 180 == 0)
                _rotationAngle = -90;
            else if (!_isRotated && _rotationAngle % 180 != 0)
                _rotationAngle = 0;
            _sizeCached = false;
        }
#endif

        public ItemStaticData Data => _data;
        public uint InstanceID => _instanceID;
        public ushort PrefabID => _data?.PrefabID ?? 0;
        public ItemType Type => _data?.Type ?? ItemType.Misc;
        public int Quantity => _quantity;
        public int Durability => _durability;
        public bool IsRotated => _rotationAngle != 0;
        public int RotationAngle => _rotationAngle;
        public float IconBaseRotation => _data?.IconBaseRotation ?? 0f;

        public Vector2Int CurrentSize
        {
            get
            {
                if (!_sizeCached) CacheSizes();
                return _rotationAngle == 0 ? _sizeNormal : _sizeRotated;
            }
        }

        public int TotalWeightGrams => (_data?.WeightGrams ?? 0) * _quantity;
        public bool IsFullStack => _quantity >= (_data?.HardStackLimit ?? 1);
        public int SpaceInStack => (_data?.HardStackLimit ?? 1) - _quantity;

        internal void AddQuantity(int amount) =>
            _quantity = Mathf.Min(_quantity + amount, _data?.HardStackLimit ?? int.MaxValue);

        internal void RemoveQuantity(int amount) =>
            _quantity = Mathf.Max(_quantity - amount, 0);

        /// <summary>
        /// Вращение предмета: только 2 состояния — 0° и -90°.
        /// Циклично: 0 → -90 → 0 → -90 → ...
        /// </summary>
        public void Rotate()
        {
            if (_data == null || !_data.CanRotate) return;
            _rotationAngle = _rotationAngle == 0 ? -90 : 0;
            _isRotated = _rotationAngle != 0;
            _sizeCached = false;
        }

        /// <summary>
        /// Восстанавливает состояние вращения. Clamp к 0 или -90.
        /// </summary>
        internal void RestoreRotationState(int angle)
        {
            _rotationAngle = (angle % 180 != 0) ? -90 : 0;
            _isRotated = _rotationAngle != 0;
            _sizeCached = false;
        }

        public bool CanStackWith(InventoryItem other) =>
            other != null && _data?.PrefabID == other.PrefabID && _quantity < (_data?.HardStackLimit ?? 1);

        public bool CanFitInSpace(int width, int height)
        {
            var size = CurrentSize;
            return size.x <= width && size.y <= height;
        }

        public SavedItem ToSaveData(int x, int y) =>
            new SavedItem(_data?.ItemID ?? "", _instanceID, x, y, _quantity, _durability, _isRotated);

        public static InventoryItem FromSaveData(SavedItem saveData, ItemStaticData data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));
            if (!saveData.IsValid())
            {
                Debug.LogWarning($"[InventoryItem] Invalid SavedItem: ItemID='{saveData.ItemID}', InstanceID={saveData.InstanceID}");
                return null;
            }
            if (saveData.ItemID != data.ItemID)
            {
                Debug.LogError($"[InventoryItem] ItemID mismatch: Saved='{saveData.ItemID}' != Template='{data.ItemID}'");
                return null;
            }
            var item = new InventoryItem(data, saveData.InstanceID, saveData.Quantity, saveData.Durability, saveData.IsRotated);
            if (saveData.IsRotated) item._rotationAngle = -90;
            return item;
        }

        private void CacheSizes()
        {
            if (_data == null)
            {
                _sizeNormal = _sizeRotated = new Vector2Int(1, 1);
                _sizeCached = true;
                return;
            }
            _sizeNormal = _data.Size;
            _sizeRotated = new Vector2Int(_data.Size.y, _data.Size.x);
            _sizeCached = true;
        }

        [ContextMenu("Debug: Print Info")]
        public void DebugPrint()
        {
            Debug.Log($"[InventoryItem] {_data?.ItemID ?? "NULL"} | Qty: {_quantity} | Size: {CurrentSize.x}x{CurrentSize.y} | Angle: {_rotationAngle}°");
        }
    }
}