﻿using K_Incident.Core.Inventory;
using System;
using UnityEngine;

namespace K_Incident.Core
{
    /// <summary>
    /// Точка входа для системы инвентаря.
    /// ✅ ИСПРАВЛЕНО БАГ 4: Три независимых контроллера (Pocket1 2x2 + Pocket2 2x2 + Backpack 8x10).
    /// ✅ ИСПРАВЛЕНО БАГ 5: Глубокое клонирование InventoryData для защиты ScriptableObject от мутации в Editor.
    /// </summary>
    public class K_InventorySetup : MonoBehaviour
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField, Tooltip("База данных предметов (ScriptableObject)")]
        private ItemDatabase _database;

        [Header("Initial Data (Optional)")]
        [SerializeField, Tooltip("Начальные данные КАРМАНА 1 (опционально)")]
        private InventoryData _initialPocketsData;

        [SerializeField, Tooltip("Начальные данные КАРМАНА 2 (опционально)")]
        private InventoryData _initialPocket2Data;

        [SerializeField, Tooltip("Начальные данные РЮКЗАКА (опционально)")]
        private InventoryData _initialBackpackData;

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = true;

        #endregion

        #region Constants

        private const int POCKETS_WIDTH = 2;
        private const int POCKETS_HEIGHT = 2;
        private const int DEFAULT_BACKPACK_WIDTH = 8;
        private const int DEFAULT_BACKPACK_HEIGHT = 10;
        private const uint INSTANCE_ID_BUFFER = 10000;

        #endregion

        #region Fields

        private InventoryController _pocketsController;
        private InventoryController _pocket2Controller;
        private InventoryController _backpackController;
        private K_WeightManager _cachedWeightManager;

        #endregion

        #region Properties

        public static ItemDatabase DatabaseInstance { get; private set; }
        public static bool IsInitialized { get; private set; } = false;

        /// <summary>Контроллер КАРМАНА 1 (2x2)</summary>
        public InventoryController PocketsController => _pocketsController;

        /// <summary>Контроллер КАРМАНА 2 (2x2)</summary>
        public InventoryController Pocket2Controller => _pocket2Controller;

        /// <summary>Контроллер РЮКЗАКА (на спине, 8x10)</summary>
        public InventoryController BackpackController => _backpackController;

        /// <summary>
        /// ⚠️ DEPRECATED: Оставлено для обратной совместимости.
        /// Возвращает PocketsController. Используйте PocketsController или BackpackController явно.
        /// </summary>
        [Obsolete("Use PocketsController or BackpackController explicitly")]
        public InventoryController Controller => _pocketsController;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            if (_database == null)
            {
                Debug.LogError("[InventorySetup] CRITICAL: ItemDatabase NOT assigned!");
                enabled = false;
                return;
            }

            uint globalMaxId = FindGlobalMaxInstanceId();
            GlobalIDManager.InitWithMaxId(globalMaxId);

            DatabaseInstance = _database;
            _database.Initialize();

            // ✅ ФИКС БАГОВ 4 и 5: Глубокое клонирование + жесткие размеры
            var runtimePocketsData = CloneInventoryData(_initialPocketsData, POCKETS_WIDTH, POCKETS_HEIGHT);
            _pocketsController = new InventoryController(runtimePocketsData, _database, "Player_Pocket1");

            var runtimePocket2Data = CloneInventoryData(_initialPocket2Data, POCKETS_WIDTH, POCKETS_HEIGHT);
            _pocket2Controller = new InventoryController(runtimePocket2Data, _database, "Player_Pocket2");

            var runtimeBackpackData = CloneInventoryData(_initialBackpackData, DEFAULT_BACKPACK_WIDTH, DEFAULT_BACKPACK_HEIGHT);
            _backpackController = new InventoryController(runtimeBackpackData, _database, "Player_Backpack");

            _pocketsController.OnInventoryChanged += OnInventoryUpdated;
            _pocketsController.OnWeightChanged += OnWeightUpdated;
            _pocket2Controller.OnInventoryChanged += OnInventoryUpdated;
            _pocket2Controller.OnWeightChanged += OnWeightUpdated;
            _backpackController.OnInventoryChanged += OnInventoryUpdated;
            _backpackController.OnWeightChanged += OnWeightUpdated;

            IsInitialized = true;
            LogDebug($"[InventorySetup] ✅ Initialized. Pocket1: {POCKETS_WIDTH}x{POCKETS_HEIGHT}, Pocket2: {POCKETS_WIDTH}x{POCKETS_HEIGHT}, Backpack: {DEFAULT_BACKPACK_WIDTH}x{DEFAULT_BACKPACK_HEIGHT}");
        }

        private void Start()
        {
            if (!IsInitialized) return;

            K_SaveManager.Instance?.Register(_pocketsController);
            K_SaveManager.Instance?.Register(_pocket2Controller);
            K_SaveManager.Instance?.Register(_backpackController);
            LogDebug("[InventorySetup] All controllers registered with SaveManager.");

            _cachedWeightManager = FindFirstObjectByType<K_WeightManager>();
            if (_cachedWeightManager != null)
            {
                _pocketsController.OnWeightChanged += _ => UpdateTotalWeight();
                _pocket2Controller.OnWeightChanged += _ => UpdateTotalWeight();
                _backpackController.OnWeightChanged += _ => UpdateTotalWeight();
                UpdateTotalWeight();
                LogDebug("[InventorySetup] Connected to WeightManager (combined weight).");
            }
            else
            {
                Debug.LogWarning("[InventorySetup] K_WeightManager not found!");
            }
        }

        private void OnDestroy()
        {
            if (_pocketsController != null)
            {
                _pocketsController.OnInventoryChanged -= OnInventoryUpdated;
                _pocketsController.OnWeightChanged -= OnWeightUpdated;
                _pocketsController.Dispose();
                _pocketsController = null;
            }

            if (_pocket2Controller != null)
            {
                _pocket2Controller.OnInventoryChanged -= OnInventoryUpdated;
                _pocket2Controller.OnWeightChanged -= OnWeightUpdated;
                _pocket2Controller.Dispose();
                _pocket2Controller = null;
            }

            if (_backpackController != null)
            {
                _backpackController.OnInventoryChanged -= OnInventoryUpdated;
                _backpackController.OnWeightChanged -= OnWeightUpdated;
                _backpackController.Dispose();
                _backpackController = null;
            }

            DatabaseInstance = null;
            IsInitialized = false;
            _cachedWeightManager = null;
        }

        #endregion

        #region Event Handlers

        private void OnInventoryUpdated()
        {
            LogDebug("[Inventory] Changed!");
        }

        private void OnWeightUpdated(float kg) { }

        private void UpdateTotalWeight()
        {
            if (_cachedWeightManager == null) return;
            float total = 0f;
            if (_pocketsController != null) total += _pocketsController.CurrentWeightKg;
            if (_pocket2Controller != null) total += _pocket2Controller.CurrentWeightKg;
            if (_backpackController != null) total += _backpackController.CurrentWeightKg;
            _cachedWeightManager.SetWeight(total);
        }

        #endregion

        #region Utilities

        /// <summary>
        /// ✅ Глубокое клонирование InventoryData с жестким ограничением размеров.
        /// Защищает ScriptableObject от мутации в Editor и гарантирует корректные размеры.
        /// </summary>
        private InventoryData CloneInventoryData(InventoryData source, int forceWidth, int forceHeight)
        {
            var clone = new InventoryData(forceWidth, forceHeight);

            if (source != null)
            {
                foreach (var savedItem in source.GetItems())
                {
                    if (savedItem.X < forceWidth && savedItem.Y < forceHeight)
                    {
                        clone.AddItem(savedItem);
                    }
                    else
                    {
                        Debug.LogWarning($"[InventorySetup] Skipped item {savedItem.ItemID} at ({savedItem.X},{savedItem.Y}) - outside {forceWidth}x{forceHeight} grid");
                    }
                }
            }

            return clone;
        }

        private uint FindGlobalMaxInstanceId()
        {
            uint maxId = 0;

            if (_initialPocketsData != null)
            {
                foreach (var item in _initialPocketsData.GetItems())
                    if (item.InstanceID > maxId) maxId = item.InstanceID;
            }

            if (_initialPocket2Data != null)
            {
                foreach (var item in _initialPocket2Data.GetItems())
                    if (item.InstanceID > maxId) maxId = item.InstanceID;
            }

            if (_initialBackpackData != null)
            {
                foreach (var item in _initialBackpackData.GetItems())
                    if (item.InstanceID > maxId) maxId = item.InstanceID;
            }

            return maxId + INSTANCE_ID_BUFFER;
        }

        public static ItemDatabase GetDatabase()
        {
            if (!IsInitialized)
            {
                Debug.LogWarning("[InventorySetup] GetDatabase() called before initialization!");
                return null;
            }
            return DatabaseInstance;
        }

        private void LogDebug(string message)
        {
            if (_debugLogs) Debug.Log(message);
        }

        #endregion

        #region Editor Helpers

#if UNITY_EDITOR
        [ContextMenu("Print Both Grids")]
        private void PrintGrids()
        {
            Debug.Log("=== POCKET 1 ===");
            _pocketsController?.DebugPrintGrid();
            Debug.Log("=== POCKET 2 ===");
            _pocket2Controller?.DebugPrintGrid();
            Debug.Log("=== BACKPACK ===");
            _backpackController?.DebugPrintGrid();
        }

        [ContextMenu("Clear All")]
        private void ClearAll()
        {
            _pocketsController?.Clear();
            _pocket2Controller?.Clear();
            _backpackController?.Clear();
            Debug.Log("[InventorySetup] All inventories cleared.");
        }
#endif

        #endregion
    }
}