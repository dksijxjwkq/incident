﻿using K_Incident.Core.Inventory;
using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace K_Incident.Core.Inventory
{
    public enum EquipmentSlotType { Primary, Pistol, Backpack }

    /// <summary>
    /// UI слота экипировки.
    /// ФИКС БАГ #5: Unequip теперь пробует Pockets, затем Backpack.
    /// </summary>
    public class K_EquipmentSlotUI : MonoBehaviour,
        IPointerClickHandler,
        IPointerEnterHandler,
        IPointerExitHandler,
        IDropHandler,
        IBeginDragHandler,
        IDragHandler,
        IEndDragHandler
    {
        #region Constants

        private const float FLASH_ERROR_DURATION = 0.15f;
        private const float HOVER_THROTTLE = 0.2f;
        private const float DROP_FEEDBACK_DURATION = 0.1f;

        private static readonly Color COLOR_VALID_DROP = new Color(0.2f, 0.8f, 0.2f, 0.6f);
        private static readonly Color COLOR_INVALID_DROP = new Color(0.9f, 0.2f, 0.2f, 0.6f);
        private static readonly Color COLOR_HOVER = new Color(1f, 1f, 1f, 0.15f);
        private static readonly Color COLOR_ITEM_HOVER = new Color(1f, 0.85f, 0f, 0.35f);

        private static readonly Vector2 SIZE_PRIMARY = new Vector2(130f, 315f);
        private static readonly Vector2 SIZE_PISTOL = new Vector2(120f, 120f);
        private static readonly Vector2 SIZE_BACKPACK = new Vector2(100f, 100f);

        #endregion

        #region Inspector Fields

        [SerializeField] private Image _icon;
        [SerializeField] private TextMeshProUGUI _label;
        [SerializeField] private Image _highlight;
        [SerializeField, Tooltip("Тип слота: Primary, Pistol, Backpack")]
        private EquipmentSlotType _slotType;
        [SerializeField, Tooltip("Если нет места в инвентаре при снятии - попытаться вернуть предмет в инвентарь.")]
        private bool _spawnOnGroundIfNoSpace;
        [SerializeField, Tooltip("LayerMask для raycast при спавне предмета на землю")]
        private LayerMask _groundLayer = Physics.DefaultRaycastLayers;

        [Header("Item Hover Highlight")]
        [SerializeField, Tooltip("Цвет подсветки при наведении на занятый слот. По умолчанию совпадает с UI_Item.")]
        private Color _itemHoverColor = new Color(1f, 0.85f, 0f, 0.35f);

        [Header("Pixel Perfect Bottom Border Fix")]
        [SerializeField, Tooltip("Цвет нижней границы. Подбери под цвет рамки слота.")]
        private Color _bottomBorderColor = new Color(0.3f, 0.3f, 0.3f, 1f);
        [SerializeField, Tooltip("Толщина нижней границы (px).")]
        private float _bottomBorderHeight = 1f;
        [SerializeField, Tooltip("Сдвиг границы вверх от математического низа (px).")]
        private float _bottomBorderOffset = 1f;

        #endregion

        #region Fields

        public event Action<K_EquipmentSlotUI, bool> OnHoverChanged;
        public event Action<K_EquipmentSlotUI, InventoryItem> OnValidDropPreview;
        public event Action<K_EquipmentSlotUI> OnDropAccepted;

        private K_InventoryUI _inventoryUI;
        private InventoryItem _equippedItem;
        private RectTransform _rectTransform;
        private Coroutine _hoverThrottleCoroutine;
        private Coroutine _flashErrorCoroutine;
        private Coroutine _dropFeedbackCoroutine;
        private bool _isHovering;
        private bool _isDraggingOver;
        private bool _isDraggingFromSlot;
        private Image _itemHoverOverlay; // Оверлей поверх иконки для hover-эффекта

        #endregion

        #region Properties

        public EquipmentSlotType SlotType => _slotType;
        public bool IsOccupied => _equippedItem != null;
        public InventoryItem EquippedItem => _equippedItem;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _rectTransform = GetComponent<RectTransform>();

            if (_highlight != null)
            {
                _highlight.enabled = false;
                _highlight.raycastTarget = false;
                _highlight.color = Color.clear;
            }

            if (_icon != null)
                _icon.enabled = false;

            // ФИКС PP: Рисуем нижнюю границу чтобы Pixel Perfect её не обрезал
            DrawBottomBorderFix();

            // Создаём оверлей поверх всех детей для hover-эффекта на предмете
            EnsureItemHoverOverlay();
        }

        /// <summary>
        /// Рисует нижнюю границу слота отдельной линией.
        /// Нужна потому что Pixel Perfect на Canvas обрезает нижнюю рамку спрайта.
        /// </summary>
        private void DrawBottomBorderFix()
        {
            if (_rectTransform == null) return;

            // Удаляем старую если есть
            Transform existing = transform.Find("SlotBottomBorderFix");
            if (existing != null) Destroy(existing);

            var obj = new GameObject("SlotBottomBorderFix", typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(transform, false);

            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(1f, 0f);
            rt.pivot = new Vector2(0.5f, 0f);
            rt.anchoredPosition = new Vector2(0f, _bottomBorderOffset);
            rt.sizeDelta = new Vector2(0f, _bottomBorderHeight);

            var img = obj.GetComponent<Image>();
            img.color = _bottomBorderColor;
            img.raycastTarget = false;
            img.maskable = true;
        }

        public void Initialize(K_InventoryUI inventoryUI, EquipmentSlotType slotType)
        {
            _inventoryUI = inventoryUI;
            _slotType = slotType;
            if (_rectTransform != null)
                _rectTransform.sizeDelta = GetSlotSize(slotType);
            UpdateLabelText();
            Refresh();
        }

        private static Vector2 GetSlotSize(EquipmentSlotType type) => type switch
        {
            EquipmentSlotType.Primary => SIZE_PRIMARY,
            EquipmentSlotType.Pistol => SIZE_PISTOL,
            EquipmentSlotType.Backpack => SIZE_BACKPACK,
            _ => SIZE_PISTOL
        };

        private void UpdateLabelText()
        {
            if (_label == null) return;
            _label.text = _slotType switch
            {
                EquipmentSlotType.Primary => gameObject.name.Contains("1") ? "ОСНОВНОЕ 1" : "ОСНОВНОЕ 2",
                EquipmentSlotType.Pistol => "ПИСТОЛЕТ",
                EquipmentSlotType.Backpack => "РЮКЗАК",
                _ => string.Empty
            };
        }

        #endregion

        #region Pointer Handlers

        public void OnPointerEnter(PointerEventData eventData)
        {
            _isHovering = true;
            if (_hoverThrottleCoroutine == null)
                _hoverThrottleCoroutine = StartCoroutine(ThrottledHoverUpdate());

            // Подсветка занятого слота при наведении (как UI_Item в сетке)
            if (IsOccupied && !_isDraggingFromSlot)
                ShowItemHover();
            else if (_highlight != null && _highlight.enabled)
                _highlight.color = COLOR_HOVER;
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            _isHovering = false;
            _isDraggingOver = false;
            if (_hoverThrottleCoroutine != null)
            {
                StopCoroutine(_hoverThrottleCoroutine);
                _hoverThrottleCoroutine = null;
            }

            HideItemHover();

            if (!IsOccupied && _highlight != null && _highlight.enabled)
                _highlight.color = Color.clear;

            OnHoverChanged?.Invoke(this, false);
        }

        private IEnumerator ThrottledHoverUpdate()
        {
            yield return new WaitForSeconds(HOVER_THROTTLE);
            while (_isHovering)
            {
                OnHoverChanged?.Invoke(this, true);
                yield return new WaitForSeconds(HOVER_THROTTLE);
            }
            _hoverThrottleCoroutine = null;
        }

        #endregion

        #region Drop Handler

        public void OnDrop(PointerEventData eventData)
        {
            TriggerDropFeedback(true);
            _inventoryUI?.OnEquipmentSlotDrop(this, eventData);
        }

        public void TriggerDropFeedback(bool isValid)
        {
            if (_highlight == null || !_highlight.enabled) return;
            if (_dropFeedbackCoroutine != null) StopCoroutine(_dropFeedbackCoroutine);
            _dropFeedbackCoroutine = StartCoroutine(FlashDropFeedback(isValid ? COLOR_VALID_DROP : COLOR_INVALID_DROP));
        }

        private IEnumerator FlashDropFeedback(Color targetColor)
        {
            if (_highlight == null) yield break;
            var originalColor = _highlight.color;
            _highlight.color = targetColor;
            yield return new WaitForSeconds(DROP_FEEDBACK_DURATION);
            if (_highlight != null)
                _highlight.color = _isHovering ? COLOR_HOVER : Color.clear;
            _dropFeedbackCoroutine = null;
        }

        #endregion

        #region Click Handler (Unequip by RMB)

        public void OnPointerClick(PointerEventData eventData)
        {
            if (eventData.button != PointerEventData.InputButton.Right) return;
            if (_equippedItem == null) return;
            Unequip();
        }

        /// <summary>
        /// ФИКС БАГ #5: Unequip теперь пробует Pocket1, Pocket2, затем Backpack.
        /// В оригинале пробовались только карманы (4x2 = 8 слотов).
        /// </summary>
        public void Unequip()
        {
            if (_equippedItem == null) return;
            if (_inventoryUI == null)
            {
                Debug.LogWarning("[EquipmentSlot] inventoryUI is null - cannot unequip");
                return;
            }

            bool placed = false;

            // Сначала пробуем карман 1
            var pocketsController = _inventoryUI.GetControllerForGrid(GridType.Pockets);
            if (pocketsController != null)
            {
                placed = pocketsController.TryPlaceItemInFirstFreeSlot(_equippedItem);
            }

            // Потом пробуем карман 2
            if (!placed)
            {
                var pocket2Controller = _inventoryUI.GetControllerForGrid(GridType.Pocket2);
                if (pocket2Controller != null)
                {
                    placed = pocket2Controller.TryPlaceItemInFirstFreeSlot(_equippedItem);
                }
            }

            // ФИКС БАГ #5: Если оба кармана полны — пробуем рюкзак
            if (!placed)
            {
                var backpackController = _inventoryUI.GetControllerForGrid(GridType.Backpack);
                if (backpackController != null)
                {
                    placed = backpackController.TryPlaceItemInFirstFreeSlot(_equippedItem);
                }
            }

            // Фоллбэк:spawn on ground
            if (!placed)
            {
                if (_spawnOnGroundIfNoSpace)
                {
                    SpawnItemOnGround(_equippedItem);
                }
                else
                {
                    if (_flashErrorCoroutine != null) StopCoroutine(_flashErrorCoroutine);
                    _flashErrorCoroutine = StartCoroutine(FlashSlotError());
                    Debug.LogWarning("[EquipmentSlot] No space in Pockets, Pocket2 or Backpack! Item NOT unequipped.");
                    return;
                }
            }

            if (_slotType == EquipmentSlotType.Backpack)
                _inventoryUI.OnBackpackUnequipped();

            _equippedItem = null;
            Refresh();
        }

        private IEnumerator FlashSlotError()
        {
            if (_icon == null) yield break;
            var originalColor = _icon.color;
            _icon.color = Color.red;
            yield return new WaitForSeconds(FLASH_ERROR_DURATION);
            if (_icon != null && _icon.gameObject.activeInHierarchy)
                _icon.color = originalColor;
        }

        private void SpawnItemOnGround(InventoryItem item)
        {
            if (item == null) return;
            Debug.LogWarning($"[EquipmentSlot] SpawnItemOnGround NOT IMPLEMENTED - returning {item.Data?.DisplayName ?? "Unknown"} to inventory");
            if (_inventoryUI != null)
            {
                var playerController = _inventoryUI.GetControllerForGrid(GridType.Pockets);
                if (playerController != null)
                {
                    bool placed = playerController.TryPlaceItemInFirstFreeSlot(item);
                    if (placed) return;
                }
            }
            Debug.LogError($"[EquipmentSlot] CRITICAL: Item {item.Data?.ItemID} could not be placed - ITEM LOST (prototype limitation)");
        }

        #endregion

        #region Drag from slot

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (_equippedItem == null || _inventoryUI == null) return;

            _isDraggingFromSlot = true;

            // Убираем подсветку при старте drag'а
            HideItemHover();

            if (_icon != null)
                _icon.color = new Color(1f, 1f, 1f, 0.5f);

            _inventoryUI.StartDragFromEquipmentSlot(this, eventData);
        }

        public void OnDrag(PointerEventData eventData)
        {
            if (!_isDraggingFromSlot || _inventoryUI == null) return;
            _inventoryUI.UpdateDragGhostPosition(eventData);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            if (!_isDraggingFromSlot) return;

            _isDraggingFromSlot = false;

            if (_icon != null)
                _icon.color = Color.white;

            _inventoryUI?.EndDragFromEquipmentSlot();
        }

        #endregion

        #region Item Management

        public void OnDropItem(InventoryItem item)
        {
#if UNITY_EDITOR
            Debug.Assert(item?.Data != null, $"[EquipmentSlot] OnDropItem called with invalid item data");
#endif
            if (!ValidateItemForSlot(item))
            {
                TriggerDropFeedback(false);
                return;
            }

            _equippedItem = item;
            Refresh();
            OnDropAccepted?.Invoke(this);
        }

        public bool ValidateItemForSlot(InventoryItem item)
        {
            if (item == null || item.Data == null) return false;

            return _slotType switch
            {
                EquipmentSlotType.Primary => item.Type == ItemType.Weapon && !item.Data.IsPistol,
                EquipmentSlotType.Pistol => item.Type == ItemType.Weapon && item.Data.IsPistol,
                EquipmentSlotType.Backpack => item.Data.IsBackpack,
                _ => false
            };
        }

        public bool CanAcceptItemPreview(InventoryItem item)
        {
            if (IsOccupied) return false;
            return ValidateItemForSlot(item);
        }

        public void UpdateDropPreview(InventoryItem item, bool isValid)
        {
            if (_highlight == null || !_highlight.enabled) return;
            _isDraggingOver = true;
            _highlight.color = isValid ? COLOR_VALID_DROP : COLOR_INVALID_DROP;
            _highlight.enabled = true;
            OnValidDropPreview?.Invoke(this, isValid ? item : null);
        }

        public void ClearDropPreview()
        {
            _isDraggingOver = false;
            if (_highlight != null && _highlight.enabled)
                _highlight.color = _isHovering ? COLOR_HOVER : Color.clear;
        }

        public void Refresh()
        {
            if (_icon == null) return;

            bool hasItem = _equippedItem != null && _equippedItem.Data?.Icon != null;

            if (hasItem)
            {
                _icon.sprite = _equippedItem.Data.Icon;
                _icon.enabled = true;
                _icon.color = Color.white;
                if (_icon.rectTransform != null)
                    _icon.rectTransform.localRotation = Quaternion.Euler(0f, 0f, -90f);
                // ФИКС: сохраняем пропорции иконки чтобы оружие не искажалось
                _icon.preserveAspect = true;
                // ФИКС: Метка не меняет цвет при наличии предмета
                if (_label != null)
                {
                    _label.gameObject.SetActive(true);
                    _label.color = Color.white;
                }
                // Подсветка: если наведены — показываем, иначе скрываем
                if (_isHovering && !_isDraggingFromSlot)
                    ShowItemHover();
                else
                    HideItemHover();
            }
            else
            {
                _icon.sprite = null;
                _icon.enabled = false;
                _icon.color = Color.white;
                // Восстанавливаем полную прозрачность метки
                if (_label != null)
                {
                    _label.gameObject.SetActive(true);
                    _label.color = Color.white;
                }
                if (_highlight != null)
                {
                    _highlight.enabled = _isHovering || _isDraggingOver;
                    _highlight.color = _isDraggingOver ? COLOR_VALID_DROP : (_isHovering ? COLOR_HOVER : Color.clear);
                }
            }
        }

        public void SetEquippedItem(InventoryItem item)
        {
            _equippedItem = item;
            Refresh();
        }

        private void OnDestroy()
        {
            if (_flashErrorCoroutine != null) StopCoroutine(_flashErrorCoroutine);
            if (_hoverThrottleCoroutine != null) StopCoroutine(_hoverThrottleCoroutine);
            if (_dropFeedbackCoroutine != null) StopCoroutine(_dropFeedbackCoroutine);
        }

        #endregion

        #region Item Hover Overlay

        /// <summary>
        /// Создаёт Image-оверлей поверх ВСЕХ детей слота (включая иконку).
        /// Нужен потому что _highlight может быть ниже _icon в иерархии
        /// и иконка перекрывает его. Этот оверлей всегда последний в иерархии.
        /// </summary>
        private void EnsureItemHoverOverlay()
        {
            if (_itemHoverOverlay != null) return;

            var obj = new GameObject("ItemHoverOverlay", typeof(RectTransform), typeof(Image));
            obj.transform.SetParent(transform, false);
            obj.transform.SetAsLastSibling(); // Поверх всего

            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = Vector2.zero; // Растянется на весь слот

            _itemHoverOverlay = obj.GetComponent<Image>();
            _itemHoverOverlay.sprite = null;
            _itemHoverOverlay.type = Image.Type.Simple;
            _itemHoverOverlay.color = Color.clear;
            _itemHoverOverlay.raycastTarget = false;
        }

        private void ShowItemHover()
        {
            if (_itemHoverOverlay == null) return;
            _itemHoverOverlay.transform.SetAsLastSibling(); // Гарантируем поверх иконки
            _itemHoverOverlay.color = _itemHoverColor;
        }

        private void HideItemHover()
        {
            if (_itemHoverOverlay == null) return;
            _itemHoverOverlay.color = Color.clear;
        }

        #endregion

        #region Editor Helpers

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (_highlight == null)
                _highlight = transform.Find("Highlight")?.GetComponent<Image>();
        }
#endif

        #endregion
    }
}