﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using K_Incident.Core;
using K_Incident.Core.Inventory;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.EventSystems;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// UI контроллер инвентаря (стилистика Escape from Tarkov).
    ///
    /// ИСПРАВЛЕННЫЕ БАГИ:
    /// #1: UI_Item.EnsureIconIsChild() убивал raycast target (исправлено в UI_Item.cs)
    /// #2: OpenContainer() — утечка подписок при смене контейнера
    /// #3: ReturnToPool() не удалял из _activeItems → коррупция пула
    /// #4: RefreshGrid использовал захардкоженные размеры рюкзака
    /// #6: EndDragComplete() вызывал лишний MarkForRefresh()
    /// #7: _cachedEventData создавался с null EventSystem
    /// </summary>
    [RequireComponent(typeof(CanvasGroup))]
    public class K_InventoryUI : MonoBehaviour
    {
        #region Inspector Fields

        [Header("Grid Config")]
        [SerializeField, Tooltip("Размер слота в пикселях")]
        private float _slotSize = 70f;

        [SerializeField, Tooltip("Отступ между слотами")]
        private float _slotSpacing = 0f;

        [Header("References")]
        [SerializeField] private K_InventorySetup _inventorySetup;
        [SerializeField] private TextMeshProUGUI _weightText;
        [SerializeField] private GameObject _slotPrefab;
        [SerializeField] private GameObject _uiItemPrefab;
        [SerializeField] private GameObject _dragGhostPrefab;

        [Header("Player Inventory (LEFT PANE)")]
        [SerializeField] private Transform _pocketsGrid;
        [SerializeField] private Transform _backpackGrid;
        [SerializeField] private GameObject _backpackPanel;
        [SerializeField] private Transform _pocketsItemsContainer;
        [SerializeField] private Transform _backpackItemsContainer;

        [Header("Equipment Slots")]
        [SerializeField] private K_EquipmentSlotUI _primarySlot1;
        [SerializeField] private K_EquipmentSlotUI _primarySlot2;
        [SerializeField] private K_EquipmentSlotUI _pistolSlot;
        [SerializeField] private K_EquipmentSlotUI _backpackSlot;

        [Header("Surroundings/Container (RIGHT PANE)")]
        [SerializeField] private GameObject _surroundingsPanel;
        [SerializeField] private Transform _surroundingsGrid;
        [SerializeField] private Transform _surroundingsItemsContainer;
        [SerializeField] private TextMeshProUGUI _containerNameText;

        [Header("Background")]
        [SerializeField, Tooltip("Объект с фоном инвентаря (Image). Raycast Target должен быть снят.")]
        private GameObject _inventoryBackground;

        [Header("Configuration")]
        [SerializeField] private KeyCode _openCloseKey = KeyCode.Tab;
        [SerializeField] private KeyCode _rotateKey = KeyCode.R;

        [Header("UI Colors")]
        [SerializeField] private Color _dragValidColor = new Color(0.33f, 0.55f, 0.33f, 0.7f);
        [SerializeField] private Color _dragInvalidColor = new Color(0.71f, 0.24f, 0.24f, 0.7f);
        [SerializeField] private Color _textNormalColor = new Color(0.71f, 0.73f, 0.75f);
        [SerializeField] private Color _textWarningColor = new Color(0.71f, 0.55f, 0.24f);
        [SerializeField] private Color _textCriticalColor = new Color(0.71f, 0.24f, 0.24f);

        [Header("Hover Highlight")]
        [SerializeField, Tooltip("Включить выделение предмета при наведении")]
        private bool _enableHoverHighlight = true;

        [Header("Occupied Cell Tint")]
        [SerializeField, Tooltip("Добавка к цвету ячеек занятых предметом (чуть светлее)")]
        private Color _occupiedCellTint = new Color(0.06f, 0.06f, 0.06f, 0f);

        [Header("Drag Cell Highlight (instead of ghost outline)")]
        [SerializeField, Tooltip("Цвет ячеек при валидной позиции drag (настраиваемый)")]
        private Color _dragCellValidColor = new Color(1f, 0.85f, 0f, 0.35f);
        [SerializeField, Tooltip("Цвет ячеек при невалидной позиции drag (настраиваемый)")]
        private Color _dragCellInvalidColor = new Color(0.85f, 0.15f, 0.15f, 0.5f);

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = true;

        #endregion

        #region Constants

        private const int POCKET_COLUMNS = 4;
        private const int POCKET_ROWS = 2;
        private const int BACKPACK_BASE_COLS = 8;
        private const int BACKPACK_BASE_ROWS = 10;

        private const int POOL_PREWARM_COUNT = 100;
        private const float UI_REFRESH_THROTTLE = 0.3f;
        private const int GHOST_SORTING_ORDER = 32000;
        private const float DROP_FALLBACK_DELAY = 0.05f;

        private const float WEIGHT_WARNING_RATIO = 0.9f;
        private const float WEIGHT_CRITICAL_RATIO = 1.1f;

        #endregion

        #region Fields

        private InventoryController _pocketsController;
        private InventoryController _backpackController;
        private InventoryController _activeContainerController;
        private CanvasGroup _canvasGroup;

        [SerializeField] private K_PlayerMotor _playerMotor;

        private bool _isOpen;
        private bool _isLootingContainer;
        private bool _pendingRefresh;
        private float _lastRefreshTime;

        private bool _isDragging;
        private UI_Item _draggedItem;
        private GameObject _dragGhost;
        private Image _dragGhostImage;
        private RectTransform _dragGhostIconRect;
        private CanvasGroup _dragGhostCanvasGroup;
        private Canvas _dragGhostCanvas;
        private RectTransform _dragGhostRT;
        private Transform _rootCanvasTransform;
        private readonly List<RaycastResult> _raycastBuffer = new List<RaycastResult>(8);
        private PointerEventData _cachedEventData;

        private K_EquipmentSlotUI _draggedFromEquipmentSlot;
        private InventoryItem _draggedFromSlotItem;

        // Hover
        private UI_Item _hoveredItem;

        // Drag cell highlighting
        private struct DragCellHighlight
        {
            public K_InventorySlotUI slot;
            public Color previousColor;
        }
        private readonly List<DragCellHighlight> _activeDragHighlights = new List<DragCellHighlight>(20);

        // Drag state: origin (for fallback on cancel)
        private GridType _dragOriginGridType;
        private int _dragOriginX, _dragOriginY;
        private int _dragOriginRotationAngle;
        private bool _dragItemRemoved;
        private bool _dropHandled;
        private Image _dragGhostRootImage;

        private Vector2 _pocketsGridPadding = Vector2.zero;
        private Vector2 _backpackGridPadding = Vector2.zero;
        private Vector2 _containerGridPadding = Vector2.zero;

        // ФИКС БАГ #4: Храним реальные размеры рюкзака
        private int _currentBackpackCols = BACKPACK_BASE_COLS;
        private int _currentBackpackRows = BACKPACK_BASE_ROWS;

        // ФИКС БАГ #6: Фоллбэк для refresh после неудачного drop
        private bool _needsPostDragRefresh;
        private Coroutine _postDragRefreshCoroutine;

        private readonly Queue<UI_Item> _itemPool = new Queue<UI_Item>(POOL_PREWARM_COUNT);
        private readonly Dictionary<string, UI_Item> _activeItems = new Dictionary<string, UI_Item>(200);

        private Action _onInventoryChangedHandler;
        private Action<float> _onWeightChangedHandler;
        private Action<InventoryItem, int, int> _onItemPlacedHandler;
        private Action<InventoryItem> _onItemChangedHandler;

        private Coroutine _refreshCoroutine;

        public static event Action<InventoryController> OnContainerClosed;

        #endregion

        #region Properties

        public bool IsOpen => _isOpen;
        public bool IsLooting => _isLootingContainer;
        public bool IsDragging => _isDragging;
        public float SlotSize => _slotSize;
        public float SlotSpacing => _slotSpacing;

        public bool IsDraggingFromEquipmentSlot => _draggedFromEquipmentSlot != null && _draggedFromSlotItem != null;
        public InventoryItem DraggedFromSlotItem => _draggedFromSlotItem;

        #endregion

        #region Unity Lifecycle

        private void Awake()
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null) _canvasGroup = gameObject.AddComponent<CanvasGroup>();
            InitializeCanvasState();

            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(false);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(false);

            _rootCanvasTransform = FindRootCanvas();

            if (_dragGhostPrefab != null)
            {
                _dragGhost = Instantiate(_dragGhostPrefab);
                _dragGhost.SetActive(false);

                RectTransform prefabRT = _dragGhost.GetComponent<RectTransform>();
                Image prefabImage = _dragGhost.GetComponent<Image>();
                _dragGhostRT = prefabRT;

                if (prefabImage != null)
                {
                    _dragGhostRootImage = prefabImage;
                    _dragGhostImage = CreateChildIcon(_dragGhostRT, prefabImage);
                    _dragGhostIconRect = _dragGhostImage.rectTransform;
                    prefabImage.enabled = false;
                    prefabImage.raycastTarget = false;
                }
                else
                {
                    Debug.LogError("[InventoryUI] DragGhost Prefab MISSING Image on root!");
                    _dragGhost = null;
                }

                if (_dragGhostRT != null && _dragGhostImage != null)
                {
                    _dragGhostImage.raycastTarget = false;
                    _dragGhostImage.color = Color.white;
                    _dragGhostImage.enabled = true;

                    _dragGhostCanvasGroup = _dragGhost.GetComponent<CanvasGroup>();
                    if (_dragGhostCanvasGroup == null)
                        _dragGhostCanvasGroup = _dragGhost.AddComponent<CanvasGroup>();
                    _dragGhostCanvasGroup.blocksRaycasts = false;
                    _dragGhostCanvasGroup.interactable = false;
                    _dragGhostCanvasGroup.alpha = 1f;

                    _dragGhostCanvas = _dragGhost.GetComponent<Canvas>();
                    if (_dragGhostCanvas == null)
                        _dragGhostCanvas = _dragGhost.AddComponent<Canvas>();
                    _dragGhostCanvas.renderMode = RenderMode.ScreenSpaceOverlay;
                    _dragGhostCanvas.overrideSorting = true;
                    _dragGhostCanvas.sortingOrder = GHOST_SORTING_ORDER;

                    if (_rootCanvasTransform != null)
                        _dragGhost.transform.SetParent(_rootCanvasTransform, false);
                    else
                        _dragGhost.transform.SetParent(transform.root, false);
                }
            }

            // ФИКС БАГ #7: НЕ создаём _cachedEventData здесь.
            // Он будет создан лениво в UpdateDragCellHighlights() с правильным EventSystem.

            PreWarmPool(POOL_PREWARM_COUNT);
            DisableLayoutOnItemContainers();
            SetupItemsContainerRaycasts();
            SetupBackgroundRaycast();
        }

        private void Start()
        {
            if (!InitializeReferences())
            {
                enabled = false;
                return;
            }

            if (_playerMotor == null)
                _playerMotor = FindFirstObjectByType<K_PlayerMotor>();

            BuildAllGrids();
            SubscribeToEvents();
            UpdateWeightDisplay(0f);
            ForceRefresh();
        }

        private void Update()
        {
            if (Input.GetKeyDown(_openCloseKey)) ToggleInventory();

            if (_isDragging)
            {
                if (Input.GetKeyDown(_rotateKey))
                    RotateDraggedItem();
            }
        }

        private void OnDestroy()
        {
            UnsubscribeFromEvents();
            UnsubscribeFromContainerEvents();
            ClearPooledItems();
            if (_dragGhost != null) Destroy(_dragGhost);
        }

        #endregion

        #region Initialization

        private Transform FindRootCanvas()
        {
            var parentCanvas = GetComponentInParent<Canvas>();
            if (parentCanvas != null)
            {
                while (parentCanvas.transform.parent != null && parentCanvas.transform.parent.GetComponent<Canvas>() != null)
                    parentCanvas = parentCanvas.transform.parent.GetComponent<Canvas>();
                return parentCanvas.transform;
            }
            return FindFirstObjectByType<Canvas>()?.transform;
        }

        private void InitializeCanvasState()
        {
            _canvasGroup.alpha = 0f;
            _canvasGroup.interactable = false;
            _canvasGroup.blocksRaycasts = false;
        }

        private Image CreateChildIcon(RectTransform parent, Image source)
        {
            var childObj = new GameObject("GhostIcon", typeof(RectTransform), typeof(Image));
            childObj.transform.SetParent(parent, false);

            var childRT = childObj.GetComponent<RectTransform>();
            childRT.anchorMin = new Vector2(0.5f, 0.5f);
            childRT.anchorMax = new Vector2(0.5f, 0.5f);
            childRT.pivot = new Vector2(0.5f, 0.5f);
            childRT.anchoredPosition = Vector2.zero;
            childRT.localRotation = Quaternion.identity;
            childRT.localScale = Vector3.one;
            childRT.sizeDelta = parent.sizeDelta;

            var childImage = childObj.GetComponent<Image>();
            childImage.sprite = source.sprite;
            childImage.color = source.color;
            childImage.type = source.type;
            childImage.preserveAspect = false;
            childImage.raycastTarget = false;
            childImage.enabled = true;

            return childImage;
        }

        private void SetupItemsContainerRaycasts()
        {
            var containers = new[] { _pocketsItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                var graphic = container.GetComponent<Graphic>();
                if (graphic != null) graphic.raycastTarget = false;
            }
        }

        private void SetupBackgroundRaycast()
        {
            if (_inventoryBackground != null)
            {
                var bgGraphic = _inventoryBackground.GetComponent<Graphic>();
                if (bgGraphic != null) bgGraphic.raycastTarget = false;
            }
        }

        private bool InitializeReferences()
        {
            if (_inventorySetup == null)
                _inventorySetup = FindFirstObjectByType<K_InventorySetup>();

            _pocketsController = _inventorySetup?.PocketsController;
            _backpackController = _inventorySetup?.BackpackController;

            if (_pocketsController == null || _backpackController == null)
            {
                Debug.LogError("[InventoryUI] Controllers are null! Check K_InventorySetup.");
                return false;
            }
            return true;
        }

        private void PreWarmPool(int count)
        {
            if (_uiItemPrefab == null) return;
            for (int i = 0; i < count; i++)
            {
                var item = CreateNewPooledItem();
                if (item != null) _itemPool.Enqueue(item);
            }
        }

        private UI_Item CreateNewPooledItem()
        {
            if (_uiItemPrefab == null) return null;
            var newItem = Instantiate(_uiItemPrefab, transform).GetComponent<UI_Item>();
            if (newItem == null) return null;
            newItem.gameObject.SetActive(false);
            var cg = newItem.GetComponent<CanvasGroup>();
            if (cg == null) cg = newItem.gameObject.AddComponent<CanvasGroup>();
            cg.alpha = 1f;
            cg.interactable = true;
            cg.blocksRaycasts = true;
            return newItem;
        }

        private void DisableLayoutOnItemContainers()
        {
            var containers = new[] { _pocketsItemsContainer, _backpackItemsContainer, _surroundingsItemsContainer };
            foreach (var container in containers)
            {
                if (container == null) continue;
                var grid = container.GetComponent<GridLayoutGroup>();
                if (grid != null) grid.enabled = false;
                foreach (var graphic in container.GetComponents<Graphic>())
                    graphic.raycastTarget = false;
            }
        }

        #endregion

        #region Grid Management

        private void BuildAllGrids()
        {
            BuildGrid(_pocketsGrid, POCKET_COLUMNS * POCKET_ROWS, POCKET_COLUMNS, GridType.Pockets);
            if (_backpackGrid != null && _backpackPanel != null)
                RebuildBackpackGrid(BACKPACK_BASE_COLS, BACKPACK_BASE_ROWS);
            SetupEquipmentSlots();
        }

        private void SetupEquipmentSlots()
        {
            _primarySlot1?.Initialize(this, EquipmentSlotType.Primary);
            _primarySlot2?.Initialize(this, EquipmentSlotType.Primary);
            _pistolSlot?.Initialize(this, EquipmentSlotType.Pistol);
            _backpackSlot?.Initialize(this, EquipmentSlotType.Backpack);
        }

        private void BuildGrid(Transform parent, int slotCount, int columns, GridType gridType)
        {
            if (parent == null || _slotPrefab == null) return;
            ClearGrid(parent);
            SetupGridLayout(parent, columns);
            CacheGridLayoutPadding(parent, gridType);

            for (int i = 0; i < slotCount; i++)
            {
                var slot = Instantiate(_slotPrefab, parent);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % columns;
                    int y = i / columns;
                    slotUI.Setup(x, y, gridType, this);
                }
            }
            LayoutRebuilder.ForceRebuildLayoutImmediate(parent.GetComponent<RectTransform>());
        }

        private void CacheGridLayoutPadding(Transform grid, GridType gridType)
        {
            if (grid == null) return;

            var layout = grid.GetComponent<GridLayoutGroup>();
            if (layout != null)
            {
                Vector2 padding = new Vector2(layout.padding.left, layout.padding.top);

                switch (gridType)
                {
                    case GridType.Pockets: _pocketsGridPadding = padding; break;
                    case GridType.Backpack: _backpackGridPadding = padding; break;
                    case GridType.Container: _containerGridPadding = padding; break;
                }
            }
        }

        private void ClearGrid(Transform parent)
        {
            if (parent == null) return;
            for (int i = parent.childCount - 1; i >= 0; i--)
                Destroy(parent.GetChild(i).gameObject);
        }

        private void SetupGridLayout(Transform parent, int columns)
        {
            var grid = parent.GetComponent<GridLayoutGroup>();
            if (grid == null) grid = parent.gameObject.AddComponent<GridLayoutGroup>();
            grid.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
            grid.constraintCount = columns;
            grid.cellSize = new Vector2(_slotSize, _slotSize);
            grid.spacing = new Vector2(_slotSpacing, _slotSpacing);
            grid.childAlignment = TextAnchor.UpperLeft;
        }

        #endregion

        #region UI Control

        public void ToggleInventory()
        {
            if (_isOpen) CloseAll();
            else OpenInventoryOnly();
        }

        private void OpenInventoryOnly()
        {
            _isOpen = true;
            SetCanvasActive(true);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);
            if (_backpackPanel != null) _backpackPanel.SetActive(true);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(true);
            ForceRefresh();
        }

        public void CloseAll()
        {
            // ФИКС БАГ #2: Отписываемся от событий контейнера
            UnsubscribeFromContainerEvents();
            ClearHover();

            _isOpen = false;
            _isLootingContainer = false;
            _activeContainerController = null;

            SetCanvasActive(false);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(true);
            if (_backpackPanel != null) _backpackPanel.SetActive(false);
            if (_inventoryBackground != null) _inventoryBackground.SetActive(false);
            if (_surroundingsPanel != null) _surroundingsPanel.SetActive(false);

            ReturnAllItemsToPool();
            OnContainerClosed?.Invoke(_pocketsController);
        }

        public void OpenContainer(InventoryController containerController, string containerName, int width, int height)
        {
            if (containerController == null) return;
            if (_isLootingContainer && _activeContainerController == containerController)
            {
                CloseAll();
                return;
            }

            // ФИКС БАГ #2: Отписываемся от событий СТАРОГО контейнера перед переключением
            UnsubscribeFromContainerEvents();

            _activeContainerController = containerController;
            _isLootingContainer = true;
            _isOpen = true;

            // Подписываемся на события НОВОГО контейнера
            SubscribeToContainerEvents();

            SetCanvasActive(true);
            if (_playerMotor != null) _playerMotor.SetMovementEnabled(false);

            if (_surroundingsPanel != null)
            {
                _surroundingsPanel.SetActive(true);
                if (_containerNameText != null) _containerNameText.text = containerName;
                RebuildSurroundingsGrid(width, height);
            }

            SetupBackgroundRaycast();
            ForceRefresh();
        }

        /// <summary>
        /// ФИКС БАГ #2: Отписка от событий активного контейнера.
        /// </summary>
        private void SubscribeToContainerEvents()
        {
            if (_activeContainerController == null) return;
            _activeContainerController.OnInventoryChanged += _onInventoryChangedHandler;
            _activeContainerController.OnItemPlaced += _onItemPlacedHandler;
            _activeContainerController.OnItemRemoved += _onItemChangedHandler;
            _activeContainerController.OnItemRotated += _onItemChangedHandler;
            _activeContainerController.OnItemQuantityChanged += _onItemChangedHandler;
        }

        /// <summary>
        /// ФИКС БАГ #2: Отписка от событий активного контейнера.
        /// </summary>
        private void UnsubscribeFromContainerEvents()
        {
            if (_activeContainerController == null) return;
            _activeContainerController.OnInventoryChanged -= _onInventoryChangedHandler;
            _activeContainerController.OnItemPlaced -= _onItemPlacedHandler;
            _activeContainerController.OnItemRemoved -= _onItemChangedHandler;
            _activeContainerController.OnItemRotated -= _onItemChangedHandler;
            _activeContainerController.OnItemQuantityChanged -= _onItemChangedHandler;
        }

        private void SetCanvasActive(bool active)
        {
            if (_canvasGroup == null) return;
            _canvasGroup.alpha = active ? 1f : 0f;
            _canvasGroup.interactable = active;
            _canvasGroup.blocksRaycasts = active;
        }

        private void RebuildSurroundingsGrid(int width, int height)
        {
            if (_surroundingsGrid == null || _slotPrefab == null) return;
            ClearGrid(_surroundingsGrid);
            SetupGridLayout(_surroundingsGrid, width);
            CacheGridLayoutPadding(_surroundingsGrid, GridType.Container);

            for (int i = 0; i < width * height; i++)
            {
                var slot = Instantiate(_slotPrefab, _surroundingsGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % width;
                    int y = i / width;
                    slotUI.Setup(x, y, GridType.Container, this);
                }
            }
        }

        public void OnBackpackEquipped(InventoryItem backpackItem)
        {
            if (_backpackGrid != null && backpackItem?.Data != null && _isOpen)
                RebuildBackpackGrid(backpackItem.Data.BackpackWidth, backpackItem.Data.BackpackHeight);
        }

        public void OnBackpackUnequipped()
        {
            if (_backpackGrid != null && _isOpen)
                RebuildBackpackGrid(BACKPACK_BASE_COLS, BACKPACK_BASE_ROWS);
        }

        public void RebuildBackpackGrid(int width, int height)
        {
            if (_backpackGrid == null || _slotPrefab == null) return;

            // ФИКС БАГ #4: Запоминаем реальные размеры рюкзака
            _currentBackpackCols = width;
            _currentBackpackRows = height;

            ClearGrid(_backpackGrid);
            SetupGridLayout(_backpackGrid, width);
            CacheGridLayoutPadding(_backpackGrid, GridType.Backpack);

            for (int i = 0; i < width * height; i++)
            {
                var slot = Instantiate(_slotPrefab, _backpackGrid);
                var slotUI = slot.GetComponent<K_InventorySlotUI>();
                if (slotUI != null)
                {
                    int x = i % width;
                    int y = i / width;
                    slotUI.Setup(x, y, GridType.Backpack, this);
                }
            }
            RefreshAll();
        }

        #endregion

        #region Refresh System

        public void RefreshAll()
        {
            if (_pendingRefresh) return;
            if (Time.time - _lastRefreshTime < UI_REFRESH_THROTTLE)
            {
                _pendingRefresh = true;
                return;
            }
            _pendingRefresh = true;
            _lastRefreshTime = Time.time;
            if (_refreshCoroutine != null) StopCoroutine(_refreshCoroutine);
            _refreshCoroutine = StartCoroutine(RefreshNextFrame());
        }

        public void ForceRefresh()
        {
            _pendingRefresh = false;
            _lastRefreshTime = 0f;

            SyncItemsContainerPositions();

            if (_refreshCoroutine != null)
            {
                StopCoroutine(_refreshCoroutine);
                _refreshCoroutine = null;
            }
            _refreshCoroutine = StartCoroutine(RefreshNextFrame());
        }

        private IEnumerator RefreshNextFrame()
        {
            yield return null;
            _pendingRefresh = false;

            SyncItemsContainerPositions();

            ReturnAllItemsToPool();

            RefreshGrid(GridType.Pockets, POCKET_COLUMNS, POCKET_ROWS, _pocketsItemsContainer);

            // ФИКС БАГ #4: Используем реальные размеры рюкзака, не захардкоженные
            if (_backpackGrid != null)
                RefreshGrid(GridType.Backpack, _currentBackpackCols, _currentBackpackRows, _backpackItemsContainer);

            if (_isLootingContainer && _activeContainerController != null)
                RefreshGrid(GridType.Container, _activeContainerController.Width, _activeContainerController.Height, _surroundingsItemsContainer);

            _primarySlot1?.Refresh();
            _primarySlot2?.Refresh();
            _pistolSlot?.Refresh();
            _backpackSlot?.Refresh();

            // Occupied cell tinting (task 2)
            UpdateOccupiedCellTints();
        }

        private void RefreshGrid(GridType type, int cols, int rows, Transform container)
        {
            var controller = GetControllerForGrid(type);
            if (controller == null || container == null) return;

            for (int y = 0; y < rows; y++)
                for (int x = 0; x < cols; x++)
                    RefreshSlot(type, x, y, controller, container);
        }

        private void RefreshSlot(GridType type, int x, int y, InventoryController controller, Transform container)
        {
            string key = GetCellKey(type, x, y);
            var item = controller.GetItemAt(x, y);

            if (_activeItems.TryGetValue(key, out var uiItem))
            {
                if (item == null)
                {
                    // ФИКС #3: Не возвращаем в пул перетаскиваемый предмет
                    if (uiItem == _draggedItem)
                    {
                        _activeItems.Remove(key);
                        return;
                    }
                    ReturnToPool(uiItem);
                }
                else
                {
                    if (uiItem.X != x || uiItem.Y != y)
                    {
                        ReturnToPool(uiItem);
                        CreateUIItem(item, x, y, type, container);
                    }
                    else
                    {
                        uiItem.UpdateData(item);
                        uiItem.gameObject.SetActive(true);
                    }
                }
            }
            else if (item != null && controller.IsRootCell(item.InstanceID, x, y))
            {
                CreateUIItem(item, x, y, type, container);
            }
        }

        /// <summary>Найти слот UI по координатам в сетке. Слоты идут по порядку GridLayoutGroup.</summary>
        private K_InventorySlotUI GetSlotAt(GridType gridType, int x, int y)
        {
            Transform grid = gridType switch
            {
                GridType.Pockets => _pocketsGrid,
                GridType.Backpack => _backpackGrid,
                GridType.Container => _surroundingsGrid,
                _ => null
            };
            if (grid == null) return null;

            int columns = GetGridWidth(gridType);
            int index = y * columns + x;
            if (index < 0 || index >= grid.childCount) return null;
            return grid.GetChild(index).GetComponent<K_InventorySlotUI>();
        }

        private string GetCellKey(GridType type, int x, int y) => $"{type}_{x}_{y}";

        private void CreateUIItem(InventoryItem item, int x, int y, GridType type, Transform container)
        {
            string key = GetCellKey(type, x, y);
            if (_activeItems.ContainsKey(key)) return;

            if (container == null || _uiItemPrefab == null || item == null) return;

            var uiItem = GetPooledItem();
            if (uiItem == null) return;

            uiItem.transform.SetParent(container, false);
            uiItem.transform.SetAsLastSibling();

            var rect = uiItem.GetComponent<RectTransform>();
            if (rect != null)
            {
                Vector2Int currentSize = item.CurrentSize;
                float widthPx = currentSize.x * _slotSize + (currentSize.x - 1) * _slotSpacing;
                float heightPx = currentSize.y * _slotSize + (currentSize.y - 1) * _slotSpacing;

                Vector2 padding = type switch
                {
                    GridType.Pockets => _pocketsGridPadding,
                    GridType.Backpack => _backpackGridPadding,
                    GridType.Container => _containerGridPadding,
                    _ => Vector2.zero
                };

                rect.anchorMin = new Vector2(0f, 1f);
                rect.anchorMax = new Vector2(0f, 1f);
                rect.pivot = new Vector2(0f, 1f);
                rect.sizeDelta = new Vector2(widthPx, heightPx);

                rect.anchoredPosition = new Vector2(
                    padding.x + x * (_slotSize + _slotSpacing),
                    -padding.y - y * (_slotSize + _slotSpacing)
                );

                rect.localScale = Vector3.one;
                rect.localRotation = Quaternion.identity;
            }

            uiItem.gameObject.SetActive(true);
            uiItem.Setup(item, this, type, x, y);
            _activeItems[key] = uiItem;
        }

        private Transform GetItemsContainer(GridType type) => type switch
        {
            GridType.Pockets => _pocketsItemsContainer,
            GridType.Backpack => _backpackItemsContainer,
            GridType.Container => _surroundingsItemsContainer,
            _ => null
        };

        private void SyncItemsContainerPositions()
        {
            SyncContainer(_pocketsGrid, _pocketsItemsContainer);
            SyncContainer(_backpackGrid, _backpackItemsContainer);
            SyncContainer(_surroundingsGrid, _surroundingsItemsContainer);
        }

        private void SyncContainer(Transform grid, Transform itemsContainer)
        {
            if (grid == null || itemsContainer == null) return;

            RectTransform gridRect = grid.GetComponent<RectTransform>();
            RectTransform itemsRect = itemsContainer.GetComponent<RectTransform>();

            if (gridRect == null || itemsRect == null) return;

            itemsRect.anchorMin = gridRect.anchorMin;
            itemsRect.anchorMax = gridRect.anchorMax;
            itemsRect.pivot = gridRect.pivot;
            itemsRect.anchoredPosition = gridRect.anchoredPosition;
            itemsRect.sizeDelta = gridRect.sizeDelta;
            itemsRect.localScale = gridRect.localScale;
        }

        #endregion

        #region Occupied Cell Tinting

        private void UpdateOccupiedCellTints()
        {
            ResetAllSlotColors();
            TintOccupiedCells(GridType.Pockets, _pocketsController);
            TintOccupiedCells(GridType.Backpack, _backpackController);
            if (_isLootingContainer && _activeContainerController != null)
                TintOccupiedCells(GridType.Container, _activeContainerController);
        }

        private void ResetAllSlotColors()
        {
            ResetGridSlotColors(_pocketsGrid);
            ResetGridSlotColors(_backpackGrid);
            ResetGridSlotColors(_surroundingsGrid);
        }

        private void ResetGridSlotColors(Transform grid)
        {
            if (grid == null) return;
            for (int i = 0; i < grid.childCount; i++)
            {
                var slot = grid.GetChild(i).GetComponent<K_InventorySlotUI>();
                slot?.ResetCellColor();
            }
        }

        private void TintOccupiedCells(GridType gridType, InventoryController controller)
        {
            if (controller == null) return;
            for (int y = 0; y < controller.Height; y++)
            {
                for (int x = 0; x < controller.Width; x++)
                {
                    if (controller.GetItemAt(x, y) != null)
                    {
                        var slot = GetSlotAt(gridType, x, y);
                        slot?.TintOccupied(_occupiedCellTint);
                    }
                }
            }
        }

        #endregion

        #region Drag & Drop System

        public void StartDrag(UI_Item draggedItem, PointerEventData eventData)
        {
            if (draggedItem?.Item == null || _dragGhost == null || _dragGhostRT == null) return;

            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedItem = draggedItem;
            _isDragging = true;
            _dropHandled = false;
            _needsPostDragRefresh = false;

            // Отменяем pending fallback refresh
            if (_postDragRefreshCoroutine != null)
            {
                StopCoroutine(_postDragRefreshCoroutine);
                _postDragRefreshCoroutine = null;
            }

            // ФИКС #3: Сохраняем оригинальную позицию и УДАЛЯЕМ предмет из сетки.
            // Теперь вращение свободное — не привязано к текущей позиции в сетке.
            _dragOriginGridType = draggedItem.GridType;
            _dragOriginX = draggedItem.X;
            _dragOriginY = draggedItem.Y;
            _dragOriginRotationAngle = draggedItem.Item.RotationAngle;
            _dragItemRemoved = false;

            var sourceController = GetControllerForGrid(draggedItem.GridType);
            if (sourceController != null)
            {
                sourceController.RemoveItem(draggedItem.Item);
                _dragItemRemoved = true;

                // ФИКС: сразу очищаем occupied tint с ячеек, которые занимал предмет.
                // Иначе до следующего refresh на старом месте остаётся подсветка.
                Vector2Int originSize = draggedItem.Item.CurrentSize;
                for (int dy = 0; dy < originSize.y; dy++)
                {
                    for (int dx = 0; dx < originSize.x; dx++)
                    {
                        var slot = GetSlotAt(draggedItem.GridType,
                            draggedItem.X + dx, draggedItem.Y + dy);
                        if (slot != null)
                            slot.ResetCellColor();
                    }
                }
            }

            // Снимаем hover при начале drag
            if (_hoveredItem == draggedItem)
            {
                _hoveredItem.SetSelected(false);
                _hoveredItem = null;
            }

            SetupDragOutline(draggedItem.Item);

            _dragGhost.SetActive(true);
            UpdateDragGhostPosition(eventData);
        }

        public void StartDragFromEquipmentSlot(K_EquipmentSlotUI slot, PointerEventData eventData)
        {
            if (slot?.EquippedItem == null || _dragGhost == null || _dragGhostRT == null) return;
            var item = slot.EquippedItem;

            _draggedFromEquipmentSlot = slot;
            _draggedFromSlotItem = item;
            _draggedItem = null;
            _isDragging = true;
            _dropHandled = false;
            _dragItemRemoved = false;
            _needsPostDragRefresh = false;

            if (_postDragRefreshCoroutine != null)
            {
                StopCoroutine(_postDragRefreshCoroutine);
                _postDragRefreshCoroutine = null;
            }

            SetupDragOutline(item);

            _dragGhost.SetActive(true);
            UpdateDragGhostPosition(eventData);
        }

        public void UpdateDragGhostPosition(PointerEventData eventData)
        {
            if (!_isDragging || _dragGhost == null || !_dragGhost.activeSelf || _dragGhostRT == null) return;

            RectTransform canvasRT = _rootCanvasTransform as RectTransform;
            if (canvasRT == null) return;

            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(canvasRT, eventData.position, null, out Vector2 localPoint))
                _dragGhostRT.anchoredPosition = localPoint;

            UpdateDragCellHighlights();
        }

        /// <summary>
        /// Вращение при перетаскивании: 2 состояния (0°→90°→0° циклично).
        /// Предмет уже удалён из сетки при старте drag.
        /// </summary>
        private void RotateDraggedItem()
        {
            var item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null || !item.Data.CanRotate) return;

            // Прямое вращение без привязки к сетке
            item.Rotate();
            UpdateGhostSize();
            UpdateGhostRotation();
            // ФИКС: обновляем подсветку ячеек после смены размера
            UpdateDragCellHighlights();
        }

        private void UpdateGhostSize()
        {
            if (_dragGhostRT == null) return;

            Vector2Int currentSize;
            Vector2Int normalSize;

            if (_draggedItem?.Item != null)
            {
                currentSize = _draggedItem.Item.CurrentSize;
                normalSize = _draggedItem.Item.Data.Size;
            }
            else if (_draggedFromSlotItem != null)
            {
                currentSize = _draggedFromSlotItem.CurrentSize;
                normalSize = _draggedFromSlotItem.Data.Size;
            }
            else
            {
                currentSize = new Vector2Int(1, 1);
                normalSize = new Vector2Int(1, 1);
            }

            float bodyW = currentSize.x * _slotSize + (currentSize.x - 1) * _slotSpacing;
            float bodyH = currentSize.y * _slotSize + (currentSize.y - 1) * _slotSpacing;
            _dragGhostRT.sizeDelta = new Vector2(bodyW, bodyH);

            // Иконка ghost — размер по Data.Size с swap для IconBaseRotation (как в UI_Item)
            var iconItem = _draggedItem?.Item ?? _draggedFromSlotItem;
            float baseRot = iconItem?.IconBaseRotation ?? 0f;
            bool iconSwapsAxes = Mathf.Abs(baseRot % 180) > 0.01f;
            float iconW = (iconSwapsAxes ? normalSize.y : normalSize.x) * _slotSize
                              + ((iconSwapsAxes ? normalSize.y : normalSize.x) - 1) * _slotSpacing;
            float iconH = (iconSwapsAxes ? normalSize.x : normalSize.y) * _slotSize
                              + ((iconSwapsAxes ? normalSize.x : normalSize.y) - 1) * _slotSpacing;
            _dragGhostIconRect.sizeDelta = new Vector2(iconW, iconH);
        }

        private void UpdateGhostRotation()
        {
            var item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null || _dragGhostIconRect == null) return;

            _dragGhostRT.localRotation = Quaternion.identity;
            float visualAngle = item.IconBaseRotation - item.RotationAngle;
            _dragGhostIconRect.localRotation = Quaternion.Euler(0, 0, visualAngle);

            Debug.Log($"[ROT-DIAG GHOST] Base={item.IconBaseRotation} | R={item.RotationAngle} | visual={visualAngle}");
        }

        /// <summary>
        /// TASK 3+4+6: Подсветка ячеек под курсором вместо обводки призрака.
        /// Иконка предмета видна (летает над ячейками). За границей — скрыть всё.
        /// </summary>
        private void UpdateDragCellHighlights()
        {
            if (EventSystem.current == null) return;

            InventoryItem item = _draggedItem?.Item ?? _draggedFromSlotItem;
            if (item == null) { ClearHighlightsKeepGhostVisible(); return; }

            // Ленивая инициализация
            if (_cachedEventData == null)
                _cachedEventData = new PointerEventData(EventSystem.current);

            _cachedEventData.position = Input.mousePosition;
            _raycastBuffer.Clear();
            EventSystem.current.RaycastAll(_cachedEventData, _raycastBuffer);

            K_InventorySlotUI hitSlot = null;
            bool canPlace = false;

            foreach (var result in _raycastBuffer)
            {
                var slot = result.gameObject.GetComponent<K_InventorySlotUI>();
                if (slot != null)
                {
                    var controller = GetControllerForGrid(slot.GridType);
                    if (controller == null) continue;

                    Vector2Int itemSize = item.CurrentSize;
                    var (targetX, targetY) = CalculateSnapPosition(
                        slot.X, slot.Y, itemSize, controller.Width, controller.Height);

                    canPlace = controller.CanPlaceItem(item, targetX, targetY);
                    hitSlot = slot;
                    break;
                }

                var equipSlot = result.gameObject.GetComponent<K_EquipmentSlotUI>();
                if (equipSlot != null)
                {
                    canPlace = ValidateEquipItem(item, equipSlot);
                    break;
                }
            }

            // TASK 3 (fix): За границей сетки — убрать подсветку, ghost виден
            if (hitSlot == null)
            {
                ClearHighlightsKeepGhostVisible();
                return;
            }

            // Показываем ghost (с иконкой)
            if (_dragGhost != null) _dragGhost.SetActive(true);

            // Рассчитываем ячейки для подсветки
            var controller2 = GetControllerForGrid(hitSlot.GridType);
            if (controller2 == null) return;

            Vector2Int itemSize2 = item.CurrentSize;
            var (tx, ty) = CalculateSnapPosition(
                hitSlot.X, hitSlot.Y, itemSize2, controller2.Width, controller2.Height);

            Color highlightColor = canPlace ? _dragCellValidColor : _dragCellInvalidColor;

            // Очищаем старые и ставим новые
            ClearDragCellHighlights();
            for (int dy = 0; dy < itemSize2.y; dy++)
            {
                for (int dx = 0; dx < itemSize2.x; dx++)
                {
                    var s = GetSlotAt(hitSlot.GridType, tx + dx, ty + dy);
                    if (s != null)
                    {
                        _activeDragHighlights.Add(new DragCellHighlight
                        {
                            slot = s,
                            previousColor = s.CellOverlayColor
                        });
                        s.SetCellColor(highlightColor);
                    }
                }
            }

            // NOTE: ghost следует за курсором (UpdateDragGhostPosition),
            // подсветка ячеек считается независимо — это создаёт эффект "полёта над ячейками".
        }

        /// <summary>
        /// Смещает ghost так, чтобы его центр совпадал с центром подсвеченной области ячеек.
        /// Без этого ghost стоит на курсоре, а подсветка — со смещением (до пол-ячейки).
        /// </summary>
        private void SnapGhostToHighlightArea(GridType gridType, int tx, int ty, Vector2Int itemSize)
        {
            if (_dragGhostRT == null || _rootCanvasTransform == null) return;

            var topLeftSlot = GetSlotAt(gridType, tx, ty);
            if (topLeftSlot == null) return;

            var slotRT = topLeftSlot.transform as RectTransform;
            var canvasRT = _rootCanvasTransform as RectTransform;
            if (slotRT == null || canvasRT == null) return;

            // Центр левой верхней ячейки → canvas-local координаты
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                canvasRT, slotRT.position, null, out Vector2 slotCenterLocal))
                return;

            // Смещение от центра первой ячейки до центра всей подсвеченной области
            float cellStep = _slotSize + _slotSpacing;
            float offsetX = ((float)itemSize.x - 1f) * 0.5f * cellStep;
            float offsetY = -((float)itemSize.y - 1f) * 0.5f * cellStep; // минус: UI Y инвертирован

            _dragGhostRT.anchoredPosition = slotCenterLocal + new Vector2(offsetX, offsetY);
        }

        private void ClearDragCellHighlights()
        {
            foreach (var h in _activeDragHighlights)
            {
                if (h.slot != null)
                    h.slot.SetCellColor(h.previousColor);
            }
            _activeDragHighlights.Clear();
        }

        /// <summary>За границей сетки: подсветку убрать, ghost оставить видимым.</summary>
        private void ClearHighlightsKeepGhostVisible()
        {
            ClearDragCellHighlights();
            // Ghost НЕ скрываем — игрок должен видеть что он тащит
        }

        private void HideDragGhostAndClearHighlights()
        {
            ClearDragCellHighlights();
            if (_dragGhost != null) _dragGhost.SetActive(false);
        }

        public bool TryPlaceItem(UI_Item draggedItem, GridType targetGrid, int targetX, int targetY)
        {
            if (draggedItem?.Item == null) return false;

            var item = draggedItem.Item;
            var targetController = GetControllerForGrid(targetGrid);
            if (targetController == null) return false;

            if (targetX < 0 || targetY < 0 ||
                targetX >= targetController.Width ||
                targetY >= targetController.Height)
            {
                LogDebug($"[InventoryUI] REJECTED - out of bounds ({targetX},{targetY})");
                return false;
            }

            // ФИКС #3: Если предмет был удалён из сетки при старте drag — просто размещаем.
            if (_dragItemRemoved)
            {
                int earlyPlaceCount = targetController.TryPlaceItem(item, targetX, targetY);
                if (earlyPlaceCount > 0)
                {
                    _dragItemRemoved = false;
                    _dropHandled = true;
                    ForceRefresh();
                    return true;
                }
                return false;
            }

            // Оригинальная логика для предметов которые НЕ были удалены из сетки
            var sourceController = GetControllerForGrid(draggedItem.GridType);

            if (sourceController == targetController &&
                draggedItem.X == targetX &&
                draggedItem.Y == targetY)
                return true;

            if (sourceController == targetController)
            {
                bool moved = sourceController.MoveItem(item, targetX, targetY);
                if (moved) ForceRefresh();
                return moved;
            }

            int originX = draggedItem.X;
            int originY = draggedItem.Y;

            if (!sourceController.RemoveItem(item))
                return false;

            int placedCount = targetController.TryPlaceItem(item, targetX, targetY);
            bool success = placedCount > 0;

            if (!success)
                sourceController.TryPlaceItem(item, originX, originY);

            if (success) ForceRefresh();

            return success;
        }

        public bool TryEquipItem(UI_Item draggedItem, K_EquipmentSlotUI slot)
        {
            if (draggedItem?.Item == null || slot == null) return false;
            var item = draggedItem.Item;
            if (!ValidateEquipItem(item, slot)) return false;

            var sourceController = GetControllerForGrid(draggedItem.GridType);
            if (sourceController == null) return false;

            // Если слот занят — пробуем swap: старый предмет → на место нового
            if (slot.IsOccupied && slot.EquippedItem != null)
            {
                var oldEquipped = slot.EquippedItem;

                // Старый предмет наследует разворот нового
                oldEquipped.RestoreRotationState(item.RotationAngle);

                // Пытаемся поставить старый предмет на позицию нового
                int placed = sourceController.TryPlaceItem(oldEquipped, draggedItem.X, draggedItem.Y);
                if (placed == 0)
                {
                    bool fallback = sourceController.TryPlaceItemInFirstFreeSlot(oldEquipped);
                    placed = fallback ? 1 : 0;
                }

                if (placed == 0) return false; // Нет места для старого предмета

                // Старый предмет размещён — убираем новый из сетки
                if (!sourceController.RemoveItem(item)) return false;

                string itemKey = GetCellKey(draggedItem.GridType, draggedItem.X, draggedItem.Y);
                _activeItems.Remove(itemKey);

                slot.SetEquippedItem(null);
                slot.OnDropItem(item);
                draggedItem.gameObject.SetActive(false);
                ReturnToPool(draggedItem);
                ForceRefresh();
                return true;
            }

            // Слот пуст — обычная экипировка
            if (sourceController.RemoveItem(item))
            {
                string itemKey = GetCellKey(draggedItem.GridType, draggedItem.X, draggedItem.Y);
                _activeItems.Remove(itemKey);

                slot.OnDropItem(item);
                draggedItem.gameObject.SetActive(false);
                ReturnToPool(draggedItem);

                ForceRefresh();
                return true;
            }
            return false;
        }

        public bool TryPlaceItemFromEquipmentSlot(GridType targetGrid, int targetX, int targetY)
        {
            if (_draggedFromEquipmentSlot == null || _draggedFromSlotItem == null) return false;

            var item = _draggedFromSlotItem;
            var targetController = GetControllerForGrid(targetGrid);
            if (targetController == null) return false;

            if (targetX < 0 || targetY < 0 ||
                targetX >= targetController.Width ||
                targetY >= targetController.Height)
                return false;

            int placedCount = targetController.TryPlaceItem(item, targetX, targetY);

            if (placedCount > 0)
            {
                _draggedFromEquipmentSlot.SetEquippedItem(null);
                ForceRefresh();
                return true;
            }

            return false;
        }

        public bool TryEquipItemFromSlot(K_EquipmentSlotUI sourceSlot, K_EquipmentSlotUI targetSlot)
        {
            if (sourceSlot?.EquippedItem == null || targetSlot == null || sourceSlot == targetSlot) return false;

            var item = sourceSlot.EquippedItem;
            if (!ValidateEquipItem(item, targetSlot)) return false;

            // Если целевой слот занят — пробуем swap между слотами
            if (targetSlot.IsOccupied && targetSlot.EquippedItem != null)
            {
                var oldTargetItem = targetSlot.EquippedItem;

                // Проверяем: может ли старый предмет целевого слота поместиться в исходный слот?
                if (sourceSlot.ValidateItemForSlot(oldTargetItem))
                {
                    // Swap: старый предмет → исходный слот
                    sourceSlot.SetEquippedItem(oldTargetItem);
                    targetSlot.SetEquippedItem(null);
                }
                else
                {
                    // Старый предмет не подходит для исходного слота — пробуем unequip в инвентарь.
                    // Наследуем разворот нового предмета перед размещением в сетке.
                    oldTargetItem.RestoreRotationState(item.RotationAngle);
                    targetSlot.Unequip();
                    if (targetSlot.IsOccupied) return false; // Не получилось разместить
                }
            }
            else
            {
                // Целевой слот пуст — просто убираем из исходного
                sourceSlot.SetEquippedItem(null);
            }

            targetSlot.OnDropItem(item);
            return true;
        }

        /// <summary>
        /// ФИКС #3 + #6: При отмене drag — вернуть предмет на исходную позицию.
        /// Refresh происходит либо из OnDrop, либо через fallback.
        /// </summary>
        public void EndDragComplete()
        {
            _isDragging = false;

            // ФИКС #3: Если предмет был удалён из сетки но не размещён (drag отменён)
            if (_dragItemRemoved && !_dropHandled && _draggedItem?.Item != null)
            {
                var item = _draggedItem.Item;
                var controller = GetControllerForGrid(_dragOriginGridType);

                if (controller != null)
                {
                    // Пытаемся вернуть на исходную позицию
                    int placed = controller.TryPlaceItem(item, _dragOriginX, _dragOriginY);
                    if (placed == 0)
                    {
                        // Исходная позиция занята — ищем любое свободное место
                        controller.TryPlaceItemInFirstFreeSlot(item);
                    }
                }
            }

            _dragItemRemoved = false;
            _dropHandled = false;
            _draggedItem = null;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            ClearDragCellHighlights();
            if (_dragGhost != null) _dragGhost.SetActive(false);

            _needsPostDragRefresh = true;
            _postDragRefreshCoroutine = StartCoroutine(PostDragRefreshFallback());
        }

        /// <summary>
        /// ФИКС БАГ #6: Fallback refresh через короткую задержку.
        /// Если OnDrop был обработан и вызвал ForceRefresh(), _needsPostDragRefresh
        /// будет сброшен. Если drop не удался — этот корутин обеспечит refresh.
        /// </summary>
        private IEnumerator PostDragRefreshFallback()
        {
            yield return new WaitForSeconds(DROP_FALLBACK_DELAY);

            if (_needsPostDragRefresh)
            {
                _needsPostDragRefresh = false;
                ForceRefresh();
            }
            _postDragRefreshCoroutine = null;
        }

        public void EndDragFromEquipmentSlot()
        {
            _isDragging = false;
            _draggedFromEquipmentSlot = null;
            _draggedFromSlotItem = null;
            _draggedItem = null;
            ClearDragCellHighlights();
            if (_dragGhost != null) _dragGhost.SetActive(false);
            ForceRefresh();
        }

        private bool ValidateEquipItem(InventoryItem item, K_EquipmentSlotUI slot)
        {
            if (item?.Data == null) return false;
            return slot.SlotType switch
            {
                EquipmentSlotType.Primary => item.Type == ItemType.Weapon && !item.Data.IsPistol,
                EquipmentSlotType.Pistol => item.Type == ItemType.Weapon && item.Data.IsPistol,
                EquipmentSlotType.Backpack => item.Data.IsBackpack,
                _ => false
            };
        }

        #endregion

        #region Event Handling

        private void SubscribeToEvents()
        {
            _onInventoryChangedHandler = RefreshAll;
            _onWeightChangedHandler = UpdateWeightDisplay;
            _onItemPlacedHandler = (item, x, y) => RefreshAll();
            _onItemChangedHandler = _ => RefreshAll();

            if (_pocketsController != null)
            {
                _pocketsController.OnInventoryChanged += _onInventoryChangedHandler;
                _pocketsController.OnItemPlaced += _onItemPlacedHandler;
                _pocketsController.OnItemRemoved += _onItemChangedHandler;
                _pocketsController.OnItemRotated += _onItemChangedHandler;
                _pocketsController.OnItemQuantityChanged += _onItemChangedHandler;
                _pocketsController.OnWeightChanged += _onWeightChangedHandler;
            }

            if (_backpackController != null)
            {
                _backpackController.OnInventoryChanged += _onInventoryChangedHandler;
                _backpackController.OnItemPlaced += _onItemPlacedHandler;
                _backpackController.OnItemRemoved += _onItemChangedHandler;
                _backpackController.OnItemRotated += _onItemChangedHandler;
                _backpackController.OnItemQuantityChanged += _onItemChangedHandler;
                _backpackController.OnWeightChanged += _onWeightChangedHandler;
            }
        }

        private void UnsubscribeFromEvents()
        {
            if (_pocketsController != null)
            {
                _pocketsController.OnInventoryChanged -= _onInventoryChangedHandler;
                _pocketsController.OnItemPlaced -= _onItemPlacedHandler;
                _pocketsController.OnItemRemoved -= _onItemChangedHandler;
                _pocketsController.OnItemRotated -= _onItemChangedHandler;
                _pocketsController.OnItemQuantityChanged -= _onItemChangedHandler;
                _pocketsController.OnWeightChanged -= _onWeightChangedHandler;
            }

            if (_backpackController != null)
            {
                _backpackController.OnInventoryChanged -= _onInventoryChangedHandler;
                _backpackController.OnItemPlaced -= _onItemPlacedHandler;
                _backpackController.OnItemRemoved -= _onItemChangedHandler;
                _backpackController.OnItemRotated -= _onItemChangedHandler;
                _backpackController.OnItemQuantityChanged -= _onItemChangedHandler;
                _backpackController.OnWeightChanged -= _onWeightChangedHandler;
            }
        }

        private void UpdateWeightDisplay(float kg)
        {
            if (_weightText == null) return;

            float totalKg = 0f;
            float maxCapacity = 0f;

            if (_pocketsController != null)
            {
                totalKg += _pocketsController.CurrentWeightKg;
                maxCapacity += _pocketsController.MaxCapacityGrams;
            }
            if (_backpackController != null)
            {
                totalKg += _backpackController.CurrentWeightKg;
                maxCapacity += _backpackController.MaxCapacityGrams;
            }

            float ratio = maxCapacity > 0 ? (totalKg * 1000f) / maxCapacity : 0f;
            Color textColor = ratio > WEIGHT_CRITICAL_RATIO ? _textCriticalColor
                            : ratio > WEIGHT_WARNING_RATIO ? _textWarningColor
                            : _textNormalColor;

            float maxKg = maxCapacity / 1000f;
            _weightText.text = $"<color=#{ColorUtility.ToHtmlStringRGB(textColor)}>{totalKg:F1} / {maxKg:F0} kg</color>";
        }

        #endregion

        #region Pool Management

        private UI_Item GetPooledItem()
        {
            if (_itemPool.Count > 0) return _itemPool.Dequeue();
            return CreateNewPooledItem();
        }

        /// <summary>
        /// ФИКС БАГ #3: ReturnToPool теперь удаляет элемент из _activeItems.
        /// Это предотвращает двойной возврат и коррупцию пула.
        /// </summary>
        private void ReturnToPool(UI_Item item)
        {
            if (item == null) return;

            // ФИКС БАГ #3: Удаляем из _activeItems, чтобы ReturnAllItemsToPool
            // не вернул этот элемент повторно
            foreach (var kvp in _activeItems)
            {
                if (kvp.Value == item)
                {
                    _activeItems.Remove(kvp.Key);
                    break;
                }
            }

            item.ResetState();
            item.gameObject.SetActive(false);
            item.transform.SetParent(transform, false);
            _itemPool.Enqueue(item);
        }

        private void ReturnAllItemsToPool()
        {
            UI_Item protectedItem = _draggedItem;

            foreach (var item in _activeItems.Values)
            {
                if (item == protectedItem) continue;
                ReturnToPoolOnly(item);
            }

            _activeItems.Clear();

            // ФИКС #3: Если предмет удалён из сетки — НЕ добавляем в _activeItems.
            // Иначе RefreshGrid увидит пустую ячейку и вернёт предмет в пул.
            if (protectedItem != null && protectedItem.Item != null && !_dragItemRemoved)
            {
                string key = GetCellKey(protectedItem.GridType, protectedItem.X, protectedItem.Y);
                _activeItems[key] = protectedItem;
            }
        }

        /// <summary>
        /// Внутренний метод: возвращает элемент в пул БЕЗ удаления из _activeItems.
        /// Используется в ReturnAllItemsToPool() для очистки всех элементов.
        /// </summary>
        private void ReturnToPoolOnly(UI_Item item)
        {
            if (item == null) return;
            item.ResetState();
            item.gameObject.SetActive(false);
            item.transform.SetParent(transform, false);
            _itemPool.Enqueue(item);
        }

        private void ClearPooledItems()
        {
            foreach (var item in _itemPool) if (item != null) Destroy(item.gameObject);
            _itemPool.Clear();
            _activeItems.Clear();
        }

        private void MarkForRefresh()
        {
            _needsPostDragRefresh = false; // Сбрасываем fallback

            if (!_pendingRefresh)
            {
                _pendingRefresh = true;
                StartCoroutine(RefreshNextFrame());
            }
        }

        #endregion

        #region Public API

        public InventoryController GetControllerForGrid(GridType gridType) => gridType switch
        {
            GridType.Pockets => _pocketsController,
            GridType.Backpack => _backpackController,
            GridType.Container => _activeContainerController,
            _ => null
        };

        public int GetGridWidth(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_COLUMNS;
            if (gridType == GridType.Backpack) return _currentBackpackCols; // ФИКС БАГ #4
            var c = GetControllerForGrid(gridType);
            return c?.Width ?? 0;
        }

        public int GetGridHeight(GridType gridType)
        {
            if (gridType == GridType.Pockets) return POCKET_ROWS;
            if (gridType == GridType.Backpack) return _currentBackpackRows; // ФИКС БАГ #4
            var c = GetControllerForGrid(gridType);
            return c?.Height ?? 0;
        }

        public void OnEquipmentSlotDrop(K_EquipmentSlotUI slot, PointerEventData eventData)
        {
            if (slot == null || eventData?.pointerDrag == null) return;

            var draggedUI = eventData.pointerDrag.GetComponent<UI_Item>();
            if (draggedUI?.Item != null)
            {
                var item = draggedUI.Item;

                // ВСЕГДА валидируем тип предмета — даже если предмет уже удалён из сетки.
                // Раньше _dragItemRemoved вызывал short-circuit и валидация пропускалась.
                if (!ValidateEquipItem(item, slot))
                {
                    // Невалидный тип (пистолет в Primary и т.д.) — не делаем _dropHandled,
                    // чтобы EndDragComplete вернул предмет обратно в сетку.
                    return;
                }

                // Если слот ЗАНЯТ — пробуем swap: старый предмет → на место нового в инвентаре
                if (slot.IsOccupied && slot.EquippedItem != null)
                {
                    var oldEquipped = slot.EquippedItem;
                    var originController = GetControllerForGrid(_dragOriginGridType);

                    if (originController != null)
                    {
                        // Старый предмет наследует разворот нового
                        oldEquipped.RestoreRotationState(item.RotationAngle);

                        // Пытаемся поставить старый предмет на исходную позицию нового
                        int placed = originController.TryPlaceItem(oldEquipped, _dragOriginX, _dragOriginY);
                        if (placed == 0)
                        {
                            // Исходная позиция занята — пробуем любое свободное место в той же сетке
                            bool fallback = originController.TryPlaceItemInFirstFreeSlot(oldEquipped);
                            placed = fallback ? 1 : 0;
                        }

                        if (placed == 0)
                        {
                            // Старый предмет больше нового / нет места — ОТМЕНА swap.
                            // EndDragComplete вернёт новый предмет обратно в сетку.
                            return;
                        }

                        // Старый предмет размещён в инвентаре — очищаем слот
                        slot.SetEquippedItem(null);
                    }
                    else
                    {
                        // Нет контроллера для исходной сетки — отмена
                        return;
                    }
                }

                // Успех: экипируем новый предмет
                _dragItemRemoved = false;
                _dropHandled = true;
                slot.OnDropItem(item);
                draggedUI.gameObject.SetActive(false);
                ReturnToPool(draggedUI);

                _isDragging = false;
                _draggedItem = null;
                ClearDragCellHighlights();
                if (_dragGhost != null) _dragGhost.SetActive(false);
                if (_postDragRefreshCoroutine != null)
                {
                    StopCoroutine(_postDragRefreshCoroutine);
                    _postDragRefreshCoroutine = null;
                }
                _needsPostDragRefresh = false;

                ForceRefresh();
                return;
            }

            // Drag из другого слота экипировки (slot → slot)
            if (_draggedFromEquipmentSlot != null && _draggedFromSlotItem != null)
            {
                if (ValidateEquipItem(_draggedFromSlotItem, slot))
                    TryEquipItemFromSlot(_draggedFromEquipmentSlot, slot);
            }
        }

        #endregion

        #region Hover Highlight

        /// <summary>
        /// TASK 1: Выделение предмета при наведении (hover).
        /// Вызывается из UI_Item.OnPointerEnter.
        /// </summary>
        public void OnItemHovered(UI_Item hoveredItem)
        {
            if (!_enableHoverHighlight) return;
            if (hoveredItem == null || hoveredItem.Item == null) return;
            if (_isDragging) return;

            // Снимаем с предыдущего
            if (_hoveredItem != null && _hoveredItem != hoveredItem)
                _hoveredItem.SetSelected(false);

            hoveredItem.SetSelected(true);
            _hoveredItem = hoveredItem;
        }

        /// <summary>Снять выделение при уходе курсора.</summary>
        public void OnItemUnhovered(UI_Item unhoveredItem)
        {
            if (unhoveredItem == null) return;
            if (_hoveredItem == unhoveredItem)
            {
                unhoveredItem.SetSelected(false);
                _hoveredItem = null;
            }
        }

        /// <summary>Снять hover со всех предметов.</summary>
        private void ClearHover()
        {
            if (_hoveredItem != null)
            {
                _hoveredItem.SetSelected(false);
                _hoveredItem = null;
            }
        }

        #endregion

        #region Drag Outline & Snap Helpers

        /// <summary>
        /// ФИКС #5: Настраивает призрак как обводку (semi-transparent rect без иконки).
        /// </summary>
        private void SetupDragOutline(InventoryItem item)
        {
            if (_dragGhost == null || _dragGhostRT == null) return;

            if (_rootCanvasTransform != null)
                _dragGhost.transform.SetParent(_rootCanvasTransform, false);

            // Root: обводка (semi-transparent цвет, без sprite)
            _dragGhostRT.anchorMin = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchorMax = new Vector2(0.5f, 0.5f);
            _dragGhostRT.pivot = new Vector2(0.5f, 0.5f);
            _dragGhostRT.anchoredPosition = Vector2.zero;
            _dragGhostRT.localScale = Vector3.one;
            _dragGhostRT.localRotation = Quaternion.identity;
            _dragGhostRT.SetAsLastSibling();

            if (_dragGhostRootImage != null)
            {
                _dragGhostRootImage.sprite = null;
                _dragGhostRootImage.type = Image.Type.Simple;
                _dragGhostRootImage.color = Color.clear;
                _dragGhostRootImage.enabled = false;
                _dragGhostRootImage.raycastTarget = false;
            }

            // TASK 4: Иконка ВИДНА — предмет «летает» над ячейками
            if (_dragGhostImage != null)
            {
                _dragGhostImage.enabled = true;
                _dragGhostImage.sprite = item.Data.Icon;
                _dragGhostImage.preserveAspect = false;
            }

            UpdateGhostSize();
            UpdateGhostRotation();
        }

        /// <summary>
        /// ФИКС #1: Вычисляет top-left позицию предмета из позиции курсора (центр предмета).
        /// </summary>
        public static (int x, int y) CalculateSnapPosition(
            int cursorSlotX, int cursorSlotY, Vector2Int itemSize, int gridWidth, int gridHeight)
        {
            // Cursor = центр предмета. Top-left = cursor - size/2.
            int targetX = cursorSlotX - itemSize.x / 2;
            int targetY = cursorSlotY - itemSize.y / 2;

            // Clamp чтобы предмет не вылезал за сетку
            int maxX = Mathf.Max(0, gridWidth - itemSize.x);
            int maxY = Mathf.Max(0, gridHeight - itemSize.y);

            targetX = Mathf.Clamp(targetX, 0, maxX);
            targetY = Mathf.Clamp(targetY, 0, maxY);

            return (targetX, targetY);
        }

        /// <summary>
        /// Публичный метод для K_InventorySlotUI — рассчитывает скорректированную позицию drop.
        /// </summary>
        public (int x, int y) GetAdjustedDropPosition(int slotX, int slotY, Vector2Int itemSize, GridType gridType)
        {
            var controller = GetControllerForGrid(gridType);
            if (controller == null) return (slotX, slotY);
            return CalculateSnapPosition(slotX, slotY, itemSize, controller.Width, controller.Height);
        }

        #endregion

        #region Debug Helpers

        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs)
                UnityEngine.Debug.Log(message);
        }

        #endregion
    }
}