﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using K_Incident.Core.Inventory;

namespace K_Incident.Core.Inventory
{
    /// <summary>
    /// UI-представление предмета в инвентаре.
    ///
    /// ИСПРАВЛЕНО:
    /// #1:  EnsureIconIsChild() — raycast target на root.
    /// #ROT: Вращение теперь ВСЕГДА через RotationAngle напрямую, без IsRotated-гейта.
    ///       Это гарантирует 4 чётких шага (0°→-90°→-180°→-270°→0°).
    /// #SEL: Добавлено выделение предмета по клику (цвет настраивается через инспектор).
    /// </summary>
    public class UI_Item : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler,
                          IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
    {
        #region Inspector Fields

        [Header("References")]
        [SerializeField] private Image _icon;
        [SerializeField] private TextMeshProUGUI _quantityText;
        [SerializeField] private GameObject _quantityGroup;

        [Header("Selection (Click Highlight)")]
        [SerializeField, Tooltip("Цвет выделения при клике на предмет")]
        private Color _selectionColor = new Color(1f, 0.85f, 0f, 0.35f);

        [Header("Debug")]
        [SerializeField] private bool _debugLogs = false;

        #endregion

        #region Constants

        private static readonly Vector2 OFFSCREEN_POSITION = new Vector2(-9999f, -9999f);
        private static Sprite _transparentSprite; // 1x1 прозрачный спрайт для raycast

        #endregion

        #region Fields

        private InventoryItem _item;
        private K_InventoryUI _inventoryUI;
        private GridType _gridType;
        private int _gridX, _gridY;
        private bool _isDragging;
        private CanvasGroup _canvasGroup;
        private RectTransform _bodyRect;
        private RectTransform _iconRect;
        private bool _iconEnsuredAsChild;
        private Image _raycastTarget;
        private Image _selectionOverlay; // ИСПРАВЛЕНИЕ #SEL: оверлей выделения

        #endregion

        #region Properties

        public InventoryItem Item => _item;
        public GridType GridType => _gridType;
        public int X => _gridX;
        public int Y => _gridY;
        public bool IsDragging => _isDragging;
        public Color SelectionColor => _selectionColor;

        #endregion

        /// <summary>
        /// Создаёт 1x1 полностью прозрачный спрайт.
        /// Используется для raycast-target Image, чтобы Unity не рендерила белую пелену.
        /// </summary>
        private static Sprite GetTransparentSprite()
        {
            if (_transparentSprite != null) return _transparentSprite;
            var tex = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            tex.SetPixel(0, 0, Color.clear);
            tex.Apply();
            _transparentSprite = Sprite.Create(tex, new Rect(0, 0, 1, 1), Vector2.zero, 1f);
            _transparentSprite.name = "TransparentRaycast";
            return _transparentSprite;
        }

        #region Initialization

        private void Awake()
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_canvasGroup == null)
                _canvasGroup = gameObject.AddComponent<CanvasGroup>();

            _bodyRect = GetComponent<RectTransform>();

            EnsureIconIsChild();
            EnsureRaycastTarget();
            EnsureSelectionOverlay();
        }

        /// <summary>
        /// Гарантирует, что иконка живёт в отдельном child-RectTransform.
        /// </summary>
        private void EnsureIconIsChild()
        {
            if (_icon == null)
                _icon = GetComponentInChildren<Image>();

            if (_icon == null)
            {
                Debug.LogWarning($"[UI_Item] {gameObject.name}: Image (icon) не назначена!");
                return;
            }

            _iconRect = _icon.rectTransform;

            if (_iconRect == _bodyRect)
            {
                var childObj = new GameObject("Icon", typeof(RectTransform), typeof(Image));
                childObj.transform.SetParent(_bodyRect, false);

                var childRT = childObj.GetComponent<RectTransform>();
                childRT.anchorMin = new Vector2(0.5f, 0.5f);
                childRT.anchorMax = new Vector2(0.5f, 0.5f);
                childRT.pivot = new Vector2(0.5f, 0.5f);
                childRT.anchoredPosition = Vector2.zero;
                childRT.localRotation = Quaternion.identity;
                childRT.localScale = Vector3.one;

                var childImage = childObj.GetComponent<Image>();
                childImage.sprite = _icon.sprite;
                childImage.color = Color.white;
                childImage.type = _icon.type;
                childImage.preserveAspect = false;
                childImage.raycastTarget = true; // Raycast через иконку, не через root
                childImage.enabled = true;

                _icon.enabled = false;
                _icon.raycastTarget = false;

                _icon = childImage;
                _iconRect = childRT;
            }
            else
            {
                _icon.raycastTarget = true; // Raycast через иконку
            }

            _iconRect.anchorMin = new Vector2(0.5f, 0.5f);
            _iconRect.anchorMax = new Vector2(0.5f, 0.5f);
            _iconRect.pivot = new Vector2(0.5f, 0.5f);
            _iconRect.anchoredPosition = Vector2.zero;
            _iconRect.localScale = Vector3.one;

            _iconEnsuredAsChild = true;
        }

        /// <summary>
        /// Отключает ВСЕ Image на root (полностью — enabled=false).
        /// Raycast обрабатывается через иконку-ребёнок (в EnsureIconIsChild).
        /// </summary>
        private void EnsureRaycastTarget()
        {
            var allImages = GetComponents<Image>();
            foreach (var img in allImages)
            {
                if (img == null) continue;
                img.sprite = null;
                img.color = Color.clear;
                img.raycastTarget = false;
                img.enabled = false;
            }
            _raycastTarget = null;
        }

        /// <summary>
        /// ИСПРАВЛЕНИЕ #SEL: Создаёт невидимый Image-оверлей для выделения по клику.
        /// Размер совпадает с телом предмета. По умолчанию выключен.
        /// </summary>
        private void EnsureSelectionOverlay()
        {
            // Проверяем, нет ли уже оверлея
            Transform existing = _bodyRect.Find("SelectionOverlay");
            if (existing != null)
            {
                _selectionOverlay = existing.GetComponent<Image>();
                if (_selectionOverlay == null)
                    _selectionOverlay = existing.gameObject.AddComponent<Image>();
                _selectionOverlay.color = Color.clear;
                _selectionOverlay.raycastTarget = false;
                // ФИКС: отключаем по умолчанию — enabled Image без sprite
                // может рендерить артефакт (серая пелена) в некоторых версиях Unity.
                _selectionOverlay.enabled = false;
                return; // Оверлей уже существует — не создаём дубликат
            }

            // Создаём
            var overlayObj = new GameObject("SelectionOverlay", typeof(RectTransform), typeof(Image));
            overlayObj.transform.SetParent(_bodyRect, false);

            var rt = overlayObj.GetComponent<RectTransform>();
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.pivot = new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = Vector2.zero;
            rt.sizeDelta = Vector2.zero; // Растянется на весь parent
            rt.localScale = Vector3.one;

            _selectionOverlay = overlayObj.GetComponent<Image>();
            _selectionOverlay.sprite = null;
            _selectionOverlay.type = Image.Type.Simple;
            _selectionOverlay.color = Color.clear;
            _selectionOverlay.raycastTarget = false;
            // ФИКС: отключаем по умолчанию — enabled Image без sprite
            // может рендерить артефакт (серая пелена) в некоторых версиях Unity.
            _selectionOverlay.enabled = false;
        }

        public void Setup(InventoryItem item, K_InventoryUI inventoryUI, GridType gridType, int x, int y)
        {
            _item = item;
            _inventoryUI = inventoryUI;
            _gridType = gridType;
            _gridX = x;
            _gridY = y;

            if (_canvasGroup != null)
            {
                _canvasGroup.interactable = true;
                _canvasGroup.blocksRaycasts = true;
                _canvasGroup.alpha = 1f;
            }

            // Сброс выделения при переиспользовании из пула
            ClearSelection();

            gameObject.SetActive(true);
            UpdateVisuals();
            LogDebug($"[UI_Item] Setup: {item.Data.DisplayName} at [{x},{y}] GridType={gridType}");
        }

        #endregion

        #region Visual Updates

        public void UpdateVisuals()
        {
            if (_item == null || _item.Data == null) return;

            if (!_iconEnsuredAsChild)
                EnsureIconIsChild();

            if (_icon != null && _item.Data.Icon != null)
            {
                _icon.sprite = _item.Data.Icon;
                _icon.color = Color.white;
                _icon.enabled = true;
            }
            else if (_icon != null)
            {
                _icon.enabled = false;
            }

            float slotSize = _inventoryUI != null ? _inventoryUI.SlotSize : 70f;
            float slotSpacing = _inventoryUI != null ? _inventoryUI.SlotSpacing : 0f;

            // Body — CurrentSize (с учётом поворота).
            if (_bodyRect != null)
            {
                Vector2Int currentSize = _item.CurrentSize;
                float widthPx = currentSize.x * slotSize + (currentSize.x - 1) * slotSpacing;
                float heightPx = currentSize.y * slotSize + (currentSize.y - 1) * slotSpacing;
                _bodyRect.sizeDelta = new Vector2(widthPx, heightPx);
                _bodyRect.localRotation = Quaternion.identity;
            }

            // Иконка — размер по Data.Size, с swap если IconBaseRotation меняет оси.
            if (_icon != null && _iconRect != null)
            {
                Vector2Int normalSize = _item.Data.Size;
                bool iconSwapsAxes = Mathf.Abs(_item.IconBaseRotation % 180) > 0.01f;
                float iconW = (iconSwapsAxes ? normalSize.y : normalSize.x) * slotSize
                              + ((iconSwapsAxes ? normalSize.y : normalSize.x) - 1) * slotSpacing;
                float iconH = (iconSwapsAxes ? normalSize.x : normalSize.y) * slotSize
                              + ((iconSwapsAxes ? normalSize.x : normalSize.y) - 1) * slotSpacing;
                _iconRect.sizeDelta = new Vector2(iconW, iconH);

                _icon.preserveAspect = false;
                float visualAngle = _item.IconBaseRotation - _item.RotationAngle;
                _iconRect.localRotation = Quaternion.Euler(0, 0, visualAngle);

                Debug.Log($"[ROT-DIAG] {_item.Data.DisplayName} | Base={_item.IconBaseRotation} | R={_item.RotationAngle} | visual={visualAngle}");
            }

            // Количество
            if (_quantityText != null && _quantityGroup != null)
            {
                if (_item.Quantity > 1)
                {
                    _quantityGroup.SetActive(true);
                    _quantityText.text = _item.Quantity.ToString();
                }
                else
                {
                    _quantityGroup.SetActive(false);
                }
            }
        }

        public void UpdateData(InventoryItem item)
        {
            _item = item;
            UpdateVisuals();
        }

        #endregion

        #region Selection (Click Highlight)

        /// <summary>
        /// ИСПРАВЛЕНИЕ #SEL: Выделить предмет цветом.
        /// Вызывается из K_InventoryUI при клике ЛКМ.
        /// </summary>
        public void SetSelected(bool selected)
        {
            if (_selectionOverlay == null) return;
            _selectionOverlay.enabled = selected;
            _selectionOverlay.color = selected ? _selectionColor : Color.clear;
        }

        /// <summary>Снять выделение</summary>
        public void ClearSelection()
        {
            if (_selectionOverlay != null)
            {
                _selectionOverlay.color = Color.clear;
                _selectionOverlay.enabled = false;
            }
        }

        #endregion

        #region Pool Management

        public void ResetState()
        {
            _item = null;
            _inventoryUI = null;
            _gridType = GridType.Pockets;
            _gridX = 0;
            _gridY = 0;
            _isDragging = false;

            ClearSelection();

            if (_icon != null)
            {
                _icon.sprite = null;
                _icon.enabled = false;
                if (_iconRect != null)
                    _iconRect.localRotation = Quaternion.identity;
            }

            if (_quantityGroup != null)
                _quantityGroup.SetActive(false);

            if (_canvasGroup != null)
            {
                _canvasGroup.interactable = false;
                _canvasGroup.blocksRaycasts = false;
                _canvasGroup.alpha = 1f;
            }

            if (_bodyRect != null)
                _bodyRect.localRotation = Quaternion.identity;
        }

        #endregion

        #region Drag & Drop (EventSystem Interfaces)

        public void OnBeginDrag(PointerEventData eventData)
        {
            if (_item == null || _inventoryUI == null) return;

            _isDragging = true;

            if (_canvasGroup != null)
            {
                _canvasGroup.alpha = 0f;
                _canvasGroup.blocksRaycasts = false;
                _canvasGroup.interactable = false;
            }

            if (_bodyRect != null)
                _bodyRect.anchoredPosition = OFFSCREEN_POSITION;

            _inventoryUI.StartDrag(this, eventData);
            LogDebug($"[UI_Item] BeginDrag: {_item.Data.DisplayName}");
        }

        public void OnDrag(PointerEventData eventData)
        {
            _inventoryUI?.UpdateDragGhostPosition(eventData);
        }

        public void OnEndDrag(PointerEventData eventData)
        {
            _isDragging = false;

            if (_canvasGroup != null)
            {
                _canvasGroup.alpha = 1f;
                _canvasGroup.blocksRaycasts = true;
                _canvasGroup.interactable = true;
            }

            _inventoryUI?.EndDragComplete();
            LogDebug($"[UI_Item] EndDrag: {_item?.Data.DisplayName ?? "NULL"}");
        }

        public void OnPointerClick(PointerEventData eventData)
        {
            // Клик оставляем пустым — выделение теперь по наведению (hover).
        }

        public void OnPointerEnter(PointerEventData eventData)
        {
            if (_isDragging || _item == null) return;
            _inventoryUI?.OnItemHovered(this);
            LogDebug($"[UI_Item] Hover Enter: {_item?.Data.DisplayName}");
        }

        public void OnPointerExit(PointerEventData eventData)
        {
            if (_isDragging) return;
            _inventoryUI?.OnItemUnhovered(this);
            LogDebug($"[UI_Item] Hover Exit: {_item?.Data.DisplayName}");
        }

        #endregion

        #region Debug Helpers

        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        private void LogDebug(string message)
        {
            if (_debugLogs)
                Debug.Log(message);
        }

        #endregion
    }
}